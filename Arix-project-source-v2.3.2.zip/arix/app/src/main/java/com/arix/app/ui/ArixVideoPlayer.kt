package com.arix.app.ui

import android.view.ViewGroup
import androidx.annotation.OptIn
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.datasource.okhttp.OkHttpDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.ui.PlayerView
import com.arix.app.data.ArixMediaApi
import okhttp3.OkHttpClient
import java.util.concurrent.TimeUnit

/**
 * v2.3.2 — native video stage for direct streams (.mp4 / .m3u8 / .mpd).
 *
 * Replaces the WebView-based player stage: several stream CDNs validate the
 * Referer header (the MovieBox CDN answers 429 without it) and block
 * cross-origin manifest fetches (hls.js XHR). ExoPlayer performs plain HTTP
 * requests with explicit headers, so both problems disappear. The OkHttp
 * data source keeps TLS/HTTP2 behavior consistent with the scraper client.
 *
 * @param streamUrl   direct media URL
 * @param referer     page origin the CDN expects (empty = no Referer header)
 * @param posterUrl   optional poster, kept for future artwork use
 */
@OptIn(UnstableApi::class)
@Composable
internal fun ArixVideoPlayer(
    streamUrl: String,
    referer: String = "",
    posterUrl: String = "",
) {
    val context = LocalContext.current
    var playerError by remember(streamUrl) { mutableStateOf<String?>(null) }

    // One client per composition is fine; headers are per-request anyway.
    val httpClient = remember {
        OkHttpClient.Builder()
            .connectTimeout(12, TimeUnit.SECONDS)
            .readTimeout(20, TimeUnit.SECONDS)
            .followRedirects(true)
            .build()
    }

    val player = remember(streamUrl) {
        val requestHeaders = buildMap {
            put("User-Agent", ArixMediaApi.BrowserUserAgent)
            if (referer.isNotBlank()) put("Referer", referer)
            put("Accept", "*/*")
            put("Accept-Language", "en-US,en;q=0.9")
        }
        val httpFactory = OkHttpDataSource.Factory(httpClient)
            .setUserAgent(ArixMediaApi.BrowserUserAgent)
            .setDefaultRequestProperties(requestHeaders)
        val dataSourceFactory = DefaultDataSource.Factory(context, httpFactory)
        val mediaSourceFactory = DefaultMediaSourceFactory(dataSourceFactory)
        ExoPlayer.Builder(context)
            .setMediaSourceFactory(mediaSourceFactory)
            .setSeekBackIncrementMs(10_000L)
            .setSeekForwardIncrementMs(10_000L)
            .build()
            .apply {
                val mimeType = when {
                    streamUrl.contains(".m3u8", ignoreCase = true) -> MimeTypes.APPLICATION_M3U8
                    streamUrl.contains(".mpd", ignoreCase = true) -> MimeTypes.APPLICATION_MPD
                    else -> null
                }
                val mediaItemBuilder = MediaItem.Builder().setUri(streamUrl)
                if (mimeType != null) mediaItemBuilder.setMimeType(mimeType)
                setMediaItem(mediaItemBuilder.build())
                playWhenReady = true
                addListener(object : Player.Listener {
                    override fun onPlayerError(error: PlaybackException) {
                        playerError = when (val cause = error.cause) {
                            is androidx.media3.datasource.HttpDataSource.InvalidResponseCodeException -> {
                                val code = cause.responseCode
                                "Stream rejected (HTTP $code). Try another server."
                            }
                            else -> "Playback failed: ${error.errorCodeName}. Try another server."
                        }
                    }
                })
                prepare()
            }
    }

    DisposableEffect(streamUrl) {
        onDispose { player.release() }
    }

    // Keep the error overlay in sync when switching servers quickly.
    LaunchedEffect(streamUrl) { playerError = null }

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .aspectRatio(16f / 9f),
    ) {
        AndroidView(
            factory = { viewContext ->
                PlayerView(viewContext).apply {
                    useController = true
                    setShowSubtitleButton(true)
                    setShutterBackgroundColor(android.graphics.Color.BLACK)
                    layoutParams = ViewGroup.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.MATCH_PARENT,
                    )
                    resizeMode = androidx.media3.ui.AspectRatioFrameLayout.RESIZE_MODE_FIT
                }
            },
            update = { view -> view.player = player },
            modifier = Modifier.fillMaxSize(),
        )
        playerError?.let { message ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 18.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = androidx.compose.foundation.layout.Arrangement.Center,
            ) {
                Text(
                    text = message,
                    color = Color(0xFFE5757A),
                    textAlign = TextAlign.Center,
                    style = androidx.compose.material3.MaterialTheme.typography.bodySmall,
                )
                Spacer(Modifier.height(6.dp))
                Text(
                    text = "Pick another quality or server chip below.",
                    color = Color(0xFF9AA0A6),
                    textAlign = TextAlign.Center,
                    style = androidx.compose.material3.MaterialTheme.typography.labelSmall,
                )
            }
        }
    }
}

/** Media mime hint for captions side-loaded into the player. */
@OptIn(UnstableApi::class)
internal fun arixCaptionMimeType(url: String): String = when {
    url.contains(".vtt", ignoreCase = true) -> MimeTypes.TEXT_VTT
    else -> MimeTypes.APPLICATION_SUBRIP
}

@Suppress("unused")
private val unusedKeepReference: Any = C.TIME_UNSET
