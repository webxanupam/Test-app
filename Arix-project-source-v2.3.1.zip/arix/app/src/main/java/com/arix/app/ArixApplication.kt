package com.arix.app

import android.app.Application
import android.content.Context
import androidx.lifecycle.DefaultLifecycleObserver
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.ProcessLifecycleOwner
import com.posthog.android.PostHogAndroid
import com.posthog.android.PostHogAndroidConfig
import com.arix.app.data.AgentExtensionsRepository
import com.arix.app.data.AlpineChromeController
import com.arix.app.data.AgentModeController
import com.arix.app.data.AgentSkillManager
import com.arix.app.data.ArixAppExtensionManager
import com.arix.app.data.ArixSystemControlTool
import com.arix.app.data.ArixModKernel
import com.arix.app.data.ArixDiagnosticLogger
import com.arix.app.data.ArixToolExecutor
import com.arix.app.data.ChatRepository
import com.arix.app.data.PiExtensionManager
import com.arix.app.data.PiExtensionStateRepository
import com.arix.app.data.RuntimeWorkspaceFileBridge
import com.arix.app.data.ChatStateStore
import com.arix.app.data.ScheduledTask
import com.arix.app.data.ScheduledTaskManager
import com.arix.app.data.ScheduledTaskRepository
import com.arix.app.data.ScheduledTaskScheduler
import com.arix.app.data.SessionExecutionManager
import com.arix.app.data.SettingsRepository
import com.arix.app.data.WorkspaceFileBridge
import com.arix.app.data.pi.PiCompletionClient
import com.arix.app.data.pi.PiAgentRunner
import com.arix.app.data.pi.PiKernelBridge
import com.arix.app.mod.ArixNativeModManager
import com.arix.app.runtime.AlpineRuntime
import com.arix.app.runtime.RuntimeRouter
import kotlinx.coroutines.CoroutineExceptionHandler
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

class ArixApplication : Application() {
    val runtime: ArixAppRuntime by lazy(LazyThreadSafetyMode.NONE) {
        ArixAppRuntime(this)
    }
    @Volatile
    private var isPostHogInitialized = false

    override fun onCreate() {
        super.onCreate()
        // v2.3.0 hardening: the accessibility service shares this process, and
        // Android flags the service as "malfunctioning" (and disables it) when
        // the process crashes or blocks during startup. No initialization step
        // below is allowed to take the process down — failures are logged and
        // the app continues degraded instead of killing the service binding.
        runCatching {
            // Must run before any repository opens a DataStore/SharedPreferences/
            // Room file: carries v2.1.5 "aether_*" data into the "arix_*" stores.
            com.arix.app.data.LegacyAetherStoreMigrator.migrate(this)
        }.onFailure { throwable ->
            android.util.Log.e("ArixApplication", "Legacy store migration failed", throwable)
        }
        runCatching {
            // v2.2.7: media backend (movies/anime JSON + poster disk cache).
            com.arix.app.data.ArixMediaApi.initialize(this)
            com.arix.app.data.ArixMediaApi.initializePosterCache(this)
        }.onFailure { throwable ->
            android.util.Log.e("ArixApplication", "Media backend init failed", throwable)
        }
        runCatching { runtime.initialize() }.onFailure { throwable ->
            android.util.Log.e("ArixApplication", "Runtime init failed", throwable)
        }
    }

    override fun onTerminate() {
        runtime.nativeModManager.shutdown()
        super.onTerminate()
    }

    fun initializePostHog() {
        if (isPostHogInitialized || BuildConfig.POSTHOG_API_KEY.isBlank()) return
        synchronized(this) {
            if (isPostHogInitialized || BuildConfig.POSTHOG_API_KEY.isBlank()) return
            val config = PostHogAndroidConfig(
                apiKey = BuildConfig.POSTHOG_API_KEY,
                host = BuildConfig.POSTHOG_HOST,
            ).apply {
                captureApplicationLifecycleEvents = true
                captureDeepLinks = true
                captureScreenViews = true
                debug = BuildConfig.DEBUG
                releaseIdentifier = "${BuildConfig.APPLICATION_ID}@${BuildConfig.VERSION_NAME}+${BuildConfig.VERSION_CODE}"
                errorTrackingConfig.autoCapture = true
                errorTrackingConfig.inAppIncludes.addAll(
                    listOf(
                        "com.arix.app",
                    ),
                )
            }
            PostHogAndroid.setup(this, config)
            isPostHogInitialized = true
        }
    }
}

class ArixAppRuntime(
    private val application: ArixApplication,
) {
    val diagnosticLogger = ArixDiagnosticLogger(application)
    private val appScope = CoroutineScope(
        SupervisorJob() +
            Dispatchers.Default +
            CoroutineExceptionHandler { _, throwable ->
                diagnosticLogger.exception(
                    category = "coroutine",
                    event = "uncaught_exception",
                    throwable = throwable,
                )
            }
    )

    val settingsRepository = SettingsRepository(application)
    val piExtensionStateRepository = PiExtensionStateRepository(application)
    val modKernel = ArixModKernel()
    val chatRepository = ChatRepository(application)
    val extensionsRepository = AgentExtensionsRepository(application)
    val scheduledTaskRepository = ScheduledTaskRepository(application)
    val alpineRuntime = AlpineRuntime(
        context = application,
        diagnosticLogger = diagnosticLogger,
    )
    val piKernelBridge = PiKernelBridge(
        alpineRuntime = alpineRuntime,
        diagnosticLogger = diagnosticLogger,
    )
    val nativeModManager = ArixNativeModManager(
        context = application,
        application = application,
        alpineRuntime = alpineRuntime,
        piKernelBridge = piKernelBridge,
        kernel = modKernel,
        piExtensionStateRepository = piExtensionStateRepository,
        diagnosticLogger = diagnosticLogger,
    )
    val piCompletionClient = PiCompletionClient(
        bridge = piKernelBridge,
        settingsRepository = settingsRepository,
    )
    val runtimeRouter = RuntimeRouter(
        alpineRuntime = alpineRuntime,
    )
    val workspaceFileBridge = WorkspaceFileBridge(
        context = application,
        alpineRuntime = alpineRuntime,
    )
    val runtimeWorkspaceFileBridge = RuntimeWorkspaceFileBridge(
        context = application,
        alpineRuntime = alpineRuntime,
    )
    val agentModeController = AgentModeController(
        context = application,
        runtimeWorkspaceFileBridge = runtimeWorkspaceFileBridge,
        diagnosticLogger = diagnosticLogger,
    )
    val systemControlTool = ArixSystemControlTool(
        context = application,
    )
    val alpineChromeController = AlpineChromeController(
        context = application,
        alpineRuntime = alpineRuntime,
        diagnosticLogger = diagnosticLogger,
    )
    val skillManager = AgentSkillManager(
        context = application,
        extensionsRepository = extensionsRepository,
    )
    val piExtensionManager = PiExtensionManager(
        context = application,
        alpineRuntime = alpineRuntime,
        piKernelBridge = piKernelBridge,
        skillManager = skillManager,
        stateRepository = piExtensionStateRepository,
    )
    val arixAppExtensionManager = ArixAppExtensionManager(
        bridge = piKernelBridge,
        scope = appScope,
        diagnosticLogger = diagnosticLogger,
        modKernel = modKernel,
        loadOptionsProvider = piExtensionStateRepository::loadOptions,
    )
    val piAgentRunner = PiAgentRunner(
        bridge = piKernelBridge,
        settingsRepository = settingsRepository,
        piExtensionStateRepository = piExtensionStateRepository,
        appExtensionManager = arixAppExtensionManager,
        alpineChromeController = alpineChromeController,
        diagnosticLogger = diagnosticLogger,
        toolExecutor = ArixToolExecutor(
            runtimeRouter = runtimeRouter,
            agentModeController = agentModeController,
            systemControlTool = systemControlTool,
        ),
    )
    val appForegroundTracker = AppForegroundTracker()
    val notificationController = ArixNotificationController(application)
    val scheduledTaskScheduler = ScheduledTaskScheduler(
        context = application,
        diagnosticLogger = diagnosticLogger,
    )
    val scheduledTaskManager = ScheduledTaskManager(
        repository = scheduledTaskRepository,
        scheduler = scheduledTaskScheduler,
    )
    val chatStateStore = ChatStateStore(
        scope = appScope,
        chatRepository = chatRepository,
    )
    val sessionExecutionManager = SessionExecutionManager(
        application = application,
        scope = appScope,
        settingsRepository = settingsRepository,
        extensionsRepository = extensionsRepository,
        chatStateStore = chatStateStore,
        chatRepository = chatRepository,
        runtimeRouter = runtimeRouter,
        workspaceFileBridge = workspaceFileBridge,
        agentModeController = agentModeController,
        skillManager = skillManager,
        scheduledTaskManager = scheduledTaskManager,
        notificationController = notificationController,
        appForegroundTracker = appForegroundTracker,
        diagnosticLogger = diagnosticLogger,
        piCompletionClient = piCompletionClient,
        piKernelBridge = piKernelBridge,
        piAgentRunner = piAgentRunner,
    )

    fun initialize() {
        diagnosticLogger.installUncaughtExceptionHandler()
        diagnosticLogger.event(
            category = "app",
            event = "startup",
            details = mapOf(
                "version_name" to BuildConfig.VERSION_NAME,
                "version_code" to BuildConfig.VERSION_CODE,
                "debug" to BuildConfig.DEBUG,
            ),
        )
        notificationController.ensureChannels()
        ProcessLifecycleOwner.get().lifecycle.addObserver(appForegroundTracker)
        appScope.launch {
            nativeModManager.initialize()
        }
        appScope.launch {
            alpineRuntime.refreshApkRepositoriesForCurrentNetwork()
        }
        appScope.launch {
            settingsRepository.migrateLegacyProvidersToPi()
        }
        appScope.launch {
            if (settingsRepository.settings.first().privacyPolicyAccepted) {
                initializePostHog()
            }
        }
        appScope.launch {
            scheduledTaskManager.rescheduleAll()
        }
    }

    fun initializePostHog() {
        application.initializePostHog()
    }

    fun handleScheduledTaskAlarm(
        taskId: String,
        pendingResult: android.content.BroadcastReceiver.PendingResult,
    ) {
        diagnosticLogger.event(
            category = "scheduled_task",
            event = "alarm_received",
            details = mapOf("task_id" to taskId),
        )
        appScope.launch {
            try {
                val task = scheduledTaskManager.markTriggeredAndScheduleNext(taskId)
                if (task == null) {
                    diagnosticLogger.event(
                        category = "scheduled_task",
                        event = "trigger_missing_task",
                        level = "warn",
                        details = mapOf("task_id" to taskId),
                    )
                    return@launch
                }
                val started = startScheduledTaskFromAlarm(task)
                diagnosticLogger.event(
                    category = "scheduled_task",
                    event = if (started) "trigger_started" else "trigger_skipped",
                    level = if (started) "info" else "warn",
                    details = mapOf("task_id" to taskId),
                )
            } finally {
                pendingResult.finish()
            }
        }
    }

    private suspend fun startScheduledTaskFromAlarm(task: ScheduledTask): Boolean {
        return try {
            if (settingsRepository.settings.first().keepTasksRunningInBackground) {
                runCatching {
                    ArixForegroundService.ensureRunning(application)
                }.onFailure { throwable ->
                    diagnosticLogger.exception(
                        category = "scheduled_task",
                        event = "foreground_service_start_failed",
                        throwable = throwable,
                        details = mapOf("task_id" to task.id),
                    )
                }
            }
            sessionExecutionManager.startScheduledTask(task)
        } catch (throwable: Throwable) {
            diagnosticLogger.exception(
                category = "scheduled_task",
                event = "trigger_start_failed",
                throwable = throwable,
                details = mapOf("task_id" to task.id),
            )
            false
        }
    }

    fun rescheduleScheduledTasks(
        pendingResult: android.content.BroadcastReceiver.PendingResult,
    ) {
        appScope.launch {
            try {
                scheduledTaskManager.rescheduleAll()
            } finally {
                pendingResult.finish()
            }
        }
    }
}

class AppForegroundTracker : DefaultLifecycleObserver {
    private val _isForeground = MutableStateFlow(false)

    val isForeground: StateFlow<Boolean> = _isForeground.asStateFlow()

    override fun onStart(owner: LifecycleOwner) {
        _isForeground.value = true
    }

    override fun onStop(owner: LifecycleOwner) {
        _isForeground.value = false
    }
}

val Context.arixRuntime: ArixAppRuntime
    get() = (applicationContext as ArixApplication).runtime
