package com.arix.app.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Construction
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material.icons.outlined.Construction
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Language
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material.icons.outlined.Terminal
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.ripple
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import com.arix.app.ui.theme.ArixPrimary
import com.arix.app.ui.theme.ArixSurfaceHigher

/** Height of the bottom navigation pill including its inner chrome. */
val ArixBottomNavBarHeight = 64.dp

/**
 * Premium floating bottom navigation: an icon-only pill with a soft violet
 * glow behind the active tab. No labels — Home, Tools, Terminal, Browser,
 * Settings. Items share the width evenly (weight) so the pill fits every
 * screen size.
 *
 * The bar hides when the IME is open so the composer can use the full width,
 * and it is only rendered on the main tab screens (Settings is full-screen
 * with its own back navigation).
 */
@Composable
fun ArixBottomNavBar(
    currentScreen: AppScreen,
    imeVisible: Boolean,
    onSelect: (AppScreen) -> Unit,
    modifier: Modifier = Modifier,
) {
    val navBottomPadding = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()
    val lift by animateDpAsState(
        targetValue = if (imeVisible) 0.dp else 10.dp,
        animationSpec = tween(durationMillis = 220),
        label = "arix_bottom_nav_lift",
    )
    AnimatedVisibility(
        visible = !imeVisible,
        enter = slideInVertically(tween(220)) { it / 2 } + fadeIn(tween(180)),
        exit = slideOutVertically(tween(180)) { it / 2 } + fadeOut(tween(140)),
        modifier = modifier,
    ) {
        Surface(
            modifier = Modifier
                .padding(start = 24.dp, end = 24.dp, bottom = lift + navBottomPadding.coerceAtMost(6.dp))
                .shadow(elevation = 18.dp, ambientColor = Color(0x66000000), spotColor = Color(0x88000000), shape = RoundedCornerShape(28.dp)),
            shape = RoundedCornerShape(28.dp),
            color = ArixSurfaceHigher.copy(alpha = 0.98f),
            contentColor = ArixPrimary,
            border = null,
            shadowElevation = 0.dp,
        ) {
            Row(
                modifier = Modifier
                    .height(ArixBottomNavBarHeight)
                    .padding(horizontal = 14.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                ArixBottomNavItem(
                    icon = Icons.Outlined.Home,
                    activeIcon = Icons.Filled.Home,
                    contentDescription = "Home",
                    selected = currentScreen == AppScreen.Chat,
                    onSelect = { onSelect(AppScreen.Chat) },
                    modifier = Modifier.weight(1f),
                )
                ArixBottomNavItem(
                    icon = Icons.Outlined.Construction,
                    activeIcon = Icons.Filled.Construction,
                    contentDescription = "Tools",
                    selected = currentScreen == AppScreen.Tools,
                    onSelect = { onSelect(AppScreen.Tools) },
                    modifier = Modifier.weight(1f),
                )
                ArixBottomNavItem(
                    icon = Icons.Outlined.Terminal,
                    activeIcon = Icons.Filled.Terminal,
                    contentDescription = "Terminal",
                    selected = currentScreen == AppScreen.Terminal,
                    onSelect = { onSelect(AppScreen.Terminal) },
                    modifier = Modifier.weight(1f),
                )
                ArixBottomNavItem(
                    icon = Icons.Outlined.Language,
                    activeIcon = Icons.Filled.Language,
                    contentDescription = "Browser",
                    selected = currentScreen == AppScreen.Browser,
                    onSelect = { onSelect(AppScreen.Browser) },
                    modifier = Modifier.weight(1f),
                )
                // v2.3.1: direct Settings access from the bottom bar.
                ArixBottomNavItem(
                    icon = Icons.Outlined.Settings,
                    activeIcon = Icons.Filled.Settings,
                    contentDescription = "Settings",
                    selected = currentScreen == AppScreen.Settings,
                    onSelect = { onSelect(AppScreen.Settings) },
                    modifier = Modifier.weight(1f),
                )
            }
        }
    }
}

@Composable
private fun ArixBottomNavItem(
    icon: ImageVector,
    activeIcon: ImageVector,
    contentDescription: String,
    selected: Boolean,
    onSelect: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val interaction = androidx.compose.runtime.remember { MutableInteractionSource() }
    Box(
        modifier = modifier
            .padding(horizontal = 3.dp)
            .height(48.dp)
            .clip(RoundedCornerShape(18.dp))
            .background(
                when {
                    selected -> Brush.verticalGradient(
                        listOf(
                            ArixPrimary.copy(alpha = 0.22f),
                            ArixPrimary.copy(alpha = 0.10f),
                        ),
                    )
                    else -> Brush.verticalGradient(
                        listOf(Color.Transparent, Color.Transparent),
                    )
                },
            )
            .clickable(
                interactionSource = interaction,
                indication = ripple(bounded = true, color = ArixPrimary.copy(alpha = 0.35f)),
            ) { onSelect() },
        contentAlignment = Alignment.Center,
    ) {
        Box(contentAlignment = Alignment.Center) {
            // Soft glow halo behind the active icon.
            Box(
                modifier = Modifier
                    .size(if (selected) 34.dp else 0.dp)
                    .clip(CircleShape)
                    .background(ArixPrimary.copy(alpha = if (selected) 0.18f else 0f)),
            )
            Icon(
                imageVector = if (selected) activeIcon else icon,
                contentDescription = contentDescription,
                // v2.3.0 fix: inactive tabs were tinted with ArixSurfaceVariant
                // (a dark surface tone) which made the icons nearly invisible
                // on the dark pill background. Inactive icons are now white
                // with a slight dim; the active tab keeps the violet accent.
                tint = if (selected) ArixPrimary else Color(0xCCFFFFFF),
                modifier = Modifier.size(23.dp),
            )
        }
    }
}
