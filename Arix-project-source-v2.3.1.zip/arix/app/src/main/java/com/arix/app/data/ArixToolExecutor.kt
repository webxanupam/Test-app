package com.arix.app.data

import com.arix.app.runtime.RuntimeRouter
import org.json.JSONArray
import org.json.JSONObject

data class ArixToolExecutionResult(
    val toolName: String,
    val argumentsJson: String,
    val rawOutput: String,
    val visibleOutput: String = ArixToolExecutor.sanitizeToolOutputForConversation(toolName, rawOutput),
) {
    val isError: Boolean = !ArixToolExecutor.inferToolOutputOk(visibleOutput)
}

/**
 * Adapter for Arix-owned host capabilities only. Pi Coding Agent owns all
 * filesystem, shell, search, Skill, Extension, and image-reading mechanics.
 */
class ArixToolExecutor(
    private val runtimeRouter: RuntimeRouter,
    private val agentModeController: AgentModeController? = null,
    private val systemControlTool: ArixSystemControlTool? = null,
) {
    suspend fun execute(
        settings: AppSettings,
        workspaceDirectory: String,
        toolName: String,
        argumentsJson: String,
        selfManagementTool: ArixSelfManagementTool? = null,
        agentModeEnabled: Boolean = false,
        currentRuntimeId: LocalRuntimeId = settings.defaultRuntimeId ?: LocalRuntimeId.Alpine,
        onRuntimeChanged: suspend (LocalRuntimeId) -> Unit = {},
        onProgress: (suspend (String) -> Unit)? = null,
    ): ArixToolExecutionResult {
        val rawOutput = when (toolName) {
            "system_control" -> systemControlTool?.execute(argumentsJson)
                ?: unavailableToolOutput(toolName)

            "agent_mode" -> if (agentModeEnabled) {
                agentModeController?.execute(
                    settings = settings,
                    workspaceDirectory = workspaceDirectory,
                    argumentsJson = argumentsJson,
                ) ?: unavailableToolOutput(toolName)
            } else {
                JSONObject()
                    .put("ok", false)
                    .put("errmsg", "Agent Mode is not enabled for this chat.")
                    .toString()
            }

            "arix_runtime_manage" -> executeRuntimeManage(
                settings = settings,
                currentRuntimeId = currentRuntimeId,
                workspaceDirectory = workspaceDirectory,
                argumentsJson = argumentsJson,
                onRuntimeChanged = onRuntimeChanged,
            )

            in SelfManagementToolNames -> selfManagementTool?.execute(
                toolName = toolName,
                argumentsJson = argumentsJson,
            ) ?: unavailableToolOutput(toolName)

            else -> JSONObject()
                .put("ok", false)
                .put("error", "Unknown Arix host tool '$toolName'.")
                .toString()
        }
        return ArixToolExecutionResult(toolName, argumentsJson, rawOutput)
    }

    private suspend fun executeRuntimeManage(
        settings: AppSettings,
        currentRuntimeId: LocalRuntimeId,
        workspaceDirectory: String,
        argumentsJson: String,
        onRuntimeChanged: suspend (LocalRuntimeId) -> Unit,
    ): String {
        val arguments = runCatching { JSONObject(argumentsJson) }.getOrNull()
            ?: return JSONObject().put("ok", false).put("errmsg", "Invalid JSON arguments.").toString()
        val action = arguments.optString("action").trim()
        if (action == "status") {
            val states = listOf(LocalRuntimeId.Alpine).associateWith { runtimeId ->
                runtimeRouter.runtimeById(runtimeId).inspectSetup()
            }
            return JSONObject().apply {
                put("ok", true)
                put("action", "status")
                put("runtime", currentRuntimeId.storageValue)
                put("cwd", workspaceDirectory)
                put(
                    "available",
                    JSONObject().apply {
                        states.forEach { (runtimeId, state) -> put(runtimeId.storageValue, state.isReady) }
                    },
                )
            }.toString()
        }
        if (action != "set") {
            return JSONObject().put("ok", false).put("errmsg", "action must be 'status' or 'set'.").toString()
        }
        val requested = LocalRuntimeId.fromStorage(arguments.optString("runtime"))
            ?: return JSONObject().put("ok", false).put("errmsg", "runtime must be 'alpine'.").toString()
        if (requested != LocalRuntimeId.Alpine) {
            return JSONObject().put("ok", false).put("errmsg", "Alpine is the only local runtime.").toString()
        }
        val setup = runtimeRouter.runtimeById(requested).inspectSetup()
        val enabled = settings.enabledRuntimeIds.isEmpty() || requested in settings.enabledRuntimeIds
        if (!setup.isReady || !enabled) {
            return JSONObject().apply {
                put("ok", false)
                put("errmsg", "${requested.displayName} runtime is unavailable.")
                put("detail", setup.detail)
                put("runtime", currentRuntimeId.storageValue)
                put("cwd", workspaceDirectory)
            }.toString()
        }
        onRuntimeChanged(requested)
        return JSONObject().apply {
            put("ok", true)
            put("action", "set")
            put("runtime", requested.storageValue)
            put("cwd", workspaceDirectory)
        }.toString()
    }

    companion object {
        val hostToolNames: Set<String> = setOf("agent_mode", "system_control", *SelfManagementToolNames.toTypedArray())

        fun supports(toolName: String): Boolean = toolName in hostToolNames

        fun hostToolDefinitions(
            selfManagementTool: ArixSelfManagementTool? = null,
            agentModeEnabled: Boolean = false,
        ): JSONArray = JSONArray().apply {
            // Instant no-root system control is always available.
            put(ArixSystemControlTool.toolDefinition)
            selfManagementTool?.toolDefinitions()?.forEach { definition ->
                put(
                    flattenOpenAiToolDefinition(
                        definition = definition,
                        executionMode = if (
                            definition.optJSONObject("function")?.optString("name") == "arix_config_get"
                        ) "parallel" else "sequential",
                    ),
                )
            }
            if (agentModeEnabled) put(agentModeToolDefinition())
        }

        fun sanitizeToolOutputForConversation(toolName: String, output: String): String {
            if (toolName != "agent_mode") return output
            val parsed = runCatching { JSONObject(output) }.getOrNull() ?: return output
            if (!parsed.has("screenshot_base64")) return output
            parsed.remove("screenshot_base64")
            parsed.put("screenshot_injected_into_next_model_request", true)
            return parsed.toString()
        }

        fun inferToolOutputOk(output: String): Boolean {
            val parsed = runCatching { JSONObject(output) }.getOrNull() ?: return true
            return parsed.optBoolean("ok", !parsed.optBoolean("err", false))
        }
    }
}

private val SelfManagementToolNames = setOf(
    "arix_config_get",
    "arix_config_set",
    "arix_skill_manage",
    "arix_runtime_manage",
    "arix_agent_mode_manage",
    "arix_scheduled_task_manage",
    "arix_extension_manage",
    "arix_developer_manage",
)

private fun unavailableToolOutput(toolName: String): String = JSONObject()
    .put("ok", false)
    .put("errmsg", "Host dependency for '$toolName' is not available.")
    .toString()

private fun flattenOpenAiToolDefinition(
    definition: JSONObject,
    executionMode: String,
): JSONObject {
    val function = definition.optJSONObject("function") ?: JSONObject()
    return JSONObject().apply {
        put("name", function.optString("name"))
        put("description", function.optString("description"))
        put("parameters", relaxStrictOptionalParameters(function.optJSONObject("parameters")))
        put("execution_mode", executionMode)
    }
}

private fun relaxStrictOptionalParameters(parameters: JSONObject?): JSONObject {
    val relaxed = JSONObject((parameters ?: JSONObject().put("type", "object")).toString())
    val properties = relaxed.optJSONObject("properties") ?: return relaxed
    val required = relaxed.optJSONArray("required") ?: return relaxed
    relaxed.put(
        "required",
        JSONArray().apply {
            for (index in 0 until required.length()) {
                val name = required.optString(index)
                if (name.isNotBlank() && !properties.optJSONObject(name).allowsNull()) put(name)
            }
        },
    )
    return relaxed
}

private fun JSONObject?.allowsNull(): Boolean = when (val type = this?.opt("type")) {
    "null" -> true
    is JSONArray -> (0 until type.length()).any { type.optString(it) == "null" }
    else -> false
}

private fun agentModeToolDefinition(): JSONObject = JSONObject().apply {
    put("name", "agent_mode")
    put(
        "description",
        "No-root Agent Mode: drive the real Android screen through the Arix accessibility service. " +
            "Use only when Agent Mode is selected in the chat composer. Prefer read_screen / find_element / " +
            "click_element over raw coordinates whenever possible.",
    )
    put(
        "parameters",
        JSONObject().apply {
            put("type", "object")
            put(
                "properties",
                JSONObject().apply {
                    put(
                        "action",
                        stringProperty(
                            "One of: start, stop, status, list_apps, launch, open, tap, swipe, key, text, " +
                                "screenshot, read_screen, find_element, click_element, notifications, " +
                                "device_info, volume, settings, call, hud.",
                        ),
                    )
                    put("query", stringProperty("For list_apps: optional app filter. For find_element / click_element: on-screen text to match. For notifications: optional text filter."))
                    put("include_system", booleanProperty("For list_apps: whether to include system apps."))
                    put("max_results", integerProperty("For list_apps / notifications: maximum result count."))
                    put("target", stringProperty("For launch: package name or exact app label."))
                    put("url", stringProperty("For open: URL or deep link to open."))
                    listOf("x", "y", "x1", "y1", "x2", "y2", "duration_ms").forEach { key ->
                        put(key, integerProperty("Normalized coordinate or gesture duration for $key."))
                    }
                    put("key", stringProperty("For key: back, home, recents, notifications, quick_settings, power_dialog, split_screen, lock_screen, take_screenshot. For settings: brightness, auto_brightness, screen_timeout. For notifications dismiss: the notification key to dismiss."))
                    put("text", stringProperty("For text: text to type into the focused field."))
                    put("view_id", stringProperty("For find_element / click_element: view id substring to match."))
                    put("notification_action", stringProperty("For notifications: 'list' (default) or 'dismiss'."))
                    put("stream", stringProperty("For volume: music, ring, alarm, call, system, notification."))
                    put("level", integerProperty("For volume set: absolute level."))
                    put("delta", integerProperty("For volume set: relative step."))
                    put("volume_action", stringProperty("For volume: 'get' (default) or 'set'."))
                    put("settings_action", stringProperty("For settings: 'get' (default) or 'set'."))
                    put("value", integerProperty("For settings set / volume set: numeric value (settings booleans use 1/0)."))
                    put("call_action", stringProperty("For call: state, dial, answer, end."))
                    put("number", stringProperty("For call dial: phone number."))
                    put("visible", stringProperty("For hud: 'show' (default) or 'hide'."))
                },
            )
            put("required", JSONArray().put("action"))
            put("additionalProperties", false)
        },
    )
    put("execution_mode", "sequential")
}

private fun stringProperty(description: String): JSONObject = JSONObject()
    .put("type", "string")
    .put("description", description)

private fun integerProperty(description: String): JSONObject = JSONObject()
    .put("type", "integer")
    .put("description", description)

private fun booleanProperty(description: String): JSONObject = JSONObject()
    .put("type", "boolean")
    .put("description", description)
