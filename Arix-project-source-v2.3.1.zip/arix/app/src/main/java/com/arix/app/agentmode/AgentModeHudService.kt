package com.arix.app.agentmode

import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView

/**
 * Floating Agent Mode HUD (SYSTEM_ALERT_WINDOW, no root). Shows a draggable
 * status chip with a Stop control while an agent session is driving the
 * device, so the user can always end the session from any app.
 *
 * The Stop button broadcasts [AgentModeHudStopAction]; AgentModeController
 * listens for it, ends the agent session, and stops this service.
 */
class AgentModeHudService : Service() {

    private var windowManager: WindowManager? = null
    private var hudView: View? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (!Settings.canDrawOverlays(this)) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (hudView == null) showHud()
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        hudView?.let { view -> runCatching { windowManager?.removeView(view) } }
        hudView = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    @Suppress("ClickableViewAccessibility")
    private fun showHud() {
        val manager = getSystemService(WINDOW_SERVICE) as? WindowManager ?: return
        windowManager = manager
        val density = resources.displayMetrics.density
        fun dp(value: Int): Int = (value * density).toInt()

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            } else {
                @Suppress("DEPRECATION")
                WindowManager.LayoutParams.TYPE_PHONE
            },
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT,
        ).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            x = 0
            y = dp(18)
        }

        val root = FrameLayout(this)
        val chip = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = GradientDrawable().apply {
                setColor(0xF214161C.toInt())
                cornerRadius = dp(21).toFloat()
                setStroke(dp(1), 0x669D6BFF.toInt())
            }
            setPadding(dp(14), dp(9), dp(10), dp(9))
        }

        val statusDot = View(this).apply {
            val dotBackground = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(0xFF9D6BFF.toInt())
            }
            background = dotBackground
            layoutParams = LinearLayout.LayoutParams(dp(8), dp(8)).apply {
                marginEnd = dp(8)
            }
        }

        val title = TextView(this).apply {
            text = "Arix Agent Mode"
            setTextColor(Color.WHITE)
            textSize = 13f
            typeface = Typeface.DEFAULT_BOLD
        }
        val subtitle = TextView(this).apply {
            text = "active"
            setTextColor(0xFFB9B4D6.toInt())
            textSize = 12f
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT,
            ).apply {
                marginStart = dp(6)
            }
        }
        val stopButton = TextView(this).apply {
            text = "STOP"
            setTextColor(Color.WHITE)
            textSize = 12f
            typeface = Typeface.DEFAULT_BOLD
            val buttonBackground = GradientDrawable().apply {
                setColor(0xFF6E3FE8.toInt())
                cornerRadius = dp(14).toFloat()
            }
            background = buttonBackground
            setPadding(dp(14), dp(7), dp(14), dp(7))
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT,
            ).apply {
                marginStart = dp(12)
            }
            setOnClickListener {
                sendStopBroadcast()
            }
        }

        chip.addView(statusDot)
        chip.addView(title)
        chip.addView(subtitle)
        chip.addView(stopButton)
        root.addView(chip)
        hudView = root

        val touchSlop = ViewConfiguration.get(this).scaledTouchSlop
        var downX = 0f
        var downY = 0f
        var startX = 0
        var startY = 0
        var moved = false
        root.setOnTouchListener { _, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = event.rawX
                    downY = event.rawY
                    startX = params.x
                    startY = params.y
                    moved = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = event.rawX - downX
                    val dy = event.rawY - downY
                    if (moved || kotlin.math.abs(dx) > touchSlop || kotlin.math.abs(dy) > touchSlop) {
                        moved = true
                        params.gravity = Gravity.TOP or Gravity.START
                        params.x = (startX + dx).toInt().coerceAtLeast(0)
                        params.y = (startY + dy).toInt().coerceAtLeast(0)
                        runCatching { manager.updateViewLayout(root, params) }
                    }
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    if (!moved && event.actionMasked == MotionEvent.ACTION_UP) {
                        root.performClick()
                    }
                    true
                }
                else -> false
            }
        }

        runCatching { manager.addView(root, params) }
    }

    private fun sendStopBroadcast() {
        sendBroadcast(Intent(AgentModeHudStopAction).setPackage(packageName))
    }

    companion object {
        const val AgentModeHudStopAction = "com.arix.app.action.AGENT_MODE_HUD_STOP"

        fun start(context: Context) {
            val intent = Intent(context, AgentModeHudService::class.java)
            runCatching { context.startService(intent) }
        }

        fun stop(context: Context) {
            val intent = Intent(context, AgentModeHudService::class.java)
            runCatching { context.stopService(intent) }
        }
    }
}
