package com.arix.app.data.pi

import com.arix.app.data.AppSettings
import com.arix.app.data.LocalRuntimeId
import java.time.ZonedDateTime
import java.time.format.DateTimeFormatter
import java.util.Locale

private val DynamicPromptPlaceholderRegex = Regex("""\{\{\s*([A-Za-z0-9_-]+)\s*\}\}""")

internal fun buildPiAgentInstructions(
    settings: AppSettings,
    workspaceDirectory: String,
    runtimeId: LocalRuntimeId,
    agentModeEnabled: Boolean,
    chromeEnabled: Boolean = false,
): String = buildString {
    val configuredPrompt = expandDynamicPromptPlaceholders(settings.systemPrompt).trim()
    if (configuredPrompt.isNotBlank()) {
        append(configuredPrompt)
        append("\n\n")
    }
    append(
        "You are running inside Arix on Android. " +
            "The current local runtime is ${runtimeId.storageValue} and its session cwd is $workspaceDirectory. " +
            "User-uploaded files are placed under uploads/; use read on the provided path when image or file contents are needed. " +
            "Arix-owned configuration, Skill, runtime, Extension, Agent Mode, scheduled-task, and developer operations are exposed only through available arix_* tools. " +
            "Never modify LLM provider credentials or model configuration through self-management tools. " +
            "Only claim device actions or command results that were actually observed."
    )
    append(
        "\n\nSystem control: the system_control tool is ALWAYS available (no Agent Mode needed) and " +
            "runs instantly in the app process. ALWAYS use it first for: opening Android settings pages " +
            "(open_settings page=wifi|bluetooth|apps|display|about|...), launching apps (open_app target=name-or-package), " +
            "listing installed apps (list_apps), reading what is on screen (what_on_screen), pressing " +
            "back/home/recents or locking the screen (global_action), opening links (open_url), volume, and " +
            "device info. Never say you are unable to open settings or apps — call system_control. If " +
            "what_on_screen or global_action report the accessibility service is off, run open_settings " +
            "page=accessibility and tell the user to enable Arix there."
    )
    if (agentModeEnabled) {
        append(
            "\n\nAgent Mode is enabled for this chat. Use the agent_mode tool to operate the real Android screen " +
                "through the accessibility service: prefer read_screen, find_element, and click_element over raw " +
                "coordinates, and verify results with the automatic screenshot each action returns. " +
                "Tap and swipe coordinates use the normalized 0..1000 range. " +
                "Notifications, device settings, volume, call handling, and app launching are available through the same tool."
        )
    }
    if (runtimeId == LocalRuntimeId.Alpine) {
        append(
            "\n\nAndroid system control without root: prefer the system_control tool for launching apps, " +
                "opening settings, and reading the screen — it is faster and cannot fail on PATH. The Alpine " +
                "shell also mounts the Android /system toolbox: '/system/bin/am start -n <pkg>/<activity>' or " +
                "'/system/bin/am start -a android.intent.action.VIEW -d <url>' launches apps and links, " +
                "'/system/bin/pm list packages -3' lists apps, '/system/bin/settings get/put system|secure|global " +
                "<key> <value>' reads and writes device settings (writes respect the app's WRITE_SETTINGS " +
                "grant), and '/system/bin/dumpsys battery', 'dumpsys window' etc. report system state " +
                "where permitted. Always call system binaries by absolute path (/system/bin/am) in case PATH " +
                "is reset by a login profile. Use the shell for advanced inspection, system_control for " +
                "everything the user can see, and agent_mode for raw screen interaction."
        )
    }
    if (chromeEnabled) {
        append(
            "\n\nThe chat has enabled the browser tool (Chrome Extension tool). Prefer selectors and DOM-reading actions, and use coordinates only as a fallback."
        )
    }
}

private fun expandDynamicPromptPlaceholders(
    prompt: String,
    now: ZonedDateTime = ZonedDateTime.now(),
): String {
    if (!prompt.contains("{{")) return prompt
    val values = mapOf(
        "current_datetime" to now.format(DateTimeFormatter.ISO_OFFSET_DATE_TIME),
        "current_date" to now.toLocalDate().toString(),
        "current_time" to now.toLocalTime().withNano(0).toString(),
        "timezone" to now.zone.id,
        "unix_timestamp" to now.toEpochSecond().toString(),
    )
    return DynamicPromptPlaceholderRegex.replace(prompt) { match ->
        values[match.groupValues[1].lowercase(Locale.US)] ?: match.value
    }
}
