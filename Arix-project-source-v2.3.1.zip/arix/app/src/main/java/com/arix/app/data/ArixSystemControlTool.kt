package com.arix.app.data

import android.accessibilityservice.AccessibilityService
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.view.accessibility.AccessibilityNodeInfo
import com.arix.app.agentmode.ArixAccessibility
import org.json.JSONArray
import org.json.JSONObject

/**
 * No-root, always-available Android system control. Complements the full
 * Agent Mode (agent_mode tool) with the operations users ask for most:
 * opening apps, opening system settings pages, pressing Back/Home, reading
 * what is on screen, and basic device info. Nothing here requires Agent Mode
 * to be enabled for the chat — the tool works whenever the app is running.
 *
 * Screen reading and global key presses additionally require the Arix
 * accessibility service to be enabled in system settings; the tool returns
 * a clear, actionable message when it is not.
 */
class ArixSystemControlTool(
    private val context: Context,
) {

    fun execute(argumentsJson: String): String {
        val arguments = runCatching { JSONObject(argumentsJson) }.getOrNull()
            ?: return failure("Arguments were not valid JSON.")
        return runCatching { executeAction(arguments) }
            .getOrElse { throwable -> failure("${throwable.message ?: throwable.javaClass.simpleName}") }
    }

    private fun executeAction(arguments: JSONObject): String {
        return when (arguments.optString("action").trim().lowercase()) {
            "open_settings" -> openSettings(arguments.optString("page").trim().lowercase())
            "open_app" -> openApp(
                target = arguments.optString("target").ifBlank { arguments.optString("app") }.trim(),
            )
            "list_apps" -> listApps(
                query = arguments.optString("query").trim(),
                includeSystem = arguments.optBoolean("include_system", false),
                maxResults = minOf(arguments.optInt("max_results", 40).coerceAtLeast(1), 200),
            )
            "what_on_screen" -> readScreen(arguments.optInt("max_items", 120).coerceIn(10, 400))
            "global_action" -> globalAction(arguments.optString("key").trim().lowercase())
            "open_url" -> openUrl(arguments.optString("url").trim())
            "device_info" -> deviceInfo()
            "volume" -> volume(
                stream = arguments.optString("stream", "music").trim().lowercase(),
                action = arguments.optString("volume_action", "get").trim().lowercase(),
                direction = arguments.optString("direction", "up").trim().lowercase(),
            )
            "status" -> status()
            else -> failure(
                "Unknown action. Use open_settings, open_app, list_apps, what_on_screen, " +
                    "global_action, open_url, device_info, volume, or status."
            )
        }
    }

    /* ------------------------------------------------------------- status */

    private fun status(): String = JSONObject().apply {
        put("ok", true)
        put("action", "status")
        put("accessibility_service", ArixAccessibility.isRunning)
        put(
            "write_settings",
            Settings.System.canWrite(context),
        )
        put("android_version", Build.VERSION.RELEASE)
        put("device", "${Build.MANUFACTURER} ${Build.MODEL}")
    }.toString()

    /* ------------------------------------------------------- open settings */

    private fun settingsIntent(page: String): Intent? = when (page) {
        "", "main", "home", "settings" -> Intent(Settings.ACTION_SETTINGS)
        "wifi", "wlan" -> Intent(Settings.ACTION_WIFI_SETTINGS)
        "bluetooth", "bt" -> Intent(Settings.ACTION_BLUETOOTH_SETTINGS)
        "apps", "applications", "app", "manage_apps" -> Intent(Settings.ACTION_MANAGE_APPLICATIONS_SETTINGS)
        "app_details", "application_details" -> null // needs a package; handled by open_app
        "notifications", "notification" -> Intent("android.settings.NOTIFICATION_SETTINGS")
        "notification_history" -> Intent("android.settings.NOTIFICATION_HISTORY_SETTINGS")
        "sound", "audio", "volume" -> Intent(Settings.ACTION_SOUND_SETTINGS)
        "display", "screen", "brightness" -> Intent(Settings.ACTION_DISPLAY_SETTINGS)
        "battery" -> Intent(Settings.ACTION_BATTERY_SAVER_SETTINGS)
        "storage", "memory" -> Intent(Settings.ACTION_INTERNAL_STORAGE_SETTINGS)
        "location", "gps" -> Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS)
        "security" -> Intent(Settings.ACTION_SECURITY_SETTINGS)
        "privacy" -> Intent(Settings.ACTION_PRIVACY_SETTINGS)
        "accounts", "account", "sync" -> Intent(Settings.ACTION_SYNC_SETTINGS)
        "date", "time", "date_time", "datetime" -> Intent(Settings.ACTION_DATE_SETTINGS)
        "language", "locale", "input_language" -> Intent(Settings.ACTION_LOCALE_SETTINGS)
        "keyboard", "input", "ime", "input_method" -> Intent(Settings.ACTION_INPUT_METHOD_SETTINGS)
        "accessibility" -> Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)
        "developer", "developer_options" -> Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS)
        "about", "about_phone", "device_info" -> Intent(Settings.ACTION_DEVICE_INFO_SETTINGS)
        "airplane", "airplane_mode" -> Intent(Settings.ACTION_AIRPLANE_MODE_SETTINGS)
        "nfc" -> Intent(Settings.ACTION_NFC_SETTINGS)
        "cast", "screen_cast" -> Intent(Settings.ACTION_CAST_SETTINGS)
        "print", "printing" -> Intent(Settings.ACTION_PRINT_SETTINGS)
        "data_usage", "data" -> Intent(Settings.ACTION_DATA_USAGE_SETTINGS)
        "home", "default_apps" -> Intent(Settings.ACTION_HOME_SETTINGS)
        "search" -> Intent(Settings.ACTION_SEARCH_SETTINGS)
        "usage", "usage_access" -> Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)
        "vpn" -> Intent(Settings.ACTION_VPN_SETTINGS)
        else -> null
    }

    private fun openSettings(page: String): String {
        val intent = settingsIntent(page)
            ?: return failure(
                "Unknown settings page '$page'. Known pages: main, wifi, bluetooth, apps, notifications, " +
                    "sound, display, battery, storage, location, security, privacy, accounts, date, " +
                    "language, keyboard, accessibility, developer, about, airplane, nfc, cast, print, " +
                    "data_usage, home, vpn, usage.",
            )
        return runCatching {
            context.startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            JSONObject().apply {
                put("ok", true)
                put("action", "open_settings")
                put("page", page)
                put("detail", "Opened the ${page.ifBlank { "main" }} settings screen.")
            }.toString()
        }.getOrElse { throwable ->
            failure("Could not open settings page '$page': ${throwable.message}")
        }
    }

    /* ----------------------------------------------------------- open app */

    private fun openApp(target: String): String {
        if (target.isBlank()) {
            return failure("Provide the app name or package name, e.g. {\"action\":\"open_app\",\"target\":\"whatsapp\"}.")
        }
        val manager = context.packageManager
        val launchables = manager.getInstalledApplications(0)
            .filter { manager.getLaunchIntentForPackage(it.packageName) != null }

        val byPackage = launchables.firstOrNull {
            it.packageName.equals(target, ignoreCase = true)
        }
        val byLabel = launchables
            .map { it to manager.getApplicationLabel(it).toString() }
            .firstOrNull { (info, label) ->
                label.equals(target, ignoreCase = true) ||
                    label.contains(target, ignoreCase = true) ||
                    info.packageName.contains(target, ignoreCase = true)
            }
        val resolved = byPackage ?: byLabel?.first
            ?: return failure(
                "No launchable app matched '$target'. Use list_apps to see installed apps.",
            )
        val label = manager.getApplicationLabel(resolved).toString()
        val launch = manager.getLaunchIntentForPackage(resolved.packageName)
            ?: return failure("App '$label' has no launch intent.")
        return runCatching {
            context.startActivity(launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            JSONObject().apply {
                put("ok", true)
                put("action", "open_app")
                put("app", label)
                put("package", resolved.packageName)
                put("detail", "Launched $label.")
            }.toString()
        }.getOrElse { throwable ->
            failure("Could not launch '$label': ${throwable.message}")
        }
    }

    private fun listApps(query: String, includeSystem: Boolean, maxResults: Int): String {
        val manager = context.packageManager
        val launchables = manager.getInstalledApplications(0)
            .filter { manager.getLaunchIntentForPackage(it.packageName) != null }
            .map { info ->
                AppEntry(
                    label = manager.getApplicationLabel(info).toString(),
                    packageName = info.packageName,
                    isSystem = (info.flags and android.content.pm.ApplicationInfo.FLAG_SYSTEM) != 0,
                )
            }
            .filter { includeSystem || !it.isSystem }
            .filter { query.isBlank() || it.label.contains(query, true) || it.packageName.contains(query, true) }
            .sortedWith(compareByDescending<AppEntry> { it.label.startsWith(query, true) }.thenBy { it.label.lowercase() })
            .take(maxResults)
        return JSONObject().apply {
            put("ok", true)
            put("action", "list_apps")
            put("count", launchables.size)
            put("apps", JSONArray().apply {
                launchables.forEach { entry ->
                    put(
                        JSONObject().apply {
                            put("label", entry.label)
                            put("package", entry.packageName)
                            put("system", entry.isSystem)
                        },
                    )
                }
            })
            put("detail", "Found ${launchables.size} app(s)${if (query.isNotBlank()) " matching '$query'" else ""}.")
        }.toString()
    }

    private data class AppEntry(val label: String, val packageName: String, val isSystem: Boolean)

    /* ------------------------------------------------------ what on screen */

    private fun readScreen(maxItems: Int): String {
        val service = ArixAccessibility.service()
        if (service == null) {
            return JSONObject().apply {
                put("ok", false)
                put("action", "what_on_screen")
                put(
                    "errmsg",
                    "The Arix accessibility service is not enabled, so the screen cannot be read. " +
                        "Ask the user to enable it: open Settings > Accessibility > Arix and turn the " +
                        "service on, then retry. (open_settings with page=accessibility opens that screen.)",
                )
            }.toString()
        }
        val root = runCatching { service.rootWindowNode() }.getOrNull()
        if (root == null) {
            return failure("No active window content is available right now.")
        }
        val items = JSONArray()
        val seen = HashSet<String>()
        var count = 0
        val queue = ArrayDeque<AccessibilityNodeInfo>()
        queue.add(root)
        while (queue.isNotEmpty() && count < maxItems) {
            val current = queue.removeFirst()
            val text = current.text?.toString()?.trim().orEmpty()
            val description = current.contentDescription?.toString()?.trim().orEmpty()
            val viewId = current.viewIdResourceName.orEmpty()
            val candidate = listOf(text, description).firstOrNull { it.isNotBlank() }
            if (candidate != null && seen.add(candidate)) {
                items.put(
                    JSONObject().apply {
                        put("text", candidate.take(220))
                        if (viewId.isNotBlank()) put("view_id", viewId)
                        put("clickable", current.isClickable)
                        put("scrollable", current.isScrollable)
                        val bounds = android.graphics.Rect()
                        current.getBoundsInScreen(bounds)
                        put("bounds", JSONObject().apply {
                            put("left", bounds.left)
                            put("top", bounds.top)
                            put("right", bounds.right)
                            put("bottom", bounds.bottom)
                        })
                    },
                )
                count++
            }
            for (index in 0 until current.childCount) {
                current.getChild(index)?.let(queue::add)
            }
            if (current !== root) {
                runCatching { current.recycle() }
            }
        }
        val packageName = root.packageName?.toString().orEmpty()
        val activity = runCatching {
            val window = service.windows.firstOrNull { it.isActive && it.root != null }
            window?.root?.packageName?.toString()
        }.getOrNull().orEmpty()
        return JSONObject().apply {
            put("ok", true)
            put("action", "what_on_screen")
            put("package", packageName)
            if (activity.isNotBlank()) put("active_window", activity)
            put("items", items)
            put("count", count)
            put("detail", "Read $count on-screen element(s) from $packageName.")
        }.toString()
    }

    /* ------------------------------------------------------- global keys */

    private fun globalAction(key: String): String {
        val service = ArixAccessibility.service()
            ?: return JSONObject().apply {
                put("ok", false)
                put(
                    "errmsg",
                    "The Arix accessibility service is not enabled, so device keys cannot be pressed. " +
                        "Ask the user to enable it: Settings > Accessibility > Arix. " +
                        "(open_settings with page=accessibility opens that screen.)",
                )
            }.toString()
        val actionId = when (key) {
            "back" -> AccessibilityService.GLOBAL_ACTION_BACK
            "home" -> AccessibilityService.GLOBAL_ACTION_HOME
            "recents", "overview", "multitasking" -> AccessibilityService.GLOBAL_ACTION_RECENTS
            "notifications", "notification_shade" -> AccessibilityService.GLOBAL_ACTION_NOTIFICATIONS
            "quick_settings" -> AccessibilityService.GLOBAL_ACTION_QUICK_SETTINGS
            "power_dialog" -> AccessibilityService.GLOBAL_ACTION_POWER_DIALOG
            "lock_screen", "lock" -> AccessibilityService.GLOBAL_ACTION_LOCK_SCREEN
            "take_screenshot", "screenshot" -> AccessibilityService.GLOBAL_ACTION_TAKE_SCREENSHOT
            else -> -1
        }
        if (actionId < 0) {
            return failure("Unknown key '$key'. Use back, home, recents, notifications, quick_settings, power_dialog, lock_screen, take_screenshot.")
        }
        val performed = runCatching { service.globalAction(actionId) }.getOrDefault(false)
        return if (performed) {
            JSONObject().apply {
                put("ok", true)
                put("action", "global_action")
                put("key", key)
                put("detail", "Performed $key.")
            }.toString()
        } else {
            failure("The system rejected the '$key' action.")
        }
    }

    /* --------------------------------------------------------- open url */

    private fun openUrl(url: String): String {
        if (!url.startsWith("http://") && !url.startsWith("https://")) {
            return failure("URL must start with http:// or https://")
        }
        return runCatching {
            context.startActivity(
                Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            )
            JSONObject().apply {
                put("ok", true)
                put("action", "open_url")
                put("url", url)
            }.toString()
        }.getOrElse { throwable -> failure("Could not open URL: ${throwable.message}") }
    }

    /* -------------------------------------------------------- device info */

    private fun deviceInfo(): String {
        val audio = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val battery = runCatching {
            val intent = context.registerReceiver(
                null,
                android.content.IntentFilter(Intent.ACTION_BATTERY_CHANGED),
            )
            val level = intent?.getIntExtra(android.os.BatteryManager.EXTRA_LEVEL, -1) ?: -1
            val scale = intent?.getIntExtra(android.os.BatteryManager.EXTRA_SCALE, -1) ?: -1
            if (level >= 0 && scale > 0) level * 100 / scale else null
        }.getOrNull()
        val metrics = context.resources.displayMetrics
        return JSONObject().apply {
            put("ok", true)
            put("action", "device_info")
            put("model", Build.MODEL)
            put("manufacturer", Build.MANUFACTURER)
            put("android_version", Build.VERSION.RELEASE)
            put("sdk", Build.VERSION.SDK_INT)
            battery?.let { put("battery_percent", it) }
            put("screen", JSONObject().apply {
                put("width_px", metrics.widthPixels)
                put("height_px", metrics.heightPixels)
                put("density", metrics.densityDpi / 160.0)
            })
            put("volume", JSONObject().apply {
                put("music", audio.getStreamVolume(AudioManager.STREAM_MUSIC))
                put("ring", audio.getStreamVolume(AudioManager.STREAM_RING))
                put("alarm", audio.getStreamVolume(AudioManager.STREAM_ALARM))
            })
        }.toString()
    }

    /* ------------------------------------------------------------ volume */

    private fun volume(stream: String, action: String, direction: String): String {
        val audio = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val streamId = when (stream) {
            "music", "media" -> AudioManager.STREAM_MUSIC
            "ring", "ringer" -> AudioManager.STREAM_RING
            "alarm" -> AudioManager.STREAM_ALARM
            "call" -> AudioManager.STREAM_VOICE_CALL
            "system" -> AudioManager.STREAM_SYSTEM
            "notification", "notifications" -> AudioManager.STREAM_NOTIFICATION
            else -> AudioManager.STREAM_MUSIC
        }
        if (action == "get") {
            return JSONObject().apply {
                put("ok", true)
                put("action", "volume")
                put("stream", stream)
                put("level", audio.getStreamVolume(streamId))
                put("max", audio.getStreamMaxVolume(streamId))
            }.toString()
        }
        val directionFlag = if (direction == "down") AudioManager.ADJUST_LOWER else AudioManager.ADJUST_RAISE
        if (action == "mute") {
            audio.adjustStreamVolume(streamId, AudioManager.ADJUST_MUTE, 0)
        } else if (action == "unmute") {
            audio.adjustStreamVolume(streamId, AudioManager.ADJUST_UNMUTE, 0)
        } else {
            audio.adjustStreamVolume(streamId, directionFlag, 0)
        }
        return JSONObject().apply {
            put("ok", true)
            put("action", "volume")
            put("stream", stream)
            put("level", audio.getStreamVolume(streamId))
            put("max", audio.getStreamMaxVolume(streamId))
        }.toString()
    }

    private fun failure(message: String): String = JSONObject()
        .put("ok", false)
        .put("errmsg", message)
        .toString()

    companion object {
        val toolDefinition: JSONObject = JSONObject().apply {
            put("name", "system_control")
            put(
                "description",
                "Instant no-root Android system control. ALWAYS prefer this tool for: opening system " +
                    "settings (wifi, bluetooth, apps, display, about, developer, ...), launching apps by " +
                    "name or package, listing installed apps, reading what is currently on screen, " +
                    "pressing Back/Home/Recents/locking the screen, opening URLs, volume control, and " +
                    "device info. It works without Agent Mode; only what_on_screen and global_action " +
                    "need the Arix accessibility service to be enabled (they explain how if not).",
            )
            put(
                "parameters",
                JSONObject().apply {
                    put("type", "object")
                    put(
                        "properties",
                        JSONObject().apply {
                            put(
                                "action",
                                JSONObject().put("type", "string")
                                    .put(
                                        "description",
                                        "One of: open_settings, open_app, list_apps, what_on_screen, " +
                                            "global_action, open_url, device_info, volume, status.",
                                    ),
                            )
                            put(
                                "page",
                                JSONObject().put("type", "string")
                                    .put(
                                        "description",
                                        "For open_settings: main, wifi, bluetooth, apps, notifications, sound, display, " +
                                            "battery, storage, location, security, privacy, accounts, date, language, " +
                                            "keyboard, accessibility, developer, about, airplane, nfc, cast, print, " +
                                            "data_usage, home, vpn, usage.",
                                    ),
                            )
                            put("target", JSONObject().put("type", "string").put("description", "For open_app: app label or package name."))
                            put("query", JSONObject().put("type", "string").put("description", "For list_apps: optional filter."))
                            put("include_system", JSONObject().put("type", "boolean").put("description", "For list_apps: include system apps."))
                            put("key", JSONObject().put("type", "string").put("description", "For global_action: back, home, recents, notifications, quick_settings, power_dialog, lock_screen, take_screenshot."))
                            put("url", JSONObject().put("type", "string").put("description", "For open_url: http/https URL."))
                            put("stream", JSONObject().put("type", "string").put("description", "For volume: music, ring, alarm, call, system, notification."))
                            put("volume_action", JSONObject().put("type", "string").put("description", "For volume: get (default), set, mute, unmute."))
                            put("direction", JSONObject().put("type", "string").put("description", "For volume set: up or down."))
                        },
                    )
                    put("required", JSONArray().put("action"))
                    put("additionalProperties", false)
                },
            )
            put("execution_mode", "sequential")
        }
    }
}
