package com.arix.app.data

import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ArixToolExecutorTest {
    @Test
    fun hostToolDefinitionsDoNotDuplicatePiNativeTools() {
        val definitions = ArixToolExecutor.hostToolDefinitions()
        // system_control is always available; nothing else leaks without
        // a self-management tool or Agent Mode.
        assertEquals(1, definitions.length())
        assertEquals("system_control", definitions.getJSONObject(0).getString("name"))
    }

    @Test
    fun sanitizeAgentModeOutputRemovesScreenshotBytes() {
        val sanitized = ArixToolExecutor.sanitizeToolOutputForConversation(
            toolName = "agent_mode",
            output = JSONObject().apply {
                put("ok", true)
                put("screenshot_base64", "abc123")
                put("screenshot_mime_type", "image/png")
            }.toString(),
        )

        val json = JSONObject(sanitized)
        assertFalse(json.has("screenshot_base64"))
        assertTrue(json.getBoolean("screenshot_injected_into_next_model_request"))
        assertEquals("image/png", json.getString("screenshot_mime_type"))
    }

    @Test
    fun dynamicHostToolDefinitionsExcludeMcpAndChromeButIncludeAgentMode() {
        val definitions = ArixToolExecutor.hostToolDefinitions(
            selfManagementTool = null,
            agentModeEnabled = true,
        )
        val names = (0 until definitions.length())
            .map { definitions.getJSONObject(it).getString("name") }

        assertFalse("mcp_list_tools" in names)
        assertFalse("mcp__docs__search" in names)
        assertTrue("agent_mode" in names)
        assertTrue("system_control" in names)
        assertFalse("chrome" in names)
    }

    @Test
    fun inferToolOutputOkHonorsArixJsonFlags() {
        assertTrue(ArixToolExecutor.inferToolOutputOk("""{"ok":true}"""))
        assertFalse(ArixToolExecutor.inferToolOutputOk("""{"ok":false}"""))
        assertFalse(ArixToolExecutor.inferToolOutputOk("""{"err":true}"""))
        assertTrue(ArixToolExecutor.inferToolOutputOk("plain text"))
    }

}
