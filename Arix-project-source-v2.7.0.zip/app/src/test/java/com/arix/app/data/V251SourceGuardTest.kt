package com.arix.app.data

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

/**
 * v2.5.1 source guards: --no-sandbox infobar suppression, single-window
 * guarantee, and the double-browser UI fix.
 */
class V251SourceGuardTest {
    private fun moduleDir(): File {
        var dir: File? = File(System.getProperty("user.dir"))
        repeat(6) {
            val direct = File(dir, "src/main/java/com/arix/app")
            if (direct.isDirectory) return dir!!
            dir = dir?.parentFile
        }
        throw IllegalStateException("app module directory not found")
    }

    private fun appSource(relative: String): String =
        File(moduleDir(), "src/main/java/com/arix/app/$relative").readText()

    @Test
    fun chromiumLaunchSuppressesNoSandboxInfobar() {
        // --test-type makes Chromium skip ALL startup infobars, including the
        // "--no-sandbox ... stability and security will suffer" warning
        // (Chromium: infobar_utils.cc returns early when kTestType is present).
        // --no-sandbox itself must stay: the browser runs as root under proot.
        val src = appSource("data/AlpineChromeController.kt")
        assertTrue(src.contains("--no-sandbox"))
        assertTrue(src.contains("--test-type"))
        assertTrue(src.contains("--disable-session-crash-bubble"))
    }

    @Test
    fun exactlyOneBrowserWindowAfterConnect() {
        // The extra-page-target sweep guarantees a single Chromium window
        // even after a crash-restore or a singleton race.
        val src = appSource("data/AlpineChromeController.kt")
        assertTrue(src.contains("closeExtraPageTargets"))
        assertTrue(src.contains("/json/close/"))
    }

    @Test
    fun liveChromePanelIsToggleGatedNotAutoShown() {
        // v2.5.1 double-browser fix: the live preview panel renders only with
        // the Chrome toggle on — it must not auto-show merely because the
        // agent's browser is running (chromeDisplayState.isActive).
        val src = appSource("ui/ConversationUi.kt")
        assertTrue(src.contains("chromePreviewVisible =\n        chromeSelected &&"))
        assertFalse(src.contains("(chromeSelected || chromeDisplayState.isActive)"))
    }

    @Test
    fun agentModePanelRequiresRealAgentModeInvocations() {
        // The agent-mode preview must not leak the Chrome desktop through the
        // latestPreviewPath fallback (that path was chrome data).
        val src = appSource("ui/ConversationUi.kt")
        assertTrue(
            src.contains("agentModeSelected && agentModeDisplayState.isActive &&") &&
                src.contains("blockAgentModeInvocations.isNotEmpty() ||\n                pendingAgentModeInvocations.isNotEmpty())"),
        )
        assertFalse(
            src.contains("agentModeDisplayState.latestPreviewPath.isNotBlank())\n    val chromePreviewVisible"),
        )
    }

    @Test
    fun browserInvocationsStayVisibleWhenPanelIsHidden() {
        // With the toggle off, browser tool rows must stay in the pending
        // tool list instead of disappearing entirely.
        val src = appSource("ui/ConversationUi.kt")
        assertTrue(src.contains("(chromePreviewVisible && it.isChromeDisplayInvocation())"))
    }

    @Test
    fun versionMatchesGradleProperties() {
        // v2.7.0: keep the version guard in sync with gradle.properties instead
        // of hard-coding the version in the test source.
        val gradleProps = File(moduleDir().parentFile, "gradle.properties").readText()
        val versionMatch = Regex("arix\\.versionName=(\\d+)\\.(\\d+)\\.(\\d+)").find(gradleProps)
        assertTrue(versionMatch != null)
        val major = versionMatch!!.groupValues[1].toInt()
        val minor = versionMatch.groupValues[2].toInt()
        assertTrue(major == 2 && minor >= 7)
        val appGradle = File(moduleDir(), "build.gradle.kts").readText()
        assertTrue(appGradle.contains("versionCode = 41"))
    }
}
