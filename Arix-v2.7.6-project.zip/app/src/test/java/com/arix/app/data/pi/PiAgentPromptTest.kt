package com.arix.app.data.pi

import com.arix.app.data.AppSettings
import com.arix.app.data.LocalRuntimeId
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * v2.7.6 regression tests: the agent brain prompt.
 *
 *  - NO ADB instructions may ever appear in the prompt (the ADB device-
 *    control path was removed; the model must never be told ADB exists),
 *  - the core capability/verification policy must be present,
 *  - the device-control section must REFLECT the real capability state
 *    (available vs. not available),
 *  - the browser must be scoped to web tasks only (no universal fallback).
 */
class PiAgentPromptTest {

    private fun build(
        systemControlAvailable: Boolean,
        settings: AppSettings = AppSettings(systemPrompt = ""),
    ): String = buildPiAgentInstructions(
        settings = settings,
        workspaceDirectory = "/workspace",
        runtimeId = LocalRuntimeId.Alpine,
        agentModeEnabled = true,
        chromeEnabled = false,
        systemControlAvailable = systemControlAvailable,
    )

    @Test
    fun `prompt never mentions adb`() {
        for (available in listOf(true, false)) {
            val prompt = build(available)
            val lowered = prompt.lowercase()
            assertFalse("prompt must not mention adb", lowered.contains("adb"))
            assertFalse(prompt.contains("arix-adb"))
            assertFalse(prompt.contains("uiautomator"))
            assertFalse(prompt.contains("adb shell"))
            assertFalse(prompt.contains("wireless debugging"))
        }
    }

    @Test
    fun `prompt contains the core capability policy`() {
        val prompt = build(true)
        assertTrue(prompt.contains("local-first Android agent"))
        assertTrue(prompt.contains("Never invent tools"))
        assertTrue(prompt.contains("Never substitute an unrelated tool when a tool fails"))
        assertTrue(prompt.contains("Never claim an action succeeded unless success is actually observed"))
        assertTrue(prompt.contains("verified"))
    }

    @Test
    fun `prompt reflects system control availability`() {
        val available = build(systemControlAvailable = true)
        assertTrue(available.contains("AVAILABLE right now"))
        assertTrue(available.contains("read_screen"))
        assertTrue(available.contains("ui_action"))

        val unavailable = build(systemControlAvailable = false)
        assertTrue(unavailable.contains("NOT available right now"))
        // The workflow section must not be taught when the capability is off.
        assertFalse(unavailable.contains("AVAILABLE right now"))
    }

    @Test
    fun `unavailable prompt guides to accessibility settings without inventing mechanisms`() {
        val prompt = build(systemControlAvailable = false)
        assertTrue(prompt.contains("Android Settings"))
        assertTrue(prompt.contains("Accessibility"))
        assertTrue(prompt.contains("device_status"))
        // Must not suggest bash as a control mechanism.
        assertFalse(prompt.contains("bash with `adb"))
        assertFalse(prompt.contains("input tap"))
    }

    @Test
    fun `upi policy forbids screen automation of payments`() {
        for (available in listOf(true, false)) {
            val prompt = build(available)
            assertTrue(prompt.contains("upi_pay"))
            assertTrue(prompt.contains("NEVER automate payment apps"))
        }
    }

    @Test
    fun `browser is scoped to web tasks only`() {
        val prompt = build(true)
        assertTrue(prompt.contains("ONLY for web tasks"))
        assertTrue(prompt.contains("NOT a fallback for Android device control"))
        // The v2.7.5 "always available" claim must be gone.
        assertFalse(prompt.contains("always available"))
    }

    @Test
    fun `custom system prompt is still honored`() {
        val prompt = build(true, AppSettings(systemPrompt = "CUSTOM_MARKER_123"))
        assertTrue(prompt.contains("CUSTOM_MARKER_123"))
    }
}
