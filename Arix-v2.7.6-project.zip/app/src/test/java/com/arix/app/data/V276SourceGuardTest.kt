package com.arix.app.data

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

/**
 * v2.7.6 source guards: the ADB → Accessibility migration contract.
 *
 * These tests read the ACTUAL source tree (like the earlier V245/V246/V251
 * guards) and fail when any regressed code path reappears:
 *  - NO active ADB device-control path anywhere in executable sources,
 *  - the Accessibility service is registered via the official mechanism,
 *  - UPI never uses Accessibility,
 *  - the agent prompt never teaches ADB,
 *  - the removed dangerous permissions stay removed,
 *  - the agent fallback policy stays NO_FALLBACK.
 */
class V276SourceGuardTest {
    private fun moduleDir(): File {
        var dir: File? = File(System.getProperty("user.dir"))
        repeat(6) {
            val direct = File(dir, "src/main/java/com/arix/app")
            if (direct.isDirectory) return dir!!
            dir = dir?.parentFile
        }
        throw IllegalStateException("app module directory not found")
    }

    private fun appSource(relative: String): String =
        File(moduleDir(), "src/main/java/com/arix/app/$relative").readText()

    private fun manifest(): String = File(moduleDir(), "src/main/AndroidManifest.xml").readText()

    private fun projectRoot(): File = moduleDir().parentFile

    private fun bridgeSource(): String =
        File(projectRoot(), "pi-bridge/src/bridge.ts").readText()

    private fun subagents(relative: String): String =
        File(projectRoot(), "extensions/pi-subagents/src/$relative").readText()

    // ------------------------------------------------------------------
    // ADB removal
    // ------------------------------------------------------------------

    @Test
    fun `agent prompt contains no adb instructions`() {
        // Check the executable STRING LITERALS (not doc comments, which may
        // legitimately document the removal history): the buildString block
        // must not teach any adb mechanism.
        val prompt = appSource("data/pi/PiAgentPrompt.kt")
        val literals = prompt.substringAfter("): String = buildString {")
        assertFalse(literals.lowercase().contains("adb"))
        assertFalse(literals.contains("uiautomator"))
        assertFalse(literals.contains("wireless debugging"))
    }

    @Test
    fun `adb agent mode controller is gone`() {
        assertFalse(File(moduleDir(), "src/main/java/com/arix/app/data/ArixAgentModeController.kt").exists())
    }

    @Test
    fun `alpine runtime has no adb helper or adb preset`() {
        val runtime = appSource("runtime/AlpineRuntime.kt")
        // Executable ADB code must be gone (migration-note comments naming the
        // removed identifiers are allowed and honest).
        assertFalse(runtime.contains("private val AdbHelperScript"))
        assertFalse(runtime.contains("private fun ensureAdbHelperScript()"))
        assertFalse(runtime.contains("put(\"ARIX_DEVICE_IP\""))
        assertFalse(runtime.contains("deviceLanIpAddress()?.let"))
        assertFalse(runtime.contains("\"adb\" to listOf(\"android-tools\")"))
        assertFalse(runtime.contains("adb --version"))
        assertFalse(runtime.contains("command -v adb"))
    }

    @Test
    fun `tool executor never teaches adb`() {
        val executor = appSource("data/ArixToolExecutor.kt")
        assertFalse(executor.contains("adb shell"))
        assertFalse(executor.contains("arix-adb"))
        assertFalse(executor.contains("uiautomator dump"))
    }

    @Test
    fun `adb preset strings are removed`() {
        val strings = File(projectRoot(), "shared/src/commonMain/composeResources/values/strings.xml").readText()
        assertFalse(strings.contains("settings_adb_tools"))
    }

    // ------------------------------------------------------------------
    // Accessibility implementation
    // ------------------------------------------------------------------

    @Test
    fun `accessibility service exists with official registration`() {
        val service = appSource("accessibility/ArixAccessibilityService.kt")
        assertTrue(service.contains(": AccessibilityService()"))

        val manifestText = manifest()
        assertTrue(manifestText.contains("android.permission.BIND_ACCESSIBILITY_SERVICE"))
        assertTrue(manifestText.contains(".accessibility.ArixAccessibilityService"))
        assertTrue(manifestText.contains("@xml/arix_accessibility_service_config"))
        assertTrue(manifestText.contains("android.accessibilityservice.AccessibilityService"))
    }

    @Test
    fun `accessibility config declares required capabilities`() {
        val config = File(moduleDir(), "src/main/res/xml/arix_accessibility_service_config.xml").readText()
        assertTrue(config.contains("android:canRetrieveWindowContent=\"true\""))
        assertTrue(config.contains("android:canPerformGestures=\"true\""))
        assertTrue(config.contains("flagRetrieveInteractiveWindows"))
    }

    @Test
    fun `device controller is the only system control abstraction`() {
        val controller = appSource("data/ArixDeviceController.kt")
        assertTrue(controller.contains("class ArixDeviceController"))
        // No shell-outs in the controller.
        val lowered = controller.lowercase()
        assertFalse(lowered.contains("runtime.exec"))
        assertFalse(lowered.contains("processbuilder"))
        assertFalse(lowered.contains("\"adb"))
    }

    @Test
    fun `state manager tracks the five states`() {
        val manager = appSource("accessibility/ArixAccessibilityStateManager.kt")
        for (state in listOf("DISABLED", "CONNECTING", "CONNECTED", "DISCONNECTED", "UNAVAILABLE")) {
            assertTrue(manager.contains(state))
        }
        // Opening settings must never imply enabled.
        assertTrue(manager.contains("currentState"))
        assertTrue(manager.contains("isServiceEnabledInSettings"))
    }

    // ------------------------------------------------------------------
    // UPI isolation
    // ------------------------------------------------------------------

    @Test
    fun `upi controller never touches accessibility or adb`() {
        // Check real API usage (comments may mention "no accessibility" as a
        // guarantee — that is documentation, not usage).
        val upi = appSource("data/ArixUpiPaymentController.kt")
        assertFalse(upi.contains("AccessibilityNodeInfo"))
        assertFalse(upi.contains("AccessibilityService"))
        assertFalse(upi.contains("dispatchGesture"))
        assertFalse(upi.contains("performGlobalAction"))
        assertFalse(upi.contains("uiAction"))
        assertFalse(upi.contains("Runtime.getRuntime"))
        assertFalse(upi.contains("adb shell"))
        assertFalse(upi.contains("arix-adb"))
        assertTrue(upi.contains("upi://pay"))
    }

    // ------------------------------------------------------------------
    // Permission audit
    // ------------------------------------------------------------------

    @Test
    fun `removed dangerous permissions stay removed`() {
        val manifestText = manifest()
        assertFalse(manifestText.contains("android.permission.WRITE_SETTINGS"))
        assertFalse(manifestText.contains("android.permission.READ_PHONE_STATE"))
        assertFalse(manifestText.contains("android.permission.ANSWER_PHONE_CALLS"))
    }

    @Test
    fun `required permissions stay present`() {
        val manifestText = manifest()
        assertTrue(manifestText.contains("android.permission.INTERNET"))
        assertTrue(manifestText.contains("android.permission.SYSTEM_ALERT_WINDOW"))
        assertTrue(manifestText.contains("android.permission.SCHEDULE_EXACT_ALARM"))
    }

    // ------------------------------------------------------------------
    // Tool registry
    // ------------------------------------------------------------------

    @Test
    fun `bridge allowlist has no agent_mode or adb tool`() {
        val bridge = bridgeSource()
        val allowlistStart = bridge.indexOf("const ARIX_HOST_TOOL_NAMES = new Set([")
        val allowlistEnd = bridge.indexOf("]);", allowlistStart)
        val allowlist = bridge.substring(allowlistStart, allowlistEnd)
        assertFalse(allowlist.contains("\"agent_mode\""))
        assertFalse(allowlist.contains("\"arix_agent_mode_manage\""))
        assertFalse(allowlist.contains("\"adb"))
        // The new capability-gated tools must be allowlisted.
        assertTrue(allowlist.contains("\"read_screen\""))
        assertTrue(allowlist.contains("\"ui_action\""))
        assertTrue(allowlist.contains("\"device_status\""))
        assertTrue(allowlist.contains("\"weather\""))
        assertTrue(allowlist.contains("\"upi_pay\""))
        assertTrue(allowlist.contains("\"arix_mcp_call\""))
    }

    // ------------------------------------------------------------------
    // NO_FALLBACK agent dispatch
    // ------------------------------------------------------------------

    @Test
    fun `agent types default to no fallback`() {
        val agentTypes = subagents("agent-types.ts")
        assertTrue(agentTypes.contains("let fallbackSubagent: string | undefined = NO_FALLBACK;"))
        // The implicit general-purpose substitution must be gone.
        val resolveFn = agentTypes.substring(
            agentTypes.indexOf("export function resolveSpawnTypeIn"),
            agentTypes.indexOf("/** Resolve a caller-supplied agent type against the process-wide registry."),
        )
        assertFalse(resolveFn.contains("type: \"general-purpose\", fellBackFrom"))
    }

    @Test
    fun `get config returns undefined for unknown types`() {
        val agentTypes = subagents("agent-types.ts")
        assertTrue(agentTypes.contains("export function getConfig(type: string): AgentConfig | undefined"))
        // The old general-purpose fallback block must be gone.
        val getConfigFn = agentTypes.substring(
            agentTypes.indexOf("export function getConfig"),
        )
        assertFalse(getConfigFn.contains("const gp = agents.get(\"general-purpose\")"))
    }

    @Test
    fun `run agent fails closed for unknown types`() {
        val runner = subagents("agent-runner.ts")
        assertTrue(runner.contains("AGENT_NOT_FOUND"))
        assertFalse(runner.contains("No fallback config available"))
    }
}
