package com.arix.app.data

import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * v2.7.6: updated host-tool surface tests. The ADB-era `agent_mode` tool is
 * gone; the authoritative registry exposes the capability-gated device
 * control tools instead (read_screen / ui_action only while Accessibility is
 * CONNECTED; deterministic open_* always).
 */
class ArixToolExecutorTest {
    @Test
    fun hostToolDefinitionsExposeNativeAndStatusTools() {
        val definitions = ArixToolExecutor.hostToolDefinitions()
        val names = buildSet {
            for (index in 0 until definitions.length()) add(definitions.getJSONObject(index).optString("name"))
        }
        assertEquals("device_status", definitions.getJSONObject(0).optString("name"))
        assertTrue(names.contains("open_app"))
        assertTrue(names.contains("open_settings"))
        assertTrue(names.contains("open_url"))
        assertTrue(names.contains("weather"))
        assertTrue(names.contains("upi_pay"))
    }

    @Test
    fun hostToolDefinitionsExposeFlattenedShape() {
        val definitions = ArixToolExecutor.hostToolDefinitions()
        val definition = definitions.getJSONObject(0)
        assertEquals("device_status", definition.optString("name"))
        assertTrue(definition.has("parameters"))
        assertTrue(definition.optString("description").isNotBlank())
    }

    @Test
    fun hostToolNamesCoverTheRegistryExactly() {
        // v2.7.6 tools.
        assertTrue(ArixToolExecutor.supports("device_status"))
        assertTrue(ArixToolExecutor.supports("read_screen"))
        assertTrue(ArixToolExecutor.supports("ui_action"))
        assertTrue(ArixToolExecutor.supports("open_app"))
        assertTrue(ArixToolExecutor.supports("open_settings"))
        assertTrue(ArixToolExecutor.supports("open_url"))
        assertTrue(ArixToolExecutor.supports("weather"))
        assertTrue(ArixToolExecutor.supports("upi_pay"))
        assertTrue(ArixToolExecutor.supports("arix_config_get"))
        assertTrue(ArixToolExecutor.supports("arix_mcp_call"))
        // Removed / never-existing tools.
        assertFalse(ArixToolExecutor.supports("agent_mode"))
        assertFalse(ArixToolExecutor.supports("system_control"))
        assertFalse(ArixToolExecutor.supports("android_shell"))
        assertFalse(ArixToolExecutor.supports("chrome"))
        assertFalse(ArixToolExecutor.supports("adb"))
        assertFalse(ArixToolExecutor.supports("arix_adb"))
        assertFalse(ArixToolExecutor.supports("device"))
    }

    @Test
    fun inferToolOutputOkHonorsArixJsonFlags() {
        assertTrue(ArixToolExecutor.inferToolOutputOk("""{"ok":true}"""))
        assertFalse(ArixToolExecutor.inferToolOutputOk("""{"ok":false}"""))
        assertFalse(ArixToolExecutor.inferToolOutputOk("""{"err":true}"""))
        assertTrue(ArixToolExecutor.inferToolOutputOk("plain text"))
    }

    @Test
    fun executionResultFlagsErrorOutput() {
        val ok = ArixToolExecutionResult("device_status", "{}", """{"ok":true}""")
        val failed = ArixToolExecutionResult("device_status", "{}", """{"ok":false,"error_code":"X"}""")
        assertFalse(ok.isError)
        assertTrue(failed.isError)
    }

    @Test
    fun upiPayDefinitionForbidsScreenAutomation() {
        // §29: UPI must never be automated through accessibility/ADB.
        val definitions = ArixToolExecutor.hostToolDefinitions()
        val upi = (0 until definitions.length())
            .map { definitions.getJSONObject(it) }
            .first { it.optString("name") == "upi_pay" }
        val description = upi.optString("description")
        assertTrue(description.contains("NEVER attempt to automate the UPI app"))
    }
}
