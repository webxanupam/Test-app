package com.arix.app.accessibility

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * v2.7.6 regression tests: the semantic-first target matcher behind
 * ArixDeviceController. Covers the required failure semantics:
 *  - TARGET_NOT_FOUND for absent targets,
 *  - TARGET_AMBIGUOUS for non-unique matches (never a guess),
 *  - TARGET_STALE for indices from an outdated screen read,
 *  - uniqueness enforcement for text / description / resource-id,
 *  - coordinate hit-testing as the last resort.
 */
class ArixNodeMatcherTest {

    private fun node(
        index: Int,
        text: String = "",
        desc: String = "",
        resId: String? = null,
        className: String = "TextView",
        bounds: ArixBounds? = ArixBounds(0, 0, 100, 100),
        clickable: Boolean = false,
        scrollable: Boolean = false,
        visible: Boolean = true,
        depth: Int = 0,
        parent: Int = -1,
    ) = ArixNodeSnapshot(
        index = index,
        depth = depth,
        parentIndex = parent,
        text = text,
        contentDescription = desc,
        viewIdResourceName = resId,
        className = className,
        packageName = "com.example",
        bounds = bounds,
        isClickable = clickable,
        isLongClickable = false,
        isScrollable = scrollable,
        isEditable = false,
        isChecked = false,
        isCheckable = false,
        isEnabled = true,
        isVisibleToUser = visible,
        isFocusable = true,
        isFocused = false,
        isPassword = false,
    )

    @Test
    fun `empty target spec is rejected`() {
        val resolution = ArixNodeMatcher.resolve(listOf(node(0)), ArixTargetSpec())
        assertTrue(resolution is ArixTargetResolution.NotFound)
        assertEquals(ArixTargetResolution.TARGET_NOT_FOUND, (resolution as ArixTargetResolution.NotFound).reason)
    }

    @Test
    fun `exact text match resolves uniquely`() {
        val nodes = listOf(
            node(0, text = "Wi-Fi"),
            node(1, text = "Bluetooth"),
        )
        val resolution = ArixNodeMatcher.resolve(nodes, ArixTargetSpec(text = "Wi-Fi"))
        assertTrue(resolution is ArixTargetResolution.Resolved)
        assertEquals(0, (resolution as ArixTargetResolution.Resolved).node.index)
    }

    @Test
    fun `text match is case-insensitive`() {
        val nodes = listOf(node(0, text = "Wi-Fi Settings"))
        val resolution = ArixNodeMatcher.resolve(nodes, ArixTargetSpec(text = "wi-fi settings"))
        assertTrue(resolution is ArixTargetResolution.Resolved)
    }

    @Test
    fun `ambiguous text match is rejected not guessed`() {
        val nodes = listOf(
            node(0, text = "OK"),
            node(1, text = "OK"),
        )
        val resolution = ArixNodeMatcher.resolve(nodes, ArixTargetSpec(text = "OK"))
        assertTrue(resolution is ArixTargetResolution.Ambiguous)
        assertEquals(2, (resolution as ArixTargetResolution.Ambiguous).matches.size)
    }

    @Test
    fun `missing text is target not found`() {
        val nodes = listOf(node(0, text = "Wi-Fi"))
        val resolution = ArixNodeMatcher.resolve(nodes, ArixTargetSpec(text = "Cancel"))
        assertTrue(resolution is ArixTargetResolution.NotFound)
        assertEquals(ArixTargetResolution.TARGET_NOT_FOUND, (resolution as ArixTargetResolution.NotFound).reason)
    }

    @Test
    fun `duplicate text falls back to unique contains match`() {
        val nodes = listOf(
            node(0, text = "Settings"),
            node(1, text = "Wi-Fi & internet Settings"),
        )
        val resolution = ArixNodeMatcher.resolve(nodes, ArixTargetSpec(text = "Wi-Fi"))
        assertTrue(resolution is ArixTargetResolution.Resolved)
        assertEquals(1, (resolution as ArixTargetResolution.Resolved).node.index)
    }

    @Test
    fun `index resolves and out-of-range index is stale`() {
        val nodes = listOf(node(0, text = "A"), node(1, text = "B"))
        val ok = ArixNodeMatcher.resolve(nodes, ArixTargetSpec(index = 1))
        assertTrue(ok is ArixTargetResolution.Resolved)
        assertEquals(1, (ok as ArixTargetResolution.Resolved).node.index)

        val stale = ArixNodeMatcher.resolve(nodes, ArixTargetSpec(index = 7))
        assertTrue(stale is ArixTargetResolution.NotFound)
        assertEquals(ArixTargetResolution.TARGET_STALE, (stale as ArixTargetResolution.NotFound).reason)
    }

    @Test
    fun `invisible nodes are never targeted by text`() {
        val nodes = listOf(node(0, text = "Hidden", visible = false), node(1, text = "Visible"))
        val resolution = ArixNodeMatcher.resolve(nodes, ArixTargetSpec(text = "Hidden"))
        assertTrue(resolution is ArixTargetResolution.NotFound)
    }

    @Test
    fun `content description exact match resolves`() {
        val nodes = listOf(
            node(0, desc = "Search"),
            node(1, desc = "Menu"),
        )
        val resolution = ArixNodeMatcher.resolve(nodes, ArixTargetSpec(contentDescription = "menu"))
        assertTrue(resolution is ArixTargetResolution.Resolved)
        assertEquals(1, (resolution as ArixTargetResolution.Resolved).node.index)
    }

    @Test
    fun `resource id matches full and short forms`() {
        val nodes = listOf(node(0, resId = "com.android.settings:id/title"))
        val byShort = ArixNodeMatcher.resolve(nodes, ArixTargetSpec(resourceId = "title"))
        assertTrue(byShort is ArixTargetResolution.Resolved)
        val byFull = ArixNodeMatcher.resolve(nodes, ArixTargetSpec(resourceId = "com.android.settings:id/title"))
        assertTrue(byFull is ArixTargetResolution.Resolved)
    }

    @Test
    fun `resource id ambiguity prefers the single clickable node`() {
        val nodes = listOf(
            node(0, resId = "row", clickable = false),
            node(1, resId = "row", clickable = true),
        )
        val resolution = ArixNodeMatcher.resolve(nodes, ArixTargetSpec(resourceId = "row"))
        assertTrue(resolution is ArixTargetResolution.Resolved)
        assertEquals(1, (resolution as ArixTargetResolution.Resolved).node.index)
    }

    @Test
    fun `coordinate hit picks clickable container`() {
        val container = node(0, bounds = ArixBounds(0, 0, 500, 500), className = "RecyclerView", clickable = true)
        val innerLabel = node(1, bounds = ArixBounds(10, 10, 200, 80), className = "TextView", parent = 0)
        val nodes = listOf(container, innerLabel)
        val resolution = ArixNodeMatcher.resolve(nodes, ArixTargetSpec(x = 50, y = 50))
        // Point is inside both; the matcher prefers the clickable container.
        assertTrue(resolution is ArixTargetResolution.Resolved)
        assertEquals(0, (resolution as ArixTargetResolution.Resolved).node.index)
    }

    @Test
    fun `coordinate miss is target not found`() {
        val nodes = listOf(node(0, bounds = ArixBounds(0, 0, 100, 100)))
        val resolution = ArixNodeMatcher.resolve(nodes, ArixTargetSpec(x = 500, y = 500))
        assertTrue(resolution is ArixTargetResolution.NotFound)
    }

    @Test
    fun `coordinate only requires both x and y`() {
        val nodes = listOf(node(0))
        val half = ArixNodeMatcher.resolve(nodes, ArixTargetSpec(x = 10))
        assertTrue(half is ArixTargetResolution.NotFound)
    }

    @Test
    fun `clickable ancestor resolution walks up`() {
        val root = node(0, bounds = ArixBounds(0, 0, 500, 500), className = "View", clickable = true)
        val label = node(1, text = "Open", className = "TextView", parent = 0)
        val nodes = listOf(root, label)
        val ancestor = ArixNodeMatcher.actionableAncestorOrSelf(label, nodes, requireClickable = true)
        assertNotNull(ancestor)
        assertEquals(0, ancestor!!.index)

        // The node itself wins when already actionable.
        val self = ArixNodeMatcher.actionableAncestorOrSelf(root, nodes, requireClickable = true)
        assertEquals(0, self!!.index)
    }

    @Test
    fun `fingerprint matching is used for stale-screen safety`() {
        val reference = node(0, text = "Save", resId = "com.app:id/save", bounds = ArixBounds(1, 2, 50, 60))
        val sameNode = node(3, text = "Save", resId = "com.app:id/save", bounds = ArixBounds(1, 2, 50, 60))
        val different = node(3, text = "Delete", resId = "com.app:id/save", bounds = ArixBounds(1, 2, 50, 60))
        assertTrue(reference.matchesFingerprint(sameNode))
        assertFalse(reference.matchesFingerprint(different))
    }

    @Test
    fun `renderer emits indices flags and bounds`() {
        val nodes = listOf(
            node(0, text = "Save", clickable = true, bounds = ArixBounds(10, 20, 110, 120)),
            node(1, text = "Name", className = "EditText", resId = "com.app:id/name"),
        )
        val rendered = ArixScreenRenderer.render(nodes)
        assertTrue(rendered.contains("#0"))
        assertTrue(rendered.contains("Save"))
        assertTrue(rendered.contains("[clickable]"))
        assertTrue(rendered.contains("id=name"))
        assertFalse(rendered.contains("#7"))
    }

    @Test
    fun `digest changes when content changes`() {
        val before = listOf(node(0, text = "A"))
        val same = listOf(node(0, text = "A"))
        val after = listOf(node(0, text = "B"))
        assertEquals(ArixScreenRenderer.digest(before), ArixScreenRenderer.digest(same))
        assertFalse(ArixScreenRenderer.digest(before) == ArixScreenRenderer.digest(after))
    }

    @Test
    fun `bounds helpers behave`() {
        val bounds = ArixBounds(10, 20, 110, 220)
        assertEquals(100, bounds.width)
        assertEquals(200, bounds.height)
        assertEquals(60, bounds.centerX)
        assertEquals(120, bounds.centerY)
        assertTrue(bounds.contains(10, 20))
        assertTrue(bounds.contains(109, 219))
        assertFalse(bounds.contains(110, 20))
        assertEquals("[10,20][110,220]", bounds.render())
        assertNull(bounds.takeIf { false })
    }
}
