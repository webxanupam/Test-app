package com.arix.app.data

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

class V246SourceGuardTest {
    private fun moduleDir(): File {
        var dir: File? = File(System.getProperty("user.dir"))
        repeat(6) {
            val direct = File(dir, "src/main/java/com/arix/app")
            if (direct.isDirectory) return dir!!
            dir = dir?.parentFile
        }
        throw IllegalStateException("app module directory not found")
    }

    private fun appSource(relative: String): String =
        File(moduleDir(), "src/main/java/com/arix/app/$relative").readText()

    @Test
    fun visualDisplayRendersExactlyOnePreviewPanel() {
        val src = appSource("ui/ConversationUi.kt")
        assertTrue(src.contains("agentModePreviewUnfiltered && !chromePreviewVisible"))
    }

    @Test
    fun chatPreviewWebViewIsTransparentOverTheDarkBackdrop() {
        val src = appSource("ui/ConversationUi.kt")
        assertTrue(src.contains("transparentBackground = true"))
    }

    @Test
    fun chromiumBootsOnAboutBlank() {
        // v2.4.8: reverted to Aether's about:blank start page.
        val src = appSource("data/AlpineChromeController.kt")
        assertTrue(src.contains("about:blank"))
    }

    @Test
    fun vncViewerSurfacesConnectionErrorsViaWatchdog() {
        val src = appSource("ui/AlpineChromeScreen.kt")
        assertTrue(src.contains("watchVncConnection"))
        assertTrue(src.contains("arix-vnc-status-visible"))
    }

    @Test
    fun noHardcodedSystemControlTool() {
        // v2.4.8: ArixSystemControlTool was removed entirely.
        // v2.7.6: the ADB `agent_mode` tool was removed too — device control is
        // the Accessibility service reached through ArixDeviceController.
        val executor = appSource("data/ArixToolExecutor.kt")
        assertFalse(executor.contains("system_control"))
        assertFalse(executor.contains("ArixSystemControlTool"))
        assertFalse(executor.contains("agent_mode"))
    }

    @Test
    fun agentModeControllerIsRemovedWithAdb() {
        // v2.7.6: the ADB-based ArixAgentModeController (uiautomator dump via
        // arix-adb) was deleted entirely and must never return. Screen reading
        // is the Accessibility service (ArixDeviceController.readScreen).
        val controllerFile = File(moduleDir(), "src/main/java/com/arix/app/data/ArixAgentModeController.kt")
        assertFalse(controllerFile.exists())
        val runtime = appSource("runtime/AlpineRuntime.kt")
        assertFalse(runtime.contains("arix-adb shell"))
        assertFalse(runtime.contains("uiautomator dump"))
        assertFalse(runtime.contains("screencap -p"))
    }

    @Test
    fun toolHeaderIsCenteredWithoutSubtitle() {
        val src = appSource("ui/ArixToolsUi.kt")
        assertTrue(src.contains("align(Alignment.CenterStart)"))
        assertTrue(src.contains("align(Alignment.Center)"))
    }

    @Test
    fun toolScreensHaveClearHeaderToContentSpacing() {
        val src = appSource("ui/ArixToolsUi.kt")
        assertTrue(src.contains("Spacer(Modifier.height(14.dp))"))
    }
}
