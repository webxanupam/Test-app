package com.arix.app.accessibility

import android.accessibilityservice.AccessibilityServiceInfo
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.provider.Settings
import android.view.accessibility.AccessibilityManager
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.lang.ref.WeakReference

/**
 * v2.7.6: Authoritative Accessibility state for Arix system control.
 *
 * Replaces the v2.4.9–v2.7.5 ADB-based screen awareness (uiautomator dump
 * through the Alpine-side arix-adb helper) with a genuine in-process
 * AccessibilityService connection. This object is the SINGLE source of truth
 * for whether Arix can currently control the device.
 *
 * It deliberately distinguishes:
 *  - DISABLED    — the service is not enabled in Android Settings.
 *  - CONNECTING  — enabled in Settings but the service instance is not bound yet.
 *  - CONNECTED   — the service is bound and usable (device control possible).
 *  - DISCONNECTED— previously connected, then unbound/crashed while still enabled
 *                  (MIUI may kill the service; the system rebinds it later).
 *  - UNAVAILABLE — the service is not resolvable on this build (never expected
 *                  on a healthy install; a hard, non-retryable condition).
 *
 * Nothing here is a stale cached Boolean: [currentState] recomputes from the
 * live service instance plus the platform's enabled-services list on every
 * call, and the service callbacks keep the StateFlow fresh for the UI.
 *
 * Android 11 / API 30 compatibility: every API used here exists since
 * API 16–24; no branch depends on post-API-30 behavior.
 */
/** Lifecycle states, ordered from least to most usable (top-level for import ergonomics). */
enum class ArixAccessibilityState { DISABLED, CONNECTING, CONNECTED, DISCONNECTED, UNAVAILABLE }

object ArixAccessibilityStateManager {

        private const val ServiceClassName = "com.arix.app.accessibility.ArixAccessibilityService"

    @Volatile
    private var instanceRef: WeakReference<ArixAccessibilityService>? = null

    /** Monotonic counter bumped on every (re)connect — reconnect diagnostics. */
    @Volatile
    private var connectCounter: Int = 0

    @Volatile
    private var lastUnbindReason: String = ""

    private val mutableState = MutableStateFlow(ArixAccessibilityState.DISABLED)
    val state: StateFlow<ArixAccessibilityState> = mutableState.asStateFlow()

    /** Last window-state event package seen by the service (cheap heuristic). */
    @Volatile
    var lastEventPackage: String? = null
        private set

    @Volatile
    var lastEventAtMillis: Long = 0L
        private set

    fun serviceComponent(context: Context): ComponentName =
        ComponentName(context.packageName, ServiceClassName)

    /** The bound service instance, or null when not connected. */
    fun connectedService(): ArixAccessibilityService? = instanceRef?.get()

    fun connectCount(): Int = connectCounter

    fun unbindReason(): String = lastUnbindReason

    // ------------------------------------------------------------------
    // Service lifecycle callbacks (invoked only by ArixAccessibilityService)
    // ------------------------------------------------------------------

    fun onServiceConnected(service: ArixAccessibilityService) {
        instanceRef = WeakReference(service)
        connectCounter += 1
        lastUnbindReason = ""
        publish(recomputeWithInstance(contextFrom(service)))
    }

    fun onServiceUnbound(service: ArixAccessibilityService, reason: String) {
        if (instanceRef?.get() === service) instanceRef = null
        lastUnbindReason = reason
        publish(recomputeWithInstance(contextFrom(service)))
    }

    fun onAccessibilityEvent(packageName: String?) {
        if (!packageName.isNullOrBlank()) {
            lastEventPackage = packageName
            lastEventAtMillis = System.currentTimeMillis()
        }
    }

    // ------------------------------------------------------------------
    // State computation
    // ------------------------------------------------------------------

    /**
     * Current authoritative state. Cheap enough to call before every
     * device-control operation (the enabled-check is a local settings read).
     */
    fun currentState(context: Context?): ArixAccessibilityState {
        if (instanceRef?.get() != null) return ArixAccessibilityState.CONNECTED
        return recomputeWithoutInstance(context)
    }

    private fun recomputeWithInstance(context: Context?): ArixAccessibilityState {
        if (instanceRef?.get() != null) return ArixAccessibilityState.CONNECTED
        return recomputeWithoutInstance(context)
    }

    private fun recomputeWithoutInstance(context: Context?): ArixAccessibilityState {
        val appContext = context ?: return ArixAccessibilityState.CONNECTING
        val enabled = isServiceEnabledInSettings(appContext)
        return when {
            !enabled -> ArixAccessibilityState.DISABLED
            lastUnbindReason.isNotBlank() -> ArixAccessibilityState.DISCONNECTED
            else -> ArixAccessibilityState.CONNECTING
        }
    }

    /** True only when the service is bound AND could be used right now. */
    fun isSystemControlAvailable(context: Context?): Boolean =
        currentState(context) == ArixAccessibilityState.CONNECTED

    /**
     * Is the service enabled in Android's Accessibility Settings? This is
     * permission-level state, NOT usability — the service may be enabled but
     * not yet bound. Uses both the AccessibilityManager list and the raw
     * secure setting string because OEMs (MIUI included) have shipped builds
     * where one of the two lags behind the other.
     */
    fun isServiceEnabledInSettings(context: Context): Boolean {
        val component = serviceComponent(context)
        if (component.packageName.isBlank() || component.className.isBlank()) return false

        val manager = context.getSystemService(Context.ACCESSIBILITY_SERVICE) as? AccessibilityManager
        if (manager != null) {
            runCatching {
                val enabled = manager.getEnabledAccessibilityServiceList(AccessibilityServiceInfo.FEEDBACK_ALL_MASK)
                if (enabled != null && enabled.any { it.resolveInfo?.serviceInfo?.name == component.className &&
                        it.resolveInfo?.serviceInfo?.packageName == component.packageName }) {
                    return true
                }
            }
        }

        // Fallback: parse the secure setting directly (flat-binder style,
        // works even when the manager service list is stale on OEM builds).
        runCatching {
            val raw = Settings.Secure.getString(context.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES)
            if (raw.isNullOrBlank()) return false
            val flatten = ComponentName.unflattenFromString(
                component.packageName + "/" + component.className,
            ) ?: component
            val flat = flatten.flattenToString().substringAfter('/')
            val flatShort = flatten.flattenToShortString()
            raw.split(':').any { entry ->
                val entryFlat = entry.trim()
                entryFlat == flat ||
                    entryFlat == flatShort ||
                    entryFlat.substringAfter('/').equals(component.className, ignoreCase = true) &&
                    (entryFlat.substringBefore('/').isBlank() || entryFlat.substringBefore('/').equals(component.packageName, ignoreCase = true))
            }
        }
        return false
    }

    /**
     * Opens Android's Accessibility Settings so the user can enable the Arix
     * service themselves. Opening the screen is NEVER treated as "enabled" —
     * the state must be re-checked with [currentState] after the user returns,
     * and only a CONNECTED result means control is actually possible.
     */
    fun openAccessibilitySettings(context: Context): Boolean = runCatching {
        val intent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(intent)
        true
    }.getOrDefault(false)

    /** Human-facing summary for diagnostics and the device_status tool. */
    fun describe(context: Context?): Map<String, Any> {
        val stateNow = currentState(context)
        return buildMap {
            put("state", stateNow.name.lowercase())
            put("enabled_in_settings", context?.let { isServiceEnabledInSettings(it) } ?: false)
            put("service_connected", connectedService() != null)
            put("connect_count", connectCounter)
            if (lastUnbindReason.isNotBlank()) put("last_unbind_reason", lastUnbindReason)
            put(
                "system_control_available",
                stateNow == ArixAccessibilityState.CONNECTED,
            )
        }
    }

    /** Force a recompute + publish (e.g. on activity resume after Settings). */
    fun refresh(context: Context?): ArixAccessibilityState {
        val next = currentState(context)
        publish(next)
        return next
    }

    private fun publish(next: ArixAccessibilityState) {
        mutableState.value = next
    }

    private fun contextFrom(service: ArixAccessibilityService): Context? =
        runCatching { service.applicationContext }.getOrNull()
}
