package com.arix.app.accessibility

/**
 * v2.7.6: Pure, framework-free snapshot of an AccessibilityNodeInfo plus the
 * semantic target matcher used by ArixDeviceController.
 *
 * Snapshots exist so that (a) matching logic is unit-testable without an
 * Android runtime, and (b) Arix never holds live AccessibilityNodeInfo
 * references across operations — on MIUI/Android 11 nodes go stale the moment
 * a window changes, so every action re-walks the live tree and re-resolves
 * the target from its fingerprint instead of caching node objects.
 */

/** Framework-free bounds box (screen coordinates, pixels). */
data class ArixBounds(
    val left: Int,
    val top: Int,
    val right: Int,
    val bottom: Int,
) {
    val width: Int get() = (right - left).coerceAtLeast(0)
    val height: Int get() = (bottom - top).coerceAtLeast(0)
    val centerX: Int get() = if (width > 0) (left + right) / 2 else left
    val centerY: Int get() = if (height > 0) (top + bottom) / 2 else top
    val area: Int get() = width * height

    fun contains(x: Int, y: Int): Boolean =
        x >= left && x < right && y >= top && y < bottom

    fun render(): String = "[$left,$top][$right,$bottom]"
}

/**
 * Immutable fingerprint of one node in the most recent [readScreen] walk.
 * `index` is stable only within that walk; targeting by index re-resolves the
 * fingerprint against a fresh walk, so a changed screen yields TARGET_STALE
 * instead of tapping the wrong element.
 */
data class ArixNodeSnapshot(
    val index: Int,
    val depth: Int,
    val parentIndex: Int,
    val text: String,
    val contentDescription: String,
    val viewIdResourceName: String?,
    val className: String,
    val packageName: String?,
    val bounds: ArixBounds?,
    val isClickable: Boolean,
    val isLongClickable: Boolean,
    val isScrollable: Boolean,
    val isEditable: Boolean,
    val isChecked: Boolean,
    val isCheckable: Boolean,
    val isEnabled: Boolean,
    val isVisibleToUser: Boolean,
    val isFocusable: Boolean,
    val isFocused: Boolean,
    val isPassword: Boolean,
) {
    val hasContent: Boolean
        get() = text.isNotBlank() || contentDescription.isNotBlank() || isClickable || isScrollable || isEditable

    fun matchesFingerprint(other: ArixNodeSnapshot): Boolean =
        text == other.text &&
            contentDescription == other.contentDescription &&
            viewIdResourceName == other.viewIdResourceName &&
            className == other.className &&
            bounds == other.bounds &&
            isClickable == other.isClickable &&
            isScrollable == other.isScrollable
}

/** How the caller identified the target node for an action. */
data class ArixTargetSpec(
    val index: Int? = null,
    val text: String? = null,
    val contentDescription: String? = null,
    val resourceId: String? = null,
    val x: Int? = null,
    val y: Int? = null,
) {
    val isEmpty: Boolean
        get() = index == null && text.isNullOrBlank() && contentDescription.isNullOrBlank() &&
            resourceId.isNullOrBlank() && x == null && y == null

    val isCoordinateOnly: Boolean
        get() = x != null && y != null && index == null && text.isNullOrBlank() &&
            contentDescription.isNullOrBlank() && resourceId.isNullOrBlank()

    fun describe(): String = buildString {
        if (index != null) append("index=$index")
        if (!text.isNullOrBlank()) appendIfBlank("text=\"$text\"")
        if (!contentDescription.isNullOrBlank()) appendIfBlank("desc=\"$contentDescription\"")
        if (!resourceId.isNullOrBlank()) appendIfBlank("resource_id=\"$resourceId\"")
        if (x != null && y != null) appendIfBlank("point=($x,$y)")
    }

    private fun StringBuilder.appendIfBlank(value: String) {
        if (isNotEmpty()) append(' ')
        append(value)
    }
}

/** Outcome of resolving an [ArixTargetSpec] against a node walk. */
sealed class ArixTargetResolution {
    /** Exactly one node identified. */
    data class Resolved(val node: ArixNodeSnapshot) : ArixTargetResolution()

    /** No node matched. [reason] is a stable machine code. */
    data class NotFound(val reason: String, val message: String) : ArixTargetResolution()

    /** More than one node matched — the caller must disambiguate. */
    data class Ambiguous(
        val matches: List<ArixNodeSnapshot>,
        val message: String,
    ) : ArixTargetResolution()

    companion object {
        const val TARGET_NOT_FOUND = "TARGET_NOT_FOUND"
        const val TARGET_STALE = "TARGET_STALE"
        const val TARGET_AMBIGUOUS = "TARGET_AMBIGUOUS"
    }
}

/**
 * Semantic-first matcher. Priority per Arix policy:
 *  1. node index from the latest read (fingerprint re-verified),
 *  2. text (exact, then unique substring),
 *  3. content description (exact, then unique substring),
 *  4. resource id (full or suffix match),
 *  5. node properties,
 *  6. coordinates (deepest/hittest node — last resort).
 *
 * Every rule requires a UNIQUE match; ambiguity is an error, never a guess.
 * Matching considers only nodes visible to the user when the walk marks them,
 * because invisible nodes cannot be acted upon on Android 11.
 */
object ArixNodeMatcher {

    fun resolve(nodes: List<ArixNodeSnapshot>, spec: ArixTargetSpec): ArixTargetResolution {
        if (spec.isEmpty) {
            return ArixTargetResolution.NotFound(
                ArixTargetResolution.TARGET_NOT_FOUND,
                "No target given: provide index, text, content_description, resource_id or coordinates from read_screen.",
            )
        }
        val candidates = nodes.filter { it.isVisibleToUser }

        // 1. Index from the latest read_screen walk.
        if (spec.index != null) {
            val node = nodes.firstOrNull { it.index == spec.index }
                ?: return ArixTargetResolution.NotFound(
                    ArixTargetResolution.TARGET_STALE,
                    "Node #${spec.index} no longer exists — the screen changed. Re-read the screen and retry.",
                )
            if (!node.isVisibleToUser) {
                return ArixTargetResolution.NotFound(
                    ArixTargetResolution.TARGET_NOT_FOUND,
                    "Node #${spec.index} exists but is not visible.",
                )
            }
            return ArixTargetResolution.Resolved(node)
        }

        // 2. Text — exact first (case-insensitive), then unique contains.
        if (!spec.text.isNullOrBlank()) {
            val exact = candidates.filter { it.text.equals(spec.text.trim(), ignoreCase = true) }
            if (exact.size == 1) return ArixTargetResolution.Resolved(exact.first())
            if (exact.size > 1) return ambiguous(exact, spec.text)
            val contains = candidates.filter {
                it.text.isNotBlank() && it.text.contains(spec.text.trim(), ignoreCase = true)
            }
            if (contains.size == 1) return ArixTargetResolution.Resolved(contains.first())
            if (contains.size > 1) return ambiguous(contains, spec.text)
            return ArixTargetResolution.NotFound(
                ArixTargetResolution.TARGET_NOT_FOUND,
                "No visible node has text \"${spec.text}\". Re-read the screen; if the target is icon-only, use its content_description or resource_id.",
            )
        }

        // 3. Content description — exact, then unique contains.
        if (!spec.contentDescription.isNullOrBlank()) {
            val exact = candidates.filter {
                it.contentDescription.equals(spec.contentDescription.trim(), ignoreCase = true)
            }
            if (exact.size == 1) return ArixTargetResolution.Resolved(exact.first())
            if (exact.size > 1) return ambiguous(exact, spec.contentDescription)
            return ArixTargetResolution.NotFound(
                ArixTargetResolution.TARGET_NOT_FOUND,
                "No visible node has content description \"${spec.contentDescription}\".",
            )
        }

        // 4. Resource id — full ("pkg:id/name"), short ("name") or suffix match.
        if (!spec.resourceId.isNullOrBlank()) {
            val wanted = spec.resourceId.trim()
            val idMatches = candidates.filter { node ->
                val id = node.viewIdResourceName
                if (id.isNullOrBlank()) {
                    false
                } else {
                    id == wanted || id.substringAfterLast('/') == wanted.substringAfterLast('/')
                }
            }
            if (idMatches.size == 1) return ArixTargetResolution.Resolved(idMatches.first())
            if (idMatches.size > 1) {
                // Same resource id repeated (list rows): only clickable ones help.
                val clickable = idMatches.filter { it.isClickable }
                if (clickable.size == 1) return ArixTargetResolution.Resolved(clickable.first())
                return ambiguous(idMatches, wanted)
            }
            return ArixTargetResolution.NotFound(
                ArixTargetResolution.TARGET_NOT_FOUND,
                "No visible node has resource id \"$wanted\".",
            )
        }

        // 5/6. Coordinates — deepest visible node containing the point.
        if (spec.x != null && spec.y != null) {
            val hit = candidates
                .filter { it.bounds != null && it.bounds.contains(spec.x, spec.y) && it.bounds.area > 0 }
                .sortedByDescending { it.bounds!!.area }
                .firstOrNull { it.isClickable } ?: candidates
                .filter { it.bounds != null && it.bounds.contains(spec.x, spec.y) && it.bounds.area > 0 }
                .minByOrNull { it.bounds!!.area }
            return if (hit != null) {
                ArixTargetResolution.Resolved(hit)
            } else {
                ArixTargetResolution.NotFound(
                    ArixTargetResolution.TARGET_NOT_FOUND,
                    "No visible node contains point (${spec.x},${spec.y}).",
                )
            }
        }

        return ArixTargetResolution.NotFound(
            ArixTargetResolution.TARGET_NOT_FOUND,
            "Incomplete target (coordinates need both x and y).",
        )
    }

    /**
     * The node to perform the action ON may be an inner text label whose
     * clickable ancestor actually receives the click. Returns the same node
     * when it is actionable; otherwise the nearest clickable/scrollable
     * ancestor within `maxHops`, or null.
     */
    fun actionableAncestorOrSelf(
        node: ArixNodeSnapshot,
        nodes: List<ArixNodeSnapshot>,
        requireClickable: Boolean,
        maxHops: Int = 6,
    ): ArixNodeSnapshot? {
        var current: ArixNodeSnapshot = node
        var hops = 0
        while (hops <= maxHops) {
            val ok = if (requireClickable) current.isClickable else current.isScrollable
            if (ok) return current
            if (current.parentIndex < 0) return null
            val parent = nodes.firstOrNull { it.index == current.parentIndex } ?: return null
            current = parent
            hops += 1
        }
        return null
    }

    /** Fingerprint equality used when re-resolving an index on a fresh walk. */
    fun findByFingerprint(nodes: List<ArixNodeSnapshot>, reference: ArixNodeSnapshot): List<ArixNodeSnapshot> =
        nodes.filter { it.matchesFingerprint(reference) }

    private fun ambiguous(matches: List<ArixNodeSnapshot>, wanted: String): ArixTargetResolution =
        ArixTargetResolution.Ambiguous(
            matches,
            "\"$wanted\" matches ${matches.size} visible nodes (#${matches.joinToString(", ") { it.index.toString() }}). " +
                "Narrow it: use the node index, a longer text, or its resource_id.",
        )
}

/**
 * Renders a node walk as the compact, token-efficient text tree the agent
 * reads. Format per line (mirrors the historical uiautomator-style dump the
 * agent already understands, now with a stable index):
 *
 * `#idx [l,t][r,b] Class [clickable][longClickable][scrollable][editable] | text="…" | desc="…" | id=…`
 */
object ArixScreenRenderer {

    const val DefaultMaxChars = 40_000

    fun render(nodes: List<ArixNodeSnapshot>, maxChars: Int = DefaultMaxChars): String {
        val builder = StringBuilder()
        for (node in nodes) {
            if (!node.hasContent && node.className.isBlank()) continue
            builder.append("  ".repeat(node.depth.coerceAtMost(30)))
                .append('#').append(node.index).append(' ')
                .append(node.bounds?.render() ?: "[]").append(' ')
                .append(node.className.substringAfterLast('.'))
            if (node.isClickable) builder.append(" [clickable]")
            if (node.isLongClickable) builder.append(" [longClickable]")
            if (node.isScrollable) builder.append(" [scrollable]")
            if (node.isEditable) builder.append(" [editable]")
            if (node.isChecked) builder.append(" [checked]")
            if (!node.isEnabled) builder.append(" [disabled]")
            if (node.text.isNotBlank()) builder.append(" | text=\"").append(node.text.take(160)).append('"')
            if (node.contentDescription.isNotBlank()) {
                builder.append(" | desc=\"").append(node.contentDescription.take(160)).append('"')
            }
            val shortId = node.viewIdResourceName?.substringAfterLast('/')
            if (!shortId.isNullOrBlank()) builder.append(" | id=").append(shortId)
            builder.append('\n')
            if (builder.length > maxChars) {
                builder.append("…(truncated at ").append(maxChars).append(" chars)\n")
                break
            }
        }
        return builder.toString().trimEnd()
    }

    /** Short digest used for change detection (verification layer). */
    fun digest(nodes: List<ArixNodeSnapshot>): String {
        var hash = 17
        for (node in nodes) {
            hash = hash * 31 + node.index
            hash = hash * 31 + node.text.hashCode()
            hash = hash * 31 + node.contentDescription.hashCode()
            hash = hash * 31 + (node.viewIdResourceName?.hashCode() ?: 0)
            hash = hash * 31 + (node.bounds?.hashCode() ?: 0)
            hash = hash * 31 + node.isClickable.hashCode()
        }
        return hash.toString(16)
    }
}
