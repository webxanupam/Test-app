package com.arix.app.data

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Context
import android.content.Intent
import android.graphics.Path
import android.graphics.Rect
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.accessibility.AccessibilityNodeInfo
import com.arix.app.accessibility.ArixAccessibilityState
import com.arix.app.accessibility.ArixAccessibilityStateManager
import com.arix.app.accessibility.ArixBounds
import com.arix.app.accessibility.ArixNodeMatcher
import com.arix.app.accessibility.ArixNodeSnapshot
import com.arix.app.accessibility.ArixScreenRenderer
import com.arix.app.accessibility.ArixTargetResolution
import com.arix.app.accessibility.ArixTargetSpec
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.atomic.AtomicLong

/**
 * v2.7.6: ArixDeviceController — the ONE clean abstraction between the agent
 * and Android device control.
 *
 *   AGENT  →  ArixDeviceController  →  ArixAccessibilityService  →  ANDROID
 *
 * The agent (and the tool registry) never touches AccessibilityService
 * internals: they call controlled operations on this class, which validates
 * state, resolves targets semantically, performs the action, observes the
 * resulting screen and reports an honest, structured result.
 *
 * ADB is gone from device control. This class contains no shell-outs of any
 * kind: node actions, text/description/id matching, global actions and
 * gesture dispatch only. Deterministic native launches (openApp / openApp
 * Settings / openUrl) use public Android intents, and their results are
 * verified by OBSERVATION through the accessibility tree whenever the service
 * is connected — never by assuming that a startActivity call succeeded.
 *
 * Android 11 / API 30 / POCO X2 (MIUI) rules enforced throughout:
 *  - every Accessibility object is nullable-checked (root, windows, nodes);
 *  - nodes are never cached across operations (stale-node hazard) — targets
 *    are re-resolved from a fresh walk on every action;
 *  - service disconnect at ANY moment produces a structured failure, never a
 *    crash (the MIUI background killer is a normal event, not an exception);
 *  - gestures and node actions are time-bounded;
 *  - no API newer than 30 is used unguarded.
 */
class ArixDeviceController(
    private val appContext: Context,
    private val diagnosticLogger: ArixDiagnosticLogger? = null,
) {

    private val operationCounter = AtomicLong(0)

    // ==================================================================
    // Capability / state
    // ==================================================================

    /** Authoritative availability of system control for tool-registry gating. */
    fun isSystemControlAvailable(): Boolean =
        ArixAccessibilityStateManager.currentState(appContext) == ArixAccessibilityState.CONNECTED

    /** Structured accessibility state (the device_status tool payload). */
    fun accessibilityStatus(): JSONObject {
        val state = ArixAccessibilityStateManager.currentState(appContext)
        val enabled = ArixAccessibilityStateManager.isServiceEnabledInSettings(appContext)
        val result = JSONObject().apply {
            put("accessibility_state", state.name.lowercase())
            put("enabled_in_settings", enabled)
            put("service_connected", ArixAccessibilityStateManager.connectedService() != null)
            put("system_control_available", state == ArixAccessibilityState.CONNECTED)
            put(
                "detail",
                when (state) {
                    ArixAccessibilityState.CONNECTED ->
                        "Accessibility service connected — system control available."
                    ArixAccessibilityState.DISABLED ->
                        "The Arix accessibility service is disabled. Ask the user to enable it in " +
                            "Android Settings → Accessibility → Arix (installed services), then re-check with device_status."
                    ArixAccessibilityState.CONNECTING ->
                        "The service is enabled but still connecting. Wait a moment and re-check with device_status."
                    ArixAccessibilityState.DISCONNECTED ->
                        "The service was disconnected (MIUI may kill it). Re-check with device_status; " +
                            "the system usually rebinds it automatically."
                    ArixAccessibilityState.UNAVAILABLE ->
                        "The accessibility service is unavailable on this build."
                },
            )
            if (state == ArixAccessibilityState.CONNECTED) {
                currentAppJson()?.let { put("current_app", it) }
            }
        }
        return ArixToolContract.success(result, verified = true)
    }

    /** Opens Android Accessibility Settings (user-mediated; never auto-"enabled"). */
    fun openAccessibilitySettings(): JSONObject {
        val opened = ArixAccessibilityStateManager.openAccessibilitySettings(appContext)
        return if (opened) {
            ArixToolContract.success(
                JSONObject().apply {
                    put("action", "open_accessibility_settings")
                    put("state", "requested")
                    put(
                        "detail",
                        "Opened Android Accessibility Settings. The user must enable Arix themselves; " +
                            "opening this screen does NOT enable anything. After the user returns, re-check " +
                            "the real state with device_status.",
                    )
                },
                verified = false,
            )
        } else {
            ArixToolContract.failure(
                ArixToolContract.ACTION_FAILED,
                "Could not open Android Accessibility Settings.",
            )
        }
    }

    // ==================================================================
    // Observation
    // ==================================================================

    /**
     * Reads the current screen as a structured text tree (semantic screen
     * awareness). Requires the service to be CONNECTED. The tree contains
     * every visible element with a stable index, bounds, class, text,
     * description, resource id and interaction flags — the agent decides
     * what the elements mean.
     */
    suspend fun readScreen(maxChars: Int = ArixScreenRenderer.DefaultMaxChars): JSONObject =
        deviceControl { walk ->
            val tree = ArixScreenRenderer.render(walk.nodes, maxChars)
            val result = JSONObject().apply {
                put("screen", tree.ifBlank { "(no visible content)" })
                put("node_count", walk.nodes.size)
                currentAppJson(walk)?.let { put("current_app", it) }
                put(
                    "detail",
                    "Structured screen contents. Each line: #index [bounds] Class [flags] | text | desc | id. " +
                        "Targets for ui_action: index, text, content_description, resource_id or coordinates.",
                )
            }
            ArixToolContract.success(result, verified = true)
        }

    /** The currently active app/window (observed, not assumed). */
    suspend fun getCurrentApp(): JSONObject = deviceControl { walk ->
        val result = currentAppJson(walk) ?: JSONObject().apply {
            put("note", "No active window information available right now.")
        }
        ArixToolContract.success(result, verified = true)
    }

    // ==================================================================
    // System control actions
    // ==================================================================

    /**
     * Performs ONE ui action. Target resolution is semantic-first
     * (index/text/desc/id); coordinates are accepted as a last resort.
     * Every state-changing action is followed by a fresh screen observation
     * so the result reflects what ACTUALLY happened.
     */
    suspend fun uiAction(
        action: String,
        target: ArixTargetSpec,
        text: String? = null,
        direction: String? = null,
        points: List<Pair<Int, Int>> = emptyList(),
        durationMs: Long = 300L,
    ): JSONObject = deviceControl { before ->
        val normalizedAction = action.trim().lowercase()
        val beforeDigest = ArixScreenRenderer.digest(before.nodes)

        val actionResult: JSONObject = when (normalizedAction) {
            "click" -> performClick(target, before)
            "long_click", "longclick" -> performLongClick(target, before)
            "scroll" -> performScroll(target, before, direction)
            "set_text", "settext" -> performSetText(target, before, text)
            "focus" -> performNodeTargetAction(target, AccessibilityNodeInfo.ACTION_FOCUS, "focus")
            "clear_focus" -> performNodeTargetAction(target, AccessibilityNodeInfo.ACTION_CLEAR_FOCUS, "clear_focus")
            "press_back" -> performGlobalAction(AccessibilityService.GLOBAL_ACTION_BACK, "back")
            "press_home" -> performGlobalAction(AccessibilityService.GLOBAL_ACTION_HOME, "home")
            "press_recents" -> performGlobalAction(AccessibilityService.GLOBAL_ACTION_RECENTS, "recents")
            "gesture" -> performGesture(points, durationMs)
            else -> ArixToolContract.failure(
                ArixToolContract.INVALID_ARGUMENTS,
                "Unknown action '$action'. Valid: click, long_click, scroll, set_text, focus, clear_focus, " +
                    "press_back, press_home, press_recents, gesture.",
            )
        }

        // Observation + verification layer: re-read the screen and report the
        // real resulting state. The model judges; we never fabricate success.
        if (!actionResult.optBoolean("ok", false)) {
            return@deviceControl actionResult
        }
        val afterWalk = captureWalk()
        val afterDigest = afterWalk?.let { ArixScreenRenderer.digest(it.nodes) }
        val changed = afterDigest != null && afterDigest != beforeDigest
        val actionVerified = actionResult.optBoolean("verified", false)
        val verified = actionVerified || changed
        actionResult.put("observed", JSONObject().apply {
            put("state_changed", changed)
            currentAppJson(afterWalk ?: before)?.let { put("current_app", it) }
            afterWalk?.let { walk -> put("screen", ArixScreenRenderer.render(walk.nodes, ObservedMaxChars)) }
        })
        actionResult.put("verified", verified)
        actionResult.put("state", if (verified) "observed" else "performed_unverified")
        ArixToolContract.success(actionResult, verified = verified)
    }

    // ==================================================================
    // Deterministic native operations (no accessibility REQUIRED, verified
    // BY OBSERVATION whenever accessibility IS connected)
    // ==================================================================

    /** Launch an installed app by display name or package name. */
    suspend fun openApp(target: String): JSONObject {
        val requested = target.trim()
        if (requested.isBlank()) {
            return ArixToolContract.failure(
                ArixToolContract.INVALID_ARGUMENTS,
                "Provide the app name or package name to open.",
            )
        }
        val manager = appContext.packageManager
        val launchables = runCatching {
            manager.getInstalledApplications(0).filter { manager.getLaunchIntentForPackage(it.packageName) != null }
        }.getOrDefault(emptyList())
        val resolved = launchables.firstOrNull { it.packageName.equals(requested, ignoreCase = true) }
            ?: launchables.map { it to runCatching { manager.getApplicationLabel(it).toString() }.getOrDefault(it.packageName) }
                .firstOrNull { (info, label) ->
                    label.equals(requested, ignoreCase = true) ||
                        (requested.length >= 3 && label.contains(requested, ignoreCase = true))
                }?.first
            ?: return ArixToolContract.failure(
                ArixToolContract.TARGET_NOT_FOUND,
                "No installed app matched '$requested'. Ask the user for the exact app name.",
            )
        val label = runCatching { manager.getApplicationLabel(resolved).toString() }.getOrDefault(resolved.packageName)
        val launch = runCatching { manager.getLaunchIntentForPackage(resolved.packageName) }.getOrNull()
            ?: return ArixToolContract.failure(
                ArixToolContract.ACTION_FAILED,
                "App '$label' (${resolved.packageName}) has no launch intent.",
            )
        runCatching {
            appContext.startActivity(launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }.getOrElse {
            return ArixToolContract.failure(
                ArixToolContract.ACTION_FAILED,
                "Could not launch '$label': ${it.message ?: "unknown error"}",
            )
        }
        return verifyLaunch(
            expectedPackage = resolved.packageName,
            details = JSONObject().put("action", "open_app").put("app", label).put("package", resolved.packageName),
        )
    }

    /** Opens a standard Android Settings screen (deterministic intent). */
    suspend fun openSettings(page: String): JSONObject {
        val requested = page.trim().lowercase().ifBlank { "main" }
        val intent = settingsIntentFor(requested)
            ?: return ArixToolContract.failure(
                ArixToolContract.INVALID_ARGUMENTS,
                "Unknown settings page '$requested'. Valid: main, wifi, bluetooth, apps, notifications, " +
                    "sound, display, battery, storage, location, security, developer, about, accessibility.",
            )
        runCatching {
            appContext.startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }.getOrElse {
            return ArixToolContract.failure(
                ArixToolContract.ACTION_FAILED,
                "Could not open Settings ($requested): ${it.message ?: "unknown error"}",
            )
        }
        return verifyLaunch(
            expectedMarkers = settingsMarkersFor(requested),
            details = JSONObject().put("action", "open_settings").put("page", requested),
        )
    }

    /** Opens a URL with the default handler (browser or app). */
    suspend fun openUrl(url: String): JSONObject {
        val requested = url.trim()
        if (requested.isBlank()) {
            return ArixToolContract.failure(ArixToolContract.INVALID_ARGUMENTS, "Provide the URL to open.")
        }
        val normalized = if ("://" !in requested) "https://$requested" else requested
        val parsed = runCatching { Uri.parse(normalized) }.getOrNull()
            ?: return ArixToolContract.failure(ArixToolContract.INVALID_ARGUMENTS, "The URL is not valid.")
        runCatching {
            appContext.startActivity(
                Intent(Intent.ACTION_VIEW, parsed).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            )
        }.getOrElse {
            return ArixToolContract.failure(
                ArixToolContract.ACTION_FAILED,
                "No handler could open '$normalized': ${it.message ?: "unknown error"}",
            )
        }
        return ArixToolContract.success(
            JSONObject().apply {
                put("action", "open_url")
                put("url", normalized)
                put("state", "requested")
                put(
                    "detail",
                    "The open request was dispatched. If you must confirm the page actually loaded, " +
                        "use read_screen while the accessibility service is connected.",
                )
            },
            verified = false,
        )
    }

    // ==================================================================
    // Internals: state guard, tree walking, target resolution, actions
    // ==================================================================

    /**
     * Runs [block] only when system control is genuinely usable; converts any
     * unavailability into the structured failure contract (never throws to
     * the caller, never falls back to another mechanism).
     */
    private suspend fun deviceControl(block: suspend (NodeWalk) -> JSONObject): JSONObject = try {
        val state = ArixAccessibilityStateManager.currentState(appContext)
        if (state != ArixAccessibilityState.CONNECTED) {
            return ArixToolContract.failure(
                errorCodeForState(state),
                "Accessibility is $state — system control is unavailable. " +
                    stateGuidance(state),
            )
        }
        val walk = captureWalk()
            ?: return ArixToolContract.failure(
                ArixToolContract.ACCESSIBILITY_DISCONNECTED,
                "The accessibility service is connected but no window tree could be read right now " +
                    "(the screen may be off/locked or in a secure state). Wait, re-read, or ask the user.",
            )
        log("operation", mapOf("nodes" to walk.nodes.size))
        block(walk)
    } catch (throwable: Throwable) {
        log("failure", mapOf("error" to (throwable.message ?: throwable.javaClass.simpleName)))
        ArixToolContract.failure(
            ArixToolContract.ACTION_FAILED,
            "Device control operation failed: ${throwable.message ?: throwable.javaClass.simpleName}",
        )
    }

    private fun stateGuidance(state: ArixAccessibilityState): String = when (state) {
        ArixAccessibilityState.DISABLED ->
            "Ask the user to enable the Arix service in Android Settings → Accessibility, then re-check " +
                "with device_status. Do NOT attempt any other control mechanism."
        else ->
            "Re-check with device_status before retrying. Do NOT attempt any other control mechanism."
    }

    private fun errorCodeForState(state: ArixAccessibilityState): String = when (state) {
        ArixAccessibilityState.DISABLED -> ArixToolContract.ACCESSIBILITY_DISABLED
        ArixAccessibilityState.CONNECTING -> ArixToolContract.ACCESSIBILITY_DISCONNECTED
        ArixAccessibilityState.DISCONNECTED -> ArixToolContract.ACCESSIBILITY_DISCONNECTED
        ArixAccessibilityState.UNAVAILABLE -> ArixToolContract.ACCESSIBILITY_UNAVAILABLE
        ArixAccessibilityState.CONNECTED -> ArixToolContract.ACCESSIBILITY_DISCONNECTED
    }

    /** Data captured from one on-demand accessibility tree walk. */
    private class NodeWalk(
        val nodes: List<ArixNodeSnapshot>,
        val liveNodes: List<AccessibilityNodeInfo>,
        val rootPackage: String?,
        val windowTitle: String?,
    )

    /**
     * Walks the ACTIVE window tree (plus other interactive windows when the
     * active root is missing) and snapshots every node. `nodes[i]` and
     * `liveNodes[i]` are index-aligned. Live node objects are used for the
     * duration of ONE action only, never cached across calls.
     */
    private fun captureWalk(): NodeWalk? {
        val service = ArixAccessibilityStateManager.connectedService() ?: return null
        return runCatching { walkService(service) }.getOrNull()
    }

    /** One walked root window (its node tree + window title, if any). */
    private class RootEntry(val root: AccessibilityNodeInfo, val title: String?)

    private fun walkService(service: AccessibilityService): NodeWalk? {
        val roots = ArrayList<RootEntry>()
        var activeTitle: String? = null

        val activeRoot = runCatching { service.rootInActiveWindow }.getOrNull()
        if (activeRoot != null) {
            roots.add(RootEntry(activeRoot, null))
        }

        // Interactive windows cover dialogs, popups and split-screen panes
        // (FLAG_RETRIEVE_INTERACTIVE_WINDOWS, API 22+).
        val windows = runCatching { service.windows }.getOrNull()
        if (windows != null) {
            for (window in windows) {
                val root = runCatching { window.root }.getOrNull() ?: continue
                if (root === activeRoot) {
                    activeTitle = runCatching { window.title?.toString() }.getOrNull()
                    continue
                }
                val interesting = runCatching {
                    (window.isActive || window.isFocused) &&
                        roots.none { it.root === root }
                }.getOrDefault(false)
                if (interesting) {
                    roots.add(RootEntry(root, runCatching { window.title?.toString() }.getOrNull()))
                }
            }
        }
        if (roots.isEmpty()) return null

        val snapshots = ArrayList<ArixNodeSnapshot>(256)
        val live = ArrayList<AccessibilityNodeInfo>(256)
        var rootPackage: String? = null
        var title: String? = activeTitle

        for (entry in roots) {
            if (rootPackage == null) {
                rootPackage = runCatching { entry.root.packageName?.toString() }.getOrNull()
            }
            if (title == null && entry.title != null) title = entry.title
            walkNode(entry.root, 0, -1, snapshots, live)
            if (snapshots.size >= MaxNodes) break
        }
        if (snapshots.isEmpty()) return null
        return NodeWalk(snapshots, live, rootPackage, title)
    }

    /** Depth-first walk with hard limits (MIUI dialog safety). */
    private fun walkNode(
        node: AccessibilityNodeInfo,
        depth: Int,
        parentIndex: Int,
        snapshots: MutableList<ArixNodeSnapshot>,
        live: MutableList<AccessibilityNodeInfo>,
    ) {
        if (depth > MaxDepth || snapshots.size >= MaxNodes) return
        val snapshot = snapshotOf(node, snapshots.size, depth, parentIndex)
        val selfIndex: Int
        if (snapshot != null) {
            snapshots.add(snapshot)
            live.add(node)
            selfIndex = snapshot.index
        } else {
            selfIndex = parentIndex // transparent node: children attach to grandparent
        }
        val childCount = runCatching { node.childCount }.getOrDefault(0)
        for (childIndex in 0 until childCount) {
            if (snapshots.size >= MaxNodes) return
            val child = runCatching { node.getChild(childIndex) }.getOrNull() ?: continue
            walkNode(child, depth + 1, selfIndex, snapshots, live)
        }
    }

    private fun snapshotOf(
        node: AccessibilityNodeInfo,
        index: Int,
        depth: Int,
        parentIndex: Int,
    ): ArixNodeSnapshot? = runCatching {
        val boundsRect = Rect()
        runCatching { node.getBoundsInScreen(boundsRect) }
        val hasBounds = true
        ArixNodeSnapshot(
            index = index,
            depth = depth,
            parentIndex = parentIndex,
            text = node.text?.toString().orEmpty(),
            contentDescription = node.contentDescription?.toString().orEmpty(),
            viewIdResourceName = node.viewIdResourceName,
            className = node.className?.toString().orEmpty(),
            packageName = node.packageName?.toString(),
            bounds = if (hasBounds && boundsRect.width() > 0) {
                ArixBounds(boundsRect.left, boundsRect.top, boundsRect.right, boundsRect.bottom)
            } else {
                null
            },
            isClickable = node.isClickable,
            isLongClickable = node.isLongClickable,
            isScrollable = node.isScrollable,
            isEditable = node.isEditable,
            isChecked = node.isChecked,
            isCheckable = node.isCheckable,
            isEnabled = node.isEnabled,
            isVisibleToUser = node.isVisibleToUser,
            isFocusable = node.isFocusable,
            isFocused = node.isFocused,
            isPassword = node.isPassword,
        )
    }.getOrNull()

    private fun currentAppJson(walk: NodeWalk? = null): JSONObject? {
        val captured = walk ?: captureWalk()
        val service = ArixAccessibilityStateManager.connectedService()
        val packageName = captured?.rootPackage
            ?: runCatching { service?.rootInActiveWindow?.packageName?.toString() }.getOrNull()
            ?: ArixAccessibilityStateManager.lastEventPackage
        if (packageName.isNullOrBlank()) return null
        return JSONObject().apply {
            put("package", packageName)
            captured?.windowTitle?.takeIf { it.isNotBlank() }?.let { put("window_title", it.take(120)) }
        }
    }

    // ---- individual actions ------------------------------------------------

    private suspend fun performClick(target: ArixTargetSpec, walk: NodeWalk): JSONObject {
        val resolution = ArixNodeMatcher.resolve(walk.nodes, target)
        return when (resolution) {
            is ArixTargetResolution.Resolved -> {
                val actionable = ArixNodeMatcher.actionableAncestorOrSelf(
                    resolution.node,
                    walk.nodes,
                    requireClickable = true,
                )
                val node = actionable ?: resolution.node
                val performed = performNodeAction(node.index, walk, AccessibilityNodeInfo.ACTION_CLICK)
                if (performed) {
                    JSONObject().put("action", "click").put("target", resolution.node.index)
                        .put("performed", true).put("mechanism", "node_action")
                } else {
                    // Node action refused: coordinate gesture fallback — the
                    // LAST resort, at the target's own bounds center.
                    val bounds = resolution.node.bounds ?: actionable?.bounds
                    if (bounds != null) {
                        performGesture(
                            listOf(bounds.centerX to bounds.centerY, bounds.centerX to bounds.centerY),
                            GestureTapDurationMs,
                        ).let { gestureResult ->
                            if (gestureResult.optBoolean("ok", false)) {
                                gestureResult.put("action", "click").put("target", resolution.node.index)
                                    .put("mechanism", "coordinate_gesture")
                            } else {
                                gestureResult
                            }
                        }
                    } else {
                        ArixToolContract.failure(
                            ArixToolContract.ACTION_FAILED,
                            "Click on node #${resolution.node.index} was refused and it has no usable bounds " +
                                "for a gesture fallback.",
                        )
                    }
                }
            }
            is ArixTargetResolution.NotFound -> ArixToolContract.failure(resolution.reason, resolution.message)
            is ArixTargetResolution.Ambiguous -> ArixToolContract.failure(
                ArixToolContract.TARGET_AMBIGUOUS,
                resolution.message,
                JSONObject().put("matches", JSONArray().apply { resolution.matches.forEach { put(it.index) } }),
            )
        }
    }

    private fun performLongClick(target: ArixTargetSpec, walk: NodeWalk): JSONObject {
        val resolution = ArixNodeMatcher.resolve(walk.nodes, target)
        return when (resolution) {
            is ArixTargetResolution.Resolved -> {
                val actionable = ArixNodeMatcher.actionableAncestorOrSelf(
                    resolution.node,
                    walk.nodes,
                    requireClickable = true,
                )
                val node = actionable ?: resolution.node
                val performed = performNodeAction(
                    node.index,
                    walk,
                    AccessibilityNodeInfo.ACTION_LONG_CLICK,
                )
                if (performed) {
                    JSONObject().put("action", "long_click").put("target", resolution.node.index)
                        .put("performed", true).put("mechanism", "node_action")
                } else {
                    ArixToolContract.failure(
                        ArixToolContract.ACTION_FAILED,
                        "Node #${resolution.node.index} does not accept long-click. Use action=gesture with a " +
                            "stationary ~600ms press at its bounds center instead.",
                    )
                }
            }
            is ArixTargetResolution.NotFound -> ArixToolContract.failure(resolution.reason, resolution.message)
            is ArixTargetResolution.Ambiguous -> ArixToolContract.failure(
                ArixToolContract.TARGET_AMBIGUOUS,
                resolution.message,
            )
        }
    }

    private fun performScroll(target: ArixTargetSpec, walk: NodeWalk, direction: String?): JSONObject {
        val requestedDirection = when (direction?.trim()?.lowercase()) {
            null, "", "down", "forward" -> "forward"
            "up", "backward", "back" -> "backward"
            else -> return ArixToolContract.failure(
                ArixToolContract.INVALID_ARGUMENTS,
                "direction must be 'forward' (down) or 'backward' (up).",
            )
        }
        val scrollAction = if (requestedDirection == "forward") {
            AccessibilityNodeInfo.ACTION_SCROLL_FORWARD
        } else {
            AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD
        }

        // No explicit target → first scrollable container in the walk.
        val resolution = if (target.isEmpty) {
            val scrollable = walk.nodes.firstOrNull { it.isScrollable && it.isVisibleToUser }
                ?: return ArixToolContract.failure(
                    ArixToolContract.TARGET_NOT_FOUND,
                    "No scrollable container on the current screen. Provide a target (text/id) of the list " +
                        "you want to scroll.",
                )
            ArixTargetResolution.Resolved(scrollable)
        } else {
            ArixNodeMatcher.resolve(walk.nodes, target)
        }
        return when (resolution) {
            is ArixTargetResolution.Resolved -> {
                val node = ArixNodeMatcher.actionableAncestorOrSelf(
                    resolution.node,
                    walk.nodes,
                    requireClickable = false,
                ) ?: resolution.node
                val performed = performNodeAction(node.index, walk, scrollAction)
                if (performed) {
                    JSONObject().put("action", "scroll").put("direction", requestedDirection)
                        .put("target", node.index).put("performed", true).put("mechanism", "node_action")
                } else {
                    ArixToolContract.failure(
                        ArixToolContract.ACTION_FAILED,
                        "Scroll on node #${node.index} was refused. Try action=gesture with a vertical swipe " +
                            "over the list bounds.",
                    )
                }
            }
            is ArixTargetResolution.NotFound -> ArixToolContract.failure(resolution.reason, resolution.message)
            is ArixTargetResolution.Ambiguous -> ArixToolContract.failure(
                ArixToolContract.TARGET_AMBIGUOUS,
                resolution.message,
            )
        }
    }

    private fun performSetText(target: ArixTargetSpec, walk: NodeWalk, text: String?): JSONObject {
        if (text == null) {
            return ArixToolContract.failure(
                ArixToolContract.INVALID_ARGUMENTS,
                "set_text requires the 'text' argument.",
            )
        }
        val resolution = ArixNodeMatcher.resolve(walk.nodes, target)
        return when (resolution) {
            is ArixTargetResolution.Resolved -> {
                val node = if (resolution.node.isEditable) {
                    resolution.node
                } else {
                    walk.nodes.firstOrNull { it.isEditable && it.isVisibleToUser } ?: resolution.node
                }
                val arguments = Bundle().apply {
                    putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
                }
                val performed = performNodeAction(
                    node.index,
                    walk,
                    AccessibilityNodeInfo.ACTION_SET_TEXT,
                    arguments,
                )
                if (!performed) {
                    return ArixToolContract.failure(
                        ArixToolContract.ACTION_FAILED,
                        "Node #${node.index} refused set_text (it may not be editable). Focus the field " +
                            "(action=focus) and have the user type, or retry with the correct field target.",
                    )
                }
                // Observation-based verification: read the node's real text back.
                val observedText = readNodeText(walk, node.index)
                val verified = observedText?.contains(text.take(40)) == true
                JSONObject().put("action", "set_text").put("target", node.index)
                    .put("performed", true)
                    .put("verified", verified)
                    .put("observed_text", observedText ?: "")
            }
            is ArixTargetResolution.NotFound -> ArixToolContract.failure(resolution.reason, resolution.message)
            is ArixTargetResolution.Ambiguous -> ArixToolContract.failure(
                ArixToolContract.TARGET_AMBIGUOUS,
                resolution.message,
            )
        }
    }

    private fun performNodeTargetAction(target: ArixTargetSpec, nodeAction: Int, name: String): JSONObject {
        // Re-walk fresh: focus works on live nodes only.
        val walk = captureWalk()
            ?: return ArixToolContract.failure(
                ArixToolContract.ACCESSIBILITY_DISCONNECTED,
                "The accessibility connection was lost before the $name action.",
            )
        val resolution = ArixNodeMatcher.resolve(walk.nodes, target)
        return when (resolution) {
            is ArixTargetResolution.Resolved -> {
                val performed = performNodeAction(resolution.node.index, walk, nodeAction)
                if (performed) {
                    JSONObject().put("action", name).put("target", resolution.node.index)
                        .put("performed", true).put("mechanism", "node_action")
                } else {
                    ArixToolContract.failure(
                        ArixToolContract.ACTION_FAILED,
                        "Node #${resolution.node.index} refused the $name action.",
                    )
                }
            }
            is ArixTargetResolution.NotFound -> ArixToolContract.failure(resolution.reason, resolution.message)
            is ArixTargetResolution.Ambiguous -> ArixToolContract.failure(
                ArixToolContract.TARGET_AMBIGUOUS,
                resolution.message,
            )
        }
    }

    private fun performGlobalAction(globalAction: Int, name: String): JSONObject {
        val service = ArixAccessibilityStateManager.connectedService()
            ?: return ArixToolContract.failure(
                ArixToolContract.ACCESSIBILITY_DISCONNECTED,
                "The accessibility connection was lost before press_$name.",
            )
        val performed = runCatching { service.performGlobalAction(globalAction) }.getOrDefault(false)
        return if (performed) {
            val homeVerified = if (name == "home") verifyHomePressed() else null
            JSONObject().put("action", "press_$name").put("performed", true)
                .also { payload -> homeVerified?.let { payload.put("verified", it) } }
        } else {
            ArixToolContract.failure(
                ArixToolContract.ACTION_FAILED,
                "The system refused GLOBAL_ACTION_${name.uppercase()} (this can happen when the action is " +
                    "not supported in the current context, e.g. some gesture-navigation states).",
            )
        }
    }

    private fun verifyHomePressed(): Boolean? {
        // Best-effort: after HOME the active package usually becomes the
        // launcher. Unknown → null (unverified), never fabricated.
        return runCatching {
            val service = ArixAccessibilityStateManager.connectedService() ?: return null
            val root = service.rootInActiveWindow ?: return null
            val packageName = root.packageName?.toString() ?: return null
            val intent = appContext.packageManager.getLaunchIntentForPackage(packageName)
            intent?.categories?.contains(Intent.CATEGORY_HOME) == true
        }.getOrNull()
    }

    /** Coordinate gesture dispatch (API 24+, safe on API 30 / POCO X2). */
    private suspend fun performGesture(
        points: List<Pair<Int, Int>>,
        durationMs: Long,
    ): JSONObject {
        val path = points.filter { it.first >= 0 && it.second >= 0 }
        if (path.size < 2) {
            return ArixToolContract.failure(
                ArixToolContract.INVALID_ARGUMENTS,
                "gesture needs at least 2 points as 'points' (e.g. \"x,y x,y\") and a duration_ms.",
            )
        }
        val duration = durationMs.coerceIn(50L, 3_000L)
        val service = ArixAccessibilityStateManager.connectedService()
            ?: return ArixToolContract.failure(
                ArixToolContract.ACCESSIBILITY_DISCONNECTED,
                "The accessibility connection was lost before the gesture.",
            )
        val gesturePath = Path().apply {
            moveTo(path.first().first.toFloat(), path.first().second.toFloat())
            path.drop(1).forEach { (x, y) -> lineTo(x.toFloat(), y.toFloat()) }
        }
        val description = runCatching {
            GestureDescription.Builder()
                .addStroke(GestureDescription.StrokeDescription(gesturePath, 0L, duration))
                .build()
        }.getOrNull()
            ?: return ArixToolContract.failure(ArixToolContract.ACTION_FAILED, "The gesture could not be built.")

        val completed = runCatching {
            withTimeoutOrNull(GestureTimeoutMs + duration) {
                awaitGestureResult(service, description)
            }
        }.getOrNull() ?: false
        return if (completed) {
            JSONObject().put("action", "gesture").put("performed", true).put("mechanism", "coordinate_gesture")
        } else {
            ArixToolContract.failure(
                ArixToolContract.ACTION_FAILED,
                "The gesture was not completed (timed out or cancelled by the system).",
            )
        }
    }

    private suspend fun awaitGestureResult(
        service: AccessibilityService,
        description: GestureDescription,
    ): Boolean = suspendCancellableCoroutine { continuation ->
        val callback = object : AccessibilityService.GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) {
                if (continuation.isActive) continuation.resumeWith(Result.success(true))
            }

            override fun onCancelled(gestureDescription: GestureDescription?) {
                if (continuation.isActive) continuation.resumeWith(Result.success(false))
            }
        }
        val dispatched = runCatching { service.dispatchGesture(description, callback, null) }.getOrDefault(false)
        if (!dispatched && continuation.isActive) {
            continuation.resumeWith(Result.success(false))
        }
    }

    /**
     * Performs a node action against a FRESH walk: nodes go stale between the
     * resolution walk and the action (MIUI window churn), so the target's
     * fingerprint is re-matched on the live tree before acting.
     */
    private fun performNodeAction(
        resolvedIndex: Int,
        referenceWalk: NodeWalk,
        action: Int,
        arguments: Bundle? = null,
    ): Boolean {
        val reference = referenceWalk.nodes.firstOrNull { it.index == resolvedIndex } ?: return false
        val service = ArixAccessibilityStateManager.connectedService() ?: return false
        val liveWalk = runCatching { walkService(service) }.getOrNull() ?: return false
        // Re-resolve by fingerprint on the fresh walk; fall back to same-index
        // when the fingerprint is unique enough not to collide.
        val fingerprintMatches = liveWalk.nodes.filter { it.matchesFingerprint(reference) }
        val target: ArixNodeSnapshot = when {
            fingerprintMatches.size == 1 -> fingerprintMatches.first()
            fingerprintMatches.isNotEmpty() -> fingerprintMatches.firstOrNull { it.index == resolvedIndex }
                ?: fingerprintMatches.first()
            else -> liveWalk.nodes.getOrNull(resolvedIndex)
                ?.takeIf { it.className == reference.className } ?: return false
        }
        val liveNode = liveWalk.liveNodes.getOrNull(target.index) ?: return false
        runCatching { liveNode.refresh() }
        return runCatching { liveNode.performAction(action, arguments) }.getOrDefault(false)
    }

    private fun readNodeText(walk: NodeWalk, index: Int): String? {
        val snapshot = walk.nodes.firstOrNull { it.index == index } ?: return null
        val service = ArixAccessibilityStateManager.connectedService() ?: return null
        val liveWalk = runCatching { walkService(service) }.getOrNull() ?: return null
        val liveNode = liveWalk.liveNodes.getOrNull(snapshot.index)
            ?: liveWalk.liveNodes.firstOrNull {
                runCatching {
                    it.viewIdResourceName == snapshot.viewIdResourceName &&
                        it.text?.toString().orEmpty() == snapshot.text
                }.getOrDefault(false)
            }
            ?: return null
        runCatching { liveNode.refresh() }
        return runCatching { liveNode.text?.toString() }.getOrNull()
    }

    // ---- launch verification ------------------------------------------------

    /**
     * Observation-based verification for native launches. Polls the real
     * screen state for up to [LaunchVerifyTimeoutMs]. Without accessibility
     * the result honestly reports state=requested / verified=false.
     */
    private suspend fun verifyLaunch(
        expectedPackage: String? = null,
        expectedMarkers: List<String> = emptyList(),
        details: JSONObject = JSONObject(),
    ): JSONObject = withContext(Dispatchers.Default) {
        val accessibilityConnected =
            ArixAccessibilityStateManager.currentState(appContext) == ArixAccessibilityState.CONNECTED
        if (!accessibilityConnected) {
            return@withContext ArixToolContract.success(
                JSONObject().apply {
                    details.keys().forEach { put(it, details.get(it)) }
                    put("state", "requested")
                    put("verified", false)
                    put(
                        "detail",
                        "The launch request was dispatched. The Arix accessibility service is not connected, " +
                            "so the resulting screen could not be observed — this is NOT proof that the target " +
                            "screen opened. Ask the user to confirm, or connect accessibility first.",
                    )
                },
                verified = false,
            )
        }

        var observedPackage: String? = null
        var observedMarkers: List<String> = emptyList()
        var observed = false
        val deadline = System.currentTimeMillis() + LaunchVerifyTimeoutMs
        while (System.currentTimeMillis() < deadline) {
            delay(PollIntervalMs)
            val walk = captureWalk() ?: continue
            observedPackage = walk.rootPackage
            observed = true
            if (expectedMarkers.isNotEmpty()) {
                val haystack = walk.nodes
                    .filter { it.isVisibleToUser }
                    .joinToString(" ") { "${it.text} ${it.contentDescription}" }
                    .lowercase()
                observedMarkers = expectedMarkers.filter { haystack.contains(it.lowercase()) }
            }
            val packageOk = expectedPackage == null || observedPackage == expectedPackage
            val markersOk = expectedMarkers.isEmpty() || observedMarkers.isNotEmpty()
            if (packageOk && markersOk) break
        }

        val packageOk = expectedPackage == null || observedPackage == expectedPackage
        val markersOk = expectedMarkers.isEmpty() || observedMarkers.isNotEmpty()
        val verified = observed && packageOk && markersOk
        ArixToolContract.success(
            JSONObject().apply {
                details.keys().forEach { put(it, details.get(it)) }
                put("state", if (verified) "verified" else "observed_mismatch")
                put("verified", verified)
                put("observed", observed)
                put("observed_package", observedPackage ?: "")
                if (expectedPackage != null) put("expected_package", expectedPackage)
                if (observedMarkers.isNotEmpty()) put("matched_markers", JSONArray(observedMarkers))
                if (!verified) {
                    put(
                        "detail",
                        when {
                            !observed ->
                                "The screen could not be read after launch (accessibility lost). " +
                                    "Do not claim success — ask the user to confirm."
                            !packageOk ->
                                "After launch, the observed app is '${observedPackage}', not " +
                                    "'${expectedPackage}'. Report what was actually observed."
                            else ->
                                "The expected screen content was not observed. Report what was actually " +
                                    "observed instead of claiming the target screen opened."
                        },
                    )
                }
            },
            verified = verified,
        )
    }

    private fun settingsIntentFor(page: String): Intent? = when (page) {
        "main", "home", "root" -> Intent(Settings.ACTION_SETTINGS)
        "wifi", "wi-fi" -> Intent(Settings.ACTION_WIFI_SETTINGS)
        "bluetooth" -> Intent(Settings.ACTION_BLUETOOTH_SETTINGS)
        "apps" -> Intent(Settings.ACTION_MANAGE_APPLICATIONS_SETTINGS)
        "notifications" -> Intent("android.settings.NOTIFICATION_SETTINGS")
        "sound", "volume" -> Intent(Settings.ACTION_SOUND_SETTINGS)
        "display" -> Intent(Settings.ACTION_DISPLAY_SETTINGS)
        "battery", "battery_saver" -> Intent(Settings.ACTION_BATTERY_SAVER_SETTINGS)
        "storage" -> Intent(Settings.ACTION_INTERNAL_STORAGE_SETTINGS)
        "location" -> Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS)
        "security" -> Intent(Settings.ACTION_SECURITY_SETTINGS)
        "developer", "developer_options" -> Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS)
        "about", "about_phone" -> Intent(Settings.ACTION_DEVICE_INFO_SETTINGS)
        "accessibility" -> Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)
        else -> null
    }

    private fun settingsMarkersFor(page: String): List<String> = when (page) {
        "main", "home", "root" -> listOf("settings")
        "wifi", "wi-fi" -> listOf("wi-fi", "wi‑fi", "wifi", "wireless", "network & internet")
        "bluetooth" -> listOf("bluetooth", "connected devices")
        "apps" -> listOf("apps & notifications", "app management", "manage apps", "all apps")
        "notifications" -> listOf("notifications")
        "accessibility" -> listOf("accessibility")
        else -> emptyList()
    }

    private fun log(event: String, details: Map<String, Any?>) {
        runCatching {
            diagnosticLogger?.event(
                category = "device_control",
                event = event,
                details = details + mapOf("op" to operationCounter.incrementAndGet()),
            )
        }
    }

    companion object {
        private const val MaxNodes = 900
        private const val MaxDepth = 45
        private const val GestureTimeoutMs = 2_000L
        private const val GestureTapDurationMs = 80L
        private const val LaunchVerifyTimeoutMs = 6_000L
        private const val PollIntervalMs = 350L
        private const val ObservedMaxChars = 1_600
    }
}
