package com.arix.app.accessibility

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityServiceInfo
import android.content.Intent
import android.view.accessibility.AccessibilityEvent

/**
 * v2.7.6: Arix's real system-control AccessibilityService (Android 11/API 30
 * compatible).
 *
 * History: v2.3.2 removed the previous accessibility experiment; v2.4.9–v2.7.5
 * used ADB (`arix-adb` + uiautomator dump + `adb shell input`) from the Alpine
 * guest. ADB is now removed from device control entirely — this service is
 * the ONLY Android system-control mechanism, registered in the manifest with
 * android.permission.BIND_ACCESSIBILITY_SERVICE and a standard
 * accessibility-service XML config.
 *
 * The service is deliberately THIN: it maintains the bound instance for
 * [ArixAccessibilityStateManager], records cheap window-state hints, and
 * performs node/gesture operations on behalf of [com.arix.app.data.ArixDeviceController].
 * It contains no "brain" — the agent decides, the controller validates, this
 * service executes. All heavy tree walking happens on demand in controller
 * coroutines, never on the accessibility callback thread.
 *
 * POCO X2 / MIUI robustness:
 *  - the instance is held via WeakReference, cleared in onUnbind/onDestroy;
 *  - every consumer must tolerate instance == null at any moment (killed
 *    service, aggressive battery manager, process recreation);
 *  - events are only used to update two volatile fields — no allocation-heavy
 *    work, so MIUI's stricter main-thread budgets are respected;
 *  - the service must survive activity recreation, app switches and screen
 *    changes without leaking state.
 */
class ArixAccessibilityService : AccessibilityService() {

    override fun onServiceConnected() {
        super.onServiceConnected()
        runCatching {
            serviceInfo = serviceInfo.apply {
                // Interactive windows let the controller see dialogs, popups and
                // split-screen panes on Android 11 (API 22+, safe on API 26+).
                flags = flags or AccessibilityServiceInfo.FLAG_RETRIEVE_INTERACTIVE_WINDOWS
                // Keep event traffic minimal: the controller polls trees on
                // demand; events only update a package hint.
                eventTypes = AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED
                feedbackType = AccessibilityServiceInfo.FEEDBACK_GENERIC
                notificationTimeout = 100
            }
        }
        ArixAccessibilityStateManager.onServiceConnected(this)
    }

    override fun onUnbind(intent: Intent): Boolean {
        // Called when the user disables the service, or the system unbinds it.
        // Both are recoverable: Android rebinds an enabled service.
        ArixAccessibilityStateManager.onServiceUnbound(this, "unbound")
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        ArixAccessibilityStateManager.onServiceUnbound(this, "destroyed")
        super.onDestroy()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Featherweight by design (MIUI main-thread budget). The package hint
        // helps getCurrentApp answer without a full tree walk.
        val packageName = event?.packageName?.toString()
        ArixAccessibilityStateManager.onAccessibilityEvent(packageName)
    }

    override fun onInterrupt() {
        // Nothing to interrupt — no feedback is produced.
    }
}
