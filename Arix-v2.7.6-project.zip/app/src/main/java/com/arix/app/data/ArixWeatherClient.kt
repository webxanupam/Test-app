package com.arix.app.data

import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/**
 * ArixWeatherClient — v2.7.5 native weather tool, powered by Weather.com.
 *
 * Answers weather questions with a live in-chat weather card (no LLM
 * round-trip, no user API key). Data source: The Weather Company's public
 * v3 API — the exact service weather.com itself serves from (the key below
 * is weather.com's own public web-client key, read from their site bundle):
 *
 *  - Location:    https://api.weather.com/v3/location/search
 *  - Current:     https://api.weather.com/v3/wx/observations/current
 *  - Daily:       https://api.weather.com/v3/wx/forecast/daily/5day
 *                 (with half-day daypart entries: rain chances, phrases…)
 *  - Hourly:      https://api.weather.com/v3/wx/forecast/hourly/12hour
 *  - Fallback location when the message carries no city: IP geolocation via
 *    https://get.geojs.io/v1/ip/geo.json (then ipapi.co).
 *
 * The card shows what a user actually needs without clutter: current
 * conditions, rain chance, the next hours' rain timeline, sunrise/sunset,
 * UV, and a 5-day outlook with day/night rain chances and a plain-language
 * narrative for each day.
 *
 * All methods perform blocking network IO — call from Dispatchers.IO.
 */
object ArixWeatherClient {

    private val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .followRedirects(true)
        .build()

    /** Hard cap on the daily forecast rows handed to the widget. */
    private const val MaxDailyEntries = 5

    /** Hourly rows shown on the rain-chance timeline. */
    private const val MaxHourlyEntries = 12

    /**
     * Weather.com's public web-client key (extracted from weather.com's own
     * JavaScript bundle — the same one their site uses for live data).
     */
    private const val ApiKey = "71f92ea9dd2f4790b92ea9dd2f779061"

    private const val BaseUrl = "https://api.weather.com"

    /* -------------------------------------------------------------- public */

    /**
     * Fetches the weather for [query] (a free-text place name, blank = use IP
     * geolocation) and returns the structured `weather` widget payload.
     */
    fun weatherOutputJson(query: String): String {
        val place = resolvePlace(query)
        val observations = fetchObservations(place.latitude, place.longitude)
        val forecast = fetchDailyForecast(place.latitude, place.longitude)
        val hourly = fetchHourlyForecast(place.latitude, place.longitude)

        val current = observations
        val daypart = forecast.optJSONArray("daypart")?.optJSONObject(0) ?: JSONObject()

        // Today's rain chance: the day slot when present, else the night slot.
        val todayDay = daypartSlot(daypart, 0)
        val todayNight = daypartSlot(daypart, 1)
        val todayRainChance = (todayDay?.optInt("precipChance", 0) ?: 0)
            .takeIf { todayDay != null }
            ?: (todayNight?.optInt("precipChance", 0) ?: 0)

        val hourlyEntries = JSONArray()
        val count = hourly.optJSONArray("validTimeUtc")?.length() ?: 0
        for (index in 0 until count.coerceAtMost(MaxHourlyEntries)) {
            val epochSeconds = hourly.optJSONArray("validTimeUtc")?.optLong(index) ?: 0L
            hourlyEntries.put(
                JSONObject()
                    .put("epoch_ms", epochSeconds * 1000L)
                    .put("temperature", hourly.optJSONArray("temperature")?.optInt(index) ?: 0)
                    .put("code", hourly.optJSONArray("iconCode")?.optInt(index) ?: 0)
                    .put("precip_chance", hourly.optJSONArray("precipChance")?.optInt(index) ?: 0)
                    .put("phrase", hourly.optJSONArray("wxPhraseLong")?.optString(index) ?: "")
                    .put("is_day", hourly.optJSONArray("dayOrNight")?.optString(index) == "D"),
            )
        }

        val dailyEntries = JSONArray()
        val dayCount = (forecast.optJSONArray("temperatureMax")?.length() ?: 0)
            .coerceAtMost(MaxDailyEntries)
        for (index in 0 until dayCount) {
            val daySlot = daypartSlot(daypart, index * 2)
            val nightSlot = daypartSlot(daypart, index * 2 + 1)
            val primary = daySlot ?: nightSlot ?: JSONObject()
            dailyEntries.put(
                JSONObject()
                    .put("date", forecast.optJSONArray("validTimeLocal")?.optString(index) ?: "")
                    .put("date_epoch_ms", epochSecondsOfLocal(forecast.optJSONArray("validTimeLocal")?.optString(index)))
                    .put("day_name", forecast.optJSONArray("dayOfWeek")?.optString(index) ?: "")
                    .put("code", primary.optInt("iconCode", 0))
                    .put("max", round1(arrayDouble(forecast.optJSONArray("temperatureMax"), index)))
                    .put("min", round1(arrayDouble(forecast.optJSONArray("temperatureMin"), index)))
                    .put("precipitation_probability", primary.optInt("precipChance", 0))
                    .put("day_rain_chance", daySlot?.optInt("precipChance", 0) ?: -1)
                    .put("night_rain_chance", nightSlot?.optInt("precipChance", 0) ?: -1)
                    .put("uv_index", daySlot?.optInt("uvIndex", -1) ?: -1)
                    .put("qpf", daySlot?.optDouble("qpf", 0.0) ?: 0.0)
                    .put("phrase", primary.optString("wxPhraseLong"))
                    .put("narrative", forecast.optJSONArray("narrative")?.optString(index) ?: "")
                    .put("sunrise", forecast.optJSONArray("sunriseTimeLocal")?.optString(index) ?: "")
                    .put("sunset", forecast.optJSONArray("sunsetTimeLocal")?.optString(index) ?: ""),
            )
        }

        val todayNarrative = forecast.optJSONArray("narrative")?.optString(0) ?: ""

        return JSONObject()
            .put("widget", "weather")
            .put("ok", true)
            .put("source", "Weather.com")
            .put("location", place.displayName)
            .put("latitude", place.latitude)
            .put("longitude", place.longitude)
            .put("observed_at", current.optString("validTimeLocal"))
            .put("temperature", round1(current.optDouble("temperature")))
            .put("apparent_temperature", round1(current.optDouble("temperatureFeelsLike")))
            .put("humidity", current.optInt("relativeHumidity"))
            .put("wind_speed", round1(current.optDouble("windSpeed")))
            .put("wind_direction", current.optString("windDirectionCardinal"))
            .put("wind_direction_deg", current.optInt("windDirection"))
            .put("visibility", round1(current.optDouble("visibility")))
            .put("pressure", round1(current.optDouble("pressureMeanSeaLevel")))
            .put("uv_index", current.optInt("uvIndex"))
            .put("uv_description", current.optString("uvDescription"))
            .put("is_day", current.optString("dayOrNight") == "D")
            .put("code", current.optInt("iconCode", 0))
            .put("condition", current.optString("wxPhraseLong"))
            .put("sunrise", current.optString("sunriseTimeLocal"))
            .put("sunset", current.optString("sunsetTimeLocal"))
            .put("precip_24h", round1(current.optDouble("precip24Hour")))
            .put("rain_chance_today", todayRainChance)
            .put("narrative", todayNarrative)
            .put("hourly", hourlyEntries)
            .put("daily", dailyEntries)
            .toString()
    }

    /* ------------------------------------------------------------ internals */

    private data class Place(
        val displayName: String,
        val latitude: Double,
        val longitude: Double,
    )

    private fun resolvePlace(query: String): Place {
        val trimmed = query.trim()
        if (trimmed.isNotEmpty()) {
            geocode(trimmed)?.let { return it }
        }
        return ipLocate() ?: Place("Earth", 0.0, 0.0)
    }

    /** Resolves a place name through Weather.com's location search. */
    private fun geocode(query: String): Place? {
        val url = "$BaseUrl/v3/location/search" +
            "?query=${urlEncode(query)}&locationType=city&apiKey=$ApiKey" +
            "&language=en-US&format=json"
        val body = getJson(url) ?: return null
        val address = body.optJSONArray("address") ?: return null
        val first = address.optJSONObject(0) ?: return null
        return Place(
            displayName = first.optString("address").ifBlank {
                listOf(first.optString("city"), first.optString("adminDistrict"), first.optString("country"))
                    .filter { it.isNotBlank() }
                    .joinToString(", ")
            },
            latitude = first.optDouble("latitude"),
            longitude = first.optDouble("longitude"),
        )
    }

    /** Best-effort IP geolocation (geojs first, ipapi.co as fallback). */
    private fun ipLocate(): Place? {
        runCatching {
            val body = getJson("https://get.geojs.io/v1/ip/geo.json") ?: return@runCatching
            val latitude = body.optDouble("latitude")
            val longitude = body.optDouble("longitude")
            if (latitude != 0.0 || longitude != 0.0) {
                return Place(
                    displayName = listOf(body.optString("city"), body.optString("region"), body.optString("country"))
                        .filter { it.isNotBlank() }
                        .joinToString(", "),
                    latitude = latitude,
                    longitude = longitude,
                )
            }
        }
        runCatching {
            val body = getJson("https://ipapi.co/json/") ?: return@runCatching
            val latitude = body.optDouble("latitude")
            val longitude = body.optDouble("longitude")
            if (latitude != 0.0 || longitude != 0.0) {
                return Place(
                    displayName = listOf(body.optString("city"), body.optString("region"), body.optString("country_name"))
                        .filter { it.isNotBlank() }
                        .joinToString(", "),
                    latitude = latitude,
                    longitude = longitude,
                )
            }
        }
        return null
    }

    private fun fetchObservations(latitude: Double, longitude: Double): JSONObject {
        val url = "$BaseUrl/v3/wx/observations/current" +
            "?geocode=${trimCoord(latitude)},${trimCoord(longitude)}" +
            "&apiKey=$ApiKey&language=en-US&units=m&format=json"
        val body = getJson(url)
            ?: error("Weather.com could not be reached. Check your connection and try again.")
        if (!body.has("temperature")) {
            error("Weather.com returned an unexpected response for the current conditions.")
        }
        return body
    }

    private fun fetchDailyForecast(latitude: Double, longitude: Double): JSONObject {
        val url = "$BaseUrl/v3/wx/forecast/daily/5day" +
            "?geocode=${trimCoord(latitude)},${trimCoord(longitude)}" +
            "&apiKey=$ApiKey&language=en-US&units=m&format=json"
        val body = getJson(url)
            ?: error("The Weather.com forecast could not be reached. Check your connection and try again.")
        if (!body.has("temperatureMax")) {
            error("Weather.com returned an unexpected response for the forecast.")
        }
        return body
    }

    private fun fetchHourlyForecast(latitude: Double, longitude: Double): JSONObject {
        val url = "$BaseUrl/v3/wx/forecast/hourly/12hour" +
            "?geocode=${trimCoord(latitude)},${trimCoord(longitude)}" +
            "&apiKey=$ApiKey&language=en-US&units=m&format=json"
        return getJson(url) ?: JSONObject()
    }

    /** Reads one parallel-array slot from a Weather.com daypart object. */
    private fun daypartSlot(daypart: JSONObject, index: Int): JSONObject? {
        val name = daypart.optJSONArray("daypartName")?.optString(index) ?: return null
        if (name.isBlank() || name == "null") return null
        return JSONObject()
            .put("daypartName", name)
            .put("precipChance", daypart.optJSONArray("precipChance")?.optInt(index) ?: 0)
            .put("iconCode", daypart.optJSONArray("iconCode")?.optInt(index) ?: 0)
            .put("temperature", daypart.optJSONArray("temperature")?.optInt(index) ?: 0)
            .put("wxPhraseLong", daypart.optJSONArray("wxPhraseLong")?.optString(index) ?: "")
            .put("dayOrNight", daypart.optJSONArray("dayOrNight")?.optString(index) ?: "D")
            .put("uvIndex", daypart.optJSONArray("uvIndex")?.optInt(index) ?: -1)
            .put("qpf", arrayDouble(daypart.optJSONArray("qpf"), index))
    }

    /** Reads a numeric parallel-array value as Double (handles Int/Double). */
    private fun arrayDouble(array: JSONArray?, index: Int): Double {
        val value = array?.opt(index) ?: return 0.0
        return when (value) {
            is Double -> value
            is Int -> value.toDouble()
            is Long -> value.toDouble()
            is Number -> value.toDouble()
            is String -> value.toDoubleOrNull() ?: 0.0
            else -> 0.0
        }
    }

    /** "2026-09-06T00:30:00+0530" → epoch millis (best-effort). */
    private fun epochSecondsOfLocal(value: String?): Long {
        if (value.isNullOrBlank()) return 0L
        return runCatching {
            // Weather.com emits offsets like "+0530" (no colon) — normalize
            // to "+05:30" so OffsetDateTime can parse it.
            val cleaned = value.substringBefore('.').replace(
                Regex("([+-]\\d{2})(\\d{2})$"),
                "$1:$2",
            )
            java.time.OffsetDateTime.parse(cleaned).toInstant().toEpochMilli()
        }.getOrDefault(0L)
    }

    private fun getJson(url: String): JSONObject? {
        val request = Request.Builder()
            .url(url)
            .header("User-Agent", ArixMediaApi.BrowserUserAgent)
            .header("Accept", "application/json")
            .get()
            .build()
        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) return null
            val text = response.body?.string() ?: return null
            if (text.isBlank()) return null
            return runCatching { JSONObject(text) }.getOrNull()
        }
    }

    private fun urlEncode(value: String): String =
        java.net.URLEncoder.encode(value, Charsets.UTF_8.name())

    private fun trimCoord(value: Double): String =
        String.format(java.util.Locale.US, "%.4f", value)

    private fun round1(value: Double): Double =
        Math.round(value * 10.0) / 10.0
}
