package com.arix.app.data

import com.arix.app.accessibility.ArixTargetSpec
import com.arix.app.runtime.RuntimeRouter
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.ConcurrentHashMap

data class ArixToolExecutionResult(
    val toolName: String,
    val argumentsJson: String,
    val rawOutput: String,
) {
    val visibleOutput: String = rawOutput
    val isError: Boolean = !ArixToolExecutor.inferToolOutputOk(rawOutput)
}

/**
 * Arix v2.7.6: AUTHORITATIVE host-tool registry and dispatcher.
 *
 * The LLM may only call tools that are genuinely available in the CURRENT
 * runtime; the tool list sent each turn is computed from live capability
 * state (Accessibility connection, MCP connections, dependency presence) —
 * never a static "everything exists" list.
 *
 * Dispatch contract (zero hallucinated tool calls, no substitution):
 *
 *   requested tool name
 *     → EXACT registry lookup (no fuzzy match, no similar-name guess)
 *     → availability check (dependency present + capability currently usable)
 *     → argument validation
 *     → loop guard (identical failing call repeated)
 *     → execute
 *
 * A tool that does not exist is TOOL_NOT_FOUND — a hard failure, never an
 * invitation to try another tool. There is NO automatic substitution: a
 * failed Accessibility operation does not fall back to shell, browser, MCP,
 * another agent, or anything else. ADB was removed from device control in
 * v2.7.6 and must never return as a hidden fallback.
 *
 * Device-control architecture:
 *   agent → ArixDeviceController → ArixAccessibilityService → Android
 *
 * v2.6.2: MCP host tools — `arix_mcp_list` and `arix_mcp_call` expose the
 * app's native MCP connections to the agent as first-class tools, and every
 * connected MCP tool is also registered under its namespaced call name with
 * its real input schema.
 *
 * v2.7.5: built-in weather + UPI payment tools (both LLM-driven; there is
 * deliberately NO keyword/regex router for them).
 */
class ArixToolExecutor(
    private val runtimeRouter: RuntimeRouter,
    private val deviceController: ArixDeviceController? = null,
    private val mcpClientManager: McpClientManager? = null,
    private val upiPaymentController: ArixUpiPaymentController? = null,
) {

    /** Per-recent-window identical-failure tracker (loop guard, §27). */
    private val failureTracker = ConcurrentHashMap<String, FailureRecord>()

    private class FailureRecord(
        @Volatile var count: Int,
        @Volatile var lastAtMillis: Long,
    )

    suspend fun execute(
        settings: AppSettings,
        workspaceDirectory: String,
        toolName: String,
        argumentsJson: String,
        selfManagementTool: ArixSelfManagementTool? = null,
        currentRuntimeId: LocalRuntimeId = settings.defaultRuntimeId ?: LocalRuntimeId.Alpine,
        onRuntimeChanged: suspend (LocalRuntimeId) -> Unit = {},
        onProgress: (suspend (String) -> Unit)? = null,
    ): ArixToolExecutionResult {
        val rawOutput = executeInternal(
            settings = settings,
            workspaceDirectory = workspaceDirectory,
            toolName = toolName,
            argumentsJson = argumentsJson,
            selfManagementTool = selfManagementTool,
            currentRuntimeId = currentRuntimeId,
            onRuntimeChanged = onRuntimeChanged,
            onProgress = onProgress,
        )
        // Failed host tool results are flagged via isError in the bridge
        // payload; the pi-bridge's built-in failure policy appends the
        // ask-the-user guidance to the result CONTENT (what the model reads)
        // while keeping the user-visible card clean.
        return ArixToolExecutionResult(toolName, argumentsJson, rawOutput)
    }

    private suspend fun executeInternal(
        settings: AppSettings,
        workspaceDirectory: String,
        toolName: String,
        argumentsJson: String,
        selfManagementTool: ArixSelfManagementTool?,
        currentRuntimeId: LocalRuntimeId,
        onRuntimeChanged: suspend (LocalRuntimeId) -> Unit,
        onProgress: (suspend (String) -> Unit)? = null,
    ): String {
        // ------------------------------------------------------------------
        // Loop guard FIRST: block the third IDENTICAL failing call. Every
        // failure path below feeds the tracker, so repeated identical calls
        // (unknown tool, unavailable capability, invalid arguments, execution
        // failure) all count.
        // ------------------------------------------------------------------
        val loopKey = "$toolName|${argumentsJson.hashCode()}"
        val record = failureTracker[loopKey]
        if (record != null && record.count >= MaxIdenticalFailures &&
            System.currentTimeMillis() - record.lastAtMillis < FailureWindowMillis
        ) {
            return ArixToolContract.withTool(
                ArixToolContract.failure(
                    ArixToolContract.REPEATED_FAILURE,
                    "The identical call to '$toolName' with the same arguments has already failed " +
                        "${record.count} times. Stop repeating it: report the failure to the user. A retry is " +
                        "only justified with CORRECTED, unambiguous input.",
                ),
                toolName,
            ).toString()
        }

        val rawOutput = executeValidated(
            settings = settings,
            workspaceDirectory = workspaceDirectory,
            toolName = toolName,
            argumentsJson = argumentsJson,
            selfManagementTool = selfManagementTool,
            currentRuntimeId = currentRuntimeId,
            onRuntimeChanged = onRuntimeChanged,
            onProgress = onProgress,
        )

        // Track identical failures for the loop guard; success resets.
        if (ArixToolExecutor.inferToolOutputOk(rawOutput)) {
            failureTracker.remove(loopKey)
        } else {
            val existing = failureTracker[loopKey]
            if (existing == null) {
                failureTracker[loopKey] = FailureRecord(1, System.currentTimeMillis())
            } else {
                existing.count += 1
                existing.lastAtMillis = System.currentTimeMillis()
            }
            if (failureTracker.size > TrackerCapacity) evictStaleFailures()
        }
        return rawOutput
    }

    /** Steps 1–5: exact lookup, availability, validation, dispatch. */
    private suspend fun executeValidated(
        settings: AppSettings,
        workspaceDirectory: String,
        toolName: String,
        argumentsJson: String,
        selfManagementTool: ArixSelfManagementTool?,
        currentRuntimeId: LocalRuntimeId,
        onRuntimeChanged: suspend (LocalRuntimeId) -> Unit,
        onProgress: (suspend (String) -> Unit)? = null,
    ): String {
        // ------------------------------------------------------------------
        // 1) EXACT registry lookup — a missing tool is a hard failure.
        // ------------------------------------------------------------------
        if (toolName !in hostToolNames && !isMcpNamespacedTool(toolName)) {
            return ArixToolContract.withTool(
                ArixToolContract.failure(
                    ArixToolContract.TOOL_NOT_FOUND,
                    "Tool '$toolName' does not exist in this runtime. Do not guess or substitute another " +
                        "tool; the available tools are exactly the ones listed for this turn.",
                ),
                toolName,
            ).toString()
        }

        // ------------------------------------------------------------------
        // 2) Availability + dependency check (TOOL_UNAVAILABLE when a
        //    capability is genuinely not usable right now).
        // ------------------------------------------------------------------
        val unavailable = unavailableReason(toolName, selfManagementTool)
        if (unavailable != null) {
            return ArixToolContract.withTool(
                ArixToolContract.failure(ArixToolContract.TOOL_UNAVAILABLE, unavailable),
                toolName,
            ).toString()
        }

        // ------------------------------------------------------------------
        // 3) Argument validation for the registry-validated device tools.
        // ------------------------------------------------------------------
        if (toolName in RegistryValidatedToolNames) {
            val arguments = runCatching { JSONObject(argumentsJson) }.getOrNull()
            if (arguments == null) {
                return ArixToolContract.withTool(
                    ArixToolContract.failure(
                        ArixToolContract.INVALID_ARGUMENTS,
                        "Arguments were not valid JSON.",
                    ),
                    toolName,
                ).toString()
            }
        }

        // ------------------------------------------------------------------
        // 4) Execute.
        // ------------------------------------------------------------------
        return dispatch(
            settings = settings,
            workspaceDirectory = workspaceDirectory,
            toolName = toolName,
            argumentsJson = argumentsJson,
            selfManagementTool = selfManagementTool,
            currentRuntimeId = currentRuntimeId,
            onRuntimeChanged = onRuntimeChanged,
            onProgress = onProgress,
        )
    }

    private fun evictStaleFailures() {
        val now = System.currentTimeMillis()
        failureTracker.entries.removeIf { now - it.value.lastAtMillis > FailureWindowMillis }
    }

    private suspend fun dispatch(
        settings: AppSettings,
        workspaceDirectory: String,
        toolName: String,
        argumentsJson: String,
        selfManagementTool: ArixSelfManagementTool?,
        currentRuntimeId: LocalRuntimeId,
        onRuntimeChanged: suspend (LocalRuntimeId) -> Unit,
        onProgress: (suspend (String) -> Unit)? = null,
    ): String = when (toolName) {
        "device_status" -> deviceStatusResult(argumentsJson)

        "read_screen" -> deviceToolResultSuspending(toolName) { controller ->
            val arguments = runCatching { JSONObject(argumentsJson) }.getOrNull()
            val maxChars = arguments?.optInt("max_chars", ArixScreenRendererDefaultMaxChars)
                ?: ArixScreenRendererDefaultMaxChars
            controller.readScreen(maxChars.coerceIn(2_000, 60_000))
        }

        "ui_action" -> uiActionResult(toolName, argumentsJson)

        "open_app" -> deviceToolResultSuspending(toolName) { controller ->
            val arguments = JSONObject(argumentsJson)
            controller.openApp(
                arguments.optString("app").ifBlank { arguments.optString("target") }.trim(),
            )
        }

        "open_settings" -> deviceToolResultSuspending(toolName) { controller ->
            val arguments = JSONObject(argumentsJson)
            controller.openSettings(
                arguments.optString("page").ifBlank { arguments.optString("screen") }.trim(),
            )
        }

        "open_url" -> deviceToolResultSuspending(toolName) { controller ->
            val arguments = JSONObject(argumentsJson)
            controller.openUrl(arguments.optString("url").trim())
        }

        "weather" -> executeWeatherTool(argumentsJson)

        "upi_pay" -> upiPaymentController?.execute(argumentsJson)
            ?: ArixToolContract.withTool(
                ArixToolContract.failure(
                    ArixToolContract.TOOL_UNAVAILABLE,
                    "UPI payments are not available in this build.",
                ),
                toolName,
            ).toString()

        "arix_runtime_manage" -> executeRuntimeManage(
            settings = settings,
            currentRuntimeId = currentRuntimeId,
            workspaceDirectory = workspaceDirectory,
            argumentsJson = argumentsJson,
            onRuntimeChanged = onRuntimeChanged,
        )

        "arix_mcp_list" -> executeMcpList()

        "arix_mcp_call" -> executeMcpCall(argumentsJson, onProgress)

        // Self-management tools (arix_config_* / arix_skill_manage /
        // arix_scheduled_task_manage / arix_extension_manage /
        // arix_developer_manage) execute through the self-management tool.
        in SelfManagementToolNames -> selfManagementTool?.execute(
            toolName = toolName,
            argumentsJson = argumentsJson,
        ) ?: unavailableToolOutput(toolName)

        // Namespaced MCP tools (mcp__<server>__<tool> or <server>:<tool>)
        else -> executeMcpToolByName(toolName, argumentsJson, onProgress)
    }

    // ------------------------------------------------------------------
    // Device-control tool wrappers
    // ------------------------------------------------------------------

    private fun deviceToolResult(
        toolName: String,
        block: (ArixDeviceController) -> JSONObject,
    ): String {
        val controller = deviceController
            ?: return ArixToolContract.withTool(
                ArixToolContract.failure(
                    ArixToolContract.TOOL_UNAVAILABLE,
                    "Device control is not available in this build.",
                ),
                toolName,
            ).toString()
        val payload = runCatching { block(controller) }.getOrElse { throwable ->
            ArixToolContract.failure(
                ArixToolContract.ACTION_FAILED,
                "Device operation failed: ${throwable.message ?: "unknown error"}",
            )
        }
        return ArixToolContract.withTool(payload, toolName).toString()
    }

    private suspend fun deviceToolResultSuspending(
        toolName: String,
        block: suspend (ArixDeviceController) -> JSONObject,
    ): String {
        val controller = deviceController
            ?: return ArixToolContract.withTool(
                ArixToolContract.failure(
                    ArixToolContract.TOOL_UNAVAILABLE,
                    "Device control is not available in this build.",
                ),
                toolName,
            ).toString()
        val payload = runCatching { block(controller) }.getOrElse { throwable ->
            ArixToolContract.failure(
                ArixToolContract.ACTION_FAILED,
                "Device operation failed: ${throwable.message ?: "unknown error"}",
            )
        }
        return ArixToolContract.withTool(payload, toolName).toString()
    }

    private fun deviceStatusResult(argumentsJson: String): String = deviceToolResult("device_status") { controller ->
        val arguments = runCatching { JSONObject(argumentsJson) }.getOrNull() ?: JSONObject()
        when (arguments.optString("action").trim().lowercase()) {
            "", "state", "status" -> controller.accessibilityStatus()
            "open_accessibility_settings" -> controller.openAccessibilitySettings()
            else -> ArixToolContract.failure(
                ArixToolContract.INVALID_ARGUMENTS,
                "Unknown device_status action. Use 'state' (default) or 'open_accessibility_settings'.",
            )
        }
    }

    private suspend fun uiActionResult(toolName: String, argumentsJson: String): String {
        val arguments = runCatching { JSONObject(argumentsJson) }.getOrNull()
            ?: return ArixToolContract.withTool(
                ArixToolContract.failure(
                    ArixToolContract.INVALID_ARGUMENTS,
                    "Arguments were not valid JSON.",
                ),
                toolName,
            ).toString()
        val action = arguments.optString("action").trim().lowercase()
        if (action.isBlank()) {
            return ArixToolContract.withTool(
                ArixToolContract.failure(
                    ArixToolContract.INVALID_ARGUMENTS,
                    "'action' is required (click, long_click, scroll, set_text, focus, clear_focus, " +
                        "press_back, press_home, press_recents, gesture).",
                ),
                toolName,
            ).toString()
        }
        val target = ArixTargetSpec(
            index = if (arguments.has("target_index") && !arguments.isNull("target_index")) {
                arguments.optInt("target_index")
            } else {
                null
            },
            text = arguments.optString("target_text").trim().ifBlank { null },
            contentDescription = arguments.optString("target_content_description").trim().ifBlank { null },
            resourceId = arguments.optString("target_resource_id").trim().ifBlank { null },
            x = if (arguments.has("x") && !arguments.isNull("x")) arguments.optInt("x") else null,
            y = if (arguments.has("y") && !arguments.isNull("y")) arguments.optInt("y") else null,
        )
        val points = parseGesturePoints(arguments.optString("points"))
        val payload = deviceToolResultSuspending(toolName) { controller ->
            controller.uiAction(
                action = action,
                target = target,
                text = arguments.optString("value").ifBlank { null },
                direction = arguments.optString("direction").trim().ifBlank { null },
                points = points,
                durationMs = if (arguments.has("duration_ms") && !arguments.isNull("duration_ms")) {
                    arguments.optLong("duration_ms")
                } else {
                    300L
                },
            )
        }
        return payload
    }

    private fun parseGesturePoints(raw: String): List<Pair<Int, Int>> = raw
        .split(' ', ';')
        .mapNotNull { token ->
            val cleaned = token.trim().removeSurrounding("(", ")")
            if (cleaned.isBlank()) return@mapNotNull null
            val parts = cleaned.split(',', ' ')
            if (parts.size < 2) return@mapNotNull null
            val x = parts[0].trim().toIntOrNull() ?: return@mapNotNull null
            val y = parts[1].trim().toIntOrNull() ?: return@mapNotNull null
            x to y
        }

    // ------------------------------------------------------------------
    // Availability resolution
    // ------------------------------------------------------------------

    private fun unavailableReason(toolName: String, selfManagementTool: ArixSelfManagementTool?): String? {
        when (toolName) {
            "read_screen", "ui_action" -> {
                val controller = deviceController ?: return "Device control is not available in this build."
                if (!controller.isSystemControlAvailable()) {
                    return "System control requires the Arix Accessibility service. It is currently not " +
                        "connected. Check the real state with device_status; do not attempt any other " +
                        "control mechanism."
                }
                return null
            }

            "upi_pay" -> if (upiPaymentController == null) return "UPI payments are not available in this build."

            "arix_mcp_list", "arix_mcp_call" -> if (mcpClientManager == null) {
                return "MCP is not available in this build."
            }

            in SelfManagementToolNames -> {
                if (selfManagementTool == null) return "Host dependency for '$toolName' is not available."
            }
        }
        return null
    }

    // ------------------------------------------------------------------
    // v2.7.5 weather tool
    // ------------------------------------------------------------------

    private suspend fun executeWeatherTool(argumentsJson: String): String {
        val arguments = runCatching { JSONObject(argumentsJson) }.getOrNull()
            ?: return ArixToolContract.withTool(
                ArixToolContract.failure(ArixToolContract.INVALID_ARGUMENTS, "Invalid JSON arguments."),
                "weather",
            ).toString()
        val query = arguments.optString("query")
            .ifBlank { arguments.optString("location") }
            .ifBlank { arguments.optString("place") }
            .ifBlank { arguments.optString("city") }
            .trim()
        return runCatching { ArixWeatherClient.weatherOutputJson(query) }
            .fold(
                onSuccess = { it },
                onFailure = { throwable ->
                    ArixToolContract.withTool(
                        ArixToolContract.failure(
                            ArixToolContract.NETWORK_ERROR,
                            "The weather lookup failed: ${throwable.message ?: "network error"}",
                        ),
                        "weather",
                    ).toString()
                },
            )
    }

    // ------------------------------------------------------------------
    // Runtime management (unchanged behavior, structured errors)
    // ------------------------------------------------------------------

    private suspend fun executeRuntimeManage(
        settings: AppSettings,
        currentRuntimeId: LocalRuntimeId,
        workspaceDirectory: String,
        argumentsJson: String,
        onRuntimeChanged: suspend (LocalRuntimeId) -> Unit,
    ): String {
        val arguments = runCatching { JSONObject(argumentsJson) }.getOrNull()
            ?: return ArixToolContract.withTool(
                ArixToolContract.failure(ArixToolContract.INVALID_ARGUMENTS, "Invalid JSON arguments."),
                "arix_runtime_manage",
            ).toString()
        val action = arguments.optString("action").trim()
        if (action == "status") {
            val states = listOf(LocalRuntimeId.Alpine).associateWith { runtimeId ->
                runtimeRouter.runtimeById(runtimeId).inspectSetup()
            }
            return JSONObject().apply {
                put("ok", true)
                put("action", "status")
                put("runtime", currentRuntimeId.storageValue)
                put("cwd", workspaceDirectory)
                put("available", JSONObject().apply {
                    states.forEach { (runtimeId, state) -> put(runtimeId.storageValue, state.isReady) }
                })
            }.toString()
        }
        if (action != "set") {
            return ArixToolContract.withTool(
                ArixToolContract.failure(
                    ArixToolContract.INVALID_ARGUMENTS,
                    "action must be 'status' or 'set'.",
                ),
                "arix_runtime_manage",
            ).toString()
        }
        val requested = LocalRuntimeId.fromStorage(arguments.optString("runtime"))
            ?: return ArixToolContract.withTool(
                ArixToolContract.failure(ArixToolContract.INVALID_ARGUMENTS, "runtime must be 'alpine'."),
                "arix_runtime_manage",
            ).toString()
        if (requested != LocalRuntimeId.Alpine) {
            return ArixToolContract.withTool(
                ArixToolContract.failure(
                    ArixToolContract.INVALID_ARGUMENTS,
                    "Alpine is the only local runtime.",
                ),
                "arix_runtime_manage",
            ).toString()
        }
        val setup = runtimeRouter.runtimeById(requested).inspectSetup()
        val enabled = settings.enabledRuntimeIds.isEmpty() || requested in settings.enabledRuntimeIds
        if (!setup.isReady || !enabled) {
            return JSONObject().apply {
                put("ok", false)
                put("errmsg", "${requested.displayName} runtime is unavailable.")
                put("detail", setup.detail)
                put("runtime", currentRuntimeId.storageValue)
                put("cwd", workspaceDirectory)
            }.toString()
        }
        onRuntimeChanged(requested)
        return JSONObject().apply {
            put("ok", true)
            put("action", "set")
            put("runtime", requested.storageValue)
            put("cwd", workspaceDirectory)
        }.toString()
    }

    // ------------------------------------------------------------------
    // MCP (v2.6.2, unchanged behavior, structured failures)
    // ------------------------------------------------------------------

    private suspend fun executeMcpList(): String {
        val manager = mcpClientManager
            ?: return ArixToolContract.withTool(
                ArixToolContract.failure(
                    ArixToolContract.TOOL_UNAVAILABLE,
                    "MCP is not available in this build.",
                ),
                "arix_mcp_list",
            ).toString()
        val result = manager.listTools(null)
        return result.fold(
            onSuccess = { output ->
                // Annotate with live per-server connection status.
                runCatching {
                    val parsed = JSONObject(output)
                    val statuses = JSONObject()
                    manager.snapshots().forEach { snapshot ->
                        statuses.put(
                            snapshot.config.id,
                            JSONObject()
                                .put("name", snapshot.config.displayName)
                                .put("status", snapshot.status.name.lowercase())
                                .put("enabled", snapshot.config.isEnabled)
                                .put(
                                    "error",
                                    snapshot.errorMessage.takeIf { it.isNotBlank() } ?: "",
                                ),
                        )
                    }
                    parsed.put("servers", statuses)
                    parsed.put("stdout", "Listed ${parsed.optJSONArray("tools")?.length() ?: 0} MCP tools.")
                    parsed.toString()
                }.getOrDefault(output)
            },
            onFailure = { throwable ->
                ArixToolContract.withTool(
                    ArixToolContract.failure(
                        ArixToolContract.NETWORK_ERROR,
                        throwable.message ?: "MCP list failed.",
                    ),
                    "arix_mcp_list",
                ).toString()
            },
        )
    }

    private suspend fun executeMcpCall(
        argumentsJson: String,
        onProgress: (suspend (String) -> Unit)?,
    ): String {
        val manager = mcpClientManager
            ?: return ArixToolContract.withTool(
                ArixToolContract.failure(
                    ArixToolContract.TOOL_UNAVAILABLE,
                    "MCP is not available in this build.",
                ),
                "arix_mcp_call",
            ).toString()
        val arguments = runCatching { JSONObject(argumentsJson) }.getOrNull()
            ?: return ArixToolContract.withTool(
                ArixToolContract.failure(ArixToolContract.INVALID_ARGUMENTS, "Invalid JSON arguments."),
                "arix_mcp_call",
            ).toString()
        val callName = arguments.optString("tool").trim()
            .ifBlank { arguments.optString("call_name").trim() }
            .ifBlank { arguments.optString("name").trim() }
        if (callName.isBlank()) {
            return ArixToolContract.withTool(
                ArixToolContract.failure(
                    ArixToolContract.INVALID_ARGUMENTS,
                    "'tool' (the MCP tool call name) is required. Use arix_mcp_list to discover names.",
                ),
                "arix_mcp_call",
            ).toString()
        }
        val callArguments = arguments.optJSONObject("arguments") ?: JSONObject()
        onProgress?.invoke(
            JSONObject()
                .put("ok", true)
                .put("status", "Calling MCP tool $callName…")
                .put("stdout", "Calling MCP tool $callName…")
                .toString()
        )
        val result = manager.callToolByName(callName, callArguments.toString())
        return result.fold(
            onSuccess = { output -> enrichMcpCallOutput(output, callName) },
            onFailure = { throwable ->
                ArixToolContract.withTool(
                    ArixToolContract.failure(
                        ArixToolContract.ACTION_FAILED,
                        throwable.message ?: "MCP tool call failed.",
                    ),
                    "arix_mcp_call",
                ).put("stdout", "MCP tool '$callName' failed: ${throwable.message}")
                    .toString()
            },
        )
    }

    /** Direct call for namespaced MCP tool host tools. */
    private suspend fun executeMcpToolByName(
        toolName: String,
        argumentsJson: String,
        onProgress: (suspend (String) -> Unit)?,
    ): String {
        val manager = mcpClientManager
            ?: return ArixToolContract.withTool(
                ArixToolContract.failure(
                    ArixToolContract.TOOL_UNAVAILABLE,
                    "MCP is not available in this build.",
                ),
                toolName,
            ).toString()
        val result = manager.callToolByName(toolName, argumentsJson)
        return result.fold(
            onSuccess = { output -> enrichMcpCallOutput(output, toolName) },
            onFailure = { throwable ->
                ArixToolContract.withTool(
                    ArixToolContract.failure(
                        ArixToolContract.ACTION_FAILED,
                        throwable.message ?: "MCP tool call failed.",
                    ),
                    toolName,
                ).put("stdout", "MCP tool '$toolName' failed: ${throwable.message}")
                    .toString()
            },
        )
    }

    /**
     * v2.6.2: marks a successful MCP call output with the widget hint the
     * chat renderer auto-detects (`widget: "mcp_data"` + the raw MCP result
     * under `result`) so movie-style results render as native chat widgets.
     */
    private fun enrichMcpCallOutput(output: String, callName: String): String =
        runCatching {
            val parsed = JSONObject(output)
            if (parsed.has("widget")) return output
            parsed.put("widget", "mcp_data")
            parsed.put("mcp_call_name", callName)
            parsed.put("stdout", parsed.optString("stdout").ifBlank { "Called MCP tool $callName." })
            parsed.toString()
        }.getOrDefault(output)

    // ------------------------------------------------------------------
    // Turn-scoped tool list (capability-gated)
    // ------------------------------------------------------------------

    /**
     * Tool definitions for the CURRENT turn, built from ACTUAL runtime state:
     * system-control tools appear only when the Accessibility service is
     * genuinely connected; MCP tools appear only for connected servers. The
     * LLM reasons only over the capabilities it actually receives.
     */
    suspend fun hostToolDefinitionsForTurn(
        selfManagementTool: ArixSelfManagementTool? = null,
    ): JSONArray {
        val base = hostToolDefinitions(selfManagementTool)
        // Native + status tools are included by hostToolDefinitions() only
        // when their dependency (deviceController) exists — that check is
        // static per build. The CONNECTION check for system control:
        runCatching {
            val controller = deviceController
            if (controller != null && controller.isSystemControlAvailable()) {
                base.put(readScreenToolDefinition())
                base.put(uiActionToolDefinition())
            }
        }
        // MCP namespaced tools.
        val manager = mcpClientManager
        if (manager != null) {
            runCatching {
                manager.toolBindings().forEach { binding ->
                    base.put(
                        JSONObject().apply {
                            put("name", binding.namespacedToolName)
                            put(
                                "description",
                                "[MCP ${binding.serverName}] ${binding.description.ifBlank { binding.toolName }} — call this directly; Arix auto-reconnects the server if needed.",
                            )
                            put(
                                "parameters",
                                relaxStrictOptionalParameters(binding.inputSchema),
                            )
                            put("execution_mode", "sequential")
                        },
                    )
                }
            }
        }
        return base
    }

    companion object {

        /**
         * Every tool name the Kotlin host can ever resolve EXACTLY. Includes
         * the system-control tools: they are only ADVERTISED per turn while
         * the Accessibility service is connected, but remain resolvable (and
         * fail with a structured ACCESSIBILITY_* error) if called while
         * disconnected — the model gets the real reason, not a false
         * "tool does not exist".
         */
        val hostToolNames: Set<String> = setOf(
            "device_status",
            "read_screen",
            "ui_action",
            "open_app",
            "open_settings",
            "open_url",
            "weather",
            "upi_pay",
            "arix_mcp_list",
            "arix_mcp_call",
            *SelfManagementToolNames.toTypedArray(),
        )

        /** Registry-validated device tools whose arguments must be JSON objects. */
        private val RegistryValidatedToolNames = setOf(
            "device_status",
            "read_screen",
            "ui_action",
            "open_app",
            "open_settings",
            "open_url",
        )

        /** Names requiring a CONNECTED Accessibility service (never listed when offline). */
        const val SystemControlToolReadScreen = "read_screen"
        const val SystemControlToolUiAction = "ui_action"

        private const val MaxIdenticalFailures = 2
        private const val FailureWindowMillis = 10 * 60_000L
        private const val TrackerCapacity = 128
        private const val ArixScreenRendererDefaultMaxChars = 40_000

        fun isMcpNamespacedTool(toolName: String): Boolean =
            toolName.startsWith("mcp__") || (
                toolName.contains(':') &&
                    !toolName.startsWith("arix_") &&
                    // Guard against unrelated ':' usage — MCP legacy names
                    // are "serverName:toolName" with no further colons.
                    toolName.count { it == ':' } == 1
                )

        /**
         * EXACT host-tool resolution used by the runner guard. No fuzzy
         * matching, no prefixes: a name is either registered or it is not.
         */
        fun supports(toolName: String): Boolean =
            toolName in hostToolNames || isMcpNamespacedTool(toolName)

        fun hostToolDefinitions(
            selfManagementTool: ArixSelfManagementTool? = null,
        ): JSONArray = JSONArray().apply {
            // Native launch + status tools (deterministic, no Accessibility
            // required; verification uses Accessibility when connected).
            put(deviceStatusToolDefinition())
            put(openAppToolDefinition())
            put(openSettingsToolDefinition())
            put(openUrlToolDefinition())
            put(weatherToolDefinition())
            put(upiPayToolDefinition())
            put(mcpListToolDefinition())
            put(mcpCallToolDefinition())
            selfManagementTool?.toolDefinitions()?.forEach { definition ->
                put(
                    flattenOpenAiToolDefinition(
                        definition = definition,
                        executionMode = if (
                            definition.optJSONObject("function")?.optString("name") == "arix_config_get"
                        ) "parallel" else "sequential",
                    ),
                )
            }
        }

        fun inferToolOutputOk(output: String): Boolean {
            val parsed = runCatching { JSONObject(output) }.getOrNull() ?: return true
            return parsed.optBoolean("ok", !parsed.optBoolean("err", false))
        }
    }
}

private val SelfManagementToolNames = setOf(
    "arix_config_get",
    "arix_config_set",
    "arix_skill_manage",
    "arix_runtime_manage",
    "arix_scheduled_task_manage",
    "arix_extension_manage",
    "arix_developer_manage",
)

private fun unavailableToolOutput(toolName: String): String = JSONObject()
    .put("ok", false)
    .put("errmsg", "Host dependency for '$toolName' is not available.")
    .toString()

private fun flattenOpenAiToolDefinition(
    definition: JSONObject,
    executionMode: String,
): JSONObject {
    val function = definition.optJSONObject("function") ?: JSONObject()
    return JSONObject().apply {
        put("name", function.optString("name"))
        put("description", function.optString("description"))
        put("parameters", relaxStrictOptionalParameters(function.optJSONObject("parameters")))
        put("execution_mode", executionMode)
    }
}

private fun relaxStrictOptionalParameters(parameters: JSONObject?): JSONObject {
    val relaxed = JSONObject((parameters ?: JSONObject().put("type", "object")).toString())
    val properties = relaxed.optJSONObject("properties") ?: return relaxed
    val required = relaxed.optJSONArray("required") ?: return relaxed
    relaxed.put("required", JSONArray().apply {
        for (index in 0 until required.length()) {
            val name = required.optString(index)
            if (name.isNotBlank() && !properties.optJSONObject(name).allowsNull()) put(name)
        }
    })
    return relaxed
}

private fun JSONObject?.allowsNull(): Boolean = when (val type = this?.opt("type")) {
    "null" -> true
    is JSONArray -> (0 until type.length()).any { type.optString(it) == "null" }
    else -> false
}

// ======================================================================
// v2.7.6 host-tool definitions. NOTE: none of these descriptions mention
// ADB, shell device control, or any mechanism other than the real one —
// the model must never be told a mechanism that does not exist.
// ======================================================================

/**
 * `device_status` — the capability check tool. Always available; reports the
 * REAL accessibility state (never an assumption) and can open Android
 * Accessibility Settings for the user.
 */
internal fun deviceStatusToolDefinition(): JSONObject = JSONObject().apply {
    put("name", "device_status")
    put(
        "description",
        "Check the device-control capability state: the REAL accessibility connection state " +
            "(disabled / connecting / connected / disconnected / unavailable), whether it is enabled in " +
            "Android Settings, the current foreground app when connected, and which system-control " +
            "capabilities are available right now. Call this BEFORE any system-control plan and whenever " +
            "read_screen or ui_action fail with an accessibility error. " +
            "action=open_accessibility_settings opens Android's Accessibility settings for the user to " +
            "enable the Arix service themselves — after they return, re-check with this tool; opening " +
            "settings NEVER means the service was enabled.",
    )
    put("parameters", JSONObject().apply {
        put("type", "object")
        put("properties", JSONObject().apply {
            put("action", JSONObject().put("type", "string").put(
                "description",
                "'state' (default) — read the real capability state; 'open_accessibility_settings' — open " +
                    "the Android settings page where the user enables the Arix service.",
            ))
        })
        put("additionalProperties", false)
    })
    put("execution_mode", "sequential")
}

/** `read_screen` — semantic screen awareness via the accessibility tree. */
internal fun readScreenToolDefinition(): JSONObject = JSONObject().apply {
    put("name", "read_screen")
    put(
        "description",
        "Read the current screen as structured text through the connected accessibility service: every " +
            "visible element with a stable #index, bounds, class, text, content description, resource id " +
            "and clickable/scrollable/editable flags, plus the active app. No screenshots — pure text. " +
            "Use this to observe what is ACTUALLY on screen before acting and after every state-changing " +
            "action to verify the result. Requires the Arix accessibility service to be connected (check " +
            "with device_status first).",
    )
    put("parameters", JSONObject().apply {
        put("type", "object")
        put("properties", JSONObject().apply {
            put("max_chars", JSONObject().put("type", "integer").put(
                "description",
                "Optional cap on the returned tree size (default 40000).",
            ))
        })
        put("additionalProperties", false)
    })
    put("execution_mode", "sequential")
}

/**
 * `ui_action` — one controlled UI action, semantic-first. Target priority:
 * index from the latest read_screen, then exact text, then content
 * description, then resource id; coordinates only as a last resort.
 */
internal fun uiActionToolDefinition(): JSONObject = JSONObject().apply {
    put("name", "ui_action")
    put(
        "description",
        "Perform ONE controlled interaction with the current screen through the accessibility service. " +
            "actions: click, long_click, scroll, set_text, focus, clear_focus, press_back, press_home, " +
            "press_recents, gesture. Identify the target SEMANTICALLY (target_index / target_text / " +
            "target_content_description / target_resource_id — exactly as seen in the latest read_screen); " +
            "coordinate gestures (x,y / points) are a last resort when a node action is impossible. " +
            "read_screen FIRST, then act: the result reports what was actually performed plus the observed " +
            "screen after the action — never assume the screen changed without checking 'observed'.",
    )
    put("parameters", JSONObject().apply {
        put("type", "object")
        put("properties", JSONObject().apply {
            put("action", JSONObject().put("type", "string").put(
                "description",
                "One of: click, long_click, scroll, set_text, focus, clear_focus, press_back, press_home, " +
                    "press_recents, gesture.",
            ))
            put("target_index", JSONObject().put("type", "integer").put(
                "description", "Node #index from the latest read_screen (preferred when known).",
            ))
            put("target_text", JSONObject().put("type", "string").put(
                "description", "Exact visible text of the target element (case-insensitive).",
            ))
            put("target_content_description", JSONObject().put("type", "string").put(
                "description", "Content description of the target (icon buttons).",
            ))
            put("target_resource_id", JSONObject().put("type", "string").put(
                "description", "Resource id, e.g. 'submit_button' (suffix match).",
            ))
            put("x", JSONObject().put("type", "integer").put(
                "description", "X coordinate (last resort, with y).",
            ))
            put("y", JSONObject().put("type", "integer").put(
                "description", "Y coordinate (last resort, with x).",
            ))
            put("value", JSONObject().put("type", "string").put(
                "description", "The text to type (for action=set_text).",
            ))
            put("direction", JSONObject().put("type", "string").put(
                "description", "Scroll direction: 'forward' (down, default) or 'backward' (up).",
            ))
            put("points", JSONObject().put("type", "string").put(
                "description", "Gesture path as \"x1,y1 x2,y2 ...\" (for action=gesture).",
            ))
            put("duration_ms", JSONObject().put("type", "integer").put(
                "description", "Gesture duration in ms (default 300).",
            ))
        })
        put("required", JSONArray().put("action"))
        put("additionalProperties", false)
    })
    put("execution_mode", "sequential")
}

/** `open_app` — deterministic native launch, verified by observation. */
internal fun openAppToolDefinition(): JSONObject = JSONObject().apply {
    put("name", "open_app")
    put(
        "description",
        "Launch an installed app by display name or package name via a standard Android launch intent. " +
            "When the accessibility service is connected the result is VERIFIED by observing the actual " +
            "foreground app; without it, the result honestly reports state=requested (dispatched, NOT " +
            "proof of success). Never claim the app opened unless the result says verified=true.",
    )
    put("parameters", JSONObject().apply {
        put("type", "object")
        put("properties", JSONObject().apply {
            put("app", JSONObject().put("type", "string").put(
                "description", "App display name (e.g. 'WhatsApp') or package name (e.g. com.whatsapp).",
            ))
        })
        put("required", JSONArray().put("app"))
        put("additionalProperties", false)
    })
    put("execution_mode", "sequential")
}

/** `open_settings` — deterministic Android Settings screen, verified by observation. */
internal fun openSettingsToolDefinition(): JSONObject = JSONObject().apply {
    put("name", "open_settings")
    put(
        "description",
        "Open an Android Settings screen by key: main, wifi, bluetooth, apps, notifications, sound, " +
            "display, battery, storage, location, security, developer, about, accessibility. Uses the " +
            "standard public Settings intent. With accessibility connected the result reports the " +
            "actually-observed screen — e.g. opening wifi settings is only verified when Wi-Fi content is " +
            "actually seen; report what was observed, not what was requested.",
    )
    put("parameters", JSONObject().apply {
        put("type", "object")
        put("properties", JSONObject().apply {
            put("page", JSONObject().put("type", "string").put(
                "description",
                "Settings screen key: main, wifi, bluetooth, apps, notifications, sound, display, " +
                    "battery, storage, location, security, developer, about, accessibility.",
            ))
        })
        put("required", JSONArray().put("page"))
        put("additionalProperties", false)
    })
    put("execution_mode", "sequential")
}

/** `open_url` — deterministic ACTION_VIEW dispatch. */
internal fun openUrlToolDefinition(): JSONObject = JSONObject().apply {
    put("name", "open_url")
    put(
        "description",
        "Open a URL with the device's default handler (browser or app) via the standard Android view " +
            "intent. The result reports state=requested — dispatch is not proof of loading. To verify the " +
            "page content, use read_screen while accessibility is connected.",
    )
    put("parameters", JSONObject().apply {
        put("type", "object")
        put("properties", JSONObject().apply {
            put("url", JSONObject().put("type", "string").put(
                "description", "The URL to open (https:// added automatically if missing).",
            ))
        })
        put("required", JSONArray().put("url"))
        put("additionalProperties", false)
    })
    put("execution_mode", "sequential")
}

/**
 * v2.7.5: `weather` — live current conditions + 5-day forecast from
 * Weather.com. The result renders as a rich in-chat weather card.
 */
internal fun weatherToolDefinition(): JSONObject = JSONObject().apply {
    put("name", "weather")
    put(
        "description",
        "Get live weather from Weather.com: current conditions (temperature, feels like, humidity, " +
            "wind, visibility, UV index, sunrise/sunset), the hourly rain-chance timeline for the next " +
            "12 hours, and a 5-day daily forecast with day/night details, precipitation chances and a " +
            "plain-language narrative. Call this for ANY weather-related request (current weather, " +
            "forecast, rain chances, 'will it rain today', temperature in a city, etc.). Rendered to " +
            "the user as a rich weather card automatically — summarize the highlights in one or two " +
            "sentences and let the card show the details.",
    )
    put("parameters", JSONObject().apply {
        put("type", "object")
        put("properties", JSONObject().apply {
            put("query", JSONObject().put("type", "string").put(
                "description",
                "The place to get weather for — a city or area name (e.g. 'Kolkata', 'Delhi', " +
                    "'London'). Empty or omitted = the user's current location (IP-based)."
            ))
        })
        put("additionalProperties", false)
    })
    put("execution_mode", "sequential")
}

/**
 * v2.7.5: `upi_pay` — native UPI payment via the standard Android upi://
 * deep link. No root, no ADB, no accessibility automation, and Arix never
 * sees credentials: the user confirms the payment inside their own UPI app.
 */
internal fun upiPayToolDefinition(): JSONObject = JSONObject().apply {
    put("name", "upi_pay")
    put(
        "description",
        "Send money through UPI (India's payment system) by opening the native Android UPI payment " +
            "sheet — the user picks their UPI app (GPay, PhonePe, Paytm, BHIM, …) and confirms inside " +
            "it; Arix never touches credentials and no root/ADB/accessibility is used. Call this " +
            "whenever the user asks to pay, send money, or transfer an amount through UPI, e.g. " +
            "'pay 300 to 9876543210' or 'send 50 rupees to name@okhdfcbank'. Extract the payee " +
            "(UPI ID like name@bank OR a 10-digit mobile number registered with UPI) and the amount " +
            "in rupees from the user's message; include the payee name and a short note when the " +
            "user provides them. If the payee or amount is missing or ambiguous, ASK the user " +
            "instead of guessing — payments move real money. NEVER attempt to automate the UPI app " +
            "itself with ui_action/accessibility or any other mechanism — opening the UPI sheet is " +
            "where Arix's role ends, and the user's in-app confirmation is the only proof of payment.",
    )
    put("parameters", JSONObject().apply {
        put("type", "object")
        put("properties", JSONObject().apply {
            put("payee", JSONObject().put("type", "string").put(
                "description",
                "Who to pay: a UPI ID / virtual payment address (like 'name@okhdfcbank') or the " +
                    "10-digit mobile number registered with UPI."
            ))
            put("amount", JSONObject().put("type", "number").put(
                "description", "Amount to pay in rupees (INR), e.g. 300."
            ))
            put("payee_name", JSONObject().put("type", "string").put(
                "description", "Optional display name of the payee (pre-fills the UPI sheet)."
            ))
            put("note", JSONObject().put("type", "string").put(
                "description", "Optional short payment note/remark (max ~50 chars)."
            ))
        })
        put("required", JSONArray().put("payee").put("amount"))
        put("additionalProperties", false)
    })
    put("execution_mode", "sequential")
}

/** v2.6.2: arix_mcp_list — discover MCP servers, tools and option fields. */
internal fun mcpListToolDefinition(): JSONObject = JSONObject().apply {
    put("name", "arix_mcp_list")
    put(
        "description",
        "List the user's connected MCP (Model Context Protocol) servers with live connection " +
            "status, every tool they expose (namespaced call names like mcp__<server>__<tool>), " +
            "each tool's input fields, resources and prompts. Use this FIRST whenever the user " +
            "asks about data that might come from their MCP connections. If a server shows a bad " +
            "status, do not switch methods — call the tool anyway; Arix auto-reconnects the server " +
            "and waits for it.",
    )
    put("parameters", JSONObject().apply {
        put("type", "object")
        put("properties", JSONObject().apply {
            put("server", JSONObject().put("type", "string").put(
                "description", "Optional server id or name to filter to one MCP server."
            ))
        })
        put("additionalProperties", false)
    })
    put("execution_mode", "sequential")
}

/** v2.6.2: arix_mcp_call — call any MCP tool with auto-reconnect. */
internal fun mcpCallToolDefinition(): JSONObject = JSONObject().apply {
    put("name", "arix_mcp_call")
    put(
        "description",
        "Call an MCP tool by its call name. Accepts the namespaced form " +
            "(mcp__<server>__<tool>), the legacy form (<server>:<tool>) or a plain tool name " +
            "when it is unique. Arix automatically reconnects the MCP server if it is not " +
            "connected and waits for the reconnection before executing — you do NOT need to " +
            "fall back to other methods when a connection dropped, just call the tool. " +
            "Structured results (title / poster / stream / url fields) are rendered to the " +
            "user as interactive cards automatically.",
    )
    put("parameters", JSONObject().apply {
        put("type", "object")
        put("properties", JSONObject().apply {
            put("tool", JSONObject().put("type", "string").put(
                "description", "The MCP tool call name from arix_mcp_list, e.g. mcp__movies__search or movies:search."
            ))
            put("arguments", JSONObject().put("type", "object").put(
                "description", "The tool's input arguments as a JSON object (see the tool's fields from arix_mcp_list)."
            ))
        })
        put("required", JSONArray().put("tool"))
        put("additionalProperties", false)
    })
    put("execution_mode", "sequential")
}
