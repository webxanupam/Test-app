package com.arix.app

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.arix.app.data.ArixStorageAccess
import com.arix.app.ui.ArixApp

class MainActivity : AppCompatActivity() {
    private val notificationPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission(),
    ) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        maybeRequestStoragePermissionOnce()
        setContent {
            ArixApp(onNotificationPermissionRequested = ::maybeRequestNotificationPermission)
        }
    }

    override fun onResume() {
        super.onResume()
        (application as ArixApplication).runtime.nativeModManager.notifyUiStable()
        // v2.7.6: re-check the REAL accessibility state whenever the user
        // returns to the app (e.g. back from Android Accessibility Settings).
        // Opening settings never implies enabling — only the live service
        // state does, and this refresh recomputes it from the platform.
        com.arix.app.accessibility.ArixAccessibilityStateManager.refresh(applicationContext)
    }

    private fun maybeRequestNotificationPermission() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU) return
        if (
            ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.POST_NOTIFICATIONS,
            ) == PackageManager.PERMISSION_GRANTED
        ) {
            return
        }
        notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
    }

    /**
     * v2.4.1: the Alpine VM bind-mounts the phone's real shared storage as
     * /sdcard. Ask for the legacy storage permission exactly once on first
     * launch (Android 8–10); on Android 11+ the terminal's banner deep-links
     * to the All-files-access settings page instead, because that grant can
     * only be toggled by the user.
     */
    private fun maybeRequestStoragePermissionOnce() {
        val prefs = getSharedPreferences("arix_runtime_prefs", Context.MODE_PRIVATE)
        if (prefs.getBoolean("storage_permission_prompted", false)) return
        prefs.edit().putBoolean("storage_permission_prompted", true).apply()
        if (ArixStorageAccess.hasPhoneStorageAccess(this)) return
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) return
        ArixStorageAccess.requestPhoneStorageAccess(this)
    }
}
