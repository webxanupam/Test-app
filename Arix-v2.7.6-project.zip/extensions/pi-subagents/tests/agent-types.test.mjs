/**
 * v2.7.6 regression tests: strict agent dispatch (NO_FALLBACK policy).
 *
 * Run: npx tsc && node --test tests/agent-types.test.mjs
 *
 * Covers the Arix contract:
 *  - unknown agent → failure, NEVER general-purpose,
 *  - misspelled agent → failure,
 *  - disabled agent → failure,
 *  - case-insensitive exact match → accepted when unique,
 *  - case-ambiguous → failure,
 *  - getConfig() returns undefined for unknown/disabled types,
 *  - runAgent throws AGENT_NOT_FOUND for unknown types,
 *  - an explicitly configured fallback still works, but a broken one fails
 *    closed instead of guessing.
 */
import test from "node:test";
import assert from "node:assert/strict";
import { createRequire } from "node:module";

const require = createRequire(import.meta.url);

const {
  NO_FALLBACK,
  getConfig,
  getAgentConfig,
  resolveSpawnType,
  resolveSpawnTypeIn,
  setFallbackSubagent,
  getFallbackSubagent,
  registerAgents,
  buildAgentRegistry,
} = require("../dist/agent-types.js");
const { DEFAULT_AGENTS } = require("../dist/default-agents.js");

/** Fresh process-wide registry state per test (defaults + NO_FALLBACK). */
function resetRegistry() {
  registerAgents(new Map());
  // undefined == strict (NO_FALLBACK) since v2.7.6: an unset value means
  // "never substitute another agent". Verify STRICTLY via behavior below.
  setFallbackSubagent(undefined);
}

function resetRegistryStrictDefault() {
  registerAgents(new Map());
  // The pristine module default is NO_FALLBACK; the getter reflects it until
  // a setter runs. (Both "none" and undefined behave strictly.)
  setFallbackSubagent(NO_FALLBACK);
}

test("module default is NO_FALLBACK (strict dispatch)", () => {
  registerAgents(new Map());
  // The pristine module state (before any setter runs) is strict; verified
  // behaviorally because a setter may legally set undefined (also strict).
  const resolution = resolveSpawnType("ghost-agent");
  assert.equal(resolution.ok, false);
  assert.equal(resolution.type, undefined);
});

test("unknown agent type never falls back to general-purpose", () => {
  resetRegistry();
  const resolution = resolveSpawnType("definitely-not-an-agent");
  assert.equal(resolution.ok, false);
  assert.match(resolution.message, /Unknown or disabled agent type/);
  // The resolution must not secretly dispatch general-purpose (the Available
  // list legitimately mentions it as a registered agent).
  assert.equal("type" in resolution, false);
});

test("missing agent type fails closed", () => {
  resetRegistry();
  const resolution = resolveSpawnType(undefined);
  assert.equal(resolution.ok, false);
  assert.match(resolution.message, /No agent type given/);
});

test("misspelled agent type is rejected", () => {
  resetRegistry();
  for (const misspelled of ["explor", "explore-agent-extra", "general_purpose", "GENERAL"]) {
    const resolution = resolveSpawnType(misspelled);
    assert.equal(resolution.ok, false, `expected failure for "${misspelled}"`);
  }
});

test("disabled agent type is rejected", () => {
  resetRegistry();
  const disabled = new Map(DEFAULT_AGENTS);
  const explore = disabled.get("Explore");
  if (!explore) return; // not present in this registry build
  disabled.set("Explore", { ...explore, enabled: false });
  registerAgents(disabled);
  const resolution = resolveSpawnType("Explore");
  assert.equal(resolution.ok, false);
  assert.match(resolution.message, /Unknown or disabled agent type: "Explore"/);
});

test("exact and unique case-insensitive matches are accepted", () => {
  resetRegistry();
  if (!DEFAULT_AGENTS.has("Explore")) return;
  const exact = resolveSpawnType("Explore");
  assert.equal(exact.ok, true);
  assert.equal(exact.type, "Explore");
  assert.equal(exact.fellBackFrom, undefined);

  const lower = resolveSpawnType("explore");
  assert.equal(lower.ok, true);
  assert.equal(lower.type, "Explore");
});

test("case-ambiguous agent names are rejected", () => {
  const registry = new Map(DEFAULT_AGENTS);
  const template = registry.get("Explore") ?? [...registry.values()][0];
  registry.set("Custom", { ...template, name: "Custom" });
  registry.set("custom", { ...template, name: "custom" });
  const resolution = resolveSpawnTypeIn(registry, "CUSTOM");
  assert.equal(resolution.ok, false);
  assert.match(resolution.message, /Unknown or disabled agent type: "CUSTOM"/);
});

test("general-purpose stays a legitimate registered agent", () => {
  resetRegistry();
  if (!DEFAULT_AGENTS.has("general-purpose")) return;
  const resolution = resolveSpawnType("general-purpose");
  assert.equal(resolution.ok, true);
  assert.equal(resolution.type, "general-purpose");
  const config = getConfig("general-purpose");
  assert.ok(config);
});

test("getConfig returns undefined for unknown and disabled types", () => {
  resetRegistry();
  assert.equal(getConfig("nope"), undefined);
  const disabled = new Map(DEFAULT_AGENTS);
  const gp = disabled.get("general-purpose");
  if (!gp) return;
  disabled.set("general-purpose", { ...gp, enabled: false });
  registerAgents(disabled);
  // The enabled-aware accessor must refuse disabled agents.
  assert.equal(getConfig("general-purpose"), undefined);
});

test("runAgent throws AGENT_NOT_FOUND for unknown types", async () => {
  resetRegistry();
  const { runAgent } = await import("../dist/agent-runner.js");
  const fakeCtx = { cwd: process.cwd(), getSystemPrompt: () => "" };
  await assert.rejects(
    () => runAgent(fakeCtx, "no-such-agent", "prompt", {}),
    (error) => {
      assert.match(error.message, /AGENT_NOT_FOUND/);
      assert.match(error.message, /no-such-agent/);
      return true;
    },
  );
});

test("explicit configured fallback still works when valid", () => {
  resetRegistry();
  if (!DEFAULT_AGENTS.has("Explore")) return;
  setFallbackSubagent("Explore");
  const resolution = resolveSpawnType("does-not-exist");
  assert.equal(resolution.ok, true);
  assert.equal(resolution.type, "Explore");
  assert.equal(resolution.fellBackFrom, "does-not-exist");
});

test("broken configured fallback fails closed instead of guessing", () => {
  resetRegistry();
  setFallbackSubagent("also-broken");
  const resolution = resolveSpawnType("does-not-exist");
  assert.equal(resolution.ok, false);
  assert.match(resolution.message, /fallbackSubagent "also-broken"/);
});

test("buildAgentRegistry overlays user agents over defaults", () => {
  const template = DEFAULT_AGENTS.get("Explore") ?? [...DEFAULT_AGENTS.values()][0];
  const user = new Map();
  user.set("mine", { ...template, name: "mine", description: "mine" });
  const registry = buildAgentRegistry(user);
  assert.ok(registry.has("mine"));
  assert.ok(registry.has("Explore"));
});
