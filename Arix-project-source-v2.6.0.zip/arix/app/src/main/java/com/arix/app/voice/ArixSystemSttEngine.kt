package com.arix.app.voice

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicLong
import java.util.concurrent.atomic.AtomicReference

/**
 * v2.6.0: system-default speech-to-text for the composer's voice input button.
 *
 * Replaces the bundled offline Vosk stack with the device's own speech
 * recognition service (Google / Samsung / etc. — whatever the user has
 * selected as the system recognizer). No model downloads, no bundled
 * assets, no native libraries: the APK stays small and recognition works
 * in every language the system recognizer supports.
 */
class ArixSystemSttEngine(
    private val context: Context,
) {
    sealed interface State {
        data object Idle : State
        data object Listening : State
        data class Partial(val text: String) : State
        data class Final(val text: String) : State
        data class Error(val message: String) : State
    }

    private val _state = MutableStateFlow<State>(State.Idle)
    val state: StateFlow<State> = _state.asStateFlow()

    private val recognizer = AtomicReference<SpeechRecognizer?>(null)
    private val startRequested = AtomicBoolean(false)
    private var watchdogJob: Job? = null
    private val lastSpeechActivityAt = AtomicLong(0L)

    fun hasMicPermission(): Boolean = ContextCompat.checkSelfPermission(
        context,
        Manifest.permission.RECORD_AUDIO,
    ) == PackageManager.PERMISSION_GRANTED

    /** True when the device has a system speech recognition service. */
    fun isRecognitionAvailable(): Boolean =
        SpeechRecognizer.isRecognitionAvailable(context)

    /**
     * Starts a recognition session using the system default recognizer.
     * Transcript updates flow through [state].
     *
     * [silenceTimeoutMs] arms a silence watchdog — when the user never talks
     * (or stops talking) for that long, listening stops cleanly (used by the
     * summoned assistant panel). 0 disables the watchdog (manual dictation —
     * the system recognizer performs its own endpointing and emits a final
     * result when the user stops speaking).
     *
     * Sets an error state when the mic permission is missing or no system
     * recognizer exists.
     */
    fun startListening(scope: CoroutineScope, silenceTimeoutMs: Long = 0L) {
        if (startRequested.getAndSet(true)) return
        if (!hasMicPermission()) {
            startRequested.set(false)
            _state.value = State.Error("Microphone permission is required for voice input.")
            return
        }
        if (!isRecognitionAvailable()) {
            startRequested.set(false)
            _state.value = State.Error(
                "No speech recognition service is installed on this device. " +
                    "Install or enable a voice input engine (e.g. Google app) and try again.",
            )
            return
        }
        // SpeechRecognizer must be driven from the main thread.
        scope.launch(Dispatchers.Main) {
            try {
                stopWatchdog()
                val engine = obtainRecognizer()
                lastSpeechActivityAt.set(System.currentTimeMillis())
                _state.value = State.Listening
                engine.startListening(buildRecognizerIntent())
                startSilenceWatchdog(scope, silenceTimeoutMs)
            } catch (throwable: Throwable) {
                if (throwable is kotlinx.coroutines.CancellationException) throw throwable
                startRequested.set(false)
                _state.value = State.Error(
                    throwable.message ?: "Could not start voice input.",
                )
            }
        }
    }

    /** Stops the active session (if any) and returns to [State.Idle]. */
    fun stop() {
        startRequested.set(false)
        stopWatchdog()
        val engine = recognizer.getAndSet(null)
        if (engine != null) {
            runCatching { engine.stopListening() }
            runCatching { engine.destroy() }
        }
        if (_state.value !is State.Error) _state.value = State.Idle
    }

    /** Full teardown — called when the host ViewModel is cleared. */
    fun shutdown() {
        stop()
    }

    // ── internals ──────────────────────────────────────────────────────────

    /**
     * The system SpeechRecognizer can only be created on the main thread;
     * a fresh instance is created per session because a destroyed
     * recognizer cannot be restarted.
     */
    private fun obtainRecognizer(): SpeechRecognizer {
        recognizer.get()?.let { existing ->
            runCatching { existing.destroy() }
        }
        val engine = SpeechRecognizer.createSpeechRecognizer(context)
        engine.setRecognitionListener(ArixRecognitionListener())
        recognizer.set(engine)
        return engine
    }

    private fun buildRecognizerIntent(): Intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
        putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
        putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
        // Follow the system locale — the system recognizer picks the right
        // language model on its own; no hard-coded locale.
        putExtra(RecognizerIntent.EXTRA_LANGUAGE, java.util.Locale.getDefault().toString())
        putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, context.packageName)
        // Use the system default (usually online) recognizer, not a forced
        // on-device one.
        putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, false)
    }

    private inner class ArixRecognitionListener : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) {
            lastSpeechActivityAt.set(System.currentTimeMillis())
        }

        override fun onBeginningOfSpeech() {
            lastSpeechActivityAt.set(System.currentTimeMillis())
        }

        override fun onRmsChanged(rmsdB: Float) = Unit

        override fun onBufferReceived(buffer: ByteArray?) = Unit

        override fun onEndOfSpeech() {
            // The recognizer is about to deliver the final result.
            lastSpeechActivityAt.set(System.currentTimeMillis())
        }

        override fun onError(error: Int) {
            startRequested.set(false)
            stopWatchdog()
            releaseSession()
            when (error) {
                SpeechRecognizer.ERROR_NO_MATCH,
                SpeechRecognizer.ERROR_SPEECH_TIMEOUT,
                SpeechRecognizer.ERROR_RECOGNIZER_BUSY,
                -> {
                    // "Nothing was said" is a normal outcome, not a failure —
                    // quietly return to Idle instead of scaring the user.
                    _state.value = State.Idle
                }
                SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> {
                    _state.value = State.Error("Microphone permission is required for voice input.")
                }
                SpeechRecognizer.ERROR_NETWORK -> {
                    _state.value = State.Error("Speech recognition network error. Check your connection.")
                }
                SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> {
                    _state.value = State.Idle
                }
                SpeechRecognizer.ERROR_CLIENT -> {
                    // Often fired when the session is cut short; treat as a
                    // clean stop so a mid-dictation tap never surfaces an error.
                    if (_state.value is State.Listening || _state.value is State.Partial) {
                        _state.value = State.Idle
                    }
                }
                else -> {
                    _state.value = State.Error(speechErrorMessage(error))
                }
            }
        }

        override fun onResults(results: Bundle?) {
            startRequested.set(false)
            stopWatchdog()
            releaseSession()
            val text = extractText(results)
            if (text.isNullOrBlank()) {
                _state.value = State.Idle
            } else {
                _state.value = State.Final(text)
            }
        }

        override fun onPartialResults(partialResults: Bundle?) {
            lastSpeechActivityAt.set(System.currentTimeMillis())
            val text = extractText(partialResults)
            if (!text.isNullOrBlank()) {
                _state.value = State.Partial(text)
            }
        }

        override fun onEvent(eventType: Int, params: Bundle?) = Unit
    }

    private fun releaseSession() {
        val engine = recognizer.getAndSet(null)
        if (engine != null) {
            runCatching { engine.stopListening() }
            runCatching { engine.destroy() }
        }
    }

    private fun extractText(bundle: Bundle?): String? {
        val matches = bundle?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION) ?: return null
        return matches.firstOrNull { it.isNotBlank() }?.trim()
    }

    private fun speechErrorMessage(error: Int): String = when (error) {
        SpeechRecognizer.ERROR_AUDIO -> "Audio recording error."
        SpeechRecognizer.ERROR_SERVER -> "Speech recognition server error."
        SpeechRecognizer.ERROR_SERVER_DISCONNECTED -> "Speech recognition service disconnected."
        SpeechRecognizer.ERROR_TOO_MANY_REQUESTS -> "Speech recognizer is busy. Try again in a moment."
        SpeechRecognizer.ERROR_LANGUAGE_NOT_SUPPORTED,
        SpeechRecognizer.ERROR_LANGUAGE_UNAVAILABLE,
        -> "The current system language is not supported by the speech recognizer."
        SpeechRecognizer.ERROR_CANNOT_CHECK_SUPPORT,
        SpeechRecognizer.ERROR_CANNOT_LISTEN_TO_DOWNLOAD_EVENTS,
        -> "Speech recognition is unavailable on this device."
        else -> "Speech recognition error ($error)."
    }

    /** v2.6.0: silence watchdog — stops the mic when the user has not spoken
     *  for [silenceTimeoutMs] (only armed when a positive timeout is given). */
    private fun startSilenceWatchdog(scope: CoroutineScope, silenceTimeoutMs: Long) {
        watchdogJob?.cancel()
        if (silenceTimeoutMs <= 0L) return
        watchdogJob = scope.launch {
            try {
                while (true) {
                    delay(SilenceWatchdogTickMs)
                    val state = _state.value
                    val listening = state is State.Listening || state is State.Partial
                    if (!listening) return@launch
                    val idleFor = System.currentTimeMillis() - lastSpeechActivityAt.get()
                    if (idleFor >= silenceTimeoutMs) {
                        stop()
                        return@launch
                    }
                }
            } catch (t: Throwable) {
                if (t is kotlinx.coroutines.CancellationException) throw t
            }
        }
    }

    private fun stopWatchdog() {
        watchdogJob?.cancel()
        watchdogJob = null
    }

    companion object {
        /** Watchdog polling interval. */
        private const val SilenceWatchdogTickMs = 400L

        /** Silence timeout used by the summoned assistant panel's auto-listen. */
        const val AssistantAutoStopSilenceMs = 10_000L
    }
}
