package com.arix.app.voice

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map

private val Context.voiceDataStore by preferencesDataStore(name = "arix_voice")

/**
 * v2.6.0: user-facing settings for the voice input stack.
 *
 * STT — the device's own system speech recognition service (Google /
 * Samsung / …). No model downloads and nothing bundled inside the APK.
 * The "Hey Arix" wake word, offline Vosk STT and offline Kokoro TTS were
 * removed in v2.6.0.
 */
data class ArixVoiceSettings(
    /** Voice input (system STT) is enabled in the composer. */
    val voiceInputEnabled: Boolean = true,
)

class ArixVoiceRepository(
    private val context: Context,
) {
    val settings: Flow<ArixVoiceSettings> = context.voiceDataStore.data.map { preferences ->
        ArixVoiceSettings(
            voiceInputEnabled = preferences[VOICE_INPUT_ENABLED] ?: true,
        )
    }

    suspend fun current(): ArixVoiceSettings = settings.first()

    suspend fun setVoiceInputEnabled(enabled: Boolean) {
        context.voiceDataStore.edit { it[VOICE_INPUT_ENABLED] = enabled }
    }

    private companion object {
        val VOICE_INPUT_ENABLED = booleanPreferencesKey("voice_input_enabled")
    }
}
