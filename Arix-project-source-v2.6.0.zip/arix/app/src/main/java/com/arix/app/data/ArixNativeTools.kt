package com.arix.app.data

import android.graphics.Bitmap
import android.graphics.Color
import java.io.ByteArrayOutputStream

/**
 * Client-side intent detection for the instant native tools (Anime
 * Explorer, QR Generator, and instant system commands). When the user's
 * message clearly asks for an anime list / search / watch, a QR code, or an
 * app/settings/URL open command, the app runs the tool natively and renders
 * the in-chat widget or result card IMMEDIATELY — no LLM round-trip, no raw
 * URLs, no delay, and no risk of the model merely *claiming* it opened
 * something.
 *
 * v2.5.2: the movie_explorer chat command was REMOVED (it scraped the
 * watchonlinemovies site, which is unreliable). Movie requests in chat now
 * flow to the LLM normally, and the dedicated Tools → “Watch Movies &
 * Series” screen (MovieBox/WeFeed API) is unaffected. anime_explorer is
 * unchanged.
 */
sealed interface ArixNativeIntent {
    val toolName: String

    data class AnimeList(val page: Int) : ArixNativeIntent {
        override val toolName: String = "anime_explorer"
    }

    data class AnimeSearch(val query: String) : ArixNativeIntent {
        override val toolName: String = "anime_explorer"
    }

    data class AnimeWatch(val query: String) : ArixNativeIntent {
        override val toolName: String = "anime_explorer"
    }

    data class QrCode(val data: String) : ArixNativeIntent {
        override val toolName: String = "qr_code"
    }

    /** "open youtube" / "launch whatsapp" — instant native app launch. */
    data class OpenApp(val target: String) : ArixNativeIntent {
        override val toolName: String = "system_control"
    }

    /** "open wifi settings" / "open bluetooth settings" — instant settings page. */
    data class OpenSettings(val page: String) : ArixNativeIntent {
        override val toolName: String = "system_control"
    }

    /** "open example.com" — instant URL open. */
    data class OpenUrl(val url: String) : ArixNativeIntent {
        override val toolName: String = "system_control"
    }

    companion object {
        private val latestWord = Regex("\\b(latest|new(est)?|recent|trending|now playing|just added)\\b", RegexOption.IGNORE_CASE)
        private val urlPattern = Regex("https?://\\S+", RegexOption.IGNORE_CASE)
        private val qrWord = Regex("\\b(qr|qrcode|qr[- ]?codes?)\\b", RegexOption.IGNORE_CASE)
        private val qrImperative = Regex(
            "^\\s*(please\\s+)?(can\\s+you\\s+)?(create|make|generate|give|get|show|draw|build|scan)\\s+" +
                "(me\\s+)?(a\\s+|an\\s+|the\\s+)?(qr(\\s?code)?|qrcode)\\b[\\s,:\\-\\u2013]*",
            RegexOption.IGNORE_CASE,
        )
        private val qrDirect = Regex(
            "^\\s*(qr(\\s?code)?|qrcode)\\s*[:\\-\\u2013]\\s*",
            RegexOption.IGNORE_CASE,
        )

        /* ------------------------------------------------------ anime */

        private val animeWord = Regex("\\banimes?\\b", RegexOption.IGNORE_CASE)
        private val animeSearchVerb = Regex("\\b(search|find|look\\s+(for|up))\\b", RegexOption.IGNORE_CASE)
        private val animeWatchVerb = Regex("\\b(watch|play|stream|open|show\\s+me)\\b", RegexOption.IGNORE_CASE)

        private fun animeMatch(value: String): ArixNativeIntent? {
            val lower = value.lowercase()
            val hasAnimeWord = animeWord.containsMatchIn(value)

            // "more anime" / "anime page 2"
            val pageMatch = Regex("\\bpage\\s*(\\d{1,2})\\b").find(lower)
            if (hasAnimeWord && (pageMatch != null || Regex("\\b(more|next)\\b").containsMatchIn(lower))) {
                val page = pageMatch?.groupValues?.get(1)?.toIntOrNull()?.coerceIn(1, 20) ?: 2
                return AnimeList(page)
            }
            if (!hasAnimeWord) return null

            val searchHit = animeSearchVerb.find(value)
            val watchHit = animeWatchVerb.find(value)
            val titleFrom = (searchHit ?: watchHit)?.range?.last?.plus(1) ?: -1
            val title = if (titleFrom in 1..value.length) {
                value.substring(titleFrom)
                    .replace(Regex("\\banime\\b", RegexOption.IGNORE_CASE), " ")
                    .replace(Regex("^(for|of|about|me)?\\s*"), "")
                    .replace(Regex("[?.!\\s]+$"), "")
                    .trim()
            } else {
                ""
            }

            if (searchHit != null && title.length >= 2) return AnimeSearch(title)
            if (watchHit != null && title.length >= 2) return AnimeWatch(title)

            if (latestWord.containsMatchIn(value) ||
                Regex("\\b(show|list|browse|ongoing|new\\s+episodes?)\\b", RegexOption.IGNORE_CASE).containsMatchIn(value)
            ) {
                return AnimeList(1)
            }
            return null
        }

        /* -------------------------------------------- system commands */

        private val openVerb = Regex(
            "^\\s*(please\\s+|can\\s+you\\s+|kindly\\s+)?(open|launch|start|go\\s+to|turn\\s+on)\\s+(the\\s+|my\\s+)?",
            RegexOption.IGNORE_CASE,
        )

        // Commands that must never be hijacked by the app opener.
        private val reservedTargets = listOf(
            "movie", "movies", "film", "anime", "qr", "code", "chat", "new",
            "settings", "url", "link", "website", "site", "page",
        )

        private val settingsTargets = mapOf(
            "settings" to "main",
            "wifi settings" to "wifi", "wi-fi settings" to "wifi", "wlan settings" to "wifi",
            "bluetooth settings" to "bluetooth", "bt settings" to "bluetooth",
            "display settings" to "display", "brightness settings" to "display", "screen settings" to "display",
            "battery settings" to "battery", "storage settings" to "storage",
            "location settings" to "location", "gps settings" to "location",
            "security settings" to "security", "privacy settings" to "privacy",
            "sound settings" to "sound", "volume settings" to "sound", "audio settings" to "sound",
            "notification settings" to "notifications", "notifications settings" to "notifications",
            "airplane settings" to "airplane", "airplane mode settings" to "airplane",
            "data usage settings" to "data_usage", "developer settings" to "developer",
            "developer options" to "developer", "about settings" to "about", "about phone settings" to "about",
            "accessibility settings" to "accessibility", "keyboard settings" to "keyboard",
            "language settings" to "language", "date settings" to "date", "time settings" to "date",
            "accounts settings" to "accounts", "account settings" to "accounts",
            "nfc settings" to "nfc", "cast settings" to "cast", "printing settings" to "print",
            "vpn settings" to "vpn",
        )

        private fun systemMatch(value: String): ArixNativeIntent? {
            // URL command: "open https://example.com"
            val url = urlPattern.find(value)?.value
            if (url != null && openVerb.containsMatchIn(value)) return OpenUrl(url)

            // System commands REQUIRE an explicit verb ("open", "launch", "go
            // to", "turn on"). Plain conversational messages ("hello",
            // "thanks", "good morning") must stay with the LLM.
            if (!openVerb.containsMatchIn(value)) return null

            val stripped = openVerb.replace(value, "").trim()
            if (stripped.isBlank()) return null
            val target = stripped
                .replace(Regex("\\s+(app|application|please|now)$", RegexOption.IGNORE_CASE), "")
                .replace(Regex("[.!?\\s]+$"), "")
                .trim()
            if (target.isBlank()) return null

            // Settings pages get their dedicated action.
            val settingsPage = settingsTargets[target.lowercase()]
            if (settingsPage != null) return OpenSettings(settingsPage)

            // "turn on wifi/bt/..." without "settings" still opens the page.
            if (value.contains(Regex("\\bturn\\s+on\\b", RegexOption.IGNORE_CASE))) {
                val toggle = mapOf(
                    "wifi" to "wifi", "wi-fi" to "wifi", "bluetooth" to "bluetooth", "bt" to "bluetooth",
                    "location" to "location", "gps" to "location", "nfc" to "nfc",
                )[target.lowercase()]
                if (toggle != null) return OpenSettings(toggle)
            }

            val words = target.split(Regex("\\s+"))
            if (words.size > 3) return null
            if (words.any { word -> word.lowercase() in reservedTargets }) return null
            if (target.length > 40) return null
            // Skip question-like phrasing ("do you know how to open ...").
            if (value.contains(Regex("\\b(what|how|why|which|when)\\b", RegexOption.IGNORE_CASE))) return null
            return OpenApp(target)
        }

        /** Returns the matched native intent, or null when the message should
         *  go to the LLM as a normal conversation turn. */
        fun match(text: String): ArixNativeIntent? {
            val value = text.trim()
            if (value.isEmpty()) return null

            qrMatch(value)?.let { return it }
            animeMatch(value)?.let { return it }
            return systemMatch(value)
        }

        private fun qrMatch(value: String): QrCode? {
            if (!qrWord.containsMatchIn(value)) return null
            // Only true QR commands: an imperative ("create a qr for X") or a
            // direct payload form ("QR code: X"). Questions about QR codes in
            // general stay with the LLM.
            val stripped = when {
                qrImperative.containsMatchIn(value) -> qrImperative.replace(value, "")
                    .replace(Regex("^(for|of|with|containing|to)\\s+", RegexOption.IGNORE_CASE), "")
                qrDirect.containsMatchIn(value) -> qrDirect.replace(value, "")
                    .replace(Regex("^(for|of|with)\\s+", RegexOption.IGNORE_CASE), "")
                else -> return null
            }
            var payload = stripped.trim()
            // Trailing filler like "please" / "thanks"
            payload = payload.replace(Regex("[.!?\\s]+$", RegexOption.IGNORE_CASE), "").trim()
            // Strip wrapping quotes
            if (payload.length >= 2 &&
                ((payload.startsWith("\"") && payload.endsWith("\"")) ||
                    (payload.startsWith("'") && payload.endsWith("'")))
            ) {
                payload = payload.substring(1, payload.length - 1).trim()
            }
            if (payload.isBlank()) return null
            if (payload.toByteArray(Charsets.UTF_8).size > 2300) return null
            return QrCode(payload)
        }
    }
}

/** Renders a QR matrix to a PNG with a quiet zone — 100% offline and instant. */
object ArixQrPng {
    fun render(
        matrix: ArixQrEncoder.QrMatrix,
        sizePx: Int = 512,
        quietZoneModules: Int = 4,
        darkColor: Int = 0xFF111111.toInt(),
        lightColor: Int = 0xFFFFFFFF.toInt(),
    ): ByteArray {
        val totalModules = matrix.size + quietZoneModules * 2
        val scale = (sizePx / totalModules).coerceAtLeast(1)
        val actualSize = scale * totalModules
        val bitmap = Bitmap.createBitmap(actualSize, actualSize, Bitmap.Config.RGB_565)
        bitmap.eraseColor(lightColor)
        val paint = android.graphics.Paint().apply { color = darkColor }
        val canvas = android.graphics.Canvas(bitmap)
        for (row in 0 until matrix.size) {
            for (col in 0 until matrix.size) {
                if (matrix.isDark(row, col)) {
                    val left = (col + quietZoneModules) * scale
                    val top = (row + quietZoneModules) * scale
                    canvas.drawRect(
                        left.toFloat(),
                        top.toFloat(),
                        (left + scale).toFloat(),
                        (top + scale).toFloat(),
                        paint,
                    )
                }
            }
        }
        val output = ByteArrayOutputStream()
        bitmap.compress(Bitmap.CompressFormat.PNG, 100, output)
        bitmap.recycle()
        return output.toByteArray()
    }

    /** Readable classification used on the generated card (mirrors the extension). */
    fun describeData(data: String): String {
        val value = data.trim()
        return when {
            Regex("^https?://", RegexOption.IGNORE_CASE).containsMatchIn(value) -> "Link"
            Regex("^WIFI:", RegexOption.IGNORE_CASE).containsMatchIn(value) -> "Wi-Fi"
            Regex("^mailto:", RegexOption.IGNORE_CASE).containsMatchIn(value) ||
                Regex("^[^\\s@]+@[^\\s@]+\\.[^\\s@]+$").matches(value) -> "Email"
            Regex("^tel:", RegexOption.IGNORE_CASE).containsMatchIn(value) -> "Phone"
            Regex("^(SMSTO|MECARD|BEGIN:VCARD)", RegexOption.IGNORE_CASE).containsMatchIn(value) -> "Contact"
            Regex("^geo:", RegexOption.IGNORE_CASE).containsMatchIn(value) -> "Location"
            Regex("^\\d+$").matches(value) -> "Number"
            else -> "Text"
        }
    }
}
