package com.arix.app.data

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.MultipartBody
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.IOException
import java.security.SecureRandom
import java.util.concurrent.TimeUnit

/**
 * ArixFileShareClient — the File Share tool backend (v2.4.0).
 *
 * Uploads any user-picked file to a free public host and returns a direct
 * download URL the user can copy or share. Four independent servers are
 * supported so one host being down (or blocking a network) never kills the
 * tool:
 *
 *  - Server 1 — Pixeldrain (pixeldrain.com/api/file, anonymous multipart)
 *  - Server 2 — Filebin.net (POST bin + PUT file, 6-day retention)
 *  - Server 3 — 0x0.st (multipart upload, 30–365 day retention)
 *  - Server 4 — Litterbox (litter.catbox.moe temp host, 72 h retention)
 *
 * Every upload streams straight from the content resolver into OkHttp's
 * request body (no full in-memory copies), so multi-hundred-MB files work
 * within ordinary heap limits. All methods perform blocking network IO —
 * call them from Dispatchers.IO.
 */
object ArixFileShareClient {

    /** Server ids, in the order the UI shows them. */
    const val ServerPixeldrain = "pixeldrain"
    const val ServerFilebin = "filebin"
    const val ServerZeroX0 = "0x0"
    const val ServerLitterbox = "litterbox"

    data class UploadResult(
        val url: String,
        val server: String,
        val fileName: String,
        val sizeBytes: Long,
    )

    private val random = SecureRandom()

    private val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(10, TimeUnit.MINUTES)
        .writeTimeout(10, TimeUnit.MINUTES)
        .followRedirects(true)
        .build()

    /* ------------------------------------------------------------- public */

    /** Human label for a server id ("Server 1 — Pixeldrain"). */
    fun serverLabel(serverId: String): String = when (serverId) {
        ServerPixeldrain -> "Server 1"
        ServerFilebin -> "Server 2"
        ServerZeroX0 -> "Server 3"
        ServerLitterbox -> "Server 4"
        else -> "Server"
    }

    /** Friendly host blurb shown under the server chips. */
    fun serverHint(serverId: String): String = when (serverId) {
        ServerPixeldrain -> "Pixeldrain · fast, generous limits"
        ServerFilebin -> "Filebin.net · 6-day availability"
        ServerZeroX0 -> "0x0.st · up to 512 MB, 30+ days"
        ServerLitterbox -> "Litterbox · 72-hour quick share"
        else -> ""
    }

    /**
     * Uploads the file behind [uri] to [server] and returns the direct
     * download URL. Throws [IOException] with a readable message on failure.
     */
    fun upload(context: Context, uri: Uri, server: String): UploadResult {
        val appContext = context.applicationContext
        val resolver = appContext.contentResolver
        val displayName = queryDisplayName(resolver, uri)
        val size = querySize(resolver, uri)
        val contentType = resolver.getType(uri) ?: "application/octet-stream"
        val mediaType = contentType.toMediaType()
        // Stream the file: RequestBody backed by the resolver's stream.
        val body = object : okhttp3.RequestBody() {
            override fun contentType() = mediaType
            override fun contentLength(): Long = size
            override fun writeTo(sink: okio.BufferedSink) {
                resolver.openInputStream(uri)?.use { input ->
                    val buffer = ByteArray(64 * 1024)
                    while (true) {
                        val read = input.read(buffer)
                        if (read < 0) break
                        sink.write(buffer, 0, read)
                    }
                } ?: throw IOException("The selected file could not be opened.")
            }
        }
        return when (server) {
            ServerPixeldrain -> uploadToPixeldrain(body, displayName, size)
            ServerFilebin -> uploadToFilebin(body, displayName, size)
            ServerZeroX0 -> uploadToZeroX0(body, displayName, size)
            ServerLitterbox -> uploadToLitterbox(body, displayName, size)
            else -> error("Unknown upload server.")
        }
    }

    /* ---------------------------------------------------------- providers */

    /**
     * Pixeldrain: POST https://pixeldrain.com/api/file (multipart "file").
     * Anonymous uploads; the direct link is
     * https://pixeldrain.com/api/file/<id>?download .
     */
    private fun uploadToPixeldrain(body: okhttp3.RequestBody, fileName: String, size: Long): UploadResult {
        val multipart = MultipartBody.Builder()
            .setType(MultipartBody.FORM)
            .addFormDataPart("file", fileName, body)
            .build()
        val request = Request.Builder()
            .url("https://pixeldrain.com/api/file")
            .header("User-Agent", ArixMediaApi.BrowserUserAgent)
            .post(multipart)
            .build()
        client.newCall(request).execute().use { response ->
            val text = response.body?.string().orEmpty()
            if (!response.isSuccessful) {
                // Pixeldrain occasionally gates anonymous uploads behind API
                // keys; surface a targeted message so the user can switch.
                if (response.code == 401 || text.contains("authentication_required", ignoreCase = true)) {
                    throw IOException("Pixeldrain currently requires an API key for uploads — try Server 2 or 3.")
                }
                throw IOException("Pixeldrain upload failed (HTTP ${response.code}). Try another server.")
            }
            val id = runCatching { JSONObject(text).optString("id") }.getOrDefault("")
            if (id.isBlank()) throw IOException("Pixeldrain did not return a file id. Try another server.")
            return UploadResult(
                url = "https://pixeldrain.com/api/file/$id?download",
                server = ServerPixeldrain,
                fileName = fileName,
                sizeBytes = size,
            )
        }
    }

    /**
     * Filebin.net: create a fresh random bin (POST), then PUT the file into
     * it. Download URL: https://filebin.net/<bin>/<file> (browsers and curl
     * both resolve it directly).
     */
    private fun uploadToFilebin(body: okhttp3.RequestBody, fileName: String, size: Long): UploadResult {
        val bin = randomBinId()
        // 1. Create the bin (safe to call even when it already exists).
        val createRequest = Request.Builder()
            .url("https://filebin.net/$bin")
            .header("User-Agent", ArixMediaApi.BrowserUserAgent)
            .header("Accept", "application/json")
            .post(ByteArray(0).toRequestBody(null))
            .build()
        runCatching {
            client.newCall(createRequest).execute().use { response ->
                response.body?.string()
            }
        }
        // 2. Upload the file bytes.
        val putRequest = Request.Builder()
            .url("https://filebin.net/$bin/${urlSafe(fileName)}")
            .header("User-Agent", ArixMediaApi.BrowserUserAgent)
            .header("Accept", applicationJson)
            .header("Content-Type", "application/octet-stream")
            .put(body)
            .build()
        client.newCall(putRequest).execute().use { response ->
            val text = response.body?.string().orEmpty()
            if (!response.isSuccessful) {
                throw IOException("Filebin upload failed (HTTP ${response.code}). Try another server.")
            }
            val filename = runCatching {
                JSONObject(text).optJSONObject("file")?.optString("filename").orEmpty()
            }.getOrDefault("")
            val finalName = filename.takeIf { it.isNotBlank() } ?: fileName
            return UploadResult(
                url = "https://filebin.net/$bin/${urlSafe(finalName)}",
                server = ServerFilebin,
                fileName = finalName,
                sizeBytes = size,
            )
        }
    }

    /**
     * 0x0.st: POST multipart "file"; the plain-text response body is the URL.
     * Some datacenter IPs are blocked — the error message points at the other
     * servers when that happens.
     */
    private fun uploadToZeroX0(body: okhttp3.RequestBody, fileName: String, size: Long): UploadResult {
        val multipart = MultipartBody.Builder()
            .setType(MultipartBody.FORM)
            .addFormDataPart("file", fileName, body)
            .build()
        val request = Request.Builder()
            .url("https://0x0.st")
            .header("User-Agent", "ArixFileShare/2.4 (Android; file sharing tool)")
            .post(multipart)
            .build()
        client.newCall(request).execute().use { response ->
            val text = response.body?.string()?.trim().orEmpty()
            if (!response.isSuccessful || !text.startsWith("http")) {
                throw IOException("0x0.st is not reachable from this network (HTTP ${response.code}). Try another server.")
            }
            return UploadResult(
                url = text.substringBefore('\n'),
                server = ServerZeroX0,
                fileName = fileName,
                sizeBytes = size,
            )
        }
    }

    /**
     * Litterbox (temp catbox): POST multipart reqtype=fileupload + time=72h;
     * the plain-text response is the direct link.
     */
    private fun uploadToLitterbox(body: okhttp3.RequestBody, fileName: String, size: Long): UploadResult {
        val multipart = MultipartBody.Builder()
            .setType(MultipartBody.FORM)
            .addFormDataPart("reqtype", "fileupload")
            .addFormDataPart("time", "72h")
            .addFormDataPart("fileToUpload", fileName, body)
            .build()
        val request = Request.Builder()
            .url("https://litterbox.catbox.moe/resources/internals/api.php")
            .header("User-Agent", ArixMediaApi.BrowserUserAgent)
            .post(multipart)
            .build()
        client.newCall(request).execute().use { response ->
            val text = response.body?.string()?.trim().orEmpty()
            if (!response.isSuccessful || !text.startsWith("http")) {
                throw IOException("Litterbox upload failed (HTTP ${response.code}). Try another server.")
            }
            return UploadResult(
                url = text.substringBefore('\n'),
                server = ServerLitterbox,
                fileName = fileName,
                sizeBytes = size,
            )
        }
    }

    /* -------------------------------------------------------------- utils */

    private const val applicationJson = "application/json"
    private val BinChars = "abcdefghjkmnpqrstuvwxyz23456789"

    private fun randomBinId(): String {
        val sb = StringBuilder("arix")
        repeat(14) {
            sb.append(BinChars[random.nextInt(BinChars.length)])
        }
        return sb.toString()
    }

    private fun urlSafe(name: String): String =
        name.replace(Regex("[^A-Za-z0-9._ ()-]"), "_").take(120).ifBlank { "file.bin" }

    private fun queryDisplayName(
        resolver: android.content.ContentResolver,
        uri: Uri,
    ): String = runCatching {
        resolver.query(uri, null, null, null, null)?.use { cursor ->
            if (cursor.moveToFirst()) {
                val index = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (index >= 0) cursor.getString(index) else null
            } else {
                null
            }
        }
    }.getOrNull()
        ?: uri.lastPathSegment?.substringAfterLast('/')?.substringAfter(':')
        ?: "arix-${System.currentTimeMillis()}.bin"

    private fun querySize(
        resolver: android.content.ContentResolver,
        uri: Uri,
    ): Long = runCatching {
        resolver.query(uri, null, null, null, null)?.use { cursor ->
            if (cursor.moveToFirst()) {
                val index = cursor.getColumnIndex(OpenableColumns.SIZE)
                if (index >= 0) cursor.getLong(index).takeIf { it > 0 } else null
            } else {
                null
            }
        }
    }.getOrNull() ?: -1L

    /** Formats a byte count for the result card. */
    fun formatBytes(bytes: Long): String {
        if (bytes <= 0) return "unknown size"
        val kb = bytes / 1024.0
        val mb = kb / 1024.0
        val gb = mb / 1024.0
        return when {
            gb >= 1 -> "%.2f GB".format(gb)
            mb >= 1 -> "%.1f MB".format(mb)
            kb >= 1 -> "%.0f KB".format(kb)
            else -> "$bytes B"
        }
    }
}
