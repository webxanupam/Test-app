package com.arix.app.data

import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/**
 * ArixMovieBoxClient — native Kotlin port of the MovieBox / WeFeed H5 BFF
 * client (h5-api.aoneroom.com). Mirrors the reference JS implementation:
 *
 *  - `home` is called lazily to seed the bearer token (refreshed from the
 *    `x-user` response header on every request).
 *  - Requests emulate the themoviebox.xyz web client (mobile Chromium UA,
 *    id locale, Makassar timezone).
 *  - Responses may use camelCase or snake_case keys depending on the endpoint,
 *    so every field read goes through dual-key fallbacks.
 *
 * All methods perform blocking network IO — call them from Dispatchers.IO
 * (the same contract as MovieSiteClient / ArixAnimeSiteClient).
 */
object ArixMovieBoxClient {

    private const val BaseUrl = "https://h5-api.aoneroom.com/wefeed-h5api-bff"
    private const val PlayBaseUrl = "https://themoviebox.xyz/wefeed-h5api-bff"

    private val JsonMediaType = "application/json; charset=utf-8".toMediaType()

    private val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(20, TimeUnit.SECONDS)
        .followRedirects(true)
        .build()

    @Volatile
    private var token: String? = null

    /* ------------------------------------------------------------- models */

    data class Subject(
        val subjectId: String = "",
        val title: String = "",
        val coverUrl: String = "",
        val detailPath: String = "",
        val description: String = "",
        val subjectType: Int = 0, // 0 movie, 1 series (per WeFeed convention)
        val rating: Double = 0.0,
        val year: String = "",
        val genre: String = "",
        val itemTitle: String = "", // episode label when nested inside a subject
    )

    data class Episode(
        val subjectId: String = "",
        val title: String = "",
        val season: Int = 0,
        val episode: Int = 0,
        val detailPath: String = "",
        val numberLabel: String = "",
    )

    data class PlaySource(
        val url: String = "",
        val quality: String = "",
        val format: String = "",
        val lineLabel: String = "",
    )

    data class Caption(
        val id: String = "",
        val language: String = "",
        val format: String = "",
        val url: String = "",
        val title: String = "",
    )

    data class DownloadLink(
        val url: String = "",
        val quality: String = "",
        val label: String = "",
        val sizeBytes: Long = 0L,
    )

    data class HomeSection(
        val title: String = "",
        val items: List<Subject> = emptyList(),
    )

    data class Home(
        val sections: List<HomeSection> = emptyList(),
        val trendingTabs: List<String> = emptyList(),
    )

    data class Detail(
        val subject: Subject = Subject(),
        val episodes: List<Episode> = emptyList(),
        val recommendations: List<Subject> = emptyList(),
        val captions: List<Caption> = emptyList(),
    )

    /* -------------------------------------------------------------- http */

    private fun headers(authorize: Boolean = true): JSONObject {
        val host = "themoviebox.xyz"
        val headers = JSONObject()
        headers.put("accept", "application/json")
        headers.put("accept-language", "id-ID")
        if (authorize) headers.put("authorization", "Bearer ${token.orEmpty()}")
        headers.put("cache-control", "no-cache")
        headers.put("content-type", "application/json")
        headers.put("origin", "https://$host")
        headers.put("pragma", "no-cache")
        headers.put("referer", "https://$host/")
        headers.put(
            "user-agent",
            "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Mobile Safari/537.36",
        )
        headers.put("x-client-info", JSONObject().put("timezone", "Asia/Makassar").toString())
        headers.put("x-request-lang", "id")
        return headers
    }

    private fun buildRequest(
        method: String,
        url: String,
        query: Map<String, String> = emptyMap(),
        body: JSONObject? = null,
        authorize: Boolean = true,
        extraHeaders: JSONObject = JSONObject(),
    ): Request {
        val headerSpec = headers(authorize)
        val headerKeys = extraHeaders.keys()
        while (headerKeys.hasNext()) {
            val key = headerKeys.next()
            headerSpec.put(key, extraHeaders.opt(key))
        }
        var target = url
        if (query.isNotEmpty()) {
            val separator = if (target.contains('?')) '&' else '?'
            target += separator + query.entries.joinToString("&") { (k, v) ->
                "${android.net.Uri.encode(k)}=${android.net.Uri.encode(v)}"
            }
        }
        val builder = Request.Builder().url(target)
        val keys = headerSpec.keys()
        while (keys.hasNext()) {
            val key = keys.next()
            val value = headerSpec.optString(key)
            if (value == "\u0000REMOVE") continue
            builder.header(key, value)
        }
        when (method.uppercase()) {
            "POST" -> builder.post((body ?: JSONObject()).toString().toRequestBody(JsonMediaType))
            else -> builder.get()
        }
        return builder.build()
    }

    /** Executes a request, refreshing the token from the x-user header. */
    private fun execute(request: Request): JSONObject {
        client.newCall(request).execute().use { response ->
            val bodyText = response.body?.string().orEmpty()
            response.header("x-user")?.let { xUser ->
                runCatching {
                    val parsed = JSONObject(xUser)
                    parsed.optString("token").takeIf { it.isNotBlank() }?.let { token = it }
                }
            }
            if (bodyText.isBlank()) {
                error("MovieBox returned an empty response (HTTP ${response.code}).")
            }
            return runCatching { JSONObject(bodyText) }
                .getOrElse { error("MovieBox returned invalid JSON (HTTP ${response.code}).") }
        }
    }

    /** Blocking token seed — mirrors the JS client's lazy home() bootstrap. */
    private fun ensureTokenSeeded() {
        if (token.isNullOrBlank()) {
            runCatching { home() }
        }
    }

    private fun dataObject(response: JSONObject): JSONObject {
        // Some endpoints wrap in { code, message, data }, others return fields directly.
        return response.optJSONObject("data") ?: response
    }

    /* --------------------------------------------------------- endpoints */

    /** Featured / recommended home content. Also seeds the auth token. */
    fun home(): Home {
        val response = execute(
            buildRequest(
                "GET",
                "$BaseUrl/home",
                query = mapOf("host" to "themoviebox.xyz"),
                authorize = false,
            ),
        )
        val sections = mutableListOf<HomeSection>()
        val data = dataObject(response)
        // WeFeed home surfaces named content blocks; collect every array of
        // subject-shaped objects as a section.
        val keys = data.keys()
        while (keys.hasNext()) {
            val key = keys.next()
            val array = data.optJSONArray(key) ?: continue
            val items = parseSubjects(array)
            if (items.isNotEmpty()) {
                sections.add(HomeSection(title = prettifyKey(key), items = items.take(24)))
            }
        }
        data.optJSONObject("subject_list_info")?.optJSONArray("list")?.let { array ->
            val items = parseSubjects(array)
            if (items.isNotEmpty()) sections.add(0, HomeSection("Featured", items.take(24)))
        }
        val trendingTabs = mutableListOf<String>()
        data.optJSONArray("tab_list")?.let { tabs ->
            for (i in 0 until tabs.length()) {
                tabs.optJSONObject(i)?.optStringAny("tab_id", "tabId")?.takeIf { it.isNotBlank() }
                    ?.let(trendingTabs::add)
            }
        }
        return Home(sections = sections, trendingTabs = trendingTabs)
    }

    /** Keyword search over movies and series. */
    fun search(
        keyword: String,
        page: Int = 1,
        perPage: Int = 24,
    ): List<Subject> {
        if (keyword.isBlank()) return emptyList()
        ensureTokenSeeded()
        val body = JSONObject()
            .put("keyword", keyword)
            .put("page", page)
            .put("per_page", perPage)
            .put("subject_type", 0)
        val response = execute(
            buildRequest(
                "POST",
                "$BaseUrl/subject/search",
                body = body,
                extraHeaders = JSONObject().put("authorization", "Bearer ${token.orEmpty()}"),
            ),
        )
        return parseSubjects(findSubjectArray(dataObject(response)))
    }

    /** Trending content with pagination. */
    fun trending(
        tabId: String? = null,
        page: Int = 1,
        perPage: Int = 18,
    ): List<Subject> {
        ensureTokenSeeded()
        val query = buildMap {
            put("page", page.toString())
            put("per_page", perPage.toString())
            tabId?.takeIf { it.isNotBlank() }?.let { put("tab_id", it) }
        }
        val response = execute(
            buildRequest("GET", "$BaseUrl/subject/trending", query = query),
        )
        return parseSubjects(findSubjectArray(dataObject(response)))
    }

    /** Bottom tab list (categories). */
    fun tabs(): List<Pair<String, String>> {
        val response = execute(buildRequest("GET", "$BaseUrl/tab/get-bottom-tab-list"))
        val data = dataObject(response)
        val result = mutableListOf<Pair<String, String>>()
        val arrays = listOf(data.optJSONArray("list"), data.optJSONArray("tabs"), data as? JSONArray)
        arrays.firstOrNull { it != null && it.length() > 0 }?.let { array ->
            for (i in 0 until array.length()) {
                val entry = array.optJSONObject(i) ?: continue
                val id = entry.optStringAny("tab_id", "tabId")
                    .ifBlank { entry.optString("id") }
                val name = entry.optStringAny("tab_name", "tabName")
                    .ifBlank { entry.optString("name") }
                if (id.isNotBlank()) result.add(id to name.ifBlank { id })
            }
        }
        return result
    }

    /** Related / recommended subjects for a subject. */
    fun detailRec(subjectId: String, page: Int = 1): List<Subject> {
        val response = execute(
            buildRequest(
                "GET",
                "$BaseUrl/subject/detail-rec",
                query = mapOf(
                    "subject_id" to subjectId,
                    "page" to page.toString(),
                    "per_page" to "12",
                ),
            ),
        )
        return parseSubjects(findSubjectArray(dataObject(response)))
    }

    /** Full detail: subject info + episodes (series) + captions. */
    fun detail(detailPath: String): Detail {
        val extra = JSONObject()
        extra.put("authorization", "\u0000REMOVE")
        extra.put("x-request-lang", "\u0000REMOVE")
        val response = execute(
            buildRequest(
                "GET",
                "$BaseUrl/detail",
                query = mapOf("detail_path" to detailPath),
                authorize = false,
                extraHeaders = extra,
            ),
        )
        val data = dataObject(response)
        val subjectJson = data.optJSONObject("subject") ?: data
        val subject = parseSubject(subjectJson, detailPathFallback = detailPath)
        val episodes = mutableListOf<Episode>()
        data.optJSONArray("episode_list")?.let { list ->
            for (i in 0 until list.length()) {
                val entry = list.optJSONObject(i) ?: continue
                val item = entry.optJSONObject("item") ?: entry
                episodes.add(
                    Episode(
                        subjectId = item.optStringAny("subject_id", "subjectId")
                            .ifBlank { subject.subjectId },
                        title = item.optStringAny("title", "name")
                            .ifBlank { entry.optStringAny("title", "name") },
                        season = item.optIntAny("se", "season"),
                        episode = item.optIntAny("ep", "episode", "number"),
                        detailPath = item.optStringAny("detail_path", "detailPath")
                            .ifBlank { detailPath },
                        numberLabel = item.optStringAny("number", "number_label"),
                    ),
                )
            }
        }
        val captions = mutableListOf<Caption>()
        data.optJSONArray("caption_list")?.let { list ->
            for (i in 0 until list.length()) {
                val entry = list.optJSONObject(i) ?: continue
                val caption = Caption(
                    id = entry.optStringAny("caption_id", "id")
                        .ifBlank { entry.optString("id") },
                    language = entry.optStringAny("language", "lang")
                        .ifBlank { entry.optStringAny("language_name", "name") },
                    format = entry.optString("format").ifBlank { "MP4" },
                    url = entry.optStringAny("url", "caption_url"),
                    title = entry.optString("title"),
                )
                if (caption.id.isNotBlank()) captions.add(caption)
            }
        }
        return Detail(
            subject = subject,
            episodes = episodes.sortedWith(compareBy({ it.season }, { it.episode })),
            recommendations = emptyList(),
            captions = captions,
        )
    }

    /** Playable stream info for a movie or specific series episode. */
    fun play(
        subjectId: String,
        detailPath: String,
        season: Int = 0,
        episode: Int = 0,
    ): List<PlaySource> {
        val extra = JSONObject()
        extra.put("authorization", "\u0000REMOVE")
        extra.put("x-request-lang", "\u0000REMOVE")
        extra.put("sec-fetch-site", "same-origin")
        extra.put("x-source", "")
        val response = execute(
            buildRequest(
                "GET",
                "$PlayBaseUrl/subject/play",
                query = mapOf(
                    "subject_id" to subjectId,
                    "se" to season.toString(),
                    "ep" to episode.toString(),
                    "detail_path" to detailPath,
                    "stream_sign_type" to "1",
                ),
                authorize = false,
                extraHeaders = extra,
            ),
        )
        val data = dataObject(response)
        val sources = mutableListOf<PlaySource>()
        // Primary: direct url field.
        data.optStringAny("url", "play_url", "playUrl").takeIf { it.isNotBlank() }?.let { raw ->
            sources.add(PlaySource(url = normalize(raw)))
        }
        // Alternative: nested line / codec lists.
        val listArrays = listOf(
            data.optJSONArray("url_list"),
            data.optJSONArray("play_list"),
            data.optJSONArray("list"),
            data.optJSONObject("play_info")?.optJSONArray("list"),
        )
        listArrays.filterNotNull().forEach { array ->
            for (i in 0 until array.length()) {
                val entry = array.optJSONObject(i) ?: continue
                val url = entry.optStringAny("url", "play_url", "playUrl")
                if (url.isBlank()) continue
                sources.add(
                    PlaySource(
                        url = normalize(url),
                        quality = entry.optStringAny("quality", "definition"),
                        format = entry.optString("format"),
                        lineLabel = entry.optStringAny("line", "name", "label"),
                    ),
                )
            }
        }
        return sources.distinctBy { it.url }
    }

    /** Subtitle/caption payload for an id (returns raw URL when provided). */
    fun captionUrl(
        id: String,
        subjectId: String,
        detailPath: String,
        format: String = "MP4",
    ): String {
        val extra = JSONObject()
        extra.put("authorization", "\u0000REMOVE")
        extra.put("x-request-lang", "\u0000REMOVE")
        val response = execute(
            buildRequest(
                "GET",
                "$BaseUrl/subject/caption",
                query = mapOf(
                    "format" to format,
                    "id" to id,
                    "subject_id" to subjectId,
                    "detail_path" to detailPath,
                ),
                authorize = false,
                extraHeaders = extra,
            ),
        )
        val data = dataObject(response)
        return data.optStringAny("url", "caption_url", "captionUrl")
    }

    /** Download sources when the API exposes them. */
    fun download(
        subjectId: String,
        detailPath: String,
        season: Int = 0,
        episode: Int = 0,
    ): List<DownloadLink> {
        ensureTokenSeeded()
        val response = execute(
            buildRequest(
                "GET",
                "$BaseUrl/subject/download",
                query = mapOf(
                    "subject_id" to subjectId,
                    "se" to season.toString(),
                    "ep" to episode.toString(),
                    "detail_path" to detailPath,
                ),
            ),
        )
        val data = dataObject(response)
        val result = mutableListOf<DownloadLink>()
        val arrays = listOf(
            data.optJSONArray("list"),
            data.optJSONArray("download_list"),
            data.optJSONArray("url_list"),
        )
        arrays.filterNotNull().forEach { array ->
            for (i in 0 until array.length()) {
                val entry = array.optJSONObject(i) ?: continue
                val url = entry.optStringAny("url", "download_url", "downloadUrl")
                if (url.isBlank()) continue
                result.add(
                    DownloadLink(
                        url = normalize(url),
                        quality = entry.optStringAny("quality", "definition"),
                        label = entry.optStringAny("label", "name", "title"),
                        sizeBytes = entry.optLongAny("size", "file_size"),
                    ),
                )
            }
        }
        return result.distinctBy { it.url }
    }

    /* -------------------------------------------------------------- parse */

    private fun findSubjectArray(data: JSONObject): JSONArray {
        data.optJSONArray("list")?.let { if (it.length() > 0) return it }
        data.optJSONObject("subject_list_info")?.optJSONArray("list")?.let { return it }
        data.optJSONArray("subject_list")?.let { return it }
        data.optJSONArray("subjects")?.let { return it }
        data.keys().asSequence().forEach { key ->
            data.optJSONArray(key)?.let { array ->
                if (array.length() > 0 && array.optJSONObject(0)?.hasAny(
                        "subject_id", "subjectId", "detail_path", "detailPath",
                    ) == true
                ) {
                    return array
                }
            }
        }
        return JSONArray()
    }

    private fun parseSubjects(array: JSONArray): List<Subject> {
        val result = mutableListOf<Subject>()
        for (i in 0 until array.length()) {
            val entry = array.optJSONObject(i) ?: continue
            // Nested { item: {...} } wrappers appear in trending lists.
            val item = entry.optJSONObject("item") ?: entry
            val subject = parseSubject(item)
            if (subject.title.isNotBlank() || subject.subjectId.isNotBlank()) {
                val withWrapperTitle = if (subject.title.isBlank()) {
                    subject.copy(title = entry.optStringAny("title", "name"))
                } else {
                    subject
                }
                result.add(withWrapperTitle)
            }
        }
        return result
    }

    private fun parseSubject(
        json: JSONObject,
        detailPathFallback: String = "",
    ): Subject {
        val cover = json.optStringAny("cover_url", "coverUrl", "cover", "poster", "image")
            .ifBlank {
                json.optJSONObject("cover")?.optStringAny("url", "default") ?: ""
            }
        return Subject(
            subjectId = json.optStringAny("subject_id", "subjectId", "id"),
            title = json.optStringAny("title", "name"),
            coverUrl = cover,
            detailPath = json.optStringAny("detail_path", "detailPath").ifBlank { detailPathFallback },
            description = json.optStringAny("description", "desc", "brief"),
            subjectType = json.optIntAny("subject_type", "subjectType", "type"),
            rating = json.optDoubleAny("rating", "score", "douban_score"),
            year = json.optStringAny("year", "release_year", "releaseYear"),
            genre = json.optStringAny("genre", "genres", "type_name"),
        )
    }

    private fun normalize(raw: String): String {
        val value = raw.trim()
        return if (value.startsWith("//")) "https:$value" else value
    }

    private fun prettifyKey(key: String): String =
        key.replace('_', ' ').replaceFirstChar { it.uppercase() }

    /* ------------------------------------------------- JSONObject helpers */

    private fun JSONObject.optStringAny(vararg keys: String): String {
        for (key in keys) {
            val value = optString(key, "")
            if (value.isNotBlank() && value != "null") return value
        }
        return ""
    }

    private fun JSONObject.optIntAny(vararg keys: String): Int {
        for (key in keys) {
            if (has(key)) optInt(key).let { if (it != 0) return it }
        }
        return 0
    }

    private fun JSONObject.optDoubleAny(vararg keys: String): Double {
        for (key in keys) {
            if (has(key)) optDouble(key).let { if (it != 0.0) return it }
        }
        return 0.0
    }

    private fun JSONObject.optLongAny(vararg keys: String): Long {
        for (key in keys) {
            if (has(key)) return optLong(key)
        }
        return 0L
    }

    private fun JSONObject.hasAny(vararg keys: String): Boolean {
        for (key in keys) {
            if (has(key)) return true
        }
        return false
    }
}
