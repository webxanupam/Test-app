package com.arix.app.data

import org.json.JSONArray
import org.json.JSONObject

/**
 * Anime Explorer data layer (v2.2.7).
 *
 * Two sources:
 *  - animelok.live  — a Next.js site. Listings are server-rendered RSC
 *    flight payloads (poster + slug + title inside `self.__next_f.push`
 *    scripts); episodes and per-episode stream servers come from its clean
 *    JSON API (`/api/anime/<slug>/episodes/<n>` returns servers with direct
 *    .m3u8 links or short.icu embeds). No HTML scraping needed for playback.
 *  - animesalt.cx (animesalt.ac redirects there) — a WordPress site. Search
 *    via `?s=`, series pages list `/episode/<slug>-SxEy/` links, and episode
 *    pages carry a direct `as-cdn*.top` iframe plus a base64-encoded
 *    multi-language player payload (language -> short.icu link).
 *
 * All requests go through [ArixMediaApi] (direct-first + validated + cached)
 * so listings render instantly and dead proxies can never poison a result.
 */
object ArixAnimeSiteClient {

    const val SourceAnimeLok = "animelok"
    const val SourceAnimeSalt = "animesalt"

    /* ------------------------------------------------------------ models */

    data class AnimeItem(
        val title: String,
        val url: String, // site detail page URL (or animelok:/slug pseudo URL)
        val thumbnail: String,
        val source: String,
        val meta: String = "",
    )

    data class AnimeEpisode(
        val number: Int,
        val name: String,
        val url: String, // episode page URL or animelok slug#ep marker
    )

    data class AnimeServer(
        val label: String,
        val language: String,
        val url: String,
    )

    data class AnimeDetail(
        val title: String,
        val source: String,
        val url: String,
        val thumbnail: String,
        val description: String,
        val episodes: List<AnimeEpisode>,
    )

    data class AnimeEpisodeServers(
        val title: String,
        val source: String,
        val episodeNumber: Int,
        val episodeName: String,
        val servers: List<AnimeServer>,
        val languages: List<String>,
    )

    /* -------------------------------------------------- AnimeLok listings */

    /**
     * Parses the Next.js RSC flight payload of an AnimeLok listing page.
     * Card shape (verified live):
     *   {"href":"/anime/<hash>","className":"w-full flex flex-col group gap-2...",
     *    "children":[["$","$L49",null,{"slug":"one-piece-21"}],
     *                ["$","div",...,["$","$L4",null,{"src":"<poster>","alt":"<title>",...
     */
    private fun parseAnimeLokCards(html: String): List<AnimeItem> {
        val items = mutableListOf<AnimeItem>()
        val seen = mutableSetOf<String>()
        // Extract the RSC flight payload with a manual scanner. The old
        // regex `self\.__next_f\.push\(\[1,"((?:[^"\\]|\\.)*)"\]\)` recursed
        // per character and threw StackOverflowError on the real 380KB
        // /ongoing page, which silently degraded every AnimeLok listing.
        val flight = StringBuilder()
        val pushMarker = "self.__next_f.push([1,\""
        var cursor = html.indexOf(pushMarker)
        while (cursor >= 0) {
            var index = cursor + pushMarker.length
            while (index < html.length) {
                val ch = html[index]
                if (ch == '\\' && index + 1 < html.length) {
                    flight.append(ch).append(html[index + 1])
                    index += 2
                    continue
                }
                if (ch == '"') break
                flight.append(ch)
                index += 1
            }
            cursor = html.indexOf(pushMarker, index.coerceAtLeast(cursor + pushMarker.length))
        }
        val flightText = flight.toString()
            .replace("\\\"", "\"")
            .replace("\\\\", "\\")
            .replace("\\n", " ")
        val cardRegex = Regex(
            "\"href\":\"(/anime/[^\"]+)\"[\\s\\S]{0,400}?\"slug\":\"([^\"]+)\"[\\s\\S]{0,900}?\"src\":\"(https?://[^\"]+)\"[\\s\\S]{0,200}?\"alt\":\"([^\"]*)\"",
        )
        cardRegex.findAll(flightText).forEach { match ->
            val slug = match.groupValues[2]
            if (slug.isBlank() || !seen.add(slug)) return@forEach
            val title = ArixMediaApi.decodeEntities(match.groupValues[4])
            if (title.isBlank()) return@forEach
            items.add(
                AnimeItem(
                    title = title,
                    url = "$SourceAnimeLok:$slug",
                    thumbnail = ArixMediaApi.normalizeUrl(match.groupValues[3]),
                    source = SourceAnimeLok,
                ),
            )
        }
        // Server-rendered fallback: <a href="/anime/slug"> … <img alt="Title" src="…">
        if (items.isEmpty()) {
            val fallback = Regex(
                "href=\"(/anime/[^\"]+)\"[\\s\\S]{0,800}?<img[^>]+alt=\"([^\"]{2,80})\"[\\s\\S]{0,400}?(?:data-src|src)=\"(https?://[^\"]+)\"",
                RegexOption.IGNORE_CASE,
            )
            fallback.findAll(html).forEach { match ->
                val href = match.groupValues[1]
                val slug = href.substringAfterLast('/')
                if (!seen.add(slug)) return@forEach
                items.add(
                    AnimeItem(
                        title = ArixMediaApi.decodeEntities(match.groupValues[2]),
                        url = "$SourceAnimeLok:$slug",
                        thumbnail = ArixMediaApi.normalizeUrl(match.groupValues[3]),
                        source = SourceAnimeLok,
                    ),
                )
            }
        }
        return items
    }

    fun animeLokLatest(page: Int = 1, limit: Int = 24): List<AnimeItem> {
        val normalized = page.coerceIn(1, 30)
        val url = if (normalized <= 1) {
            "${ArixMediaApi.AnimeLokBase}/ongoing"
        } else {
            "${ArixMediaApi.AnimeLokBase}/ongoing?page=$normalized"
        }
        return ArixMediaApi.fetchCachedJson(url, ArixMediaApi.Kind.ANIME_LIST) {
            ArixMediaApi.fetchPage(url, ArixMediaApi.Kind.ANIME_LIST)
        }.let(::parseAnimeLokCards).take(limit)
    }

    fun animeLokLatestEpisodes(limit: Int = 24): List<AnimeItem> {
        val url = "${ArixMediaApi.AnimeLokBase}/latest-episode"
        return ArixMediaApi.fetchCachedJson(url, ArixMediaApi.Kind.ANIME_LIST) {
            ArixMediaApi.fetchPage(url, ArixMediaApi.Kind.ANIME_LIST)
        }.let(::parseAnimeLokCards).take(limit)
    }

    fun animeLokSearch(query: String, limit: Int = 24): List<AnimeItem> {
        val url = "${ArixMediaApi.AnimeLokBase}/search?keyword=" +
            android.net.Uri.encode(query)
        return ArixMediaApi.fetchCachedJson(url, ArixMediaApi.Kind.ANIME_LIST) {
            ArixMediaApi.fetchPage(url, ArixMediaApi.Kind.ANIME_LIST)
        }.let(::parseAnimeLokCards).take(limit)
    }

    /* ------------------------------------------------- AnimeLok playback */

    /** Episode list for an AnimeLok slug via the site's JSON API. */
    private fun animeLokEpisodes(slug: String): List<AnimeEpisode> {
        val episodes = mutableListOf<AnimeEpisode>()
        var page = 0 // the API's page index is 0-based: page=0 → episodes 1..50
        while (page < 8) { // hard cap: 8 pages x 50 = 400 episodes
            val url = "${ArixMediaApi.AnimeLokBase}/api/anime/$slug/episodes-range?page=$page&pageSize=50"
            val body = runCatching {
                ArixMediaApi.fetchCachedJson(url, ArixMediaApi.Kind.JSON, ttl = 10 * 60 * 1000L) {
                    ArixMediaApi.fetchJson(url)
                }
            }.getOrNull() ?: break
            val payload = runCatching { JSONObject(body) }.getOrNull() ?: break
            val array = payload.optJSONArray("episodes") ?: break
            for (index in 0 until array.length()) {
                val entry = array.optJSONObject(index) ?: continue
                val number = entry.optInt("number", 0)
                if (number <= 0) continue
                episodes.add(
                    AnimeEpisode(
                        number = number,
                        name = entry.optString("name"),
                        url = "$SourceAnimeLok:$slug#$number",
                    ),
                )
            }
            val totalPages = payload.optInt("totalPages", page + 1)
            if (page + 1 >= totalPages || array.length() == 0) break
            page += 1
        }
        episodes.sortBy { it.number }
        return episodes.distinctBy { it.number }
    }

    /** Stream servers for one AnimeLok episode via the site's JSON API. */
    private fun animeLokEpisodeServers(slug: String, episode: Int): AnimeEpisodeServers? {
        val url = "${ArixMediaApi.AnimeLokBase}/api/anime/$slug/episodes/$episode"
        val body = runCatching {
            ArixMediaApi.fetchCachedJson(url, ArixMediaApi.Kind.JSON, ttl = 30 * 60 * 1000L) {
                ArixMediaApi.fetchJson(url)
            }
        }.getOrNull() ?: return null
        val payload = runCatching { JSONObject(body) }.getOrNull() ?: return null
        val anime = payload.optJSONObject("anime")
        val episodeObj = payload.optJSONObject("episode")
        val serversArray = episodeObj?.optJSONArray("servers")
        val servers = mutableListOf<AnimeServer>()
        val languages = mutableSetOf<String>()
        if (serversArray != null) {
            for (index in 0 until serversArray.length()) {
                val server = serversArray.optJSONObject(index) ?: continue
                val serverUrl = server.optString("url")
                if (!serverUrl.startsWith("http")) continue
                val language = server.optJSONArray("languages")
                    ?.optString(0)
                    ?.lowercase()
                    ?.replaceFirstChar { it.uppercase() }
                    .orEmpty()
                if (language.isNotBlank()) languages.add(language)
                servers.add(
                    AnimeServer(
                        label = buildString {
                            append(server.optString("name").ifBlank { "Server ${index + 1}" })
                            val tip = server.optString("tip")
                            if (tip.isNotBlank() && !tip.equals(language, ignoreCase = true)) {
                                append(" · ").append(tip)
                            }
                        },
                        language = language,
                        url = serverUrl,
                    ),
                )
            }
        }
        return AnimeEpisodeServers(
            title = anime?.optString("title").orEmpty(),
            source = SourceAnimeLok,
            episodeNumber = episodeObj?.optInt("number", episode) ?: episode,
            episodeName = episodeObj?.optString("name").orEmpty(),
            servers = servers,
            languages = languages.toList(),
        )
    }

    /* ------------------------------------------------- AnimeSalt (WP) */

    private fun parseAnimeSaltCards(html: String): List<AnimeItem> {
        val items = mutableListOf<AnimeItem>()
        val seen = mutableSetOf<String>()
        val articleRegex = Regex(
            "<article[\\s\\S]*?</article>",
            RegexOption.IGNORE_CASE,
        )
        articleRegex.findAll(html).forEach { article ->
            val block = article.value
            val link = Regex("<a[^>]+href=\"(https?://[^\"]+/(?:series|movies|tvshows)/[^\"]+)\"", RegexOption.IGNORE_CASE)
                .find(block)?.groupValues?.get(1)
                ?: Regex("<a[^>]+href=\"(https?://animesalt\\.cx/[^\"]+)\"", RegexOption.IGNORE_CASE)
                    .find(block)?.groupValues?.get(1)
            if (link == null || !seen.add(link)) return@forEach
            val title = Regex("<h2[^>]*class=\"[^\"]*entry-title[^\"]*\"[^>]*>([\\s\\S]*?)</h2>", RegexOption.IGNORE_CASE)
                .find(block)?.groupValues?.get(1)
                ?.let { ArixMediaApi.decodeEntities(it.replace(Regex("<[^>]+>"), "")) }
                .orEmpty()
                .ifBlank {
                    Regex("<h3[^>]*>([\\s\\S]*?)</h3>", RegexOption.IGNORE_CASE)
                        .find(block)?.groupValues?.get(1)
                        ?.let { ArixMediaApi.decodeEntities(it.replace(Regex("<[^>]+>"), "")) }
                        .orEmpty()
                }
                .ifBlank {
                    ArixMediaApi.decodeEntities(
                        link.trimEnd('/').substringAfterLast('/').replace("-", " "),
                    )
                }
            val poster = Regex("(?:data-src|data-lazy-src|src)=\"(https?://[^\"]+)\"", RegexOption.IGNORE_CASE)
                .findAll(block)
                .map { it.groupValues[1] }
                .firstOrNull { it.contains("image.tmdb.org") || it.contains(".jpg") || it.contains(".png") || it.contains(".webp") }
                .orEmpty()
                .let { if (it.startsWith("//")) "https:$it" else it }
            items.add(
                AnimeItem(
                    title = title,
                    url = link,
                    thumbnail = poster,
                    source = SourceAnimeSalt,
                ),
            )
        }
        // chart-item blocks on the homepage
        if (items.isEmpty()) {
            val chartRegex = Regex(
                "<div class=\"chart-item\">[\\s\\S]{0,1400}?</div>\\s*<div class=\"chart-title\">([^<]*)</div>",
                RegexOption.IGNORE_CASE,
            )
            chartRegex.findAll(html).forEach { match ->
                val block = match.value
                val link = Regex("href=\"(https?://animesalt\\.cx/[^\"]+)\"", RegexOption.IGNORE_CASE)
                    .find(block)?.groupValues?.get(1) ?: return@forEach
                if (!seen.add(link)) return@forEach
                val poster = Regex("data-src=\"([^\"]+)\"", RegexOption.IGNORE_CASE)
                    .find(block)?.groupValues?.get(1)?.let { ArixMediaApi.normalizeUrl(it) }.orEmpty()
                items.add(
                    AnimeItem(
                        title = ArixMediaApi.decodeEntities(match.groupValues[1]),
                        url = link,
                        thumbnail = poster,
                        source = SourceAnimeSalt,
                    ),
                )
            }
        }
        return items
    }

    fun animeSaltLatest(page: Int = 1, limit: Int = 24): List<AnimeItem> {
        val normalized = page.coerceIn(1, 30)
        val url = if (normalized <= 1) {
            "${ArixMediaApi.AnimeSaltBase}/category/type/anime/"
        } else {
            "${ArixMediaApi.AnimeSaltBase}/category/type/anime/page/$normalized/"
        }
        return ArixMediaApi.fetchCachedJson(url, ArixMediaApi.Kind.ANIME_LIST) {
            ArixMediaApi.fetchPage(url, ArixMediaApi.Kind.ANIME_LIST)
        }.let(::parseAnimeSaltCards).take(limit)
    }

    fun animeSaltSearch(query: String, limit: Int = 24): List<AnimeItem> {
        val url = "${ArixMediaApi.AnimeSaltBase}/?s=" + android.net.Uri.encode(query)
        return ArixMediaApi.fetchCachedJson(url, ArixMediaApi.Kind.ANIME_LIST) {
            ArixMediaApi.fetchPage(url, ArixMediaApi.Kind.ANIME_LIST)
        }.let(::parseAnimeSaltCards).take(limit)
    }

    /** Series/episode listing for an AnimeSalt detail URL. */
    private fun animeSaltDetail(pageUrl: String): AnimeDetail? {
        val html = ArixMediaApi.fetchCachedJson(pageUrl, ArixMediaApi.Kind.ANIME_DETAIL, ttl = 15 * 60 * 1000L) {
            ArixMediaApi.fetchPage(pageUrl, ArixMediaApi.Kind.ANIME_DETAIL)
        }
        val title = Regex("<h1[^>]*class=\"[^\"]*entry-title[^\"]*\"[^>]*>([\\s\\S]*?)</h1>", RegexOption.IGNORE_CASE)
            .find(html)?.groupValues?.get(1)
            ?.let { ArixMediaApi.decodeEntities(it.replace(Regex("<[^>]+>"), "")) }
            .orEmpty()
            .ifBlank {
                Regex("<title>([\\s\\S]*?)</title>", RegexOption.IGNORE_CASE)
                    .find(html)?.groupValues?.get(1)
                    ?.let { ArixMediaApi.decodeEntities(it.substringBefore("–").substringBefore("|").trim()) }
                    .orEmpty()
            }
        val poster = Regex("(?:data-src|data-lazy-src|src)=\"(https?://image\\.tmdb\\.org[^\"]+)\"", RegexOption.IGNORE_CASE)
            .find(html)?.groupValues?.get(1)?.let { ArixMediaApi.normalizeUrl(it) }.orEmpty()
        val episodes = mutableListOf<AnimeEpisode>()
        val seenEpisodes = mutableSetOf<String>()
        Regex("href=\"(https?://[^\"]*/episode/[^\"]+)\"[^>]*>", RegexOption.IGNORE_CASE)
            .findAll(html)
            .forEach { match ->
                val link = match.groupValues[1]
                if (!seenEpisodes.add(link)) return@forEach
                val number = link.substringAfterLast('/')
                    .let { Regex("(\\d+)x(\\d+)").find(it) }
                    ?.let { (it.groupValues[1].toIntOrNull() ?: 1) * 1000 + (it.groupValues[2].toIntOrNull() ?: 1) }
                    ?: (episodes.size + 1)
                episodes.add(AnimeEpisode(number = number, name = "", url = link))
            }
        if (episodes.isEmpty()) return null
        return AnimeDetail(
            title = title,
            source = SourceAnimeSalt,
            url = pageUrl,
            thumbnail = poster,
            description = "",
            episodes = episodes.sortedBy { it.number },
        )
    }

    /**
     * Stream servers for an AnimeSalt episode page: the direct cdn iframe
     * plus every language link from the base64 multi-lang player payload.
     */
    private fun animeSaltEpisodeServers(episodeUrl: String): AnimeEpisodeServers? {
        val html = ArixMediaApi.fetchCachedJson(episodeUrl, ArixMediaApi.Kind.ANIME_DETAIL, ttl = 30 * 60 * 1000L) {
            ArixMediaApi.fetchPage(episodeUrl, ArixMediaApi.Kind.ANIME_DETAIL)
        }
        val servers = mutableListOf<AnimeServer>()
        val languages = mutableListOf<String>()
        Regex("<iframe[^>]+(?:data-src|src)=\"(https?://as-cdn[^\"]+)\"", RegexOption.IGNORE_CASE)
            .find(html)?.groupValues?.get(1)?.let { cdn ->
                servers.add(AnimeServer(label = "Main", language = "Auto", url = cdn))
                languages.add("Auto")
            }
        Regex("player\\.php\\?data=([A-Za-z0-9+/=]+)")
            .findAll(html)
            .firstOrNull()
            ?.let { match ->
                runCatching {
                    val decoded = android.util.Base64.decode(match.groupValues[1], android.util.Base64.DEFAULT)
                        .toString(Charsets.UTF_8)
                    val array = JSONArray(decoded)
                    for (index in 0 until array.length()) {
                        val entry = array.optJSONObject(index) ?: continue
                        val language = entry.optString("language")
                        val link = entry.optString("link")
                        if (!link.startsWith("http")) continue
                        servers.add(
                            AnimeServer(
                                label = "$language · Stream",
                                language = language,
                                url = link,
                            ),
                        )
                        if (language.isNotBlank()) languages.add(language)
                    }
                }
            }
        if (servers.isEmpty()) return null
        val title = Regex("<title>([\\s\\S]*?)</title>", RegexOption.IGNORE_CASE)
            .find(html)?.groupValues?.get(1)
            ?.let { ArixMediaApi.decodeEntities(it.substringBefore("–").substringBefore("|").trim()) }
            .orEmpty()
        return AnimeEpisodeServers(
            title = title,
            source = SourceAnimeSalt,
            episodeNumber = 0,
            episodeName = "",
            servers = servers,
            languages = languages.distinct(),
        )
    }

    /* ------------------------------------------------------ public API */

    fun latest(page: Int = 1, limit: Int = 24): List<AnimeItem> {
        // AnimeLok is the primary source; AnimeSalt fills in when it's down.
        val primary = runCatching { animeLokLatest(page, limit) }.getOrDefault(emptyList())
        if (primary.isNotEmpty()) return primary
        return runCatching { animeSaltLatest(page, limit) }.getOrDefault(emptyList())
    }

    fun search(query: String, limit: Int = 24): List<AnimeItem> {
        val primary = runCatching { animeLokSearch(query, limit) }.getOrDefault(emptyList())
        if (primary.isNotEmpty()) return primary
        return runCatching { animeSaltSearch(query, limit) }.getOrDefault(emptyList())
    }

    /** Latest listing restricted to a single provider source id. */
    fun latestFrom(source: String, page: Int = 1, limit: Int = 24): List<AnimeItem> =
        when (source) {
            SourceAnimeSalt -> runCatching { animeSaltLatest(page, limit) }.getOrDefault(emptyList())
            else -> runCatching { animeLokLatest(page, limit) }.getOrDefault(emptyList())
        }

    /** Search restricted to a single provider source id. */
    fun searchFrom(source: String, query: String, limit: Int = 24): List<AnimeItem> =
        when (source) {
            SourceAnimeSalt -> runCatching { animeSaltSearch(query, limit) }.getOrDefault(emptyList())
            else -> runCatching { animeLokSearch(query, limit) }.getOrDefault(emptyList())
        }

    /** Episodes list for an anime item (either source). */
    fun fetchEpisodes(itemUrl: String): AnimeDetail? = when {
        itemUrl.startsWith("$SourceAnimeLok:") -> {
            val slug = itemUrl.removePrefix("$SourceAnimeLok:")
            val episodes = runCatching { animeLokEpisodes(slug) }.getOrDefault(emptyList())
            if (episodes.isEmpty()) null
            else AnimeDetail(
                title = "",
                source = SourceAnimeLok,
                url = itemUrl,
                thumbnail = "",
                description = "",
                episodes = episodes,
            )
        }

        itemUrl.startsWith("http") -> runCatching { animeSaltDetail(itemUrl) }.getOrNull()
        else -> null
    }

    /** Servers for one episode (either source). */
    fun fetchEpisodeServers(itemUrl: String, episode: Int, episodeUrl: String): AnimeEpisodeServers? = when {
        itemUrl.startsWith("$SourceAnimeLok:") -> {
            val slug = itemUrl.removePrefix("$SourceAnimeLok:")
            runCatching { animeLokEpisodeServers(slug, episode) }.getOrNull()
        }

        episodeUrl.startsWith("http") -> runCatching { animeSaltEpisodeServers(episodeUrl) }.getOrNull()
        else -> null
    }

    /**
     * Converts a raw stream URL into something the in-app WebView player can
     * load: short.icu links become the abyssplayer embed (the exact transform
     * the site itself performs), .m3u8 links are played by the built-in hls.js
     * stage, everything else loads directly.
     */
    fun playableUrl(raw: String): String {
        var url = ArixMediaApi.normalizeUrl(raw)
        if (url.contains("short.icu") || url.contains("short.ink")) {
            url = url.replace(".ink", ".icu").replace("short.icu", "abyssplayer.com")
        }
        return url
    }

    /* --------------------------------------------------- widget JSON */

    fun listOutputJson(mode: String, query: String, page: Int, items: List<AnimeItem>): String {
        return JSONObject().apply {
            put("widget", "anime_list")
            put("mode", mode)
            put("query", query)
            put("page", page)
            put("results", JSONArray().apply {
                items.forEach { item ->
                    put(
                        JSONObject().apply {
                            put("title", item.title)
                            put("url", item.url)
                            put("thumbnail", item.thumbnail)
                            put("source", item.source)
                            put("meta", item.meta)
                        },
                    )
                }
            })
        }.toString()
    }

    fun detailOutputJson(detail: AnimeDetail, item: AnimeItem): String {
        return JSONObject().apply {
            put("widget", "anime_player")
            put("mode", "episodes")
            put("title", detail.title.ifBlank { item.title })
            put("thumbnail", detail.thumbnail.ifBlank { item.thumbnail })
            put("source", detail.source)
            put("url", detail.url)
            put("description", detail.description)
            put("episodes", JSONArray().apply {
                detail.episodes.take(300).forEach { episode ->
                    put(
                        JSONObject().apply {
                            put("number", episode.number)
                            put("name", episode.name)
                            put("url", episode.url)
                        },
                    )
                }
            })
            put("servers", JSONArray())
            put("languages", JSONArray())
        }.toString()
    }

    fun serversOutputJson(
        detail: ArixAnimeSiteClient.AnimeDetail,
        servers: ArixAnimeSiteClient.AnimeEpisodeServers,
    ): String {
        return JSONObject().apply {
            put("widget", "anime_player")
            put("mode", "episodes")
            put("title", servers.title.ifBlank { detail.title })
            put("thumbnail", detail.thumbnail)
            put("source", servers.source)
            put("url", detail.url)
            put("description", detail.description)
            put("episode_number", servers.episodeNumber)
            put("episode_name", servers.episodeName)
            put("servers", JSONArray().apply {
                servers.servers.forEach { server ->
                    put(
                        JSONObject().apply {
                            put("label", server.label)
                            put("language", server.language)
                            put("url", server.url)
                        },
                    )
                }
            })
            put("languages", JSONArray().apply {
                servers.languages.forEach { put(it) }
            })
        }.toString()
    }

    /** Merges a servers payload back into an episodes payload for the widget. */
    fun mergeServersIntoJson(baseJson: String, serversJson: String): String {
        val base = runCatching { JSONObject(baseJson) }.getOrNull() ?: return baseJson
        val servers = runCatching { JSONObject(serversJson) }.getOrNull() ?: return baseJson
        servers.optJSONArray("servers")?.let { base.put("servers", it) }
        servers.optJSONArray("languages")?.let { base.put("languages", it) }
        servers.optInt("episode_number", 0).takeIf { it > 0 }?.let { base.put("selected_episode", it) }
        servers.optString("episode_name")?.let { if (it.isNotBlank()) base.put("episode_name", it) }
        return base.toString()
    }
}
