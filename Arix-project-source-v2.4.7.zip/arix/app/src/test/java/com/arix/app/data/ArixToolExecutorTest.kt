package com.arix.app.data

import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ArixToolExecutorTest {
    @Test
    fun hostToolDefinitionsDoNotDuplicatePiNativeTools() {
        val definitions = ArixToolExecutor.hostToolDefinitions()
        // v2.4.7: only system_control now (android_shell retired).
        assertEquals(1, definitions.length())
        assertEquals("system_control", definitions.getJSONObject(0).getString("name"))
    }

    @Test
    fun hostToolDefinitionsExposeFlattenedShape() {
        val definitions = ArixToolExecutor.hostToolDefinitions()
        val definition = definitions.getJSONObject(0)
        assertEquals("system_control", definition.optString("name"))
        assertTrue(definition.has("parameters"))
        assertTrue(definition.optString("description").isNotBlank())
    }

    @Test
    fun systemControlDefinitionExposesAdbActions() {
        val definitions = ArixToolExecutor.hostToolDefinitions()
        val definition = definitions.getJSONObject(0)
        assertEquals("system_control", definition.optString("name"))
        assertEquals("sequential", definition.optString("execution_mode"))
        val actionProp = definition.getJSONObject("parameters").getJSONObject("properties").getJSONObject("action")
        val actionDesc = actionProp.optString("description")
        assertTrue("action description must mention adb_tap", actionDesc.contains("adb_tap"))
        assertTrue("action description must mention adb_screenshot", actionDesc.contains("adb_screenshot"))
    }

    @Test
    fun hostToolNamesCoverSystemAndSelfManagement() {
        assertTrue(ArixToolExecutor.supports("system_control"))
        assertFalse(ArixToolExecutor.supports("android_shell"))
        assertTrue(ArixToolExecutor.supports("arix_config_get"))
        assertFalse(ArixToolExecutor.supports("agent_mode"))
        assertFalse(ArixToolExecutor.supports("chrome"))
    }

    @Test
    fun inferToolOutputOkHonorsArixJsonFlags() {
        assertTrue(ArixToolExecutor.inferToolOutputOk("""{"ok":true}"""))
        assertFalse(ArixToolExecutor.inferToolOutputOk("""{"ok":false}"""))
        assertFalse(ArixToolExecutor.inferToolOutputOk("""{"err":true}"""))
        assertTrue(ArixToolExecutor.inferToolOutputOk("plain text"))
        assertTrue(ArixToolExecutor.inferToolOutputOk("""{"status":"fine"}"""))
    }

    @Test
    fun executionResultFlagsErrorOutput() {
        val ok = ArixToolExecutionResult("system_control", "{}", """{"ok":true}""")
        val failed = ArixToolExecutionResult("system_control", "{}", """{"ok":false,"errmsg":"nope"}""")
        assertFalse(ok.isError)
        assertTrue(failed.isError)
        assertEquals(failed.rawOutput, failed.visibleOutput)
    }
}
