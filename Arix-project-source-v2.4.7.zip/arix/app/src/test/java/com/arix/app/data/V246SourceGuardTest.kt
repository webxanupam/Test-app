package com.arix.app.data

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

class V246SourceGuardTest {
    private fun moduleDir(): File {
        var dir: File? = File(System.getProperty("user.dir"))
        repeat(6) {
            val direct = File(dir, "src/main/java/com/arix/app")
            if (direct.isDirectory) return dir!!
            dir = dir?.parentFile
        }
        throw IllegalStateException("app module directory not found")
    }

    private fun appSource(relative: String): String =
        File(moduleDir(), "src/main/java/com/arix/app/$relative").readText()

    @Test
    fun visualDisplayRendersExactlyOnePreviewPanel() {
        val src = appSource("ui/ConversationUi.kt")
        assertTrue(src.contains("agentModePreviewUnfiltered && !chromePreviewVisible"))
    }

    @Test
    fun chatPreviewWebViewIsTransparentOverTheDarkBackdrop() {
        val src = appSource("ui/ConversationUi.kt")
        assertTrue(src.contains("transparentBackground = true"))
    }

    @Test
    fun chromiumBootsOnDarkStartPageInsteadOfAboutBlank() {
        val src = appSource("data/AlpineChromeController.kt")
        assertTrue(src.contains("data:text/html;charset=utf-8"))
        assertFalse("launch script must not boot about:blank", src.contains("about:blank &"))
    }

    @Test
    fun vncViewerSurfacesConnectionErrorsViaWatchdog() {
        val src = appSource("ui/AlpineChromeScreen.kt")
        assertTrue(src.contains("watchVncConnection"))
        assertTrue(src.contains("arix-vnc-status-visible"))
    }

    // v2.4.7: android_shell host tool retired — guard tests for it were removed.

    @Test
    fun androidShellHostToolIsRetiredAndRedirectsToAdbActions() {
        val executor = appSource("data/ArixToolExecutor.kt")
        assertFalse(executor.contains("androidShellTool: ArixAndroidShellTool?"))
        assertFalse(executor.contains("ArixAndroidShellTool.toolDefinition"))
        assertTrue(executor.contains("\"android_shell\" -> JSONObject()"))
        assertTrue(executor.contains("adb_tap"))
        assertTrue(executor.contains("adb_screenshot"))
    }

    @Test
    fun systemControlExposesAdbDeviceActions() {
        val src = appSource("data/ArixSystemControlTool.kt")
        assertTrue(src.contains("adb_tap"))
        assertTrue(src.contains("adb_swipe"))
        assertTrue(src.contains("adb_screenshot"))
        assertTrue(src.contains("adb_input_text"))
        assertTrue(src.contains("adb_keyevent"))
        assertTrue(src.contains("adb_human_tap"))
        assertTrue(src.contains("adb_human_swipe"))
        assertTrue(src.contains("alpineRuntimeProvider"))
    }

    @Test
    fun toolHeaderIsCenteredWithoutSubtitleMatchingSettingsScreen() {
        val src = appSource("ui/ArixToolsUi.kt")
        assertTrue(src.contains("align(Alignment.CenterStart)"))
        assertTrue(src.contains("align(Alignment.Center)"))
    }

    @Test
    fun toolScreensHaveClearHeaderToContentSpacing() {
        val src = appSource("ui/ArixToolsUi.kt")
        assertTrue(src.contains("Spacer(Modifier.height(14.dp))"))
    }

    @Test
    fun moviesSearchBoxDoesNotTouchCategoryList() {
        val src = appSource("ui/ArixToolsUi.kt")
        assertTrue(src.contains("v2.4.7: 12dp spacer so the search pill does not touch the chips."))
    }
}
