package com.arix.app.data

import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.service.notification.StatusBarNotification
import com.arix.app.agentmode.ArixNotificationAccess
import com.arix.app.runtime.AlpineRuntime
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import kotlin.math.roundToInt
import kotlin.random.Random

/**
 * No-root Android system control. v2.3.2: accessibility service removed.
 * v2.4.7: ADB-backed device control added — full UI automation through
 * the device's own wireless debugging service (Android 11+).
 */
class ArixSystemControlTool(
    private val context: Context,
    private val alpineRuntimeProvider: () -> AlpineRuntime? = { null },
) {

    suspend fun execute(argumentsJson: String): String {
        val arguments = runCatching { JSONObject(argumentsJson) }.getOrNull()
            ?: return failure("Arguments were not valid JSON.")
        return try {
            executeAction(arguments)
        } catch (throwable: Throwable) {
            if (throwable is kotlin.coroutines.cancellation.CancellationException) throw throwable
            failure("${throwable.message ?: throwable.javaClass.simpleName}")
        }
    }

    private suspend fun executeAction(arguments: JSONObject): String {
        return when (arguments.optString("action").trim().lowercase()) {
            "open_settings" -> openSettings(arguments.optString("page").trim().lowercase())
            "open_app" -> openApp(
                target = arguments.optString("target").ifBlank { arguments.optString("app") }.trim(),
            )
            "list_apps" -> listApps(
                query = arguments.optString("query").trim(),
                includeSystem = arguments.optBoolean("include_system", false),
                maxResults = minOf(arguments.optInt("max_results", 40).coerceAtLeast(1), 200),
            )
            "read_notifications", "notifications" -> readNotifications(
                filter = arguments.optString("filter").ifBlank { arguments.optString("package") }.trim(),
                maxItems = minOf(arguments.optInt("max_items", 30).coerceIn(1, 120), 120),
            )
            "notification_access_status" -> notificationAccessStatus()
            "open_url", "open_link" -> openLink(
                url = arguments.optString("url").ifBlank { arguments.optString("link") }.trim(),
                forceBrowser = arguments.optBoolean("force_browser", false),
            )
            "device_info" -> deviceInfo()
            "volume" -> volume(
                stream = arguments.optString("stream", "music").trim().lowercase(),
                action = arguments.optString("volume_action", "get").trim().lowercase(),
                direction = arguments.optString("direction", "up").trim().lowercase(),
            )
            "adb_status" -> adbStatus()
            "adb_connect" -> adbConnect(
                host = arguments.optString("host").ifBlank { arguments.optString("target") }.trim(),
                port = arguments.optInt("port", 5555).coerceIn(1, 65535),
            )
            "adb_disconnect" -> adbDisconnect()
            "adb_shell" -> adbShell(
                command = arguments.optString("command").trim(),
                timeoutMs = arguments.optInt("timeout_ms", DefaultAdbTimeoutMs).coerceIn(MinAdbTimeoutMs, MaxAdbTimeoutMs),
            )
            "adb_tap" -> adbTap(arguments.optInt("x", -1), arguments.optInt("y", -1), humanLike = false)
            "adb_human_tap" -> adbTap(arguments.optInt("x", -1), arguments.optInt("y", -1), humanLike = true)
            "adb_swipe" -> adbSwipe(
                startX = arguments.optInt("start_x", -1),
                startY = arguments.optInt("start_y", -1),
                endX = arguments.optInt("end_x", -1),
                endY = arguments.optInt("end_y", -1),
                durationMs = arguments.optInt("duration_ms", 300).coerceIn(50, 4_000),
                humanLike = false,
            )
            "adb_human_swipe" -> adbSwipe(
                startX = arguments.optInt("start_x", -1),
                startY = arguments.optInt("start_y", -1),
                endX = arguments.optInt("end_x", -1),
                endY = arguments.optInt("end_y", -1),
                durationMs = arguments.optInt("duration_ms", 450).coerceIn(80, 4_000),
                humanLike = true,
            )
            "adb_input_text" -> adbInputText(arguments.optString("text"))
            "adb_keyevent" -> adbKeyevent(arguments.optString("keycode").trim().lowercase())
            "adb_screenshot", "adb_screencap" -> adbScreenshot(
                resizeWidth = arguments.optInt("resize_width", 0).coerceAtLeast(0),
            )
            "adb_packages" -> adbPackages(arguments.optString("query").trim())
            "status" -> status()
            else -> failure(
                "Unknown action. Use open_settings, open_app, list_apps, read_notifications, " +
                    "notification_access_status, open_url, device_info, volume, adb_status, " +
                    "adb_connect, adb_disconnect, adb_shell, adb_tap, adb_human_tap, adb_swipe, " +
                    "adb_human_swipe, adb_input_text, adb_keyevent, adb_screenshot, adb_packages, " +
                    "or status."
            )
        }
    }

    private suspend fun status(): String {
        val adbAvailable = alpineRuntimeProvider()?.let { isAdbAvailable(it) } ?: false
        return JSONObject().apply {
            put("ok", true)
            put("action", "status")
            put("notification_access", ArixNotificationAccess.isRunning)
            put("write_settings", Settings.System.canWrite(context))
            put("android_version", Build.VERSION.RELEASE)
            put("device", "${Build.MANUFACTURER} ${Build.MODEL}")
            put("adb_available", adbAvailable)
        }.toString()
    }

    private fun settingsIntent(page: String): Intent? = when (page) {
        "", "main", "home", "settings" -> Intent(Settings.ACTION_SETTINGS)
        "wifi", "wlan" -> Intent(Settings.ACTION_WIFI_SETTINGS)
        "bluetooth", "bt" -> Intent(Settings.ACTION_BLUETOOTH_SETTINGS)
        "apps", "applications", "app", "manage_apps" -> Intent(Settings.ACTION_MANAGE_APPLICATIONS_SETTINGS)
        "app_details", "application_details" -> null
        "notifications", "notification" -> Intent("android.settings.NOTIFICATION_SETTINGS")
        "notification_history" -> Intent("android.settings.NOTIFICATION_HISTORY_SETTINGS")
        "notification_access" -> Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS")
        "sound", "audio", "volume" -> Intent(Settings.ACTION_SOUND_SETTINGS)
        "display", "screen", "brightness" -> Intent(Settings.ACTION_DISPLAY_SETTINGS)
        "battery" -> Intent(Settings.ACTION_BATTERY_SAVER_SETTINGS)
        "storage", "memory" -> Intent(Settings.ACTION_INTERNAL_STORAGE_SETTINGS)
        "location", "gps" -> Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS)
        "security" -> Intent(Settings.ACTION_SECURITY_SETTINGS)
        "privacy" -> Intent(Settings.ACTION_PRIVACY_SETTINGS)
        "accounts", "account", "sync" -> Intent(Settings.ACTION_SYNC_SETTINGS)
        "date", "time", "date_time", "datetime" -> Intent(Settings.ACTION_DATE_SETTINGS)
        "language", "locale", "input_language" -> Intent(Settings.ACTION_LOCALE_SETTINGS)
        "keyboard", "input", "ime", "input_method" -> Intent(Settings.ACTION_INPUT_METHOD_SETTINGS)
        "developer", "developer_options" -> Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS)
        "about", "about_phone", "device_info" -> Intent(Settings.ACTION_DEVICE_INFO_SETTINGS)
        "airplane", "airplane_mode" -> Intent(Settings.ACTION_AIRPLANE_MODE_SETTINGS)
        "nfc" -> Intent(Settings.ACTION_NFC_SETTINGS)
        "cast", "screen_cast" -> Intent(Settings.ACTION_CAST_SETTINGS)
        "print", "printing" -> Intent(Settings.ACTION_PRINT_SETTINGS)
        "data_usage", "data" -> Intent(Settings.ACTION_DATA_USAGE_SETTINGS)
        "home", "default_apps" -> Intent(Settings.ACTION_HOME_SETTINGS)
        "search" -> Intent(Settings.ACTION_SEARCH_SETTINGS)
        "usage", "usage_access" -> Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)
        "vpn" -> Intent(Settings.ACTION_VPN_SETTINGS)
        "wireless_debugging", "wireless_debug" -> Intent("com.android.settings.application.DEVELOPMENT_SETTINGS").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        else -> null
    }

    private fun openSettings(page: String): String {
        val intent = settingsIntent(page)
            ?: return failure("Unknown settings page '$page'.")
        return runCatching {
            context.startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            JSONObject().apply {
                put("ok", true); put("action", "open_settings"); put("page", page)
                put("detail", "Opened the ${page.ifBlank { "main" }} settings screen.")
            }.toString()
        }.getOrElse { failure("Could not open settings page '$page': ${it.message}") }
    }

    private fun openApp(target: String): String {
        if (target.isBlank()) return failure("Provide the app name or package name.")
        val manager = context.packageManager
        val launchables = manager.getInstalledApplications(0).filter { manager.getLaunchIntentForPackage(it.packageName) != null }
        val byPackage = launchables.firstOrNull { it.packageName.equals(target, ignoreCase = true) }
        val byLabel = launchables.map { it to manager.getApplicationLabel(it).toString() }
            .firstOrNull { (info, label) -> label.equals(target, ignoreCase = true) || label.contains(target, ignoreCase = true) || info.packageName.contains(target, ignoreCase = true) }
        val resolved = byPackage ?: byLabel?.first
            ?: return failure("No launchable app matched '$target'. Use list_apps to see installed apps.")
        val label = manager.getApplicationLabel(resolved).toString()
        val launch = manager.getLaunchIntentForPackage(resolved.packageName)
            ?: return failure("App '$label' has no launch intent.")
        return runCatching {
            context.startActivity(launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            JSONObject().apply {
                put("ok", true); put("action", "open_app"); put("app", label)
                put("package", resolved.packageName); put("detail", "Launched $label.")
            }.toString()
        }.getOrElse { failure("Could not launch '$label': ${it.message}") }
    }

    private fun listApps(query: String, includeSystem: Boolean, maxResults: Int): String {
        val manager = context.packageManager
        val launchables = manager.getInstalledApplications(0)
            .filter { manager.getLaunchIntentForPackage(it.packageName) != null }
            .map { AppEntry(manager.getApplicationLabel(it).toString(), it.packageName, (it.flags and android.content.pm.ApplicationInfo.FLAG_SYSTEM) != 0) }
            .filter { includeSystem || !it.isSystem }
            .filter { query.isBlank() || it.label.contains(query, true) || it.packageName.contains(query, true) }
            .sortedWith(compareByDescending<AppEntry> { it.label.startsWith(query, true) }.thenBy { it.label.lowercase() })
            .take(maxResults)
        return JSONObject().apply {
            put("ok", true); put("action", "list_apps"); put("count", launchables.size)
            put("apps", JSONArray().apply {
                launchables.forEach { put(JSONObject().apply { put("label", it.label); put("package", it.packageName); put("system", it.isSystem) }) }
            })
            put("detail", "Found ${launchables.size} app(s)${if (query.isNotBlank()) " matching '$query'" else ""}.")
        }.toString()
    }

    private data class AppEntry(val label: String, val packageName: String, val isSystem: Boolean)

    private fun readNotifications(filter: String, maxItems: Int): String {
        val service = ArixNotificationAccess.service()
        if (service == null) {
            return JSONObject().apply {
                put("ok", false); put("action", "read_notifications")
                put("errmsg", "Notification access is not enabled. Ask the user to grant it via open_settings page=notification_access.")
            }.toString()
        }
        val notifications: List<StatusBarNotification> = service.snapshot()
        val filtered = if (filter.isNotBlank()) notifications.filter { it.packageName.contains(filter, ignoreCase = true) } else notifications
        val items = JSONArray()
        filtered.take(maxItems).forEach { notification ->
            runCatching {
                val extras = notification.notification?.extras ?: return@runCatching
                val title = extras.getCharSequence("android.title")?.toString().orEmpty()
                val text = extras.getCharSequence("android.text")?.toString().orEmpty()
                val bigText = extras.getCharSequence("android.bigText")?.toString().orEmpty()
                val subText = extras.getCharSequence("android.subText")?.toString().orEmpty()
                if (title.isBlank() && text.isBlank() && bigText.isBlank()) return@runCatching
                items.put(JSONObject().apply {
                    put("package", notification.packageName)
                    if (title.isNotBlank()) put("title", title.take(160))
                    if (text.isNotBlank()) put("text", text.take(400))
                    if (bigText.isNotBlank() && bigText != text) put("big_text", bigText.take(900))
                    if (subText.isNotBlank()) put("sub_text", subText.take(80))
                    put("when", notification.postTime)
                })
            }
        }
        val counts = JSONObject()
        notifications.groupBy { it.packageName }.forEach { (pkg, list) -> counts.put(pkg, list.size) }
        return JSONObject().apply {
            put("ok", true); put("action", "read_notifications")
            if (filter.isNotBlank()) put("filter", filter)
            put("count", items.length()); put("total", notifications.size)
            put("items", items); put("package_counts", counts)
            put("detail", "Read ${items.length()} notification(s)${if (filter.isNotBlank()) " from packages matching '$filter'" else ""}.")
        }.toString()
    }

    private fun notificationAccessStatus(): String {
        val enabled = ArixNotificationAccess.isNotificationAccessEnabled(context)
        return JSONObject().apply {
            put("ok", true); put("action", "notification_access_status"); put("enabled", enabled)
            put("connected", ArixNotificationAccess.isRunning)
            put("detail", if (enabled) "Notification access is enabled." else "Notification access is not enabled. open_settings page=notification_access.")
        }.toString()
    }

    private fun openLink(url: String, forceBrowser: Boolean): String {
        if (url.isBlank()) return failure("Provide the url to open.")
        val parsed = runCatching { Uri.parse(url) }.getOrNull() ?: return failure("Could not parse the URL '$url'.")
        val isHttp = url.startsWith("http://", ignoreCase = true) || url.startsWith("https://", ignoreCase = true)
        return runCatching {
            val intent = if (isHttp && forceBrowser) {
                Intent(Intent.ACTION_VIEW, parsed).apply {
                    addCategory(Intent.CATEGORY_BROWSABLE)
                    setPackage(context.packageManager.resolveActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://example.com")), 0)?.activityInfo?.packageName)
                }
            } else Intent(Intent.ACTION_VIEW, parsed)
            context.startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            JSONObject().apply { put("ok", true); put("action", "open_url"); put("url", url) }.toString()
        }.getOrElse { failure("Could not open URL: ${it.message}") }
    }

    private fun deviceInfo(): String {
        val audio = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val battery = runCatching {
            val intent = context.registerReceiver(null, android.content.IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            val level = intent?.getIntExtra(android.os.BatteryManager.EXTRA_LEVEL, -1) ?: -1
            val scale = intent?.getIntExtra(android.os.BatteryManager.EXTRA_SCALE, -1) ?: -1
            if (level >= 0 && scale > 0) level * 100 / scale else null
        }.getOrNull()
        val metrics = context.resources.displayMetrics
        return JSONObject().apply {
            put("ok", true); put("action", "device_info"); put("model", Build.MODEL)
            put("manufacturer", Build.MANUFACTURER); put("android_version", Build.VERSION.RELEASE)
            put("sdk", Build.VERSION.SDK_INT)
            battery?.let { put("battery_percent", it) }
            put("screen", JSONObject().apply { put("width_px", metrics.widthPixels); put("height_px", metrics.heightPixels); put("density", metrics.densityDpi / 160.0) })
            put("volume", JSONObject().apply { put("music", audio.getStreamVolume(AudioManager.STREAM_MUSIC)); put("ring", audio.getStreamVolume(AudioManager.STREAM_RING)); put("alarm", audio.getStreamVolume(AudioManager.STREAM_ALARM)) })
        }.toString()
    }

    private fun volume(stream: String, action: String, direction: String): String {
        val audio = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val streamId = when (stream) {
            "music", "media" -> AudioManager.STREAM_MUSIC
            "ring", "ringer" -> AudioManager.STREAM_RING
            "alarm" -> AudioManager.STREAM_ALARM
            "call" -> AudioManager.STREAM_VOICE_CALL
            "system" -> AudioManager.STREAM_SYSTEM
            "notification", "notifications" -> AudioManager.STREAM_NOTIFICATION
            else -> AudioManager.STREAM_MUSIC
        }
        if (action == "get") {
            return JSONObject().apply { put("ok", true); put("action", "volume"); put("stream", stream); put("level", audio.getStreamVolume(streamId)); put("max", audio.getStreamMaxVolume(streamId)) }.toString()
        }
        val directionFlag = if (direction == "down") AudioManager.ADJUST_LOWER else AudioManager.ADJUST_RAISE
        if (action == "mute") audio.adjustStreamVolume(streamId, AudioManager.ADJUST_MUTE, 0)
        else if (action == "unmute") audio.adjustStreamVolume(streamId, AudioManager.ADJUST_UNMUTE, 0)
        else audio.adjustStreamVolume(streamId, directionFlag, 0)
        return JSONObject().apply { put("ok", true); put("action", "volume"); put("stream", stream); put("level", audio.getStreamVolume(streamId)); put("max", audio.getStreamMaxVolume(streamId)) }.toString()
    }

    /* ADB device control — v2.4.7 */

    private suspend fun isAdbAvailable(runtime: AlpineRuntime): Boolean = runCatching {
        val result = runtime.executeCommand("command -v adb >/dev/null 2>&1 && command -v arix-adb >/dev/null 2>&1 && echo ok", runtime.homeDirectory, 10_000L)
        JSONObject(result).optBoolean("ok") && JSONObject(result).optString("stdout", "").contains("ok")
    }.getOrElse { false }

    private suspend fun adbStatus(): String {
        val runtime = alpineRuntimeProvider() ?: return failure("ADB device control is unavailable: the Alpine runtime is not ready. Open Settings → Alpine → Packages → install the 'ADB tools' preset.")
        if (!isAdbAvailable(runtime)) {
            return JSONObject().apply {
                put("ok", false); put("action", "adb_status"); put("adb_installed", false)
                put("errmsg", "ADB is not installed in the Alpine runtime yet. Install the 'ADB tools' preset.")
                put("setup_steps", JSONArray()
                    .put("Settings → System → Developer options → Wireless debugging → ON")
                    .put("Open 'Pair device with pairing code' and note IP:PORT + 6-digit code")
                    .put("In the Alpine terminal tab: arix-adb pair 127.0.0.1:PORT CODE")
                    .put("Then: arix-adb connect 127.0.0.1:PORT"))
            }.toString()
        }
        val raw = runtime.executeCommand("arix-adb status 2>&1; echo '---'; arix-adb devices 2>&1", runtime.homeDirectory, 15_000L)
        val parsed = JSONObject(raw)
        val stdout = parsed.optString("stdout", "")
        val connected = stdout.contains("\tdevice", ignoreCase = true) || stdout.contains("connected", ignoreCase = true)
        return JSONObject().apply {
            put("ok", true); put("action", "adb_status"); put("adb_installed", true); put("connected", connected); put("raw", stdout)
            if (connected) put("detail", "ADB is connected — adb_tap, adb_swipe, adb_screenshot, adb_input_text are ready.")
            else put("detail", "ADB is installed but no device is connected. Pair via Wireless debugging then arix-adb connect.")
        }.toString()
    }

    private suspend fun adbConnect(host: String, port: Int): String {
        val runtime = alpineRuntimeProvider() ?: return failure("Alpine runtime is not ready; cannot connect to ADB.")
        if (!isAdbAvailable(runtime)) return failure("ADB is not installed. Install the 'ADB tools' preset first.")
        val target = if (host.isBlank()) "127.0.0.1:$port" else "$host:$port"
        val raw = runtime.executeCommand("arix-adb connect '$target' 2>&1", runtime.homeDirectory, 15_000L)
        val stdout = JSONObject(raw).optString("stdout", "")
        val ok = stdout.contains("connected", ignoreCase = true) && !stdout.contains("cannot", ignoreCase = true) && !stdout.contains("failed", ignoreCase = true)
        return JSONObject().apply {
            put("ok", ok); put("action", "adb_connect"); put("target", target); put("stdout", stdout)
            if (ok) put("detail", "Connected to $target.") else put("errmsg", "Could not connect to $target. Raw: $stdout")
        }.toString()
    }

    private suspend fun adbDisconnect(): String {
        val runtime = alpineRuntimeProvider() ?: return failure("Alpine runtime is not ready.")
        if (!isAdbAvailable(runtime)) return failure("ADB is not installed.")
        val raw = runtime.executeCommand("arix-adb disconnect 2>&1", runtime.homeDirectory, 10_000L)
        return JSONObject().apply { put("ok", true); put("action", "adb_disconnect"); put("stdout", JSONObject(raw).optString("stdout", "")); put("detail", "Disconnected.") }.toString()
    }

    private suspend fun adbShell(command: String, timeoutMs: Int): String {
        val runtime = alpineRuntimeProvider() ?: return failure("Alpine runtime is not ready.")
        if (!isAdbAvailable(runtime)) return failure("ADB is not installed.")
        if (command.isBlank()) return failure("Missing 'command' argument for adb_shell.")
        val quoted = "'" + command.replace("'", "'\\''") + "'"
        val raw = runtime.executeCommand("arix-adb shell $quoted", runtime.homeDirectory, timeoutMs.toLong())
        val parsed = JSONObject(raw)
        val ok = parsed.optBoolean("ok")
        return JSONObject().apply {
            put("ok", ok); put("action", "adb_shell"); put("command", command)
            put("exit_code", parsed.optInt("exit_code", if (ok) 0 else -1))
            put("stdout", parsed.optString("stdout", "")); put("stderr", parsed.optString("stderr", ""))
            if (!ok) put("errmsg", parsed.optString("stderr", "").ifBlank { "adb shell failed." })
        }.toString()
    }

    private suspend fun adbTap(x: Int, y: Int, humanLike: Boolean): String {
        if (x < 0 || y < 0) return failure("Provide valid 'x' and 'y' coordinates.")
        val runtime = alpineRuntimeProvider() ?: return failure("Alpine runtime is not ready.")
        if (!isAdbAvailable(runtime)) return failure("ADB is not installed.")
        val (targetX, targetY) = if (humanLike) (x + Random.nextInt(-3, 4)) to (y + Random.nextInt(-3, 4)) else x to y
        val holdMs = if (humanLike) Random.nextInt(45, 96) else 0
        val command = if (humanLike) "input swipe $targetX $targetY $targetX $targetY $holdMs" else "input tap $targetX $targetY"
        if (humanLike) kotlinx.coroutines.delay(Random.nextInt(60, 181).toLong())
        val raw = runtime.executeCommand("arix-adb shell '$command' 2>&1", runtime.homeDirectory, 10_000L)
        val parsed = JSONObject(raw)
        val ok = parsed.optBoolean("ok")
        return JSONObject().apply {
            put("ok", ok); put("action", if (humanLike) "adb_human_tap" else "adb_tap")
            put("x", targetX); put("y", targetY)
            if (humanLike) put("hold_ms", holdMs)
            if (!ok) put("errmsg", parsed.optString("stderr", "").ifBlank { "adb tap failed." })
            else put("detail", "Tapped at ($targetX, $targetY)${if (humanLike) " (human-like)" else ""}.")
        }.toString()
    }

    private suspend fun adbSwipe(startX: Int, startY: Int, endX: Int, endY: Int, durationMs: Int, humanLike: Boolean): String {
        if (startX < 0 || startY < 0 || endX < 0 || endY < 0) return failure("Provide valid start_x, start_y, end_x, end_y.")
        val runtime = alpineRuntimeProvider() ?: return failure("Alpine runtime is not ready.")
        if (!isAdbAvailable(runtime)) return failure("ADB is not installed.")
        val coords = if (humanLike) listOf(startX, startY, endX, endY).map { it + Random.nextInt(-4, 5) } else listOf(startX, startY, endX, endY)
        val sx = coords[0]; val sy = coords[1]; val ex = coords[2]; val ey = coords[3]
        val dur = if (humanLike) (durationMs * (1.0 + Random.nextDouble(-0.15, 0.16))).roundToInt().coerceIn(80, 4_000) else durationMs
        if (humanLike) kotlinx.coroutines.delay(Random.nextInt(80, 221).toLong())
        val command = "input swipe $sx $sy $ex $ey $dur"
        val raw = runtime.executeCommand("arix-adb shell '$command' 2>&1", runtime.homeDirectory, 12_000L)
        val parsed = JSONObject(raw)
        val ok = parsed.optBoolean("ok")
        return JSONObject().apply {
            put("ok", ok); put("action", if (humanLike) "adb_human_swipe" else "adb_swipe")
            put("start_x", sx); put("start_y", sy); put("end_x", ex); put("end_y", ey); put("duration_ms", dur)
            if (!ok) put("errmsg", parsed.optString("stderr", "").ifBlank { "adb swipe failed." })
            else put("detail", "Swiped ($sx,$sy) → ($ex,$ey) over ${dur}ms${if (humanLike) " (human-like)" else ""}.")
        }.toString()
    }

    private suspend fun adbInputText(text: String): String {
        if (text.isBlank()) return failure("Missing 'text' argument for adb_input_text.")
        val runtime = alpineRuntimeProvider() ?: return failure("Alpine runtime is not ready.")
        if (!isAdbAvailable(runtime)) return failure("ADB is not installed.")
        val quoted = "'" + text.replace("'", "'\\''").replace("%", "\\%") + "'"
        val raw = runtime.executeCommand("arix-adb shell \"input text $quoted\" 2>&1", runtime.homeDirectory, 12_000L)
        val parsed = JSONObject(raw)
        val ok = parsed.optBoolean("ok")
        return JSONObject().apply {
            put("ok", ok); put("action", "adb_input_text"); put("text", text)
            if (!ok) put("errmsg", parsed.optString("stderr", "").ifBlank { "adb input text failed." })
            else put("detail", "Typed ${text.length} character(s).")
        }.toString()
    }

    private suspend fun adbKeyevent(keycode: String): String {
        if (keycode.isBlank()) return failure("Missing 'keycode' argument for adb_keyevent.")
        val runtime = alpineRuntimeProvider() ?: return failure("Alpine runtime is not ready.")
        if (!isAdbAvailable(runtime)) return failure("ADB is not installed.")
        val normalized = if (keycode.startsWith("KEYCODE_", ignoreCase = true)) keycode.uppercase() else "KEYCODE_" + keycode.uppercase()
        val raw = runtime.executeCommand("arix-adb shell 'input $normalized' 2>&1", runtime.homeDirectory, 10_000L)
        val parsed = JSONObject(raw)
        val ok = parsed.optBoolean("ok")
        return JSONObject().apply {
            put("ok", ok); put("action", "adb_keyevent"); put("keycode", normalized)
            if (!ok) put("errmsg", parsed.optString("stderr", "").ifBlank { "adb keyevent failed." })
            else put("detail", "Pressed $normalized.")
        }.toString()
    }

    private suspend fun adbScreenshot(resizeWidth: Int): String {
        val runtime = alpineRuntimeProvider() ?: return failure("Alpine runtime is not ready.")
        if (!isAdbAvailable(runtime)) return failure("ADB is not installed.")
        val captureDir = File(context.filesDir, "arix-adb/captures").apply { mkdirs() }
        val timestamp = System.currentTimeMillis()
        val remotePath = "/sdcard/arix_shot_$timestamp.png"
        val pullTarget = File(captureDir, "shot_$timestamp.png")
        val raw = runtime.executeCommand("set -e\narix-adb shell 'screencap -p $remotePath' 2>&1\narix-adb pull '$remotePath' '${pullTarget.absolutePath}' 2>&1\narix-adb shell 'rm -f $remotePath' 2>&1", runtime.homeDirectory, 30_000L)
        val parsed = JSONObject(raw)
        val ok = parsed.optBoolean("ok") && pullTarget.exists() && pullTarget.length() > 0
        if (!ok) {
            return JSONObject().apply { put("ok", false); put("action", "adb_screenshot"); put("errmsg", parsed.optString("stderr", "").ifBlank { "adb screencap failed." }) }.toString()
        }
        return JSONObject().apply {
            put("ok", true); put("action", "adb_screenshot"); put("path", pullTarget.absolutePath)
            put("size_bytes", pullTarget.length()); put("captured_at", timestamp)
            put("detail", "Captured the device screen to ${pullTarget.absolutePath}.")
        }.toString()
    }

    private suspend fun adbPackages(query: String): String {
        val runtime = alpineRuntimeProvider() ?: return failure("Alpine runtime is not ready.")
        if (!isAdbAvailable(runtime)) return failure("ADB is not installed.")
        val filter = if (query.isNotBlank()) "| grep -i '${query.replace("'", "'\\''")}'" else ""
        val raw = runtime.executeCommand("arix-adb shell 'pm list packages' $filter 2>&1 | head -200", runtime.homeDirectory, 20_000L)
        val parsed = JSONObject(raw)
        val stdout = parsed.optString("stdout", "")
        val packages = stdout.lineSequence().map { it.removePrefix("package:").trim() }.filter { it.isNotBlank() }.toList()
        return JSONObject().apply {
            put("ok", true); put("action", "adb_packages"); put("count", packages.size)
            put("packages", JSONArray().apply { packages.forEach { put(it) } })
            if (query.isNotBlank()) put("query", query)
            put("detail", "Listed ${packages.size} package(s)${if (query.isNotBlank()) " matching '$query'" else ""}.")
        }.toString()
    }

    private fun failure(message: String): String = JSONObject().put("ok", false).put("errmsg", message).toString()

    companion object {
        private const val DefaultAdbTimeoutMs = 15_000
        private const val MinAdbTimeoutMs = 1_000
        private const val MaxAdbTimeoutMs = 120_000

        val toolDefinition: JSONObject = JSONObject().apply {
            put("name", "system_control")
            put("description", "No-root Android device control. ALWAYS prefer this tool for: launching apps (open_app), listing apps, reading live notifications (read_notifications), opening URLs and app deep links (open_url), opening system settings, volume control, device info. v2.4.7: full ADB-backed UI automation — adb_tap, adb_swipe, adb_screenshot, adb_input_text, adb_keyevent, adb_human_tap, adb_human_swipe (with random jitter + delays for human-like interactions), adb_shell, adb_packages. First-time setup: ask the user to enable Wireless debugging (Android 11+) and pair via the Alpine terminal tab once; see adb_status. For browsing a website with full automation use the chrome tool instead.")
            put("parameters", JSONObject().apply {
                put("type", "object")
                put("properties", JSONObject().apply {
                    put("action", JSONObject().put("type", "string").put("description", "One of: open_app, list_apps, read_notifications, notification_access_status, open_url, open_settings, device_info, volume, status, adb_status, adb_connect, adb_disconnect, adb_shell, adb_tap, adb_human_tap, adb_swipe, adb_human_swipe, adb_input_text, adb_keyevent, adb_screenshot, adb_packages."))
                    put("page", JSONObject().put("type", "string").put("description", "For open_settings: main, wifi, bluetooth, apps, notifications, sound, display, battery, storage, location, security, privacy, accounts, date, language, keyboard, developer, about, airplane, nfc, cast, print, data_usage, home, vpn, usage, wireless_debugging."))
                    put("target", JSONObject().put("type", "string").put("description", "For open_app: app label or package. For adb_connect: optional target host."))
                    put("query", JSONObject().put("type", "string").put("description", "For list_apps / read_notifications / adb_packages: optional filter."))
                    put("filter", JSONObject().put("type", "string").put("description", "For read_notifications: filter by package substring."))
                    put("max_items", JSONObject().put("type", "number").put("description", "For read_notifications: max items (default 30)."))
                    put("include_system", JSONObject().put("type", "boolean").put("description", "For list_apps: include system apps."))
                    put("url", JSONObject().put("type", "string").put("description", "For open_url: http/https URL or deep link."))
                    put("force_browser", JSONObject().put("type", "boolean").put("description", "For open_url: open in browser."))
                    put("stream", JSONObject().put("type", "string").put("description", "For volume: music, ring, alarm, call, system, notification."))
                    put("volume_action", JSONObject().put("type", "string").put("description", "For volume: get, set, mute, unmute."))
                    put("direction", JSONObject().put("type", "string").put("description", "For volume set: up or down."))
                    put("host", JSONObject().put("type", "string").put("description", "For adb_connect: target host (default 127.0.0.1)."))
                    put("port", JSONObject().put("type", "number").put("description", "For adb_connect: target port (default 5555)."))
                    put("command", JSONObject().put("type", "string").put("description", "For adb_shell: adb shell command."))
                    put("timeout_ms", JSONObject().put("type", "number").put("description", "For adb_shell: timeout ms (default 15000, max 120000)."))
                    put("x", JSONObject().put("type", "number").put("description", "For adb_tap: x coordinate."))
                    put("y", JSONObject().put("type", "number").put("description", "For adb_tap: y coordinate."))
                    put("start_x", JSONObject().put("type", "number").put("description", "For adb_swipe: start x."))
                    put("start_y", JSONObject().put("type", "number").put("description", "For adb_swipe: start y."))
                    put("end_x", JSONObject().put("type", "number").put("description", "For adb_swipe: end x."))
                    put("end_y", JSONObject().put("type", "number").put("description", "For adb_swipe: end y."))
                    put("duration_ms", JSONObject().put("type", "number").put("description", "For adb_swipe: duration ms."))
                    put("text", JSONObject().put("type", "string").put("description", "For adb_input_text: text to type."))
                    put("keycode", JSONObject().put("type", "string").put("description", "For adb_keyevent: keycode (BACK, HOME, POWER, ENTER, MENU)."))
                    put("resize_width", JSONObject().put("type", "number").put("description", "For adb_screenshot: optional resize width."))
                })
                put("required", JSONArray().put("action"))
                put("additionalProperties", false)
            })
            put("execution_mode", "sequential")
        }
    }
}
