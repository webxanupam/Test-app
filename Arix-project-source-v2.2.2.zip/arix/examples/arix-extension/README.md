# Combined Pi + Arix extension example

Zip this directory and import it from Arix's Extensions page.

The package contains:

- a standard Pi command (`/arix-example`);
- a native card above Arix's composer;
- an extension-owned native page in the conversation drawer;
- a WebView using the JavaScript action bridge;
- persistent extension state and Android host calls.

See `docs/ARIX_EXTENSIONS.md` for the complete API.
