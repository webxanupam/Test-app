<p align="center">
  <img src="app/src/main/res/drawable-nodpi/arix_mark.png" width="128" height="128" alt="Arix Logo">
</p>

<h1 align="center">Arix</h1>

<p align="center">
  <strong>Soar with local AI.</strong><br>
  A stunning, localized, highly extensible general-purpose AI Agent for Android.
</p>

<p align="center">
  <a href="#-visuals--experience">Visuals & Experience</a> •
  <a href="#-high-extensibility">Extensions</a> •
  <a href="#-core-features">Core Features</a> •
  <a href="https://webxanupam.blogspot.com/docs">Documentation</a>
</p>

<p align="center">
  <table>
    <tr>
      <td><img src="public/welcome.jpg" width="280"></td>
      <td><img src="public/agentmode.jpg" width="280"></td>
      <td><img src="public/chat.jpg" width="280"></td>
      <td><img src="public/research.jpg" width="280"></td>
    </tr>
  </table>
</p>

---

## 🌪️ Arix 

> Fast, private, and always at hand - your local AI agent for Android.

**Arix** is dedicated to bringing a modern, local AI Agent experience to Android devices. Built on top of the Pi framework, it pairs a minimalist, polished UI with immense extensibility, seamless tool calling, and full extension ecosystem support.

## 🧩 High Extensibility

Arix natively supports loading standard [Pi Extensions](https://github.com/earendil-works/pi). To bring TUI-oriented extensions seamlessly to mobile touchscreens, Arix provides a rich **Extension API** allowing extensions to inject custom settings cards, interactive composer widgets, overlay transcript viewers, prompt interceptors, and semantic tool titles.

| Extension | Description | Repository |
| :--- | :--- | :--- |
| **Pi Web Access*** | Web search across 20+ providers (OpenAI, Brave, Exa, Tavily, Perplexity, Gemini, SearXNG), GitHub repo cloning, PDF extraction, and YouTube/video understanding with native settings and transcript cards. | [pi-web-access](https://github.com/AetherExtensions/pi-web-access) |
| **Pi MCP Adapter*** | Model Context Protocol (MCP) gateway supporting Stdio, Streamable HTTP, SSE, and Unix domain sockets with lazy loading, token-saving tool discovery, interactive OAuth authentication, and a visual server management GUI. | [pi-mcp-adapter](https://github.com/AetherExtensions/pi-mcp-adapter) |
| **Pi Subagents*** | Claude Code-style autonomous sub-agents with parallel background execution, mid-run steering, live widget & FleetView cards above the composer, conversation overlay viewer, and `@handle` prompt mentions. | [pi-subagents](https://github.com/AetherExtensions/pi-subagents) |
| **Movie Explorer*** | Search movies, browse the latest releases, and play them instantly with a multi-server embedded player and download links (sources watchonlinemovies.com.pk with proxy fallbacks). | bundled |
| **QR Code Generator*** | Turn any text, link, or Wi-Fi payload into a scannable QR code using free open QR APIs with multiple automatic fallbacks. | bundled |

*\* Bundled extensions adapted for mobile. Add your own extension to the list by submitting a PR.*

Extensions can be installed directly as zip packages in **Settings → Extensions → Import extension**.

For extension development documentation, see <https://webxanupam.blogspot.com/docs/extensions/overview.md>.


## 📱 Visuals & Experience

Arix's UI and interactions are heavily inspired by excellent, mature applications like ChatGPT, Codex CLI/App, Gemini, and Poco Agent. Every animation and interaction detail has been carefully polished to break the stereotype that "open-source means cheap and unrefined."

<p align="center">
  <table>
    <tr>
      <td><img src="public/input_bar.jpg" width="280"></td>
      <td><img src="public/tool_execution.jpg" width="280"></td>
      <td><img src="public/msg_options.jpg" width="280"></td>
    </tr>
  </table>
</p>


## ✨ Core Features

- **Stunning UI & Silky Smooth Interactions**: Distilling the design essence of top-tier apps like ChatGPT to create a minimalist, modern, and elegant interface — now with a premium deep-dark theme and a refreshed violet Arix mark.
- **Pi Harness Kernel**: Powered by the Pi framework, providing the widest LLM provider compatibility and a lightweight, highly efficient Agent execution engine.
- **Extreme Extensibility**: Inherits Pi's complete extension model while providing Arix's proprietary Script Extensions and Native Mods system to deeply customize mobile UI, settings, composer widgets, and runtime behavior.
- **Built-in Alpine VM**: Includes an automatically installed Alpine Linux environment to run shell commands and tools out of the box.
- **Extensible Host Control**: Supports optional Shizuku and Termux integration for direct device manipulation and automation. (Android only)
- **IST Time Greeting**: The home screen greets you by Indian Standard Time — "Good morning, Sir", "Good evening, Sir", and so on — with an onboarding-style typewriter reveal, a live IST clock, and a soft violet-gradient headline, fading away as soon as the conversation begins.


## 🚀 Quick Start

See <https://webxanupam.blogspot.com/docs/quickstart>.


## 🤝 Contributing

Arix is under active iteration and polish. Feedback, bug reports, and pull requests are always welcome.



## Special Thanks

- OpenAI Codex
- Google Gemini
- [Linux DO Community](https://linux.do/)



---

## 📄 License

This project is licensed under the **GPL-3.0 License**.

---

<p align="center">
  Built with ❤️ by Shilin "BaimoQilin" Zhou.
</p>
