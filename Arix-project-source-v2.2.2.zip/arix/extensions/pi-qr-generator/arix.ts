/**
 * QR Code Generator — Arix extension entry point.
 *
 * Adds:
 *   - a rich `qr-code` message card (base64 image, payload, provider info)
 *   - a composer menu item that instantly QR-encodes the current draft
 *   - the bridge used by index.ts to mirror tool results into the chat
 *   - a settings page describing the provider fallback chain
 */

import { mkdirSync, writeFileSync } from "node:fs";
import { homedir } from "node:os";
import { join } from "node:path";
import { describeQrData, generateQrPng } from "./qr.ts";

type ArixJsonObject = Record<string, unknown>;
type ArixView = ArixJsonObject | ArixView[] | string | null | undefined;
type ArixRenderContext = ArixJsonObject & { storage: ArixJsonObject };
type ArixMessageTypeDefinition = {
  type: string;
  title?: string;
  icon?: string;
  render:
    | ArixView
    | ((context: ArixRenderContext & { message: ArixJsonObject }) => ArixView | Promise<ArixView>);
};
type ArixQrPayload = {
  data: string;
  kind: string;
  base64: string;
  size: number;
  provider: string;
  savedPath: string;
};
type ArixExtensionApi = {
  ui: {
    text(text: string, properties?: ArixJsonObject): ArixJsonObject;
    column(children: ArixView[], properties?: ArixJsonObject): ArixJsonObject;
    row(children: ArixView[], properties?: ArixJsonObject): ArixJsonObject;
    card(children: ArixView[], properties?: ArixJsonObject): ArixJsonObject;
    button(label: string, action: string, properties?: ArixJsonObject): ArixJsonObject;
    input(value: string, action: string, properties?: ArixJsonObject): ArixJsonObject;
    spacer(size?: number, properties?: ArixJsonObject): ArixJsonObject;
    web(properties: ArixJsonObject): ArixJsonObject;
  };
  host: { invoke(method: string, args?: ArixJsonObject): Promise<ArixJsonObject> };
  state: { get(path?: string): Promise<ArixJsonObject> };
  storage: {
    get<T = unknown>(key: string, fallback?: T): T;
    set(key: string, value: unknown): void;
  };
  messages: {
    append(type: string, payload?: ArixJsonObject, text?: string): Promise<ArixJsonObject>;
  };
  registerSettings(definition: ArixJsonObject): () => void;
  registerAction(
    id: string,
    handler: (payload: ArixJsonObject) => unknown | Promise<unknown>,
  ): () => void;
  registerMessageType(definition: ArixMessageTypeDefinition): () => void;
  registerComposerMenuItem(definition: ArixJsonObject): () => void;
  registerToolTitle(
    toolName: string,
    runningTitle: string,
    completedTitle: string,
    priority?: number,
  ): () => void;
  notify(message: string, level?: "info" | "warning" | "error"): void;
  invalidate(): void;
};

const BRIDGE_KEY = Symbol.for("pi-qr-generator.arix-bridge");
const SETTINGS_PAGE_ID = "qr-generator-settings";

interface QrBridge {
  api: ArixExtensionApi;
}

function escapeHtml(value: string): string {
  return String(value ?? "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}

/** Called by index.ts to mirror tool results into the Arix conversation. */
export async function appendArixQrMessage(
  type: string,
  payload: ArixJsonObject,
  text = "",
): Promise<boolean> {
  const bridge = (globalThis as Record<PropertyKey, unknown>)[BRIDGE_KEY] as QrBridge | undefined;
  if (!bridge) return false;
  try {
    await bridge.api.messages.append(type, payload, text);
    return true;
  } catch {
    return false;
  }
}

function qrCardHtml(payload: ArixQrPayload): string {
  const data = String(payload.data ?? "");
  const base64 = String(payload.base64 ?? "");
  const kind = String(payload.kind ?? "Text");
  const provider = String(payload.provider ?? "");
  const size = Number(payload.size ?? 300);
  const savedPath = String(payload.savedPath ?? "");
  return `<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1"/>
<style>
  * { box-sizing: border-box; margin: 0; padding: 0; -webkit-tap-highlight-color: transparent; }
  body { font-family: -apple-system, Roboto, 'Segoe UI', sans-serif; background: transparent; color: #ECECF1; }
  .wrap { display: flex; gap: 14px; padding: 12px; align-items: flex-start; }
  .qr { width: 148px; height: 148px; border-radius: 14px; background: #fff; flex: 0 0 auto; display: flex; align-items: center; justify-content: center; }
  .qr img { width: 128px; height: 128px; image-rendering: pixelated; display: block; }
  .side { flex: 1; min-width: 0; display: flex; flex-direction: column; gap: 7px; padding-top: 2px; }
  .kind { display: inline-block; align-self: flex-start; background: #2A2A33; color: #B9BDC6; font-size: 10px; font-weight: 600; border-radius: 10px; padding: 3px 8px; letter-spacing: 0.4px; text-transform: uppercase; }
  .data { font-size: 12px; line-height: 1.45; word-break: break-all; max-height: 92px; overflow: hidden; }
  .meta { font-size: 10px; color: #9AA0A6; line-height: 1.5; }
  .path { font-size: 9.5px; color: #8B8BF0; word-break: break-all; }
</style>
</head>
<body>
  <div class="wrap">
    <div class="qr"><img src="data:image/png;base64,${escapeHtml(base64)}" alt="QR code"/></div>
    <div class="side">
      <span class="kind">${escapeHtml(kind)} · QR</span>
      <div class="data">${escapeHtml(data)}</div>
      <div class="meta">${escapeHtml(String(size))}×${escapeHtml(String(size))} px · via ${escapeHtml(provider)}</div>
      ${savedPath ? `<div class="path">Saved: ${escapeHtml(savedPath)}</div>` : ""}
    </div>
  </div>
</body>
</html>`;
}

async function generateAndAppendQr(api: ArixExtensionApi, data: string): Promise<unknown> {
  const payload = String(data ?? "").trim();
  if (!payload) {
    api.notify("Enter some text or a link first, then tap QR Code.", "warning");
    return { error: "empty data" };
  }
  api.notify("Generating QR code…", "info");
  try {
    const result = await generateQrPng(payload, 300);
    let savedPath = "";
    try {
      const outputDir = join(homedir(), ".arix", "qr-codes");
      mkdirSync(outputDir, { recursive: true });
      const stamp = new Date().toISOString().replace(/[:.]/g, "-").slice(0, 19);
      const filePath = join(outputDir, `qr-${stamp}.png`);
      writeFileSync(filePath, result.bytes);
      savedPath = filePath;
    } catch {
      // Saving is best-effort.
    }
    await api.messages.append(
      "qr-code",
      {
        data: payload,
        kind: describeQrData(payload),
        base64: result.base64,
        size: result.size,
        provider: result.providerLabel,
        savedPath,
      },
      `QR code for: ${payload}`,
    );
    return { ok: true, provider: result.provider };
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);
    api.notify(`QR generation failed: ${message}`, "error");
    return { error: message };
  }
}

export const activateArix = async (arix: ArixExtensionApi) => {
  (globalThis as Record<PropertyKey, unknown>)[BRIDGE_KEY] = { api: arix } satisfies QrBridge;

  arix.registerToolTitle?.("qr_code", "Generating QR code", "Generated QR code", 200);

  /* Composer menu item: QR-encode the current draft instantly. */
  try {
    arix.registerComposerMenuItem({
      id: "qr-generate",
      title: "QR Code",
      subtitle: "Encode the composer text as a QR code",
      icon: "qr",
      order: 60,
      action: "qr_from_draft",
    });
  } catch {
    // Composer menu registration is best-effort.
  }

  arix.registerAction("qr_from_draft", async () => {
    let draft = "";
    try {
      const result = (await arix.state.get("draft_input")) as ArixJsonObject;
      const candidate = result?.value;
      draft = typeof candidate === "string" ? candidate : "";
    } catch {
      draft = "";
    }
    if (!draft.trim()) {
      const stored = arix.storage.get<string>("qr_last_input", "");
      if (stored) draft = stored;
    }
    if (!draft.trim()) {
      api_notify(arix, "Type the text or link to encode, then tap QR Code again.");
      return { error: "empty draft" };
    }
    return await generateAndAppendQr(arix, draft);
  });

  /* Settings page text input writes here (value-control dispatch contract). */
  arix.registerAction(
    `settings:${SETTINGS_PAGE_ID}:payload_input`,
    (payload) => {
      const value = String(payload.value ?? "");
      arix.storage.set("qr_last_input", value);
      return { ok: true };
    },
  );

  arix.registerAction("qr_quick_generate", async () => {
    const value = String(arix.storage.get<string>("qr_last_input", "") ?? "").trim();
    if (!value) {
      api_notify(arix, "Enter the text or link to encode first.");
      return { error: "empty input" };
    }
    return await generateAndAppendQr(arix, value);
  });

  arix.registerMessageType({
    type: "qr-code",
    title: "QR Code",
    icon: "qr",
    render: ({ message }) => {
      const payload = (message.payload ?? message) as unknown as ArixQrPayload;
      const base64 = String(payload?.base64 ?? "");
      if (!base64) {
        return arix.ui.card([
          arix.ui.text(String(payload?.data ?? "QR code"), { weight: 1 }),
          arix.ui.text("The QR image is no longer available.", { color: "muted" }),
        ], { radius: 16 });
      }
      return arix.ui.card([
        arix.ui.web({
          height: 172,
          html: qrCardHtml({
            data: String(payload?.data ?? ""),
            kind: String(payload?.kind ?? "Text"),
            base64,
            size: Number(payload?.size ?? 300),
            provider: String(payload?.provider ?? ""),
            savedPath: String(payload?.savedPath ?? ""),
          }),
        }),
      ], { radius: 16 });
    },
  });

  try {
    arix.registerSettings({
      id: SETTINGS_PAGE_ID,
      title: "QR Code Generator",
      subtitle: "Free open QR APIs with automatic fallback",
      icon: "qr",
      order: 50,
      categories: [
        {
          id: "quick",
          title: "Quick generate",
          subtitle: "Create a QR code without leaving Settings",
          icon: "qr",
          order: 0,
          sections: [
            {
              title: "QR payload",
              description: "Enter any text, link, email, phone number, or Wi-Fi string.",
              settings: [
                {
                  id: "payload_input",
                  type: "text",
                  label: "Text or link",
                  placeholder: "https://example.com",
                },
                {
                  id: "payload_generate",
                  type: "button",
                  label: "Generate QR code",
                  buttonLabel: "Generate QR code",
                  action: "qr_quick_generate",
                  tone: "primary",
                },
              ],
            },
          ],
        },
        {
          id: "providers",
          title: "Providers",
          subtitle: "Fallback order for QR generation",
          icon: "settings",
          order: 1,
          sections: [
            {
              title: "Free QR API fallbacks",
              description:
                "Requests walk down this list until a provider returns a valid PNG: " +
                "api.qrserver.com (goqr.me) → quickchart.io → qrtag.net. " +
                "All providers are free and keyless.",
              settings: [
                { id: "p1", type: "label", label: "1. api.qrserver.com", description: "Primary provider (goqr.me)" },
                { id: "p2", type: "label", label: "2. quickchart.io", description: "First fallback" },
                { id: "p3", type: "label", label: "3. qrtag.net", description: "Second fallback" },
              ],
            },
          ],
        },
      ],
    });
  } catch {
    // Settings registration is best-effort.
  }
};

function api_notify(api: ArixExtensionApi, message: string): void {
  try {
    api.notify(message, "info");
  } catch {
    // Notification is best-effort.
  }
}
