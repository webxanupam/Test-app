/**
 * QR Code Generator — Pi extension entry point.
 *
 * Registers the `qr_code` agent tool. The tool encodes any text or link into
 * a QR PNG through free QR APIs with automatic fallback, saves the image into
 * the workspace, and mirrors a rich QR card into the Arix conversation via
 * the bridge installed by arix.ts.
 */

import { mkdirSync, writeFileSync } from "node:fs";
import { join } from "node:path";
import type { AgentToolResult, ExtensionAPI } from "@earendil-works/pi-coding-agent";
import { Type } from "typebox";
import { describeQrData, generateQrPng } from "./qr.ts";
import { appendArixQrMessage } from "./arix.ts";

const TOOL_NAME = "qr_code";
const QR_OUTPUT_DIR = "qr-codes";

export function buildQrFileName(data: string): string {
  const stamp = new Date().toISOString().replace(/[:.]/g, "-").slice(0, 19);
  return `qr-${stamp}.png`;
}

export default function activateQrGenerator(pi: ExtensionAPI) {
  pi.registerTool({
    name: TOOL_NAME,
    label: "QR Code Generator",
    description:
      "Generate a scannable QR code image for any text, URL, email, phone number, " +
      "Wi-Fi payload, or contact card. Uses free open QR APIs with multiple " +
      "automatic fallbacks, saves the PNG into the workspace qr-codes/ directory, " +
      "and shows the QR code directly in the chat. Use this whenever the user " +
      "asks for a QR code.",
    promptSnippet: "Use when the user wants a QR code for a link or any text.",
    parameters: Type.Object({
      data: Type.String({ description: "The text, URL, or payload to encode into the QR code." }),
      size: Type.Optional(
        Type.Number({
          description: "Image size in pixels (120-1000, default 300).",
        }),
      ),
    }),

    async execute(
      _callId: string,
      params: { data: string; size?: number },
      _signal?: AbortSignal,
      _onUpdate?: unknown,
      ctx?: { cwd?: string },
    ): Promise<AgentToolResult<Record<string, unknown>>> {
      const data = String(params.data ?? "").trim();
      if (!data) {
        return {
          content: [{ type: "text", text: "Error: data is required to generate a QR code." }],
          details: { error: "missing data" },
        };
      }
      try {
        const result = await generateQrPng(data, params.size ?? 300);

        let savedPath = "";
        try {
          const outputDir = join(ctx?.cwd ?? process.cwd(), QR_OUTPUT_DIR);
          mkdirSync(outputDir, { recursive: true });
          const filePath = join(outputDir, buildQrFileName(data));
          writeFileSync(filePath, result.bytes);
          savedPath = filePath;
        } catch {
          // Saving is best-effort; the QR card still shows the image.
        }

        const summary =
          `QR code generated for: ${data}\n` +
          `Provider: ${result.providerLabel} · Size: ${result.size}×${result.size} px` +
          (savedPath ? `\nSaved to: ${savedPath}` : "");

        void appendArixQrMessage?.(
          "qr-code",
          {
            data,
            kind: describeQrData(data),
            base64: result.base64,
            size: result.size,
            provider: result.providerLabel,
            savedPath,
          },
          summary,
        );

        return {
          content: [{ type: "text", text: summary }],
          details: {
            data,
            provider: result.provider,
            size: result.size,
            savedPath,
          },
        };
      } catch (error) {
        const message = error instanceof Error ? error.message : String(error);
        return {
          content: [{ type: "text", text: `QR code generation failed: ${message}` }],
          details: { error: message },
        };
      }
    },
  });
}
