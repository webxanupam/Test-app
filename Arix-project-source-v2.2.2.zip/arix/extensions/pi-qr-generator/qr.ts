/**
 * QR Code Generator data layer.
 *
 * Generates QR code PNG images through a chain of free, keyless, open QR
 * APIs. Every provider is tried in order until one returns a valid PNG, so a
 * single dead endpoint never breaks QR generation:
 *
 *   1. api.qrserver.com  (goqr.me — the most widely used free QR API)
 *   2. quickchart.io     (open-source chart/QR service)
 *   3. qrtag.net         (minimal QR image API)
 *
 * Zero npm dependencies: uses the built-in Node fetch only.
 */

const REQUEST_TIMEOUT_MS = 20_000;

export interface QrProvider {
  id: string;
  label: string;
  buildUrl(data: string, size: number): string;
}

export const QR_PROVIDERS: QrProvider[] = [
  {
    id: "qrserver",
    label: "api.qrserver.com",
    buildUrl: (data, size) =>
      `https://api.qrserver.com/v1/create-qr-code/?size=${size}x${size}&format=png&data=${encodeURIComponent(data)}`,
  },
  {
    id: "quickchart",
    label: "quickchart.io",
    buildUrl: (data, size) =>
      `https://quickchart.io/qr?text=${encodeURIComponent(data)}&size=${size}&margin=1&dark=000000&light=ffffff`,
  },
  {
    id: "qrtag",
    label: "qrtag.net",
    buildUrl: (data, size) => {
      const bucket = size <= 120 ? 120 : size <= 250 ? 250 : size <= 500 ? 500 : 1000;
      return `https://qrtag.net/api/qr_${bucket}.png?url=${encodeURIComponent(data)}`;
    },
  },
];

export interface QrResult {
  base64: string;
  bytes: Uint8Array;
  size: number;
  provider: string;
  providerLabel: string;
  data: string;
}

function clampSize(size: number): number {
  if (!Number.isFinite(size)) return 300;
  return Math.min(Math.max(Math.round(size), 120), 1000);
}

async function fetchPng(url: string): Promise<Uint8Array> {
  const response = await fetch(url, {
    redirect: "follow",
    signal: AbortSignal.timeout(REQUEST_TIMEOUT_MS),
    headers: {
      Accept: "image/png,image/*;q=0.8,*/*;q=0.5",
      "User-Agent":
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 " +
        "(KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36",
    },
  });
  if (!response.ok) throw new Error(`HTTP ${response.status}`);
  const buffer = new Uint8Array(await response.arrayBuffer());
  // Minimal PNG signature check.
  if (buffer.length < 8 || buffer[0] !== 0x89 || buffer[1] !== 0x50) {
    throw new Error("Response is not a PNG image");
  }
  return buffer;
}

function toBase64(bytes: Uint8Array): string {
  let binary = "";
  const chunkSize = 0x8000;
  for (let index = 0; index < bytes.length; index += chunkSize) {
    binary += String.fromCharCode(...bytes.subarray(index, index + chunkSize));
  }
  return btoa(binary);
}

/** Generate a QR code PNG using the first working provider. */
export async function generateQrPng(data: string, size = 300): Promise<QrResult> {
  const payload = String(data ?? "");
  if (!payload.trim()) throw new Error("QR data must not be empty.");
  const clamped = clampSize(size);
  const failures: string[] = [];

  for (const provider of QR_PROVIDERS) {
    try {
      const bytes = await fetchPng(provider.buildUrl(payload, clamped));
      return {
        base64: toBase64(bytes),
        bytes,
        size: clamped,
        provider: provider.id,
        providerLabel: provider.label,
        data: payload,
      };
    } catch (error) {
      failures.push(`${provider.label}: ${error instanceof Error ? error.message : String(error)}`);
    }
  }
  throw new Error(`All QR providers failed — ${failures.join(" | ")}`);
}

/** Readable classification used on the generated card. */
export function describeQrData(data: string): string {
  const value = String(data ?? "").trim();
  if (/^https?:\/\//i.test(value)) return "Link";
  if (/^WIFI:/i.test(value)) return "Wi-Fi";
  if (/^mailto:/i.test(value) || /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value)) return "Email";
  if (/^tel:/i.test(value)) return "Phone";
  if (/^(SMSTO|MECARD|BEGIN:VCARD)/i.test(value)) return "Contact";
  if (/^geo:/i.test(value)) return "Location";
  if (/^\d+$/.test(value)) return "Number";
  return "Text";
}
