/**
 * Movie Explorer — Pi extension entry point.
 *
 * Registers the `movie_explorer` agent tool with three modes:
 *   - latest : list the newest movies added to the source site
 *   - search : find movies by name
 *   - play   : resolve a movie detail page into embed players + downloads
 *
 * The tool also mirrors rich results into the Arix conversation (poster grid
 * and multi-server player cards) through the bridge installed by arix.ts.
 */

import type { AgentToolResult, ExtensionAPI } from "@earendil-works/pi-coding-agent";
import { Type } from "typebox";
import {
  fetchLatestMovies,
  fetchMovieDetail,
  searchMovies,
  type MovieDetail,
  type MovieItem,
} from "./movies.ts";
import { appendArixMovieMessage } from "./arix.ts";

const TOOL_NAME = "movie_explorer";
const MAX_LIST_ITEMS = 24;

function formatListResult(mode: string, query: string, results: MovieItem[]): string {
  if (results.length === 0) {
    return mode === "search"
      ? `No movies found for "${query}".`
      : "Could not fetch the latest movies right now. Try again in a moment.";
  }
  const header = mode === "search"
    ? `Movies matching "${query}":`
    : "Latest movies on the site:";
  const lines = results
    .slice(0, MAX_LIST_ITEMS)
    .map((item, index) => {
      const views = item.views ? ` (${item.views})` : "";
      return `${index + 1}. ${item.title}${views}\n   ${item.url}`;
    });
  return [header, "", ...lines].join("\n");
}

function formatPlayResult(detail: MovieDetail): string {
  const parts: string[] = [];
  parts.push(detail.title || "Movie");
  if (detail.description) parts.push(detail.description);
  parts.push("");
  if (detail.servers.length > 0) {
    parts.push(`Stream servers (${detail.servers.length}):`);
    detail.servers.forEach((server, index) => {
      parts.push(`  ${index + 1}. ${server.label} — ${server.url}`);
    });
  } else {
    parts.push("No streaming servers were found on this page.");
  }
  if (detail.downloads.length > 0) {
    parts.push("");
    parts.push(`Download links (${detail.downloads.length}):`);
    detail.downloads.slice(0, 20).forEach((download) => {
      const quality = download.quality ? `[${download.quality}] ` : "";
      parts.push(`  ${quality}${download.label} — ${download.url}`);
    });
  }
  return parts.join("\n");
}

export default function activateMovieExplorer(pi: ExtensionAPI) {
  pi.registerTool({
    name: TOOL_NAME,
    label: "Movie Explorer",
    description:
      "Explore, search, and play movies from watchonlinemovies.com.pk. " +
      "Modes: 'latest' lists newly added movies; 'search' finds movies by name " +
      "(pass the movie name as query); 'play' resolves a movie detail URL into " +
      "playable embed servers and download links (pass the movie URL). " +
      "Use this tool whenever the user wants to watch, find, search, list, or " +
      "play a movie or asks for the latest movies.",
    promptSnippet:
      "Use for watching movies: latest movies, movie search, and movie playback with multiple servers.",
    parameters: Type.Object({
      mode: Type.Union([Type.Literal("latest"), Type.Literal("search"), Type.Literal("play")], {
        description: "Operation mode: latest, search, or play.",
      }),
      query: Type.Optional(Type.String({ description: "Movie name. Required for mode=search." })),
      url: Type.Optional(
        Type.String({ description: "Movie detail page URL. Required for mode=play." }),
      ),
      page: Type.Optional(
        Type.Number({ description: "Listing page number for mode=latest (default 1)." }),
      ),
      limit: Type.Optional(
        Type.Number({ description: "Maximum number of list results (default 20)." }),
      ),
    }),

    async execute(
      _callId: string,
      params: {
        mode: "latest" | "search" | "play";
        query?: string;
        url?: string;
        page?: number;
        limit?: number;
      },
      signal?: AbortSignal,
    ): Promise<AgentToolResult<Record<string, unknown>>> {
      const mode = params.mode;
      const limit = Math.min(Math.max(Math.floor(params.limit ?? 20), 1), 50);

      const aborted = () =>
        signal?.aborted === true
          ? {
              content: [{ type: "text" as const, text: "Movie Explorer was cancelled." }],
              details: { error: "cancelled" },
            }
          : undefined;

      /* ---------------------------------------------------------- latest */
      if (mode === "latest") {
        try {
          const page = Math.min(Math.max(Math.floor(params.page ?? 1), 1), 20);
          const results = await fetchLatestMovies(page);
          void appendArixMovieMessage("movie-list", {
            mode: "latest",
            query: "",
            page,
            results,
          }, formatListResult("latest", "", results));
          return {
            content: [{ type: "text", text: formatListResult("latest", "", results) }],
            details: { mode, page, count: results.length },
          };
        } catch (error) {
          const message = error instanceof Error ? error.message : String(error);
          return {
            content: [{ type: "text", text: `Latest movies fetch failed: ${message}` }],
            details: { error: message },
          };
        }
      }

      /* --------------------------------------------------------- search */
      if (mode === "search") {
        const query = (params.query ?? "").trim();
        if (!query) {
          return {
            content: [{ type: "text", text: "Error: query is required for mode=search." }],
            details: { error: "missing query" },
          };
        }
        try {
          const results = await searchMovies(query, limit);
          void appendArixMovieMessage("movie-list", {
            mode: "search",
            query,
            page: 1,
            results,
          }, formatListResult("search", query, results));
          return {
            content: [{ type: "text", text: formatListResult("search", query, results) }],
            details: { mode, query, count: results.length },
          };
        } catch (error) {
          const message = error instanceof Error ? error.message : String(error);
          return {
            content: [{ type: "text", text: `Movie search failed: ${message}` }],
            details: { error: message },
          };
        }
      }

      /* ----------------------------------------------------------- play */
      const url = (params.url ?? "").trim();
      if (!/^https?:\/\//.test(url)) {
        return {
          content: [{ type: "text", text: "Error: a movie detail page URL is required for mode=play." }],
          details: { error: "missing url" },
        };
      }
      try {
        const detail = await fetchMovieDetail(url);
        const cancelled = aborted();
        if (cancelled) return cancelled;
        void appendArixMovieMessage("movie-player", {
          mode: "play",
          title: detail.title,
          description: detail.description,
          thumbnail: detail.thumbnail,
          source: detail.source,
          url: detail.url,
          servers: detail.servers,
          downloads: detail.downloads.slice(0, 24),
          totalServers: detail.servers.length,
          totalDownloads: detail.downloads.length,
        }, formatPlayResult(detail));
        return {
          content: [{ type: "text", text: formatPlayResult(detail) }],
          details: {
            mode,
            url,
            title: detail.title,
            servers: detail.servers.length,
            downloads: detail.downloads.length,
          },
        };
      } catch (error) {
        const message = error instanceof Error ? error.message : String(error);
        return {
          content: [{ type: "text", text: `Movie playback lookup failed: ${message}` }],
          details: { error: message },
        };
      }
    },
  });
}
