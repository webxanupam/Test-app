/**
 * Movie Explorer data layer.
 *
 * Zero-dependency scraper for watchonlinemovies.com.pk (which permanently
 * redirects to www.watch-movies.com.pk). Provides:
 *   - fetchLatestMovies(page)  homepage listing (+ WP REST API fallback)
 *   - searchMovies(query)      WordPress REST search API (+ HTML fallback)
 *   - fetchMovieDetail(url)    detail page embeds (+ WP REST API fallback)
 *
 * Network strategy per request:
 *   1. try the origin directly (works from normal mobile networks)
 *   2. try the WordPress JSON REST API (survives Cloudflare HTML challenges;
 *      NOTE: the `_fields` query parameter triggers Cloudflare — never use it)
 *   3. fall back through a shuffled list of public CORS proxies
 */

export const WOMP_BASE = "https://www.watchonlinemovies.com.pk";
export const SITE_BASE = "https://www.watch-movies.com.pk";

const BROWSER_UA =
  "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 " +
  "(KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36";

const PROXIES = [
  "https://cors.caliph.my.id/",
  "https://proxy.it-mohmmed.workers.dev/?url=",
  "https://proxy.khacmanh-info.workers.dev/?url=",
  "https://proxy.khacdat-info.workers.dev/?url=",
  "https://proxy.nkm1703.workers.dev/?url=",
  "https://proxy.uneti-it.workers.dev/?url=",
  "https://proxy.teamvn1235.workers.dev/?url=",
  "https://proxy.zeronightpro.workers.dev/?url=",
  "https://proxy.manhrit.workers.dev/?url=",
  "https://proxy.cskh-n8n.workers.dev/?url=",
  "https://proxy.manhnguyenict.workers.dev/?url=",
  "https://proxy.nguyenmanhict.workers.dev/?url=",
  "https://proxy.cskh-zm.workers.dev/?url=",
  "https://proxy.tgb6jphrx7.workers.dev/?url=",
  "https://proxy.manhict.workers.dev/?url=",
  "https://api.allorigins.win/raw?url=",
  "https://api.codetabs.com/v1/proxy?quest=",
];

export interface MovieItem {
  title: string;
  url: string;
  thumbnail: string;
  views: string;
}

export interface MovieServer {
  label: string;
  url: string;
}

export interface MovieDownload {
  quality: string;
  label: string;
  url: string;
}

export interface MovieDetail {
  title: string;
  description: string;
  thumbnail: string;
  servers: MovieServer[];
  downloads: MovieDownload[];
  source: string;
  url: string;
}

function shuffle<T>(items: readonly T[]): T[] {
  const copy = [...items];
  for (let i = copy.length - 1; i > 0; i -= 1) {
    const j = Math.floor(Math.random() * (i + 1));
    [copy[i], copy[j]] = [copy[j], copy[i]];
  }
  return copy;
}

function normalizeUrl(raw: string): string {
  const value = raw.trim();
  if (value.startsWith("//")) return `https:${value}`;
  return value;
}

async function fetchTextDirect(url: string, timeoutMs: number): Promise<string> {
  const response = await fetch(url, {
    redirect: "follow",
    signal: AbortSignal.timeout(timeoutMs),
    headers: {
      "User-Agent": BROWSER_UA,
      Accept: "text/html,application/xhtml+xml,application/json;q=0.9,*/*;q=0.8",
      "Accept-Language": "en-US,en;q=0.9",
    },
  });
  if (!response.ok) throw new Error(`HTTP ${response.status}`);
  return await response.text();
}

async function fetchTextViaProxy(proxy: string, url: string, timeoutMs: number): Promise<string> {
  const proxied = `${proxy}${encodeURIComponent(url)}`;
  const response = await fetch(proxied, {
    redirect: "follow",
    signal: AbortSignal.timeout(timeoutMs),
    headers: {
      "User-Agent": BROWSER_UA,
      Accept: "*/*",
    },
  });
  if (!response.ok) throw new Error(`HTTP ${response.status}`);
  return await response.text();
}

/** Fetch a page as text: direct first, then shuffled proxies. */
export async function fetchPage(url: string, timeoutMs = 15_000): Promise<string> {
  const errors: string[] = [];
  try {
    const direct = await fetchTextDirect(url, timeoutMs);
    if (direct.includes("<")) return direct;
    errors.push("direct: non-HTML response");
  } catch (error) {
    errors.push(`direct: ${error instanceof Error ? error.message : String(error)}`);
  }
  // Try a bounded subset of proxies so a total failure surfaces quickly
  // instead of walking the entire list.
  for (const proxy of shuffle(PROXIES).slice(0, 5)) {
    try {
      const html = await fetchTextViaProxy(proxy, url, timeoutMs);
      if (typeof html === "string" && html.includes("<") && html.length > 500) return html;
    } catch {
      // try the next proxy
    }
  }
  throw new Error(`All fetch attempts failed for ${url} (${errors.join("; ")})`);
}

/** Fetch JSON from the WordPress REST API (direct, then via proxies). */
async function fetchApiJson(pathAndQuery: string, timeoutMs = 15_000): Promise<unknown> {
  const url = `${SITE_BASE}/wp-json/wp/v2/${pathAndQuery}`;
  const attempts: string[] = [];
  try {
    return JSON.parse(await fetchTextDirect(url, timeoutMs));
  } catch (error) {
    attempts.push(`direct: ${error instanceof Error ? error.message : String(error)}`);
  }
  for (const proxy of shuffle(PROXIES).slice(0, 4)) {
    try {
      const text = await fetchTextViaProxy(proxy, url, timeoutMs);
      return JSON.parse(text);
    } catch (error) {
      attempts.push(`proxy: ${error instanceof Error ? error.message : String(error)}`);
    }
  }
  throw new Error(`WP API failed for ${pathAndQuery} (${attempts.join("; ")})`);
}

function decodeEntities(input: string): string {
  return input
    .replace(/&nbsp;/gi, " ")
    .replace(/&amp;/gi, "&")
    .replace(/&quot;/gi, '"')
    .replace(/&#0?39;|&apos;|&#x27;/gi, "'")
    .replace(/&lt;/gi, "<")
    .replace(/&gt;/gi, ">")
    .replace(/&#8211;|&ndash;/gi, "-")
    .replace(/&#8212;|&mdash;/gi, "-")
    .replace(/&#8216;|&#8217;|&lsquo;|&rsquo;/gi, "'")
    .replace(/&#8220;|&#8221;|&ldquo;|&rdquo;/gi, '"')
    .replace(/&#(\d+);/g, (_match, code: string) => {
      const value = Number.parseInt(code, 10);
      return Number.isFinite(value) ? String.fromCodePoint(value) : "";
    })
    .replace(/\s+/g, " ")
    .trim();
}

function cleanTitle(raw: string): string {
  let title = decodeEntities(raw);
  if (title.includes(" - ")) title = title.split(" - ")[0].trim();
  if (title.includes(" | ")) title = title.split(" | ")[0].trim();
  return title;
}

/** Extract the movie listing from a listing page HTML. */
export function scrapeMovieListFromHtml(html: string): MovieItem[] {
  const results: MovieItem[] = [];
  const seen = new Set<string>();
  const blocks = html.split(/<div[^>]*class=["'][^"']*postbox[^"']*["'][^>]*>/i);
  const postBoxRegex = /<h2[^>]*>\s*<a[^>]+href=["']([^"']+)["'][^>]*(?:title=["']([^"']*)["'])?[^>]*>([\s\S]*?)<\/a>/i;
  const viewsRegex = /class=["'][^"']*views[^"']*["'][^>]*>([^<]+)</i;

  for (const block of blocks) {
    // Only keep a reasonable window of the block (before the next postbox).
    const segment = block.slice(0, 4000);
    const linkMatch = segment.match(postBoxRegex);
    if (!linkMatch) continue;
    const url = normalizeUrl(decodeEntities(linkMatch[1]));
    if (!/^https?:\/\//.test(url) || seen.has(url)) continue;

    const title = cleanTitle(linkMatch[2] || linkMatch[3] || "");
    if (!title) continue;

    const imgMatch = segment.match(
      /<img[^>]+?(?:data-wpfc-original-src|data-lazy-src|data-src|src)=["']([^"']+)["']/i,
    );
    let thumbnail = imgMatch ? normalizeUrl(decodeEntities(imgMatch[1])) : "";
    // Ignore the site logo and placeholder images.
    if (thumbnail.includes("logo") || thumbnail.includes("placeholder")) thumbnail = "";

    const viewsMatch = segment.match(viewsRegex);
    const views = viewsMatch ? decodeEntities(viewsMatch[1]).replace(/^views\s*:\s*/i, "") : "";

    seen.add(url);
    results.push({ title, url, thumbnail, views });
  }
  return results;
}

/* ---------------------------------------------------------------------------
 * WordPress REST API helpers (Cloudflare-resistant fallback paths).
 * Never append the `_fields` parameter: it triggers a Cloudflare challenge.
 * ------------------------------------------------------------------------ */

interface WpPostRecord {
  title?: { rendered?: string };
  link?: string;
  slug?: string;
  content?: { rendered?: string };
  excerpt?: { rendered?: string };
  yoast_head_json?: { og_image?: Array<{ url?: string }> };
}

function postRecordToMovieItem(post: WpPostRecord): MovieItem | undefined {
  const title = cleanTitle(String(post.title?.rendered ?? "").replace(/<[^>]+>/g, ""));
  const url = String(post.link ?? "");
  if (!title || !/^https?:\/\//.test(url)) return undefined;
  const thumbnail = String(post.yoast_head_json?.og_image?.[0]?.url ?? "");
  return {
    title,
    url,
    thumbnail: thumbnail && /^https?:\/\//.test(thumbnail) ? thumbnail : "",
    views: "",
  };
}

async function latestMoviesViaApi(page: number, limit: number): Promise<MovieItem[]> {
  const payload = await fetchApiJson(`posts?per_page=${Math.min(limit, 50)}&page=${page}`);
  if (!Array.isArray(payload)) return [];
  const items: MovieItem[] = [];
  for (const entry of payload) {
    if (!entry || typeof entry !== "object") continue;
    const item = postRecordToMovieItem(entry as WpPostRecord);
    if (item) items.push(item);
  }
  return items;
}

async function searchMoviesViaApi(query: string, limit: number): Promise<MovieItem[]> {
  const payload = await fetchApiJson(
    `search?per_page=${Math.min(Math.max(limit, 1), 50)}&search=${encodeURIComponent(query)}`,
  );
  if (!Array.isArray(payload)) return [];
  const results: MovieItem[] = [];
  for (const entry of payload) {
    if (!entry || typeof entry !== "object") continue;
    const record = entry as Record<string, unknown>;
    const title = typeof record.title === "string" ? record.title : "";
    const url = typeof record.url === "string" ? record.url : "";
    if (!title || !/^https?:\/\//.test(url)) continue;
    results.push({ title: cleanTitle(title), url, thumbnail: "", views: "" });
  }
  return results;
}

/** Search using the classic WordPress ?s= HTML results (used as a fallback). */
export async function searchMoviesViaHtml(query: string): Promise<MovieItem[]> {
  const searchUrl = `${WOMP_BASE}/?s=${encodeURIComponent(query)}`;
  const html = await fetchPage(searchUrl, 15_000);
  return scrapeMovieListFromHtml(html);
}

export async function searchMovies(query: string, limit = 20): Promise<MovieItem[]> {
  try {
    const apiResults = await searchMoviesViaApi(query, limit);
    if (apiResults.length > 0) return apiResults.slice(0, limit);
  } catch {
    // fall through to the HTML search
  }
  const htmlResults = await searchMoviesViaHtml(query);
  return htmlResults.slice(0, limit);
}

export async function fetchLatestMovies(page = 1, limit = 24): Promise<MovieItem[]> {
  const normalizedPage = Math.min(Math.max(Math.floor(page), 1), 20);
  const normalizedLimit = Math.min(Math.max(Math.floor(limit), 1), 50);
  try {
    const html = await fetchPage(
      normalizedPage > 1 ? `${WOMP_BASE}/page/${normalizedPage}/` : `${WOMP_BASE}/`,
      15_000,
    );
    const results = scrapeMovieListFromHtml(html);
    if (results.length > 0) return results.slice(0, normalizedLimit);
  } catch {
    // fall through to the REST API
  }
  return latestMoviesViaApi(normalizedPage, normalizedLimit);
}

const IFRAME_SRC_REGEX =
  /(?:data-wpfc-original-src|data-lazy-src|data-src|src)\s*=\s*["']([^"']+)["']/i;

function extractIframeSource(tag: string): string {
  const match = tag.match(IFRAME_SRC_REGEX);
  return match ? normalizeUrl(decodeEntities(match[1])) : "";
}

/** Extract embed players + download links from HTML content. */
export function scrapePlayersFromHtml(html: string): {
  servers: MovieServer[];
  downloads: MovieDownload[];
} {
  const servers: MovieServer[] = [];
  const downloads: MovieDownload[] = [];
  const seenDownloads = new Set<string>();

  // --- Embedded players: an <h2> label immediately followed by <p><iframe> ---
  const playerRegex = /<h2[^>]*>([\s\S]*?)<\/h2>\s*(?:<p[^>]*>)?\s*(<iframe[^>]*>)/gi;
  let playerMatch: RegExpExecArray | null;
  while ((playerMatch = playerRegex.exec(html)) !== null) {
    const label = decodeEntities(playerMatch[1].replace(/<[^>]+>/g, ""));
    const src = extractIframeSource(playerMatch[2]);
    if (!src) continue;
    if (/youtube\.com\/embed|google\.com\/maps/i.test(src)) continue;
    servers.push({
      label: label.replace(/\s*below\s*$/i, "").trim() || `Player ${servers.length + 1}`,
      url: src,
    });
  }

  // --- Fallback: every iframe that looks like a video host ---
  if (servers.length === 0) {
    const iframeRegex = /<iframe[^>]*>/gi;
    let iframeMatch: RegExpExecArray | null;
    let index = 0;
    while ((iframeMatch = iframeRegex.exec(html)) !== null) {
      const src = extractIframeSource(iframeMatch[0]);
      index += 1;
      if (!src) continue;
      if (/youtube\.com\/embed|google\.com\/maps/i.test(src)) continue;
      servers.push({ label: `Player ${index}`, url: src });
    }
  }

  // --- Download links: quality <h2> followed by a <p> with anchors ---
  const downloadRegex = /<h2[^>]*>([\s\S]*?)<\/h2>\s*<p[^>]*>([\s\S]*?)<\/p>/gi;
  let downloadMatch: RegExpExecArray | null;
  while ((downloadMatch = downloadRegex.exec(html)) !== null) {
    const quality = decodeEntities(downloadMatch[1].replace(/<[^>]+>/g, ""));
    const body = downloadMatch[2];
    if (!/quality|download|link/i.test(quality + body)) continue;
    const anchorRegex = /<a[^>]+href=["']([^"']+)["'][^>]*>([\s\S]*?)<\/a>/gi;
    let anchorMatch: RegExpExecArray | null;
    while ((anchorMatch = anchorRegex.exec(body)) !== null) {
      const href = normalizeUrl(decodeEntities(anchorMatch[1]));
      const label = decodeEntities(anchorMatch[2].replace(/<[^>]+>/g, ""));
      if (!/^https?:\/\//.test(href) || href === "#" || seenDownloads.has(href)) continue;
      if (/addtoany\.com|facebook\.com|twitter\.com|pinterest\.|whatsapp\.com|skype\.com/i.test(href)) continue;
      seenDownloads.add(href);
      downloads.push({
        quality: quality.replace(/\s*links?\s*$/i, "").trim(),
        label: label || quality,
        url: href,
      });
    }
  }

  // --- Generic download fallback for hosts known to serve files ---
  if (downloads.length === 0) {
    const genericRegex = /<a[^>]+href=["']([^"']+)["'][^>]*>([\s\S]*?)<\/a>/gi;
    let genericMatch: RegExpExecArray | null;
    while ((genericMatch = genericRegex.exec(html)) !== null) {
      const href = normalizeUrl(decodeEntities(genericMatch[1]));
      const label = decodeEntities(genericMatch[2].replace(/<[^>]+>/g, ""));
      if (!/^https?:\/\//.test(href)) continue;
      if (/pkembed|do7go|mxdrop|streamtape|clvideo|download|dood|mixdrop/i.test(`${href}${label}`)) {
        if (!seenDownloads.has(href)) {
          seenDownloads.add(href);
          downloads.push({ quality: "", label: label || "Download", url: href });
        }
      }
    }
  }

  return { servers, downloads };
}

function extractTitleFromHtml(html: string): string {
  const h1Match = html.match(/<h1[^>]*>([\s\S]*?)<\/h1>/i);
  const singTitleMatch = html.match(/class=["'][^"']*singtitle[^"']*["'][^>]*>([\s\S]*?)</i);
  const titleTagMatch = html.match(/<title>([\s\S]*?)<\/title>/i);
  const rawTitle =
    (h1Match && h1Match[1]) ||
    (singTitleMatch && singTitleMatch[1]) ||
    (titleTagMatch && titleTagMatch[1]) ||
    "";
  return cleanTitle(rawTitle.replace(/<[^>]+>/g, ""));
}

function extractThumbnailFromHtml(html: string): string {
  const posterMatch =
    html.match(
      /<img[^>]+?(?:data-wpfc-original-src|data-lazy-src|data-src|src)=["']([^"']+)["'][^>]*class=["'][^"']*wp-post-image[^"']*["']/i,
    ) ||
    html.match(
      /<img[^>]+?class=["'][^"']*wp-post-image[^"']*["'][^>]*?(?:data-wpfc-original-src|data-lazy-src|data-src|src)=["']([^"']+)["']/i,
    ) ||
    html.match(/<meta[^>]+property=["']og:image["'][^>]+content=["']([^"']+)["']/i);
  return posterMatch ? normalizeUrl(decodeEntities(posterMatch[1])) : "";
}

/** Extract a movie detail payload from a movie page HTML. */
export function scrapeMovieDetailFromHtml(html: string, pageUrl: string): MovieDetail {
  const { servers, downloads } = scrapePlayersFromHtml(html);
  const descriptionMatch = html.match(
    /class=["'][^"']*entry-content[^"']*["'][^>]*>([\s\S]*?)<\/p>/i,
  );
  const description = descriptionMatch
    ? decodeEntities(descriptionMatch[1].replace(/<[^>]+>/g, "")).slice(0, 400)
    : "";
  return {
    title: extractTitleFromHtml(html),
    description,
    thumbnail: extractThumbnailFromHtml(html),
    servers,
    downloads,
    source: "watchonlinemovies",
    url: pageUrl,
  };
}

/** Build a movie detail payload from a WordPress REST API post record. */
function detailFromPostRecord(post: WpPostRecord, pageUrl: string): MovieDetail {
  const content = String(post.content?.rendered ?? "");
  const { servers, downloads } = scrapePlayersFromHtml(content);
  const excerpt = decodeEntities(String(post.excerpt?.rendered ?? "").replace(/<[^>]+>/g, "")).slice(0, 400);
  const thumbnail = String(post.yoast_head_json?.og_image?.[0]?.url ?? "");
  return {
    title: cleanTitle(String(post.title?.rendered ?? "").replace(/<[^>]+>/g, "")),
    description: excerpt,
    thumbnail: thumbnail && /^https?:\/\//.test(thumbnail) ? thumbnail : "",
    servers,
    downloads,
    source: "watchonlinemovies",
    url: pageUrl,
  };
}

function slugFromUrl(url: string): string {
  try {
    const parsed = new URL(url);
    const segments = parsed.pathname.split("/").filter(Boolean);
    return segments[segments.length - 1] ?? "";
  } catch {
    return url.split("/").filter(Boolean).pop() ?? "";
  }
}

/** Resolve a movie detail page into playable servers + downloads. */
export async function fetchMovieDetail(pageUrl: string): Promise<MovieDetail> {
  // 1. Direct detail page fetch.
  try {
    const html = await fetchPage(pageUrl, 20_000);
    const detail = scrapeMovieDetailFromHtml(html, pageUrl);
    if (detail.servers.length > 0 || detail.title) return detail;
  } catch {
    // fall through to the REST API
  }

  // 2. WordPress REST API by slug (survives Cloudflare HTML challenges).
  const slug = slugFromUrl(pageUrl);
  if (slug) {
    const payload = await fetchApiJson(`posts?slug=${encodeURIComponent(slug)}`);
    if (Array.isArray(payload) && payload.length > 0) {
      const detail = detailFromPostRecord(payload[0] as WpPostRecord, pageUrl);
      if (detail.servers.length > 0 || detail.title) return detail;
    }
  }
  throw new Error(`Unable to load the movie page: ${pageUrl}`);
}
