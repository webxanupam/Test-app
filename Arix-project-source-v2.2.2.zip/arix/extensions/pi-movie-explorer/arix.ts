/**
 * Movie Explorer — Arix extension entry point.
 *
 * Renders rich message cards for the movie_explorer tool:
 *   - movie-list   : poster grid; tapping Play resolves servers instantly
 *   - movie-player : multi-server WebView player with download links
 *
 * Also installs the bridge used by index.ts (the Pi tool) to mirror results
 * into the Arix conversation, and a small settings page.
 */

import { fetchMovieDetail } from "./movies.ts";

type ArixJsonObject = Record<string, unknown>;
type ArixView = ArixJsonObject | ArixView[] | string | null | undefined;
type ArixRenderContext = ArixJsonObject & { storage: ArixJsonObject };
type ArixMessageTypeDefinition = {
  type: string;
  title?: string;
  icon?: string;
  render:
    | ArixView
    | ((context: ArixRenderContext & { message: ArixJsonObject }) => ArixView | Promise<ArixView>);
};
type ArixServer = { label: string; url: string };
type ArixDownload = { quality: string; label: string; url: string };
type ArixMovieItem = { title: string; url: string; thumbnail: string; views: string };
type ArixMovieListPayload = {
  mode: string;
  query: string;
  page: number;
  results: ArixMovieItem[];
};
type ArixMoviePlayerPayload = {
  title: string;
  description: string;
  thumbnail: string;
  source: string;
  url: string;
  servers: ArixServer[];
  downloads: ArixDownload[];
  totalServers: number;
  totalDownloads: number;
};
type ArixExtensionApi = {
  ui: {
    text(text: string, properties?: ArixJsonObject): ArixJsonObject;
    column(children: ArixView[], properties?: ArixJsonObject): ArixJsonObject;
    row(children: ArixView[], properties?: ArixJsonObject): ArixJsonObject;
    card(children: ArixView[], properties?: ArixJsonObject): ArixJsonObject;
    button(label: string, action: string, properties?: ArixJsonObject): ArixJsonObject;
    spacer(size?: number, properties?: ArixJsonObject): ArixJsonObject;
    web(properties: ArixJsonObject): ArixJsonObject;
  };
  host: { invoke(method: string, args?: ArixJsonObject): Promise<ArixJsonObject> };
  storage: {
    get<T = unknown>(key: string, fallback?: T): T;
    set(key: string, value: unknown): void;
  };
  messages: {
    append(type: string, payload?: ArixJsonObject, text?: string): Promise<ArixJsonObject>;
  };
  registerSettings(definition: ArixJsonObject): () => void;
  registerAction(
    id: string,
    handler: (payload: ArixJsonObject) => unknown | Promise<unknown>,
  ): () => void;
  registerMessageType(definition: ArixMessageTypeDefinition): () => void;
  registerToolTitle(
    toolName: string,
    runningTitle: string,
    completedTitle: string,
    priority?: number,
  ): () => void;
  notify(message: string, level?: "info" | "warning" | "error"): void;
  invalidate(): void;
};

const BRIDGE_KEY = Symbol.for("pi-movie-explorer.arix-bridge");
const SETTINGS_PAGE_ID = "movie-explorer-settings";

interface MovieBridge {
  api: ArixExtensionApi;
}

function escapeHtml(value: string): string {
  return String(value ?? "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}

function escapeJs(value: string): string {
  return JSON.stringify(String(value ?? ""));
}

/** Called by index.ts to mirror tool results into the Arix conversation. */
export async function appendArixMovieMessage(
  type: string,
  payload: ArixJsonObject,
  text = "",
): Promise<boolean> {
  const bridge = (globalThis as Record<PropertyKey, unknown>)[BRIDGE_KEY] as
    | MovieBridge
    | undefined;
  if (!bridge) return false;
  try {
    await bridge.api.messages.append(type, payload, text);
    return true;
  } catch {
    return false;
  }
}

/* ---------------------------------------------------------------------------
 * movie-list card: self-contained poster grid inside a WebView.
 * Tapping a poster signals the play_movie extension action, which resolves
 * the embed servers without a round-trip through the agent.
 * ------------------------------------------------------------------------ */

function movieListHtml(payload: ArixMovieListPayload): string {
  const results = Array.isArray(payload.results) ? payload.results.slice(0, 30) : [];
  const heading = payload.mode === "search"
    ? `Results for “${payload.query}”`
    : "Latest movies";
  const cards = results
    .map((item) => {
      const poster = item.thumbnail
        ? `<img class="poster" src="${escapeHtml(item.thumbnail)}" alt="" loading="lazy" onerror="this.style.visibility='hidden'"/>`
        : `<div class="poster poster-empty">🎬</div>`;
      const views = item.views ? `<div class="views">${escapeHtml(item.views)}</div>` : "";
      return `
        <div class="card">
          ${poster}
          <div class="meta">
            <div class="title" title="${escapeHtml(item.title)}">${escapeHtml(item.title)}</div>
            ${views}
            <button class="play" data-url="${escapeHtml(item.url)}" data-title="${escapeHtml(item.title)}">▶ Play</button>
          </div>
        </div>`;
    })
    .join("");

  return `<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1"/>
<style>
  * { box-sizing: border-box; margin: 0; padding: 0; -webkit-tap-highlight-color: transparent; }
  body { font-family: -apple-system, Roboto, 'Segoe UI', sans-serif; background: transparent; color: #ECECF1; }
  .head { display: flex; align-items: center; justify-content: space-between; padding: 10px 12px 8px; }
  .head .label { font-size: 13px; font-weight: 600; color: #ECECF1; }
  .head .count { font-size: 11px; color: #9AA0A6; }
  .grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(96px, 1fr)); gap: 10px; padding: 0 12px 12px; }
  .card { background: #1C1C22; border-radius: 12px; overflow: hidden; display: flex; flex-direction: column; }
  .poster { width: 100%; aspect-ratio: 2/3; object-fit: cover; background: #26262E; display: block; }
  .poster-empty { display: flex; align-items: center; justify-content: center; font-size: 28px; }
  .meta { padding: 7px 8px 9px; display: flex; flex-direction: column; gap: 3px; }
  .title { font-size: 11px; line-height: 1.25; height: 28px; overflow: hidden; display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; }
  .views { font-size: 9.5px; color: #9AA0A6; }
  .play { margin-top: 4px; border: 0; border-radius: 8px; background: #5B5BD6; color: white; font-size: 11px; font-weight: 600; padding: 6px 0; width: 100%; }
  .play:active { background: #4A4AB8; }
  .empty { padding: 18px 14px; text-align: center; color: #9AA0A6; font-size: 13px; }
</style>
</head>
<body>
  <div class="head">
    <span class="label">${escapeHtml(heading)}</span>
    <span class="count">${results.length} movie${results.length === 1 ? "" : "s"}</span>
  </div>
  ${results.length > 0 ? `<div class="grid">${cards}</div>` : `<div class="empty">No movies found.</div>`}
  <script>
    document.addEventListener('click', function (event) {
      const button = event.target.closest ? event.target.closest('.play') : null;
      if (!button) return;
      Arix.postMessage(JSON.stringify({
        action: 'play_movie',
        args: { url: button.getAttribute('data-url'), title: button.getAttribute('data-title') }
      }));
    });
  </script>
</body>
</html>`;
}

/* ---------------------------------------------------------------------------
 * movie-player card: server switcher + fullscreen embed + downloads.
 * ------------------------------------------------------------------------ */

function moviePlayerHtml(payload: ArixMoviePlayerPayload): string {
  const servers = Array.isArray(payload.servers) ? payload.servers : [];
  const downloads = Array.isArray(payload.downloads) ? payload.downloads.slice(0, 20) : [];
  const serverButtons = servers
    .map(
      (server, index) =>
        `<button class="tab${index === 0 ? " active" : ""}" data-src="${escapeHtml(server.url)}" data-index="${index}">${escapeHtml(server.label || `Player ${index + 1}`)}</button>`,
    )
    .join("");
  const downloadRows = downloads
    .map(
      (download) =>
        `<a class="dl" href="${escapeHtml(download.url)}" target="_blank" rel="noopener">${escapeHtml(
          `${download.quality ? `[${download.quality}] ` : ""}${download.label || "Download"}`,
        )}</a>`,
    )
    .join("");
  const poster = payload.thumbnail
    ? `<img class="thumb" src="${escapeHtml(payload.thumbnail)}" alt="" onerror="this.style.display='none'"/>`
    : "";

  return `<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1"/>
<style>
  * { box-sizing: border-box; margin: 0; padding: 0; -webkit-tap-highlight-color: transparent; }
  body { font-family: -apple-system, Roboto, 'Segoe UI', sans-serif; background: transparent; color: #ECECF1; }
  .head { display: flex; gap: 10px; align-items: center; padding: 10px 12px 8px; }
  .thumb { width: 44px; height: 60px; border-radius: 6px; object-fit: cover; background: #26262E; }
  .info { flex: 1; min-width: 0; }
  .title { font-size: 13.5px; font-weight: 600; line-height: 1.3; }
  .desc { font-size: 10.5px; color: #9AA0A6; margin-top: 2px; max-height: 26px; overflow: hidden; }
  .tabs { display: flex; gap: 6px; padding: 0 12px 8px; overflow-x: auto; }
  .tab { flex: 0 0 auto; border: 1px solid #33333D; background: #1C1C22; color: #C9CDD4; border-radius: 16px; font-size: 11px; font-weight: 600; padding: 6px 12px; }
  .tab.active { background: #5B5BD6; border-color: #5B5BD6; color: #fff; }
  .stage { margin: 0 12px; border-radius: 12px; overflow: hidden; background: #000; aspect-ratio: 16/9; }
  .stage iframe { width: 100%; height: 100%; border: 0; display: block; }
  .stage .fallback { display: flex; height: 100%; align-items: center; justify-content: center; color: #9AA0A6; font-size: 12px; text-align: center; padding: 12px; }
  .downloads { padding: 10px 12px 12px; }
  .downloads .label { font-size: 11px; font-weight: 600; color: #9AA0A6; margin-bottom: 6px; text-transform: uppercase; letter-spacing: 0.4px; }
  .dl { display: block; color: #8B8BF0; font-size: 12px; padding: 5px 0; text-decoration: none; }
  .dl:active { opacity: 0.7; }
</style>
</head>
<body>
  <div class="head">
    ${poster}
    <div class="info">
      <div class="title">${escapeHtml(payload.title || "Now playing")}</div>
      ${payload.description ? `<div class="desc">${escapeHtml(payload.description)}</div>` : ""}
    </div>
  </div>
  ${
    servers.length > 0
      ? `<div class="tabs">${serverButtons}</div>
  <div class="stage"><iframe id="player" src="${escapeHtml(servers[0].url)}" allowfullscreen allow="autoplay; fullscreen; encrypted-media"></iframe></div>`
      : `<div class="stage"><div class="fallback">No streaming servers found for this title.</div></div>`
  }
  ${downloads.length > 0 ? `<div class="downloads"><div class="label">Downloads</div>${downloadRows}</div>` : ""}
  <script>
    var current = 0;
    var tabs = Array.prototype.slice.call(document.querySelectorAll('.tab'));
    tabs.forEach(function (tab) {
      tab.addEventListener('click', function () {
        tabs.forEach(function (other) { other.classList.remove('active'); });
        tab.classList.add('active');
        var frame = document.getElementById('player');
        if (frame) frame.src = tab.getAttribute('data-src');
        current = Number(tab.getAttribute('data-index')) || 0;
      });
    });
    window.__arixMovieState = { servers: ${escapeJs(JSON.stringify(servers))}, current: current };
  </script>
</body>
</html>`;
}

export const activateArix = async (arix: ArixExtensionApi) => {
  (globalThis as Record<PropertyKey, unknown>)[BRIDGE_KEY] = { api: arix } satisfies MovieBridge;

  arix.registerToolTitle?.("movie_explorer", "Exploring movies", "Explored movies", 200);

  /* Direct play from the poster grid: no agent round-trip needed. */
  arix.registerAction("play_movie", async (payload) => {
    const url = String(payload.url ?? "").trim();
    if (!/^https?:\/\//.test(url)) {
      arix.notify("A movie URL is required to start playback.", "error");
      return { error: "missing url" };
    }
    const requestedTitle = String(payload.title ?? "");
    arix.notify(`Loading player: ${requestedTitle || url}`, "info");
    try {
      const detail = await fetchMovieDetail(url);
      const downloads = (detail.downloads || []).slice(0, 24);
      await arix.messages.append(
        "movie-player",
        {
          mode: "play",
          title: detail.title || requestedTitle,
          description: detail.description,
          thumbnail: detail.thumbnail,
          source: detail.source,
          url: detail.url,
          servers: detail.servers,
          downloads,
          totalServers: detail.servers.length,
          totalDownloads: detail.downloads.length,
        },
        `Playing "${detail.title || requestedTitle}" — ${detail.servers.length} stream(s), ${detail.downloads.length} download(s).`,
      );
      if (detail.servers.length === 0) {
        arix.notify("No playable servers were found on that page.", "warning");
      }
      return { ok: true, servers: detail.servers.length };
    } catch (error) {
      const message = error instanceof Error ? error.message : String(error);
      arix.notify(`Playback failed: ${message}`, "error");
      return { error: message };
    }
  });

  arix.registerMessageType({
    type: "movie-list",
    title: "Movie Explorer",
    icon: "play",
    render: ({ message }) => {
      const payload = (message.payload ?? message) as unknown as ArixMovieListPayload;
      const results = Array.isArray(payload?.results) ? payload.results : [];
      const summary = payload?.mode === "search"
        ? `${results.length} result(s) for “${payload.query ?? ""}”`
        : `${results.length} latest movie(s)`;
      return arix.ui.card([
        arix.ui.web({
          height: results.length > 0 ? 420 : 120,
          html: movieListHtml({
            mode: String(payload?.mode ?? "latest"),
            query: String(payload?.query ?? ""),
            page: Number(payload?.page ?? 1),
            results,
          }),
        }),
        arix.ui.text(summary, { style: "caption", color: "muted" }),
      ], { radius: 16, spacing: 6 });
    },
  });

  arix.registerMessageType({
    type: "movie-player",
    title: "Movie Player",
    icon: "play",
    render: ({ message }) => {
      const payload = (message.payload ?? message) as unknown as ArixMoviePlayerPayload;
      const servers = Array.isArray(payload?.servers) ? payload.servers : [];
      const downloads = Array.isArray(payload?.downloads) ? payload.downloads : [];
      return arix.ui.card([
        arix.ui.web({
          height: servers.length > 0 ? 400 : 260,
          html: moviePlayerHtml({
            title: String(payload?.title ?? ""),
            description: String(payload?.description ?? ""),
            thumbnail: String(payload?.thumbnail ?? ""),
            source: String(payload?.source ?? "watchonlinemovies"),
            url: String(payload?.url ?? ""),
            servers,
            downloads,
            totalServers: servers.length,
            totalDownloads: downloads.length,
          }),
        }),
        arix.ui.row([
          arix.ui.text(
            `${servers.length} server(s) · ${downloads.length} download(s)`,
            { style: "caption", color: "muted" },
          ),
        ], { arrangement: "space-between", verticalAlignment: "center" }),
      ], { radius: 16, spacing: 6 });
    },
  });

  try {
    arix.registerSettings({
      id: SETTINGS_PAGE_ID,
      title: "Movie Explorer",
      subtitle: "Movie search, latest releases, and multi-server playback",
      icon: "play",
      order: 40,
      categories: [
        {
          id: "about",
          title: "About",
          subtitle: "Source and behaviour",
          icon: "info",
          order: 0,
          sections: [
            {
              title: "Movie source",
              description:
                "Movies are sourced from watchonlinemovies.com.pk (watch-movies.com.pk). " +
                "Search uses the site's JSON search API; listings and players are read " +
                "directly with public proxy fallbacks when the origin is unreachable.",
              settings: [
                {
                  id: "source_note",
                  type: "label",
                  label: "Source",
                  description: "watchonlinemovies.com.pk — latest movies, search, and multi-server playback",
                },
                {
                  id: "usage_hint",
                  type: "label",
                  label: "How to use",
                  description: "Ask the agent for the latest movies or search by name, then tap Play on any poster.",
                },
              ],
            },
          ],
        },
      ],
    });
  } catch {
    // Settings registration is best-effort; older hosts may reject categories.
  }
};
