package com.arix.app.ui

import android.annotation.SuppressLint
import android.graphics.Typeface
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Code
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.Extension
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.Link
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.QrCode2
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.Terminal
import androidx.compose.material.icons.rounded.WarningAmber
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.arix.app.data.ArixAppExtensionSnapshot
import com.arix.app.mod.ArixNativeComponentContext
import com.arix.app.mod.ArixNativeComponentMode
import com.arix.app.mod.ArixNativeComponentRegistration
import com.arix.app.mod.ArixNativeHost
import com.arix.app.ui.theme.ArixBackground
import com.arix.app.ui.theme.ArixOnPrimary
import com.arix.app.ui.theme.ArixOnSurface
import com.arix.app.ui.theme.ArixOnSurfaceVariant
import com.arix.app.ui.theme.ArixPrimary
import com.arix.app.ui.theme.ArixSurface
import com.arix.app.ui.theme.ArixSurfaceHigh
import com.arix.app.ui.theme.ArixSurfaceHigher
import org.json.JSONArray
import org.json.JSONObject

const val ArixExtensionSlotAppOverlay = "app.overlay"
const val ArixExtensionSlotChatTop = "chat.top"
const val ArixExtensionSlotChatEmpty = "chat.empty"
const val ArixExtensionSlotChatListStart = "chat.list.start"
const val ArixExtensionSlotChatListEnd = "chat.list.end"
const val ArixExtensionSlotChatComposerTop = "chat.composer.top"
const val ArixExtensionSlotChatComposerPlusMenu = "chat.composer.plus-menu"
const val ArixExtensionSlotSettingsHub = "settings.hub"
const val ArixExtensionSlotDrawer = "drawer"
const val ArixExtensionSlotDrawerHeader = "drawer.header"
const val ArixExtensionSlotDrawerFooter = "drawer.footer"
const val ArixExtensionSlotDrawerListEnd = "drawer.list.end"

const val ArixExtensionComponentChatComposerActionTray = "chat.composer.actionTray"
const val ArixExtensionComponentChatComposerSkillPicker = "chat.composer.skillPicker"
const val ArixExtensionComponentAppContent = "app.content"
const val ArixExtensionComponentChatScreen = "chat.screen"
const val ArixExtensionComponentSettingsScreen = "settings.screen"

@Immutable
data class ArixExtensionUiController(
    val snapshot: ArixAppExtensionSnapshot,
    val runtimeError: String,
    val nativeComponents: List<ArixNativeComponentRegistration>,
    val uiState: ArixUiState,
    val publicState: JSONObject,
    val onHostCall: suspend (String, JSONObject) -> JSONObject,
    val onAction: (String, String, JSONObject) -> Unit,
)

val LocalArixExtensionUiController =
    staticCompositionLocalOf<ArixExtensionUiController?> { null }

@Composable
fun ArixExtensionSlot(
    slot: String,
    modifier: Modifier = Modifier,
    spacing: Int = 10,
) {
    val controller = LocalArixExtensionUiController.current ?: return
    val surfaces = controller.snapshot.surfacesAt(slot)
    if (surfaces.isEmpty()) return
    Column(
        modifier = modifier,
        verticalArrangement = Arrangement.spacedBy(spacing.dp),
    ) {
        surfaces.forEach { surface ->
            key(surface.id) {
                ArixExtensionView(
                    value = surface.tree,
                    extensionId = surface.extensionId,
                )
            }
        }
    }
}

@Composable
fun ArixExtensionOverlaySlot(
    modifier: Modifier = Modifier,
) {
    val controller = LocalArixExtensionUiController.current ?: return
    val surfaces = controller.snapshot.surfacesAt(ArixExtensionSlotAppOverlay)
    if (surfaces.isEmpty()) return
    Box(modifier = modifier) {
        surfaces.forEach { surface ->
            key(surface.id) {
                ArixExtensionView(
                    value = surface.tree,
                    extensionId = surface.extensionId,
                )
            }
        }
    }
}

@Composable
fun ArixExtensionComponentHost(
    target: String,
    modifier: Modifier = Modifier,
    content: @Composable () -> Unit,
) {
    val controller = LocalArixExtensionUiController.current
    val nativeComponents = controller?.nativeComponents
        ?.filter { it.target == target }
        ?.sortedWith(
            compareBy<ArixNativeComponentRegistration> { it.priority }
                .thenBy { it.sequence }
        )
        .orEmpty()
    if (nativeComponents.isEmpty()) {
        ArixScriptExtensionComponentHost(
            target = target,
            modifier = modifier,
            content = content,
        )
        return
    }

    val nativeController = requireNotNull(controller)
    val nativeContext = ArixNativeComponentContext(
        target = target,
        uiState = nativeController.uiState,
        publicState = nativeController.publicState,
        host = ArixNativeHost { method, args ->
            nativeController.onHostCall(method, args)
        },
    )
    val before = nativeComponents.filter { it.mode == ArixNativeComponentMode.Before }
    val after = nativeComponents.filter { it.mode == ArixNativeComponentMode.After }
    val decisive = nativeComponents.lastOrNull { component ->
        component.mode == ArixNativeComponentMode.Replace ||
            component.mode == ArixNativeComponentMode.Hide
    }
    var center: @Composable () -> Unit = when (decisive?.mode) {
        ArixNativeComponentMode.Hide -> ({})
        ArixNativeComponentMode.Replace -> ({
            decisive.renderer?.render(nativeContext) {}
        })
        else -> ({
            ArixScriptExtensionComponentHost(
                target = target,
                content = content,
            )
        })
    }
    nativeComponents
        .filter { it.mode == ArixNativeComponentMode.Wrap }
        .forEach { component ->
            val nested = center
            center = {
                component.renderer?.render(nativeContext, nested)
            }
        }

    Column(
        modifier = modifier,
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        before.forEach { component ->
            key("${component.owner}:${component.id}") {
                component.renderer?.render(nativeContext) {}
            }
        }
        center()
        after.forEach { component ->
            key("${component.owner}:${component.id}") {
                component.renderer?.render(nativeContext) {}
            }
        }
    }
}

@Composable
private fun ArixScriptExtensionComponentHost(
    target: String,
    modifier: Modifier = Modifier,
    content: @Composable () -> Unit,
) {
    val controller = LocalArixExtensionUiController.current
    val components = controller?.snapshot?.componentsAt(target).orEmpty()
    if (components.isEmpty()) {
        content()
        return
    }

    val before = components.filter { it.mode.equals("before", ignoreCase = true) }
    val after = components.filter { it.mode.equals("after", ignoreCase = true) }
    val decisive = components.lastOrNull { component ->
        component.mode.equals("replace", ignoreCase = true) ||
            component.mode.equals("hide", ignoreCase = true)
    }
    var center: @Composable () -> Unit = when {
        decisive?.mode.equals("hide", ignoreCase = true) -> ({})
        decisive?.mode.equals("replace", ignoreCase = true) -> ({
            ArixExtensionView(
                value = decisive?.tree,
                extensionId = decisive?.extensionId.orEmpty(),
            )
        })
        else -> content
    }
    components
        .filter { it.mode.equals("wrap", ignoreCase = true) }
        .forEach { component ->
            val nested = center
            center = {
                ArixExtensionView(
                    value = component.tree,
                    extensionId = component.extensionId,
                    nativeContent = nested,
                )
            }
        }

    Column(
        modifier = modifier,
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        before.forEach { component ->
            key(component.id) {
                ArixExtensionView(
                    value = component.tree,
                    extensionId = component.extensionId,
                )
            }
        }
        center()
        after.forEach { component ->
            key(component.id) {
                ArixExtensionView(
                    value = component.tree,
                    extensionId = component.extensionId,
                )
            }
        }
    }
}

@Composable
private fun ArixExtensionView(
    value: Any?,
    extensionId: String,
    modifier: Modifier = Modifier,
    nativeContent: (@Composable () -> Unit)? = null,
) {
    when (value) {
        null,
        JSONObject.NULL -> Unit

        is String -> Text(
            text = value,
            color = ArixOnSurface,
            style = MaterialTheme.typography.bodyMedium,
            modifier = modifier,
        )

        is JSONArray -> Column(
            modifier = modifier,
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            for (index in 0 until value.length()) {
                key(index) {
                    ArixExtensionView(
                        value = value.opt(index),
                        extensionId = extensionId,
                        nativeContent = nativeContent,
                    )
                }
            }
        }

        is JSONObject -> ArixExtensionNode(
            node = value,
            extensionId = extensionId,
            modifier = modifier,
            nativeContent = nativeContent,
        )

        else -> Text(
            text = value.toString(),
            color = ArixOnSurface,
            style = MaterialTheme.typography.bodyMedium,
            modifier = modifier,
        )
    }
}

@Composable
@OptIn(ExperimentalLayoutApi::class)
private fun ArixExtensionNode(
    node: JSONObject,
    extensionId: String,
    modifier: Modifier = Modifier,
    nativeContent: (@Composable () -> Unit)? = null,
) {
    val controller = LocalArixExtensionUiController.current ?: return
    val type = node.optString("type", "column")
    val resolvedModifier = nodeModifier(modifier, node)
    val action = node.optString("action").trim()
    val actionArgs = node.optJSONObject("args") ?: JSONObject()
    val clickableModifier = if (action.isNotBlank()) {
        resolvedModifier.clickable {
            controller.onAction(extensionId, action, actionArgs)
        }
    } else {
        resolvedModifier
    }

    when (type.lowercase()) {
        "text",
        "code" -> {
            val text = node.optString("text")
            Text(
                text = text,
                modifier = clickableModifier,
                color = extensionColor(node.optString("color")).takeUnless {
                    node.optString("color").isBlank()
                } ?: ArixOnSurface,
                style = extensionTextStyle(node, code = type.equals("code", ignoreCase = true)),
                fontWeight = extensionFontWeight(node.optString("weight")),
                textAlign = extensionTextAlign(node.optString("align")),
                maxLines = node.optInt("maxLines", Int.MAX_VALUE).coerceAtLeast(1),
                overflow = TextOverflow.Ellipsis,
            )
        }

        "row" -> {
            val rowModifier = if (node.has("width")) {
                clickableModifier
            } else {
                clickableModifier.fillMaxWidth()
            }
            if (node.optBoolean("wrap")) {
                FlowRow(
                    modifier = rowModifier,
                    horizontalArrangement = extensionHorizontalArrangement(node.optString("arrangement")),
                    verticalArrangement = Arrangement.spacedBy(
                        node.optDouble("rowSpacing", 8.0).dp
                    ),
                    maxItemsInEachRow = node.optInt(
                        "maxItemsInEachRow",
                        Int.MAX_VALUE,
                    ).coerceAtLeast(1),
                ) {
                    renderChildren(node.optJSONArray("children"), extensionId, nativeContent)
                }
            } else {
                Row(
                    modifier = rowModifier,
                    horizontalArrangement = extensionHorizontalArrangement(node.optString("arrangement")),
                    verticalAlignment = extensionVerticalAlignment(node.optString("verticalAlignment")),
                ) {
                    renderRowChildren(node.optJSONArray("children"), extensionId, nativeContent)
                }
            }
        }

        "box" -> Box(
            modifier = clickableModifier,
            contentAlignment = extensionBoxAlignment(node.optString("alignment")),
        ) {
            renderChildren(node.optJSONArray("children"), extensionId, nativeContent)
        }

        "card" -> Column(
            modifier = clickableModifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(node.optDouble("radius", 20.0).dp))
                .background(cardColor(node.optString("tone")))
                .padding(node.optDouble("contentPadding", 16.0).dp),
            verticalArrangement = Arrangement.spacedBy(node.optDouble("spacing", 8.0).dp),
        ) {
            renderChildren(node.optJSONArray("children"), extensionId, nativeContent)
        }

        "scroll",
        "column" -> {
            val scrollable = node.optBoolean("scroll", type.equals("scroll", ignoreCase = true))
            Column(
                modifier = if (scrollable) {
                    clickableModifier.verticalScroll(rememberScrollState())
                } else {
                    clickableModifier
                },
                verticalArrangement = extensionVerticalArrangement(node.optString("arrangement")),
                horizontalAlignment = extensionHorizontalAlignment(node.optString("horizontalAlignment")),
            ) {
                renderChildren(node.optJSONArray("children"), extensionId, nativeContent)
            }
        }

        "core",
        "next" -> Box(modifier = resolvedModifier) {
            nativeContent?.invoke()
        }

        "button" -> Button(
            onClick = {
                if (action.isNotBlank()) {
                    controller.onAction(extensionId, action, actionArgs)
                }
            },
            enabled = node.optBoolean("enabled", true),
            modifier = resolvedModifier,
            shape = RoundedCornerShape(node.optDouble("radius", 18.0).dp),
            colors = ButtonDefaults.buttonColors(
                containerColor = when (node.optString("tone")) {
                    "neutral", "secondary" -> ArixSurfaceHigher
                    "danger", "error" -> MaterialTheme.colorScheme.errorContainer
                    else -> ArixPrimary
                },
                contentColor = when (node.optString("tone")) {
                    "neutral", "secondary" -> ArixOnSurface
                    "danger", "error" -> MaterialTheme.colorScheme.onErrorContainer
                    else -> ArixOnPrimary
                },
            ),
        ) {
            node.optString("icon").takeIf(String::isNotBlank)?.let { icon ->
                Icon(
                    imageVector = extensionIcon(icon),
                    contentDescription = null,
                    modifier = Modifier.size(18.dp),
                )
                Spacer(Modifier.width(8.dp))
            }
            Text(
                text = node.optString("label", node.optString("text")),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }

        "iconbutton" -> IconButton(
            onClick = {
                if (action.isNotBlank()) {
                    controller.onAction(extensionId, action, actionArgs)
                }
            },
            enabled = node.optBoolean("enabled", true),
            modifier = resolvedModifier
                .clip(CircleShape)
                .background(ArixSurfaceHigh),
        ) {
            Icon(
                imageVector = extensionIcon(node.optString("icon")),
                contentDescription = node.optString("contentDescription").ifBlank { null },
                tint = extensionColor(node.optString("color")).takeUnless {
                    node.optString("color").isBlank()
                } ?: ArixOnSurface,
            )
        }

        "switch" -> {
            val checked = node.optBoolean("checked")
            Row(
                modifier = resolvedModifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(18.dp))
                    .background(ArixSurfaceHigh)
                    .clickable {
                        if (action.isNotBlank()) {
                            controller.onAction(
                                extensionId,
                                action,
                                JSONObject(actionArgs.toString()).put("checked", !checked),
                            )
                        }
                    }
                    .padding(horizontal = 14.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = node.optString("label"),
                        color = ArixOnSurface,
                        style = MaterialTheme.typography.bodyLarge,
                    )
                    node.optString("subtitle").takeIf(String::isNotBlank)?.let { subtitle ->
                        Text(
                            text = subtitle,
                            color = ArixOnSurfaceVariant,
                            style = MaterialTheme.typography.bodySmall,
                        )
                    }
                }
                Switch(
                    checked = checked,
                    onCheckedChange = { next ->
                        if (action.isNotBlank()) {
                            controller.onAction(
                                extensionId,
                                action,
                                JSONObject(actionArgs.toString()).put("checked", next),
                            )
                        }
                    },
                    colors = SwitchDefaults.colors(
                        checkedTrackColor = ArixPrimary,
                        checkedThumbColor = ArixOnPrimary,
                    ),
                )
            }
        }

        "input", "select", "slider" -> {
            val externalValue = node.optString("value")
            var value by remember(node.optString("id"), externalValue) {
                mutableStateOf(externalValue)
            }
            val submit: () -> Unit = {
                if (action.isNotBlank()) {
                    controller.onAction(
                        extensionId,
                        action,
                        JSONObject(actionArgs.toString()).put("value", value),
                    )
                }
            }
            BasicTextField(
                value = value,
                onValueChange = { next ->
                    value = next
                    if (node.optString("dispatch") == "change") submit()
                },
                modifier = resolvedModifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(node.optDouble("radius", 18.0).dp))
                    .background(ArixSurfaceHigh)
                    .padding(horizontal = 14.dp, vertical = 12.dp),
                enabled = node.optBoolean("enabled", true),
                singleLine = node.optBoolean("singleLine", true),
                textStyle = MaterialTheme.typography.bodyMedium.copy(color = ArixOnSurface),
                cursorBrush = SolidColor(ArixPrimary),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                keyboardActions = KeyboardActions(onDone = { submit() }),
                decorationBox = { innerField ->
                    Box(contentAlignment = Alignment.CenterStart) {
                        if (value.isBlank()) {
                            Text(
                                text = node.optString("placeholder"),
                                color = ArixOnSurfaceVariant,
                                style = MaterialTheme.typography.bodyMedium,
                            )
                        }
                        innerField()
                    }
                },
            )
        }

        "spacer" -> {
            val size = node.optDouble("size", 8.0).dp
            Spacer(
                modifier = resolvedModifier
                    .height(node.optDouble("height", size.value.toDouble()).dp)
                    .width(node.optDouble("width", size.value.toDouble()).dp)
            )
        }

        "progress" -> {
            val value = node.optDouble("value", Double.NaN)
            if (value.isNaN()) {
                CircularProgressIndicator(
                    modifier = resolvedModifier.size(node.optDouble("size", 24.0).dp),
                    strokeWidth = node.optDouble("strokeWidth", 2.0).dp,
                    color = ArixPrimary,
                )
            } else {
                CircularProgressIndicator(
                    progress = { value.toFloat().coerceIn(0f, 1f) },
                    modifier = resolvedModifier.size(node.optDouble("size", 24.0).dp),
                    strokeWidth = node.optDouble("strokeWidth", 2.0).dp,
                    color = ArixPrimary,
                )
            }
        }

        "web" -> ArixExtensionWebView(
            node = node,
            extensionId = extensionId,
            modifier = resolvedModifier,
        )

        else -> Column(
            modifier = clickableModifier,
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            renderChildren(node.optJSONArray("children"), extensionId, nativeContent)
        }
    }
}

@Composable
private fun renderChildren(
    children: JSONArray?,
    extensionId: String,
    nativeContent: (@Composable () -> Unit)? = null,
) {
    if (children == null) return
    for (index in 0 until children.length()) {
        key(index) {
            ArixExtensionView(
                value = children.opt(index),
                extensionId = extensionId,
                nativeContent = nativeContent,
            )
        }
    }
}

@Composable
private fun RowScope.renderRowChildren(
    children: JSONArray?,
    extensionId: String,
    nativeContent: (@Composable () -> Unit)? = null,
) {
    if (children == null) return
    for (index in 0 until children.length()) {
        key(index) {
            val child = children.opt(index)
            val weight = (child as? JSONObject)
                ?.optDoubleOrNull("weight")
                ?.toFloat()
                ?.takeIf { it > 0f }
            ArixExtensionView(
                value = child,
                extensionId = extensionId,
                modifier = if (weight != null) Modifier.weight(weight) else Modifier,
                nativeContent = nativeContent,
            )
        }
    }
}

@Composable
private fun nodeModifier(
    base: Modifier,
    node: JSONObject,
): Modifier {
    var modifier = base
    when (node.optString("width")) {
        "fill", "match" -> modifier = modifier.fillMaxWidth()
        "full" -> modifier = modifier.fillMaxSize()
        else -> node.optDoubleOrNull("width")?.let { modifier = modifier.width(it.dp) }
    }
    when (node.optString("height")) {
        "fill", "match" -> modifier = modifier.fillMaxHeight()
        "full" -> modifier = modifier.fillMaxSize()
        else -> node.optDoubleOrNull("height")?.let { modifier = modifier.height(it.dp) }
    }
    node.optDoubleOrNull("minHeight")?.let { modifier = modifier.heightIn(min = it.dp) }
    node.optDoubleOrNull("maxHeight")?.let { modifier = modifier.heightIn(max = it.dp) }
    node.optDoubleOrNull("alpha")?.let { modifier = modifier.alpha(it.toFloat().coerceIn(0f, 1f)) }
    val radius = node.optDouble("radius", 0.0)
    val background = node.optString("background")
    if (background.isNotBlank()) {
        val shape = RoundedCornerShape(radius.dp)
        modifier = modifier
            .clip(shape)
            .background(extensionColor(background))
    }
    val padding = node.opt("padding")
    modifier = when (padding) {
        is Number -> modifier.padding(padding.toDouble().dp)
        is JSONObject -> modifier.padding(
            start = padding.optDouble("start", padding.optDouble("horizontal", 0.0)).dp,
            top = padding.optDouble("top", padding.optDouble("vertical", 0.0)).dp,
            end = padding.optDouble("end", padding.optDouble("horizontal", 0.0)).dp,
            bottom = padding.optDouble("bottom", padding.optDouble("vertical", 0.0)).dp,
        )
        else -> modifier
    }
    if (node.optBoolean("horizontalScroll")) {
        modifier = modifier.horizontalScroll(rememberScrollState())
    }
    return modifier
}

@Composable
private fun extensionTextStyle(
    node: JSONObject,
    code: Boolean,
) = when (node.optString("style").lowercase()) {
    "display" -> MaterialTheme.typography.displaySmall
    "headline" -> MaterialTheme.typography.headlineSmall
    "title" -> MaterialTheme.typography.titleLarge
    "subtitle" -> MaterialTheme.typography.titleMedium
    "label" -> MaterialTheme.typography.labelLarge
    "caption", "small" -> MaterialTheme.typography.bodySmall
    else -> MaterialTheme.typography.bodyMedium
}.let { style ->
    val withSize = node.optDoubleOrNull("fontSize")?.let {
        style.copy(fontSize = it.sp)
    } ?: style
    if (code || node.optBoolean("monospace")) {
        withSize.copy(fontFamily = FontFamily.Monospace)
    } else {
        withSize
    }
}

private fun extensionFontWeight(value: String): FontWeight? = when (value.lowercase()) {
    "thin" -> FontWeight.Thin
    "light" -> FontWeight.Light
    "medium" -> FontWeight.Medium
    "semibold", "semi-bold" -> FontWeight.SemiBold
    "bold" -> FontWeight.Bold
    "black" -> FontWeight.Black
    else -> null
}

private fun extensionTextAlign(value: String): TextAlign = when (value.lowercase()) {
    "center" -> TextAlign.Center
    "end", "right" -> TextAlign.End
    "justify" -> TextAlign.Justify
    else -> TextAlign.Start
}

private fun extensionHorizontalArrangement(value: String): Arrangement.Horizontal = when (value.lowercase()) {
    "center" -> Arrangement.Center
    "end" -> Arrangement.End
    "spacebetween", "space-between" -> Arrangement.SpaceBetween
    "spacearound", "space-around" -> Arrangement.SpaceAround
    "spaceevenly", "space-evenly" -> Arrangement.SpaceEvenly
    else -> Arrangement.spacedBy(8.dp)
}

private fun extensionVerticalArrangement(value: String): Arrangement.Vertical = when (value.lowercase()) {
    "center" -> Arrangement.Center
    "bottom", "end" -> Arrangement.Bottom
    "spacebetween", "space-between" -> Arrangement.SpaceBetween
    "spacearound", "space-around" -> Arrangement.SpaceAround
    "spaceevenly", "space-evenly" -> Arrangement.SpaceEvenly
    else -> Arrangement.spacedBy(8.dp)
}

private fun extensionVerticalAlignment(value: String): Alignment.Vertical = when (value.lowercase()) {
    "top", "start" -> Alignment.Top
    "bottom", "end" -> Alignment.Bottom
    else -> Alignment.CenterVertically
}

private fun extensionHorizontalAlignment(value: String): Alignment.Horizontal = when (value.lowercase()) {
    "center" -> Alignment.CenterHorizontally
    "end", "right" -> Alignment.End
    else -> Alignment.Start
}

private fun extensionBoxAlignment(value: String): Alignment = when (value.lowercase()) {
    "topcenter" -> Alignment.TopCenter
    "topend", "topright" -> Alignment.TopEnd
    "centerstart", "centerleft" -> Alignment.CenterStart
    "centerend", "centerright" -> Alignment.CenterEnd
    "bottomstart", "bottomleft" -> Alignment.BottomStart
    "bottomcenter" -> Alignment.BottomCenter
    "bottomend", "bottomright" -> Alignment.BottomEnd
    "center" -> Alignment.Center
    else -> Alignment.TopStart
}

@Composable
private fun cardColor(tone: String): Color = when (tone.lowercase()) {
    "primary", "accent" -> ArixPrimary.copy(alpha = 0.16f)
    "error", "danger" -> MaterialTheme.colorScheme.errorContainer
    "higher" -> ArixSurfaceHigher
    else -> ArixSurfaceHigh
}

@Composable
private fun extensionColor(value: String): Color = when (value.lowercase()) {
    "background" -> ArixBackground
    "surface" -> ArixSurface
    "surfacehigh", "surface-high" -> ArixSurfaceHigh
    "surfacehigher", "surface-higher" -> ArixSurfaceHigher
    "primary", "accent" -> ArixPrimary
    "onprimary", "on-primary" -> ArixOnPrimary
    "onsurface", "on-surface", "text" -> ArixOnSurface
    "muted", "secondary", "onsurfacevariant", "on-surface-variant" -> ArixOnSurfaceVariant
    "error", "danger" -> MaterialTheme.colorScheme.error
    "transparent" -> Color.Transparent
    else -> parseHexColor(value) ?: ArixOnSurface
}

private fun parseHexColor(value: String): Color? {
    if (!value.startsWith("#")) return null
    return runCatching {
        Color(android.graphics.Color.parseColor(value))
    }.getOrNull()
}

internal fun extensionIcon(name: String): ImageVector = when (name.lowercase()) {
    "add", "plus", "new" -> Icons.Rounded.Add
    "auto", "sparkles", "magic" -> Icons.Rounded.AutoAwesome
    "check", "done", "save" -> Icons.Rounded.Check
    "close", "cancel", "clear" -> Icons.Rounded.Close
    "code" -> Icons.Rounded.Code
    "delete", "remove", "trash" -> Icons.Rounded.Delete
    "edit", "modify", "pencil" -> Icons.Rounded.Edit
    "home" -> Icons.Rounded.Home
    "info" -> Icons.Rounded.Info
    "link", "url" -> Icons.Rounded.Link
    "play", "run" -> Icons.Rounded.PlayArrow
    "qr", "qrcode", "qr-code", "barcode" -> Icons.Rounded.QrCode2
    "refresh", "reload" -> Icons.Rounded.Refresh
    "settings" -> Icons.Rounded.Settings
    "terminal" -> Icons.Rounded.Terminal
    "warning" -> Icons.Rounded.WarningAmber
    else -> Icons.Rounded.Extension
}

@SuppressLint("SetJavaScriptEnabled")
@Composable
private fun ArixExtensionWebView(
    node: JSONObject,
    extensionId: String,
    modifier: Modifier = Modifier,
) {
    val controller = LocalArixExtensionUiController.current ?: return
    val html = node.optString("html")
    val url = node.optString("url")
    AndroidView(
        factory = { context ->
            WebView(context).apply {
                setBackgroundColor(android.graphics.Color.TRANSPARENT)
                settings.javaScriptEnabled = true
                settings.domStorageEnabled = true
                settings.allowFileAccess = true
                settings.allowContentAccess = true
                settings.javaScriptCanOpenWindowsAutomatically = true
                webViewClient = WebViewClient()
                addJavascriptInterface(
                    ArixExtensionJavascriptBridge { action, args ->
                        controller.onAction(extensionId, action, args)
                    },
                    "Arix",
                )
                loadArixExtensionWebContent(url, html)
            }
        },
        update = { webView ->
            val contentKey = "$url\u0000$html"
            if (webView.tag != contentKey) {
                webView.tag = contentKey
                webView.loadArixExtensionWebContent(url, html)
            }
        },
        modifier = modifier
            .fillMaxWidth()
            .height(node.optDouble("height", 240.0).dp)
            .clip(RoundedCornerShape(node.optDouble("radius", 20.0).dp)),
    )
}

private fun WebView.loadArixExtensionWebContent(
    url: String,
    html: String,
) {
    if (url.isNotBlank()) {
        loadUrl(url)
    } else {
        loadDataWithBaseURL(
            "https://arix.local/",
            html,
            "text/html",
            "UTF-8",
            null,
        )
    }
}

private class ArixExtensionJavascriptBridge(
    private val onAction: (String, JSONObject) -> Unit,
) {
    @JavascriptInterface
    fun postMessage(message: String) {
        val payload = runCatching { JSONObject(message) }.getOrNull() ?: return
        val action = payload.optString("action").trim()
        if (action.isBlank()) return
        onAction(action, payload.optJSONObject("args") ?: JSONObject())
    }
}

private fun JSONObject.optDoubleOrNull(name: String): Double? {
    if (!has(name)) return null
    val value = opt(name)
    return when (value) {
        is Number -> value.toDouble()
        is String -> value.toDoubleOrNull()
        else -> null
    }
}
