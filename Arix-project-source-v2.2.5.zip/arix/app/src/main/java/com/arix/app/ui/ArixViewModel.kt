package com.arix.app.ui

import android.app.Application
import android.net.Uri
import android.os.Build
import android.provider.OpenableColumns
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import java.io.FileOutputStream
import com.arix.app.BuildConfig
import com.arix.app.R
import com.arix.app.arixRuntime
import com.arix.app.data.ActiveSkillContext
import com.arix.app.data.ArixAnalytics
import com.arix.app.data.ArixModOperationDecision
import com.arix.app.data.ArixModServiceMethod
import com.arix.app.data.AutomaticModelPurpose
import com.arix.app.data.AgentWorkspaceMode
import com.arix.app.data.AlpineEnvironmentVariable
import com.arix.app.data.AppLanguage
import com.arix.app.data.AppSettings
import com.arix.app.data.ArixNativeIntent
import com.arix.app.data.normalizeReasoningEffort
import com.arix.app.data.AppThemeMode
import com.arix.app.data.CurrentOnboardingVersion
import com.arix.app.data.DiagnosticRedactor
import com.arix.app.data.InstalledSkill
import com.arix.app.data.InstalledPiExtension
import com.arix.app.data.PiExtensionInstallKind
import com.arix.app.data.PiExtensionCatalogEntry
import com.arix.app.data.PiDiscoveredSkillSource
import com.arix.app.data.ProviderModelCatalogClient
import com.arix.app.data.thinkingCatalogKey
import com.arix.app.data.LlmProviderConfig
import com.arix.app.data.LlmTokenUsage
import com.arix.app.data.ModelCatalogClient
import com.arix.app.data.LocalRuntimeId
import com.arix.app.data.ProviderModelOption
import com.arix.app.data.PersistedChatState
import com.arix.app.data.PersistedChatWriteIntent
import com.arix.app.data.availableModelOptions
import com.arix.app.data.McpClientManager
import com.arix.app.data.McpServerConfig
import com.arix.app.data.McpServerTestOperation
import com.arix.app.data.normalizeSelectableModelKey
import com.arix.app.data.normalizeLlmInactivityReconnectTimeoutSeconds
import com.arix.app.data.normalizeLlmUserAgent
import com.arix.app.data.normalizeOldCommandHistoryRetentionHours
import com.arix.app.data.normalizeTavilyBaseUrl
import com.arix.app.data.OnboardingStarterPrompt
import com.arix.app.data.PackageProfileState
import com.arix.app.data.ScheduledTask
import com.arix.app.data.ScheduledTaskCreator
import com.arix.app.data.ScheduledTaskSchedule
import com.arix.app.data.normalizeAlpineEnvironmentVariables
import com.arix.app.data.SessionFollowUpMode
import com.arix.app.data.SessionExecutionState
import com.arix.app.data.SessionTurnEvent
import com.arix.app.data.SessionTurnOutcome
import com.arix.app.data.SessionTurnRequest
import com.arix.app.data.parseChatSessions
import com.arix.app.data.parseCustomHeaders
import com.arix.app.data.parseMcpServerConfigs
import com.arix.app.data.parseProviderConfigs
import com.arix.app.data.serializeChatSessions
import com.arix.app.data.serializeMcpServerConfigs
import com.arix.app.data.serializeProviderConfigs
import com.arix.app.data.toJson
import com.arix.app.data.toJsonArray
import com.arix.app.data.withExplicitDefaultChatModel
import com.arix.app.data.LlmMessage
import com.arix.app.data.LlmTextPart
import com.arix.app.data.ProviderAuthMethod
import com.arix.app.data.pi.PiCompletionClient
import com.arix.app.data.pi.PiKernelBridge
import com.arix.app.data.pi.PiCoreSetupActivity
import com.arix.app.data.pi.PiCoreSetupPhase
import com.arix.app.data.pi.PiCoreSetupState
import com.arix.app.data.pi.PiCoreSetupUpdate
import com.arix.app.data.pi.PiProviderAuthState
import com.arix.app.data.pi.toProviderPayloadJson
import com.arix.app.data.pi.toPiOAuthPrompt
import com.arix.app.data.pi.toPiProviderEnvironmentVariables
import com.arix.app.data.pi.toPiModelConfig
import com.arix.app.data.isProviderSetupValid
import com.arix.app.data.isOnboardingComplete
import com.arix.app.data.shouldMarkOnboardingCompleted
import com.arix.app.data.shouldLaunchOnboarding
import com.arix.app.data.shouldRevealFollowUpTourCard
import com.arix.app.data.resolveDefaultChatModelKey
import com.arix.app.data.resolveDefaultCompactingModelKey
import com.arix.app.data.resolveDefaultTitleModelKey
import com.arix.app.data.resolveAutomaticModelKey
import com.arix.app.data.resolveModelSettings
import com.arix.app.data.resolveStoredOrAutomaticModelKey
import com.arix.app.runtime.AlpineSetupProgress
import com.arix.app.runtime.AlpineTerminalLaunchSpec
import com.arix.app.runtime.AlpineSetupActivity
import com.arix.app.runtime.LocalRuntimeIssue
import com.arix.app.runtime.LocalRuntimeSetupState
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import java.util.Base64
import java.util.Locale
import java.util.UUID

private const val FollowUpTourAutoOpenDelayMillis = 2_500L
private const val LogcatReadTimeoutSeconds = 4L
private const val MaxSetupOutputChars = 48_000
private const val SessionTitleSystemPrompt =
    "Generate a concise chat title for this conversation. Return only the title, in the user's language when possible, with no quotes, no emoji, and at most 6 words."
private const val CompactCommand = "/compact"
// Pi Coding Agent defaults: compact before the model loses the 16K response reserve.
private const val ContextWindowTokens = 128_000L
private const val AutoCompactionReserveTokens = 16_384L
private const val MaxInlineImageAttachmentBytes = 5 * 1024 * 1024

internal fun shouldAutoCompactContext(
    usage: LlmTokenUsage?,
    tokenUsageSource: String,
    assistantText: String,
    contextWindow: Long = ContextWindowTokens,
    reserveTokens: Long = AutoCompactionReserveTokens,
): Boolean {
    val totalTokens = usage?.withMissingTotalResolved()?.totalTokens ?: return false
    if (contextWindow <= reserveTokens) return false
    val trailingEstimate = if (tokenUsageSource == "estimated") {
        (assistantText.length + 3L) / 4L
    } else {
        0L
    }
    return totalTokens + trailingEstimate > contextWindow - reserveTokens
}

internal fun mergeImportedPiExtensions(
    current: List<InstalledPiExtension>,
    imported: List<InstalledPiExtension>,
): List<InstalledPiExtension> =
    (current.filter { it.kind != PiExtensionInstallKind.Imported } + imported)
        .distinctBy(InstalledPiExtension::id)
        .sortedBy { it.name.lowercase(Locale.US) }

class ArixViewModel(
    application: Application,
) : AndroidViewModel(application) {
    private val runtime = application.arixRuntime
    private val diagnosticLogger = runtime.diagnosticLogger
    private val settingsRepository = runtime.settingsRepository
    private val modKernel = runtime.modKernel
    private val chatStateStore = runtime.chatStateStore
    private val extensionsRepository = runtime.extensionsRepository
    private val sessionExecutionManager = runtime.sessionExecutionManager
    private val piCompletionClient: PiCompletionClient = runtime.piCompletionClient
    private val piKernelBridge: PiKernelBridge = runtime.piKernelBridge
    private val workspaceFileBridge = runtime.workspaceFileBridge
    private val runtimeWorkspaceFileBridge = runtime.runtimeWorkspaceFileBridge
    private val agentModeController = runtime.agentModeController
    private val webViewFetcher by lazy { com.arix.app.data.WebViewFetcher(application) }
    private val skillManager = runtime.skillManager
    private val piExtensionManager = runtime.piExtensionManager
    private val arixAppExtensionManager = runtime.arixAppExtensionManager
    private val scheduledTaskManager = runtime.scheduledTaskManager
    private val mcpClientManager = McpClientManager(
        runtimeRouter = runtime.runtimeRouter,
        settings = AppSettings(),
        diagnosticLogger = diagnosticLogger,
    )
    private var lastModelCatalogRequestKey: String = ""
    private var didInitializeStartupDraftModel = false
    private var didReceiveInitialChatState = false
    private val _uiState = MutableStateFlow(ArixUiState())
    private val _transientMessages = MutableSharedFlow<UiText>(extraBufferCapacity = 4)
    private var didEvaluateWorkspaceMode = false
    private var selectSessionJob: Job? = null
    private var providerAuthJob: Job? = null
    private var extensionSendHookJob: Job? = null
    private var developerAlpineSetupPreviewJob: Job? = null
    private var piExtensionRefreshGeneration: Long = 0
    private var didRefreshAlpineAfterSettingsLoad = false

    // MUST be declared before the init block below: registerCoreModServices()
    // (called from init) appends to this list, and Kotlin initializes
    // properties in declaration order. Declaring it later leaves it null
    // during init and crashes the ViewModel constructor (instant app exit).
    private val coreModServiceUnregisters = mutableListOf<() -> Unit>()

    val uiState: StateFlow<ArixUiState> = _uiState.asStateFlow()
    val transientMessages = _transientMessages.asSharedFlow()

    init {
        registerCoreModServices()
        refreshImportedPiExtensions()

        viewModelScope.launch {
            settingsRepository.initializeLanguageIfNeeded()
            settingsRepository.settings.collect { settings ->
                if (settings.privacyPolicyAccepted) {
                    runtime.initializePostHog()
                }
                _uiState.update { current ->
                    if (!current.isStartupRouteResolved) {
                        current.copy(
                            settings = settings,
                            currentScreen = if (settings.shouldLaunchOnboarding()) {
                                AppScreen.Onboarding
                            } else {
                                AppScreen.Chat
                            },
                            isStartupRouteResolved = true,
                            isOnboardingReplay = false,
                            onboardingStep = OnboardingStep.Landing,
                            onboardingReturnScreen = AppScreen.Chat,
                        )
                    } else {
                        current.copy(settings = settings)
                    }
                }
                initializeStartupDraftModelIfReady()
                runtime.alpineRuntime.setEnvironmentVariables(settings.alpineEnvironmentVariables)
                if (!didRefreshAlpineAfterSettingsLoad) {
                    didRefreshAlpineAfterSettingsLoad = true
                    refreshAlpineSetup(startPiIfReady = false)
                }
                agentModeController.refreshAuthorization(settings)
                maybeInitializeWorkspaceMode(settings)
            }
        }

        viewModelScope.launch {
            var didReceiveChatState = false
            chatStateStore.state.collect { persisted ->
                if (!didReceiveChatState && persisted.sessions.isEmpty() && persisted.currentSessionId == DraftSessionId) {
                    didReceiveChatState = true
                    didReceiveInitialChatState = true
                    initializeStartupDraftModelIfReady()
                    return@collect
                }
                didReceiveChatState = true
                val hydratedPersisted = hydrateCurrentSessionMessages(persisted)
                _uiState.update { current ->
                    val currentSessionId = hydratedPersisted.currentSessionId.ifBlank { DraftSessionId }
                    val currentExecution = current.sessionExecutionStates[currentSessionId]
                    current.copy(
                        sessions = hydratedPersisted.sessions,
                        currentSessionId = currentSessionId,
                        isSending = currentExecution?.isRunning == true,
                        pendingResponseSessionId = currentExecution?.sessionId,
                        pendingToolInvocations = currentExecution?.pendingToolInvocations.orEmpty(),
                        pendingResponseBlocks = currentExecution?.pendingResponseBlocks.orEmpty(),
                        pendingAssistantText = currentExecution?.pendingAssistantText.orEmpty(),
                        pendingStatusText = currentExecution?.pendingStatusText.orEmpty(),
                        pendingStatusDetail = currentExecution?.pendingStatusDetail.orEmpty(),
                    )
                }
                didReceiveInitialChatState = true
                initializeStartupDraftModelIfReady()
            }
        }

        viewModelScope.launch {
            sessionExecutionManager.executionStates.collect { executionStates ->
                _uiState.update { current ->
                    val currentExecution = executionStates[current.currentSessionId]
                    current.copy(
                        sessionExecutionStates = executionStates,
                        isSending = currentExecution?.isRunning == true,
                        pendingResponseSessionId = currentExecution?.sessionId,
                        pendingToolInvocations = currentExecution?.pendingToolInvocations.orEmpty(),
                        pendingResponseBlocks = currentExecution?.pendingResponseBlocks.orEmpty(),
                        pendingAssistantText = currentExecution?.pendingAssistantText.orEmpty(),
                        pendingStatusText = currentExecution?.pendingStatusText.orEmpty(),
                        pendingStatusDetail = currentExecution?.pendingStatusDetail.orEmpty(),
                    )
                }
            }
        }

        viewModelScope.launch {
            sessionExecutionManager.turnEvents.collect { event ->
                handleTurnEvent(event)
            }
        }

        viewModelScope.launch {
            extensionsRepository.extensionState.collect { extensionState ->
                var didPruneSelections = false
                val enabledSkillIds = extensionState.installedSkills
                    .filter { it.isEnabled }
                    .map { it.id }
                    .toSet()
                val enabledMcpServerIds = extensionState.mcpServers
                    .filter { it.isEnabled }
                    .map { it.id }
                    .toSet()
                _uiState.update { current ->
                    val updatedSessions = current.sessions.map { session ->
                        val updatedSelectedSkillIds = session.selectedSkillIds.filter(enabledSkillIds::contains)
                        val updatedActiveSkills = session.activeSkills.filter { activeSkill ->
                            updatedSelectedSkillIds.contains(activeSkill.skillId)
                        }
                        val updatedActiveMcpServerIds = session.activeMcpServerIds.filter(enabledMcpServerIds::contains)
                        if (
                            updatedSelectedSkillIds != session.selectedSkillIds ||
                            updatedActiveSkills != session.activeSkills ||
                            updatedActiveMcpServerIds != session.activeMcpServerIds
                        ) {
                            didPruneSelections = true
                            session.copy(
                                selectedSkillIds = updatedSelectedSkillIds,
                                activeSkills = updatedActiveSkills,
                                activeMcpServerIds = updatedActiveMcpServerIds,
                            )
                        } else {
                            session
                        }
                    }
                    val updatedDraftSelectedSkillIds = current.draftSelectedSkillIds.filter(enabledSkillIds::contains)
                    val updatedDraftSelectedMcpServerIds = current.draftSelectedMcpServerIds.filter(enabledMcpServerIds::contains)
                    if (
                        updatedDraftSelectedSkillIds != current.draftSelectedSkillIds ||
                        updatedDraftSelectedMcpServerIds != current.draftSelectedMcpServerIds
                    ) {
                        didPruneSelections = true
                    }
                    current.copy(
                        sessions = updatedSessions,
                        draftSelectedSkillIds = updatedDraftSelectedSkillIds,
                        draftSelectedMcpServerIds = updatedDraftSelectedMcpServerIds,
                        installedSkills = extensionState.installedSkills,
                        mcpServers = extensionState.mcpServers,
                    )
                }
                if (didPruneSelections) {
                    persistPrunedSessionSelections(
                        enabledSkillIds = enabledSkillIds,
                        enabledMcpServerIds = enabledMcpServerIds,
                    )
                }
            }
        }

        viewModelScope.launch {
            settingsRepository.providerConfigs.collect { configs ->
                _uiState.update { current -> current.copy(providerConfigs = configs) }
                initializeStartupDraftModelIfReady()
                refreshModelCatalogInfo(configs)
            }
        }
        viewModelScope.launch {
            scheduledTaskManager.scheduledTasks.collect { tasks ->
                _uiState.update { current -> current.copy(scheduledTasks = tasks) }
            }
        }
        viewModelScope.launch {
            agentModeController.displayState.collect { displayState ->
                _uiState.update { current -> current.copy(agentModeDisplayState = displayState) }
            }
        }
        viewModelScope.launch {
            runtime.alpineChromeController.displayState.collect { displayState ->
                _uiState.update { current -> current.copy(chromeDisplayState = displayState) }
            }
        }
        viewModelScope.launch {
            agentModeController.authorizationState.collect { authorizationState ->
                _uiState.update { current -> current.copy(agentModeAuthorizationState = authorizationState) }
            }
        }
    }

    private fun refreshModelCatalogInfo(configs: List<LlmProviderConfig>) {
        val options = configs.availableModelOptions()
        val requestKey = options.joinToString("|") { "${it.key}:${it.fullLabel}" }
        if (requestKey == lastModelCatalogRequestKey) return
        lastModelCatalogRequestKey = requestKey
        if (options.isEmpty()) {
            _uiState.update { current -> current.copy(modelCatalogInfo = emptyMap()) }
            return
        }
        viewModelScope.launch {
            if (_uiState.value.modelCatalogInfo.isEmpty()) {
                val cached = settingsRepository.loadModelCatalogCache()
                    .filterKeys(options.mapTo(mutableSetOf(), ProviderModelOption::key)::contains)
                if (cached.isNotEmpty() && requestKey == lastModelCatalogRequestKey) {
                    _uiState.update { current -> current.copy(modelCatalogInfo = cached) }
                }
            }
            val thinkingCacheKeys = options.mapTo(mutableSetOf()) { option ->
                thinkingCatalogKey(option.piProviderId, option.modelId)
            }
            val cachedThinkingLevels = settingsRepository.loadThinkingCatalogCache()
                .filterKeys(thinkingCacheKeys::contains)
            val cachedThinkingLevelMaps = settingsRepository.loadThinkingLevelMapsCache()
                .filterKeys(thinkingCacheKeys::contains)
            val cachedReasoningModels = settingsRepository.loadReasoningModelsCache()
                .filterTo(mutableSetOf(), thinkingCacheKeys::contains)
            if (cachedThinkingLevels.isNotEmpty() && requestKey == lastModelCatalogRequestKey) {
                _uiState.update { current ->
                    current.copy(
                        thinkingLevelsByProviderModel = current.thinkingLevelsByProviderModel + cachedThinkingLevels,
                        thinkingLevelClampsByProviderModel = current.thinkingLevelClampsByProviderModel + cachedThinkingLevelMaps,
                        reasoningModels = current.reasoningModels + cachedReasoningModels,
                    )
                }
            }
            val modelInfo = ModelCatalogClient.fetchModelInfo(options)
            if (modelInfo.isNotEmpty()) {
                settingsRepository.saveModelCatalogCache(modelInfo)
            }
            if (modelInfo.isNotEmpty() && requestKey == lastModelCatalogRequestKey) {
                _uiState.update { current -> current.copy(modelCatalogInfo = modelInfo) }
            }

            // Populate the effort cache during startup as well as when the model
            // picker is opened. Cached values are already applied above, so an
            // unavailable network never delays the initial picker state.
            val catalogResult = ProviderModelCatalogClient.fetchPublicThinkingCatalog(options)
            if (catalogResult.levelsByProviderModel.isNotEmpty()) {
                settingsRepository.saveThinkingCatalogCache(
                    catalogResult.levelsByProviderModel,
                    catalogResult.levelMapsByProviderModel,
                    catalogResult.reasoningModels,
                )
                if (requestKey == lastModelCatalogRequestKey) {
                    _uiState.update { state ->
                        state.copy(
                            thinkingLevelsByProviderModel =
                                state.thinkingLevelsByProviderModel + catalogResult.levelsByProviderModel,
                            thinkingLevelClampsByProviderModel =
                                (state.thinkingLevelClampsByProviderModel -
                                    catalogResult.levelsByProviderModel.keys) +
                                    catalogResult.levelMapsByProviderModel,
                            reasoningModels =
                                (state.reasoningModels - catalogResult.levelsByProviderModel.keys) +
                                    catalogResult.reasoningModels,
                        )
                    }
                }
            }
        }
    }

    fun acceptPrivacyPolicy() {
        viewModelScope.launch {
            settingsRepository.updatePrivacyPolicyAccepted(true)
            runtime.initializePostHog()
        }
    }

    fun refreshAlpineSetup(startPiIfReady: Boolean = false) {
        viewModelScope.launch {
            val setupState = withContext(Dispatchers.IO) {
                runtime.alpineRuntime.inspectSetup()
            }
            _uiState.update { current ->
                current.copy(
                    alpineSetupState = setupState,
                    piCoreSetupState = if (setupState.isReady) {
                        current.piCoreSetupState.copy(
                            isChecking = false,
                            activity = PiCoreSetupActivity.None,
                            bytesPerSecond = 0L,
                        )
                    } else {
                        current.piCoreSetupState
                    },
                )
            }
            if (setupState.isReady) {
                val storedSettings = _uiState.value.settings
                val settings = storedSettings.copy(
                    alpineSetupCompleted = true,
                    enabledRuntimeIds = storedSettings.enabledRuntimeIds + LocalRuntimeId.Alpine,
                )
                if (settings != storedSettings) settingsRepository.updateSettings(settings)
                val verifiedProfiles = withContext(Dispatchers.IO) {
                    settings.alpinePackageProfiles.mapValues { (profileId, profileState) ->
                        if (
                            profileState.installed &&
                            !runtime.alpineRuntime.isPackageProfileInstalled(profileId)
                        ) {
                            profileState.copy(
                                installed = false,
                                installedAtMillis = 0L,
                                lastError = "",
                            )
                        } else {
                            profileState
                        }
                    }
                }
                if (verifiedProfiles != settings.alpinePackageProfiles) {
                    settingsRepository.updateSettings(
                        settings.copy(alpinePackageProfiles = verifiedProfiles)
                    )
                    if (verifiedProfiles["chrome"]?.installed != true) {
                        _uiState.update { current ->
                            current.copy(
                                draftChromeEnabled = false,
                                sessions = current.sessions.map { it.copy(chromeEnabled = false) },
                            )
                        }
                        chatStateStore.updateAndFlush { persisted ->
                            persisted.copy(
                                sessions = persisted.sessions.map { it.copy(chromeEnabled = false) },
                            )
                        }
                    }
                }
                if (startPiIfReady) {
                    refreshPiCoreSetup()
                } else {
                    viewModelScope.launch { syncPiDiscoveredSkills() }
                }
            } else {
                _uiState.update {
                    it.copy(
                        piCoreSetupState = PiCoreSetupState(
                            detail = "Initialize Alpine before starting the agent runtime.",
                        )
                    )
                }
            }
        }
    }

    fun initializeAlpineRuntime(makeDefault: Boolean = true) {
        viewModelScope.launch {
            initializeAlpineRuntimeAfterReset(makeDefault)
        }
    }

    fun retryAlpineRuntimeSetup(makeDefault: Boolean = true) {
        viewModelScope.launch {
            _uiState.update { current ->
                current.copy(
                    alpineSetupState = LocalRuntimeSetupState(
                        runtimeId = LocalRuntimeId.Alpine,
                        issue = LocalRuntimeIssue.NotInstalled,
                    ),
                    piCoreSetupState = PiCoreSetupState(
                        isChecking = true,
                        phase = PiCoreSetupPhase.CheckingAlpine,
                        output = "Starting Alpine setup...\n",
                    ),
                )
            }
            val resetFailure = try {
                withContext(Dispatchers.IO) {
                    runtime.alpineChromeController.stop()
                    runtime.piKernelBridge.stop()
                    runtime.alpineRuntime.reset()
                }
                null
            } catch (error: CancellationException) {
                throw error
            } catch (error: Throwable) {
                error
            }
            if (resetFailure != null) {
                val detail = resetFailure.userFacingMessage()
                _uiState.update { current ->
                    current.copy(
                        alpineSetupState = LocalRuntimeSetupState(
                            runtimeId = LocalRuntimeId.Alpine,
                            issue = LocalRuntimeIssue.Failed,
                            detail = detail,
                        ),
                        piCoreSetupState = current.piCoreSetupState.copy(
                            isChecking = false,
                            phase = PiCoreSetupPhase.Failed,
                            failedAtPhase = PiCoreSetupPhase.CheckingAlpine,
                            detail = detail,
                            output = appendSetupOutput(
                                current.piCoreSetupState.output,
                                "Setup failed: $detail\n",
                            ),
                        ),
                    )
                }
                emitTransientMessage(UiText.Raw(detail))
                return@launch
            }
            val settings = _uiState.value.settings
            val remainingRuntimeIds = settings.enabledRuntimeIds - LocalRuntimeId.Alpine
            settingsRepository.updateSettings(
                settings.copy(
                    alpineSetupCompleted = false,
                    alpinePackageProfiles = emptyMap(),
                    enabledRuntimeIds = remainingRuntimeIds,
                    defaultRuntimeId = if (settings.defaultRuntimeId == LocalRuntimeId.Alpine) {
                        remainingRuntimeIds.firstOrNull()
                    } else {
                        settings.defaultRuntimeId
                    },
                )
            )
            _uiState.update { current ->
                current.copy(
                    alpinePackageInstallProgress = emptyMap(),
                    draftChromeEnabled = false,
                    sessions = current.sessions.map { it.copy(chromeEnabled = false) },
                )
            }
            chatStateStore.updateAndFlush { persisted ->
                persisted.copy(
                    sessions = persisted.sessions.map { it.copy(chromeEnabled = false) },
                )
            }
            initializeAlpineRuntimeAfterReset(makeDefault)
        }
    }

    private suspend fun initializeAlpineRuntimeAfterReset(makeDefault: Boolean) {
        _uiState.update { current ->
            current.copy(
                piCoreSetupState = PiCoreSetupState(
                    isChecking = true,
                    phase = PiCoreSetupPhase.CheckingAlpine,
                    output = "Starting Alpine setup...\n",
                )
            )
        }
        val setupState = withContext(Dispatchers.IO) {
            runtime.alpineRuntime.initialize { progress ->
                applyPiCoreSetupUpdate(
                    PiCoreSetupUpdate(
                        phase = PiCoreSetupPhase.CheckingAlpine,
                        activity = when (progress.activity) {
                            AlpineSetupActivity.Extracting -> PiCoreSetupActivity.Extracting
                            AlpineSetupActivity.Downloading -> PiCoreSetupActivity.Downloading
                            AlpineSetupActivity.Installing -> PiCoreSetupActivity.None
                            AlpineSetupActivity.None -> PiCoreSetupActivity.None
                        },
                        bytesPerSecond = progress.bytesPerSecond,
                        output = progress.output,
                    )
                )
            }
        }
        if (setupState.isReady) {
            settingsRepository.updateSettings(
                _uiState.value.settings.withRuntimeEnabled(
                    runtimeId = LocalRuntimeId.Alpine,
                    makeDefault = makeDefault,
                )
            )
        }
        _uiState.update { current -> current.copy(alpineSetupState = setupState) }
        if (setupState.isReady) {
            _uiState.update { current ->
                current.copy(
                    piCoreSetupState = current.piCoreSetupState.copy(
                        isChecking = false,
                        activity = PiCoreSetupActivity.None,
                        bytesPerSecond = 0L,
                    ),
                )
            }
            refreshPiCoreSetup()
        } else {
            _uiState.update { current ->
                current.copy(
                    piCoreSetupState = current.piCoreSetupState.copy(
                        isChecking = false,
                        phase = PiCoreSetupPhase.Failed,
                        failedAtPhase = PiCoreSetupPhase.CheckingAlpine,
                        detail = setupState.detail,
                        activity = PiCoreSetupActivity.None,
                        bytesPerSecond = 0L,
                        output = appendSetupOutput(
                            current.piCoreSetupState.output,
                            "Setup failed: ${setupState.detail}\n",
                        ),
                    )
                )
            }
        }
        emitTransientMessage(UiText.Raw(setupState.detail.ifBlank { "Alpine runtime status refreshed." }))
    }

    private suspend fun refreshPiCoreSetup() {
        if (_uiState.value.piCoreSetupState.isChecking) return
        _uiState.update {
            it.copy(
                piCoreSetupState = PiCoreSetupState(
                    isChecking = true,
                    phase = PiCoreSetupPhase.CheckingAlpine,
                    output = it.piCoreSetupState.output.ifBlank { "Starting agent runtime setup...\n" },
                )
            )
        }
        runCatching {
            withContext(Dispatchers.IO) {
                runtime.piKernelBridge.ping(::applyPiCoreSetupUpdate)
            }
        }.fold(
            onSuccess = { payload ->
                _uiState.update {
                    it.copy(
                        piCoreSetupState = PiCoreSetupState(
                            isReady = true,
                            phase = PiCoreSetupPhase.Ready,
                            nodeVersion = payload.optString("node_version"),
                            bridgeVersion = payload.optString("bridge_version"),
                            output = appendSetupOutput(
                                it.piCoreSetupState.output,
                                "AI engine setup complete.\n",
                            ),
                        )
                    )
                }
                syncPiDiscoveredSkills()
            },
            onFailure = { throwable ->
                if (throwable is CancellationException) throw throwable
                _uiState.update { current ->
                    current.copy(
                        piCoreSetupState = PiCoreSetupState(
                            phase = PiCoreSetupPhase.Failed,
                            failedAtPhase = current.piCoreSetupState.phase,
                            detail = throwable.userFacingMessage(),
                            output = appendSetupOutput(
                                current.piCoreSetupState.output,
                                "Setup failed: ${throwable.userFacingMessage()}\n",
                            ),
                        )
                    )
                }
            },
        )
    }

    private suspend fun syncPiDiscoveredSkills() {
        runCatching {
            val response = piKernelBridge.listDiscoveredSkills()
            val skills = response.optJSONArray("skills") ?: return@runCatching
            val discovered = buildList {
                for (index in 0 until skills.length()) {
                    val item = skills.optJSONObject(index) ?: continue
                    val guestFilePath = item.optString("file_path").trim()
                    val guestBaseDir = item.optString("base_dir").trim()
                    if (guestFilePath.isBlank() || guestBaseDir.isBlank()) continue
                    val hostFile = runtime.alpineRuntime.resolveWorkspaceHostPath(guestFilePath)?.hostFile
                        ?: runtime.alpineRuntime.resolveGuestPath(guestFilePath)
                    val hostRoot = runtime.alpineRuntime.resolveWorkspaceHostPath(guestBaseDir)?.hostFile
                        ?: runtime.alpineRuntime.resolveGuestPath(guestBaseDir)
                    if (!hostFile.isFile || !hostRoot.isDirectory) continue
                    add(
                        PiDiscoveredSkillSource(
                            guestFilePath = guestFilePath,
                            guestBaseDir = guestBaseDir,
                            hostFile = hostFile,
                            hostRoot = hostRoot,
                        )
                    )
                }
            }
            skillManager.syncPiDiscoveredSkills(discovered).getOrThrow()
        }
    }

    fun resetAlpineRuntime() {
        viewModelScope.launch {
            val setupState = withContext(Dispatchers.IO) {
                runtime.alpineChromeController.stop()
                runtime.alpineRuntime.reset()
            }
            val settings = _uiState.value.settings
            settingsRepository.updateSettings(
                settings.copy(
                    enabledRuntimeIds = settings.enabledRuntimeIds - LocalRuntimeId.Alpine,
                    defaultRuntimeId = if (settings.defaultRuntimeId == LocalRuntimeId.Alpine) {
                        (settings.enabledRuntimeIds - LocalRuntimeId.Alpine).firstOrNull()
                    } else {
                        settings.defaultRuntimeId
                    },
                    alpineSetupCompleted = false,
                    alpinePackageProfiles = emptyMap(),
                )
            )
            _uiState.update { current ->
                current.copy(
                    alpineSetupState = setupState,
                    alpinePackageInstallProgress = emptyMap(),
                    draftChromeEnabled = false,
                    sessions = current.sessions.map { it.copy(chromeEnabled = false) },
                )
            }
            chatStateStore.updateAndFlush { persisted ->
                persisted.copy(
                    sessions = persisted.sessions.map { it.copy(chromeEnabled = false) },
                )
            }
        }
    }

    fun installAlpinePackageProfile(profileId: String) {
        if (_uiState.value.alpinePackageInstallProgress.containsKey(profileId)) return
        viewModelScope.launch {
            _uiState.update { current ->
                current.copy(
                    alpinePackageInstallProgress = current.alpinePackageInstallProgress +
                        (
                            profileId to AlpineSetupProgress(
                                activity = AlpineSetupActivity.Downloading,
                            )
                            ),
                )
            }
            val installState = try {
                withContext(Dispatchers.IO) {
                    runtime.alpineRuntime.installPackageProfile(profileId) { progress ->
                        _uiState.update { current ->
                            val previous = current.alpinePackageInstallProgress[profileId]
                            val merged = progress.copy(
                                bytesPerSecond = progress.bytesPerSecond.takeIf { it > 0L }
                                    ?: previous?.bytesPerSecond
                                    ?: 0L,
                                progressPercent = progress.progressPercent
                                    ?: previous?.progressPercent,
                            )
                            current.copy(
                                alpinePackageInstallProgress =
                                    current.alpinePackageInstallProgress + (profileId to merged),
                            )
                        }
                    }
                }
            } catch (throwable: Throwable) {
                if (throwable is CancellationException) throw throwable
                LocalRuntimeSetupState(
                    runtimeId = LocalRuntimeId.Alpine,
                    issue = LocalRuntimeIssue.Failed,
                    detail = throwable.userFacingMessage(),
                )
            } finally {
                _uiState.update { current ->
                    current.copy(
                        alpinePackageInstallProgress =
                            current.alpinePackageInstallProgress - profileId,
                    )
                }
            }
            val profileState = if (installState.isReady) {
                PackageProfileState(
                    profileId = profileId,
                    installed = true,
                    installedAtMillis = System.currentTimeMillis(),
                    lastError = "",
                )
            } else {
                PackageProfileState(
                    profileId = profileId,
                    installed = false,
                    installedAtMillis = 0L,
                    lastError = installState.detail.ifBlank { "Install failed." },
                )
            }
            val settings = _uiState.value.settings
            settingsRepository.updateSettings(
                settings.copy(
                    alpinePackageProfiles = settings.alpinePackageProfiles + (profileId to profileState),
                )
            )
            val runtimeState = withContext(Dispatchers.IO) {
                runtime.alpineRuntime.inspectSetup()
            }
            _uiState.update { current -> current.copy(alpineSetupState = runtimeState) }
            emitTransientMessage(UiText.Raw(installState.detail.ifBlank { "Alpine package profile updated." }))
        }
    }

    suspend fun createAlpineTerminalLaunchSpec(): Result<AlpineTerminalLaunchSpec> =
        withContext(Dispatchers.IO) {
            runCatching { runtime.alpineRuntime.createTerminalLaunchSpec() }
        }

    suspend fun startAlpineChrome(): Result<Unit> =
        runtime.alpineChromeController.startBrowser()

    suspend fun shouldShowAlpineChromeKeyboard(x: Int, y: Int): Result<Boolean> =
        runtime.alpineChromeController.shouldShowKeyboardAfterClick(x, y)

    fun setDefaultRuntime(runtimeId: LocalRuntimeId) {
        viewModelScope.launch {
            val settings = _uiState.value.settings
            settingsRepository.updateSettings(
                settings.copy(
                    enabledRuntimeIds = settings.enabledRuntimeIds + runtimeId,
                    defaultRuntimeId = runtimeId,
                )
            )
        }
    }

    fun refreshAgentModeAuthorization() {
        val settings = _uiState.value.settings
        refreshAgentModeAuthorization(
            enabled = settings.agentModeAuthorizationEnabled,
        )
    }

    fun refreshAgentModeAuthorization(
        enabled: Boolean,
    ) {
        viewModelScope.launch {
            agentModeController.refreshAuthorization(
                _uiState.value.settings.copy(
                    agentModeAuthorizationEnabled = enabled,
                )
            )
        }
    }

    fun stopAgentModeSession() {
        agentModeController.stopSession()
    }

    fun updateDraftInput(value: String) {
        _uiState.update { current ->
            current.copy(
                draftInput = value,
                showStarterPromptHint = if (
                    current.showStarterPromptHint && value != current.draftInput
                ) {
                    false
                } else {
                    current.showStarterPromptHint
                },
            )
        }
    }

    fun skipOnboarding() {
        viewModelScope.launch {
            settingsRepository.updateOnboardingSeenVersion(CurrentOnboardingVersion)
            _uiState.update { current ->
                current.copy(
                    currentScreen = AppScreen.Chat,
                    isStartupRouteResolved = true,
                    isOnboardingReplay = false,
                    onboardingStep = OnboardingStep.Landing,
                    onboardingReturnScreen = AppScreen.Chat,
                )
            }
        }
    }

    fun openOnboardingFromSettings() {
        _uiState.update { current ->
            current.copy(
                currentScreen = AppScreen.Onboarding,
                isOnboardingReplay = true,
                onboardingStep = OnboardingStep.Landing,
                onboardingReturnScreen = AppScreen.Settings,
            )
        }
    }

    fun openFollowUpOnboardingFromSettings() {
        _uiState.update { current ->
            current.copy(
                currentScreen = AppScreen.Onboarding,
                isOnboardingReplay = true,
                onboardingStep = OnboardingStep.LocalRuntimeChoice,
                onboardingReturnScreen = AppScreen.Settings,
                awaitingFollowUpTour = false,
                showFollowUpTourCard = false,
            )
        }
    }

    fun openDeveloperAlpineSetupPreview() {
        developerAlpineSetupPreviewJob?.cancel()
        _uiState.update { current ->
            current.copy(
                currentScreen = AppScreen.Onboarding,
                isOnboardingReplay = true,
                onboardingStep = OnboardingStep.AlpineSetup,
                onboardingReturnScreen = AppScreen.Settings,
                developerAlpineSetupPreviewState = PiCoreSetupState(),
            )
        }
        restartDeveloperAlpineSetupPreview()
    }

    fun restartDeveloperAlpineSetupPreview() {
        developerAlpineSetupPreviewJob?.cancel()
        _uiState.update { current ->
            if (current.developerAlpineSetupPreviewState == null) {
                current
            } else {
                current.copy(developerAlpineSetupPreviewState = PiCoreSetupState())
            }
        }
        developerAlpineSetupPreviewJob = viewModelScope.launch {
            fun update(
                phase: PiCoreSetupPhase,
                activity: PiCoreSetupActivity = PiCoreSetupActivity.None,
                bytesPerSecond: Long = 0L,
                output: String = "",
            ) {
                _uiState.update { current ->
                    val preview = current.developerAlpineSetupPreviewState ?: return@update current
                    current.copy(
                        developerAlpineSetupPreviewState = preview.copy(
                            isChecking = phase != PiCoreSetupPhase.Ready && phase != PiCoreSetupPhase.Failed,
                            isReady = phase == PiCoreSetupPhase.Ready,
                            phase = phase,
                            activity = activity,
                            bytesPerSecond = bytesPerSecond,
                            output = appendSetupOutput(preview.output, output),
                            nodeVersion = if (phase == PiCoreSetupPhase.Ready) "22.21.1" else preview.nodeVersion,
                            bridgeVersion = if (phase == PiCoreSetupPhase.Ready) "2.0.0-alpha.0" else preview.bridgeVersion,
                        )
                    )
                }
            }

            update(PiCoreSetupPhase.CheckingAlpine, output = "Starting Alpine setup preview...\n")
            delay(700L)
            update(
                phase = PiCoreSetupPhase.CheckingAlpine,
                activity = PiCoreSetupActivity.Extracting,
                bytesPerSecond = 18L * 1024L * 1024L,
                output = "Preparing Alpine runtime files...\n",
            )
            delay(900L)
            val extractionEntries = listOf(
                "bin/busybox",
                "etc/alpine-release",
                "usr/lib/libcrypto.so.3",
                "usr/bin/env",
                "var/lib/apk/world",
            )
            extractionEntries.forEachIndexed { index, path ->
                update(
                    phase = PiCoreSetupPhase.CheckingAlpine,
                    activity = PiCoreSetupActivity.Extracting,
                    bytesPerSecond = (18L + index * 3L) * 1024L * 1024L,
                    output = "Extracting $path\n",
                )
                delay(1_600L)
            }
            update(
                phase = PiCoreSetupPhase.CheckingNode,
                output = "Alpine root filesystem ready.\nChecking node --version...\n",
            )
            delay(1_000L)
            val apkLines = listOf(
                "\$ apk add --no-cache --no-chown nodejs npm",
                "fetch https://dl-cdn.alpinelinux.org/alpine/v3.23/main/aarch64/APKINDEX.tar.gz",
                "(1/8) Installing ca-certificates",
                "(2/8) Installing libuv",
                "(7/8) Installing nodejs",
                "(8/8) Installing npm",
                "OK: 94 MiB in 32 packages",
            )
            apkLines.forEachIndexed { index, line ->
                update(
                    phase = PiCoreSetupPhase.InstallingNode,
                    activity = PiCoreSetupActivity.Downloading,
                    bytesPerSecond = (2_400L + index * 370L) * 1024L,
                    output = "$line\n",
                )
                delay(1_400L)
            }
            update(PiCoreSetupPhase.PreparingBridge, output = "Preparing the AI engine bridge...\n")
            delay(900L)
            update(PiCoreSetupPhase.StartingBridge, output = "Starting node bridge.mjs...\n")
            delay(900L)
            update(PiCoreSetupPhase.VerifyingBridge, output = "Verifying bridge response...\n")
            delay(900L)
            update(PiCoreSetupPhase.Ready, output = "AI engine setup complete.\n")
        }
    }

    fun resumeOnboarding() {
        _uiState.update { current ->
            current.copy(
                currentScreen = AppScreen.Onboarding,
                isOnboardingReplay = true,
                onboardingStep = OnboardingStep.ProviderSetup,
                onboardingReturnScreen = AppScreen.Chat,
            )
        }
    }

    fun closeOnboarding() {
        developerAlpineSetupPreviewJob?.cancel()
        developerAlpineSetupPreviewJob = null
        _uiState.update { current ->
            current.copy(
                currentScreen = current.onboardingReturnScreen,
                isOnboardingReplay = false,
                onboardingStep = OnboardingStep.Landing,
                onboardingReturnScreen = AppScreen.Chat,
                developerAlpineSetupPreviewState = null,
            )
        }
    }

    private fun applyPiCoreSetupUpdate(update: PiCoreSetupUpdate) {
        _uiState.update { current ->
            current.copy(
                piCoreSetupState = current.piCoreSetupState.copy(
                    isChecking = true,
                    phase = update.phase,
                    activity = update.activity,
                    bytesPerSecond = update.bytesPerSecond,
                    output = appendSetupOutput(current.piCoreSetupState.output, update.output),
                )
            )
        }
    }

    private fun appendSetupOutput(
        current: String,
        addition: String,
    ): String {
        if (addition.isEmpty()) return current
        val combined = current + addition
        return if (combined.length <= MaxSetupOutputChars) {
            combined
        } else {
            combined.takeLast(MaxSetupOutputChars)
        }
    }

    fun completeFollowUpOnboarding() {
        captureAnalyticsEvent(
            event = "onboarding follow up completed",
            properties = mapOf(
                "section" to "follow_up",
                "source" to if (_uiState.value.isOnboardingReplay) "replay" else "auto",
                "agent_mode_authorized" to _uiState.value.agentModeAuthorizationState.isReady,
                "tavily_configured" to _uiState.value.settings.tavilyApiKey.isNotBlank(),
                "skill_count" to _uiState.value.installedSkills.size,
                "mcp_server_count" to _uiState.value.mcpServers.size,
            ),
        )
        closeOnboarding()
    }

    fun completeOnboardingProviderSetup(config: LlmProviderConfig) {
        viewModelScope.launch {
            val enabledConfig = config.copy(isEnabled = true)
            settingsRepository.upsertProviderConfig(enabledConfig)
            settingsRepository.setProviderEnabled(enabledConfig.id, true)
            val updatedSettings = _uiState.value.settings.withExplicitDefaultChatModel(enabledConfig)
            val defaultModelKey = updatedSettings.defaultChatModelKey
            settingsRepository.updateSettings(updatedSettings)
            settingsRepository.updateOnboardingSeenVersion(CurrentOnboardingVersion)
            _uiState.update { current ->
                current.copy(
                    currentScreen = AppScreen.Chat,
                    isStartupRouteResolved = true,
                    isOnboardingReplay = false,
                    onboardingStep = OnboardingStep.Landing,
                    onboardingReturnScreen = AppScreen.Chat,
                    currentSessionId = DraftSessionId,
                    draftInput = OnboardingStarterPrompt,
                    draftAttachments = emptyList(),
                    draftSelectedModelKey = defaultModelKey,
                    draftSelectedSkillIds = emptyList(),
                    draftSelectedMcpServerIds = emptyList(),
                    draftAgentModeEnabled = false,
                    draftChromeEnabled = false,
                    draftWorkspaceId = null,
                    editingSessionId = null,
                    editingMessageId = null,
                    showStarterPromptHint = true,
                    awaitingFollowUpTour = true,
                    showFollowUpTourCard = false,
                )
            }
            persistCurrentSessionId(DraftSessionId)
            captureAnalyticsEvent(
                event = "onboarding completed",
                properties = mapOf(
                    "section" to "initial",
                    "provider" to com.arix.app.data.PiProviderCatalog
                        .resolve(enabledConfig.piProviderId).displayName,
                    "provider_id" to enabledConfig.id,
                ),
            )
            captureAnalyticsEvent(
                event = "onboarding initial completed",
                properties = mapOf(
                    "section" to "initial",
                    "provider" to com.arix.app.data.PiProviderCatalog
                        .resolve(enabledConfig.piProviderId).displayName,
                    "provider_id" to enabledConfig.id,
                ),
            )
        }
    }

    fun dismissStarterPromptHint() {
        _uiState.update { current -> current.copy(showStarterPromptHint = false) }
    }

    fun openFollowUpTour() {
        _uiState.update { current ->
            current.copy(
                currentScreen = AppScreen.Onboarding,
                isOnboardingReplay = true,
                onboardingStep = OnboardingStep.LocalRuntimeChoice,
                onboardingReturnScreen = AppScreen.Chat,
                awaitingFollowUpTour = false,
                showFollowUpTourCard = false,
            )
        }
    }

    fun saveOnboardingTavilyApiKey(value: String) {
        // Legacy onboarding callbacks are ignored; Web Tools are no longer part of Arix.
    }

    fun saveOnboardingAgentModeAuthorization(enabled: Boolean) {
        viewModelScope.launch {
            settingsRepository.updateSettings(
                _uiState.value.settings.copy(
                    agentModeAuthorizationEnabled = enabled,
                )
            )
        }
    }

    fun appendDraftAttachments(uris: List<Uri>) {
        if (uris.isEmpty()) return

        val targetSessionId = ensureDraftWorkspaceId()

        viewModelScope.launch {
            val pendingAttachments = withContext(Dispatchers.IO) {
                uris
                    .mapNotNull { uri -> buildPendingDraftAttachment(uri) }
                    .distinctBy { it.uri }
                    .toList()
            }
            if (pendingAttachments.isEmpty()) return@launch

            var attachmentsToImport = emptyList<ChatAttachment>()
            _uiState.update { current ->
                val newAttachments = pendingAttachments.filterNot { candidate ->
                    current.draftAttachments.any { existing -> existing.uri == candidate.uri }
                }
                attachmentsToImport = newAttachments
                if (newAttachments.isEmpty()) {
                    current
                } else {
                    current.copy(
                        draftAttachments = current.draftAttachments + newAttachments
                    )
                }
            }

            attachmentsToImport.forEach { attachment ->
                launch(Dispatchers.IO) {
                    importDraftAttachmentToWorkspace(
                        attachment = attachment,
                        sessionId = targetSessionId,
                    )
                }
            }
        }
    }

    fun removeDraftAttachment(attachmentId: String) {
        _uiState.update { current ->
            current.copy(
                draftAttachments = current.draftAttachments.filterNot { it.id == attachmentId }
            )
        }
    }

    fun pauseGeneration() {
        val snapshot = _uiState.value
        val sessionId = sequenceOf(
            snapshot.currentSessionId,
            snapshot.pendingResponseSessionId,
        )
            .filterNotNull()
            .firstOrNull(sessionExecutionManager::isSessionRunning)
            ?: return
        val finalizedSession = sessionExecutionManager.pauseSession(sessionId) ?: return
        val executionStates = sessionExecutionManager.executionStates.value
        _uiState.update { current -> current.withFinalizedPausedSession(finalizedSession, executionStates) }
    }

    fun openSettings() {
        _uiState.update { it.copy(currentScreen = AppScreen.Settings) }
    }

    fun refreshUsageStatisticsSnapshots() {
        viewModelScope.launch {
            val snapshots = withContext(Dispatchers.IO) {
                runtime.chatRepository.getUsageStatisticsSnapshot()
            }
            _uiState.update { it.copy(usageStatisticsSnapshots = snapshots) }
        }
    }

    fun closeSettings() {
        _uiState.update {
            it.copy(currentScreen = AppScreen.Chat)
        }
    }

    fun startNewChat() {
        val snapshot = _uiState.value
        val defaultSkillIds = enabledDefaultSkillIds(snapshot)
        val operation = "chat.new"
        if (
            !modKernel.operations.hasInterceptors(operation) &&
            "operation:$operation" !in arixAppExtensionManager.state.value.snapshot.eventNames
        ) {
            startNewChatNow(defaultSkillIds)
            return
        }
        viewModelScope.launch {
            val result = dispatchArixOperation(
                operation = operation,
                payload = JSONObject().put(
                    "selected_skill_ids",
                    JSONArray(defaultSkillIds),
                ),
            )
            if (result.cancelled) return@launch
            val selectedSkillIds = if (result.payload.has("selected_skill_ids")) {
                result.payload.optJSONArray("selected_skill_ids").toStringList()
            } else {
                defaultSkillIds
            }
            withContext(Dispatchers.Main.immediate) {
                startNewChatNow(selectedSkillIds)
            }
        }
    }

    private fun startNewChatNow(
        selectedSkillIds: List<String>,
    ) {
        _uiState.update {
            val inheritedModelKey = currentConversationModelKey(it)
            val enabledSkillIds = it.installedSkills
                .filter(InstalledSkill::isEnabled)
                .map(InstalledSkill::id)
                .toSet()
            it.copy(
                currentScreen = AppScreen.Chat,
                currentSessionId = DraftSessionId,
                draftInput = "",
                draftAttachments = emptyList(),
                draftSelectedModelKey = inheritedModelKey,
                draftSelectedSkillIds = selectedSkillIds.filter(enabledSkillIds::contains),
                draftSelectedMcpServerIds = emptyList(),
                draftAgentModeEnabled = false,
                draftChromeEnabled = false,
                draftWorkspaceId = null,
                editingSessionId = null,
                editingMessageId = null,
                unviewedCompletedSessionIds = it.unviewedCompletedSessionIds - DraftSessionId,
                showStarterPromptHint = false,
            )
        }
        persistCurrentSessionId(DraftSessionId)
        captureAnalyticsEvent(event = "conversation started")
    }

    private fun initializeStartupDraftModelIfReady() {
        if (didInitializeStartupDraftModel) return
        var sessionToPersist: Pair<String, String>? = null
        _uiState.update { current ->
            val options = current.providerConfigs.availableModelOptions()
            if (
                !current.isStartupRouteResolved ||
                !didReceiveInitialChatState ||
                options.isEmpty()
            ) return@update current
            didInitializeStartupDraftModel = true
            val defaultModelKey = resolveDefaultChatModelKey(current.settings, current.providerConfigs)
            if (current.currentSessionId == DraftSessionId) {
                current.copy(draftSelectedModelKey = defaultModelKey)
            } else {
                sessionToPersist = current.currentSessionId to defaultModelKey
                current.copy(
                    sessions = current.sessions.map { session ->
                        if (session.id == current.currentSessionId) {
                            session.copy(selectedModelKey = defaultModelKey)
                        } else {
                            session
                        }
                    },
                )
            }
        }
        sessionToPersist?.let { (sessionId, defaultModelKey) ->
            persistSessionMutation(sessionId) { session ->
                if (session.selectedModelKey == defaultModelKey) null
                else session.copy(selectedModelKey = defaultModelKey)
            }
        }
    }

    private fun currentConversationModelKey(state: ArixUiState): String {
        val options = state.providerConfigs.availableModelOptions()
        val selectedKey = state.sessions
            .firstOrNull { it.id == state.currentSessionId }
            ?.selectedModelKey
            ?: state.draftSelectedModelKey
        return selectedKey.takeIf { key -> options.any { it.key == key } }
            ?: resolveDefaultChatModelKey(state.settings, state.providerConfigs)
    }

    fun selectSession(sessionId: String) {
        selectSessionJob?.cancel()
        _uiState.update { current ->
            current.copy(
                currentScreen = AppScreen.Chat,
                sessions = current.sessions.withMessagesOnlyForSession(sessionId),
                currentSessionId = sessionId,
                draftInput = "",
                draftAttachments = emptyList(),
                draftSelectedModelKey = "",
                draftSelectedSkillIds = emptyList(),
                draftSelectedMcpServerIds = emptyList(),
                draftAgentModeEnabled = false,
                draftChromeEnabled = false,
                draftWorkspaceId = null,
                editingSessionId = null,
                editingMessageId = null,
                unviewedCompletedSessionIds = current.unviewedCompletedSessionIds - sessionId,
                showStarterPromptHint = false,
            )
        }
        selectSessionJob = viewModelScope.launch {
            val loadedSession = if (sessionId == DraftSessionId) {
                null
            } else {
                runCatching {
                    withContext(Dispatchers.IO) {
                        runtime.chatRepository.getSessionWithMessages(sessionId)
                    }
                }.getOrElse { throwable ->
                    if (throwable is CancellationException) throw throwable
                    diagnosticLogger.exception(
                        category = "storage",
                        event = "session_selection_hydration_failed",
                        throwable = throwable,
                        level = "warn",
                        sessionId = sessionId,
                    )
                    null
                }
            }
            loadedSession?.let { session ->
                _uiState.update { current ->
                    if (current.currentSessionId != sessionId) {
                        current
                    } else {
                        current.copy(
                            sessions = replaceOrPrependSession(current.sessions, session)
                                .withMessagesOnlyForSession(sessionId),
                        )
                    }
                }
            }
            persistSessionSelection(sessionId, loadedSession)
        }
    }

    fun renameSession(
        sessionId: String,
        title: String,
    ) {
        val trimmedTitle = title.trim()
        if (trimmedTitle.isBlank()) return
        updateSession(sessionId) { session ->
            if (session.title == trimmedTitle && session.hasCustomTitle) {
                null
            } else {
                session.copy(
                    title = trimmedTitle.take(80),
                    hasCustomTitle = true,
                )
            }
        }
    }

    fun deleteSession(sessionId: String) {
        if (sessionExecutionManager.isSessionRunning(sessionId)) {
            emitTransientMessage(uiString(R.string.message_pause_before_deleting_session))
            return
        }

        var didUpdate = false
        _uiState.update { current ->
            val session = current.sessions.firstOrNull { it.id == sessionId } ?: return@update current
            val updatedSessions = current.sessions.filterNot { it.id == sessionId }
            if (updatedSessions.size == current.sessions.size) return@update current
            didUpdate = true
            current.copy(
                sessions = updatedSessions,
                currentSessionId = if (current.currentSessionId == sessionId) DraftSessionId else current.currentSessionId,
                draftInput = if (current.editingSessionId == sessionId) "" else current.draftInput,
                draftAttachments = if (current.editingSessionId == sessionId) emptyList() else current.draftAttachments,
                draftWorkspaceId = if (current.editingSessionId == sessionId) null else current.draftWorkspaceId,
                editingSessionId = if (current.editingSessionId == sessionId) null else current.editingSessionId,
                editingMessageId = if (current.editingSessionId == sessionId) null else current.editingMessageId,
                unviewedCompletedSessionIds = current.unviewedCompletedSessionIds - sessionId,
                showStarterPromptHint = false,
            )
        }
        if (didUpdate) {
            viewModelScope.launch {
                chatStateStore.flush()
                val sharedWorkspaceFilePaths = withContext(Dispatchers.IO) {
                    runCatching {
                        runtime.chatRepository.getUnreferencedWorkspaceFilePathsForDeletedSession(sessionId)
                    }.getOrElse { throwable ->
                        diagnosticLogger.exception(
                            category = "storage",
                            event = "unreferenced_workspace_lookup_failed",
                            throwable = throwable,
                            level = "warn",
                            sessionId = sessionId,
                            details = mapOf("lookup_scope" to "session"),
                        )
                        emptyList()
                    }
                }
                persistDeleteSession(
                    sessionId = sessionId,
                    sharedWorkspaceFilePaths = sharedWorkspaceFilePaths,
                )
                captureAnalyticsEvent(event = "conversation deleted")
            }
        }
    }

    fun exportSessionToUri(
        sessionId: String,
        destinationUri: Uri,
    ) {
        viewModelScope.launch {
            val didExport = withContext(Dispatchers.IO) {
                val session = runtime.chatRepository.getSessionWithMessages(sessionId) ?: return@withContext false
                val piSession = runCatching { piKernelBridge.exportSessionJsonl(sessionId) }.getOrNull()
                val piPath = piSession?.optString("exported_path").orEmpty()
                val piJsonl = piPath.takeIf(String::isNotBlank)
                    ?.let { path -> runCatching { java.io.File(path).readText(Charsets.UTF_8) }.getOrNull() }
                writeTextToUri(
                    uri = destinationUri,
                    text = JSONObject().apply {
                        put("schemaVersion", 1)
                        put("exportType", "session")
                        put("exportedAtMillis", System.currentTimeMillis())
                        put("session", session.copy(messages = syncActiveBranches(session.messages)).toJson())
                        put("piSession", JSONObject().apply {
                            put("sessionId", sessionId)
                            put("jsonlPath", piPath)
                            put("jsonl", piJsonl ?: "")
                        })
                    }.toString(2),
                )
            }
            emitTransientMessage(uiString(if (didExport) R.string.message_session_exported else R.string.message_session_export_failed))
        }
    }

    fun exportAllDataToUri(destinationUri: Uri) {
        val snapshot = _uiState.value
        viewModelScope.launch {
            val didExport = withContext(Dispatchers.IO) {
                val sessions = runtime.chatRepository.getSessionsWithMessages()
                writeTextToUri(
                    uri = destinationUri,
                    text = buildFullAppExportJson(snapshot, sessions).toString(2),
                )
            }
            emitTransientMessage(uiString(if (didExport) R.string.message_app_data_exported else R.string.message_app_data_export_failed))
        }
    }

    fun exportLogsToUri(destinationUri: Uri) {
        val snapshot = _uiState.value
        viewModelScope.launch {
            diagnosticLogger.event(
                category = "export",
                event = "diagnostic_export_start",
                details = mapOf(
                    "screen" to snapshot.currentScreen.name,
                    "session_count" to snapshot.sessions.size,
                ),
            )
            val didExport = withContext(Dispatchers.IO) {
                writeTextToUri(
                    uri = destinationUri,
                    text = buildDiagnosticLogText(snapshot),
                )
            }
            diagnosticLogger.event(
                category = "export",
                event = if (didExport) "diagnostic_export_end" else "diagnostic_export_failed",
                level = if (didExport) "info" else "warn",
            )
            emitTransientMessage(uiString(if (didExport) R.string.message_logs_exported else R.string.message_logs_export_failed))
        }
    }

    fun importAllDataFromUri(sourceUri: Uri) {
        viewModelScope.launch {
            val result = withContext(Dispatchers.IO) {
                runCatching {
                    val rawValue = readTextFromUri(sourceUri)
                    val json = JSONObject(rawValue)
                    val importedSkills = skillManager.importSkillBundles(json.optJSONArray("skillBundles"))
                    json.optJSONObject("extensionArchive")?.let { archive ->
                        piExtensionManager.restoreArchive(archive)
                    }
                    parseFullAppImport(json, importedSkills)
                }
            }
            result
                .onSuccess { imported ->
                    imported.piSessions.forEach { (sessionId, jsonl) ->
                        runCatching {
                            val importedPi = piKernelBridge.importSessionJsonl(sessionId, jsonl)
                            val path = importedPi.optString("session_file")
                            runtime.chatRepository.upsertAgentSessionMetadata(
                                chatSessionId = sessionId,
                                piSessionId = sessionId,
                                jsonlPath = path,
                                runtime = _uiState.value.settings.defaultRuntimeId?.storageValue.orEmpty(),
                                migrationVersion = 2,
                            )
                        }.onFailure { throwable ->
                            diagnosticLogger.exception(
                                category = "pi_bridge",
                                event = "import_session_jsonl_failed",
                                throwable = throwable,
                                level = "warn",
                                sessionId = sessionId,
                            )
                        }
                    }
                    settingsRepository.replaceImportedSettings(
                        settings = imported.settings,
                        providerConfigs = imported.providerConfigs,
                    )
                    extensionsRepository.updateInstalledSkills(imported.installedSkills)
                    extensionsRepository.updateMcpServers(imported.mcpServers)
                    chatStateStore.updateAndFlush(
                        writeIntent = PersistedChatWriteIntent.ReplaceFromImport,
                    ) {
                        it.copy(
                            sessions = imported.sessions,
                            currentSessionId = imported.currentSessionId,
                        )
                    }
                    _uiState.update { current ->
                        current.copy(
                            sessions = imported.sessions,
                            currentSessionId = imported.currentSessionId,
                            draftInput = "",
                            draftAttachments = emptyList(),
                            draftSelectedModelKey = "",
                            draftSelectedSkillIds = emptyList(),
                            draftSelectedMcpServerIds = emptyList(),
                            draftAgentModeEnabled = false,
                            draftChromeEnabled = false,
                            draftWorkspaceId = null,
                            editingSessionId = null,
                            editingMessageId = null,
                            unviewedCompletedSessionIds = emptySet(),
                            mcpServers = imported.mcpServers,
                        )
                    }
                    refreshPiExtensionState(loadCatalog = false)
                    emitTransientMessage(uiString(R.string.message_app_data_imported))
                }
                .onFailure { throwable ->
                    emitTransientMessage(uiString(R.string.message_app_data_import_failed, throwable.userFacingMessage()))
                }
        }
    }

    fun startEditingUserMessage(
        sessionId: String,
        messageId: String,
    ) {
        if (sessionExecutionManager.isSessionRunning(sessionId)) return

        val session = _uiState.value.sessions.firstOrNull { it.id == sessionId } ?: return
        val message = session.messages.firstOrNull {
            it.id == messageId && it.author == MessageAuthor.User
        } ?: return

        _uiState.update {
            it.copy(
                currentScreen = AppScreen.Chat,
                currentSessionId = sessionId,
                draftInput = message.text,
                draftAttachments = message.attachments.map(::normalizeDraftAttachmentForEditing),
                draftSelectedModelKey = if (sessionId == DraftSessionId) {
                    it.draftSelectedModelKey.ifBlank {
                        resolveDefaultChatModelKey(it.settings, it.providerConfigs)
                    }
                } else {
                    it.draftSelectedModelKey
                },
                draftWorkspaceId = sessionId,
                editingSessionId = sessionId,
                editingMessageId = messageId,
                showStarterPromptHint = false,
            )
        }
        persistCurrentSessionId(sessionId)
    }

    fun cancelMessageEdit() {
        _uiState.update {
            it.copy(
                draftInput = "",
                draftAttachments = emptyList(),
                draftSelectedModelKey = if (it.currentSessionId == DraftSessionId) {
                    it.draftSelectedModelKey.ifBlank {
                        resolveDefaultChatModelKey(it.settings, it.providerConfigs)
                    }
                } else {
                    it.draftSelectedModelKey
                },
                draftSelectedSkillIds = emptyList(),
                draftSelectedMcpServerIds = emptyList(),
                draftAgentModeEnabled = false,
                draftChromeEnabled = false,
                draftWorkspaceId = null,
                editingSessionId = null,
                editingMessageId = null,
                showStarterPromptHint = false,
            )
        }
    }

    fun deleteMessage(
        sessionId: String,
        messageId: String,
    ) {
        if (sessionExecutionManager.isSessionRunning(sessionId)) return

        var didUpdate = false
        var updatedSessionForPersistence: ChatSession? = null
        var removedSessionForPersistence = false
        var removedMessageIds = emptyList<String>()

        _uiState.update { current ->
            val sessionIndex = current.sessions.indexOfFirst { it.id == sessionId }
            if (sessionIndex < 0) return@update current

            val session = current.sessions[sessionIndex]
            val messageIndex = session.messages.indexOfFirst { it.id == messageId }
            if (messageIndex < 0) return@update current

            val trimFromIndex = session.messages.resolveConversationTrimIndex(messageIndex)
            val trimmedMessages = session.messages.take(trimFromIndex)
            val removedMessages = session.messages.drop(trimFromIndex)
            removedMessageIds = removedMessages.map { it.id }
            val updatedSessions = current.sessions.toMutableList().apply {
                removeAt(sessionIndex)
                if (trimmedMessages.isNotEmpty()) {
                    val updatedSession = session.withMessages(trimmedMessages)
                    updatedSessionForPersistence = updatedSession
                    add(sessionIndex.coerceAtMost(size), updatedSession)
                } else {
                    removedSessionForPersistence = true
                }
            }

            didUpdate = true
            current.copy(
                sessions = updatedSessions,
                currentSessionId = when {
                    trimmedMessages.isEmpty() && current.currentSessionId == sessionId -> DraftSessionId
                    else -> current.currentSessionId
                },
                draftSelectedSkillIds = if (
                    trimmedMessages.isEmpty() && current.currentSessionId == sessionId
                ) {
                    emptyList()
                } else {
                    current.draftSelectedSkillIds
                },
                draftSelectedMcpServerIds = if (
                    trimmedMessages.isEmpty() && current.currentSessionId == sessionId
                ) {
                    emptyList()
                } else {
                    current.draftSelectedMcpServerIds
                },
                draftInput = if (current.editingSessionId == sessionId) "" else current.draftInput,
                draftAttachments = if (current.editingSessionId == sessionId) {
                    emptyList()
                } else {
                    current.draftAttachments
                },
                draftWorkspaceId = if (current.editingSessionId == sessionId) null else current.draftWorkspaceId,
                editingSessionId = if (current.editingSessionId == sessionId) null else current.editingSessionId,
                editingMessageId = if (current.editingSessionId == sessionId) null else current.editingMessageId,
                pendingResponseSessionId = if (current.pendingResponseSessionId == sessionId) null else current.pendingResponseSessionId,
                pendingToolInvocations = if (current.pendingResponseSessionId == sessionId) {
                    emptyList()
                } else {
                    current.pendingToolInvocations
                },
            )
        }

        if (didUpdate) {
            viewModelScope.launch {
                chatStateStore.flush()
                val sharedWorkspaceFilePaths = withContext(Dispatchers.IO) {
                    runCatching {
                        runtime.chatRepository.getUnreferencedWorkspaceFilePathsForDeletedMessages(
                            sessionId = sessionId,
                            messageIds = removedMessageIds,
                        )
                    }.getOrElse { throwable ->
                        diagnosticLogger.exception(
                            category = "storage",
                            event = "unreferenced_workspace_lookup_failed",
                            throwable = throwable,
                            level = "warn",
                            sessionId = sessionId,
                            details = mapOf(
                                "lookup_scope" to "messages",
                                "message_count" to removedMessageIds.size,
                            ),
                        )
                        emptyList()
                    }
                }
                if (removedSessionForPersistence) {
                    persistDeleteSession(
                        sessionId = sessionId,
                        sharedWorkspaceFilePaths = sharedWorkspaceFilePaths,
                    )
                } else {
                    updatedSessionForPersistence?.let { persistSessionSnapshotAndFlush(it) }
                    if (sharedWorkspaceFilePaths.isNotEmpty()) {
                        scheduleSessionRuntimeDataCleanup(
                            sessionIds = emptyList(),
                            sharedWorkspaceFilePaths = sharedWorkspaceFilePaths,
                            mode = _uiState.value.settings.agentWorkspaceMode,
                        )
                    }
                }
            }
        }
    }

    fun redoAgentMessage(
        sessionId: String,
        messageId: String,
    ) {
        if (sessionExecutionManager.isSessionRunning(sessionId)) return

        val snapshot = _uiState.value
        var request: SessionTurnRequest? = null
        var updatedSessionForPersistence: ChatSession? = null
        var piBranchMessageId: String? = null

        _uiState.update { current ->
            val sessionIndex = current.sessions.indexOfFirst { it.id == sessionId }
            if (sessionIndex < 0) return@update current

            val session = current.sessions[sessionIndex]
            val messageIndex = session.messages.indexOfFirst {
                it.id == messageId && it.author == MessageAuthor.Agent
            }
            if (messageIndex < 0) return@update current

            val trimFromIndex = session.messages.resolveConversationTrimIndex(messageIndex)
            val trimmedMessages = session.messages.take(trimFromIndex)
            if (trimmedMessages.lastOrNull()?.author != MessageAuthor.User) {
                return@update current
            }
            piBranchMessageId = trimmedMessages.piBranchMessageIdBeforeLastUser()

            request = SessionTurnRequest(
                sessionId = sessionId,
                settings = resolveModelSettings(
                    baseSettings = snapshot.settings,
                    providerConfigs = snapshot.providerConfigs,
                    preferredModelKey = session.selectedModelKey,
                    fallbackModelKey = resolveDefaultChatModelKey(snapshot.settings, snapshot.providerConfigs),
                ),
                requestMessages = trimmedMessages,
                selectedSkillIds = session.selectedSkillIds,
                activeSkills = session.activeSkills,
                activeMcpServerIds = session.activeMcpServerIds,
                agentModeEnabled = session.agentModeEnabled,
                chromeEnabled = session.chromeEnabled,
                providerConfigs = snapshot.providerConfigs,
            )
            val updatedSessions = current.sessions.toMutableList().apply {
                removeAt(sessionIndex)
                val updatedSession = session.withMessages(trimmedMessages)
                updatedSessionForPersistence = updatedSession
                add(0, updatedSession)
            }

            current.copy(
                sessions = updatedSessions,
                currentSessionId = sessionId,
                currentScreen = AppScreen.Chat,
                draftInput = "",
                draftAttachments = emptyList(),
                draftWorkspaceId = null,
                editingSessionId = null,
                editingMessageId = null,
            )
        }

        val turnRequest = request ?: return
        updatedSessionForPersistence?.let { session ->
            persistSessionSnapshot(
                session = session,
                currentSessionId = sessionId,
                moveToFront = true,
            )
        }
        viewModelScope.launch {
            navigatePiBranch(sessionId, piBranchMessageId, resetWhenMissing = true)
            sessionExecutionManager.startTurn(turnRequest)
        }
    }

    fun retryUserMessage(
        sessionId: String,
        messageId: String,
    ) {
        if (sessionExecutionManager.isSessionRunning(sessionId)) return

        val snapshot = _uiState.value
        var request: SessionTurnRequest? = null
        var updatedSessionForPersistence: ChatSession? = null
        var piBranchMessageId: String? = null

        _uiState.update { current ->
            val sessionIndex = current.sessions.indexOfFirst { it.id == sessionId }
            if (sessionIndex < 0) return@update current

            val session = current.sessions[sessionIndex]
            val userMessage = session.messages.firstOrNull {
                it.id == messageId && it.author == MessageAuthor.User
            } ?: return@update current
            val userMessageIndex = session.messages.indexOfFirst { it.id == messageId }
            piBranchMessageId = session.messages.take(userMessageIndex).lastOrNull()?.id

            val retryMessage = userMessage.copy(
                id = "user-${System.currentTimeMillis()}",
                createdAtMillis = System.currentTimeMillis(),
                branchGroup = null,
            )
            val branchedMessages = createEditedMessageBranch(
                messages = session.messages,
                messageId = messageId,
                replacement = retryMessage,
            ) ?: return@update current
            val updatedSession = session.withMessages(branchedMessages)
            updatedSessionForPersistence = updatedSession
            val updatedSessions = current.sessions.toMutableList().apply {
                removeAt(sessionIndex)
                add(0, updatedSession)
            }

            request = SessionTurnRequest(
                sessionId = sessionId,
                settings = resolveModelSettings(
                    baseSettings = snapshot.settings,
                    providerConfigs = snapshot.providerConfigs,
                    preferredModelKey = updatedSession.selectedModelKey,
                    fallbackModelKey = resolveDefaultChatModelKey(snapshot.settings, snapshot.providerConfigs),
                ),
                requestMessages = updatedSession.messages,
                selectedSkillIds = updatedSession.selectedSkillIds,
                activeSkills = updatedSession.activeSkills,
                activeMcpServerIds = updatedSession.activeMcpServerIds,
                agentModeEnabled = updatedSession.agentModeEnabled,
                chromeEnabled = updatedSession.chromeEnabled,
                providerConfigs = snapshot.providerConfigs,
            )

            current.copy(
                sessions = updatedSessions,
                currentSessionId = sessionId,
                currentScreen = AppScreen.Chat,
                draftInput = "",
                draftAttachments = emptyList(),
                draftWorkspaceId = null,
                editingSessionId = null,
                editingMessageId = null,
            )
        }

        val turnRequest = request ?: return
        updatedSessionForPersistence?.let { session ->
            persistSessionSnapshot(
                session = session,
                currentSessionId = sessionId,
                moveToFront = true,
            )
        }
        viewModelScope.launch {
            navigatePiBranch(sessionId, piBranchMessageId, resetWhenMissing = true)
            sessionExecutionManager.startTurn(turnRequest)
        }
    }

    private suspend fun navigatePiBranch(
        sessionId: String,
        arixMessageId: String?,
        resetWhenMissing: Boolean = false,
    ) {
        val settings = _uiState.value.settings
        val workspaceDirectory = workspaceFileBridge.workspaceDirectory(
            sessionId = sessionId,
            mode = settings.agentWorkspaceMode,
        )
        val metadata = runtime.chatRepository.getAgentSessionMetadata(sessionId)
        val entryId = arixMessageId?.let { messageId ->
            runtime.chatRepository.getAgentMessageEntryIds(sessionId, messageId).lastOrNull()
        }
        runCatching {
            piKernelBridge.navigateSession(
                sessionId = sessionId,
                entryId = entryId.orEmpty(),
                reset = entryId == null && resetWhenMissing,
                sessionPayload = JSONObject().apply {
                    put("session_file", metadata?.jsonlPath.orEmpty())
                    put("workspace_directory", workspaceDirectory)
                    put("runtime", metadata?.runtime ?: settings.defaultRuntimeId?.storageValue.orEmpty())
                    put("platform", "android")
                    put("workspace_trusted", true)
                    val modelKey = thinkingCatalogKey(settings.piProviderId, settings.modelId)
                    val thinkingLevelMap = _uiState.value.thinkingLevelClampsByProviderModel[modelKey].orEmpty()
                    val isReasoningModel = modelKey in _uiState.value.reasoningModels
                    put("model_config", settings.toPiModelConfig(thinkingLevelMap, isReasoningModel).toJson())
                    put("system_prompt", "")
                    put("host_tools", JSONArray())
                },
            )
        }.onFailure { throwable ->
            diagnosticLogger.exception(
                category = "pi_bridge",
                event = "navigate_session_branch_failed",
                throwable = throwable,
                level = "warn",
                sessionId = sessionId,
            )
        }
    }

    fun switchUserMessageBranch(
        sessionId: String,
        messageId: String,
        delta: Int,
    ) {
        if (sessionExecutionManager.isSessionRunning(sessionId)) return
        var didUpdate = false
        var updatedSessionForPersistence: ChatSession? = null

        _uiState.update { current ->
            val sessionIndex = current.sessions.indexOfFirst { it.id == sessionId }
            if (sessionIndex < 0) return@update current
            val session = current.sessions[sessionIndex]
            val updatedMessages = switchMessageBranch(
                messages = session.messages,
                messageId = messageId,
                delta = delta,
            ) ?: return@update current
            didUpdate = true
            val updatedSession = session.withMessages(updatedMessages)
            updatedSessionForPersistence = updatedSession
            val updatedSessions = current.sessions.toMutableList().apply {
                set(sessionIndex, updatedSession)
            }
            current.copy(sessions = updatedSessions)
        }

        if (didUpdate) {
            updatedSessionForPersistence?.let(::persistSessionSnapshot)
        }
    }

    fun saveSettings(
        systemPrompt: String,
        tavilyApiKey: String,
        tavilyBaseUrl: String,
        llmInactivityReconnectTimeoutSeconds: Int,
        keepTasksRunningInBackground: Boolean,
        notifyOnTaskCompletion: Boolean,
        agentWorkspaceMode: AgentWorkspaceMode,
        autoCleanOldCommandHistory: Boolean,
        oldCommandHistoryRetentionHours: Int,
        agentModeAuthorizationEnabled: Boolean,
        language: AppLanguage,
        themeMode: AppThemeMode,
        defaultChatModelKey: String,
        defaultTitleModelKey: String,
        defaultNamingModelKey: String,
        defaultCompactingModelKey: String,
    ) {
        viewModelScope.launch {
            val currentState = _uiState.value
            val modelOptions = currentState.providerConfigs.availableModelOptions()
            val resolvedDefaultChatModelKey = resolveStoredOrAutomaticModelKey(
                modelKey = defaultChatModelKey,
                options = modelOptions,
                purpose = AutomaticModelPurpose.Chat,
            )
            val selectedModelSettings = resolveModelSettings(
                baseSettings = currentState.settings,
                providerConfigs = currentState.providerConfigs,
                preferredModelKey = resolvedDefaultChatModelKey,
                fallbackModelKey = resolvedDefaultChatModelKey,
            )
            settingsRepository.updateSettings(
                currentState.settings.copy(
                    piProviderId = selectedModelSettings.piProviderId,
                    providerConfigId = selectedModelSettings.providerConfigId,
                    providerAuthMethod = selectedModelSettings.providerAuthMethod,
                    apiKey = selectedModelSettings.apiKey,
                    oauthCredentialJson = selectedModelSettings.oauthCredentialJson,
                    providerEnvironmentVariables =
                        selectedModelSettings.providerEnvironmentVariables,
                    baseUrl = selectedModelSettings.baseUrl,
                    modelId = selectedModelSettings.modelId,
                    userAgent = selectedModelSettings.userAgent,
                    customHeaders = selectedModelSettings.customHeaders,
                    systemPrompt = systemPrompt,
                    tavilyApiKey = tavilyApiKey.trim(),
                    tavilyBaseUrl = normalizeTavilyBaseUrl(tavilyBaseUrl),
                    llmInactivityReconnectTimeoutSeconds =
                        normalizeLlmInactivityReconnectTimeoutSeconds(
                            llmInactivityReconnectTimeoutSeconds
                    ),
                    keepTasksRunningInBackground = keepTasksRunningInBackground,
                    notifyOnTaskCompletion = notifyOnTaskCompletion,
                    agentWorkspaceMode = agentWorkspaceMode,
                    autoCleanOldCommandHistory = autoCleanOldCommandHistory,
                    oldCommandHistoryRetentionHours = normalizeOldCommandHistoryRetentionHours(
                        oldCommandHistoryRetentionHours
                    ),
                    agentModeAuthorizationEnabled = agentModeAuthorizationEnabled,
                    language = language,
                    themeMode = themeMode,
                    defaultChatModelKey = normalizeSelectableModelKey(defaultChatModelKey, modelOptions),
                    defaultTitleModelKey = normalizeSelectableModelKey(defaultTitleModelKey, modelOptions),
                    defaultNamingModelKey = normalizeSelectableModelKey(defaultNamingModelKey, modelOptions),
                    defaultCompactingModelKey = normalizeSelectableModelKey(defaultCompactingModelKey, modelOptions),
                )
            )
        }
    }

    // ── Multi-Provider methods ────────────────────────────────────────────────

    fun updateAppLanguage(language: AppLanguage) {
        viewModelScope.launch {
            settingsRepository.updateLanguage(language)
        }
    }


    fun upsertProviderConfig(config: LlmProviderConfig) {
        viewModelScope.launch {
            val normalizedConfig = normalizeProviderConfig(config)
            settingsRepository.upsertProviderConfig(normalizedConfig)
            if (
                normalizedConfig.authMethod != ProviderAuthMethod.OAuth ||
                normalizedConfig.oauthCredentialJson.isBlank()
            ) {
                runCatching { runtime.piKernelBridge.clearProviderCredential(normalizedConfig.id) }
            }
            captureAnalyticsEvent(
                event = "provider added",
                properties = mapOf(
                    "provider" to com.arix.app.data.PiProviderCatalog
                        .resolve(config.piProviderId).displayName,
                    "provider_id" to config.id,
                ),
            )
        }
    }

    fun removeProviderConfig(id: String) {
        viewModelScope.launch {
            settingsRepository.removeProviderConfig(id)
            runCatching { runtime.piKernelBridge.clearProviderCredential(id) }
            captureAnalyticsEvent(event = "provider removed")
        }
    }

    fun setProviderEnabled(
        id: String,
        enabled: Boolean,
    ) {
        viewModelScope.launch {
            settingsRepository.setProviderEnabled(id, enabled)
        }
    }

    fun setReasoningEffort(effort: String) {
        viewModelScope.launch {
            settingsRepository.updateSettings(
                _uiState.value.settings.copy(reasoningEffort = normalizeReasoningEffort(effort)),
            )
        }
    }

    fun setCurrentChatModelSelection(modelKey: String) {
        var didUpdate = false
        var sessionIdForPersistence: String? = null
        _uiState.update { current ->
            if (current.currentSessionId == DraftSessionId) {
                if (current.draftSelectedModelKey == modelKey) return@update current
                didUpdate = true
                current.copy(draftSelectedModelKey = modelKey)
            } else {
                val sessionIndex = current.sessions.indexOfFirst { it.id == current.currentSessionId }
                if (sessionIndex < 0) return@update current
                val session = current.sessions[sessionIndex]
                if (session.selectedModelKey == modelKey) return@update current
                val updatedSession = session.copy(selectedModelKey = modelKey)
                val updatedSessions = current.sessions.toMutableList().apply {
                    set(sessionIndex, updatedSession)
                }
                sessionIdForPersistence = current.currentSessionId
                didUpdate = true
                current.copy(sessions = updatedSessions)
            }
        }
        val persistedSessionId = sessionIdForPersistence
        if (didUpdate && persistedSessionId != null) {
            persistSessionMutation(persistedSessionId) { session ->
                if (session.selectedModelKey == modelKey) {
                    null
                } else {
                    session.copy(selectedModelKey = modelKey)
                }
            }
        }
    }

    fun setCurrentChatModelSelectionAndResolveThinkingLevels(
        modelKey: String,
        onResolved: (Boolean) -> Unit,
    ) {
        setCurrentChatModelSelection(modelKey)
        val current = _uiState.value
        val option = current.providerConfigs.availableModelOptions()
            .firstOrNull { it.key == modelKey }
            ?: return onResolved(false)
        val cacheKey = thinkingCatalogKey(option.piProviderId, option.modelId)
        current.thinkingLevelsByProviderModel[cacheKey]?.let { levels ->
            onResolved(levels.isNotEmpty())
            return
        }
        viewModelScope.launch {
            val catalogResult = ProviderModelCatalogClient.fetchPublicThinkingCatalog(listOf(option))
            if (catalogResult.levelsByProviderModel.isNotEmpty()) {
                settingsRepository.saveThinkingCatalogCache(
                    catalogResult.levelsByProviderModel,
                    catalogResult.levelMapsByProviderModel,
                    catalogResult.reasoningModels,
                )
                _uiState.update { state ->
                    state.copy(
                        thinkingLevelsByProviderModel =
                            state.thinkingLevelsByProviderModel + catalogResult.levelsByProviderModel,
                        thinkingLevelClampsByProviderModel =
                            (state.thinkingLevelClampsByProviderModel -
                                catalogResult.levelsByProviderModel.keys) +
                                catalogResult.levelMapsByProviderModel,
                        reasoningModels =
                            (state.reasoningModels - catalogResult.levelsByProviderModel.keys) +
                                catalogResult.reasoningModels,
                    )
                }
            }
            onResolved(catalogResult.levelsByProviderModel[cacheKey].orEmpty().isNotEmpty())
        }
    }

    fun refreshCurrentChatThinkingLevels() {
        val current = _uiState.value
        val selectedModelKey = current.sessions
            .firstOrNull { it.id == current.currentSessionId }
            ?.selectedModelKey
            ?.takeIf(String::isNotBlank)
            ?: current.draftSelectedModelKey.takeIf(String::isNotBlank)
            ?: resolveDefaultChatModelKey(current.settings, current.providerConfigs)
        val option = current.providerConfigs.availableModelOptions()
            .firstOrNull { it.key == selectedModelKey }
            ?: return
        viewModelScope.launch {
            val catalogResult = ProviderModelCatalogClient.fetchPublicThinkingCatalog(listOf(option))
            if (catalogResult.levelsByProviderModel.isEmpty()) return@launch
            settingsRepository.saveThinkingCatalogCache(
                catalogResult.levelsByProviderModel,
                catalogResult.levelMapsByProviderModel,
                catalogResult.reasoningModels,
            )
            _uiState.update { state ->
                state.copy(
                    thinkingLevelsByProviderModel =
                        state.thinkingLevelsByProviderModel + catalogResult.levelsByProviderModel,
                    thinkingLevelClampsByProviderModel =
                        (state.thinkingLevelClampsByProviderModel -
                            catalogResult.levelsByProviderModel.keys) +
                            catalogResult.levelMapsByProviderModel,
                    reasoningModels =
                        (state.reasoningModels - catalogResult.levelsByProviderModel.keys) +
                            catalogResult.reasoningModels,
                )
            }
        }
    }

    fun fetchModels(
        config: LlmProviderConfig,
        onComplete: (List<String>) -> Unit,
    ) {
        _uiState.update { it.copy(isFetchingModels = true) }
        viewModelScope.launch {
            val result = ProviderModelCatalogClient.fetchModels(
                config = config,
            )
            _uiState.update { current ->
                current.copy(
                    isFetchingModels = false,
                )
            }
            onComplete(result.models)
            if (result.error != null) {
                _transientMessages.emit(
                    UiText.Resource(R.string.message_fetch_models_failed, listOf(result.error)),
                )
            }
        }
    }

    fun startProviderLogin(
        providerConfigId: String,
        providerId: String,
        authMethod: ProviderAuthMethod,
        oauthFlow: String = "",
    ) {
        val normalizedProviderId = providerId.trim()
        if (normalizedProviderId.isBlank()) return
        if (authMethod == ProviderAuthMethod.Ambient) return
        providerAuthJob?.cancel()
        _uiState.update {
            it.copy(
                providerAuthState = PiProviderAuthState(
                    providerId = normalizedProviderId,
                    authMethod = authMethod,
                    isRunning = true,
                    statusMessage = if (authMethod == ProviderAuthMethod.OAuth) {
                        "Waiting for authorization."
                    } else {
                        "Waiting for credentials."
                    },
                )
            )
        }
        providerAuthJob = viewModelScope.launch {
            runCatching {
                runtime.piKernelBridge.loginProvider(
                    providerConfigId = providerConfigId,
                    providerId = normalizedProviderId,
                    authMethod = authMethod.storageValue,
                    oauthFlow = oauthFlow,
                ) { event, payload ->
                    _uiState.update { current ->
                        if (
                            current.providerAuthState.providerId != normalizedProviderId ||
                            current.providerAuthState.authMethod != authMethod
                        ) {
                            current
                        } else {
                            val state = current.providerAuthState
                            current.copy(
                                providerAuthState = when (event) {
                                    "auth_url" -> state.copy(
                                        authorizationUrl = payload.optString("url"),
                                        statusMessage = payload.optString("instructions")
                                            .ifBlank { "Complete authorization in your browser." },
                                    )

                                    "auth_device_code" -> state.copy(
                                        deviceCode = payload.optString("user_code"),
                                        verificationUrl = payload.optString("verification_uri"),
                                        statusMessage = "Enter the device code in your browser.",
                                    )

                                    "auth_prompt" -> state.copy(
                                        prompt = payload.toPiOAuthPrompt(),
                                        statusMessage = payload.optString("message"),
                                    )

                                    "auth_progress" -> state.copy(
                                        statusMessage = payload.optString("message"),
                                    )

                                    else -> state
                                }
                            )
                        }
                    }
                }
            }.fold(
                onSuccess = { payload ->
                    _uiState.update { current ->
                        if (
                            current.providerAuthState.providerId != normalizedProviderId ||
                            current.providerAuthState.authMethod != authMethod
                        ) {
                            current
                        } else {
                            current.copy(
                                providerAuthState = current.providerAuthState.copy(
                                    isRunning = false,
                                    prompt = null,
                                    apiKey = payload.optString("api_key"),
                                    oauthCredentialJson = payload.optJSONObject("oauth_credential")
                                        ?.toString()
                                        .orEmpty(),
                                    providerEnvironmentVariables =
                                        payload.toPiProviderEnvironmentVariables(),
                                    statusMessage = if (authMethod == ProviderAuthMethod.OAuth) {
                                        "Connected with OAuth."
                                    } else {
                                        "API key configured."
                                    },
                                    errorMessage = "",
                                )
                            )
                        }
                    }
                },
                onFailure = { throwable ->
                    if (throwable is CancellationException) return@fold
                    _uiState.update { current ->
                        if (
                            current.providerAuthState.providerId != normalizedProviderId ||
                            current.providerAuthState.authMethod != authMethod
                        ) {
                            current
                        } else {
                            current.copy(
                                providerAuthState = current.providerAuthState.copy(
                                    isRunning = false,
                                    prompt = null,
                                    errorMessage = throwable.userFacingMessage(),
                                    statusMessage = "",
                                )
                            )
                        }
                    }
                },
            )
        }
    }

    fun submitProviderAuthPrompt(
        promptId: String,
        value: String,
        cancelled: Boolean = false,
    ) {
        viewModelScope.launch {
            runCatching {
                runtime.piKernelBridge.submitAuthPrompt(
                    promptId = promptId,
                    value = value,
                    cancelled = cancelled,
                )
            }.fold(
                onSuccess = {
                    _uiState.update { current ->
                        if (current.providerAuthState.prompt?.id != promptId) {
                            current
                        } else {
                            current.copy(
                                providerAuthState = current.providerAuthState.copy(prompt = null)
                            )
                        }
                    }
                },
                onFailure = { throwable ->
                    _uiState.update { current ->
                        if (current.providerAuthState.prompt?.id != promptId) {
                            current
                        } else {
                            current.copy(
                                providerAuthState = current.providerAuthState.copy(
                                    errorMessage = throwable.userFacingMessage(),
                                )
                            )
                        }
                    }
                },
            )
        }
    }

    fun clearProviderAuthState() {
        providerAuthJob?.cancel()
        providerAuthJob = null
        _uiState.update { it.copy(providerAuthState = PiProviderAuthState()) }
    }

    private fun mergeFetchedModels(
        current: LlmProviderConfig,
        fetchedModels: List<String>,
    ): LlmProviderConfig {
        val normalizedCurrent = normalizeProviderConfig(current)
        val previousModels = normalizedCurrent.cachedModels.toSet()
        val normalizedFetched = fetchedModels
            .map(String::trim)
            .filter(String::isNotEmpty)
            .distinct()
        val enabledModels = normalizedFetched.filter { modelId ->
            normalizedCurrent.enabledModelIds.contains(modelId) || !previousModels.contains(modelId)
        }
        return normalizeProviderConfig(
            normalizedCurrent.copy(
                modelId = when {
                    normalizedCurrent.modelId in normalizedFetched -> normalizedCurrent.modelId
                    normalizedFetched.isNotEmpty() -> normalizedFetched.first()
                    else -> normalizedCurrent.modelId
                },
                cachedModels = normalizedFetched,
                enabledModelIds = enabledModels,
            )
        )
    }

    fun installSkillFromDirectory(treeUri: Uri) {
        performSkillInstall {
            skillManager.installSkillFromDirectory(treeUri)
        }
    }

    fun installSkillFromZip(
        zipUri: Uri,
        onComplete: (Boolean) -> Unit = {},
    ) {
        performSkillInstall(onComplete = onComplete) {
            skillManager.installSkillFromZipUri(zipUri)
        }
    }

    fun installSkillFromRemote(
        url: String,
        onComplete: (Boolean) -> Unit = {},
    ) {
        val trimmedUrl = url.trim()
        if (trimmedUrl.isBlank()) {
            onComplete(false)
            return
        }
        performSkillInstall(onComplete = onComplete) {
            skillManager.installSkillFromRemote(trimmedUrl)
        }
    }

    fun removeSkill(skillId: String) {
        viewModelScope.launch {
            val result = skillManager.uninstallSkill(skillId)
            if (result.isSuccess) {
                piKernelBridge.reloadAllExtensions(runtime.piExtensionStateRepository.loadOptions())
            }
            captureAnalyticsEvent(
                event = "skill removed",
                properties = mapOf("skill_id" to skillId),
            )
        }
    }

    fun setSkillEnabled(
        skillId: String,
        enabled: Boolean,
    ) {
        viewModelScope.launch {
            extensionsRepository.setSkillEnabled(skillId, enabled)
            piKernelBridge.reloadAllExtensions(runtime.piExtensionStateRepository.loadOptions())
        }
    }

    fun refreshPiExtensions() {
        viewModelScope.launch {
            refreshPiExtensionState(loadCatalog = true)
        }
    }

    private fun refreshImportedPiExtensions() {
        val generation = ++piExtensionRefreshGeneration
        viewModelScope.launch {
            val result = piExtensionManager.listImported()
            if (generation == piExtensionRefreshGeneration) {
                publishImportedPiExtensions(result)
            }
        }
    }

    fun loadPiPackageDetails(entry: PiExtensionCatalogEntry) {
        viewModelScope.launch {
            _uiState.update {
                it.copy(
                    selectedPiPackageSource = entry.source,
                    selectedPiPackageDetails = null,
                    isLoadingPiPackageDetails = true,
                    piPackageDetailsError = "",
                )
            }
            val result = piExtensionManager.fetchPackageDetails(entry)
            _uiState.update { current ->
                if (current.selectedPiPackageSource != entry.source) {
                    current
                } else {
                    current.copy(
                        selectedPiPackageDetails = result.getOrNull(),
                        isLoadingPiPackageDetails = false,
                        piPackageDetailsError = result.exceptionOrNull()?.userFacingMessage().orEmpty(),
                    )
                }
            }
        }
    }

    fun installPiExtensionPackage(source: String) {
        performPiExtensionOperation(source) {
            piExtensionManager.installPackage(source)
        }
    }

    fun updatePiExtensionPackage(source: String) {
        performPiExtensionOperation(source) {
            piExtensionManager.updatePackage(source)
        }
    }

    fun removePiExtension(extension: InstalledPiExtension) {
        performPiExtensionOperation(extension.id) {
            piExtensionManager.remove(extension)
        }
    }

    fun setPiExtensionEnabled(
        extension: InstalledPiExtension,
        enabled: Boolean,
    ) {
        piExtensionRefreshGeneration += 1
        _uiState.update { current ->
            current.copy(
                installedPiExtensions = current.installedPiExtensions.map { installed ->
                    if (installed.id == extension.id) installed.copy(isEnabled = enabled) else installed
                },
            )
        }
        performPiExtensionOperation(extension.id) {
            piExtensionManager.setEnabled(extension, enabled)
        }
    }

    fun importPiExtension(
        uri: Uri,
        onComplete: (Boolean) -> Unit = {},
    ) {
        viewModelScope.launch {
            _uiState.update { it.copy(piExtensionOperationSource = "import") }
            val result = piExtensionManager.importFromUri(uri)
            result
                .onSuccess { extension ->
                    emitTransientMessage(
                        uiString(R.string.message_pi_extension_imported, extension.name)
                    )
                }
                .onFailure { throwable ->
                    emitTransientMessage(
                        uiString(
                            R.string.message_pi_extension_operation_failed,
                            throwable.userFacingMessage(),
                        )
                    )
                }
            refreshPiExtensionState(loadCatalog = false)
            _uiState.update { it.copy(piExtensionOperationSource = "") }
            onComplete(result.isSuccess)
        }
    }

    private fun performPiExtensionOperation(
        operationSource: String,
        operation: suspend () -> Result<Unit>,
    ) {
        viewModelScope.launch {
            _uiState.update { it.copy(piExtensionOperationSource = operationSource) }
            val result = operation()
            result
                .onSuccess {
                    emitTransientMessage(uiString(R.string.message_pi_extension_updated))
                }
                .onFailure { throwable ->
                    emitTransientMessage(
                        uiString(
                            R.string.message_pi_extension_operation_failed,
                            throwable.userFacingMessage(),
                        )
                    )
                }
            refreshPiExtensionState(loadCatalog = false)
            _uiState.update { it.copy(piExtensionOperationSource = "") }
        }
    }

    private suspend fun refreshPiExtensionState(loadCatalog: Boolean) {
        val generation = ++piExtensionRefreshGeneration
        _uiState.update { it.copy(isLoadingPiExtensions = true) }
        val installedResult = piExtensionManager.listInstalled()
        runtime.nativeModManager.refreshDiscovery()
        val catalogResult = if (loadCatalog) {
            piExtensionManager.fetchCatalog()
        } else {
            null
        }
        if (generation != piExtensionRefreshGeneration) return
        _uiState.update { current ->
            current.copy(
                installedPiExtensions = installedResult.getOrDefault(current.installedPiExtensions),
                hasLoadedInstalledPiExtensions = true,
                piExtensionCatalog = catalogResult?.getOrDefault(current.piExtensionCatalog)
                    ?: current.piExtensionCatalog,
                isLoadingPiExtensions = false,
                piExtensionCatalogError = catalogResult?.exceptionOrNull()?.userFacingMessage()
                    ?: if (loadCatalog) "" else current.piExtensionCatalogError,
            )
        }
        installedResult.exceptionOrNull()?.let { throwable ->
            emitTransientMessage(
                uiString(
                    R.string.message_pi_extension_operation_failed,
                    throwable.userFacingMessage(),
                )
            )
        }
    }

    private fun publishImportedPiExtensions(
        result: Result<List<InstalledPiExtension>>,
    ) {
        _uiState.update { current ->
            current.copy(
                installedPiExtensions = result.getOrNull()?.let { imported ->
                    mergeImportedPiExtensions(current.installedPiExtensions, imported)
                } ?: current.installedPiExtensions,
                hasLoadedInstalledPiExtensions = true,
            )
        }
    }

    fun setComposerSkillSelected(
        skillId: String,
        selected: Boolean,
    ) {
        val operation = "skills.selection"
        if (
            !modKernel.operations.hasInterceptors(operation) &&
            "operation:$operation" !in arixAppExtensionManager.state.value.snapshot.eventNames
        ) {
            setComposerSkillSelectedNow(skillId, selected)
            return
        }
        viewModelScope.launch {
            val result = dispatchArixOperation(
                operation = operation,
                payload = JSONObject()
                    .put("skill_id", skillId)
                    .put("selected", selected),
            )
            if (result.cancelled) return@launch
            val resolvedSkillId = result.payload.optString("skill_id", skillId)
            val resolvedSelected = result.payload.optBoolean("selected", selected)
            withContext(Dispatchers.Main.immediate) {
                setComposerSkillSelectedNow(resolvedSkillId, resolvedSelected)
            }
        }
    }

    private fun setComposerSkillSelectedNow(
        skillId: String,
        selected: Boolean,
    ) {
        var didUpdate = false
        var sessionIdForPersistence: String? = null
        _uiState.update { current ->
            if (current.currentSessionId == DraftSessionId) {
                val updatedDraftSelection = updateOrderedSelection(
                    current.draftSelectedSkillIds,
                    skillId,
                    selected,
                )
                if (updatedDraftSelection == current.draftSelectedSkillIds) {
                    current
                } else {
                    didUpdate = true
                    current.copy(draftSelectedSkillIds = updatedDraftSelection)
                }
            } else {
                val sessionIndex = current.sessions.indexOfFirst { it.id == current.currentSessionId }
                if (sessionIndex < 0) return@update current
                val updatedSessions = current.sessions.toMutableList()
                val session = updatedSessions.removeAt(sessionIndex)
                val updatedSelectedSkillIds = updateOrderedSelection(
                    session.selectedSkillIds,
                    skillId,
                    selected,
                )
                val updatedActiveSkills = session.activeSkills.filter { activeSkill ->
                    updatedSelectedSkillIds.contains(activeSkill.skillId)
                }
                if (
                    updatedSelectedSkillIds == session.selectedSkillIds &&
                    updatedActiveSkills == session.activeSkills
                ) {
                    updatedSessions.add(sessionIndex, session)
                    current
                } else {
                    didUpdate = true
                    val updatedSession = session.copy(
                        selectedSkillIds = updatedSelectedSkillIds,
                        activeSkills = updatedActiveSkills,
                    )
                    sessionIdForPersistence = current.currentSessionId
                    updatedSessions.add(
                        sessionIndex.coerceAtMost(updatedSessions.size),
                        updatedSession,
                    )
                    current.copy(sessions = updatedSessions)
                }
            }
        }
        val persistedSessionId = sessionIdForPersistence
        if (didUpdate && persistedSessionId != null) {
            persistSessionMutation(persistedSessionId) { session ->
                val selectedSkillIds = updateOrderedSelection(
                    session.selectedSkillIds,
                    skillId,
                    selected,
                )
                val activeSkills = session.activeSkills.filter { activeSkill ->
                    selectedSkillIds.contains(activeSkill.skillId)
                }
                if (
                    selectedSkillIds == session.selectedSkillIds &&
                    activeSkills == session.activeSkills
                ) {
                    null
                } else {
                    session.copy(
                        selectedSkillIds = selectedSkillIds,
                        activeSkills = activeSkills,
                    )
                }
            }
        }
    }

    fun saveStreamableHttpMcpServer(
        serverId: String?,
        displayName: String,
        url: String,
        headersRaw: String,
    ) {
        val trimmedName = displayName.trim()
        val trimmedUrl = url.trim()
        if (trimmedName.isBlank() || trimmedUrl.isBlank()) return
        viewModelScope.launch {
            val existingServer = serverId?.let(::findMcpServerById)
            val now = System.currentTimeMillis()
            extensionsRepository.upsertMcpServer(
                McpServerConfig(
                    id = existingServer?.id ?: "mcp-$now",
                    displayName = trimmedName,
                    actionLabel = com.arix.app.data.generateQuickActionLabel(
                        trimmedName,
                        trimmedUrl,
                    ),
                    transport = com.arix.app.data.McpTransportConfig.StreamableHttp(
                        url = trimmedUrl,
                        headers = parseKeyValueLines(headersRaw),
                    ),
                    isEnabled = existingServer?.isEnabled ?: true,
                    connectTimeoutMillis = existingServer?.connectTimeoutMillis ?: 15_000L,
                    requestTimeoutMillis = existingServer?.requestTimeoutMillis ?: 60_000L,
                    createdAtMillis = existingServer?.createdAtMillis ?: now,
                    updatedAtMillis = now,
                ),
            )
            if (existingServer != null) {
                mcpClientManager.disconnect(existingServer.id)
            }
            captureAnalyticsEvent(
                event = "mcp server added",
                properties = mapOf("transport" to "streamable_http"),
            )
        }
    }

    fun saveStdIoMcpServer(
        serverId: String?,
        displayName: String,
        command: String,
        argumentsRaw: String,
        workingDirectory: String,
        environmentRaw: String,
        runtimeEnvironment: LocalRuntimeId?,
    ) {
        val trimmedName = displayName.trim()
        val trimmedCommand = command.trim()
        if (trimmedName.isBlank() || trimmedCommand.isBlank()) return
        viewModelScope.launch {
            val existingServer = serverId?.let(::findMcpServerById)
            val now = System.currentTimeMillis()
            extensionsRepository.upsertMcpServer(
                McpServerConfig(
                    id = existingServer?.id ?: "mcp-$now",
                    displayName = trimmedName,
                    actionLabel = com.arix.app.data.generateQuickActionLabel(
                        trimmedName,
                        trimmedCommand,
                    ),
                    transport = com.arix.app.data.McpTransportConfig.StdIo(
                        command = trimmedCommand,
                        arguments = parseNonBlankLines(argumentsRaw),
                        workingDirectory = workingDirectory.trim(),
                        environment = parseKeyValueLines(environmentRaw),
                        runtimeEnvironment = runtimeEnvironment,
                    ),
                    isEnabled = existingServer?.isEnabled ?: true,
                    connectTimeoutMillis = existingServer?.connectTimeoutMillis ?: 15_000L,
                    requestTimeoutMillis = existingServer?.requestTimeoutMillis ?: 60_000L,
                    createdAtMillis = existingServer?.createdAtMillis ?: now,
                    updatedAtMillis = now,
                ),
            )
            if (existingServer != null) {
                mcpClientManager.disconnect(existingServer.id)
            }
            captureAnalyticsEvent(
                event = "mcp server added",
                properties = mapOf("transport" to "stdio"),
            )
        }
    }

    fun saveScheduledTask(
        existingTaskId: String?,
        name: String,
        prompt: String,
        schedule: ScheduledTaskSchedule,
        enabled: Boolean,
    ) {
        viewModelScope.launch {
            val existing = existingTaskId
                ?.takeIf(String::isNotBlank)
                ?.let { scheduledTaskManager.findTask(it) }
            val task = (existing ?: ScheduledTask(
                name = name.trim().ifBlank { "Scheduled task" },
                prompt = prompt.trim(),
                schedule = schedule,
                createdBy = ScheduledTaskCreator.User,
            )).copy(
                name = name.trim().ifBlank { "Scheduled task" },
                prompt = prompt.trim(),
                schedule = schedule,
                isEnabled = enabled,
            )
            if (task.prompt.isBlank()) {
                emitTransientMessage(uiString(R.string.message_scheduled_task_prompt_required))
                return@launch
            }
            scheduledTaskManager.upsertTask(task)
        }
    }

    fun setScheduledTaskEnabled(
        taskId: String,
        enabled: Boolean,
    ) {
        viewModelScope.launch {
            scheduledTaskManager.setTaskEnabled(taskId, enabled)
        }
    }

    fun removeScheduledTask(taskId: String) {
        viewModelScope.launch {
            scheduledTaskManager.removeTask(taskId)
        }
    }

    private fun maybeInitializeWorkspaceMode(settings: AppSettings) {
        if (didEvaluateWorkspaceMode) return
        didEvaluateWorkspaceMode = true
        viewModelScope.launch {
            if (settingsRepository.isWorkspaceModeInitialized()) return@launch
            val mode = if (withContext(Dispatchers.IO) { workspaceFileBridge.hasLegacySessionWorkspaces() }) {
                AgentWorkspaceMode.PerSession
            } else {
                AgentWorkspaceMode.Shared
            }
            settingsRepository.updateSettings(settings.copy(agentWorkspaceMode = mode))
        }
    }

    fun testMcpServer(
        serverId: String,
        operation: McpServerTestOperation,
        onComplete: (String) -> Unit,
    ) {
        val server = findMcpServerById(serverId)
        if (server == null) {
            onComplete("MCP server '$serverId' was not found.")
            return
        }
        viewModelScope.launch {
            val workspaceDirectory = workspaceFileBridge.workspaceDirectory(
                sessionId = "mcp-test",
                mode = _uiState.value.settings.agentWorkspaceMode,
            )
            val result = mcpClientManager.testServer(
                server = server,
                workspaceDirectory = workspaceDirectory,
                operation = operation,
                settings = _uiState.value.settings,
            )
            onComplete(
                result.fold(
                    onSuccess = { output -> formatMcpTestOutput(operation, output) },
                    onFailure = { throwable -> "Test failed: ${throwable.message ?: "Unknown MCP error."}" },
                )
            )
        }
    }

    fun removeMcpServer(serverId: String) {
        viewModelScope.launch {
            extensionsRepository.removeMcpServer(serverId)
            mcpClientManager.disconnect(serverId)
        }
    }

    fun setMcpServerEnabled(
        serverId: String,
        enabled: Boolean,
    ) {
        viewModelScope.launch {
            extensionsRepository.setMcpServerEnabled(serverId, enabled)
            if (!enabled) {
                mcpClientManager.disconnect(serverId)
            }
        }
    }

    fun setComposerMcpServerSelected(
        serverId: String,
        selected: Boolean,
    ) {
        var didUpdate = false
        var sessionIdForPersistence: String? = null
        _uiState.update { current ->
            if (current.currentSessionId == DraftSessionId) {
                val updatedDraftSelection = updateOrderedSelection(
                    current.draftSelectedMcpServerIds,
                    serverId,
                    selected,
                )
                if (updatedDraftSelection == current.draftSelectedMcpServerIds) {
                    current
                } else {
                    didUpdate = true
                    current.copy(draftSelectedMcpServerIds = updatedDraftSelection)
                }
            } else {
                val sessionIndex = current.sessions.indexOfFirst { it.id == current.currentSessionId }
                if (sessionIndex < 0) return@update current
                val updatedSessions = current.sessions.toMutableList()
                val session = updatedSessions.removeAt(sessionIndex)
                val updatedActiveIds = updateOrderedSelection(
                    session.activeMcpServerIds,
                    serverId,
                    selected,
                )
                if (updatedActiveIds == session.activeMcpServerIds) {
                    updatedSessions.add(sessionIndex, session)
                    current
                } else {
                    didUpdate = true
                    val updatedSession = session.copy(activeMcpServerIds = updatedActiveIds)
                    sessionIdForPersistence = current.currentSessionId
                    updatedSessions.add(
                        sessionIndex.coerceAtMost(updatedSessions.size),
                        updatedSession,
                    )
                    current.copy(sessions = updatedSessions)
                }
            }
        }
        val persistedSessionId = sessionIdForPersistence
        if (didUpdate && persistedSessionId != null) {
            persistSessionMutation(persistedSessionId) { session ->
                val activeMcpServerIds = updateOrderedSelection(
                    session.activeMcpServerIds,
                    serverId,
                    selected,
                )
                if (activeMcpServerIds == session.activeMcpServerIds) {
                    null
                } else {
                    session.copy(activeMcpServerIds = activeMcpServerIds)
                }
            }
        }
    }

    fun setComposerAgentModeSelected(selected: Boolean) {
        var didUpdate = false
        var persistedSelected = false
        var sessionIdForPersistence: String? = null
        _uiState.update { current ->
            val resolvedSelected = selected &&
                current.isAgentModeReady()
            persistedSelected = resolvedSelected
            if (current.currentSessionId == DraftSessionId) {
                if (current.draftAgentModeEnabled == resolvedSelected) {
                    current
                } else {
                    didUpdate = true
                    current.copy(draftAgentModeEnabled = resolvedSelected)
                }
            } else {
                val sessionIndex = current.sessions.indexOfFirst { it.id == current.currentSessionId }
                if (sessionIndex < 0) return@update current
                val updatedSessions = current.sessions.toMutableList()
                val session = updatedSessions.removeAt(sessionIndex)
                if (session.agentModeEnabled == resolvedSelected) {
                    updatedSessions.add(sessionIndex, session)
                    current
                } else {
                    didUpdate = true
                    val updatedSession = session.copy(agentModeEnabled = resolvedSelected)
                    sessionIdForPersistence = current.currentSessionId
                    updatedSessions.add(
                        sessionIndex.coerceAtMost(updatedSessions.size),
                        updatedSession,
                    )
                    current.copy(sessions = updatedSessions)
                }
            }
        }
        val persistedSessionId = sessionIdForPersistence
        if (didUpdate && persistedSessionId != null) {
            persistSessionMutation(persistedSessionId) { session ->
                val resolvedSelected = selected &&
                    _uiState.value.isAgentModeReady()
                if (session.agentModeEnabled == resolvedSelected) {
                    null
                } else {
                    session.copy(agentModeEnabled = resolvedSelected)
                }
            }
        }
        if (didUpdate) {
            captureAnalyticsEvent(
                event = "agent mode toggled",
                properties = mapOf("enabled" to persistedSelected),
            )
        }
    }

    fun setComposerChromeSelected(selected: Boolean) {
        var didUpdate = false
        var sessionIdForPersistence: String? = null
        _uiState.update { current ->
            val resolvedSelected = selected &&
                current.settings.alpinePackageProfiles["chrome"]?.installed == true &&
                current.alpineSetupState.isReady
            if (current.currentSessionId == DraftSessionId) {
                if (current.draftChromeEnabled == resolvedSelected) {
                    current
                } else {
                    didUpdate = true
                    current.copy(draftChromeEnabled = resolvedSelected)
                }
            } else {
                val sessionIndex = current.sessions.indexOfFirst { it.id == current.currentSessionId }
                if (sessionIndex < 0) return@update current
                val session = current.sessions[sessionIndex]
                if (session.chromeEnabled == resolvedSelected) {
                    current
                } else {
                    didUpdate = true
                    sessionIdForPersistence = current.currentSessionId
                    current.copy(
                        sessions = current.sessions.toMutableList().apply {
                            this[sessionIndex] = session.copy(chromeEnabled = resolvedSelected)
                        }
                    )
                }
            }
        }
        sessionIdForPersistence?.takeIf { didUpdate }?.let { sessionId ->
            persistSessionMutation(sessionId) { session ->
                val resolvedSelected = selected &&
                    _uiState.value.settings.alpinePackageProfiles["chrome"]?.installed == true &&
                    _uiState.value.alpineSetupState.isReady
                if (session.chromeEnabled == resolvedSelected) null
                else session.copy(chromeEnabled = resolvedSelected)
            }
        }
    }

    fun sendCurrentMessage() {
        submitCurrentMessage(SessionFollowUpMode.Queue)
    }

    fun queueCurrentMessage() {
        submitCurrentMessage(SessionFollowUpMode.Queue)
    }

    fun steerCurrentMessage() {
        submitCurrentMessage(SessionFollowUpMode.Steer)
    }

    override fun onCleared() {
        // Copy then clear so a re-entrant call cannot double-unregister.
        val unregisters = coreModServiceUnregisters.toList()
        coreModServiceUnregisters.clear()
        unregisters.forEach { unregister -> unregister() }
        super.onCleared()
    }

    private fun registerCoreModServices() {
        coreModServiceUnregisters += modKernel.services.register(
            id = "skills",
            owner = "arix-core",
            description = "Inspect and mutate installed skills, current selection, and new-chat defaults.",
            priority = -10_000,
            methods = listOf(
                ArixModServiceMethod("list", "List installed skills and selection state."),
                ArixModServiceMethod("getSelection", "Read current and default skill selections."),
                ArixModServiceMethod("setSelection", "Replace current or default skill selections.", true),
                ArixModServiceMethod("setSelected", "Toggle one skill in a selection scope.", true),
            ),
            handler = { method, args -> handleSkillsModService(method, args) },
        )
        coreModServiceUnregisters += modKernel.services.register(
            id = "state",
            owner = "arix-core",
            description = "Read the public Arix state tree and apply supported state transactions.",
            priority = -10_000,
            methods = listOf(
                ArixModServiceMethod("get", "Read a value from the public state tree."),
                ArixModServiceMethod("transaction", "Apply an ordered list of state mutations.", true),
            ),
            handler = { method, args -> handleStateModService(method, args) },
        )
    }

    private suspend fun dispatchArixOperation(
        operation: String,
        payload: JSONObject,
    ): ArixModOperationDecision {
        val hasNativeInterceptors = modKernel.operations.hasInterceptors(operation)
        val eventName = "operation:$operation"
        val hasScriptInterceptors =
            eventName in arixAppExtensionManager.state.value.snapshot.eventNames
        if (!hasNativeInterceptors && !hasScriptInterceptors) {
            return ArixModOperationDecision(payload = payload)
        }

        val context = buildArixExtensionHostState(_uiState.value)
        val nativeDecision = if (hasNativeInterceptors) {
            modKernel.operations.intercept(
                operation = operation,
                payload = payload,
                context = context,
            )
        } else {
            ArixModOperationDecision(payload = payload)
        }
        if (nativeDecision.cancelled) return nativeDecision

        if (!hasScriptInterceptors) {
            return nativeDecision
        }
        val scriptDecision = arixAppExtensionManager.dispatchEvent(
            event = eventName,
            data = nativeDecision.payload,
            context = context,
        ).getOrNull() ?: return ArixModOperationDecision(
            payload = nativeDecision.payload,
            cancelled = true,
            reason = "Arix script operation interceptor failed.",
        )
        return ArixModOperationDecision(
            payload = scriptDecision.payload,
            cancelled = scriptDecision.cancelled,
            reason = scriptDecision.reason,
        )
    }

    private suspend fun handleSkillsModService(
        method: String,
        args: JSONObject,
    ): JSONObject = when (method) {
        "list",
        "getSelection" -> buildSkillsModState(_uiState.value)

        "setSelection" -> {
            val requestedIds = args.optJSONArray("ids").toStringList()
            val scope = args.optString("scope", "current").lowercase()
            val snapshot = _uiState.value
            val enabledIds = snapshot.installedSkills
                .filter(InstalledSkill::isEnabled)
                .map(InstalledSkill::id)
                .toSet()
            val selectedIds = requestedIds.filter(enabledIds::contains).distinct()
            if (scope in setOf("default", "global", "current_and_default", "both")) {
                settingsRepository.updateDefaultSelectedSkillIds(selectedIds)
            }
            if (scope !in setOf("default", "global")) {
                withContext(Dispatchers.Main.immediate) {
                    setCurrentSkillSelectionNow(
                        selectedSkillIds = selectedIds,
                        sessionId = args.optString("session_id").ifBlank { null },
                    )
                }
            }
            buildSkillsModState(_uiState.value).put("updated", true)
        }

        "setSelected" -> {
            val skillId = args.optString("skill_id").trim()
            require(skillId.isNotBlank()) { "skill_id is required." }
            val scope = args.optString("scope", "current").lowercase()
            val selected = args.optBoolean("selected", true)
            val snapshot = _uiState.value
            if (scope in setOf("current_and_default", "both")) {
                val currentIds = updateOrderedSelection(
                    currentSelectedSkillIds(snapshot),
                    skillId,
                    selected,
                )
                val defaultIds = updateOrderedSelection(
                    snapshot.settings.defaultSelectedSkillIds,
                    skillId,
                    selected,
                )
                handleSkillsModService(
                    method = "setSelection",
                    args = JSONObject()
                        .put("ids", JSONArray(defaultIds))
                        .put("scope", "default"),
                )
                handleSkillsModService(
                    method = "setSelection",
                    args = JSONObject()
                        .put("ids", JSONArray(currentIds))
                        .put("scope", "current")
                        .put("session_id", args.optString("session_id")),
                )
            } else {
                val currentIds = if (scope in setOf("default", "global")) {
                    snapshot.settings.defaultSelectedSkillIds
                } else {
                    currentSelectedSkillIds(snapshot)
                }
                val updatedIds = updateOrderedSelection(currentIds, skillId, selected)
                handleSkillsModService(
                    method = "setSelection",
                    args = JSONObject()
                        .put("ids", JSONArray(updatedIds))
                        .put("scope", scope)
                        .put("session_id", args.optString("session_id")),
                )
            }
        }

        else -> error("Unknown skills service method: $method")
    }

    private suspend fun handleStateModService(
        method: String,
        args: JSONObject,
    ): JSONObject = when (method) {
        "get" -> {
            val path = args.optString("path").trim()
            val state = buildArixExtensionHostState(_uiState.value)
            JSONObject()
                .put("path", path)
                .put("value", jsonValueAtPath(state, path))
        }

        "transaction" -> {
            val operations = args.optJSONArray("operations") ?: JSONArray()
            for (index in 0 until operations.length()) {
                val operation = operations.optJSONObject(index) ?: continue
                applyModStateOperation(operation)
            }
            JSONObject()
                .put("applied", operations.length())
                .put("state", buildArixExtensionHostState(_uiState.value))
        }

        else -> error("Unknown state service method: $method")
    }

    private suspend fun applyModStateOperation(
        operation: JSONObject,
    ) {
        val op = operation.optString("op", "set").lowercase()
        val path = normalizeModStatePath(operation.optString("path"))
        val value = if (op == "remove") JSONObject.NULL else operation.opt("value")
        when (path) {
            "draft_input" -> withContext(Dispatchers.Main.immediate) {
                updateDraftInput(if (value == JSONObject.NULL) "" else value?.toString().orEmpty())
            }

            "selected_skill_ids" -> withContext(Dispatchers.Main.immediate) {
                setCurrentSkillSelectionNow(
                    selectedSkillIds = (value as? JSONArray).toStringList(),
                )
            }

            "default_skill_ids" -> {
                val enabledIds = _uiState.value.installedSkills
                    .filter(InstalledSkill::isEnabled)
                    .map(InstalledSkill::id)
                    .toSet()
                settingsRepository.updateDefaultSelectedSkillIds(
                    (value as? JSONArray).toStringList().filter(enabledIds::contains)
                )
            }

            "agent_mode_enabled" -> withContext(Dispatchers.Main.immediate) {
                setComposerAgentModeSelected(value != JSONObject.NULL && value == true)
            }

            "selected_model_key" -> {
                val modelKey = if (value == JSONObject.NULL) "" else value?.toString().orEmpty()
                require(modelKey.isNotBlank()) { "selected_model_key cannot be empty." }
                withContext(Dispatchers.Main.immediate) {
                    setCurrentChatModelSelectionAndResolveThinkingLevels(modelKey) {}
                }
            }

            "screen" -> withContext(Dispatchers.Main.immediate) {
                when (value?.toString()?.lowercase()) {
                    "settings" -> openSettings()
                    "chat" -> closeSettings()
                    else -> error("Unsupported screen state value: $value")
                }
            }

            else -> error("Unsupported public Arix state path: ${operation.optString("path")}")
        }
    }

    suspend fun handleArixExtensionHostCall(
        method: String,
        args: JSONObject,
    ): JSONObject = when (method) {
        "kernel.listServices" -> modKernel.services.listJson()

        "kernel.describeService" -> modKernel.services.describeJson(
            args.optString("service")
        )

        "service.invoke" -> modKernel.services.invoke(
            id = args.optString("service"),
            method = args.optString("method"),
            args = args.optJSONObject("args") ?: JSONObject(),
        )

        "state.get" -> handleStateModService("get", args)

        "state.transaction" -> handleStateModService("transaction", args)

        "app.getState" -> buildArixExtensionHostState(_uiState.value)

        "app.setDraftInput" -> {
            withContext(Dispatchers.Main.immediate) {
                updateDraftInput(args.optString("text"))
            }
            JSONObject().put("updated", true)
        }

        "app.appendDraftInput" -> {
            withContext(Dispatchers.Main.immediate) {
                val current = _uiState.value.draftInput
                updateDraftInput(current + args.optString("text"))
            }
            JSONObject().put("updated", true)
        }

        "app.sendMessage" -> {
            withContext(Dispatchers.Main.immediate) {
                if (args.has("text")) {
                    updateDraftInput(args.optString("text"))
                }
                when (args.optString("mode").lowercase()) {
                    "steer" -> steerCurrentMessage()
                    "queue" -> queueCurrentMessage()
                    else -> sendCurrentMessage()
                }
            }
            JSONObject().put("submitted", true)
        }

        "app.appendCustomMessage" -> {
            val type = args.optString("type").trim()
            require(type.isNotBlank()) { "Custom messages require a type." }
            val text = args.optString("text")
            val payload = args.optJSONObject("payload") ?: JSONObject()
            val sessionId = _uiState.value.currentSessionId
            val message = ChatMessage(
                id = "arix-custom-${UUID.randomUUID()}",
                author = MessageAuthor.Agent,
                text = text,
                createdAtMillis = System.currentTimeMillis(),
                assistantActionsHidden = true,
                providerPayloadJson = JSONObject()
                    .put("arix_custom_type", type)
                    .put("arix_custom_payload", payload)
                    .toString(),
            )
            withContext(Dispatchers.Main.immediate) {
                updateSession(sessionId) { session ->
                    session.copy(messages = session.messages + message, preview = text)
                }
            }
            JSONObject().put("appended", true).put("type", type)
        }

        "app.newChat" -> {
            withContext(Dispatchers.Main.immediate) {
                startNewChat()
            }
            JSONObject().put("opened", "chat")
        }

        "app.selectSession" -> {
            val sessionId = args.optString("session_id").trim()
            require(sessionId.isNotBlank()) { "session_id is required." }
            withContext(Dispatchers.Main.immediate) {
                selectSession(sessionId)
            }
            JSONObject().put("selected", sessionId)
        }

        "app.openScreen" -> {
            val screen = args.optString("screen").lowercase()
            withContext(Dispatchers.Main.immediate) {
                when (screen) {
                    "settings" -> openSettings()
                    "chat" -> closeSettings()
                    else -> error("Unknown Arix screen: $screen")
                }
            }
            JSONObject().put("opened", screen)
        }

        "app.pauseGeneration" -> {
            withContext(Dispatchers.Main.immediate) {
                pauseGeneration()
            }
            JSONObject().put("paused", true)
        }

        "app.setReasoningEffort" -> {
            val effort = normalizeReasoningEffort(args.optString("effort"))
            withContext(Dispatchers.Main.immediate) {
                setReasoningEffort(effort)
            }
            JSONObject().put("reasoning_effort", effort)
        }

        "app.setAgentMode" -> {
            val enabled = args.optBoolean("enabled")
            withContext(Dispatchers.Main.immediate) {
                setComposerAgentModeSelected(enabled)
            }
            JSONObject().put("enabled", enabled)
        }

        "app.setModel" -> {
            val modelKey = args.optString("model_key").trim()
            require(modelKey.isNotBlank()) { "model_key is required." }
            withContext(Dispatchers.Main.immediate) {
                setCurrentChatModelSelectionAndResolveThinkingLevels(modelKey) {}
            }
            JSONObject().put("model_key", modelKey)
        }

        "app.notify" -> {
            emitTransientMessage(UiText.Raw(args.optString("message")))
            JSONObject().put("notified", true)
        }

        "app.webFetch" -> {
            val url = args.optString("url").trim()
            require(url.startsWith("http://") || url.startsWith("https://")) {
                "A valid http(s) url is required."
            }
            val timeoutMs = args.optLong("timeout_ms", 25_000L).coerceIn(8_000L, 45_000L)
            val content = webViewFetcher.fetch(url, timeoutMs)
            JSONObject()
                .put("ok", true)
                .put("url", url)
                .put("content", content)
                .put("content_length", content.length.toLong())
        }

        "app.saveMediaToDownloads" -> {
            val filename = args.optString("filename").trim().ifBlank { "arix-download.bin" }
            val mimeType = args.optString("mime_type").trim().ifBlank {
                guessDownloadMimeType(filename)
            }
            val base64 = args.optString("base64")
            require(base64.isNotBlank()) { "base64 content is required." }
            val bytes = runCatching {
                android.util.Base64.decode(base64, android.util.Base64.DEFAULT)
            }.getOrElse { error("The download payload could not be decoded.") }
            val displayName = if (filename.lastIndexOf('.') > 0) filename else {
                "$filename${defaultDownloadExtension(mimeType)}"
            }
            val savedUri = saveMediaToDownloads(displayName, mimeType, bytes)
            JSONObject()
                .put("saved", true)
                .put("filename", displayName)
                .put("mime_type", mimeType)
                .put("size_bytes", bytes.size.toLong())
                .put("uri", savedUri.toString())
        }

        "settings.get" -> JSONObject()
            .put("settings", _uiState.value.settings.toJson())
            .put(
                "provider_configs",
                JSONArray(serializeProviderConfigs(_uiState.value.providerConfigs)),
            )

        "settings.patch" -> {
            val current = _uiState.value.settings
            var updated = current
            if (args.has("system_prompt")) {
                updated = updated.copy(systemPrompt = args.optString("system_prompt"))
            }
            if (args.has("reasoning_effort")) {
                updated = updated.copy(
                    reasoningEffort = normalizeReasoningEffort(args.optString("reasoning_effort"))
                )
            }
            if (args.has("keep_tasks_running_in_background")) {
                updated = updated.copy(
                    keepTasksRunningInBackground = args.optBoolean("keep_tasks_running_in_background")
                )
            }
            if (args.has("notify_on_task_completion")) {
                updated = updated.copy(
                    notifyOnTaskCompletion = args.optBoolean("notify_on_task_completion")
                )
            }
            if (args.has("theme")) {
                updated = updated.copy(themeMode = AppThemeMode.fromStorage(args.optString("theme")))
            }
            if (args.has("language")) {
                updated = updated.copy(
                    language = AppLanguage.fromStorage(args.optString("language"), updated.language)
                )
            }
            if (args.has("workspace_mode")) {
                updated = updated.copy(
                    agentWorkspaceMode = AgentWorkspaceMode.fromStorage(args.optString("workspace_mode"))
                )
            }
            if (args.has("default_skill_ids")) {
                val enabledIds = _uiState.value.installedSkills
                    .filter(InstalledSkill::isEnabled)
                    .map(InstalledSkill::id)
                    .toSet()
                updated = updated.copy(
                    defaultSelectedSkillIds = args.optJSONArray("default_skill_ids")
                        .toStringList()
                        .filter(enabledIds::contains),
                )
            }
            if (args.has("tavily_api_key")) {
                updated = updated.copy(tavilyApiKey = args.optString("tavily_api_key"))
            }
            if (args.has("tavily_base_url")) {
                updated = updated.copy(
                    tavilyBaseUrl = normalizeTavilyBaseUrl(args.optString("tavily_base_url"))
                )
            }
            settingsRepository.updateSettings(updated)
            JSONObject().put("settings", updated.toJson())
        }

        "runtime.execute" -> {
            val settings = _uiState.value.settings
            val environment = args.optString("environment").ifBlank { null }
            val selectedRuntime = runtime.runtimeRouter.runtimeFor(settings, environment)
                ?: error("No configured runtime matched ${environment ?: "the default runtime"}.")
            val command = args.optString("command")
            require(command.isNotBlank()) { "command is required." }
            val output = selectedRuntime.executeCommand(
                command = command,
                workingDirectory = args.optString("working_directory")
                    .ifBlank { selectedRuntime.homeDirectory },
                awaitTimeoutMillis = args.optLong("timeout_ms", 60_000L)
                    .coerceIn(1_000L, 10 * 60_000L),
            )
            JSONObject()
                .put("runtime", selectedRuntime.id.storageValue)
                .put("output", output)
        }

        else -> error("Unsupported Arix extension host method: $method")
    }

    private fun currentSelectedSkillIds(
        snapshot: ArixUiState,
    ): List<String> =
        snapshot.sessions
            .firstOrNull { it.id == snapshot.currentSessionId }
            ?.selectedSkillIds
            ?: snapshot.draftSelectedSkillIds

    private fun enabledDefaultSkillIds(
        snapshot: ArixUiState,
    ): List<String> {
        val enabledIds = snapshot.installedSkills
            .filter(InstalledSkill::isEnabled)
            .map(InstalledSkill::id)
            .toSet()
        return snapshot.settings.defaultSelectedSkillIds.filter(enabledIds::contains)
    }

    private fun setCurrentSkillSelectionNow(
        selectedSkillIds: List<String>,
        sessionId: String? = null,
    ) {
        val enabledIds = _uiState.value.installedSkills
            .filter(InstalledSkill::isEnabled)
            .map(InstalledSkill::id)
            .toSet()
        val normalizedIds = selectedSkillIds.filter(enabledIds::contains).distinct()
        val targetSessionId = sessionId ?: _uiState.value.currentSessionId
        if (targetSessionId == DraftSessionId) {
            _uiState.update { current ->
                current.copy(draftSelectedSkillIds = normalizedIds)
            }
        } else {
            setSessionSelectedSkillIds(targetSessionId, normalizedIds)
        }
    }

    private fun buildSkillsModState(
        snapshot: ArixUiState,
    ): JSONObject {
        val selectedIds = currentSelectedSkillIds(snapshot)
        return JSONObject().apply {
            put("session_id", snapshot.currentSessionId)
            put("selected_skill_ids", JSONArray(selectedIds))
            put("default_skill_ids", JSONArray(snapshot.settings.defaultSelectedSkillIds))
            put(
                "skills",
                JSONArray().apply {
                    snapshot.installedSkills.forEach { skill ->
                        put(
                            JSONObject().apply {
                                put("id", skill.id)
                                put("name", skill.name)
                                put("description", skill.description)
                                put("action_label", skill.actionLabel)
                                put("license", skill.license)
                                put("compatibility", skill.compatibility)
                                put("allowed_tools", JSONArray(skill.allowedTools))
                                put("enabled", skill.isEnabled)
                                put("selected", skill.id in selectedIds)
                                put(
                                    "default_selected",
                                    skill.id in snapshot.settings.defaultSelectedSkillIds,
                                )
                            }
                        )
                    }
                },
            )
        }
    }

    private fun normalizeModStatePath(
        rawPath: String,
    ): String = when (
        rawPath.trim().trim('/').replace('/', '.').lowercase()
    ) {
        "draft_input",
        "chat.draftinput",
        "chat.draft_input" -> "draft_input"

        "selected_skill_ids",
        "chat.selectedskillids",
        "chat.selected_skill_ids" -> "selected_skill_ids"

        "default_skill_ids",
        "chat.defaultskillids",
        "chat.default_skill_ids" -> "default_skill_ids"

        "agent_mode_enabled",
        "chat.agentmodeenabled",
        "chat.agent_mode_enabled" -> "agent_mode_enabled"

        "selected_model_key",
        "chat.selectedmodelkey",
        "chat.selected_model_key" -> "selected_model_key"

        "screen",
        "app.screen" -> "screen"

        else -> rawPath.trim()
    }

    private fun jsonValueAtPath(
        root: Any?,
        rawPath: String,
    ): Any? {
        val path = rawPath.trim().trim('/').replace('/', '.')
        if (path.isBlank()) return root
        var current: Any? = root
        path.split('.').filter(String::isNotBlank).forEach { segment ->
            current = when (val value = current) {
                is JSONObject -> value.opt(segment)
                is JSONArray -> segment.toIntOrNull()?.let(value::opt)
                else -> JSONObject.NULL
            }
        }
        return current ?: JSONObject.NULL
    }

    private fun buildArixExtensionHostState(
        snapshot: ArixUiState,
    ): JSONObject {
        val activeSession = snapshot.sessions.firstOrNull { it.id == snapshot.currentSessionId }
        val execution = snapshot.sessionExecutionStates[snapshot.currentSessionId]
        val selectedSkillIds = currentSelectedSkillIds(snapshot)
        return JSONObject().apply {
            put("screen", snapshot.currentScreen.name.lowercase())
            put("session_id", snapshot.currentSessionId)
            put("draft_input", snapshot.draftInput)
            put("is_running", execution?.isRunning == true)
            put("is_editing", snapshot.editingMessageId != null)
            put("selected_model_key", activeSession?.selectedModelKey ?: snapshot.draftSelectedModelKey)
            put("agent_mode_enabled", activeSession?.agentModeEnabled ?: snapshot.draftAgentModeEnabled)
            put("selected_skill_ids", JSONArray(selectedSkillIds))
            put("default_skill_ids", JSONArray(snapshot.settings.defaultSelectedSkillIds))
            put("skills", buildSkillsModState(snapshot).optJSONArray("skills"))
            put("settings", snapshot.settings.toJson())
            put("provider_configs", JSONArray(serializeProviderConfigs(snapshot.providerConfigs)))
            put("sessions", JSONArray(serializeChatSessions(snapshot.sessions)))
            put("custom_messages", JSONArray(serializeCustomExtensionMessages(activeSession)))
            put(
                "installed_extensions",
                JSONArray().apply {
                    snapshot.installedPiExtensions.forEach { extension ->
                        put(
                            JSONObject().apply {
                                put("id", extension.id)
                                put("name", extension.name)
                                put("source", extension.source)
                                put("pi_extension_count", extension.extensionCount)
                                put("arix_extension_count", extension.arixExtensionCount)
                                put("native_entrypoint_count", extension.nativeEntrypointCount)
                            }
                        )
                    }
                },
            )
        }
    }

    /** Session messages created through app.appendCustomMessage, fed to the extension runtime so
     *  registered message types can render their widget trees for the chat. */
    private fun serializeCustomExtensionMessages(
        session: ChatSession?,
        limit: Int = 8,
    ): List<JSONObject> {
        if (session == null) return emptyList()
        return session.messages
            .filter { message ->
                message.author == MessageAuthor.Agent && message.providerPayloadJson.isNotBlank()
            }
            .mapNotNull { message -> message.customExtensionMessageJson() }
            .takeLast(limit)
    }

    /** Persist a downloaded file into the system Downloads collection so any
     *  gallery/file manager can pick it up. Extension widgets (QR cards, movie
     *  downloads) call this through app.saveMediaToDownloads. */
    private fun saveMediaToDownloads(
        displayName: String,
        mimeType: String,
        bytes: ByteArray,
    ): Uri {
        val appContext = getApplication<Application>().applicationContext
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val values = android.content.ContentValues().apply {
                put(android.provider.MediaStore.Downloads.DISPLAY_NAME, displayName)
                put(android.provider.MediaStore.Downloads.MIME_TYPE, mimeType)
                put(android.provider.MediaStore.Downloads.IS_PENDING, 1)
            }
            val resolver = appContext.contentResolver
            val collection =
                android.provider.MediaStore.Downloads.getContentUri(android.provider.MediaStore.VOLUME_EXTERNAL_PRIMARY)
            val itemUri = resolver.insert(collection, values)
                ?: error("The download could not be created in the system Downloads store.")
            try {
                resolver.openOutputStream(itemUri)?.use { output ->
                    output.write(bytes)
                    output.flush()
                } ?: error("The download file could not be written.")
                values.clear()
                values.put(android.provider.MediaStore.Downloads.IS_PENDING, 0)
                resolver.update(itemUri, values, null, null)
            } catch (throwable: Throwable) {
                runCatching { resolver.delete(itemUri, null, null) }
                error("The download failed: ${throwable.message}")
            }
            return itemUri
        }
        @Suppress("DEPRECATION")
        val downloadsDirectory = android.os.Environment
            .getExternalStoragePublicDirectory(android.os.Environment.DIRECTORY_DOWNLOADS)
        downloadsDirectory.mkdirs()
        val targetFile = java.io.File(downloadsDirectory, displayName)
        targetFile.writeBytes(bytes)
        return Uri.fromFile(targetFile)
    }

    private fun guessDownloadMimeType(filename: String): String = when {
        filename.endsWith(".png", ignoreCase = true) -> "image/png"
        filename.endsWith(".jpg", true) || filename.endsWith(".jpeg", true) -> "image/jpeg"
        filename.endsWith(".webp", true) -> "image/webp"
        filename.endsWith(".gif", true) -> "image/gif"
        filename.endsWith(".mp4", true) -> "video/mp4"
        filename.endsWith(".mp3", true) -> "audio/mpeg"
        filename.endsWith(".txt", true) -> "text/plain"
        filename.endsWith(".json", true) -> "application/json"
        else -> "application/octet-stream"
    }

    private fun defaultDownloadExtension(mimeType: String): String = when (mimeType) {
        "image/png" -> ".png"
        "image/jpeg" -> ".jpg"
        "image/webp" -> ".webp"
        "image/gif" -> ".gif"
        "video/mp4" -> ".mp4"
        "audio/mpeg" -> ".mp3"
        "text/plain" -> ".txt"
        "application/json" -> ".json"
        else -> ".bin"
    }

    private fun submitCurrentMessage(
        runningFollowUpMode: SessionFollowUpMode,
    ) {
        val snapshot = _uiState.value
        if ("before_send" !in arixAppExtensionManager.state.value.snapshot.eventNames) {
            submitCurrentMessageNow(runningFollowUpMode)
            return
        }
        if (extensionSendHookJob?.isActive == true) return
        extensionSendHookJob = viewModelScope.launch {
            val eventData = JSONObject().apply {
                put("text", snapshot.draftInput)
                put("mode", runningFollowUpMode.name.lowercase())
                put("session_id", snapshot.currentSessionId)
                put(
                    "attachments",
                    JSONArray().apply {
                        snapshot.draftAttachments.forEach { attachment ->
                            put(
                                JSONObject().apply {
                                    put("id", attachment.id)
                                    put("name", attachment.name)
                                    put("mime_type", attachment.mimeType)
                                    put("workspace_path", attachment.workspacePath)
                                }
                            )
                        }
                    },
                )
            }
            val eventResult = arixAppExtensionManager.dispatchEvent(
                event = "before_send",
                data = eventData,
                context = buildArixExtensionHostState(snapshot),
            ).getOrNull()
            if (eventResult?.cancelled == true) {
                eventResult.reason.takeIf(String::isNotBlank)?.let { reason ->
                    emitTransientMessage(UiText.Raw(reason))
                }
                return@launch
            }
            val transformedText = eventResult?.payload?.optString("text", snapshot.draftInput)
                ?: snapshot.draftInput
            if (transformedText != _uiState.value.draftInput) {
                _uiState.update { current -> current.copy(draftInput = transformedText) }
            }
            submitCurrentMessageNow(runningFollowUpMode)
        }
    }

    private fun submitCurrentMessageNow(
        runningFollowUpMode: SessionFollowUpMode,
    ) {
        val snapshot = _uiState.value
        val content = snapshot.draftInput.trim()
        val attachments = snapshot.draftAttachments

        if (content.isEmpty() && attachments.isEmpty()) return
        if (attachments.any { it.workspaceState != AttachmentWorkspaceState.Ready }) return
        if (isCompactCommand(content)) {
            compactCurrentSession(snapshot)
            return
        }

        val targetSessionId = snapshot.editingSessionId ?: when {
            snapshot.currentSessionId != DraftSessionId -> snapshot.currentSessionId
            !snapshot.draftWorkspaceId.isNullOrBlank() -> snapshot.draftWorkspaceId.orEmpty()
            else -> "session-${System.currentTimeMillis()}"
        }

        // Instant native tools (Movie Explorer / QR Generator): matched
        // commands run fully inside the app and render their widget card
        // immediately — no LLM text round-trip, no raw URLs, no delay.
        if (
            attachments.isEmpty() &&
            snapshot.editingSessionId == null &&
            !sessionExecutionManager.isSessionRunning(targetSessionId) &&
            snapshot.draftSelectedSkillIds.isEmpty()
        ) {
            val nativeIntent = ArixNativeIntent.match(content)
            if (nativeIntent != null) {
                runNativeToolTurn(
                    intent = nativeIntent,
                    content = content,
                    targetSessionId = targetSessionId,
                )
                if ("message_sent" in arixAppExtensionManager.state.value.snapshot.eventNames) {
                    arixAppExtensionManager.emitEvent(
                        event = "message_sent",
                        data = JSONObject()
                            .put("session_id", targetSessionId)
                            .put("text", content)
                            .put("mode", "new_turn"),
                        context = buildArixExtensionHostState(_uiState.value),
                    )
                }
                return
            }
        }

        val now = System.currentTimeMillis()
        val userMessage = ChatMessage(
            id = "user-$now",
            author = MessageAuthor.User,
            text = content,
            createdAtMillis = now,
            attachments = attachments,
        )

        if (snapshot.editingSessionId != null && sessionExecutionManager.isSessionRunning(targetSessionId)) {
            emitTransientMessage(uiString(R.string.message_pause_before_editing_message))
            return
        }

        if (sessionExecutionManager.isSessionRunning(targetSessionId)) {
            if (!sessionExecutionManager.submitFollowUp(targetSessionId, userMessage, runningFollowUpMode)) {
                emitTransientMessage(uiString(R.string.message_session_no_longer_running))
                return
            }
            buildAnalyticsTurnRequest(
                snapshot = snapshot,
                sessionId = targetSessionId,
                userMessage = userMessage,
            )?.let { turnRequest ->
                captureMessageSent(
                    request = turnRequest,
                    attachments = attachments,
                    isEdit = false,
                    submissionType = runningFollowUpMode.name.lowercase(),
                )
            }
            _uiState.update { current ->
                current.copy(
                    currentScreen = AppScreen.Chat,
                    draftInput = "",
                    draftAttachments = emptyList(),
                    draftWorkspaceId = null,
                    editingSessionId = null,
                    editingMessageId = null,
                    showStarterPromptHint = false,
                )
            }
            if ("message_sent" in arixAppExtensionManager.state.value.snapshot.eventNames) {
                arixAppExtensionManager.emitEvent(
                    event = "message_sent",
                    data = JSONObject()
                        .put("session_id", targetSessionId)
                        .put("message_id", userMessage.id)
                        .put("text", userMessage.text)
                        .put("mode", runningFollowUpMode.name.lowercase()),
                    context = buildArixExtensionHostState(_uiState.value),
                )
            }
            return
        }

        var request: SessionTurnRequest? = null
        var requestMessages: List<ChatMessage> = emptyList()
        var requestSelectedSkillIds: List<String> = emptyList()
        var requestActiveSkills: List<ActiveSkillContext> = emptyList()
        var requestActiveMcpServerIds: List<String> = emptyList()
        var requestAgentModeEnabled = false
        var requestChromeEnabled = false
        var requestModelKey = ""
        var shouldGenerateSessionTitle = false
        var sessionForPersistence: ChatSession? = null
        var editedMessagePredecessorId: String? = null
        var isEditingExistingMessage = false

        _uiState.update { current ->
            val updatedSessions = current.sessions.toMutableList()
            if (
                current.editingSessionId != null &&
                current.editingMessageId != null
            ) {
                val editingSessionIndex = updatedSessions.indexOfFirst {
                    it.id == current.editingSessionId
                }
                if (editingSessionIndex >= 0) {
                    val editingSession = updatedSessions.removeAt(editingSessionIndex)
                    val editingMessageIndex = editingSession.messages.indexOfFirst {
                        it.id == current.editingMessageId && it.author == MessageAuthor.User
                    }
                    if (editingMessageIndex >= 0) {
                        isEditingExistingMessage = true
                        editedMessagePredecessorId = editingSession.messages
                            .take(editingMessageIndex)
                            .lastOrNull()
                            ?.id
                        val branchedMessages = createEditedMessageBranch(
                            messages = editingSession.messages,
                            messageId = current.editingMessageId,
                            replacement = userMessage,
                        ) ?: (editingSession.messages.take(editingMessageIndex) + userMessage)
                        val updated = editingSession.withMessages(branchedMessages)
                        sessionForPersistence = updated
                        updatedSessions.add(0, updated)
                        requestMessages = updated.messages
                        requestSelectedSkillIds = updated.selectedSkillIds
                        requestActiveSkills = updated.activeSkills
                        requestActiveMcpServerIds = updated.activeMcpServerIds
                        requestAgentModeEnabled = updated.agentModeEnabled
                        requestChromeEnabled = updated.chromeEnabled
                        requestModelKey = updated.selectedModelKey
                    } else {
                        updatedSessions.add(editingSessionIndex, editingSession)
                    }
                }
            }

            if (requestMessages.isEmpty()) {
                val existingIndex = updatedSessions.indexOfFirst { it.id == targetSessionId }
                if (existingIndex >= 0) {
                    val existing = updatedSessions.removeAt(existingIndex)
                    val updated = existing.withMessages(existing.messages + userMessage)
                    sessionForPersistence = updated
                    updatedSessions.add(0, updated)
                    requestMessages = updated.messages
                    requestSelectedSkillIds = updated.selectedSkillIds
                    requestActiveSkills = updated.activeSkills
                    requestActiveMcpServerIds = updated.activeMcpServerIds
                    requestAgentModeEnabled = updated.agentModeEnabled
                    requestChromeEnabled = updated.chromeEnabled
                    requestModelKey = updated.selectedModelKey
                } else {
                    val newSession = createSession(
                        id = targetSessionId,
                        messages = listOf(userMessage),
                        title = "New chat",
                        hasCustomTitle = true,
                        selectedModelKey = current.draftSelectedModelKey.ifBlank {
                            resolveDefaultChatModelKey(current.settings, current.providerConfigs)
                        },
                        selectedSkillIds = current.draftSelectedSkillIds,
                        activeMcpServerIds = current.draftSelectedMcpServerIds,
                        agentModeEnabled = current.draftAgentModeEnabled,
                        chromeEnabled = current.draftChromeEnabled,
                    )
                    shouldGenerateSessionTitle = true
                    sessionForPersistence = newSession
                    updatedSessions.add(0, newSession)
                    requestMessages = newSession.messages
                    requestSelectedSkillIds = newSession.selectedSkillIds
                    requestActiveSkills = newSession.activeSkills
                    requestActiveMcpServerIds = newSession.activeMcpServerIds
                    requestAgentModeEnabled = newSession.agentModeEnabled
                    requestChromeEnabled = newSession.chromeEnabled
                    requestModelKey = newSession.selectedModelKey
                }
            }

            request = SessionTurnRequest(
                sessionId = targetSessionId,
                settings = resolveModelSettings(
                    baseSettings = current.settings,
                    providerConfigs = current.providerConfigs,
                    preferredModelKey = requestModelKey,
                    fallbackModelKey = resolveDefaultChatModelKey(current.settings, current.providerConfigs),
                ),
                requestMessages = requestMessages,
                selectedSkillIds = requestSelectedSkillIds,
                activeSkills = requestActiveSkills,
                activeMcpServerIds = requestActiveMcpServerIds,
                agentModeEnabled = requestAgentModeEnabled,
                chromeEnabled = requestChromeEnabled,
                providerConfigs = current.providerConfigs,
            )

            current.copy(
                sessions = updatedSessions,
                currentSessionId = targetSessionId,
                draftInput = "",
                draftAttachments = emptyList(),
                draftSelectedModelKey = "",
                draftSelectedSkillIds = emptyList(),
                draftSelectedMcpServerIds = emptyList(),
                draftAgentModeEnabled = false,
                draftChromeEnabled = false,
                draftWorkspaceId = null,
                editingSessionId = null,
                editingMessageId = null,
                currentScreen = AppScreen.Chat,
                showStarterPromptHint = false,
            )
        }

        val turnRequest = request ?: return
        sessionForPersistence?.let { session ->
            persistSessionSnapshot(
                session = session,
                currentSessionId = targetSessionId,
                moveToFront = true,
            )
        }
        captureMessageSent(
            request = turnRequest,
            attachments = attachments,
            isEdit = snapshot.editingSessionId != null,
            submissionType = "new_turn",
        )
        if (shouldGenerateSessionTitle) {
            generateSessionTitle(
                sessionId = targetSessionId,
                seedMessage = userMessage,
                settings = turnRequest.settings,
            )
        }
        if (isEditingExistingMessage) {
            viewModelScope.launch {
                navigatePiBranch(
                    sessionId = targetSessionId,
                    arixMessageId = editedMessagePredecessorId,
                    resetWhenMissing = true,
                )
                sessionExecutionManager.startTurn(turnRequest)
            }
        } else {
            sessionExecutionManager.startTurn(turnRequest)
        }
        if ("message_sent" in arixAppExtensionManager.state.value.snapshot.eventNames) {
            arixAppExtensionManager.emitEvent(
                event = "message_sent",
                data = JSONObject()
                    .put("session_id", targetSessionId)
                    .put("message_id", userMessage.id)
                    .put("text", userMessage.text)
                    .put("mode", "new_turn"),
                context = buildArixExtensionHostState(_uiState.value),
            )
        }
    }

    /* ---------------------------- instant native tools --------------------- */

    private fun nativeIntentArguments(intent: ArixNativeIntent): String {
        val arguments = JSONObject().put("source", "native")
        when (intent) {
            is ArixNativeIntent.MovieList -> arguments.put("mode", "latest").put("page", intent.page)
            is ArixNativeIntent.MovieSearch -> arguments.put("mode", "search").put("query", intent.query)
            is ArixNativeIntent.MoviePlayUrl -> arguments.put("mode", "play").put("url", intent.url)
            is ArixNativeIntent.MoviePlayTitle -> arguments.put("mode", "search").put("query", intent.title)
            is ArixNativeIntent.QrCode -> arguments.put("data", intent.data)
        }
        return arguments.toString()
    }

    private sealed interface NativeToolOutcome {
        data class Success(val outputJson: String) : NativeToolOutcome
        data class Failure(val message: String) : NativeToolOutcome
    }

    private fun executeNativeIntent(intent: ArixNativeIntent): NativeToolOutcome {
        return when (intent) {
            is ArixNativeIntent.QrCode -> runCatching {
                val matrix = com.arix.app.data.ArixQrEncoder.encode(intent.data.toByteArray(Charsets.UTF_8))
                val png = com.arix.app.data.ArixQrPng.render(matrix, sizePx = 512)
                val base64 = android.util.Base64.encodeToString(png, android.util.Base64.NO_WRAP)
                JSONObject().apply {
                    put("widget", "qr_code")
                    put("data", intent.data)
                    put("kind", com.arix.app.data.ArixQrPng.describeData(intent.data))
                    put("base64", base64)
                    put("size", 512)
                    put("provider", "On-device")
                }.toString()
            }.fold(
                onSuccess = { NativeToolOutcome.Success(it) },
                onFailure = { NativeToolOutcome.Failure("QR generation failed: ${it.message ?: "unknown error"}") },
            )

            is ArixNativeIntent.MovieList -> runCatching {
                val items = MovieSiteClient.fetchLatest(intent.page)
                if (items.isEmpty()) {
                    return NativeToolOutcome.Failure("Could not load the latest movies right now. The movie site may be blocking requests — try again in a moment.")
                }
                MovieSiteClient.listOutputJson("latest", "", intent.page, items)
            }.fold(
                onSuccess = { NativeToolOutcome.Success(it) },
                onFailure = { NativeToolOutcome.Failure("Movie list failed: ${it.message ?: "network error"}") },
            )

            is ArixNativeIntent.MovieSearch -> runCatching {
                val items = MovieSiteClient.search(intent.query)
                if (items.isEmpty()) {
                    return NativeToolOutcome.Failure("No movies found for \"${intent.query}\".")
                }
                MovieSiteClient.listOutputJson("search", intent.query, 1, items)
            }.fold(
                onSuccess = { NativeToolOutcome.Success(it) },
                onFailure = { NativeToolOutcome.Failure("Movie search failed: ${it.message ?: "network error"}") },
            )

            is ArixNativeIntent.MoviePlayUrl -> runCatching {
                val detail = MovieSiteClient.fetchDetail(intent.url)
                if (detail.servers.isEmpty() && detail.downloads.isEmpty()) {
                    return NativeToolOutcome.Failure("No playable servers were found for that movie page.")
                }
                MovieSiteClient.playerOutputJson(detail)
            }.fold(
                onSuccess = { NativeToolOutcome.Success(it) },
                onFailure = { NativeToolOutcome.Failure("Could not resolve the movie: ${it.message ?: "network error"}") },
            )

            is ArixNativeIntent.MoviePlayTitle -> runCatching {
                val results = MovieSiteClient.search(intent.title, limit = 5)
                val match = results.firstOrNull()?.let { MovieSiteClient.fetchDetail(it.url) }
                    ?: return NativeToolOutcome.Failure("Could not find a playable movie for \"${intent.title}\".")
                if (match.servers.isEmpty() && match.downloads.isEmpty()) {
                    return NativeToolOutcome.Failure("No playable servers were found for \"${intent.title}\".")
                }
                MovieSiteClient.playerOutputJson(match)
            }.fold(
                onSuccess = { NativeToolOutcome.Success(it) },
                onFailure = { NativeToolOutcome.Failure("Could not resolve the movie: ${it.message ?: "network error"}") },
            )
        }
    }

    /**
     * Runs a matched native intent as an immediate in-app tool turn: the user
     * message plus an assistant message carrying a tool invocation are added
     * to the session synchronously (widget renders while running), and the
     * invocation is completed with the structured widget payload when the
     * native fetch/generation finishes.
     */
    private fun runNativeToolTurn(
        intent: ArixNativeIntent,
        content: String,
        targetSessionId: String,
    ) {
        val now = System.currentTimeMillis()
        val userMessage = ChatMessage(
            id = "user-$now",
            author = MessageAuthor.User,
            text = content,
            createdAtMillis = now,
        )
        val invocationId = "native-${intent.toolName}-$now"
        val assistantMessage = ChatMessage(
            id = "agent-native-$now",
            author = MessageAuthor.Agent,
            text = "",
            createdAtMillis = now + 1,
            toolInvocations = listOf(
                ChatToolInvocation(
                    id = invocationId,
                    toolName = intent.toolName,
                    argumentsJson = nativeIntentArguments(intent),
                    outputJson = "",
                    isRunning = true,
                    startedAtUptimeMillis = android.os.SystemClock.elapsedRealtime(),
                    startedAtMillis = now,
                    timelineOrder = now,
                ),
            ),
        )

        var sessionForPersistence: ChatSession? = null
        var shouldGenerateTitle = false
        _uiState.update { current ->
            val updatedSessions = current.sessions.toMutableList()
            val existingIndex = updatedSessions.indexOfFirst { it.id == targetSessionId }
            val updated: ChatSession
            if (existingIndex >= 0) {
                val existing = updatedSessions.removeAt(existingIndex)
                updated = existing.withMessages(existing.messages + userMessage + assistantMessage)
            } else {
                shouldGenerateTitle = true
                updated = createSession(
                    id = targetSessionId,
                    messages = listOf(userMessage, assistantMessage),
                    title = "New chat",
                    hasCustomTitle = true,
                    selectedModelKey = current.draftSelectedModelKey.ifBlank {
                        resolveDefaultChatModelKey(current.settings, current.providerConfigs)
                    },
                    selectedSkillIds = emptyList(),
                    activeMcpServerIds = current.draftSelectedMcpServerIds,
                    agentModeEnabled = current.draftAgentModeEnabled,
                    chromeEnabled = current.draftChromeEnabled,
                )
            }
            sessionForPersistence = updated
            updatedSessions.add(0, updated)
            current.copy(
                sessions = updatedSessions,
                currentSessionId = targetSessionId,
                draftInput = "",
                draftAttachments = emptyList(),
                draftSelectedModelKey = "",
                draftSelectedSkillIds = emptyList(),
                draftSelectedMcpServerIds = emptyList(),
                draftAgentModeEnabled = false,
                draftChromeEnabled = false,
                draftWorkspaceId = null,
                editingSessionId = null,
                editingMessageId = null,
                currentScreen = AppScreen.Chat,
                showStarterPromptHint = false,
            )
        }
        sessionForPersistence?.let { session ->
            persistSessionSnapshot(
                session = session,
                currentSessionId = targetSessionId,
                moveToFront = true,
            )
        }
        if (shouldGenerateTitle) {
            generateSessionTitle(
                sessionId = targetSessionId,
                seedMessage = userMessage,
                settings = _uiState.value.settings,
            )
        }

        viewModelScope.launch {
            val outcome = withContext(Dispatchers.IO) {
                runCatching { executeNativeIntent(intent) }
                    .getOrElse { NativeToolOutcome.Failure(it.message ?: "The tool stopped unexpectedly.") }
            }
            val completedUptime = android.os.SystemClock.elapsedRealtime()
            val completedAt = System.currentTimeMillis()
            updateSession(targetSessionId) { session ->
                val messageIndex = session.messages.indexOfFirst { it.id == assistantMessage.id }
                if (messageIndex < 0) return@updateSession null
                val message = session.messages[messageIndex]
                val invocation = message.toolInvocations.firstOrNull { it.id == invocationId }
                    ?: return@updateSession null
                val updatedInvocation = invocation.copy(
                    outputJson = when (outcome) {
                        is NativeToolOutcome.Success -> outcome.outputJson
                        is NativeToolOutcome.Failure -> JSONObject()
                            .put("ok", false)
                            .put("error", outcome.message)
                            .toString()
                    },
                    isRunning = false,
                    completedAtUptimeMillis = completedUptime,
                    completedAtMillis = completedAt,
                )
                val updatedMessage = message.copy(
                    toolInvocations = message.toolInvocations.map {
                        if (it.id == invocationId) updatedInvocation else it
                    },
                    text = if (outcome is NativeToolOutcome.Failure) outcome.message else "",
                )
                val updatedMessages = session.messages.toMutableList()
                updatedMessages[messageIndex] = updatedMessage
                session.withMessages(updatedMessages)
            }
        }
    }

    private fun handleTurnEvent(
        event: SessionTurnEvent,
    ) {
        captureTurnCompleted(event)
        val isSuccessfulAssistantReply = event.outcome == SessionTurnOutcome.Success
        if (
            shouldMarkOnboardingCompleted(
                settings = _uiState.value.settings,
                isSuccessfulAssistantReply = isSuccessfulAssistantReply,
            )
        ) {
            viewModelScope.launch {
                settingsRepository.updateOnboardingCompletedVersion(CurrentOnboardingVersion)
            }
        }
        if (
            shouldRevealFollowUpTourCard(
                isAwaitingFollowUpTour = _uiState.value.awaitingFollowUpTour,
                isSuccessfulAssistantReply = isSuccessfulAssistantReply,
            )
        ) {
            scheduleFollowUpTourAfterFirstReply()
        }
        _uiState.update { current ->
            val unviewedCompletedSessionIds = when {
                event.sessionId == current.currentSessionId -> current.unviewedCompletedSessionIds - event.sessionId
                event.outcome != SessionTurnOutcome.Neutral -> current.unviewedCompletedSessionIds + event.sessionId
                else -> current.unviewedCompletedSessionIds
            }
            current.copy(unviewedCompletedSessionIds = unviewedCompletedSessionIds)
        }
        if ("turn_complete" in arixAppExtensionManager.state.value.snapshot.eventNames) {
            arixAppExtensionManager.emitEvent(
                event = "turn_complete",
                data = JSONObject()
                    .put("session_id", event.sessionId)
                    .put("outcome", event.outcome.name.lowercase()),
                context = buildArixExtensionHostState(_uiState.value),
            )
        }
    }

    private suspend fun buildPendingDraftAttachment(
        uri: Uri,
    ): ChatAttachment? {
        val metadata = readAttachmentMetadata(uri) ?: return null
        return ChatAttachment(
            id = "attachment-${System.currentTimeMillis()}-${uri.hashCode()}",
            uri = uri.toString(),
            name = metadata.displayName,
            mimeType = metadata.mimeType,
            sizeBytes = metadata.sizeBytes,
            kind = metadata.kind,
            workspaceState = AttachmentWorkspaceState.Pending,
        )
    }

    private suspend fun importDraftAttachmentToWorkspace(
        attachment: ChatAttachment,
        sessionId: String,
    ) {
        val importResult = runtimeWorkspaceFileBridge.importAttachmentToWorkspace(
            sourceUri = Uri.parse(attachment.uri),
            attachmentId = attachment.id,
            displayName = attachment.name,
            onProgress = { progress ->
                _uiState.update { current ->
                    val attachmentIndex = current.draftAttachments.indexOfFirst { it.id == attachment.id }
                    if (attachmentIndex < 0) return@update current
                    val existingAttachment = current.draftAttachments[attachmentIndex]
                    current.copy(
                        draftAttachments = current.draftAttachments.toMutableList().apply {
                            set(
                                attachmentIndex,
                                existingAttachment.copy(
                                    workspaceBytesCopied = progress.bytesCopied,
                                    workspaceBytesPerSecond = progress.bytesPerSecond,
                                )
                            )
                        }
                    )
                }
            },
        )

        _uiState.update { current ->
            val attachmentIndex = current.draftAttachments.indexOfFirst { it.id == attachment.id }
            if (attachmentIndex < 0) return@update current

            val existingAttachment = current.draftAttachments[attachmentIndex]
            val updatedAttachment = importResult.fold(
                onSuccess = { importedFile ->
                    val resolvedMimeType = existingAttachment.mimeType.ifBlank {
                        workspaceFileBridge.guessMimeType(importedFile.absolutePath)
                    }
                    existingAttachment.copy(
                        mimeType = resolvedMimeType,
                        sizeBytes = existingAttachment.sizeBytes ?: importedFile.bytesCopied,
                        kind = if (resolvedMimeType.startsWith("image/")) {
                            AttachmentKind.Image
                        } else {
                            AttachmentKind.File
                        },
                        workspacePath = importedFile.absolutePath,
                        workspaceState = AttachmentWorkspaceState.Ready,
                        workspaceError = "",
                        workspaceBytesCopied = importedFile.bytesCopied,
                        workspaceBytesPerSecond = 0L,
                        inlineBase64 = if (
                            resolvedMimeType.startsWith("image/") &&
                            importedFile.inlineBytes.isNotEmpty() &&
                            importedFile.inlineBytes.size <= MaxInlineImageAttachmentBytes
                        ) {
                            Base64.getEncoder().encodeToString(importedFile.inlineBytes)
                        } else {
                            existingAttachment.inlineBase64
                        },
                    )
                },
                onFailure = { throwable ->
                    val inlineImageBase64 = readInlineImageAttachment(existingAttachment)
                    if (inlineImageBase64.isNotBlank()) {
                        existingAttachment.copy(
                            workspacePath = "",
                            workspaceState = AttachmentWorkspaceState.Ready,
                            workspaceError = "",
                            workspaceBytesPerSecond = 0L,
                            inlineBase64 = inlineImageBase64,
                        )
                    } else {
                        existingAttachment.copy(
                            workspaceState = AttachmentWorkspaceState.Failed,
                            workspaceError = throwable.message
                                .orEmpty()
                                .ifBlank { "Couldn't copy this attachment into the workspace." },
                            workspaceBytesPerSecond = 0L,
                        )
                    }
                },
            )

            current.copy(
                draftAttachments = current.draftAttachments.toMutableList().apply {
                    set(attachmentIndex, updatedAttachment)
                }
            )
        }
    }

    private fun readInlineImageAttachment(attachment: ChatAttachment): String {
        if (attachment.kind != AttachmentKind.Image || !attachment.mimeType.startsWith("image/")) return ""
        if (attachment.sizeBytes?.let { it > MaxInlineImageAttachmentBytes } == true) return ""
        return runCatching {
            val resolver = getApplication<Application>().contentResolver
            val bytes = resolver.openInputStream(Uri.parse(attachment.uri))?.use { input ->
                val buffer = ByteArray(MaxInlineImageAttachmentBytes + 1)
                var total = 0
                while (total < buffer.size) {
                    val read = input.read(buffer, total, buffer.size - total)
                    if (read <= 0) break
                    total += read
                }
                require(total <= MaxInlineImageAttachmentBytes) { "Image is too large to inline." }
                buffer.copyOf(total)
            } ?: return ""
            Base64.getEncoder().encodeToString(bytes)
        }.getOrDefault("")
    }

    private fun normalizeDraftAttachmentForEditing(
        attachment: ChatAttachment,
    ): ChatAttachment = if (
        attachment.workspacePath.isNotBlank() ||
        (attachment.kind == AttachmentKind.Image && attachment.inlineBase64.isNotBlank())
    ) {
        attachment.copy(
            workspaceState = AttachmentWorkspaceState.Ready,
            workspaceError = "",
            workspaceBytesPerSecond = 0L,
        )
    } else {
        attachment.copy(
            workspaceState = AttachmentWorkspaceState.Failed,
            workspaceError = "This attachment is missing its workspace copy. Re-upload it before sending.",
        )
    }

    private fun readAttachmentMetadata(
        uri: Uri,
    ): AttachmentMetadata? {
        val resolver = getApplication<Application>().contentResolver
        var mimeType = resolver.getType(uri).orEmpty()
        var displayName = uri.lastPathSegment ?: "Attachment"
        var sizeBytes: Long? = null

        resolver.query(
            uri,
            arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE),
            null,
            null,
            null,
        )?.use { cursor ->
            if (cursor.moveToFirst()) {
                val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (nameIndex >= 0) {
                    displayName = cursor.getString(nameIndex) ?: displayName
                }

                val sizeIndex = cursor.getColumnIndex(OpenableColumns.SIZE)
                if (sizeIndex >= 0 && !cursor.isNull(sizeIndex)) {
                    sizeBytes = cursor.getLong(sizeIndex)
                }
            }
        }

        if (mimeType.isBlank()) {
            mimeType = workspaceFileBridge.guessMimeType(displayName)
        }

        return AttachmentMetadata(
            displayName = displayName,
            mimeType = mimeType,
            sizeBytes = sizeBytes,
            kind = if (mimeType.startsWith("image/")) AttachmentKind.Image else AttachmentKind.File,
        )
    }

    private fun scheduleFollowUpTourAfterFirstReply() {
        _uiState.update { current ->
            current.copy(
                awaitingFollowUpTour = false,
                showFollowUpTourCard = true,
            )
        }
        viewModelScope.launch {
            delay(FollowUpTourAutoOpenDelayMillis)
            _uiState.update { current ->
                if (current.currentScreen != AppScreen.Chat) {
                    current
                } else {
                    current.copy(
                        currentScreen = AppScreen.Onboarding,
                        isOnboardingReplay = true,
                        onboardingStep = OnboardingStep.LocalRuntimeChoice,
                        onboardingReturnScreen = AppScreen.Chat,
                        awaitingFollowUpTour = false,
                        showFollowUpTourCard = false,
                    )
                }
            }
        }
    }

    private fun persistCurrentSessionId(sessionId: String) {
        chatStateStore.update { persisted ->
            persisted.copy(
                sessions = persisted.sessions.withMessagesOnlyForSession(sessionId),
                currentSessionId = sessionId,
            )
        }
    }

    private suspend fun hydrateCurrentSessionMessages(persisted: PersistedChatState): PersistedChatState {
        val currentSessionId = persisted.currentSessionId.ifBlank { DraftSessionId }
        if (currentSessionId == DraftSessionId) return persisted
        val currentSession = persisted.sessions.firstOrNull { it.id == currentSessionId } ?: return persisted
        if (currentSession.messages.isNotEmpty() || currentSession.messageCount <= 0) return persisted
        val loadedSession = runCatching {
            withContext(Dispatchers.IO) {
                runtime.chatRepository.getSessionWithMessages(currentSessionId)
            }
        }.getOrElse { throwable ->
            if (throwable is CancellationException) throw throwable
            diagnosticLogger.exception(
                category = "storage",
                event = "session_hydration_failed",
                throwable = throwable,
                level = "warn",
                sessionId = currentSessionId,
            )
            null
        } ?: return persisted
        return persisted.copy(
            sessions = replaceOrPrependSession(persisted.sessions, loadedSession),
        )
    }

    private fun persistSessionSelection(
        sessionId: String,
        loadedSession: ChatSession?,
    ) {
        if (loadedSession == null) {
            persistCurrentSessionId(sessionId)
            return
        }
        chatStateStore.update { persisted ->
            persisted.copy(
                sessions = replaceOrPrependSession(persisted.sessions, loadedSession)
                    .withMessagesOnlyForSession(sessionId),
                currentSessionId = sessionId,
            )
        }
    }

    private fun replaceOrPrependSession(
        sessions: List<ChatSession>,
        session: ChatSession,
    ): List<ChatSession> = if (sessions.any { it.id == session.id }) {
        sessions.map { existing ->
            if (existing.id == session.id) session else existing
        }
    } else {
        listOf(session) + sessions
    }

    private fun List<ChatSession>.withMessagesOnlyForSession(sessionId: String): List<ChatSession> =
        map { session ->
            if (session.id == sessionId) {
                session
            } else {
                session.copy(messages = emptyList())
            }
        }

    private fun replacePersistedChats(
        sessions: List<ChatSession>,
        currentSessionId: String,
    ) {
        chatStateStore.update { persisted ->
            persisted.copy(
                sessions = sessions,
                currentSessionId = currentSessionId,
            )
        }
    }

    private fun persistSessionSnapshot(
        session: ChatSession,
        currentSessionId: String? = null,
        moveToFront: Boolean = false,
    ) {
        chatStateStore.update { persisted ->
            val currentIndex = persisted.sessions.indexOfFirst { it.id == session.id }
            val updatedSessions = persisted.sessions.toMutableList().apply {
                if (currentIndex >= 0) {
                    removeAt(currentIndex)
                }
                val insertIndex = when {
                    moveToFront -> 0
                    currentIndex >= 0 -> currentIndex.coerceAtMost(size)
                    else -> 0
                }
                add(insertIndex, session)
            }
            persisted.copy(
                sessions = updatedSessions,
                currentSessionId = currentSessionId ?: persisted.currentSessionId,
            )
        }
    }

    private suspend fun persistSessionSnapshotAndFlush(
        session: ChatSession,
        moveToFront: Boolean = false,
        currentSessionId: String? = null,
    ) {
        chatStateStore.updateAndFlush { persisted ->
            val currentIndex = persisted.sessions.indexOfFirst { it.id == session.id }
            val updatedSessions = persisted.sessions.toMutableList().apply {
                if (currentIndex >= 0) {
                    removeAt(currentIndex)
                }
                val insertIndex = when {
                    moveToFront -> 0
                    currentIndex >= 0 -> currentIndex.coerceAtMost(size)
                    else -> 0
                }
                add(insertIndex, session)
            }
            persisted.copy(
                sessions = updatedSessions,
                currentSessionId = currentSessionId ?: persisted.currentSessionId,
            )
        }
    }

    private fun persistSessionMutation(
        sessionId: String,
        transform: (ChatSession) -> ChatSession?,
    ) {
        chatStateStore.update { persisted ->
            val sessionIndex = persisted.sessions.indexOfFirst { it.id == sessionId }
            if (sessionIndex < 0) return@update persisted
            val updatedSession = transform(persisted.sessions[sessionIndex]) ?: return@update persisted
            val updatedSessions = persisted.sessions.toMutableList().apply {
                set(sessionIndex, updatedSession)
            }
            persisted.copy(sessions = updatedSessions)
        }
    }

    private suspend fun persistDeleteSession(
        sessionId: String,
        sharedWorkspaceFilePaths: Collection<String> = emptyList(),
    ) {
        val agentSession = runCatching {
            runtime.chatRepository.getAgentSessionMetadata(sessionId)
        }.getOrNull()
        runCatching {
            runtime.piKernelBridge.closeSession(
                sessionId = sessionId,
                sessionFile = agentSession?.jsonlPath.orEmpty(),
                deleteFile = true,
            )
        }.onFailure { throwable ->
            diagnosticLogger.exception(
                category = "pi_bridge",
                event = "close_deleted_session_failed",
                throwable = throwable,
                level = "warn",
                sessionId = sessionId,
            )
        }
        val unreferencedSharedWorkspaceFilePaths = sharedWorkspaceFilePaths
            .map(String::trim)
            .filter(String::isNotEmpty)
            .distinct()
        chatStateStore.updateAndFlush(
            writeIntent = PersistedChatWriteIntent.DeleteSession,
        ) { persisted ->
            val updatedSessions = persisted.sessions.filterNot { it.id == sessionId }
            persisted.copy(
                sessions = updatedSessions,
                currentSessionId = if (persisted.currentSessionId == sessionId) {
                    DraftSessionId
                } else {
                    persisted.currentSessionId
                },
            )
        }
        scheduleSessionRuntimeDataCleanup(
            sessionIds = listOf(sessionId),
            sharedWorkspaceFilePaths = unreferencedSharedWorkspaceFilePaths,
            mode = _uiState.value.settings.agentWorkspaceMode,
        )
    }

    private fun scheduleSessionRuntimeDataCleanup(
        sessionIds: Collection<String>,
        sharedWorkspaceFilePaths: Collection<String>,
        mode: AgentWorkspaceMode,
    ) {
        val cleanupSessionIds = sessionIds
            .filter { it.isNotBlank() && it != DraftSessionId }
            .distinct()
        val sharedWorkspaceFileCount = sharedWorkspaceFilePaths.distinct().size
        if (cleanupSessionIds.isEmpty() && sharedWorkspaceFileCount == 0) return

        viewModelScope.launch {
            workspaceFileBridge.deleteSessionsRuntimeData(
                sessionIds = cleanupSessionIds,
                sharedWorkspaceFilePaths = sharedWorkspaceFilePaths,
            )
                .onSuccess {
                    diagnosticLogger.event(
                        category = "storage",
                        event = "deleted_session_runtime_cleanup_completed",
                        sessionId = cleanupSessionIds.singleOrNull(),
                        details = mapOf(
                            "session_count" to cleanupSessionIds.size,
                            "shared_workspace_file_count" to sharedWorkspaceFileCount,
                            "settings_workspace_mode" to mode.storageValue,
                        ),
                    )
                }
                .onFailure { throwable ->
                    diagnosticLogger.exception(
                        category = "storage",
                        event = "deleted_session_runtime_cleanup_failed",
                        throwable = throwable,
                        level = "warn",
                        sessionId = cleanupSessionIds.singleOrNull(),
                        details = mapOf(
                            "session_count" to cleanupSessionIds.size,
                            "shared_workspace_file_count" to sharedWorkspaceFileCount,
                            "settings_workspace_mode" to mode.storageValue,
                        ),
                    )
                }
        }
    }

    private fun persistPrunedSessionSelections(
        enabledSkillIds: Set<String>,
        enabledMcpServerIds: Set<String>,
    ) {
        chatStateStore.update { persisted ->
            persisted.copy(
                sessions = persisted.sessions.map { session ->
                    val selectedSkillIds = session.selectedSkillIds.filter(enabledSkillIds::contains)
                    val activeSkills = session.activeSkills.filter { activeSkill ->
                        selectedSkillIds.contains(activeSkill.skillId)
                    }
                    val activeMcpServerIds = session.activeMcpServerIds.filter(enabledMcpServerIds::contains)
                    if (
                        selectedSkillIds == session.selectedSkillIds &&
                        activeSkills == session.activeSkills &&
                        activeMcpServerIds == session.activeMcpServerIds
                    ) {
                        session
                    } else {
                        session.copy(
                            selectedSkillIds = selectedSkillIds,
                            activeSkills = activeSkills,
                            activeMcpServerIds = activeMcpServerIds,
                        )
                    }
                }
            )
        }
    }

    private fun buildAnalyticsTurnRequest(
        snapshot: ArixUiState,
        sessionId: String,
        userMessage: ChatMessage,
    ): SessionTurnRequest? {
        val session = snapshot.sessions.firstOrNull { it.id == sessionId } ?: return null
        return SessionTurnRequest(
            sessionId = sessionId,
            settings = resolveModelSettings(
                baseSettings = snapshot.settings,
                providerConfigs = snapshot.providerConfigs,
                preferredModelKey = session.selectedModelKey,
                fallbackModelKey = resolveDefaultChatModelKey(snapshot.settings, snapshot.providerConfigs),
            ),
            requestMessages = session.messages + userMessage,
            selectedSkillIds = session.selectedSkillIds,
            activeSkills = session.activeSkills,
            activeMcpServerIds = session.activeMcpServerIds,
            agentModeEnabled = session.agentModeEnabled,
            chromeEnabled = session.chromeEnabled,
            providerConfigs = snapshot.providerConfigs,
        )
    }

    private fun captureMessageSent(
        request: SessionTurnRequest,
        attachments: List<ChatAttachment>,
        isEdit: Boolean,
        submissionType: String,
    ) {
        val modelProperties = modelUsageProperties(request, source = "message")
        captureAnalyticsEvent(
            event = "message sent",
            properties = mapOf(
                "has_attachments" to attachments.isNotEmpty(),
                "attachment_count" to attachments.size,
                "agent_mode_enabled" to request.agentModeEnabled,
                "skill_count" to request.selectedSkillIds.size,
                "mcp_server_count" to request.activeMcpServerIds.size,
                "is_edit" to isEdit,
                "submission_type" to submissionType,
            ) + modelProperties,
        )
        captureAnalyticsEvent(
            event = "model used",
            properties = modelProperties + mapOf(
                "has_attachments" to attachments.isNotEmpty(),
                "attachment_count" to attachments.size,
                "is_edit" to isEdit,
                "submission_type" to submissionType,
            ),
        )
        captureAgentModeStarted(
            request = request,
            isEdit = isEdit,
            submissionType = submissionType,
        )
    }

    private fun captureTurnCompleted(event: SessionTurnEvent) {
        val tokenProperties = tokenUsageAnalyticsProperties(event)
        captureAnalyticsEvent(
            event = "conversation turn completed",
            properties = mapOf(
                "outcome" to event.outcome.name.lowercase(),
                "tool_call_count" to event.toolCallCount,
                "distinct_tool_count" to event.distinctToolCount,
                "tool_names" to event.toolNames,
                "has_tool_calls" to (event.toolCallCount > 0),
                "duration_millis" to (event.durationMillis ?: 0L),
            ) + tokenProperties,
        )
        if (event.tokenUsage != null) {
            captureAnalyticsEvent(
                event = "tokens used",
                properties = tokenProperties + mapOf(
                    "outcome" to event.outcome.name.lowercase(),
                    "tool_call_count" to event.toolCallCount,
                    "has_tool_calls" to (event.toolCallCount > 0),
                    "duration_millis" to (event.durationMillis ?: 0L),
                ),
            )
        }
    }

    private fun captureAgentModeStarted(
        request: SessionTurnRequest,
        isEdit: Boolean,
        submissionType: String,
    ) {
        if (!request.agentModeEnabled) return
        val properties = modelUsageProperties(request, source = "agent_mode") + mapOf(
            "authorization_enabled" to request.settings.agentModeAuthorizationEnabled,
            "is_edit" to isEdit,
            "submission_type" to submissionType,
        )
        if (request.settings.agentModeAuthorizationEnabled) {
            captureAnalyticsEvent(
                event = "agent mode started",
                properties = properties,
            )
        } else {
            captureAnalyticsEvent(
                event = "agent mode failed",
                properties = properties + mapOf("reason" to "authorization_disabled"),
            )
        }
    }

    private fun modelUsageProperties(
        request: SessionTurnRequest,
        source: String,
    ): Map<String, Any> = mapOf(
        "model" to request.settings.modelId.trim(),
        "provider" to com.arix.app.data.PiProviderCatalog
            .resolve(request.settings.piProviderId).displayName,
        "provider_type" to request.settings.piProviderId,
        "source" to source,
        "agent_mode_enabled" to request.agentModeEnabled,
        "skill_count" to request.selectedSkillIds.size,
        "mcp_server_count" to request.activeMcpServerIds.size,
    )

    private fun tokenUsageAnalyticsProperties(event: SessionTurnEvent): Map<String, Any> {
        val usage = event.tokenUsage
        val totalTokens = usage?.totalTokens ?: 0L
        val inputTokens = usage?.inputTokens ?: 0L
        val outputTokens = usage?.outputTokens ?: 0L
        val inputMessageCount = event.inputMessageCount.coerceAtLeast(0)
        val userMessageCount = event.userMessageCount.coerceAtLeast(0)
        return buildMap {
            put("token_usage_source", event.tokenUsageSource)
            put("has_token_usage", usage != null)
            put("input_message_count", inputMessageCount)
            put("user_message_count", userMessageCount)
            put("llm_request_count", usage?.requestCount ?: 0)
            put("input_tokens", inputTokens)
            put("output_tokens", outputTokens)
            put("total_tokens", totalTokens)
            usage?.reasoningTokens?.let { put("reasoning_tokens", it) }
            usage?.cachedInputTokens?.let { put("cached_input_tokens", it) }
            put(
                "average_tokens_per_input_message",
                if (inputMessageCount > 0) totalTokens.toDouble() / inputMessageCount else 0.0,
            )
            put(
                "average_input_tokens_per_input_message",
                if (inputMessageCount > 0) inputTokens.toDouble() / inputMessageCount else 0.0,
            )
            put(
                "average_tokens_per_user_message",
                if (userMessageCount > 0) totalTokens.toDouble() / userMessageCount else 0.0,
            )
        }
    }

    private fun captureAnalyticsEvent(
        event: String,
        properties: Map<String, Any> = emptyMap(),
    ) {
        ArixAnalytics.capture(event = event, properties = properties)
    }

    private fun normalizeProviderConfig(
        config: LlmProviderConfig,
    ): LlmProviderConfig {
        val definition = com.arix.app.data.PiProviderCatalog.resolve(
            config.piProviderId,
        )
        val manualModels = (config.manualModelIds.ifEmpty { listOf(config.modelId) })
            .map(String::trim)
            .filter(String::isNotEmpty)
            .distinct()
        val cachedModels = config.cachedModels
            .map(String::trim)
            .filter(String::isNotEmpty)
            .distinct()
        val availableModels = (cachedModels + manualModels)
            .map(String::trim)
            .filter(String::isNotEmpty)
            .distinct()
        val normalizedModelId = config.modelId.trim()
            .takeIf { it.isNotBlank() && availableModels.contains(it) }
            ?: manualModels.firstOrNull()
            ?: cachedModels.firstOrNull()
            ?: definition.defaultModelId
        val normalizedEnabledModels = config.enabledModelIds
            .map(String::trim)
            .filter { it.isNotEmpty() && availableModels.contains(it) }
            .distinct()
        return config.copy(
            providerId = config.providerId.trim(),
            name = config.name.trim().ifBlank { definition.displayName },
            piProviderId = definition.id,
            baseUrl = config.baseUrl.trim(),
            modelId = normalizedModelId,
            manualModelIds = manualModels,
            userAgent = normalizeLlmUserAgent(config.userAgent),
            customHeaders = config.customHeaders
                .map { header -> header.copy(name = header.name.trim()) }
                .filter { header ->
                    header.name.isNotBlank() &&
                        !header.name.equals("User-Agent", ignoreCase = true)
                }
                .distinctBy { header -> header.name.lowercase() },
            providerEnvironmentVariables = config.providerEnvironmentVariables
                .map { variable -> variable.copy(name = variable.name.trim()) }
                .filter { variable -> variable.name.isNotBlank() }
                .distinctBy { variable -> variable.name.uppercase() },
            cachedModels = cachedModels,
            enabledModelIds = normalizedEnabledModels,
        )
    }

    private fun createSession(
        id: String,
        messages: List<ChatMessage>,
        title: String? = null,
        hasCustomTitle: Boolean = false,
        selectedModelKey: String = "",
        selectedSkillIds: List<String> = emptyList(),
        activeSkills: List<ActiveSkillContext> = emptyList(),
        activeMcpServerIds: List<String> = emptyList(),
        agentModeEnabled: Boolean = false,
        chromeEnabled: Boolean = false,
    ): ChatSession {
        val metadata = deriveSessionMetadata(messages)
        return ChatSession(
            id = id,
            title = title ?: metadata.title,
            preview = metadata.preview,
            hasCustomTitle = hasCustomTitle,
            messages = messages,
            selectedModelKey = selectedModelKey,
            selectedSkillIds = selectedSkillIds,
            activeSkills = activeSkills,
            activeMcpServerIds = activeMcpServerIds,
            agentModeEnabled = agentModeEnabled,
            chromeEnabled = chromeEnabled,
        )
    }

    private fun ChatSession.withMessages(messages: List<ChatMessage>): ChatSession {
        val syncedMessages = syncActiveBranches(messages)
        val metadata = deriveSessionMetadata(syncedMessages)
        return copy(
            title = if (hasCustomTitle) title else metadata.title,
            preview = metadata.preview,
            messages = syncedMessages,
            messageCount = syncedMessages.size,
            lastMessageAtMillis = syncedMessages.maxOfOrNull { it.createdAtMillis },
        )
    }

    private suspend fun resolveSelectedActiveSkills(
        selectedSkillIds: List<String>,
        existingActiveSkills: List<ActiveSkillContext>,
    ): List<ActiveSkillContext> {
        if (selectedSkillIds.isEmpty()) return emptyList()
        val installedSkillsById = _uiState.value.installedSkills
            .filter { it.isEnabled }
            .associateBy { it.id }
        return buildList {
            selectedSkillIds.distinct().forEach { skillId ->
                val installedSkill = installedSkillsById[skillId] ?: return@forEach
                val refreshedSkill = skillManager.buildActiveSkillContext(installedSkill)
                    .getOrElse { return@forEach }
                add(refreshedSkill)
            }
        }
    }

    private fun upsertActiveSkillContext(
        activeSkills: List<ActiveSkillContext>,
        activeSkill: ActiveSkillContext,
    ): List<ActiveSkillContext> {
        val existingIndex = activeSkills.indexOfFirst { it.skillId == activeSkill.skillId }
        if (existingIndex < 0) return activeSkills + activeSkill
        return activeSkills.toMutableList().apply {
            set(existingIndex, activeSkill)
        }
    }

    private fun resolveSelectedMcpServers(
        selectedServerIds: List<String>,
    ): List<McpServerConfig> {
        if (selectedServerIds.isEmpty()) return emptyList()
        val enabledServersById = _uiState.value.mcpServers
            .filter { it.isEnabled }
            .associateBy { it.id }
        return selectedServerIds.distinct().mapNotNull(enabledServersById::get)
    }

    private fun setSessionSelectedSkillIds(
        sessionId: String,
        selectedSkillIds: List<String>,
    ) {
        updateSession(sessionId) { session ->
            val activeSkills = session.activeSkills.filter { activeSkill ->
                selectedSkillIds.contains(activeSkill.skillId)
            }
            if (
                session.selectedSkillIds == selectedSkillIds &&
                session.activeSkills == activeSkills
            ) {
                null
            } else {
                session.copy(
                    selectedSkillIds = selectedSkillIds,
                    activeSkills = activeSkills,
                )
            }
        }
    }

    private fun setSessionActiveSkills(
        sessionId: String,
        activeSkills: List<ActiveSkillContext>,
    ) {
        updateSession(sessionId) { session ->
            if (session.activeSkills == activeSkills) {
                null
            } else {
                session.copy(activeSkills = activeSkills)
            }
        }
    }

    private fun setSessionActiveMcpServerIds(
        sessionId: String,
        activeMcpServerIds: List<String>,
    ) {
        updateSession(sessionId) { session ->
            if (session.activeMcpServerIds == activeMcpServerIds) {
                null
            } else {
                session.copy(activeMcpServerIds = activeMcpServerIds)
            }
        }
    }

    private fun updateSession(
        sessionId: String,
        transform: (ChatSession) -> ChatSession?,
    ) {
        var didUpdate = false
        _uiState.update { current ->
            val sessionIndex = current.sessions.indexOfFirst { it.id == sessionId }
            if (sessionIndex < 0) return@update current
            val updatedSessions = current.sessions.toMutableList()
            val session = updatedSessions.removeAt(sessionIndex)
            val updatedSession = transform(session)
            if (updatedSession == null) {
                updatedSessions.add(sessionIndex, session)
                current
            } else {
                didUpdate = true
                updatedSessions.add(
                    sessionIndex.coerceAtMost(updatedSessions.size),
                    updatedSession,
                )
                current.copy(sessions = updatedSessions)
            }
        }
        if (didUpdate) {
            persistSessionMutation(sessionId, transform)
        }
    }

    private fun findMcpServerById(serverId: String): McpServerConfig? =
        _uiState.value.mcpServers.firstOrNull { it.id == serverId }

    private fun updateOrderedSelection(
        currentSelection: List<String>,
        id: String,
        selected: Boolean,
    ): List<String> = when {
        selected && currentSelection.contains(id) -> currentSelection
        selected -> currentSelection + id
        else -> currentSelection.filterNot { it == id }
    }

    private fun deriveSessionMetadata(messages: List<ChatMessage>): SessionMetadata {
        val visibleMessages = messages.filter { it.displayKind != MessageDisplayKind.HiddenContext }
        val title = messages
            .firstOrNull { it.author == MessageAuthor.User && it.displayKind == MessageDisplayKind.Standard }
            ?.summaryText()
            .orEmpty()
            .ifBlank { "New chat" }
            .take(36)

        val preview = visibleMessages
            .lastOrNull()
            ?.summaryText()
            .orEmpty()
            .ifBlank { "No messages yet." }
            .take(96)

        return SessionMetadata(title = title, preview = preview)
    }

    private fun generateSessionTitle(
        sessionId: String,
        seedMessage: ChatMessage,
        settings: AppSettings,
    ) {
                if (!settings.isProviderSetupValid()) {
            return
        }

        val titleInput = buildTitleGenerationInput(seedMessage)
        if (titleInput.isBlank()) return

        viewModelScope.launch {
            val providerConfigs = _uiState.value.providerConfigs
            val titleSettings = resolveModelSettings(
                baseSettings = settings,
                providerConfigs = providerConfigs,
                preferredModelKey = resolveDefaultTitleModelKey(settings, providerConfigs),
                fallbackModelKey = resolveDefaultChatModelKey(settings, providerConfigs),
            )
            val modelKey = thinkingCatalogKey(titleSettings.piProviderId, titleSettings.modelId)
            val thinkingLevelMap = _uiState.value.thinkingLevelClampsByProviderModel[modelKey].orEmpty()
            val isReasoningModel = modelKey in _uiState.value.reasoningModels
            val title = piCompletionClient.completeOnce(
                settings = titleSettings,
                systemPrompt = SessionTitleSystemPrompt,
                messages = listOf(
                    LlmMessage(
                        role = "user",
                        contentParts = listOf(LlmTextPart(titleInput)),
                    )
                ),
                disableReasoning = true,
                thinkingLevelMap = thinkingLevelMap,
                isReasoningModel = isReasoningModel,
            ).getOrNull()
                ?.assistantText
                ?.sanitizeGeneratedSessionTitle()
                .orEmpty()

            if (title.isBlank()) return@launch

            updateSession(sessionId) { session ->
                val firstUserMessage = session.messages.firstOrNull { it.author == MessageAuthor.User }
                if (firstUserMessage?.id != seedMessage.id) {
                    null
                } else {
                    session.copy(
                        title = title,
                        hasCustomTitle = true,
                    )
                }
            }
        }
    }

    private fun buildTitleGenerationInput(
        message: ChatMessage,
    ): String = buildString {
        val text = message.text.trim()
        if (text.isNotBlank()) {
            appendLine("First user message:")
            appendLine(text)
        }
        if (message.attachments.isNotEmpty()) {
            if (isNotEmpty()) appendLine()
            appendLine("Attachments:")
            message.attachments.forEach { attachment ->
                appendLine("- ${attachment.name}")
            }
        }
    }.trim()

    private fun isCompactCommand(content: String): Boolean =
        content.trim().equals(CompactCommand, ignoreCase = true)

    private fun compactCurrentSession(snapshot: ArixUiState) {
        compactSession(snapshot.currentSessionId, manual = true, snapshot = snapshot)
    }

    private fun compactSession(
        sessionId: String,
        manual: Boolean,
        snapshot: ArixUiState = _uiState.value,
    ) {
        if ((manual && snapshot.editingSessionId != null) || snapshot.editingSessionId == sessionId) {
            if (!manual) return
            emitTransientMessage(uiString(R.string.message_finish_editing_before_compacting))
            return
        }
        if (sessionId == DraftSessionId) {
            if (!manual) return
            emitTransientMessage(uiString(R.string.message_no_conversation_to_compact))
            return
        }
        if (sessionExecutionManager.isSessionRunning(sessionId)) {
            if (!manual) return
            emitTransientMessage(uiString(R.string.message_pause_before_compacting))
            return
        }
        if (snapshot.compactingSessionId != null) return
        val session = snapshot.sessions.firstOrNull { it.id == sessionId }
        if (session == null || session.messages.size < 2) {
            if (!manual) return
            emitTransientMessage(uiString(R.string.message_not_enough_conversation_to_compact))
            return
        }
        _uiState.update { current ->
            if (manual) {
                current.copy(
                    draftInput = "",
                    draftAttachments = emptyList(),
                    draftWorkspaceId = null,
                    editingSessionId = null,
                    editingMessageId = null,
                    showStarterPromptHint = false,
                    compactingSessionId = sessionId,
                )
            } else {
                current.copy(compactingSessionId = sessionId)
            }
        }

        viewModelScope.launch {
            try {
                val metadata = runtime.chatRepository.getAgentSessionMetadata(sessionId)
                val settings = snapshot.settings
                piKernelBridge.compactSession(
                    sessionId = sessionId,
                    sessionPayload = JSONObject().apply {
                        put("session_file", metadata?.jsonlPath.orEmpty())
                        put("workspace_directory", workspaceFileBridge.workspaceDirectory(sessionId, settings.agentWorkspaceMode))
                        put("runtime", metadata?.runtime ?: settings.defaultRuntimeId?.storageValue.orEmpty())
                        put("platform", "android")
                        val modelKey = thinkingCatalogKey(settings.piProviderId, settings.modelId)
                        val thinkingLevelMap = _uiState.value.thinkingLevelClampsByProviderModel[modelKey].orEmpty()
                        val isReasoningModel = modelKey in _uiState.value.reasoningModels
                        put("model_config", settings.toPiModelConfig(thinkingLevelMap, isReasoningModel).toJson())
                        put("system_prompt", "")
                        put("host_tools", JSONArray())
                    },
                )
                val now = System.currentTimeMillis()
                val compactedMessages = session.messages + ChatMessage(
                    id = "compact-status-$now",
                    author = MessageAuthor.Agent,
                    text = "Context compacted",
                    createdAtMillis = now,
                    assistantActionsHidden = true,
                    displayKind = MessageDisplayKind.CompactStatus,
                )
                val updatedSession = session.withMessages(compactedMessages)
                _uiState.update { current ->
                    val sessionIndex = current.sessions.indexOfFirst { it.id == sessionId }
                    if (sessionIndex < 0) return@update current
                    val updatedSessions = current.sessions.toMutableList().apply {
                        set(sessionIndex, updatedSession)
                    }
                    current.copy(sessions = updatedSessions)
                }
                persistSessionSnapshot(updatedSession, currentSessionId = sessionId)
            } catch (throwable: Throwable) {
                if (throwable is CancellationException) throw throwable
                emitTransientMessage(uiString(R.string.message_compaction_failed, throwable.userFacingMessage()))
            } finally {
                _uiState.update { current ->
                    if (current.compactingSessionId == sessionId) {
                        current.copy(compactingSessionId = null)
                    } else {
                        current
                    }
                }
            }
        }
    }

    private fun String.sanitizeGeneratedSessionTitle(): String =
        lineSequence()
            .map { line ->
                line.trim()
                    .removePrefix("Title:")
                    .removePrefix("title:")
                    .trim()
                    .trim('"', '\'', '`')
            }
            .firstOrNull { it.isNotBlank() }
            .orEmpty()
            .trimEnd('.', '!', '?')
            .take(36)

    private fun ensureDraftWorkspaceId(): String {
        val snapshot = _uiState.value
        return snapshot.editingSessionId ?: when {
            snapshot.currentSessionId != DraftSessionId -> snapshot.currentSessionId
            !snapshot.draftWorkspaceId.isNullOrBlank() -> snapshot.draftWorkspaceId.orEmpty()
            else -> {
                val generatedId = "session-${System.currentTimeMillis()}"
                _uiState.update { current ->
                    if (current.currentSessionId == DraftSessionId && current.draftWorkspaceId.isNullOrBlank()) {
                        current.copy(draftWorkspaceId = generatedId)
                    } else {
                        current
                    }
                }
                _uiState.value.draftWorkspaceId ?: generatedId
            }
        }
    }

    private fun ChatMessage.summaryText(): String {
        if (displayKind == MessageDisplayKind.CompactStatus) return text.ifBlank { "Context compacted" }
        val textSummary = text.trim()
        if (textSummary.isNotBlank()) return textSummary
        reasoningTrace?.let { trace ->
            trace.chunks.lastOrNull { it.detail.isNotBlank() || it.title.isNotBlank() }?.let { chunk ->
                return chunk.detail.ifBlank { chunk.title }
            }
            return if (trace.toolInvocations.isNotEmpty()) {
                "Thought and used ${trace.toolInvocations.size} tools"
            } else {
                "Thought"
            }
        }
        if (toolInvocations.isNotEmpty()) {
            return if (toolInvocations.size == 1) {
                when (toolInvocations.first().toolName.lowercase()) {
                    "bash" -> "Ran bash command"
                    else -> "Used ${toolInvocations.first().toolName}"
                }
            } else {
                "Used ${toolInvocations.size} tools"
            }
        }
        if (attachments.isEmpty()) return "Empty message"
        if (attachments.size == 1) return attachments.first().name
        return "${attachments.size} attachments"
    }

    private fun List<ChatMessage>.resolveConversationTrimIndex(
        targetIndex: Int,
    ): Int {
        val targetMessage = getOrNull(targetIndex) ?: return targetIndex
        val responseGroupId = targetMessage.responseGroupId
        if (
            targetMessage.author != MessageAuthor.Agent ||
            responseGroupId.isNullOrBlank()
        ) {
            return targetIndex
        }
        if (responseGroupId.isNullOrBlank()) {
            return resolveLegacyAssistantGroupStartIndex(targetIndex)
        }
        val groupStartIndex = indexOfFirst { message ->
            message.author == MessageAuthor.Agent && message.responseGroupId == responseGroupId
        }
        return if (groupStartIndex >= 0) groupStartIndex else targetIndex
    }

    private fun List<ChatMessage>.resolveLegacyAssistantGroupStartIndex(
        targetIndex: Int,
    ): Int {
        val targetMessage = getOrNull(targetIndex) ?: return targetIndex
        if (targetMessage.author != MessageAuthor.Agent) return targetIndex
        var groupStartIndex = targetIndex
        var expectedCreatedAtMillis = targetMessage.createdAtMillis
        while (groupStartIndex > 0) {
            val previous = this[groupStartIndex - 1]
            if (
                previous.author != MessageAuthor.Agent ||
                !previous.responseGroupId.isNullOrBlank() ||
                previous.createdAtMillis != expectedCreatedAtMillis - 1
            ) {
                break
            }
            groupStartIndex -= 1
            expectedCreatedAtMillis = previous.createdAtMillis
        }
        return groupStartIndex
    }

    private fun formatBytes(bytes: Long): String = when {
        bytes >= 1024 * 1024 -> String.format("%.1f MB", bytes / (1024f * 1024f))
        bytes >= 1024 -> String.format("%.1f KB", bytes / 1024f)
        else -> "$bytes B"
    }

    private fun parseKeyValueLines(rawValue: String): List<com.arix.app.data.McpKeyValue> =
        rawValue.lineSequence()
            .mapNotNull { line ->
                val trimmed = line.trim()
                if (trimmed.isEmpty()) return@mapNotNull null
                val separatorIndex = trimmed.indexOf('=')
                if (separatorIndex <= 0) return@mapNotNull null
                com.arix.app.data.McpKeyValue(
                    key = trimmed.substring(0, separatorIndex).trim(),
                    value = trimmed.substring(separatorIndex + 1).trim(),
                )
            }
            .toList()

    private fun parseNonBlankLines(rawValue: String): List<String> =
        rawValue.lineSequence()
            .map(String::trim)
            .filter(String::isNotBlank)
            .toList()

    private fun formatMcpTestOutput(
        operation: McpServerTestOperation,
        outputJson: String,
    ): String {
        val json = runCatching { JSONObject(outputJson) }.getOrNull()
            ?: return outputJson.take(4_000)
        val serverInfo = json.optString("server_info").ifBlank { json.optString("server_name") }
        return when (operation) {
            McpServerTestOperation.ListTools -> formatMcpNamedItems(
                title = "Tools",
                serverInfo = serverInfo,
                items = json.optJSONArray("tools"),
                nameKey = "name",
            )

            McpServerTestOperation.ListResources -> formatMcpNamedItems(
                title = "Resources",
                serverInfo = serverInfo,
                items = json.optJSONArray("resources"),
                nameKey = "uri",
            )

            McpServerTestOperation.ListPrompts -> formatMcpNamedItems(
                title = "Prompts",
                serverInfo = serverInfo,
                items = json.optJSONArray("prompts"),
                nameKey = "name",
            )
        }
    }

    private fun formatMcpNamedItems(
        title: String,
        serverInfo: String,
        items: JSONArray?,
        nameKey: String,
    ): String {
        val count = items?.length() ?: 0
        return buildString {
            append(title)
            append(": ")
            append(count)
            if (serverInfo.isNotBlank()) {
                append(" on ")
                append(serverInfo)
            }
            if (count > 0 && items != null) {
                appendLine()
                val visibleCount = minOf(count, 8)
                for (index in 0 until visibleCount) {
                    val item = items.optJSONObject(index) ?: continue
                    val name = item.optString(nameKey)
                        .ifBlank { item.optString("name") }
                    val description = item.optString("description")
                    append("- ")
                    append(name)
                    if (description.isNotBlank()) {
                        append(": ")
                        append(description.take(160))
                    }
                    appendLine()
                }
                if (count > visibleCount) {
                    append("... and ")
                    append(count - visibleCount)
                    append(" more")
                }
            }
        }.trim()
    }

    private fun performSkillInstall(
        onComplete: (Boolean) -> Unit = {},
        installBlock: suspend () -> Result<InstalledSkill>,
    ) {
        viewModelScope.launch {
            val result = installBlock()
            if (result.isSuccess) {
                piKernelBridge.reloadAllExtensions(runtime.piExtensionStateRepository.loadOptions())
            }
            result
                .onSuccess { installedSkill ->
                    emitTransientMessage(uiString(R.string.message_installed_skill, installedSkill.name))
                    captureAnalyticsEvent(
                        event = "skill installed",
                        properties = mapOf(
                            "skill_id" to installedSkill.id,
                            "skill_name" to installedSkill.name,
                        ),
                    )
                }
                .onFailure { throwable ->
                    emitTransientMessage(
                        uiString(R.string.message_install_skill_failed, throwable.userFacingMessage())
                    )
                }
            onComplete(result.isSuccess)
        }
    }

    private fun writeTextToUri(
        uri: Uri,
        text: String,
    ): Boolean = runCatching {
        val resolver = getApplication<Application>().contentResolver
        // Open with "rwt" so the destination is truncated before writing. The default "w"
        // mode only truncates when the document provider declares truncation support, and
        // providers that ignore mode entirely (or stream via FUSE) can otherwise leave the
        // exported file at 0 bytes.
        resolver.openOutputStream(uri, "rwt")?.use { output ->
            output.write(text.toByteArray(Charsets.UTF_8))
            output.flush()
            (output as? FileOutputStream)?.fd?.sync()
        } ?: return false
        true
    }.getOrDefault(false)

    private fun readTextFromUri(uri: Uri): String =
        getApplication<Application>().contentResolver.openInputStream(uri)?.use { input ->
            input.readBytes().toString(Charsets.UTF_8)
        } ?: error("Unable to read the selected file.")

    private fun buildDiagnosticLogText(snapshot: ArixUiState): String = buildString {
        val logcat = readLogcatDump()
        val diagnosticEvents = diagnosticLogger.readEventsText()
        val lastCrash = diagnosticLogger.readLastCrashText()
        appendLine("Arix diagnostic log")
        appendLine("generatedAtMillis=${System.currentTimeMillis()}")
        appendLine("versionName=${BuildConfig.VERSION_NAME}")
        appendLine("versionCode=${BuildConfig.VERSION_CODE}")
        appendLine("debug=${BuildConfig.DEBUG}")
        appendLine("screen=${snapshot.currentScreen}")
        appendLine("currentSessionId=${snapshot.currentSessionId}")
        appendLine("sessionCount=${snapshot.sessions.size}")
        appendLine("runningSessionCount=${snapshot.sessionExecutionStates.values.count { it.isRunning }}")
        appendLine("piProviderId=${snapshot.settings.piProviderId}")
        appendLine("providerConfigCount=${snapshot.providerConfigs.size}")
        appendLine("skillCount=${snapshot.installedSkills.size}")
        appendLine("mcpServerCount=${snapshot.mcpServers.size}")
        appendLine("agentModeAuthorized=${snapshot.agentModeAuthorizationState.isReady}")
        appendLine()
        appendLine("settingsSummary:")
        appendLine(buildSettingsDiagnosticSummary(snapshot).toString(2))
        appendLine()
        appendLine("providerConfigsSummary:")
        appendLine(buildProviderConfigsDiagnosticSummary(snapshot).toString(2))
        appendLine()
        appendLine("mcpServersSummary:")
        appendLine(buildMcpServersDiagnosticSummary(snapshot).toString(2))
        appendLine()
        appendLine("sessionsSummary:")
        appendLine(buildSessionsDiagnosticSummary(snapshot).toString(2))
        appendLine()
        appendLine("lastCrash:")
        appendLine(lastCrash.ifBlank { "No crash breadcrumb recorded." })
        appendLine()
        appendLine("diagnosticEventsJsonl:")
        appendLine(diagnosticEvents.ifBlank { "No diagnostic events recorded." })
        appendLine()
        appendLine("logcatReadStatus:")
        appendLine(logcat.toJson().toString(2))
        appendLine()
        appendLine("logcat:")
        append(logcat.output.ifBlank { logcat.message.ifBlank { "No logcat output." } })
    }

    private fun buildSettingsDiagnosticSummary(snapshot: ArixUiState): JSONObject =
        JSONObject().apply {
            put("piProviderId", snapshot.settings.piProviderId)
            put("modelId", snapshot.settings.modelId)
            put("baseUrl", DiagnosticRedactor.sanitizedBaseUrl(snapshot.settings.baseUrl))
            put("defaultChatModelKey", snapshot.settings.defaultChatModelKey)
            put("defaultTitleModelKey", snapshot.settings.defaultTitleModelKey)
            put("defaultNamingModelKey", snapshot.settings.defaultNamingModelKey)
            put("llmInactivityReconnectTimeoutSeconds", snapshot.settings.llmInactivityReconnectTimeoutSeconds)
            put("keepTasksRunningInBackground", snapshot.settings.keepTasksRunningInBackground)
            put("notifyOnTaskCompletion", snapshot.settings.notifyOnTaskCompletion)
            put("privacyPolicyAccepted", snapshot.settings.privacyPolicyAccepted)
            put("agentMode", JSONObject().apply {
                put("authorizationEnabled", snapshot.settings.agentModeAuthorizationEnabled)
                put("authorizationIssue", snapshot.agentModeAuthorizationState.issue.name)
                put("authorizationReady", snapshot.agentModeAuthorizationState.isReady)
                put("authorizationDetail", snapshot.agentModeAuthorizationState.detail)
                put("displayActive", snapshot.agentModeDisplayState.isActive)
                put("displayId", snapshot.agentModeDisplayState.displayId ?: JSONObject.NULL)
                put("displayStatus", snapshot.agentModeDisplayState.status)
                put("livePreviewActive", snapshot.agentModeDisplayState.isLivePreviewActive)
                put("lastUpdatedMillis", snapshot.agentModeDisplayState.lastUpdatedMillis)
            })
        }

    private fun buildProviderConfigsDiagnosticSummary(snapshot: ArixUiState): JSONArray =
        JSONArray().apply {
            snapshot.providerConfigs.forEach { config ->
                put(
                    JSONObject().apply {
                        put("id", config.id)
                        put("name", config.name)
                        put("piProviderId", config.piProviderId)
                        put("baseUrl", DiagnosticRedactor.sanitizedBaseUrl(config.baseUrl))
                        put("modelId", config.modelId)
                        put("cachedModelCount", config.cachedModels.size)
                        put("enabledModelCount", config.enabledModelIds.size)
                        put("isEnabled", config.isEnabled)
                    }
                )
            }
        }

    private fun buildMcpServersDiagnosticSummary(snapshot: ArixUiState): JSONArray =
        JSONArray().apply {
            snapshot.mcpServers.forEach { server ->
                put(
                    JSONObject().apply {
                        put("id", server.id)
                        put("displayName", server.displayName)
                        put("isEnabled", server.isEnabled)
                        put("transportType", server.transport.transportType.storageValue)
                        put("connectTimeoutMillis", server.connectTimeoutMillis)
                        put("requestTimeoutMillis", server.requestTimeoutMillis)
                        when (val transport = server.transport) {
                            is com.arix.app.data.McpTransportConfig.StdIo -> {
                                put("commandSummary", transport.command.lineSequence().firstOrNull().orEmpty().take(160))
                                put("argumentCount", transport.arguments.size)
                                put("workingDirectory", transport.workingDirectory)
                                put("environmentKeyCount", transport.environment.size)
                            }

                            is com.arix.app.data.McpTransportConfig.StreamableHttp -> {
                                put("url", DiagnosticRedactor.sanitizedBaseUrl(transport.url))
                                put("headerKeyCount", transport.headers.size)
                            }
                        }
                    }
                )
            }
        }

    private fun buildSessionsDiagnosticSummary(snapshot: ArixUiState): JSONObject =
        JSONObject().apply {
            put("currentSessionId", snapshot.currentSessionId)
            put("sessionCount", snapshot.sessions.size)
            put(
                "runningSessions",
                JSONArray().apply {
                    snapshot.sessionExecutionStates.values
                        .filter { it.isRunning }
                        .forEach { state ->
                            put(
                                JSONObject().apply {
                                    put("sessionId", state.sessionId)
                                    put("pendingToolCount", state.pendingToolInvocations.size)
                                    put("pendingInputCount", state.pendingInputs.size)
                                    put("activeTurnStartedAtMillis", state.activeTurnStartedAtMillis ?: JSONObject.NULL)
                                    put("pendingStatusText", state.pendingStatusText)
                                    put("pendingStatusDetail", state.pendingStatusDetail)
                                }
                            )
                        }
                },
            )
            put(
                "recentSessions",
                JSONArray().apply {
                    snapshot.sessions
                        .sortedByDescending { session -> session.lastMessageAtMillis ?: 0L }
                        .take(12)
                        .forEach { session ->
                            put(
                                JSONObject().apply {
                                    put("id", session.id)
                                    put("title", session.title)
                                    put("messageCount", session.messageCount)
                                    put("lastMessageAtMillis", session.lastMessageAtMillis ?: 0L)
                                    put("selectedModelKey", session.selectedModelKey)
                                    put("selectedSkillCount", session.selectedSkillIds.size)
                                    put("activeMcpServerCount", session.activeMcpServerIds.size)
                                    put("agentModeEnabled", session.agentModeEnabled)
                                }
                            )
                        }
                },
            )
        }

    private fun readLogcatDump(): LogcatDump {
        val pid = android.os.Process.myPid().toString()
        val commands = listOf(
            listOf("logcat", "-d", "-v", "threadtime", "-t", "4000", "--pid", pid),
            listOf("logcat", "-d", "-v", "threadtime", "-t", "8000"),
        )

        commands.forEach { command ->
            val dump = runCatching { runLogcatCommand(command) }.getOrElse { throwable ->
                LogcatDump(
                    command = command,
                    success = false,
                    exitCode = null,
                    output = "",
                    message = throwable.message ?: "Unable to run logcat command.",
                )
            }
            if (dump.success && dump.output.isNotBlank()) {
                return dump
            }
        }

        return LogcatDump(
            command = emptyList(),
            success = false,
            exitCode = null,
            output = "",
            message = "Unable to read logcat output.",
        )
    }

    private fun runLogcatCommand(command: List<String>): LogcatDump {
        val process = ProcessBuilder(command)
            .redirectErrorStream(true)
            .start()
        val executor = Executors.newSingleThreadExecutor()
        val outputFuture = executor.submit<String> {
            process.inputStream.bufferedReader(Charsets.UTF_8).use { reader ->
                reader.readText()
            }
        }
        return try {
            if (!process.waitFor(LogcatReadTimeoutSeconds, TimeUnit.SECONDS)) {
                process.destroy()
                LogcatDump(
                    command = command,
                    success = false,
                    exitCode = null,
                    output = runCatching { outputFuture.get(500, TimeUnit.MILLISECONDS) }.getOrDefault(""),
                    message = "Logcat command timed out.",
                )
            } else {
                val output = outputFuture.get(1, TimeUnit.SECONDS)
                val exitCode = process.exitValue()
                LogcatDump(
                    command = command,
                    success = exitCode == 0 && output.isNotBlank(),
                    exitCode = exitCode,
                    output = output,
                    message = when {
                        exitCode != 0 -> "Logcat command exited with code $exitCode."
                        output.isBlank() -> "Logcat command returned no output."
                        else -> ""
                    },
                )
            }
        } finally {
            executor.shutdownNow()
        }
    }

    private suspend fun buildFullAppExportJson(
        snapshot: ArixUiState,
        sessions: List<ChatSession>,
    ): JSONObject {
        val piSessions = JSONArray()
        sessions.forEach { session ->
            runCatching { piKernelBridge.exportSessionJsonl(session.id) }
                .getOrNull()
                ?.let { exported ->
                    val path = exported.optString("exported_path")
                    val jsonl = path.takeIf(String::isNotBlank)
                        ?.let { filePath -> runCatching { java.io.File(filePath).readText(Charsets.UTF_8) }.getOrNull() }
                    piSessions.put(JSONObject().apply {
                        put("sessionId", session.id)
                        put("jsonlPath", path)
                        put("jsonl", jsonl ?: "")
                    })
                }
        }
        return JSONObject().apply {
            put("schemaVersion", 3)
            put("exportType", "app")
            put("exportedAtMillis", System.currentTimeMillis())
            put("settings", snapshot.settings.toJson())
            put("providerConfigs", JSONArray(serializeProviderConfigs(snapshot.providerConfigs)))
            put("sessions", JSONArray(serializeChatSessions(sessions.map { it.copy(activeSkills = emptyList()) })))
            put("currentSessionId", snapshot.currentSessionId)
            put("skillBundles", skillManager.exportSkillBundles(snapshot.installedSkills))
            put("mcpServers", JSONArray(serializeMcpServerConfigs(snapshot.mcpServers)))
            put("piSessions", piSessions)
            put("extensionArchive", piExtensionManager.exportArchive())
        }
    }

    private fun parseFullAppImport(
        json: JSONObject,
        installedSkills: List<InstalledSkill>,
    ): ImportedAppData {
        val mcpServers = parseMcpServerConfigs(json.optJSONArray("mcpServers")?.toString().orEmpty())
        val sessions = sanitizeImportedSessions(
            sessions = parseChatSessions(json.optJSONArray("sessions")?.toString().orEmpty()),
            installedSkillIds = installedSkills.map { it.id }.toSet(),
            mcpServerIds = mcpServers.map(McpServerConfig::id).toSet(),
        )
        val piSessions = buildMap {
            val entries = json.optJSONArray("piSessions") ?: JSONArray()
            for (index in 0 until entries.length()) {
                val item = entries.optJSONObject(index) ?: continue
                val id = item.optString("sessionId").trim()
                val jsonl = item.optString("jsonl")
                if (id.isNotBlank() && jsonl.isNotBlank()) put(id, jsonl)
            }
        }
        return ImportedAppData(
            settings = parseImportedSettings(json.optJSONObject("settings")),
            providerConfigs = parseProviderConfigs(json.optJSONArray("providerConfigs")?.toString().orEmpty()),
            sessions = sessions,
            currentSessionId = json.optString("currentSessionId")
                .takeIf { id -> id == DraftSessionId || sessions.any { it.id == id } }
                ?: DraftSessionId,
            installedSkills = installedSkills,
            mcpServers = mcpServers,
            piSessions = piSessions,
        )
    }

    private fun sanitizeImportedSessions(
        sessions: List<ChatSession>,
        installedSkillIds: Set<String>,
        mcpServerIds: Set<String>,
    ): List<ChatSession> =
        sessions.map { session ->
            session.copy(
                selectedSkillIds = session.selectedSkillIds.filter(installedSkillIds::contains),
                activeSkills = emptyList(),
                activeMcpServerIds = session.activeMcpServerIds.filter(mcpServerIds::contains),
            )
        }

    private fun AppSettings.toJson(): JSONObject = JSONObject().apply {
        put("piProviderId", piProviderId)
        put("providerConfigId", providerConfigId)
        put("providerAuthMethod", providerAuthMethod.storageValue)
        put("apiKey", apiKey)
        put("oauthCredentialJson", oauthCredentialJson)
        put(
            "providerEnvironmentVariables",
            JSONArray().apply {
                providerEnvironmentVariables.forEach { variable ->
                    put(
                        JSONObject()
                            .put("name", variable.name)
                            .put("value", variable.value)
                    )
                }
            },
        )
        put("baseUrl", baseUrl)
        put("modelId", modelId)
        put("userAgent", normalizeLlmUserAgent(userAgent))
        put("customHeaders", customHeaders.toJsonArray())
        put("reasoningEffort", reasoningEffort)
        put("systemPrompt", systemPrompt)
        put("llmInactivityReconnectTimeoutSeconds", llmInactivityReconnectTimeoutSeconds)
        put("keepTasksRunningInBackground", keepTasksRunningInBackground)
        put("notifyOnTaskCompletion", notifyOnTaskCompletion)
        put("agentWorkspaceMode", agentWorkspaceMode.storageValue)
        put("enabledRuntimeIds", JSONArray().apply { enabledRuntimeIds.forEach { put(it.storageValue) } })
        put("defaultRuntimeId", defaultRuntimeId?.storageValue ?: JSONObject.NULL)
        put("alpineSetupCompleted", alpineSetupCompleted)
        put(
            "alpinePackageProfiles",
            JSONArray().apply {
                alpinePackageProfiles.values.forEach { profile ->
                    put(
                        JSONObject().apply {
                            put("profileId", profile.profileId)
                            put("installed", profile.installed)
                            put("installedAtMillis", profile.installedAtMillis)
                            put("lastError", profile.lastError)
                        }
                    )
                }
            },
        )
        put(
            "alpineEnvironmentVariables",
            JSONArray().apply {
                alpineEnvironmentVariables.forEach { variable ->
                    put(JSONObject().put("name", variable.name).put("value", variable.value))
                }
            },
        )
        put("autoCleanOldCommandHistory", autoCleanOldCommandHistory)
        put("oldCommandHistoryRetentionHours", oldCommandHistoryRetentionHours)
        put("agentModeAuthorizationEnabled", agentModeAuthorizationEnabled)
        put("language", language.storageValue)
        put("themeMode", themeMode.storageValue)
        put("defaultChatModelKey", defaultChatModelKey)
        put("defaultTitleModelKey", defaultTitleModelKey)
        put("defaultNamingModelKey", defaultNamingModelKey)
        put("defaultCompactingModelKey", defaultCompactingModelKey)
        put("defaultSelectedSkillIds", JSONArray(defaultSelectedSkillIds))
        put("onboardingSeenVersion", onboardingSeenVersion)
        put("onboardingCompletedVersion", onboardingCompletedVersion)
        put("privacyPolicyAccepted", privacyPolicyAccepted)
        put("lastUpdateCheckAtMillis", lastUpdateCheckAtMillis)
    }

    private fun parseImportedSettings(json: JSONObject?): AppSettings {
        if (json == null) return AppSettings()
        val defaults = AppSettings()
        val importedBaseUrl = json.optString("baseUrl", defaults.baseUrl)
        val importedPiProviderId = json.optString("piProviderId").trim().ifBlank {
            com.arix.app.data.inferLegacyPiProviderId(
                json.optString("provider"),
                importedBaseUrl,
            )
        }
        return AppSettings(
            piProviderId = importedPiProviderId,
            providerConfigId = json.optString("providerConfigId"),
            providerAuthMethod = com.arix.app.data.ProviderAuthMethod.fromStorage(
                json.optString("providerAuthMethod"),
            ),
            apiKey = json.optString("apiKey", defaults.apiKey),
            oauthCredentialJson = json.optString(
                "oauthCredentialJson",
                defaults.oauthCredentialJson,
            ),
            providerEnvironmentVariables = com.arix.app.data
                .parseProviderEnvironmentVariables(
                    json.optJSONArray("providerEnvironmentVariables"),
                ),
            baseUrl = importedBaseUrl,
            modelId = json.optString("modelId", defaults.modelId),
            userAgent = normalizeLlmUserAgent(json.optString("userAgent", defaults.userAgent)),
            customHeaders = parseCustomHeaders(json.optJSONArray("customHeaders")),
            reasoningEffort = normalizeReasoningEffort(
                json.optString("reasoningEffort", defaults.reasoningEffort),
            ),
            systemPrompt = json.optString("systemPrompt", defaults.systemPrompt),
            llmInactivityReconnectTimeoutSeconds = normalizeLlmInactivityReconnectTimeoutSeconds(
                json.optInt(
                    "llmInactivityReconnectTimeoutSeconds",
                    defaults.llmInactivityReconnectTimeoutSeconds,
                )
            ),
            keepTasksRunningInBackground = json.optBoolean(
                "keepTasksRunningInBackground",
                defaults.keepTasksRunningInBackground,
            ),
            notifyOnTaskCompletion = json.optBoolean(
                "notifyOnTaskCompletion",
                defaults.notifyOnTaskCompletion,
            ),
            agentWorkspaceMode = AgentWorkspaceMode.fromStorage(
                json.optString("agentWorkspaceMode", defaults.agentWorkspaceMode.storageValue),
            ),
            autoCleanOldCommandHistory = json.optBoolean(
                "autoCleanOldCommandHistory",
                defaults.autoCleanOldCommandHistory,
            ),
            oldCommandHistoryRetentionHours = normalizeOldCommandHistoryRetentionHours(
                json.optInt(
                    "oldCommandHistoryRetentionHours",
                    defaults.oldCommandHistoryRetentionHours,
                )
            ),
            enabledRuntimeIds = parseImportedRuntimeIds(json.optJSONArray("enabledRuntimeIds")),
            defaultRuntimeId = LocalRuntimeId.fromStorage(json.optString("defaultRuntimeId")),
            alpineSetupCompleted = json.optBoolean(
                "alpineSetupCompleted",
                defaults.alpineSetupCompleted,
            ),
            alpinePackageProfiles = parseImportedPackageProfileStates(
                json.optJSONArray("alpinePackageProfiles")
            ),
            alpineEnvironmentVariables = parseImportedAlpineEnvironmentVariables(
                json.optJSONArray("alpineEnvironmentVariables")
            ),
            agentModeAuthorizationEnabled = json.optBoolean(
                "agentModeAuthorizationEnabled",
                defaults.agentModeAuthorizationEnabled,
            ),
            language = AppLanguage.fromStorage(
                json.optString("language"),
                defaults.language,
            ),
            themeMode = AppThemeMode.fromStorage(json.optString("themeMode")),
            defaultChatModelKey = json.optString("defaultChatModelKey", defaults.defaultChatModelKey),
            defaultTitleModelKey = json.optString("defaultTitleModelKey", defaults.defaultTitleModelKey),
            defaultNamingModelKey = json.optString("defaultNamingModelKey", defaults.defaultNamingModelKey),
            defaultCompactingModelKey = json.optString(
                "defaultCompactingModelKey",
                defaults.defaultCompactingModelKey,
            ),
            defaultSelectedSkillIds = json.optJSONArray("defaultSelectedSkillIds").toStringList(),
            onboardingSeenVersion = json.optInt("onboardingSeenVersion", defaults.onboardingSeenVersion),
            onboardingCompletedVersion = json.optInt(
                "onboardingCompletedVersion",
                defaults.onboardingCompletedVersion,
            ),
            privacyPolicyAccepted = json.optBoolean(
                "privacyPolicyAccepted",
                defaults.privacyPolicyAccepted,
            ),
            lastUpdateCheckAtMillis = json.optLong(
                "lastUpdateCheckAtMillis",
                defaults.lastUpdateCheckAtMillis,
            ),
        )
    }

    private fun parseImportedStringArray(array: JSONArray?): List<String> {
        if (array == null) return emptyList()
        return buildList {
            for (index in 0 until array.length()) {
                val value = array.optString(index).trim()
                if (value.isNotEmpty()) {
                    add(value)
                }
            }
        }.distinct()
    }

    private fun parseImportedAlpineEnvironmentVariables(
        array: JSONArray?,
    ): List<AlpineEnvironmentVariable> {
        if (array == null) return emptyList()
        return normalizeAlpineEnvironmentVariables(
            buildList {
                for (index in 0 until array.length()) {
                    val item = array.optJSONObject(index) ?: continue
                    add(
                        AlpineEnvironmentVariable(
                            name = item.optString("name"),
                            value = item.optString("value"),
                        )
                    )
                }
            }
        )
    }

    private fun parseImportedRuntimeIds(array: JSONArray?): Set<LocalRuntimeId> {
        if (array == null) return emptySet()
        return buildSet {
            for (index in 0 until array.length()) {
                LocalRuntimeId.fromStorage(array.optString(index))?.let(::add)
            }
        }
    }

    private fun parseImportedPackageProfileStates(
        array: JSONArray?,
    ): Map<String, PackageProfileState> {
        if (array == null) return emptyMap()
        return buildMap {
            for (index in 0 until array.length()) {
                val item = array.optJSONObject(index) ?: continue
                val profileId = item.optString("profileId").trim()
                if (profileId.isBlank()) continue
                put(
                    profileId,
                    PackageProfileState(
                        profileId = profileId,
                        installed = item.optBoolean("installed", false),
                        installedAtMillis = item.optLong("installedAtMillis", 0L),
                        lastError = item.optString("lastError"),
                    )
                )
            }
        }
    }

    private fun emitTransientMessage(message: UiText) {
        _transientMessages.tryEmit(message)
    }

    private fun uiString(resId: Int, vararg formatArgs: Any): UiText =
        UiText.Resource(resId, formatArgs.toList())

    private fun Throwable.userFacingMessage(): String =
        message?.trim().takeUnless { it.isNullOrBlank() } ?: javaClass.simpleName

    private data class SessionMetadata(
        val title: String,
        val preview: String,
    )

    private data class AttachmentMetadata(
        val displayName: String,
        val mimeType: String,
        val sizeBytes: Long?,
        val kind: AttachmentKind,
    )

    private data class LogcatDump(
        val command: List<String>,
        val success: Boolean,
        val exitCode: Int?,
        val output: String,
        val message: String,
    ) {
        fun toJson(): JSONObject = JSONObject().apply {
            put("command", command.joinToString(" "))
            put("success", success)
            put("exitCode", exitCode ?: JSONObject.NULL)
            put("lineCount", output.lineSequence().count())
            put("message", message)
        }
    }

    private data class ImportedAppData(
        val settings: AppSettings,
        val providerConfigs: List<LlmProviderConfig>,
        val sessions: List<ChatSession>,
        val currentSessionId: String,
        val installedSkills: List<InstalledSkill>,
        val mcpServers: List<McpServerConfig>,
        val piSessions: Map<String, String> = emptyMap(),
    )
}

internal fun ArixUiState.withFinalizedPausedSession(
    finalizedSession: ChatSession,
    executionStates: Map<String, SessionExecutionState>,
): ArixUiState {
    val currentExecution = executionStates[currentSessionId]
    val updatedSessions = if (sessions.any { it.id == finalizedSession.id }) {
        sessions.map { if (it.id == finalizedSession.id) finalizedSession else it }
    } else {
        listOf(finalizedSession) + sessions
    }
    return copy(
        sessions = updatedSessions,
        sessionExecutionStates = executionStates,
        isSending = currentExecution?.isRunning == true,
        pendingResponseSessionId = currentExecution?.sessionId,
        pendingToolInvocations = currentExecution?.pendingToolInvocations.orEmpty(),
        pendingResponseBlocks = currentExecution?.pendingResponseBlocks.orEmpty(),
        pendingAssistantText = currentExecution?.pendingAssistantText.orEmpty(),
        pendingStatusText = currentExecution?.pendingStatusText.orEmpty(),
        pendingStatusDetail = currentExecution?.pendingStatusDetail.orEmpty(),
    )
}

private fun ArixUiState.isAgentModeReady(): Boolean =
    settings.agentModeAuthorizationEnabled &&
        agentModeAuthorizationState.isReady

private fun AppSettings.withRuntimeEnabled(
    runtimeId: LocalRuntimeId,
    makeDefault: Boolean = defaultRuntimeId == null,
): AppSettings {
    val enabled = enabledRuntimeIds + runtimeId
    return copy(
        alpineSetupCompleted = alpineSetupCompleted || runtimeId == LocalRuntimeId.Alpine,
        enabledRuntimeIds = enabled,
        defaultRuntimeId = if (makeDefault) runtimeId else defaultRuntimeId,
    )
}

private fun JSONArray?.toStringList(): List<String> {
    if (this == null) return emptyList()
    return buildList {
        for (index in 0 until length()) {
            optString(index).trim().takeIf(String::isNotBlank)?.let(::add)
        }
    }.distinct()
}
