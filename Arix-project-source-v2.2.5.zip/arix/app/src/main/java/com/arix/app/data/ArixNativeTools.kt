package com.arix.app.data

import android.graphics.Bitmap
import android.graphics.Color
import java.io.ByteArrayOutputStream

/**
 * Client-side intent detection for the instant native tools (Movie Explorer
 * and QR Generator). When the user's message clearly asks for a movie list /
 * search / playback or a QR code, the app runs the tool natively and renders
 * the in-chat widget IMMEDIATELY — no LLM round-trip, no raw URLs, no delay.
 */
sealed interface ArixNativeIntent {
    val toolName: String

    data class MovieList(val page: Int) : ArixNativeIntent {
        override val toolName: String = "movie_explorer"
    }

    data class MovieSearch(val query: String) : ArixNativeIntent {
        override val toolName: String = "movie_explorer"
    }

    data class MoviePlayUrl(val url: String) : ArixNativeIntent {
        override val toolName: String = "movie_explorer"
    }

    data class MoviePlayTitle(val title: String) : ArixNativeIntent {
        override val toolName: String = "movie_explorer"
    }

    data class QrCode(val data: String) : ArixNativeIntent {
        override val toolName: String = "qr_code"
    }

    companion object {
        private val movieWord = Regex("\\b(movies?|films?)\\b", RegexOption.IGNORE_CASE)
        private val latestWord = Regex("\\b(latest|new(est)?|recent|trending|now playing|just added)\\b", RegexOption.IGNORE_CASE)
        private val searchVerb = Regex("\\b(search|find|look\\s+(for|up))\\b", RegexOption.IGNORE_CASE)
        private val playVerb = Regex("\\b(play|watch|stream|open|show\\s+me)\\b", RegexOption.IGNORE_CASE)
        private val urlPattern = Regex("https?://\\S+", RegexOption.IGNORE_CASE)
        private val qrWord = Regex("\\b(qr|qrcode|qr[- ]?codes?)\\b", RegexOption.IGNORE_CASE)
        private val qrImperative = Regex(
            "^\\s*(please\\s+)?(can\\s+you\\s+)?(create|make|generate|give|get|show|draw|build|scan)\\s+" +
                "(me\\s+)?(a\\s+|an\\s+|the\\s+)?(qr(\\s?code)?|qrcode)\\b[\\s,:\\-\u2013]*",
            RegexOption.IGNORE_CASE,
        )
        private val qrDirect = Regex(
            "^\\s*(qr(\\s?code)?|qrcode)\\s*[:\\-\u2013]\\s*",
            RegexOption.IGNORE_CASE,
        )

        /** Returns the matched native intent, or null when the message should
         *  go to the LLM as a normal conversation turn. */
        fun match(text: String): ArixNativeIntent? {
            val value = text.trim()
            if (value.isEmpty()) return null

            qrMatch(value)?.let { return it }
            return movieMatch(value)
        }

        private fun qrMatch(value: String): QrCode? {
            if (!qrWord.containsMatchIn(value)) return null
            // Only true QR commands: an imperative ("create a qr for X") or a
            // direct payload form ("QR code: X"). Questions about QR codes in
            // general stay with the LLM.
            val stripped = when {
                qrImperative.containsMatchIn(value) -> qrImperative.replace(value, "")
                    .replace(Regex("^(for|of|with|containing|to)\\s+", RegexOption.IGNORE_CASE), "")
                qrDirect.containsMatchIn(value) -> qrDirect.replace(value, "")
                    .replace(Regex("^(for|of|with)\\s+", RegexOption.IGNORE_CASE), "")
                else -> return null
            }
            var payload = stripped.trim()
            // Trailing filler like "please" / "thanks"
            payload = payload.replace(Regex("[.!?\\s]+$", RegexOption.IGNORE_CASE), "").trim()
            // Strip wrapping quotes
            if (payload.length >= 2 &&
                ((payload.startsWith("\"") && payload.endsWith("\"")) ||
                    (payload.startsWith("'") && payload.endsWith("'")))
            ) {
                payload = payload.substring(1, payload.length - 1).trim()
            }
            if (payload.isBlank()) return null
            if (payload.toByteArray(Charsets.UTF_8).size > 2300) return null
            return QrCode(payload)
        }

        private fun movieMatch(value: String): ArixNativeIntent? {
            val lower = value.lowercase()
            val url = urlPattern.find(value)?.value
            val hasMovieWord = movieWord.containsMatchIn(value)

            // "next page" / "page 2" style follow-ups
            val pageMatch = Regex("\\bpage\\s*(\\d{1,2})\\b").find(lower)
            if (hasMovieWord && (pageMatch != null || Regex("\\b(more|next)\\b").containsMatchIn(lower))) {
                val page = pageMatch?.groupValues?.get(1)?.toIntOrNull()?.coerceIn(1, 20) ?: 2
                return MovieList(page)
            }
            if (!hasMovieWord) return null

            // An explicit URL in a play/watch message wins
            if (url != null && playVerb.containsMatchIn(value)) {
                return MoviePlayUrl(url)
            }

            val searchHit = searchVerb.find(value)
            val playHit = playVerb.find(value)
            val titleFrom = (searchHit ?: playHit)?.range?.last?.plus(1) ?: -1
            val title = if (titleFrom in 1..value.length) {
                value.substring(titleFrom)
                    .replace(Regex("\\b(movies?|films?|movie|film)\\b", RegexOption.IGNORE_CASE), " ")
                    .replace(Regex("^(for|of|about|me)?\\s*", RegexOption.IGNORE_CASE), "")
                    .replace(Regex("[?.!\\s]+$"), "")
                    .trim()
            } else {
                ""
            }

            if (searchHit != null && title.length >= 2) return MovieSearch(title)
            if (playHit != null && title.length >= 2) return MoviePlayTitle(title)

            // Bare "latest movies" / "show new movies"
            if (latestWord.containsMatchIn(value) || Regex("\\b(show|list|browse)\\b", RegexOption.IGNORE_CASE).containsMatchIn(value)) {
                return MovieList(1)
            }
            return null
        }
    }
}

/** Renders a QR matrix to a PNG with a quiet zone — 100% offline and instant. */
object ArixQrPng {
    fun render(
        matrix: ArixQrEncoder.QrMatrix,
        sizePx: Int = 512,
        quietZoneModules: Int = 4,
        darkColor: Int = 0xFF111111.toInt(),
        lightColor: Int = 0xFFFFFFFF.toInt(),
    ): ByteArray {
        val totalModules = matrix.size + quietZoneModules * 2
        val scale = (sizePx / totalModules).coerceAtLeast(1)
        val actualSize = scale * totalModules
        val bitmap = Bitmap.createBitmap(actualSize, actualSize, Bitmap.Config.RGB_565)
        bitmap.eraseColor(lightColor)
        val paint = android.graphics.Paint().apply { color = darkColor }
        val canvas = android.graphics.Canvas(bitmap)
        for (row in 0 until matrix.size) {
            for (col in 0 until matrix.size) {
                if (matrix.isDark(row, col)) {
                    val left = (col + quietZoneModules) * scale
                    val top = (row + quietZoneModules) * scale
                    canvas.drawRect(
                        left.toFloat(),
                        top.toFloat(),
                        (left + scale).toFloat(),
                        (top + scale).toFloat(),
                        paint,
                    )
                }
            }
        }
        val output = ByteArrayOutputStream()
        bitmap.compress(Bitmap.CompressFormat.PNG, 100, output)
        bitmap.recycle()
        return output.toByteArray()
    }

    /** Readable classification used on the generated card (mirrors the extension). */
    fun describeData(data: String): String {
        val value = data.trim()
        return when {
            Regex("^https?://", RegexOption.IGNORE_CASE).containsMatchIn(value) -> "Link"
            Regex("^WIFI:", RegexOption.IGNORE_CASE).containsMatchIn(value) -> "Wi-Fi"
            Regex("^mailto:", RegexOption.IGNORE_CASE).containsMatchIn(value) ||
                Regex("^[^\\s@]+@[^\\s@]+\\.[^\\s@]+$").matches(value) -> "Email"
            Regex("^tel:", RegexOption.IGNORE_CASE).containsMatchIn(value) -> "Phone"
            Regex("^(SMSTO|MECARD|BEGIN:VCARD)", RegexOption.IGNORE_CASE).containsMatchIn(value) -> "Contact"
            Regex("^geo:", RegexOption.IGNORE_CASE).containsMatchIn(value) -> "Location"
            Regex("^\\d+$").matches(value) -> "Number"
            else -> "Text"
        }
    }
}
