package com.arix.app.ui

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.automirrored.rounded.OpenInNew
import androidx.compose.material.icons.rounded.ChevronRight
import androidx.compose.material.icons.rounded.Download
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import com.arix.app.R
import com.arix.app.ui.theme.ArixOnPrimary
import com.arix.app.ui.theme.ArixOnSurface
import com.arix.app.ui.theme.ArixOnSurfaceVariant
import com.arix.app.ui.theme.ArixOutline
import com.arix.app.ui.theme.ArixPrimary
import com.arix.app.ui.theme.ArixSurfaceHigh
import com.arix.app.ui.theme.ArixSurfaceHigher
import java.io.File
import java.util.concurrent.TimeUnit
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject

/**
 * Native in-chat widgets for bundled tool results.
 *
 * The QR Code Generator and Movie Explorer extensions return a structured
 * `output_json` payload with every tool result; these widgets render that
 * payload directly in the conversation (image cards, poster grids, and a
 * multi-server player) without depending on the extension UI runtime.
 */

/* ------------------------------------------------------------------ models */

data class ArixQrWidgetModel(
    val data: String,
    val kind: String,
    val base64: String,
    val size: Int,
    val provider: String,
)

data class ArixMovieItemModel(
    val title: String,
    val url: String,
    val thumbnail: String,
    val views: String,
)

data class ArixMovieServerModel(
    val label: String,
    val url: String,
)

data class ArixMovieDownloadModel(
    val quality: String,
    val label: String,
    val url: String,
)

data class ArixMovieListModel(
    val mode: String,
    val query: String,
    val page: Int,
    val results: List<ArixMovieItemModel>,
)

data class ArixMoviePlayerModel(
    val title: String,
    val description: String,
    val thumbnail: String,
    val url: String,
    val servers: List<ArixMovieServerModel>,
    val downloads: List<ArixMovieDownloadModel>,
)

/** Parsed widget payload from a tool invocation's structured output. */
sealed interface ArixToolWidgetPayload {
    data class Qr(val model: ArixQrWidgetModel) : ArixToolWidgetPayload
    data class MovieList(val model: ArixMovieListModel) : ArixToolWidgetPayload
    data class MoviePlayer(val model: ArixMoviePlayerModel) : ArixToolWidgetPayload
}

internal fun parseArixToolWidgetPayload(outputJson: String): ArixToolWidgetPayload? {
    if (outputJson.isBlank()) return null
    val output = runCatching { JSONObject(outputJson) }.getOrNull() ?: return null
    return when (output.optString("widget")) {
        "qr_code" -> {
            val base64 = output.optString("base64")
            if (base64.isBlank()) return null
            ArixToolWidgetPayload.Qr(
                ArixQrWidgetModel(
                    data = output.optString("data"),
                    kind = output.optString("kind").ifBlank { "Text" },
                    base64 = base64,
                    size = output.optInt("size", 300),
                    provider = output.optString("provider"),
                ),
            )
        }

        "movie_list" -> {
            val results = output.optJSONArray("results") ?: return null
            val items = buildList {
                for (index in 0 until results.length()) {
                    val entry = results.optJSONObject(index) ?: continue
                    val title = entry.optString("title")
                    val url = entry.optString("url")
                    if (title.isBlank() || url.isBlank()) continue
                    add(
                        ArixMovieItemModel(
                            title = title,
                            url = url,
                            thumbnail = entry.optString("thumbnail"),
                            views = entry.optString("views"),
                        ),
                    )
                }
            }
            if (items.isEmpty()) return null
            ArixToolWidgetPayload.MovieList(
                ArixMovieListModel(
                    mode = output.optString("mode", "latest"),
                    query = output.optString("query"),
                    page = output.optInt("page", 1),
                    results = items,
                ),
            )
        }

        "movie_player" -> {
            val servers = buildList {
                val array = output.optJSONArray("servers")
                if (array != null) {
                    for (index in 0 until array.length()) {
                        val entry = array.optJSONObject(index) ?: continue
                        val url = entry.optString("url")
                        if (url.startsWith("http")) {
                            add(ArixMovieServerModel(entry.optString("label").ifBlank { "Player ${index + 1}" }, url))
                        }
                    }
                }
            }
            val downloads = buildList {
                val array = output.optJSONArray("downloads")
                if (array != null) {
                    for (index in 0 until array.length()) {
                        val entry = array.optJSONObject(index) ?: continue
                        val url = entry.optString("url")
                        if (url.startsWith("http")) {
                            add(
                                ArixMovieDownloadModel(
                                    quality = entry.optString("quality"),
                                    label = entry.optString("label").ifBlank { "Download ${index + 1}" },
                                    url = url,
                                ),
                            )
                        }
                    }
                }
            }
            ArixToolWidgetPayload.MoviePlayer(
                ArixMoviePlayerModel(
                    title = output.optString("title"),
                    description = output.optString("description"),
                    thumbnail = output.optString("thumbnail"),
                    url = output.optString("url"),
                    servers = servers,
                    downloads = downloads,
                ),
            )
        }

        else -> null
    }
}

private fun Modifier.widgetNoRippleClickable(onClick: () -> Unit): Modifier = composed {
    clickable(
        enabled = true,
        indication = null,
        interactionSource = remember { MutableInteractionSource() },
        onClick = onClick,
    )
}

/* ----------------------------------------------------------------- widgets */

/** Renders the native widget for a completed tool invocation, when present. */
@Composable
fun ArixToolResultWidget(
    toolName: String,
    outputJson: String,
    modifier: Modifier = Modifier,
) {
    val payload = remember(toolName, outputJson) {
        if (toolName == "qr_code" || toolName == "movie_explorer") {
            parseArixToolWidgetPayload(outputJson)
        } else {
            null
        }
    }
    when (payload) {
        is ArixToolWidgetPayload.Qr -> QrCodeWidget(payload.model, modifier)
        is ArixToolWidgetPayload.MovieList -> MovieListWidget(payload.model, modifier)
        is ArixToolWidgetPayload.MoviePlayer -> MoviePlayerWidget(payload.model, modifier)
        null -> Unit
    }
}

@Composable
private fun QrCodeWidget(
    model: ArixQrWidgetModel,
    modifier: Modifier = Modifier,
) {
    val context = LocalContext.current
    val bitmap = remember(model.base64) {
        runCatching {
            val bytes = android.util.Base64.decode(model.base64, android.util.Base64.DEFAULT)
            BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
        }.getOrNull()
    }
    var saving by remember { mutableStateOf(false) }
    var sharing by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    val downloadLabel = stringResource(R.string.widget_qr_download)
    val shareLabel = stringResource(R.string.widget_qr_share)
    val savedLabel = stringResource(R.string.widget_qr_saved)
    val failedLabel = stringResource(R.string.widget_qr_download_failed)
    val shareFailedLabel = stringResource(R.string.widget_qr_share_failed)

    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .background(ArixSurfaceHigh)
            .border(1.dp, ArixOutline.copy(alpha = 0.6f), RoundedCornerShape(18.dp))
            .padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            bitmap?.let {
                Image(
                    bitmap = it.asImageBitmap(),
                    contentDescription = stringResource(R.string.widget_qr_image_description),
                    modifier = Modifier
                        .size(148.dp)
                        .clip(RoundedCornerShape(14.dp))
                        .background(androidx.compose.ui.graphics.Color.White)
                        .padding(6.dp),
                    contentScale = ContentScale.Fit,
                )
            }
            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(4.dp),
            ) {
                Text(
                    text = model.data,
                    style = MaterialTheme.typography.bodyMedium,
                    color = ArixOnSurface,
                    maxLines = 3,
                    overflow = TextOverflow.Ellipsis,
                    fontWeight = FontWeight.Medium,
                )
                Text(
                    text = model.kind,
                    style = MaterialTheme.typography.labelMedium,
                    color = ArixPrimary,
                )
                Text(
                    text = "${model.size}×${model.size} · ${model.provider}",
                    style = MaterialTheme.typography.labelSmall,
                    color = ArixOnSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }
        }
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            ArixWidgetActionButton(
                label = downloadLabel,
                icon = Icons.Rounded.Download,
                primary = true,
                enabled = !saving && bitmap != null,
                modifier = Modifier.weight(1f),
            ) {
                saving = true
                scope.launch {
                    val result = withContext(Dispatchers.IO) {
                        runCatching {
                            val bytes = android.util.Base64.decode(model.base64, android.util.Base64.DEFAULT)
                            ArixMediaDownloads.saveToDownloads(
                                context = context,
                                displayName = "qr-code-${System.currentTimeMillis()}.png",
                                mimeType = "image/png",
                                bytes = bytes,
                            )
                        }
                    }
                    saving = false
                    val message = if (result.isSuccess) savedLabel else failedLabel
                    android.widget.Toast.makeText(context, message, android.widget.Toast.LENGTH_SHORT).show()
                }
            }
            ArixWidgetActionButton(
                label = shareLabel,
                icon = Icons.Rounded.Share,
                primary = false,
                enabled = !sharing && bitmap != null,
                modifier = Modifier.weight(1f),
            ) {
                sharing = true
                scope.launch {
                    val ok = withContext(Dispatchers.IO) {
                        ArixQrShare.sharePng(
                            context = context,
                            bytes = android.util.Base64.decode(model.base64, android.util.Base64.DEFAULT),
                        )
                    }
                    sharing = false
                    if (!ok) {
                        android.widget.Toast.makeText(context, shareFailedLabel, android.widget.Toast.LENGTH_SHORT).show()
                    }
                }
            }
        }
    }
}

@Composable
private fun ArixWidgetActionButton(
    label: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    primary: Boolean,
    enabled: Boolean = true,
    modifier: Modifier = Modifier,
    onClick: () -> Unit,
) {
    val container = if (primary) ArixPrimary else ArixSurfaceHigher
    val content = if (primary) ArixOnPrimary else ArixOnSurface
    Row(
        modifier = modifier
            .clip(RoundedCornerShape(12.dp))
            .background(if (enabled) container else ArixSurfaceHigher)
            .padding(horizontal = 14.dp, vertical = 10.dp)
            .let { if (enabled) it.widgetNoRippleClickable(onClick = onClick) else it },
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            modifier = Modifier.size(18.dp),
            tint = if (enabled) content else ArixOnSurfaceVariant,
        )
        Text(
            text = label,
            style = MaterialTheme.typography.labelLarge,
            color = if (enabled) content else ArixOnSurfaceVariant,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
        )
    }
}

/** Loads a remote image into an [ImageBitmap] with a small OkHttp client. */
@Composable
private fun rememberRemoteImage(url: String): ImageBitmap? {
    return produceState<ImageBitmap?>(initialValue = null, url) {
        if (url.isBlank()) return@produceState
        value = withContext(Dispatchers.IO) {
            runCatching {
                val request = Request.Builder()
                    .url(url)
                    .header("User-Agent", MovieSiteClient.BrowserUserAgent)
                    .header("Accept", "image/*,*/*;q=0.8")
                    .build()
                MovieSiteClient.httpClient.newCall(request).execute().use { response ->
                    if (!response.isSuccessful) return@runCatching null
                    val bytes = response.body?.byteStream()?.use { it.readBytes() } ?: return@runCatching null
                    if (bytes.size > 8 * 1024 * 1024) return@runCatching null
                    BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
                }
            }.getOrNull()?.asImageBitmap()
        }
    }.value
}

@Composable
private fun MoviePosterCard(
    item: ArixMovieItemModel,
    cardWidth: androidx.compose.ui.unit.Dp,
    onPlay: () -> Unit,
) {
    val poster = rememberRemoteImage(item.thumbnail)
    Column(
        modifier = Modifier
            .width(cardWidth)
            .clip(RoundedCornerShape(14.dp))
            .background(ArixSurfaceHigher)
            .padding(6.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .aspectRatio(0.68f)
                .clip(RoundedCornerShape(10.dp))
                .background(ArixSurfaceHigh),
            contentAlignment = Alignment.Center,
        ) {
            if (poster != null) {
                Image(
                    bitmap = poster,
                    contentDescription = item.title,
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop,
                )
            } else {
                CircularProgressIndicator(
                    modifier = Modifier.size(22.dp),
                    strokeWidth = 2.dp,
                    color = ArixPrimary,
                )
            }
        }
        Text(
            text = item.title,
            style = MaterialTheme.typography.labelSmall,
            color = ArixOnSurface,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.padding(horizontal = 2.dp),
        )
        ArixWidgetActionButton(
            label = stringResource(R.string.widget_movie_play),
            icon = Icons.Rounded.PlayArrow,
            primary = true,
            modifier = Modifier.fillMaxWidth(),
            onClick = onPlay,
        )
    }
}

@Composable
private fun MovieListWidget(
    model: ArixMovieListModel,
    modifier: Modifier = Modifier,
) {
    // When the user taps Play on a poster, the widget resolves that movie's
    // servers natively (proxied fetch, no agent round-trip) and swaps the
    // rail for the player. Back returns to the rail.
    var playingUrl by remember(model) { mutableStateOf<String?>(null) }
    var loadingUrl by remember(model) { mutableStateOf<String?>(null) }
    var playerModel by remember(model) { mutableStateOf<ArixMoviePlayerModel?>(null) }
    var playError by remember(model) { mutableStateOf("") }
    val scope = rememberCoroutineScope()

    playingUrl?.let { url ->
        val loaded = playerModel
        if (loaded != null && loadingUrl == null) {
            MoviePlayerWidget(loaded, modifier) { playingUrl = null }
            return
        }
    }

    val header = if (model.mode == "search") {
        stringResource(R.string.widget_movie_search_results, model.query, model.results.size)
    } else {
        stringResource(R.string.widget_movie_latest_results, model.results.size)
    }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .background(ArixSurfaceHigh)
            .border(1.dp, ArixOutline.copy(alpha = 0.6f), RoundedCornerShape(18.dp))
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(
                text = header,
                style = MaterialTheme.typography.labelLarge,
                color = ArixOnSurface,
                fontWeight = FontWeight.SemiBold,
                modifier = Modifier.weight(1f),
            )
            Icon(
                imageVector = Icons.Rounded.ChevronRight,
                contentDescription = null,
                modifier = Modifier.size(18.dp),
                tint = ArixOnSurfaceVariant,
            )
        }
        if (loadingUrl != null || playError.isNotBlank()) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                if (loadingUrl != null) {
                    CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp, color = ArixPrimary)
                    Text(
                        text = stringResource(R.string.widget_movie_resolving),
                        style = MaterialTheme.typography.bodySmall,
                        color = ArixOnSurfaceVariant,
                    )
                } else if (playError.isNotBlank()) {
                    Text(
                        text = playError,
                        style = MaterialTheme.typography.bodySmall,
                        color = androidx.compose.ui.graphics.Color(0xFFE5757A),
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f),
                    )
                }
            }
        }
        // Horizontal poster rail — scrolls sideways independently of the
        // chat list, which fixes the "scrolling moves the chat" conflict.
        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            modifier = Modifier.fillMaxWidth(),
        ) {
            items(
                model.results,
                key = { item -> item.url },
            ) { item ->
                MoviePosterCard(item, cardWidth = 122.dp) {
                    playError = ""
                    loadingUrl = item.url
                    scope.launch {
                        val detail = withContext(Dispatchers.IO) {
                            runCatching { MovieSiteClient.fetchDetail(item.url) }.getOrNull()
                        }
                        loadingUrl = null
                        if (detail != null) {
                            playerModel = detail
                            playingUrl = item.url
                        } else {
                            playError = "Could not resolve the servers for \"${item.title.take(40)}\"."
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun MoviePlayerWidget(
    model: ArixMoviePlayerModel,
    modifier: Modifier = Modifier,
    onBack: (() -> Unit)? = null,
) {
    val context = LocalContext.current
    var selectedServer by remember(model.url) { mutableStateOf(model.servers.firstOrNull()) }
    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .background(ArixSurfaceHigh)
            .border(1.dp, ArixOutline.copy(alpha = 0.6f), RoundedCornerShape(18.dp))
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            if (onBack != null) {
                Icon(
                    imageVector = Icons.AutoMirrored.Rounded.ArrowBack,
                    contentDescription = stringResource(R.string.widget_movie_back),
                    modifier = Modifier
                        .size(28.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .widgetNoRippleClickable(onClick = onBack)
                        .padding(3.dp),
                    tint = ArixOnSurfaceVariant,
                )
            }
            Text(
                text = model.title.ifBlank { stringResource(R.string.widget_movie_unknown_title) },
                style = MaterialTheme.typography.titleSmall,
                color = ArixOnSurface,
                fontWeight = FontWeight.SemiBold,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.weight(1f),
            )
        }
        if (model.description.isNotBlank()) {
            Text(
                text = model.description,
                style = MaterialTheme.typography.bodySmall,
                color = ArixOnSurfaceVariant,
                maxLines = 3,
                overflow = TextOverflow.Ellipsis,
            )
        }
        // Server chips
        if (model.servers.size > 1) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                model.servers.forEachIndexed { index, server ->
                    val selected = server == selectedServer
                    Text(
                        text = server.label.take(24),
                        style = MaterialTheme.typography.labelMedium,
                        color = if (selected) ArixOnPrimary else ArixOnSurface,
                        maxLines = 1,
                        modifier = Modifier
                            .clip(RoundedCornerShape(10.dp))
                            .background(if (selected) ArixPrimary else ArixSurfaceHigher)
                            .widgetNoRippleClickable { selectedServer = server }
                            .padding(horizontal = 12.dp, vertical = 7.dp),
                    )
                }
            }
        }
        // Embedded player stage
        selectedServer?.let { server ->
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(16f / 9f)
                    .clip(RoundedCornerShape(12.dp))
                    .background(androidx.compose.ui.graphics.Color(0xFF0A0A0E)),
            ) {
                MovieEmbedWebView(url = server.url)
            }
        } ?: Text(
            text = stringResource(R.string.widget_movie_no_servers),
            style = MaterialTheme.typography.bodySmall,
            color = ArixOnSurfaceVariant,
        )
        // Download links
        if (model.downloads.isNotEmpty()) {
            Text(
                text = stringResource(R.string.widget_movie_downloads, model.downloads.size),
                style = MaterialTheme.typography.labelLarge,
                color = ArixOnSurface,
                fontWeight = FontWeight.SemiBold,
            )
            model.downloads.take(8).forEach { download ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                        .background(ArixSurfaceHigher)
                        .widgetNoRippleClickable { openExternally(context, download.url) }
                        .padding(horizontal = 10.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    Text(
                        text = listOfNotNull(
                            download.quality.takeIf { it.isNotBlank() },
                            download.label.take(36),
                        ).joinToString(" · "),
                        style = MaterialTheme.typography.bodySmall,
                        color = ArixOnSurface,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f),
                    )
                    Icon(
                        imageVector = Icons.AutoMirrored.Rounded.OpenInNew,
                        contentDescription = stringResource(R.string.widget_movie_open),
                        modifier = Modifier.size(16.dp),
                        tint = ArixPrimary,
                    )
                }
            }
        }
    }
}

private fun openExternally(context: Context, url: String) {
    runCatching {
        context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }
}

@SuppressLint("SetJavaScriptEnabled")
@Composable
private fun MovieEmbedWebView(url: String) {
    AndroidView(
        factory = { context ->
            WebView(context).apply {
                setBackgroundColor(android.graphics.Color.TRANSPARENT)
                settings.javaScriptEnabled = true
                settings.domStorageEnabled = true
                settings.mediaPlaybackRequiresUserGesture = false
                settings.allowFileAccess = true
                settings.allowContentAccess = true
                settings.mixedContentMode = android.webkit.WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
                webViewClient = WebViewClient()
                loadUrl(url)
            }
        },
        update = { webView ->
            if (webView.tag != url) {
                webView.tag = url
                webView.loadUrl(url)
            }
        },
        modifier = Modifier.fillMaxSize(),
    )
}

/* ------------------------------------------------------- download helper */

/** Shares a QR PNG through the system share sheet via FileProvider. */
object ArixQrShare {
    fun sharePng(context: Context, bytes: ByteArray): Boolean {
        return runCatching {
            val appContext = context.applicationContext
            val shareDir = File(appContext.cacheDir, "qr-share").apply { mkdirs() }
            // Keep only the newest file so the cache never grows unbounded.
            shareDir.listFiles()?.forEach { it.delete() }
            val shareFile = File(shareDir, "arix-qr-code.png")
            shareFile.writeBytes(bytes)
            val uri = androidx.core.content.FileProvider.getUriForFile(
                appContext,
                "${appContext.packageName}.fileprovider",
                shareFile,
            )
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = "image/png"
                putExtra(Intent.EXTRA_STREAM, uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            appContext.startActivity(
                Intent.createChooser(intent, "QR code").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            )
            true
        }.getOrDefault(false)
    }
}

/** Saves media bytes into the system Downloads collection (MediaStore on
 *  Android 10+, the public Downloads directory on older versions). */
object ArixMediaDownloads {
    fun saveToDownloads(
        context: Context,
        displayName: String,
        mimeType: String,
        bytes: ByteArray,
    ): Uri {
        val appContext = context.applicationContext
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val values = android.content.ContentValues().apply {
                put(android.provider.MediaStore.Downloads.DISPLAY_NAME, displayName)
                put(android.provider.MediaStore.Downloads.MIME_TYPE, mimeType)
                put(android.provider.MediaStore.Downloads.IS_PENDING, 1)
            }
            val resolver = appContext.contentResolver
            val collection =
                android.provider.MediaStore.Downloads.getContentUri(android.provider.MediaStore.VOLUME_EXTERNAL_PRIMARY)
            val itemUri = resolver.insert(collection, values)
                ?: error("The download could not be created in the system Downloads store.")
            try {
                resolver.openOutputStream(itemUri)?.use { output ->
                    output.write(bytes)
                    output.flush()
                } ?: error("The download file could not be written.")
                values.clear()
                values.put(android.provider.MediaStore.Downloads.IS_PENDING, 0)
                resolver.update(itemUri, values, null, null)
            } catch (throwable: Throwable) {
                runCatching { resolver.delete(itemUri, null, null) }
                error("The download failed: ${throwable.message}")
            }
            return itemUri
        }
        @Suppress("DEPRECATION")
        val downloadsDirectory = android.os.Environment
            .getExternalStoragePublicDirectory(android.os.Environment.DIRECTORY_DOWNLOADS)
        downloadsDirectory.mkdirs()
        val targetFile = File(downloadsDirectory, displayName)
        targetFile.writeBytes(bytes)
        return Uri.fromFile(targetFile)
    }
}

/* ------------------------------------------------------ movie site client */

/**
 * Native movie-site client used by the poster grid's instant Play button and
 * by the client-side native tool router (instant movie lists / search).
 *
 * Mirrors the extension fetch strategy: workers.dev CORS proxies with the RAW
 * target URL appended (encoded targets are rejected), raced in parallel waves
 * for speed, then direct requests on both mirror domains. Players, download
 * links, and listings are parsed with the same patterns the extension uses.
 */
object MovieSiteClient {

    const val BrowserUserAgent =
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 " +
            "(KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36"

    private const val WompBase = "https://www.watchonlinemovies.com.pk"
    private const val SiteBase = "https://www.watch-movies.com.pk"

    private val proxies = listOf(
        "https://cors.caliph.my.id/",
        "https://proxy.it-mohmmed.workers.dev/?url=",
        "https://proxy.khacmanh-info.workers.dev/?url=",
        "https://proxy.khacdat-info.workers.dev/?url=",
        "https://proxy.nkm1703.workers.dev/?url=",
        "https://proxy.uneti-it.workers.dev/?url=",
        "https://proxy.teamvn1235.workers.dev/?url=",
        "https://proxy.zeronightpro.workers.dev/?url=",
        "https://proxy.manhrit.workers.dev/?url=",
        "https://proxy.cskh-n8n.workers.dev/?url=",
        "https://proxy.manhnguyenict.workers.dev/?url=",
        "https://proxy.nguyenmanhict.workers.dev/?url=",
        "https://proxy.cskh-zm.workers.dev/?url=",
        "https://proxy.tgb6jphrx7.workers.dev/?url=",
        "https://proxy.manhict.workers.dev/?url=",
    )

    val httpClient: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(12, TimeUnit.SECONDS)
        .followRedirects(true)
        .build()

    /** Races proxy attempts in parallel waves — the first valid HTML wins. */
    private fun fetchPage(url: String): String {
        val shuffled = proxies.shuffled()
        val errors = mutableListOf<String>()
        // 3 waves x 5 parallel proxies; each wave takes at most ~12s.
        for (wave in 0 until 3) {
            val batch = shuffled.drop(wave * 5).take(5)
            if (batch.isEmpty()) break
            val results = runBlocking {
                coroutineScope {
                    batch.map { proxy ->
                        async(Dispatchers.IO) {
                            try {
                                val request = Request.Builder()
                                    .url(proxy + url) // RAW url — encoded targets are rejected
                                    .header("User-Agent", BrowserUserAgent)
                                    .header("Accept", "text/html,application/xhtml+xml,*/*;q=0.8")
                                    .build()
                                httpClient.newCall(request).execute().use { response ->
                                    if (!response.isSuccessful) {
                                        synchronized(errors) { errors.add("proxy ${response.code}") }
                                        null
                                    } else {
                                        val body = response.body?.string().orEmpty()
                                        if (body.contains("<") && body.length > 500) body
                                        else null.also {
                                            synchronized(errors) { errors.add("proxy non-html") }
                                        }
                                    }
                                }
                            } catch (throwable: Throwable) {
                                synchronized(errors) { errors.add(throwable.message?.take(30) ?: "error") }
                                null
                            }
                        }
                    }.map { it.await() }
                }
            }
            results.filterNotNull().firstOrNull()?.let { return it }
        }
        // Direct fallbacks on both mirror domains.
        val candidates = buildList {
            add(url)
            if (url.startsWith(WompBase)) add(url.replace(WompBase, SiteBase))
            if (url.startsWith(SiteBase)) add(url.replace(SiteBase, WompBase))
        }
        for (candidate in candidates) {
            try {
                val request = Request.Builder()
                    .url(candidate)
                    .header("User-Agent", BrowserUserAgent)
                    .header("Accept", "text/html,*/*;q=0.8")
                    .header("Accept-Language", "en-US,en;q=0.9")
                    .build()
                httpClient.newCall(request).execute().use { response ->
                    if (!response.isSuccessful) {
                        errors.add("direct ${response.code}")
                        return@use
                    }
                    val body = response.body?.string().orEmpty()
                    if (body.contains("<")) return body
                }
            } catch (throwable: Throwable) {
                errors.add("direct ${throwable.message?.take(40) ?: "error"}")
            }
        }
        error("All fetch attempts failed (${errors.take(4).joinToString("; ")})")
    }

    private fun decodeEntities(input: String): String = input
        .replace("&nbsp;", " ")
        .replace("&amp;", "&")
        .replace("&quot;", "\"")
        .replace("&#0?39;|&apos;".toRegex(), "'")
        .replace("&lt;", "<")
        .replace("&gt;", ">")

    private fun normalizeUrl(raw: String): String =
        if (raw.startsWith("//")) "https:$raw" else raw

    private fun cleanTitle(raw: String): String {
        var title = decodeEntities(raw.replace(Regex("<[^>]+>"), "")).trim()
        if (title.contains(" - ")) title = title.substringBefore(" - ").trim()
        if (title.contains(" | ")) title = title.substringBefore(" | ").trim()
        return title
    }

    /** Scrapes the postbox listing rows (mirrors the extension parser). */
    private fun scrapeList(html: String): List<ArixMovieItemModel> {
        val results = mutableListOf<ArixMovieItemModel>()
        val seen = mutableSetOf<String>()
        val blocks = html.split(Regex("<div[^>]*class=[\"'][^\"']*postbox[^\"']*[\"'][^>]*>", RegexOption.IGNORE_CASE))
        val linkRegex = Regex(
            "<h2[^>]*>\\s*<a[^>]+href=[\"']([^\"']+)[\"'][^>]*(?:title=[\"']([^\"']*)[\"'])?[^>]*>([\\s\\S]*?)</a>",
            RegexOption.IGNORE_CASE,
        )
        val imgRegex = Regex(
            "<img[^>]+?(?:data-wpfc-original-src|data-lazy-src|data-src|src)=[\"']([^\"']+)[\"']",
            RegexOption.IGNORE_CASE,
        )
        val viewsRegex = Regex("class=[\"'][^\"']*views[^\"']*[\"'][^>]*>([^<]+)<", RegexOption.IGNORE_CASE)
        for (block in blocks) {
            val segment = block.take(4000)
            val link = linkRegex.find(segment) ?: continue
            val url = normalizeUrl(decodeEntities(link.groupValues[1]))
            if (!url.startsWith("http") || !seen.add(url)) continue
            val title = cleanTitle(link.groupValues[2].ifBlank { link.groupValues[3] })
            if (title.isBlank()) continue
            var thumbnail = imgRegex.find(segment)?.let {
                normalizeUrl(decodeEntities(it.groupValues[1]))
            }.orEmpty()
            if (thumbnail.contains("logo") || thumbnail.contains("placeholder")) thumbnail = ""
            val views = viewsRegex.find(segment)?.let {
                decodeEntities(it.groupValues[1]).replace(Regex("^views\\s*:\\s*", RegexOption.IGNORE_CASE), "")
            }.orEmpty()
            results.add(ArixMovieItemModel(title, url, thumbnail, views))
        }
        return results
    }

    /** Latest movies listing (page 1..20). */
    fun fetchLatest(page: Int = 1, limit: Int = 24): List<ArixMovieItemModel> {
        val normalized = page.coerceIn(1, 20)
        val html = fetchPage(if (normalized <= 1) "$WompBase/" else "$WompBase/page/$normalized/")
        return scrapeList(html).take(limit)
    }

    /** Search by name through the classic ?s= results page. */
    fun search(query: String, limit: Int = 24): List<ArixMovieItemModel> {
        val html = fetchPage("$WompBase/?s=${android.net.Uri.encode(query)}")
        return scrapeList(html).take(limit)
    }

    /** Builds the widget payload JSON for a listing. */
    fun listOutputJson(mode: String, query: String, page: Int, items: List<ArixMovieItemModel>): String {
        return JSONObject().apply {
            put("widget", "movie_list")
            put("mode", mode)
            put("query", query)
            put("page", page)
            put("results", org.json.JSONArray().apply {
                items.forEach { item ->
                    put(
                        JSONObject().apply {
                            put("title", item.title)
                            put("url", item.url)
                            put("thumbnail", item.thumbnail)
                            put("views", item.views)
                        },
                    )
                }
            })
        }.toString()
    }

    /** Builds the widget payload JSON for a player result. */
    fun playerOutputJson(model: ArixMoviePlayerModel): String {
        return JSONObject().apply {
            put("widget", "movie_player")
            put("mode", "play")
            put("title", model.title)
            put("description", model.description)
            put("thumbnail", model.thumbnail)
            put("source", "native")
            put("url", model.url)
            put("servers", org.json.JSONArray().apply {
                model.servers.forEach { server ->
                    put(JSONObject().put("label", server.label).put("url", server.url))
                }
            })
            put("downloads", org.json.JSONArray().apply {
                model.downloads.take(24).forEach { download ->
                    put(
                        JSONObject().apply {
                            put("quality", download.quality)
                            put("label", download.label)
                            put("url", download.url)
                        },
                    )
                }
            })
        }.toString()
    }

    /** Fetch a movie detail page and resolve servers + download links. */
    fun fetchDetail(pageUrl: String): ArixMoviePlayerModel {
        val html = fetchPage(pageUrl)
        val servers = mutableListOf<ArixMovieServerModel>()
        val downloads = mutableListOf<ArixMovieDownloadModel>()

        // Players: <h2>label</h2> ... <iframe ...>
        val playerRegex = Regex("<h2[^>]*>([\\s\\S]*?)</h2>\\s*(?:<p[^>]*>)?\\s*(<iframe[^>]*>)", RegexOption.IGNORE_CASE)
        playerRegex.findAll(html).forEach { match ->
            val label = decodeEntities(match.groupValues[1].replace(Regex("<[^>]+>"), "")).trim()
            val iframeTag = match.groupValues[2]
            val src = Regex("(?:data-wpfc-original-src|data-lazy-src|data-src|src)\\s*=\\s*[\"']([^\"']+)[\"']", RegexOption.IGNORE_CASE)
                .find(iframeTag)?.groupValues?.get(1) ?: return@forEach
            val serverUrl = normalizeUrl(decodeEntities(src))
            if (!serverUrl.startsWith("http")) return@forEach
            if (serverUrl.contains("youtube.com/embed") || serverUrl.contains("google.com/maps")) return@forEach
            servers.add(
                ArixMovieServerModel(
                    label = label.replace(Regex("\\s*below\\s*$", RegexOption.IGNORE_CASE), "").trim()
                        .ifBlank { "Player ${servers.size + 1}" },
                    url = serverUrl,
                ),
            )
        }

        // Fallback: every iframe
        if (servers.isEmpty()) {
            Regex("<iframe[^>]*>", RegexOption.IGNORE_CASE).findAll(html).forEachIndexed { index, match ->
                val src = Regex("(?:data-wpfc-original-src|data-lazy-src|data-src|src)\\s*=\\s*[\"']([^\"']+)[\"']", RegexOption.IGNORE_CASE)
                    .find(match.value)?.groupValues?.get(1) ?: return@forEachIndexed
                val serverUrl = normalizeUrl(decodeEntities(src))
                if (!serverUrl.startsWith("http")) return@forEachIndexed
                if (serverUrl.contains("youtube.com/embed") || serverUrl.contains("google.com/maps")) return@forEachIndexed
                servers.add(ArixMovieServerModel("Player ${index + 1}", serverUrl))
            }
        }

        // Downloads: quality <h2> followed by a <p> with anchors
        val downloadRegex = Regex("<h2[^>]*>([\\s\\S]*?)</h2>\\s*<p[^>]*>([\\s\\S]*?)</p>", RegexOption.IGNORE_CASE)
        val seenDownloads = mutableSetOf<String>()
        downloadRegex.findAll(html).forEach { match ->
            val quality = decodeEntities(match.groupValues[1].replace(Regex("<[^>]+>"), "")).trim()
            val body = match.groupValues[2]
            if (!Regex("quality|download|link", RegexOption.IGNORE_CASE).containsMatchIn(quality + body)) return@forEach
            Regex("<a[^>]+href=[\"']([^\"']+)[\"'][^>]*>([\\s\\S]*?)</a>", RegexOption.IGNORE_CASE).findAll(body).forEach { anchor ->
                val href = normalizeUrl(decodeEntities(anchor.groupValues[1]))
                val label = decodeEntities(anchor.groupValues[2].replace(Regex("<[^>]+>"), "")).trim()
                if (!href.startsWith("http") || href == "#" || !seenDownloads.add(href)) return@forEach
                if (Regex("addtoany|facebook|twitter|pinterest|whatsapp|google\\.com", RegexOption.IGNORE_CASE).containsMatchIn(href)) return@forEach
                downloads.add(ArixMovieDownloadModel(quality, label, href))
            }
        }

        val thumbnail = Regex("<meta[^>]+property=[\"']og:image[\"'][^>]+content=[\"']([^\"']+)[\"']", RegexOption.IGNORE_CASE)
            .find(html)?.groupValues?.get(1)?.let { normalizeUrl(decodeEntities(it)) }.orEmpty()

        val title = Regex("<h1[^>]*>([\\s\\S]*?)</h1>").find(html)?.let {
            decodeEntities(it.groupValues[1].replace(Regex("<[^>]+>"), "")).trim()
        }.orEmpty().ifBlank {
            Regex("<title>([\\s\\S]*?)</title>").find(html)?.let {
                decodeEntities(it.groupValues[1].trim())
            }.orEmpty()
        }

        return ArixMoviePlayerModel(
            title = title.substringBefore(" - ").substringBefore(" | ").trim(),
            description = Regex("class=[\"'][^\"']*singdesc[^\"']*[\"'][^>]*>([\\s\\S]*?)<", RegexOption.IGNORE_CASE)
                .find(html)?.groupValues?.get(1)?.let {
                    decodeEntities(it.replace(Regex("<[^>]+>"), "")).trim()
                }.orEmpty(),
            thumbnail = thumbnail,
            url = pageUrl,
            servers = servers,
            downloads = downloads,
        )
    }
}
