package com.arix.app.data

import android.content.Context
import com.arix.app.runtime.AlpineTerminalLaunchSpec
import java.io.File
import java.util.concurrent.TimeUnit
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject

/**
 * v2.4.6 — direct, no-compromise access to the real Android shell.
 *
 * Android ships an unprivileged shell (`/system/bin/sh`, mksh) that ANY app
 * process may exec through a normal pty — no root, no accessibility service,
 * no USB debugging and no wireless debugging required. This file provides
 * two complementary capabilities on top of that primitive:
 *
 *  1. [createLaunchSpec] — an interactive terminal spec for the shared
 *     Termux terminal UI (a real pty via the existing `TerminalSession`
 *     machinery, which is already shipped and battle-tested for the Alpine
 *     tab). The user gets a full interactive Android shell screen from the
 *     Tools hub.
 *
 *  2. [ArixAndroidShellTool] — an `android_shell` host tool so the AI agent
 *     can run Android-side commands (getprop, pm list packages, ps, toybox
 *     utilities, am/pm intents…) with the app's own uid. Everything runs
 *     with the exact privileges the app already has — identical to what the
 *     app's own Kotlin code could do, so this grants no new capability and
 *     requires no new permission.
 */
object ArixAndroidShell {

    /** Executable candidates in preference order. All exist unrooted. */
    private val ShellCandidates = listOf(
        "/system/bin/sh",
        "/system/xbin/sh",
        "/vendor/bin/sh",
        "/system/bin/mksh",
    )

    fun resolveShellBinary(): String? = ShellCandidates.firstOrNull { File(it).canExecute() }

    /**
     * Interactive terminal spec for the shared Termux terminal view. The
     * pty is created by the same JNI `createSubprocess` used for the Alpine
     * tab — only the executable differs (the Android shell instead of the
     * proot-wrapped Alpine one).
     */
    fun createLaunchSpec(context: Context): AlpineTerminalLaunchSpec {
        val shell = resolveShellBinary()
            ?: error("No Android shell binary was found on this device.")
        val home = context.filesDir
        val tmp = context.cacheDir
        val environment = listOf(
            "HOME=${home.absolutePath}",
            "TMPDIR=${tmp.absolutePath}",
            "PATH=/system/bin:/system/xbin:/odm/bin:/vendor/bin",
            "TERM=xterm-256color",
            "LANG=en_US.UTF-8",
            "SHELL=$shell",
            "PS1=arix-android$ ",
        )
        return AlpineTerminalLaunchSpec(
            executable = shell,
            arguments = arrayOf("-i"),
            environment = environment.toTypedArray(),
            workingDirectory = home.absolutePath,
        )
    }
}

/** One executed Android shell command. */
data class ArixShellRunResult(
    val exitCode: Int,
    val stdout: String,
    val stderr: String,
    val timedOut: Boolean,
    val durationMillis: Long,
)

/**
 * `android_shell` host tool. Runs commands with the app's own uid through
 * `/system/bin/sh -c` — the same trust level as the app itself.
 */
class ArixAndroidShellTool(
    private val context: Context,
    private val commandRunner: suspend (command: String, timeoutMillis: Long) -> ArixShellRunResult = { command, timeout ->
        defaultCommandRunner(context, command, timeout)
    },
) {
    suspend fun execute(argumentsJson: String): String {
        val arguments = runCatching { JSONObject(argumentsJson) }.getOrNull()
            ?: return failure("Arguments were not valid JSON.")
        return when (arguments.optString("action").trim().lowercase()) {
            "", "run", "execute" -> run(arguments)
            "status" -> status()
            else -> failure("action must be 'run' or 'status'.")
        }
    }

    private suspend fun run(arguments: JSONObject): String {
        val command = arguments.optString("command").trim()
        if (command.isEmpty()) return failure("Missing required 'command' argument.")
        val timeoutMillis = arguments.optInt(
            "timeout_ms",
            DefaultTimeoutMillis,
        ).coerceIn(MinTimeoutMillis, MaxTimeoutMillis)

        val result = runCatching { commandRunner(command, timeoutMillis.toLong()) }
            .getOrElse { throwable ->
                return failure("Android shell failed: ${throwable.message ?: "unknown error"}")
            }

        // Output cap: the tool result is fed to the LLM context, so keep it
        // bounded — head + tail with an explicit truncation marker preserves
        // both banners and the end of long logs.
        val stdout = capForContext(result.stdout)
        val stderr = capForContext(result.stderr)
        return JSONObject().apply {
            put("ok", !result.timedOut)
            put("tool", "android_shell")
            put("command", command)
            put("shell", ArixAndroidShell.resolveShellBinary() ?: "")
            put("exit_code", result.exitCode)
            put("timed_out", result.timedOut)
            put("duration_ms", result.durationMillis)
            put("stdout", stdout)
            put("stderr", stderr)
            if (result.timedOut) {
                put("errmsg", "Command timed out after ${timeoutMillis}ms and was killed.")
            }
        }.toString()
    }

    private fun status(): String = JSONObject().apply {
        val shell = ArixAndroidShell.resolveShellBinary()
        put("ok", shell != null)
        put("tool", "android_shell")
        put("shell", shell ?: "")
        put("root", false)
        put(
            "description",
            "Runs commands on the real Android shell with the app's own uid — " +
                "no root, no accessibility service and no USB/wireless debugging needed.",
        )
        put(
            "examples",
            JSONArray()
                .put("getprop ro.build.version.release")
                .put("pm list packages -f | head -20")
                .put("ps -A")
                .put("df /storage/emulated/0"),
        )
        if (shell == null) put("errmsg", "No Android shell binary was found on this device.")
    }.toString()

    private fun failure(message: String): String = JSONObject()
        .put("ok", false)
        .put("errmsg", message)
        .toString()

    companion object {
        private const val DefaultTimeoutMillis = 15_000
        private const val MinTimeoutMillis = 1_000
        private const val MaxTimeoutMillis = 120_000
        private const val MaxContextChars = 12_000

        val toolDefinition: JSONObject = JSONObject().apply {
            put("name", "android_shell")
            put(
                "description",
                "Run a command on the REAL Android shell (the device's own /system/bin/sh) " +
                    "as the app's unprivileged user — no root, no accessibility service and no " +
                    "USB/wireless debugging required. Use it for device-side facts the app cannot " +
                    "read through APIs: getprop build/device info, pm list packages, ps, df, " +
                    "toybox utilities, dumpsys (unprivileged parts), am/pm command lines, logcat " +
                    "for the app's own pid. Not for web browsing (use the chrome tool) or Linux " +
                    "work (use the normal shell tool). Commands run in the app's private home " +
                    "directory with a 15s default timeout.",
            )
            put(
                "parameters",
                JSONObject().apply {
                    put("type", "object")
                    put(
                        "properties",
                        JSONObject().apply {
                            put(
                                "action",
                                JSONObject().put("type", "string")
                                    .put("description", "One of: run (default), status."),
                            )
                            put(
                                "command",
                                JSONObject().put("type", "string").put(
                                    "description",
                                    "The shell command line to execute, e.g. getprop ro.product.model",
                                ),
                            )
                            put(
                                "timeout_ms",
                                JSONObject().put("type", "number")
                                    .put("description", "Optional timeout in ms (1000-120000, default 15000)."),
                            )
                        },
                    )
                    put("required", JSONArray().put("command"))
                    put("additionalProperties", false)
                },
            )
            put("execution_mode", "sequential")
        }

        /** Keeps head + tail of very long output, with a truncation marker. */
        internal fun capForContext(output: String, maxChars: Int = MaxContextChars): String {
            if (output.length <= maxChars) return output
            val half = maxChars / 2
            return output.take(half) +
                "\n… [truncated ${output.length - maxChars} characters] …\n" +
                output.takeLast(half)
        }

        /** Default implementation: ProcessBuilder + bounded wait + forceful kill. */
        private suspend fun defaultCommandRunner(
            context: Context,
            command: String,
            timeoutMillis: Long,
        ): ArixShellRunResult = withContext(Dispatchers.IO) {
            val shell = ArixAndroidShell.resolveShellBinary()
                ?: error("No Android shell binary was found on this device.")
            val startedAt = System.currentTimeMillis()
            val process = ProcessBuilder(shell, "-c", command)
                .directory(context.filesDir)
                .apply {
                    environment()["HOME"] = context.filesDir.absolutePath
                    environment()["TMPDIR"] = context.cacheDir.absolutePath
                    environment()["PATH"] = "/system/bin:/system/xbin:/odm/bin:/vendor/bin"
                    environment()["TERM"] = "dumb"
                    environment()["LANG"] = "en_US.UTF-8"
                }
                .start()

            coroutineScope {
                // Read both pipes concurrently so a chatty process can never
                // deadlock on a full pipe while we block on the other side.
                val stdoutJob = async { process.inputStream.readBytes() }
                val stderrJob = async { process.errorStream.readBytes() }
                val finished = process.waitFor(timeoutMillis, TimeUnit.MILLISECONDS)
                if (!finished) {
                    process.destroyForcibly()
                }
                // After waitFor/destroy the streams reach EOF; bound the join
                // so a stray grandchild holding the pipe can never hang us.
                val stdout = kotlinx.coroutines.withTimeoutOrNull(2_000) { stdoutJob.await() }
                    ?: ByteArray(0)
                val stderr = kotlinx.coroutines.withTimeoutOrNull(2_000) { stderrJob.await() }
                    ?: ByteArray(0)
                ArixShellRunResult(
                    exitCode = if (finished) process.exitValue() else -1,
                    stdout = stdout.toString(Charsets.UTF_8),
                    stderr = stderr.toString(Charsets.UTF_8),
                    timedOut = !finished,
                    durationMillis = System.currentTimeMillis() - startedAt,
                )
            }
        }
    }
}
