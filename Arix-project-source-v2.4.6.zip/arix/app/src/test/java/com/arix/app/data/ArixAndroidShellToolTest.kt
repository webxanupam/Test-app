package com.arix.app.data

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import kotlinx.coroutines.runBlocking
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner

/**
 * v2.4.6 — contract tests for the `android_shell` host tool (real Android
 * shell access with the app's own uid — no root, no accessibility, no ADB).
 *
 * The command runner is injected so the tests exercise the JSON contract,
 * timeout handling and output capping deterministically without needing a
 * device shell (Robolectric runs on the host JVM, where /system/bin/sh does
 * not exist).
 */
@RunWith(RobolectricTestRunner::class)
class ArixAndroidShellToolTest {

    private val context: Context = ApplicationProvider.getApplicationContext()

    private fun tool(
        runner: suspend (String, Long) -> ArixShellRunResult,
    ): ArixAndroidShellTool = ArixAndroidShellTool(
        context = context,
        commandRunner = runner,
    )

    @Test
    fun runReturnsCommandResultContract() {
        var capturedCommand: String? = null
        var capturedTimeout: Long? = null
        val toolInstance = tool { command, timeoutMillis ->
            capturedCommand = command
            capturedTimeout = timeoutMillis
            ArixShellRunResult(
                exitCode = 0,
                stdout = "Arix 16\n",
                stderr = "",
                timedOut = false,
                durationMillis = 42,
            )
        }
        val raw = runBlocking { toolInstance.execute(
            """{"action":"run","command":"echo Arix 16"}""",
        ) }
        val parsed = JSONObject(raw)
        assertEquals("echo Arix 16", capturedCommand)
        assertEquals(15_000L, capturedTimeout)
        assertTrue(parsed.getBoolean("ok"))
        assertEquals("android_shell", parsed.getString("tool"))
        assertEquals(0, parsed.getInt("exit_code"))
        assertFalse(parsed.getBoolean("timed_out"))
        assertEquals("Arix 16\n", parsed.getString("stdout"))
        assertEquals(42, parsed.getInt("duration_ms"))
    }

    @Test
    fun timeoutIsClampedAndReported() {
        var capturedTimeout: Long? = null
        val toolInstance = tool { _, timeoutMillis ->
            capturedTimeout = timeoutMillis
            ArixShellRunResult(
                exitCode = -1,
                stdout = "partial",
                stderr = "",
                timedOut = true,
                durationMillis = timeoutMillis,
            )
        }
        val raw = runBlocking { toolInstance.execute(
            """{"command":"sleep 500","timeout_ms":999999}""",
        ) }
        val parsed = JSONObject(raw)
        // 999999 clamps to the 120s ceiling.
        assertEquals(120_000L, capturedTimeout)
        assertFalse(parsed.getBoolean("ok"))
        assertTrue(parsed.getBoolean("timed_out"))
        assertEquals("partial", parsed.getString("stdout"))
        assertTrue(parsed.getString("errmsg").contains("timed out"))
    }

    @Test
    fun missingCommandFailsCleanly() {
        val toolInstance = tool { _, _ -> error("runner must not be called") }
        val parsed = JSONObject(runBlocking { toolInstance.execute("""{"action":"run"}""") })
        assertFalse(parsed.getBoolean("ok"))
        assertTrue(parsed.getString("errmsg").contains("command"))
    }

    @Test
    fun invalidJsonFailsCleanly() {
        val toolInstance = tool { _, _ -> error("runner must not be called") }
        val parsed = JSONObject(runBlocking { toolInstance.execute("not json") })
        assertFalse(parsed.getBoolean("ok"))
    }

    @Test
    fun unknownActionFailsCleanly() {
        val toolInstance = tool { _, _ -> error("runner must not be called") }
        val parsed = JSONObject(runBlocking { toolInstance.execute("""{"action":"explode"}""") })
        assertFalse(parsed.getBoolean("ok"))
        assertTrue(parsed.getString("errmsg").contains("action"))
    }

    @Test
    fun runnerFailureSurfacesAsToolError() {
        val toolInstance = tool { _, _ -> error("pipe broke") }
        val parsed = JSONObject(runBlocking { toolInstance.execute("""{"command":"ls"}""") })
        assertFalse(parsed.getBoolean("ok"))
        assertTrue(parsed.getString("errmsg").contains("pipe broke"))
    }

    @Test
    fun statusReportsNoRootNoAdbMechanism() {
        val toolInstance = tool { _, _ -> error("runner must not be called") }
        val parsed = JSONObject(runBlocking { toolInstance.execute("""{"action":"status"}""") })
        assertEquals("android_shell", parsed.getString("tool"))
        assertFalse(parsed.getBoolean("root"))
        assertTrue(parsed.getString("description").contains("no root"))
        assertTrue(parsed.getJSONArray("examples").length() > 0)
    }

    @Test
    fun longOutputIsCappedWithHeadAndTail() {
        val longOutput = buildString {
            repeat(4_000) { append("HEAD-$it\n") }
            repeat(4_000) { append("TAIL-$it\n") }
        }
        val capped = ArixAndroidShellTool.capForContext(longOutput, maxChars = 2_000)
        assertTrue(capped.length < longOutput.length)
        assertTrue(capped.contains("[truncated"))
        // The head prefix and the tail suffix both survive.
        assertTrue(capped.contains("HEAD-0"))
        assertTrue(capped.contains("TAIL-3999"))
    }

    @Test
    fun shortOutputPassesThroughUntouched() {
        assertEquals("short", ArixAndroidShellTool.capForContext("short", maxChars = 100))
    }

    @Test
    fun launchSpecPointsAtTheAndroidShellWithSaneEnvironment() {
        val shell = ArixAndroidShell.resolveShellBinary() ?: return // host JVM: no /system/bin/sh
        val spec = ArixAndroidShell.createLaunchSpec(context)
        assertEquals(shell, spec.executable)
        assertEquals(context.filesDir.absolutePath, spec.workingDirectory)
        val environment = spec.environment.associate {
            val index = it.indexOf('=')
            it.substring(0, index) to it.substring(index + 1)
        }
        assertEquals(context.filesDir.absolutePath, environment["HOME"])
        assertEquals("xterm-256color", environment["TERM"])
        assertTrue(environment["PATH"]!!.contains("/system/bin"))
    }
}
