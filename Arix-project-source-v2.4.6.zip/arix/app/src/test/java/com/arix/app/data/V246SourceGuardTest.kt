package com.arix.app.data

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

/**
 * Source-guard regression tests for the v2.4.6 fixes that cannot be exercised
 * by plain JVM unit tests because they live behind Android-runtime
 * constructors or Compose UI. Each assertion pins the exact code shape that
 * the corresponding fix introduced so a future refactor cannot silently
 * reintroduce the defect.
 */
class V246SourceGuardTest {

    private fun moduleDir(): File {
        var dir: File? = File(System.getProperty("user.dir"))
        repeat(6) {
            val direct = File(dir, "src/main/java/com/arix/app")
            if (direct.isDirectory) return dir!!
            dir = dir?.parentFile
        }
        throw IllegalStateException("app module directory not found")
    }

    private fun appSource(relative: String): String =
        File(moduleDir(), "src/main/java/com/arix/app/$relative").readText()

    @Test
    fun visualDisplayRendersExactlyOnePreviewPanel() {
        // Bug: agentModeDisplayState and chromeDisplayState are the SAME
        // state object (ArixApp passes uiState.chromeDisplayState for both),
        // so when both preview flags were true the same virtual display
        // rendered twice, stacked, while the agent browsed. Fix: the
        // agent-mode panel yields whenever the Chrome panel is visible.
        val src = appSource("ui/ConversationUi.kt")
        assertTrue(
            "agent-mode preview must be suppressed when the chrome preview is visible",
            src.contains("agentModePreviewUnfiltered && !chromePreviewVisible"),
        )
        // The chrome flag must be computed BEFORE the suppression line so the
        // suppression sees the final value.
        assertTrue(
            src.indexOf("val chromePreviewVisible =") <
                src.indexOf("agentModePreviewUnfiltered && !chromePreviewVisible"),
        )
    }

    @Test
    fun chatPreviewWebViewIsTransparentOverTheDarkBackdrop() {
        // Bug: the chat live-view WebView painted a solid WHITE background
        // until the noVNC page loaded — a blank white panel. Fix: transparent
        // background so the dark panel backdrop shows through while loading.
        val src = appSource("ui/ConversationUi.kt")
        assertTrue(src.contains("transparentBackground = true"))
    }

    @Test
    fun chromiumBootsOnDarkStartPageInsteadOfAboutBlank() {
        // Bug: the browser window started on about:blank — a full-bleed blank
        // WHITE page that read as a broken display. Fix: a small dark data:
        // URL start page; the first agent navigation replaces it exactly as
        // before.
        val src = appSource("data/AlpineChromeController.kt")
        assertTrue(src.contains("data:text/html;charset=utf-8"))
        assertFalse("launch script must not boot about:blank", src.contains("about:blank &"))
    }

    @Test
    fun vncViewerSurfacesConnectionErrorsViaWatchdog() {
        // Bug: the noVNC status bar was hidden by design, so a failed or
        // stalled VNC connection left a silent blank screen with no hint.
        // Fix: a watchdog reveals a compact status bar when no frame lands
        // within 9s and hides it again once frames flow.
        val src = appSource("ui/AlpineChromeScreen.kt")
        assertTrue(src.contains("watchVncConnection"))
        assertTrue(src.contains("arix-vnc-status-visible"))
    }

    @Test
    fun androidShellHostToolIsRegisteredAndWired() {
        // The no-root/no-ADB/no-accessibility Android shell: an `android_shell`
        // host tool dispatched by ArixToolExecutor and constructed in the
        // Application graph.
        val executor = appSource("data/ArixToolExecutor.kt")
        assertTrue(executor.contains("\"android_shell\" -> androidShellTool?.execute"))
        assertTrue(executor.contains("ArixAndroidShellTool.toolDefinition"))
        val application = appSource("ArixApplication.kt")
        assertTrue(application.contains("ArixAndroidShellTool("))
        assertTrue(application.contains("androidShellTool = androidShellTool"))
    }

    @Test
    fun androidShellExecsTheDeviceShellWithoutRootOrAdb() {
        // The mechanism itself: /system/bin/sh exec'd on a real pty through
        // the same Termux TerminalSession used by the Alpine tab.
        val shell = appSource("data/ArixAndroidShell.kt")
        assertTrue(shell.contains("/system/bin/sh"))
        assertTrue(shell.contains("destroyForcibly()"))
        assertFalse("must not use su", shell.contains("\"su\""))
        assertFalse("must not shell out to adb", shell.contains("\"adb\""))
    }

    @Test
    fun terminalScreenIsReusableForTheAndroidShell() {
        // AlpineTerminalScreen gained backward-compatible title/banner
        // parameters; the Android shell screen reuses the proven surface.
        val terminal = appSource("ui/AlpineTerminalScreen.kt")
        assertTrue(terminal.contains("screenTitle: String = \"Alpine\""))
        assertTrue(terminal.contains("showStoragePermissionBanner: Boolean = true"))
        val tools = appSource("ui/ArixToolsUi.kt")
        assertTrue(tools.contains("ArixAndroidShellToolScreen"))
        assertTrue(tools.contains("ArixAndroidShell.createLaunchSpec(context)"))
    }

    @Test
    fun toolScreensHaveClearHeaderToContentSpacing() {
        // Bug: the tool header (back button, title, subtitle) sat only 8dp
        // above the search bar. Fix: a clear 18dp gap; content also starts
        // higher (4dp top inset).
        val src = appSource("ui/ArixToolsUi.kt")
        assertTrue(src.contains("bottom = 18.dp"))
        assertTrue(src.contains("top = 4.dp"))
        // Premium card polish: consistent heights + aligned chevron slot.
        assertTrue(src.contains("heightIn(min = 96.dp)"))
    }
}
