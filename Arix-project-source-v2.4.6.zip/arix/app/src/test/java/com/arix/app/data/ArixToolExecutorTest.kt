package com.arix.app.data

import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ArixToolExecutorTest {
    @Test
    fun hostToolDefinitionsDoNotDuplicatePiNativeTools() {
        val definitions = ArixToolExecutor.hostToolDefinitions()
        // system_control is always available; android_shell (v2.4.6) is the
        // other always-on host tool; nothing else leaks without a
        // self-management tool.
        assertEquals(2, definitions.length())
        assertEquals("system_control", definitions.getJSONObject(0).getString("name"))
        assertEquals("android_shell", definitions.getJSONObject(1).getString("name"))
    }

    @Test
    fun hostToolDefinitionsExposeFlattenedShape() {
        val definitions = ArixToolExecutor.hostToolDefinitions()
        val definition = definitions.getJSONObject(0)
        // OpenAI-style definitions are flattened to name/description/parameters
        // plus Arix execution_mode metadata.
        assertEquals("system_control", definition.optString("name"))
        assertTrue(definition.has("parameters"))
        assertTrue(definition.optString("description").isNotBlank())
    }

    @Test
    fun androidShellDefinitionIsWellFormed() {
        val definitions = ArixToolExecutor.hostToolDefinitions()
        val definition = definitions.getJSONObject(1)
        assertEquals("android_shell", definition.optString("name"))
        assertEquals("sequential", definition.optString("execution_mode"))
        val required = definition
            .getJSONObject("parameters")
            .optJSONArray("required")
        assertEquals(1, required.length())
        assertEquals("command", required.getString(0))
    }

    @Test
    fun hostToolNamesCoverSystemAndroidShellAndSelfManagement() {
        assertTrue(ArixToolExecutor.supports("system_control"))
        assertTrue(ArixToolExecutor.supports("android_shell"))
        assertTrue(ArixToolExecutor.supports("arix_config_get"))
        assertFalse(ArixToolExecutor.supports("agent_mode"))
        assertFalse(ArixToolExecutor.supports("mcp_list_tools"))
        assertFalse(ArixToolExecutor.supports("chrome"))
    }

    @Test
    fun inferToolOutputOkHonorsArixJsonFlags() {
        assertTrue(ArixToolExecutor.inferToolOutputOk("""{"ok":true}"""))
        assertFalse(ArixToolExecutor.inferToolOutputOk("""{"ok":false}"""))
        assertFalse(ArixToolExecutor.inferToolOutputOk("""{"err":true}"""))
        assertTrue(ArixToolExecutor.inferToolOutputOk("plain text"))
        assertTrue(ArixToolExecutor.inferToolOutputOk("""{"status":"fine"}"""))
    }

    @Test
    fun executionResultFlagsErrorOutput() {
        val ok = ArixToolExecutionResult("system_control", "{}", """{"ok":true}""")
        val failed = ArixToolExecutionResult("system_control", "{}", """{"ok":false,"errmsg":"nope"}""")
        assertFalse(ok.isError)
        assertTrue(failed.isError)
        assertEquals(failed.rawOutput, failed.visibleOutput)
    }
}
