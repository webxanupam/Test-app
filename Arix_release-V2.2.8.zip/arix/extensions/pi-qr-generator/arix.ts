/**
 * QR Code Generator — Arix extension entry point.
 *
 * Adds:
 *   - a rich `qr-code` message card (base64 image, payload, provider info)
 *     with a Download button that saves the PNG into the system Downloads
 *   - a composer menu item that instantly QR-encodes the current draft
 *   - the bridge used by index.ts to mirror tool results into the chat
 *   - saved-image management (storage folder + one-tap clean option)
 *   - a settings page describing the provider fallback chain
 */

import { mkdirSync, readdirSync, writeFileSync, unlinkSync, existsSync } from "node:fs";
import { homedir } from "node:os";
import { join } from "node:path";
import { describeQrData, generateQrPng } from "./qr.ts";

type ArixJsonObject = Record<string, unknown>;
type ArixView = ArixJsonObject | ArixView[] | string | null | undefined;
type ArixRenderContext = ArixJsonObject & { storage: ArixJsonObject };
type ArixMessageTypeDefinition = {
  type: string;
  title?: string;
  icon?: string;
  render:
    | ArixView
    | ((context: ArixRenderContext & { message: ArixJsonObject }) => ArixView | Promise<ArixView>);
};
type ArixQrPayload = {
  data: string;
  kind: string;
  base64: string;
  size: number;
  provider: string;
  savedPath: string;
};
type ArixExtensionApi = {
  ui: {
    text(text: string, properties?: ArixJsonObject): ArixJsonObject;
    column(children: ArixView[], properties?: ArixJsonObject): ArixJsonObject;
    row(children: ArixView[], properties?: ArixJsonObject): ArixJsonObject;
    card(children: ArixView[], properties?: ArixJsonObject): ArixJsonObject;
    button(label: string, action: string, properties?: ArixJsonObject): ArixJsonObject;
    input(value: string, action: string, properties?: ArixJsonObject): ArixJsonObject;
    spacer(size?: number, properties?: ArixJsonObject): ArixJsonObject;
    web(properties: ArixJsonObject): ArixJsonObject;
  };
  host: { invoke(method: string, args?: ArixJsonObject): Promise<ArixJsonObject> };
  state: { get(path?: string): Promise<ArixJsonObject> };
  storage: {
    get<T = unknown>(key: string, fallback?: T): T;
    set(key: string, value: unknown): void;
  };
  messages: {
    append(type: string, payload?: ArixJsonObject, text?: string): Promise<ArixJsonObject>;
  };
  registerSettings(definition: ArixJsonObject): () => void;
  registerAction(
    id: string,
    handler: (payload: ArixJsonObject) => unknown | Promise<unknown>,
  ): () => void;
  registerMessageType(definition: ArixMessageTypeDefinition): () => void;
  registerComposerMenuItem(definition: ArixJsonObject): () => void;
  registerToolTitle(
    toolName: string,
    runningTitle: string,
    completedTitle: string,
    priority?: number,
  ): () => void;
  notify(message: string, level?: "info" | "warning" | "error"): void;
  invalidate(): void;
};

const BRIDGE_KEY = Symbol.for("pi-qr-generator.arix-bridge");
const SETTINGS_PAGE_ID = "qr-generator-settings";

interface QrBridge {
  api: ArixExtensionApi;
}

function escapeHtml(value: string): string {
  return String(value ?? "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}

/** Directory where generated QR PNGs are kept until cleaned. */
function savedQrDirectory(): string {
  return join(homedir(), ".arix", "qr-codes");
}

function listSavedQrFiles(): string[] {
  try {
    const dir = savedQrDirectory();
    if (!existsSync(dir)) return [];
    return readdirSync(dir).filter((name) => name.toLowerCase().endsWith(".png"));
  } catch {
    return [];
  }
}

/** Persist one QR PNG; returns the absolute path ("" when the write fails). */
export function persistQrPng(bytes: Uint8Array): string {
  try {
    const dir = savedQrDirectory();
    mkdirSync(dir, { recursive: true });
    const stamp = new Date().toISOString().replace(/[:.]/g, "-").slice(0, 19);
    const filePath = join(dir, `qr-${stamp}.png`);
    writeFileSync(filePath, bytes);
    return filePath;
  } catch {
    return "";
  }
}

/** Delete every saved QR PNG; returns the number of removed files. */
function cleanSavedQrFiles(): number {
  let removed = 0;
  for (const name of listSavedQrFiles()) {
    try {
      unlinkSync(join(savedQrDirectory(), name));
      removed += 1;
    } catch {
      // Skip files that cannot be removed.
    }
  }
  return removed;
}

function syncSavedQrCount(api: ArixExtensionApi): number {
  const count = listSavedQrFiles().length;
  try {
    api.storage.set("qr_saved_count", count);
    api.invalidate();
  } catch {
    // Storage sync is best-effort.
  }
  return count;
}

/** Called by index.ts to mirror tool results into the Arix conversation. */
export async function appendArixQrMessage(
  type: string,
  payload: ArixJsonObject,
  text = "",
): Promise<boolean> {
  const bridge = (globalThis as Record<PropertyKey, unknown>)[BRIDGE_KEY] as QrBridge | undefined;
  if (!bridge) return false;
  try {
    await bridge.api.messages.append(type, payload, text);
    return true;
  } catch {
    return false;
  }
}

function qrCardHtml(payload: ArixQrPayload): string {
  const data = String(payload.data ?? "");
  const base64 = String(payload.base64 ?? "");
  const kind = String(payload.kind ?? "Text");
  const provider = String(payload.provider ?? "");
  const size = Number(payload.size ?? 300);
  return `<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1"/>
<style>
  * { box-sizing: border-box; margin: 0; padding: 0; -webkit-tap-highlight-color: transparent; }
  body { font-family: -apple-system, Roboto, 'Segoe UI', sans-serif; background: transparent; color: #ECECF1; }
  .wrap { display: flex; gap: 14px; padding: 12px; align-items: flex-start; }
  .qr { width: 148px; height: 148px; border-radius: 14px; background: #fff; flex: 0 0 auto; display: flex; align-items: center; justify-content: center; }
  .qr img { width: 128px; height: 128px; image-rendering: pixelated; display: block; }
  .side { flex: 1; min-width: 0; display: flex; flex-direction: column; gap: 7px; padding-top: 2px; }
  .kind { display: inline-block; align-self: flex-start; background: #2A2A33; color: #B9BDC6; font-size: 10px; font-weight: 600; border-radius: 10px; padding: 3px 8px; letter-spacing: 0.4px; text-transform: uppercase; }
  .data { font-size: 12px; line-height: 1.45; word-break: break-all; max-height: 78px; overflow: hidden; }
  .meta { font-size: 10px; color: #9AA0A6; line-height: 1.5; }
  .download { margin-top: 3px; border: 0; border-radius: 10px; background: linear-gradient(135deg, #9D6BFF, #6E3FE8); color: #fff; font-size: 12px; font-weight: 700; padding: 8px 14px; align-self: flex-start; }
  .download:active { opacity: 0.75; }
  .download[disabled] { background: #3A3A44; color: #9AA0A6; }
</style>
</head>
<body>
  <div class="wrap">
    <div class="qr"><img src="data:image/png;base64,${escapeHtml(base64)}" alt="QR code"/></div>
    <div class="side">
      <span class="kind">${escapeHtml(kind)} · QR</span>
      <div class="data">${escapeHtml(data)}</div>
      <div class="meta">${escapeHtml(String(size))}×${escapeHtml(String(size))} px · via ${escapeHtml(provider)}</div>
      <button class="download" id="qr-download"
        data-b64="${escapeHtml(base64)}"
        data-name="qr-code.png">⬇ Download PNG</button>
    </div>
  </div>
  <script>
    (function () {
      var button = document.getElementById('qr-download');
      if (!button) return;
      button.addEventListener('click', function () {
        if (button.disabled) return;
        button.disabled = true;
        button.textContent = 'Saving…';
        Arix.postMessage(JSON.stringify({
          action: 'qr_download',
          args: { base64: button.getAttribute('data-b64'), filename: button.getAttribute('data-name') }
        }));
        setTimeout(function () {
          button.disabled = false;
          button.textContent = '⬇ Download PNG';
        }, 2500);
      });
    })();
  </script>
</body>
</html>`;
}

async function generateAndAppendQr(api: ArixExtensionApi, data: string): Promise<unknown> {
  const payload = String(data ?? "").trim();
  if (!payload) {
    api.notify("Enter some text or a link first, then tap QR Code.", "warning");
    return { error: "empty data" };
  }
  api.notify("Generating QR code…", "info");
  try {
    const result = await generateQrPng(payload, 300);
    const savedPath = persistQrPng(result.bytes);
    syncSavedQrCount(api);
    await api.messages.append(
      "qr-code",
      {
        data: payload,
        kind: describeQrData(payload),
        base64: result.base64,
        size: result.size,
        provider: result.providerLabel,
        savedPath,
      },
      `QR code for: ${payload}`,
    );
    return { ok: true, provider: result.provider, savedPath };
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);
    api.notify(`QR generation failed: ${message}`, "error");
    return { error: message };
  }
}

export const activateArix = async (arix: ArixExtensionApi) => {
  (globalThis as Record<PropertyKey, unknown>)[BRIDGE_KEY] = { api: arix } satisfies QrBridge;

  arix.registerToolTitle?.("qr_code", "Generating QR code", "Generated QR code", 200);

  /* Download button on every QR card: saves the PNG into system Downloads. */
  arix.registerAction("qr_download", async (payload) => {
    const base64 = String(payload.base64 ?? "");
    if (!base64) {
      arix.notify("The QR image is no longer available — generate it again.", "error");
      return { error: "missing image" };
    }
    const filename = String(payload.filename ?? "qr-code.png").trim() || "qr-code.png";
    const safeName = filename.toLowerCase().endsWith(".png") ? filename : `${filename}.png`;
    try {
      const result = await arix.host.invoke("app.saveMediaToDownloads", {
        filename: safeName,
        mime_type: "image/png",
        base64,
      });
      if (result && result.saved === true) {
        arix.notify(`Saved to Downloads: ${safeName}`, "info");
        return { ok: true, filename: safeName };
      }
      throw new Error("The host did not confirm the download.");
    } catch (error) {
      const message = error instanceof Error ? error.message : String(error);
      arix.notify(`Download failed: ${message}`, "error");
      return { error: message };
    }
  });

  /* Clean option: remove every stored generated QR image. */
  arix.registerAction("qr_clean_saved", async () => {
    const removed = cleanSavedQrFiles();
    syncSavedQrCount(arix);
    arix.notify(
      removed > 0 ? `Removed ${removed} saved QR image(s).` : "No saved QR images to remove.",
      "info",
    );
    return { ok: true, removed };
  });

  /* Composer menu item: QR-encode the current draft instantly. */
  try {
    arix.registerComposerMenuItem({
      id: "qr-generate",
      title: "QR Code",
      subtitle: "Encode the composer text as a QR code",
      icon: "qr",
      order: 60,
      action: "qr_from_draft",
    });
  } catch {
    // Composer menu registration is best-effort.
  }

  arix.registerAction("qr_from_draft", async () => {
    let draft = "";
    try {
      const result = (await arix.state.get("draft_input")) as ArixJsonObject;
      const candidate = result?.value;
      draft = typeof candidate === "string" ? candidate : "";
    } catch {
      draft = "";
    }
    if (!draft.trim()) {
      const stored = arix.storage.get<string>("qr_last_input", "");
      if (stored) draft = stored;
    }
    if (!draft.trim()) {
      api_notify(arix, "Type the text or link to encode, then tap QR Code again.");
      return { error: "empty draft" };
    }
    return await generateAndAppendQr(arix, draft);
  });

  /* Settings page text input writes here (value-control dispatch contract). */
  arix.registerAction(
    `settings:${SETTINGS_PAGE_ID}:payload_input`,
    (payload) => {
      const value = String(payload.value ?? "");
      arix.storage.set("qr_last_input", value);
      return { ok: true };
    },
  );

  arix.registerAction("qr_quick_generate", async () => {
    const value = String(arix.storage.get<string>("qr_last_input", "") ?? "").trim();
    if (!value) {
      api_notify(arix, "Enter the text or link to encode first.");
      return { error: "empty input" };
    }
    return await generateAndAppendQr(arix, value);
  });

  arix.registerAction("qr_refresh_saved_count", () => {
    const count = syncSavedQrCount(arix);
    return { ok: true, count };
  });

  arix.registerMessageType({
    type: "qr-code",
    title: "QR Code",
    icon: "qr",
    render: ({ message }) => {
      const payload = (message.payload ?? message) as unknown as ArixQrPayload;
      const base64 = String(payload?.base64 ?? "");
      if (!base64) {
        return arix.ui.card([
          arix.ui.text(String(payload?.data ?? "QR code"), { weight: 1 }),
          arix.ui.text("The QR image is no longer available.", { color: "muted" }),
        ], { radius: 16 });
      }
      return arix.ui.card([
        arix.ui.web({
          height: 176,
          html: qrCardHtml({
            data: String(payload?.data ?? ""),
            kind: String(payload?.kind ?? "Text"),
            base64,
            size: Number(payload?.size ?? 300),
            provider: String(payload?.provider ?? ""),
            savedPath: String(payload?.savedPath ?? ""),
          }),
        }),
      ], { radius: 16 });
    },
  });

  try {
    arix.registerSettings({
      id: SETTINGS_PAGE_ID,
      title: "QR Code Generator",
      subtitle: "Free open QR APIs with automatic fallback",
      icon: "qr",
      order: 50,
      categories: [
        {
          id: "quick",
          title: "Quick generate",
          subtitle: "Create a QR code without leaving Settings",
          icon: "qr",
          order: 0,
          sections: [
            {
              title: "QR payload",
              description: "Enter any text, link, email, phone number, or Wi-Fi string.",
              settings: [
                {
                  id: "payload_input",
                  type: "text",
                  label: "Text or link",
                  placeholder: "https://example.com",
                },
                {
                  id: "payload_generate",
                  type: "button",
                  label: "Generate QR code",
                  buttonLabel: "Generate QR code",
                  action: "qr_quick_generate",
                  tone: "primary",
                },
              ],
            },
          ],
        },
        {
          id: "storage",
          title: "Saved images",
          subtitle: "Stored QR codes and cleanup",
          icon: "delete",
          order: 1,
          sections: [
            {
              title: "Storage cleanup",
              description:
                "Generated QR codes are kept in the private qr-codes folder. " +
                "Use the button below to remove all stored QR images at once.",
              settings: [
                {
                  id: "clean_saved",
                  type: "button",
                  label: "Clean saved QR codes",
                  buttonLabel: "Remove all saved QR images",
                  action: "qr_clean_saved",
                  tone: "danger",
                },
                {
                  id: "refresh_count",
                  type: "button",
                  label: "Refresh count",
                  buttonLabel: "Refresh saved count",
                  action: "qr_refresh_saved_count",
                  tone: "normal",
                },
              ],
            },
          ],
        },
        {
          id: "providers",
          title: "Providers",
          subtitle: "Fallback order for QR generation",
          icon: "settings",
          order: 2,
          sections: [
            {
              title: "Free QR API fallbacks",
              description:
                "Requests walk down this list until a provider returns a valid PNG: " +
                "api.qrserver.com (goqr.me) → quickchart.io → qrtag.net. " +
                "All providers are free and keyless.",
              settings: [
                { id: "p1", type: "label", label: "1. api.qrserver.com", description: "Primary provider (goqr.me)" },
                { id: "p2", type: "label", label: "2. quickchart.io", description: "First fallback" },
                { id: "p3", type: "label", label: "3. qrtag.net", description: "Second fallback" },
              ],
            },
          ],
        },
      ],
    });
  } catch {
    // Settings registration is best-effort.
  }
};

function api_notify(api: ArixExtensionApi, message: string): void {
  try {
    api.notify(message, "info");
  } catch {
    // Notification is best-effort.
  }
}
