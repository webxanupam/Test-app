/**
 * QR Code Generator — Pi extension entry point.
 *
 * Registers the `qr_code` agent tool. The tool encodes any text or link into
 * a QR PNG through free QR APIs with automatic fallback and mirrors a rich QR
 * card (image + download button) into the Arix conversation via the bridge
 * installed by arix.ts. The PNG is stored in the private qr-codes folder and
 * can be cleaned from the extension settings page.
 */

import type { AgentToolResult, ExtensionAPI } from "@earendil-works/pi-coding-agent";
import { Type } from "typebox";
import { describeQrData, generateQrPng } from "./qr.ts";
import { persistQrPng } from "./arix.ts";

const TOOL_NAME = "qr_code";

export default function activateQrGenerator(pi: ExtensionAPI) {
  pi.registerTool({
    name: TOOL_NAME,
    label: "QR Code Generator",
    description:
      "Generate a scannable QR code image for any text, URL, email, phone number, " +
      "Wi-Fi payload, or contact card. Uses free open QR APIs with multiple " +
      "automatic fallbacks and shows the QR code directly in the chat as a card " +
      "with a download button. Use this whenever the user asks for a QR code.",
    promptSnippet: "Use when the user wants a QR code for a link or any text.",
    parameters: Type.Object({
      data: Type.String({ description: "The text, URL, or payload to encode into the QR code." }),
      size: Type.Optional(
        Type.Number({
          description: "Image size in pixels (120-1000, default 300).",
        }),
      ),
    }),

    async execute(
      _callId: string,
      params: { data: string; size?: number },
      _signal?: AbortSignal,
      _onUpdate?: unknown,
      _ctx?: { cwd?: string },
    ): Promise<AgentToolResult<Record<string, unknown>>> {
      const data = String(params.data ?? "").trim();
      if (!data) {
        return {
          content: [{ type: "text", text: "Error: data is required to generate a QR code." }],
          details: { error: "missing data" },
        };
      }
      try {
        const result = await generateQrPng(data, params.size ?? 300);

        const savedPath = persistQrPng(result.bytes);

        const kind = describeQrData(data);
        const summary =
          `QR code generated for: ${data}\n` +
          `Provider: ${result.providerLabel} · Size: ${result.size}×${result.size} px\n` +
          "The QR image card is shown in the chat with a download button.";

        return {
          content: [{ type: "text", text: summary }],
          details: {
            data,
            kind,
            base64: result.base64,
            provider: result.provider,
            provider_label: result.providerLabel,
            size: result.size,
            savedPath,
            shown_in_chat: true,
            // Structured payload for the native in-chat QR widget (image +
            // download button rendered straight from the tool result).
            output_json: JSON.stringify({
              widget: "qr_code",
              data,
              kind,
              base64: result.base64,
              size: result.size,
              provider: result.providerLabel,
            }),
          },
        };
      } catch (error) {
        const message = error instanceof Error ? error.message : String(error);
        return {
          content: [{ type: "text", text: `QR code generation failed: ${message}` }],
          details: { error: message },
        };
      }
    },
  });
}
