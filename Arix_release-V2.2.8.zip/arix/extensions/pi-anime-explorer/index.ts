/**
 * Anime Explorer — Pi extension entry point (v2.2.7).
 *
 * Registers the `anime_explorer` agent tool with three modes:
 *   - latest : list the latest ongoing anime series
 *   - search : find anime by name
 *   - watch  : resolve an anime into its episode list with stream servers
 *
 * Rich results are mirrored into the Arix conversation as native widgets
 * (poster rail + episode/server player) through the payload consumed by the
 * app's chat renderer, matching the movie explorer pattern.
 */

import type { AgentToolResult, ExtensionAPI } from "@earendil-works/pi-coding-agent";
import { Type } from "typebox";
import {
  fetchAnimeEpisodes,
  fetchLatestAnime,
  playableUrl,
  searchAnime,
  type AnimeDetail,
  type AnimeItem,
  SOURCE_ANIMELOK,
} from "./anime.ts";

const TOOL_NAME = "anime_explorer";
const MAX_LIST_ITEMS = 24;

function formatListResult(mode: string, query: string, results: AnimeItem[]): string {
  if (results.length === 0) {
    return mode === "search"
      ? `No anime found for "${query}".`
      : "Could not fetch the latest anime right now. Try again in a moment.";
  }
  const header = mode === "search"
    ? `Anime matching "${query}":`
    : "Latest ongoing anime:";
  const lines = results.slice(0, MAX_LIST_ITEMS).map((item, index) => {
    return `${index + 1}. ${item.title} [${item.source}]\n   ${item.url}`;
  });
  return [header, "", ...lines].join("\n");
}

function formatWatchResult(detail: AnimeDetail): string {
  const parts: string[] = [];
  parts.push(detail.title || "Anime");
  parts.push(`Episodes: ${detail.episodes.length}`);
  parts.push("");
  detail.episodes.slice(0, 30).forEach((episode) => {
    const name = episode.name ? ` — ${episode.name}` : "";
    parts.push(`  Episode ${episode.number}${name}`);
  });
  if (detail.episodes.length > 30) {
    parts.push(`  … and ${detail.episodes.length - 30} more`);
  }
  parts.push("");
  parts.push(
    "Pick an episode number to see its stream servers — ask me to " +
      "'play episode N' and I will resolve the servers for it.",
  );
  return parts.join("\n");
}

export default function activateAnimeExplorer(pi: ExtensionAPI) {
  pi.registerTool({
    name: TOOL_NAME,
    label: "Anime Explorer",
    description:
      "Explore, search, and watch anime from animelok.live and animesalt.cx. " +
      "Modes: 'latest' lists ongoing anime; 'search' finds anime by name " +
      "(pass the anime name as query); 'watch' resolves an anime URL into its " +
      "episode list (pass the anime URL from a previous result). After listing " +
      "episodes, resolve stream servers by calling watch again with the " +
      "episode parameter set. Use this tool whenever the user wants to watch, " +
      "find, search, list, or play anime.",
    promptSnippet:
      "Use for watching anime: latest anime, anime search, episode lists, and multi-server episode playback.",
    parameters: Type.Object({
      mode: Type.Union([Type.Literal("latest"), Type.Literal("search"), Type.Literal("watch")], {
        description: "Operation mode: latest, search, or watch.",
      }),
      query: Type.Optional(Type.String({ description: "Anime name. Required for mode=search." })),
      url: Type.Optional(
        Type.String({
          description:
            "Anime URL from a previous result (animelok:/slug or https://animesalt.cx/...). Required for mode=watch.",
        }),
      ),
      episode: Type.Optional(
        Type.Number({
          description:
            "Episode number. For mode=watch with an AnimeLok item: when set, returns the stream servers for that episode instead of the episode list.",
        }),
      ),
      page: Type.Optional(
        Type.Number({ description: "Listing page number for mode=latest (default 1)." }),
      ),
      limit: Type.Optional(
        Type.Number({ description: "Maximum number of list results (default 20)." }),
      ),
    }),

    async execute(
      _callId: string,
      params: {
        mode: "latest" | "search" | "watch";
        query?: string;
        url?: string;
        episode?: number;
        page?: number;
        limit?: number;
      },
      signal?: AbortSignal,
    ): Promise<AgentToolResult<Record<string, unknown>>> {
      const mode = params.mode;
      const limit = Math.min(Math.max(Math.floor(params.limit ?? 20), 1), 50);

      const aborted = () =>
        signal?.aborted === true
          ? {
              content: [{ type: "text" as const, text: "Anime Explorer was cancelled." }],
              details: { error: "cancelled" },
            }
          : undefined;

      /* ---------------------------------------------------------- latest */
      if (mode === "latest") {
        try {
          const page = Math.min(Math.max(Math.floor(params.page ?? 1), 1), 20);
          const results = await fetchLatestAnime(page, limit);
          return {
            content: [{ type: "text", text: formatListResult("latest", "", results) }],
            details: {
              mode,
              page,
              count: results.length,
              output_json: JSON.stringify({
                widget: "anime_list",
                mode: "latest",
                query: "",
                page,
                results: results.slice(0, MAX_LIST_ITEMS),
              }),
            },
          };
        } catch (error) {
          const message = error instanceof Error ? error.message : String(error);
          return {
            content: [
              {
                type: "text",
                text:
                  `Latest anime fetch failed: ${message}\n\n` +
                  "The anime sites are currently blocking requests. Try again in a " +
                  "moment, or search for a specific anime by name instead.",
              },
            ],
            details: { error: message },
          };
        }
      }

      /* --------------------------------------------------------- search */
      if (mode === "search") {
        const query = (params.query ?? "").trim();
        if (!query) {
          return {
            content: [{ type: "text", text: "Error: query is required for mode=search." }],
            details: { error: "missing query" },
          };
        }
        try {
          const results = await searchAnime(query, limit);
          return {
            content: [{ type: "text", text: formatListResult("search", query, results) }],
            details: {
              mode,
              query,
              count: results.length,
              output_json: JSON.stringify({
                widget: "anime_list",
                mode: "search",
                query,
                page: 1,
                results: results.slice(0, MAX_LIST_ITEMS),
              }),
            },
          };
        } catch (error) {
          const message = error instanceof Error ? error.message : String(error);
          return {
            content: [{ type: "text", text: `Anime search failed: ${message}` }],
            details: { error: message },
          };
        }
      }

      /* ---------------------------------------------------------- watch */
      const url = (params.url ?? "").trim();
      if (!url) {
        return {
          content: [
            {
              type: "text",
              text: "Error: an anime URL from a previous result is required for mode=watch.",
            },
          ],
          details: { error: "missing url" },
        };
      }
      try {
        const detail = await fetchAnimeEpisodes(url);
        const cancelled = aborted();
        if (cancelled) return cancelled;
        if (!detail || detail.episodes.length === 0) {
          return {
            content: [{ type: "text", text: `No episodes were found for that anime (${url}).` }],
            details: { error: "no episodes", url },
          };
        }

        // Episode-specific servers (AnimeLok fast path).
        const episodeNumber = params.episode;
        if (episodeNumber != null && url.startsWith(`${SOURCE_ANIMELOK}:`)) {
          const { fetchAnimeEpisodeServers } = await import("./anime.ts");
          const servers = await fetchAnimeEpisodeServers(
            url,
            Math.floor(episodeNumber),
            "",
          );
          const resolved = servers?.servers ?? [];
          if (resolved.length > 0) {
            const lines = resolved.map(
              (server, index) =>
                `  ${index + 1}. ${server.label}${server.language ? ` [${server.language}]` : ""} — ${playableUrl(server.url)}`,
            );
            return {
              content: [
                {
                  type: "text",
                  text: `${servers?.title || "Anime"} — episode ${episodeNumber} servers:\n${lines.join("\n")}`,
                },
              ],
              details: {
                mode,
                url,
                episode: episodeNumber,
                servers: resolved.length,
              },
            };
          }
          return {
            content: [
              {
                type: "text",
                text: `No stream servers were found for episode ${episodeNumber}.`,
              },
            ],
            details: { error: "no servers", url, episode: episodeNumber },
          };
        }

        return {
          content: [{ type: "text", text: formatWatchResult(detail) }],
          details: {
            mode,
            url,
            title: detail.title,
            episodes: detail.episodes.length,
            output_json: JSON.stringify({
              widget: "anime_player",
              mode: "episodes",
              title: detail.title,
              thumbnail: detail.thumbnail,
              source: detail.source,
              url: detail.url,
              description: detail.description,
              episodes: detail.episodes.slice(0, 300),
              servers: [],
              languages: [],
            }),
          },
        };
      } catch (error) {
        const message = error instanceof Error ? error.message : String(error);
        return {
          content: [{ type: "text", text: `Anime episode lookup failed: ${message}` }],
          details: { error: message },
        };
      }
    },
  });
}
