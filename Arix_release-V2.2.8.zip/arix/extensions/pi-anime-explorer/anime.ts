/**
 * Anime Explorer data layer (v2.2.7).
 *
 * Two sources with automatic fallback:
 *
 *   1. animelok.live — Next.js SSR site. Listings are parsed from the RSC
 *      flight payload; episodes and stream servers come from the site's own
 *      JSON API (/api/anime/<slug>/episodes/<n> → servers[] with direct
 *      .m3u8 streams or short.icu links).
 *   2. animesalt.cx (animesalt.ac redirects there) — WordPress. Search via
 *      ?s=, series pages list /episode/ links, episode pages carry an
 *      as-cdn iframe plus a base64-encoded player.php multi-language payload.
 *
 * Every request is DIRECT-first with content validation; public CORS proxies
 * are only a bounded fallback (same fix as the movie client — dead proxies
 * can never poison a result again).
 */

const ANIMELOK_BASE = "https://animelok.live";
const ANIMESALT_BASE = "https://animesalt.cx";

const BROWSER_UA =
  "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 " +
  "(KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36";

const PROXIES = [
  "https://cors.caliph.my.id/",
  "https://api.codetabs.com/v1/proxy?quest=",
  "https://api.allorigins.win/raw?url=",
  "https://proxy.it-mohmmed.workers.dev/?url=",
  "https://proxy.cskh-n8n.workers.dev/?url=",
];

export const SOURCE_ANIMELOK = "animelok";
export const SOURCE_ANIMESALT = "animesalt";

export interface AnimeItem {
  title: string;
  url: string; // site detail URL or animelok:/<slug> pseudo URL
  thumbnail: string;
  source: string;
  meta?: string;
}

export interface AnimeEpisode {
  number: number;
  name: string;
  url: string;
}

export interface AnimeServer {
  label: string;
  language: string;
  url: string;
}

export interface AnimeDetail {
  title: string;
  source: string;
  url: string;
  thumbnail: string;
  description: string;
  episodes: AnimeEpisode[];
}

export interface AnimeEpisodeServers {
  title: string;
  source: string;
  episodeNumber: number;
  episodeName: string;
  servers: AnimeServer[];
  languages: string[];
}

/* ------------------------------------------------------------ fetching */

function shuffle<T>(items: T[]): T[] {
  const copy = [...items];
  for (let i = copy.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [copy[i], copy[j]] = [copy[j], copy[i]];
  }
  return copy;
}

async function fetchDirect(url: string, timeoutMs: number): Promise<string> {
  const response = await fetch(url, {
    redirect: "follow",
    signal: AbortSignal.timeout(timeoutMs),
    headers: {
      "User-Agent": BROWSER_UA,
      Accept: "text/html,application/xhtml+xml,application/json;q=0.9,*/*;q=0.8",
      "Accept-Language": "en-US,en;q=0.9",
    },
  });
  if (!response.ok) throw new Error(`HTTP ${response.status}`);
  return await response.text();
}

async function fetchViaProxy(proxy: string, url: string, timeoutMs: number): Promise<string> {
  const response = await fetch(`${proxy}${url}`, {
    redirect: "follow",
    signal: AbortSignal.timeout(timeoutMs),
    headers: { "User-Agent": BROWSER_UA, Accept: "*/*" },
  });
  if (!response.ok) throw new Error(`HTTP ${response.status}`);
  return await response.text();
}

/** Direct first (with content validation), bounded proxies as fallback. */
export async function fetchPage(url: string, timeoutMs = 15_000): Promise<string> {
  const errors: string[] = [];
  try {
    const body = await fetchDirect(url, timeoutMs);
    if (body.length > 500) return body;
    errors.push("direct: response too short");
  } catch (error) {
    errors.push(`direct: ${error instanceof Error ? error.message : String(error)}`);
  }
  for (const proxy of shuffle(PROXIES).slice(0, 3)) {
    try {
      const body = await fetchViaProxy(proxy, url, Math.min(timeoutMs, 12_000));
      if (body.length > 500) return body;
      errors.push("proxy: response too short");
    } catch (error) {
      errors.push(`proxy: ${error instanceof Error ? error.message : String(error)}`);
    }
  }
  throw new Error(`All fetch attempts failed (${errors.slice(0, 3).join("; ")})`);
}

async function fetchJson(url: string, timeoutMs = 15_000): Promise<unknown> {
  return JSON.parse(await fetchPage(url, timeoutMs));
}

/* ------------------------------------------------------------- helpers */

export function decodeEntities(input: string): string {
  return input
    .replace(/&nbsp;/gi, " ")
    .replace(/&amp;/gi, "&")
    .replace(/&quot;/gi, '"')
    .replace(/&#0?39;|&apos;|&#x27;/gi, "'")
    .replace(/&lt;/gi, "<")
    .replace(/&gt;/gi, ">")
    .replace(/&#8211;|&ndash;/gi, "-")
    .replace(/&#8212;|&mdash;/gi, "-")
    .replace(/&#8216;|&#8217;|&lsquo;|&rsquo;/gi, "'")
    .replace(/&#8220;|&#8221;|&ldquo;|&rdquo;/gi, '"')
    .replace(/&#(\d+);/g, (_match, code: string) => {
      const value = Number.parseInt(code, 10);
      return Number.isFinite(value) ? String.fromCodePoint(value) : "";
    })
    .replace(/\s+/g, " ")
    .trim();
}

/** short.icu → abyssplayer embed (the exact transform the site performs). */
export function playableUrl(raw: string): string {
  let url = String(raw ?? "").trim();
  if (url.startsWith("//")) url = `https:${url}`;
  if (url.includes("short.icu") || url.includes("short.ink")) {
    url = url.replace(".ink", ".icu").replace("short.icu", "abyssplayer.com");
  }
  return url;
}

/* ------------------------------------------------- AnimeLok (Next.js) */

function parseAnimeLokCards(html: string): AnimeItem[] {
  const items: AnimeItem[] = [];
  const seen = new Set<string>();

  const pushes = [...html.matchAll(/self\.__next_f\.push\(\[1,"((?:[^"\\]|\\.)*)"\]\)/g)]
    .map((match) => match[1])
    .join("");
  const flight = pushes.replace(/\\"/g, '"').replace(/\\\\/g, "\\").replace(/\\n/g, " ");

  const cardRegex =
    /"href":"(\/anime\/[^"]+)"[\s\S]{0,400}?"slug":"([^"]+)"[\s\S]{0,900}?"src":"(https?:\/\/[^"]+)"[\s\S]{0,200}?"alt":"([^"]*)"/g;
  for (const match of flight.matchAll(cardRegex)) {
    const slug = match[2];
    if (!slug || seen.has(slug)) continue;
    const title = decodeEntities(match[4]);
    if (!title) continue;
    seen.add(slug);
    items.push({
      title,
      url: `${SOURCE_ANIMELOK}:${slug}`,
      thumbnail: match[3],
      source: SOURCE_ANIMELOK,
    });
  }

  // Fallback: plain SSR hrefs with img alt.
  if (items.length === 0) {
    const fallback =
      /href="(\/anime\/[^"]+)"[\s\S]{0,800}?<img[^>]+alt="([^"]{2,80})"[\s\S]{0,400}?(?:data-src|src)="(https?:\/\/[^"]+)"/gi;
    for (const match of html.matchAll(fallback)) {
      const slug = match[1].split("/").pop() ?? "";
      if (!slug || seen.has(slug)) continue;
      seen.add(slug);
      items.push({
        title: decodeEntities(match[2]),
        url: `${SOURCE_ANIMELOK}:${slug}`,
        thumbnail: match[3],
        source: SOURCE_ANIMELOK,
      });
    }
  }
  return items;
}

export async function animeLokLatest(page = 1, limit = 24): Promise<AnimeItem[]> {
  const normalized = Math.min(Math.max(page, 1), 30);
  const url = normalized <= 1
    ? `${ANIMELOK_BASE}/ongoing`
    : `${ANIMELOK_BASE}/ongoing?page=${normalized}`;
  return parseAnimeLokCards(await fetchPage(url)).slice(0, limit);
}

export async function animeLokSearch(query: string, limit = 24): Promise<AnimeItem[]> {
  const url = `${ANIMELOK_BASE}/search?keyword=${encodeURIComponent(query)}`;
  return parseAnimeLokCards(await fetchPage(url)).slice(0, limit);
}

/** Episodes for an AnimeLok slug via the site's JSON API (paged). */
export async function animeLokEpisodes(slug: string): Promise<AnimeEpisode[]> {
  const episodes: AnimeEpisode[] = [];
  const seen = new Set<number>();
  let page = 1;
  while (page <= 6) {
    let payload: Record<string, unknown> | undefined;
    try {
      payload = (await fetchJson(
        `${ANIMELOK_BASE}/api/anime/${slug}/episodes-range?page=${page}&pageSize=50`,
      )) as Record<string, unknown>;
    } catch {
      break;
    }
    const batch = (payload?.episodes as Array<Record<string, unknown>>) ?? [];
    if (batch.length === 0) break;
    for (const entry of batch) {
      const number = Number(entry.number ?? 0);
      if (!Number.isFinite(number) || number <= 0 || seen.has(number)) continue;
      seen.add(number);
      episodes.push({
        number,
        name: String(entry.name ?? ""),
        url: `${SOURCE_ANIMELOK}:${slug}#${number}`,
      });
    }
    const totalPages = Number(payload?.totalPages ?? page) || page;
    if (page >= totalPages) break;
    page += 1;
  }
  episodes.sort((a, b) => a.number - b.number);
  return episodes;
}

/** Stream servers for one AnimeLok episode via the site's JSON API. */
export async function animeLokEpisodeServers(
  slug: string,
  episode: number,
): Promise<AnimeEpisodeServers | null> {
  let payload: Record<string, unknown>;
  try {
    payload = (await fetchJson(`${ANIMELOK_BASE}/api/anime/${slug}/episodes/${episode}`)) as Record<
      string,
      unknown
    >;
  } catch {
    return null;
  }
  const anime = payload.anime as Record<string, unknown> | undefined;
  const episodeObj = payload.episode as Record<string, unknown> | undefined;
  const serversArray = (episodeObj?.servers as Array<Record<string, unknown>>) ?? [];
  const servers: AnimeServer[] = [];
  const languages = new Set<string>();
  serversArray.forEach((server, index) => {
    const url = String(server.url ?? "");
    if (!/^https?:\/\//.test(url)) return;
    const language = String(
      (server.languages as Array<string> | undefined)?.[0] ?? "",
    )
      .toLowerCase()
      .replace(/^./, (char) => char.toUpperCase());
    if (language) languages.add(language);
    const tip = String(server.tip ?? "");
    servers.push({
      label:
        (String(server.name ?? "") || `Server ${index + 1}`) +
        (tip && tip.toLowerCase() !== language.toLowerCase() ? ` · ${tip}` : ""),
      language,
      url,
    });
  });
  return {
    title: String(anime?.title ?? ""),
    source: SOURCE_ANIMELOK,
    episodeNumber: Number(episodeObj?.number ?? episode) || episode,
    episodeName: String(episodeObj?.name ?? ""),
    servers,
    languages: [...languages],
  };
}

/* ------------------------------------------------- AnimeSalt (WordPress) */

function parseAnimeSaltCards(html: string): AnimeItem[] {
  const items: AnimeItem[] = [];
  const seen = new Set<string>();

  for (const article of html.matchAll(/<article[\s\S]*?<\/article>/gi)) {
    const block = article[0];
    const link =
      block.match(/<a[^>]+href="(https?:\/\/[^"]+\/(?:series|movies|tvshows)\/[^"]+)"/i)?.[1] ??
      block.match(/<a[^>]+href="(https?:\/\/animesalt\.cx\/[^"]+)"/i)?.[1];
    if (!link || seen.has(link)) continue;
    seen.add(link);
    const title =
      decodeEntities(
        block.match(/<h2[^>]*class="[^"]*entry-title[^"]*"[^>]*>([\s\S]*?)<\/h2>/i)?.[1]?.replace(/<[^>]+>/g, "") ?? "",
      ) ||
      decodeEntities(
        block.match(/<h3[^>]*>([\s\S]*?)<\/h3>/i)?.[1]?.replace(/<[^>]+>/g, "") ?? "",
      ) ||
      decodeEntities(link.replace(/\/+$/, "").split("/").pop()?.replace(/-/g, " ") ?? "");
    const poster = [...block.matchAll(/(?:data-src|data-lazy-src|src)="(https?:\/\/[^"]+)"/gi)]
      .map((match) => match[1])
      .find((candidate) => /image\.tmdb\.org|\.jpe?g|\.png|\.webp/i.test(candidate)) ?? "";
    items.push({
      title,
      url: link,
      thumbnail: poster.startsWith("//") ? `https:${poster}` : poster,
      source: SOURCE_ANIMESALT,
    });
  }

  // chart-item blocks on the homepage
  if (items.length === 0) {
    const chartRegex =
      /<div class="chart-item">[\s\S]{0,1400}?<\/div>\s*<div class="chart-title">([^<]*)<\/div>/gi;
    for (const match of html.matchAll(chartRegex)) {
      const link = match[0].match(/href="(https?:\/\/animesalt\.cx\/[^"]+)"/i)?.[1];
      if (!link || seen.has(link)) continue;
      seen.add(link);
      items.push({
        title: decodeEntities(match[1]),
        url: link,
        thumbnail: match[0].match(/data-src="([^"]+)"/i)?.[1] ?? "",
        source: SOURCE_ANIMESALT,
      });
    }
  }
  return items;
}

export async function animeSaltLatest(page = 1, limit = 24): Promise<AnimeItem[]> {
  const normalized = Math.min(Math.max(page, 1), 30);
  const url = normalized <= 1
    ? `${ANIMESALT_BASE}/category/type/anime/`
    : `${ANIMESALT_BASE}/category/type/anime/page/${normalized}/`;
  return parseAnimeSaltCards(await fetchPage(url)).slice(0, limit);
}

export async function animeSaltSearch(query: string, limit = 24): Promise<AnimeItem[]> {
  const url = `${ANIMESALT_BASE}/?s=${encodeURIComponent(query)}`;
  return parseAnimeSaltCards(await fetchPage(url)).slice(0, limit);
}

/** Series/episode listing for an AnimeSalt detail URL. */
export async function animeSaltDetail(pageUrl: string): Promise<AnimeDetail | null> {
  const html = await fetchPage(pageUrl);
  const title =
    decodeEntities(
      html.match(/<h1[^>]*class="[^"]*entry-title[^"]*"[^>]*>([\s\S]*?)<\/h1>/i)?.[1]?.replace(/<[^>]+>/g, "") ?? "",
    ) ||
    decodeEntities(
      (html.match(/<title>([\s\S]*?)<\/title>/i)?.[1] ?? "")
        .split("–")[0]
        .split("|")[0]
        .trim(),
    );
  const poster = html.match(/(?:data-src|data-lazy-src|src)="(https?:\/\/image\.tmdb\.org[^"]+)"/i)?.[1] ?? "";
  const episodes: AnimeEpisode[] = [];
  const seen = new Set<string>();
  for (const match of html.matchAll(/href="(https?:\/\/[^"]*\/episode\/[^"]+)"/gi)) {
    const link = match[1];
    if (seen.has(link)) continue;
    seen.add(link);
    const seasonEpisode = link.split("/").pop()?.match(/(\d+)x(\d+)/);
    const number = seasonEpisode
      ? Number(seasonEpisode[1]) * 1000 + Number(seasonEpisode[2])
      : episodes.length + 1;
    episodes.push({ number, name: "", url: link });
  }
  if (episodes.length === 0) return null;
  episodes.sort((a, b) => a.number - b.number);
  return {
    title,
    source: SOURCE_ANIMESALT,
    url: pageUrl,
    thumbnail: poster,
    description: "",
    episodes,
  };
}

/** Stream servers for an AnimeSalt episode page (cdn iframe + base64 payload). */
export async function animeSaltEpisodeServers(
  episodeUrl: string,
): Promise<AnimeEpisodeServers | null> {
  const html = await fetchPage(episodeUrl);
  const servers: AnimeServer[] = [];
  const languages: string[] = [];

  const cdn = html.match(/<iframe[^>]+(?:data-src|src)="(https?:\/\/as-cdn[^"]+)"/i)?.[1];
  if (cdn) {
    servers.push({ label: "Main", language: "Auto", url: cdn });
    languages.push("Auto");
  }

  const encoded = html.match(/player\.php\?data=([A-Za-z0-9+/=]+)/)?.[1];
  if (encoded) {
    try {
      const decoded = Buffer.from(encoded, "base64").toString("utf-8");
      const entries = JSON.parse(decoded) as Array<Record<string, unknown>>;
      for (const entry of entries) {
        const language = String(entry.language ?? "");
        const link = String(entry.link ?? "");
        if (!/^https?:\/\//.test(link)) continue;
        servers.push({ label: `${language} · Stream`, language, url: link });
        if (language) languages.push(language);
      }
    } catch {
      // ignore malformed payloads
    }
  }

  if (servers.length === 0) return null;
  const title = decodeEntities(
    (html.match(/<title>([\s\S]*?)<\/title>/i)?.[1] ?? "")
      .split("–")[0]
      .split("|")[0]
      .trim(),
  );
  return {
    title,
    source: SOURCE_ANIMESALT,
    episodeNumber: 0,
    episodeName: "",
    servers,
    languages: [...new Set(languages)],
  };
}

/* ------------------------------------------------------------ public API */

/** Latest anime — AnimeLok first, AnimeSalt fallback. */
export async function fetchLatestAnime(page = 1, limit = 24): Promise<AnimeItem[]> {
  try {
    const primary = await animeLokLatest(page, limit);
    if (primary.length > 0) return primary;
  } catch {
    // fall through to AnimeSalt
  }
  return animeSaltLatest(page, limit);
}

/** Search anime — AnimeLok first, AnimeSalt fallback. */
export async function searchAnime(query: string, limit = 24): Promise<AnimeItem[]> {
  try {
    const primary = await animeLokSearch(query, limit);
    if (primary.length > 0) return primary;
  } catch {
    // fall through to AnimeSalt
  }
  return animeSaltSearch(query, limit);
}

/** Episode list for an anime item (either source). */
export async function fetchAnimeEpisodes(itemUrl: string): Promise<AnimeDetail | null> {
  if (itemUrl.startsWith(`${SOURCE_ANIMELOK}:`)) {
    const slug = itemUrl.slice(SOURCE_ANIMELOK.length + 1);
    const episodes = await animeLokEpisodes(slug);
    if (episodes.length === 0) return null;
    return {
      title: "",
      source: SOURCE_ANIMELOK,
      url: itemUrl,
      thumbnail: "",
      description: "",
      episodes,
    };
  }
  if (/^https?:\/\//.test(itemUrl)) {
    return animeSaltDetail(itemUrl);
  }
  return null;
}

/** Servers for one episode (either source). */
export async function fetchAnimeEpisodeServers(
  itemUrl: string,
  episode: number,
  episodeUrl: string,
): Promise<AnimeEpisodeServers | null> {
  if (itemUrl.startsWith(`${SOURCE_ANIMELOK}:`)) {
    const slug = itemUrl.slice(SOURCE_ANIMELOK.length + 1);
    return animeLokEpisodeServers(slug, episode);
  }
  if (/^https?:\/\//.test(episodeUrl)) {
    return animeSaltEpisodeServers(episodeUrl);
  }
  return null;
}
