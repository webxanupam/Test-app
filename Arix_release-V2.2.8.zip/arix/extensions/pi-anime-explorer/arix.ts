/**
 * Anime Explorer — Arix extension entry point (v2.2.7).
 *
 * Installs the host bridge and registers the anime_explorer tool titles.
 * The rich chat widgets (poster rail + episode/server player) render natively
 * from the tool's output_json payload, exactly like the movie explorer, so no
 * custom message types are required. A small settings page documents the
 * sources.
 */

type ArixJsonObject = Record<string, unknown>;
type ArixExtensionApi = {
  registerToolTitle?(
    toolName: string,
    runningTitle: string,
    completedTitle: string,
    priority?: number,
  ): () => void;
  registerSettings(definition: ArixJsonObject): () => void;
  notify(message: string, level?: "info" | "warning" | "error"): void;
  host: { invoke(method: string, args?: ArixJsonObject): Promise<ArixJsonObject> };
};

const SETTINGS_PAGE_ID = "anime-explorer-settings";

export const activateArix = async (arix: ArixExtensionApi) => {
  arix.registerToolTitle?.("anime_explorer", "Exploring anime", "Explored anime", 200);

  // Probe the host bridge once so misconfiguration surfaces immediately.
  try {
    await arix.host.invoke("app.getState", {});
  } catch {
    // Non-fatal: the Pi tool path still works without the Arix bridge.
  }

  try {
    arix.registerSettings({
      id: SETTINGS_PAGE_ID,
      title: "Anime Explorer",
      subtitle: "Anime search, latest series, and multi-server episode playback",
      icon: "play",
      order: 41,
      categories: [
        {
          id: "about",
          title: "About",
          subtitle: "Sources and behaviour",
          icon: "info",
          order: 0,
          sections: [
            {
              title: "Anime sources",
              description:
                "Anime is sourced from animelok.live (primary) with animesalt.cx as an " +
                "automatic fallback. Episode lists and stream servers come from the " +
                "site's own JSON API; embed links are played through the in-app player.",
              settings: [
                {
                  id: "source_note",
                  type: "label",
                  label: "Primary source",
                  description: "animelok.live — ongoing series, search, episodes, and stream servers",
                },
                {
                  id: "fallback_note",
                  type: "label",
                  label: "Fallback source",
                  description: "animesalt.cx — used automatically when the primary source is unreachable",
                },
                {
                  id: "usage_hint",
                  type: "label",
                  label: "How to use",
                  description:
                    "Ask the agent for the latest anime or search by name, then tap Watch on any poster.",
                },
              ],
            },
          ],
        },
      ],
    });
  } catch {
    // Settings registration is best-effort; older hosts may reject categories.
  }
};
