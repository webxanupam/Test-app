package com.arix.app.data

import android.Manifest
import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Point
import android.graphics.Rect
import android.hardware.display.DisplayManager
import android.media.AudioManager
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import android.telephony.TelephonyManager
import android.util.Base64
import android.view.accessibility.AccessibilityNodeInfo
import androidx.core.content.ContextCompat
import androidx.core.content.getSystemService
import com.arix.app.agentmode.AgentModeHudService
import com.arix.app.agentmode.ArixAccessibility
import com.arix.app.agentmode.ArixNotificationAccess
import java.io.ByteArrayOutputStream
import java.io.File
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject

private const val FallbackAgentDisplayWidth = 720
private const val FallbackAgentDisplayHeight = 1280
private const val AgentModeCaptureExtension = "jpg"
private const val AgentModeCaptureMimeType = "image/jpeg"
private const val AgentModeCaptureMaxEdge = 1280
private const val AgentModeCaptureJpegQuality = 85
private const val ScreenReadNodeLimit = 220
private const val ScreenReadDepthLimit = 40
private const val FindElementResultLimit = 24
private const val NotificationResultLimit = 40

/**
 * No-root Agent Mode controller.
 *
 * Every capability is built on public, user-authorized Android surfaces:
 *  - AccessibilityService for gestures, keys, text entry, screen reading,
 *    element lookup, and screenshots (Android 11+)
 *  - NotificationListenerService for notification access
 *  - Android Intents & App Actions for launching apps, URLs, and deep links
 *  - Direct framework APIs (AudioManager, BatteryManager, PowerManager, ...)
 *    for hardware and system control
 *  - WRITE_SETTINGS for system settings modification
 *  - TelecomManager (ANSWER_PHONE_CALLS) for call handling
 *  - SYSTEM_ALERT_WINDOW for the floating Agent Mode HUD
 *
 * The agent drives the real foreground screen; no root, Shizuku, or Termux
 * is involved anywhere.
 */
class AgentModeController(
    private val context: Context,
    private val runtimeWorkspaceFileBridge: RuntimeWorkspaceFileBridge,
    private val diagnosticLogger: ArixDiagnosticLogger = ArixDiagnosticLogger.NoOp,
) {
    private val appContext = context.applicationContext
    private val displayManager = appContext.getSystemService<DisplayManager>()!!
    private val audioManager = appContext.getSystemService<AudioManager>()!!
    private val cacheDirectory = File(appContext.cacheDir, "agent-mode").apply { mkdirs() }
    private val controllerScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val captureMutex = Mutex()
    private val _displayState = MutableStateFlow(AgentModeDisplayState())
    private val _authorizationState = MutableStateFlow(AgentModeAuthorizationState())

    val displayState: StateFlow<AgentModeDisplayState> = _displayState.asStateFlow()
    val authorizationState: StateFlow<AgentModeAuthorizationState> = _authorizationState.asStateFlow()

    init {
        _displayState.value = AgentModeDisplayState(
            isActive = false,
            displays = currentDisplaysLocal(),
            status = "Agent Mode is idle.",
            lastUpdatedMillis = System.currentTimeMillis(),
        )
    }

    suspend fun execute(
        settings: AppSettings,
        workspaceDirectory: String,
        argumentsJson: String,
    ): String = withContext(Dispatchers.IO) {
        if (!settings.agentModeAuthorizationEnabled) {
            captureAgentModeFailed(
                settings = settings,
                action = "unknown",
                reason = "authorization_disabled",
                message = "Agent Mode is not authorized.",
            )
            return@withContext JSONObject().apply {
                put("ok", false)
                put("errmsg", "Agent Mode is not authorized. Enable it in Settings > Agent Mode first.")
            }.toString()
        }

        val arguments = runCatching { JSONObject(argumentsJson) }.getOrNull()
            ?: return@withContext invalidArguments("Arguments were not valid JSON.").also {
                captureAgentModeFailed(
                    settings = settings,
                    action = "unknown",
                    reason = "invalid_arguments",
                    message = "Arguments were not valid JSON.",
                )
            }
        val action = arguments.optString("action").trim().lowercase()
        diagnosticLogger.event(
            category = "agent_mode",
            event = "action_start",
            details = mapOf(
                "action" to action.ifBlank { "unknown" },
                "accessibility_running" to ArixAccessibility.isRunning,
            ),
        )

        runCatching {
            when (action) {
                "start" -> {
                    startSession(settings)
                    captureAfterDelay(settings, workspaceDirectory, delayMillis = 600)
                }

                "stop" -> stopSessionResult()

                "status" -> statusResult(settings)

                "list_apps", "apps", "installed_apps" -> listInstalledAppsResult(arguments)

                "launch" -> {
                    val target = arguments.optString("target").trim()
                    if (target.isBlank()) {
                        invalidArguments("Missing required 'target' argument.")
                    } else {
                        launchTarget(target)
                        captureAfterDelay(settings, workspaceDirectory, delayMillis = 900)
                    }
                }

                "open" -> {
                    val url = arguments.optString("url").trim()
                        .ifBlank { arguments.optString("uri").trim() }
                        .ifBlank { arguments.optString("target").trim() }
                    if (url.isBlank()) {
                        invalidArguments("Missing required 'url' argument for the open action.")
                    } else {
                        openUri(url)
                        captureAfterDelay(settings, workspaceDirectory, delayMillis = 900)
                    }
                }

                "tap" -> {
                    requireSession()
                    val x = arguments.optDouble("x", Double.NaN)
                    val y = arguments.optDouble("y", Double.NaN)
                    if (x.isNaN() || y.isNaN()) {
                        invalidArguments("Both 'x' and 'y' are required, using 0..1000 screen coordinates.")
                    } else {
                        tapAt(settings, workspaceDirectory, x, y)
                    }
                }

                "swipe" -> {
                    requireSession()
                    val x1 = arguments.optDouble("x1", Double.NaN)
                    val y1 = arguments.optDouble("y1", Double.NaN)
                    val x2 = arguments.optDouble("x2", Double.NaN)
                    val y2 = arguments.optDouble("y2", Double.NaN)
                    val durationMs = arguments.optInt("duration_ms", arguments.optInt("durationMs", 500))
                        .coerceIn(50, 10_000)
                    if (x1.isNaN() || y1.isNaN() || x2.isNaN() || y2.isNaN()) {
                        invalidArguments("x1, y1, x2, and y2 are required, using 0..1000 screen coordinates.")
                    } else {
                        swipeTo(
                            settings = settings,
                            workspaceDirectory = workspaceDirectory,
                            x1 = x1,
                            y1 = y1,
                            x2 = x2,
                            y2 = y2,
                            durationMs = durationMs,
                        )
                    }
                }

                "key" -> {
                    requireSession()
                    val keyName = arguments.optString("key").trim().lowercase()
                    if (keyName.isBlank()) {
                        invalidArguments("Missing required 'key' argument.")
                    } else {
                        pressKeyResult(settings, workspaceDirectory, keyName)
                    }
                }

                "text" -> {
                    requireSession()
                    val text = arguments.optString("text")
                    if (text.isBlank()) {
                        invalidArguments("Missing required 'text' argument.")
                    } else {
                        inputTextResult(settings, workspaceDirectory, text)
                    }
                }

                "screenshot" -> {
                    requireSession()
                    captureAfterDelay(settings, workspaceDirectory, delayMillis = 0)
                }

                "read_screen" -> readScreenResult()

                "find_element", "find_elements" ->
                    findElementResult(settings, workspaceDirectory, arguments, click = false)

                "click_element" -> {
                    requireSession()
                    findElementResult(settings, workspaceDirectory, arguments, click = true)
                }

                "notifications" -> notificationsResult(arguments)

                "device_info" -> deviceInfoResult()

                "volume" -> volumeResult(arguments)

                "settings" -> systemSettingsResult(arguments)

                "call" -> callResult(arguments)

                "hud" -> hudResult(arguments)

                else -> invalidArguments("Unsupported action '$action'.").also {
                    captureAgentModeFailed(
                        settings = settings,
                        action = action.ifBlank { "unknown" },
                        reason = "unsupported_action",
                        message = "Unsupported action '$action'.",
                    )
                }
            }.also { raw ->
                val result = runCatching { JSONObject(raw) }.getOrNull()
                diagnosticLogger.event(
                    category = "agent_mode",
                    event = "action_end",
                    level = if (result?.optBoolean("ok", true) == false) "warn" else "info",
                    details = mapOf(
                        "action" to action.ifBlank { "unknown" },
                        "ok" to (result?.optBoolean("ok", true) ?: true),
                        "session_active" to _displayState.value.isActive,
                        "message" to result?.optString("errmsg").orEmpty(),
                    ),
                )
            }
        }.getOrElse { throwable ->
            captureAgentModeFailed(
                settings = settings,
                action = action.ifBlank { "unknown" },
                reason = "exception",
                message = throwable.message ?: throwable.javaClass.simpleName,
            )
            toolError(
                message = throwable.message ?: throwable.javaClass.simpleName,
                action = action,
            )
        }
    }

    suspend fun refreshAuthorization(settings: AppSettings) {
        _authorizationState.value = inspectAuthorization(settings).also { state ->
            diagnosticLogger.event(
                category = "agent_mode",
                event = "authorization_refreshed",
                level = if (state.isReady || state.issue == AgentModeAuthorizationIssue.Disabled) {
                    "info"
                } else {
                    "warn"
                },
                details = mapOf(
                    "issue" to state.issue.name,
                    "detail" to state.detail,
                    "enabled" to settings.agentModeAuthorizationEnabled,
                    "accessibility_running" to ArixAccessibility.isRunning,
                ),
            )
        }
        if (!ArixAccessibility.isRunning) {
            stopSession("Agent Mode stopped because the Arix accessibility service is not running.")
        }
        val screenSize = currentScreenSize()
        val state = _displayState.value
        if (state.width != screenSize.first || state.height != screenSize.second) {
            _displayState.value = state.copy(
                width = screenSize.first,
                height = screenSize.second,
                displays = currentDisplaysLocal(),
                lastUpdatedMillis = System.currentTimeMillis(),
            )
        }
    }

    fun stopSession(status: String = "Agent Mode stopped.") {
        controllerScope.launch {
            AgentModeHudService.stop(appContext)
            _displayState.value = AgentModeDisplayState(
                isActive = false,
                width = _displayState.value.width,
                height = _displayState.value.height,
                displays = currentDisplaysLocal(),
                status = status,
                lastUpdatedMillis = System.currentTimeMillis(),
            )
        }
    }

    fun sessionCapabilities(): JSONObject = JSONObject().apply {
        put("accessibility", ArixAccessibility.isRunning)
        put("notifications", ArixNotificationAccess.isRunning)
        put("overlay", Settings.canDrawOverlays(appContext))
        put("write_settings", Settings.System.canWrite(appContext))
        put("phone_state", hasPermission(Manifest.permission.READ_PHONE_STATE))
        put("answer_calls", hasPermission(Manifest.permission.ANSWER_PHONE_CALLS))
        put("screenshot", Build.VERSION.SDK_INT >= Build.VERSION_CODES.R)
    }

    // ──────────────────────────────────────────────────────────────────────────
    // Session lifecycle
    // ──────────────────────────────────────────────────────────────────────────

    private fun startSession(settings: AppSettings): String {
        if (!ArixAccessibility.isRunning) {
            error(
                "The Arix accessibility service is not enabled. Enable it in Settings > Agent Mode " +
                    "(or Android Settings > Accessibility) and try again."
            )
        }
        val screenSize = currentScreenSize()
        _displayState.value = AgentModeDisplayState(
            isActive = true,
            displayId = null,
            width = screenSize.first,
            height = screenSize.second,
            displays = currentDisplaysLocal(),
            lastUpdatedMillis = System.currentTimeMillis(),
            status = "Agent Mode session active on the real screen.",
        )
        if (Settings.canDrawOverlays(appContext)) {
            AgentModeHudService.start(appContext)
        }
        return JSONObject().apply {
            put("ok", true)
            put("active", true)
            put("width", screenSize.first)
            put("height", screenSize.second)
            put("capabilities", sessionCapabilities())
            put(
                "stdout",
                "Agent Mode session started. The agent now controls the real screen; " +
                    "coordinate ranges are normalized 0..1000.",
            )
        }.toString()
    }

    private fun stopSessionResult(): String {
        stopSession()
        return JSONObject().apply {
            put("ok", true)
            put("stdout", "Agent Mode session stopped.")
        }.toString()
    }

    private fun requireSession() {
        if (!ArixAccessibility.isRunning) {
            error(
                "The Arix accessibility service is not enabled. Enable it in Settings > Agent Mode " +
                    "(or Android Settings > Accessibility) and try again."
            )
        }
        val screenSize = currentScreenSize()
        _displayState.value = _displayState.value.copy(
            isActive = true,
            width = screenSize.first,
            height = screenSize.second,
            lastUpdatedMillis = System.currentTimeMillis(),
        )
    }

    private fun statusResult(settings: AppSettings): String {
        val state = _displayState.value
        return JSONObject().apply {
            put("ok", true)
            put("active", state.isActive)
            put("authorized", settings.agentModeAuthorizationEnabled)
            put("width", state.width)
            put("height", state.height)
            put("screenshot_path", state.latestWorkspacePath)
            put("capabilities", sessionCapabilities())
            put(
                "foreground_app",
                ArixAccessibility.service()?.lastWindowPackage.orEmpty(),
            )
            put(
                "stdout",
                if (state.isActive) {
                    "Agent Mode session is active on the real screen."
                } else {
                    "Agent Mode session is stopped."
                },
            )
        }.toString()
    }

    // ──────────────────────────────────────────────────────────────────────────
    // Apps and intents
    // ──────────────────────────────────────────────────────────────────────────

    private suspend fun listInstalledAppsResult(arguments: JSONObject): String {
        val query = arguments.optString("query").trim()
        val normalizedQuery = query.lowercase()
        val includeSystem = arguments.optBoolean(
            "include_system",
            arguments.optBoolean("includeSystem", true),
        )
        val maxResults = arguments.optInt(
            "max_results",
            arguments.optInt("maxResults", 500),
        ).coerceIn(1, 1_000)
        val apps = currentInstalledApps()
            .asSequence()
            .filter { includeSystem || !it.isSystemApp }
            .filter { app ->
                normalizedQuery.isBlank() ||
                    app.packageName.lowercase().contains(normalizedQuery) ||
                    app.appName.lowercase().contains(normalizedQuery) ||
                    app.activityName.lowercase().contains(normalizedQuery)
            }
            .toList()
        val visibleApps = apps.take(maxResults)
        return JSONObject().apply {
            put("ok", true)
            put("count", apps.size)
            put("truncated", apps.size > visibleApps.size)
            put(
                "apps",
                JSONArray().apply {
                    visibleApps.forEach { app ->
                        put(
                            JSONObject().apply {
                                put("app_name", app.appName)
                                put("package_name", app.packageName)
                                put("activity_name", app.activityName)
                                put("enabled", app.isEnabled)
                                put("system", app.isSystemApp)
                                put("launchable", true)
                            }
                        )
                    }
                },
            )
            put(
                "stdout",
                buildString {
                    append("Found ")
                    append(apps.size)
                    append(if (includeSystem) " launchable apps." else " non-system launchable apps.")
                    if (apps.size > visibleApps.size) {
                        append(" Showing ")
                        append(visibleApps.size)
                        append(".")
                    }
                    visibleApps.forEach { app ->
                        append('\n')
                        append(app.appName)
                        append(" -> ")
                        append(app.packageName)
                    }
                },
            )
        }.toString()
    }

    @Suppress("DEPRECATION")
    private fun currentInstalledApps(): List<AgentModeInstalledAppInfo> {
        val packageManager = appContext.packageManager
        val launcherIntent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return packageManager.queryIntentActivities(
            launcherIntent,
            PackageManager.MATCH_DISABLED_COMPONENTS,
        ).mapNotNull { info ->
            val activityInfo = info.activityInfo ?: return@mapNotNull null
            val applicationInfo = activityInfo.applicationInfo ?: return@mapNotNull null
            AgentModeInstalledAppInfo(
                packageName = activityInfo.packageName.orEmpty(),
                appName = info.loadLabel(packageManager).toString(),
                activityName = activityInfo.name.orEmpty(),
                isSystemApp = applicationInfo.flags and ApplicationInfo.FLAG_SYSTEM != 0,
                isEnabled = activityInfo.enabled && applicationInfo.enabled,
            )
        }
            .distinctBy { it.packageName }
            .sortedWith(compareBy({ it.appName.lowercase() }, { it.packageName }))
    }

    private fun launchTarget(target: String) {
        val launchPackage = resolveLaunchPackage(target)
            ?: error(
                "No launchable app matched '$target'. Try a package name such as com.android.chrome, " +
                    "or a shorter app label."
            )
        val intent = appContext.packageManager.getLaunchIntentForPackage(launchPackage)
            ?: error("No launchable activity for $launchPackage.")
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        runCatching { appContext.startActivity(intent) }
            .onFailure { error("Could not launch $launchPackage: ${it.message}") }
    }

    private fun resolveLaunchPackage(target: String): String? {
        val normalizedTarget = target.trim().lowercase()
        if (normalizedTarget.isBlank()) return null
        appContext.packageManager.getLaunchIntentForPackage(target)?.let { return target }

        val launchables = currentInstalledApps()
        val tokens = normalizedTarget.split(Regex("\\s+"))
            .filter { it.length > 2 && it !in setOf("app", "browser") }
        return launchables.firstOrNull { app ->
            app.packageName.equals(normalizedTarget, ignoreCase = true) ||
                app.appName.equals(target, ignoreCase = true)
        }?.packageName ?: launchables.firstOrNull { app ->
            app.packageName.lowercase().contains(normalizedTarget) ||
                app.appName.lowercase().contains(normalizedTarget) ||
                app.activityName.lowercase().contains(normalizedTarget) ||
                tokens.any { token ->
                    app.packageName.lowercase().contains(token) ||
                        app.appName.lowercase().contains(token) ||
                        app.activityName.lowercase().contains(token)
                }
        }?.packageName ?: target.takeIf {
            it.matches(Regex("""[A-Za-z][A-Za-z0-9_]*(\.[A-Za-z0-9_]+)+"""))
        }
    }

    private fun openUri(url: String) {
        val normalized = if (url.contains("://") || url.startsWith("mailto:") || url.startsWith("tel:")) {
            url
        } else {
            "https://$url"
        }
        val uri = runCatching { Uri.parse(normalized) }.getOrNull()
            ?: error("'$url' could not be parsed as a URI.")
        val intent = Intent(Intent.ACTION_VIEW, uri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        val resolved = appContext.packageManager.resolveActivity(
            intent,
            PackageManager.MATCH_DEFAULT_ONLY,
        )
        if (resolved == null) {
            error("No app is available to open '$normalized'.")
        }
        runCatching { appContext.startActivity(intent) }
            .onFailure { error("Could not open '$normalized': ${it.message}") }
    }

    // ──────────────────────────────────────────────────────────────────────────
    // Gestures, keys, text
    // ──────────────────────────────────────────────────────────────────────────

    private suspend fun tapAt(
        settings: AppSettings,
        workspaceDirectory: String,
        x: Double,
        y: Double,
    ): String {
        val service = requireAccessibility()
        val screenSize = currentScreenSize()
        val px = normalizeCoordinate(x, screenSize.first)
        val py = normalizeCoordinate(y, screenSize.second)
        service.tap(px.toFloat(), py.toFloat())
        updateCursorPosition(px, py, animationDurationMillis = 180)
        return captureAfterDelay(settings, workspaceDirectory, delayMillis = 350)
    }

    private suspend fun swipeTo(
        settings: AppSettings,
        workspaceDirectory: String,
        x1: Double,
        y1: Double,
        x2: Double,
        y2: Double,
        durationMs: Int,
    ): String {
        val service = requireAccessibility()
        val screenSize = currentScreenSize()
        val px1 = normalizeCoordinate(x1, screenSize.first)
        val py1 = normalizeCoordinate(y1, screenSize.second)
        val px2 = normalizeCoordinate(x2, screenSize.first)
        val py2 = normalizeCoordinate(y2, screenSize.second)
        updateCursorPosition(px1, py1, animationDurationMillis = 80)
        controllerScope.launch {
            delay(40)
            updateCursorPosition(px2, py2, animationDurationMillis = durationMs)
        }
        service.swipe(
            fromX = px1.toFloat(),
            fromY = py1.toFloat(),
            toX = px2.toFloat(),
            toY = py2.toFloat(),
            durationMillis = durationMs.toLong(),
        )
        return captureAfterDelay(
            settings,
            workspaceDirectory,
            delayMillis = durationMs.toLong() + 250,
        )
    }

    private suspend fun pressKeyResult(
        settings: AppSettings,
        workspaceDirectory: String,
        keyName: String,
    ): String {
        val service = requireAccessibility()
        val actionId = when (keyName) {
            "back" -> AccessibilityService.GLOBAL_ACTION_BACK
            "home" -> AccessibilityService.GLOBAL_ACTION_HOME
            "recents", "overview", "multitasking", "app_switcher" ->
                AccessibilityService.GLOBAL_ACTION_RECENTS
            "notifications", "notification_shade" ->
                AccessibilityService.GLOBAL_ACTION_NOTIFICATIONS
            "quick_settings" -> AccessibilityService.GLOBAL_ACTION_QUICK_SETTINGS
            "power_dialog", "power_menu" -> AccessibilityService.GLOBAL_ACTION_POWER_DIALOG
            "split_screen", "split_screen_mode" ->
                AccessibilityService.GLOBAL_ACTION_TOGGLE_SPLIT_SCREEN
            "lock_screen", "lock" ->
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                    AccessibilityService.GLOBAL_ACTION_LOCK_SCREEN
                } else {
                    null
                }

            "take_screenshot", "screenshot" ->
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                    AccessibilityService.GLOBAL_ACTION_TAKE_SCREENSHOT
                } else {
                    null
                }

            else -> null
        } ?: return invalidArguments(
            "Unsupported key '$keyName'. Supported keys: back, home, recents, notifications, " +
                "quick_settings, power_dialog, split_screen, lock_screen (Android 9+), " +
                "take_screenshot (Android 9+)."
        )
        val accepted = service.globalAction(actionId)
        if (!accepted) {
            error("The system rejected the '$keyName' global action.")
        }
        return captureAfterDelay(settings, workspaceDirectory, delayMillis = 300)
    }

    private suspend fun inputTextResult(
        settings: AppSettings,
        workspaceDirectory: String,
        text: String,
    ): String {
        val service = requireAccessibility()
        val node = service.focusedEditableNode()
            ?: error(
                "No focused text field was found. Tap a text field first, then type. " +
                    "Fields inside secure screens (banking apps, PIN entry) cannot be automated."
            )
        val arguments = android.os.Bundle()
        arguments.putCharSequence(
            AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE,
            text,
        )
        val setResult = runCatching { node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, arguments) }
            .getOrDefault(false)
        if (!setResult) {
            error("The focused field did not accept text input.")
        }
        return captureAfterDelay(settings, workspaceDirectory, delayMillis = 350)
    }

    // ──────────────────────────────────────────────────────────────────────────
    // Screen reading, element lookup, screenshots
    // ──────────────────────────────────────────────────────────────────────────

    private fun readScreenResult(): String {
        if (!ArixAccessibility.isRunning) {
            error(
                "The Arix accessibility service is not enabled. Enable it in Settings > Agent Mode " +
                    "and try again."
            )
        }
        val service = requireAccessibility()
        val screenSize = currentScreenSize()
        val elements = collectScreenElements(service.rootWindowNode(), screenSize)
        val stdout = buildString {
            append("Read ")
            append(elements.length())
            append(" interactive screen elements")
            val pkg = service.lastWindowPackage
            if (pkg.isNotBlank()) {
                append(" in ")
                append(pkg)
            }
            append(".")
            for (index in 0 until minOf(elements.length(), 30)) {
                val element = elements.optJSONObject(index) ?: continue
                val text = element.optString("text")
                if (text.isNotBlank()) {
                    append('\n')
                    append("- ")
                    append(text.take(60))
                }
            }
        }
        return JSONObject().apply {
            put("ok", true)
            put("count", elements.length())
            put("foreground_app", service.lastWindowPackage)
            put("elements", elements)
            put("stdout", stdout)
        }.toString()
    }

    private fun collectScreenElements(
        root: AccessibilityNodeInfo?,
        screenSize: Pair<Int, Int>,
    ): JSONArray {
        val result = JSONArray()
        if (root == null) return result
        val queue = ArrayDeque<Pair<AccessibilityNodeInfo, Int>>()
        queue.add(root to 0)
        var emitted = 0
        while (queue.isNotEmpty() && emitted < ScreenReadNodeLimit) {
            val (node, depth) = queue.removeFirst()
            if (depth > ScreenReadDepthLimit) continue
            val text = node.text?.toString().orEmpty()
            val description = node.contentDescription?.toString().orEmpty()
            val interesting = text.isNotBlank() ||
                description.isNotBlank() ||
                node.isClickable ||
                node.isScrollable ||
                node.isEditable ||
                node.isCheckable
            if (interesting) {
                val bounds = Rect().also { node.getBoundsInScreen(it) }
                if (bounds.isEmpty.not() || text.isNotBlank() || description.isNotBlank()) {
                    result.put(
                        JSONObject().apply {
                            if (text.isNotBlank()) put("text", text.take(160))
                            if (description.isNotBlank()) put("description", description.take(160))
                            node.viewIdResourceName?.let { put("view_id", it) }
                            node.className?.toString()?.substringAfterLast('.')?.let { put("class", it) }
                            if (node.isClickable) put("clickable", true)
                            if (node.isScrollable) put("scrollable", true)
                            if (node.isEditable) put("editable", true)
                            if (node.isCheckable) put("checkable", true)
                            if (node.isChecked) put("checked", true)
                            if (node.isPassword) put("password", true)
                            if (!bounds.isEmpty) {
                                put(
                                    "bounds",
                                    JSONObject().apply {
                                        put("x", normalizePixel(bounds.centerX(), screenSize.first))
                                        put("y", normalizePixel(bounds.centerY(), screenSize.second))
                                        put(
                                            "width",
                                            (bounds.width() * 1000.0 / screenSize.first.coerceAtLeast(1))
                                                .toInt().coerceIn(0, 1000),
                                        )
                                        put(
                                            "height",
                                            (bounds.height() * 1000.0 / screenSize.second.coerceAtLeast(1))
                                                .toInt().coerceIn(0, 1000),
                                        )
                                    },
                                )
                            }
                        }
                    )
                    emitted++
                }
            }
            for (childIndex in 0 until node.childCount) {
                node.getChild(childIndex)?.let { child -> queue.add(child to depth + 1) }
            }
        }
        return result
    }

    private suspend fun findElementResult(
        settings: AppSettings,
        workspaceDirectory: String,
        arguments: JSONObject,
        click: Boolean,
    ): String {
        if (!ArixAccessibility.isRunning) {
            error(
                "The Arix accessibility service is not enabled. Enable it in Settings > Agent Mode " +
                    "and try again."
            )
        }
        val service = requireAccessibility()
        val query = arguments.optString("query").trim()
            .ifBlank { arguments.optString("text").trim() }
        val viewId = arguments.optString("view_id").trim()
            .ifBlank { arguments.optString("id").trim() }
        if (query.isBlank() && viewId.isBlank()) {
            return invalidArguments("Provide 'query' (text or description match) or 'view_id'.")
        }
        val screenSize = currentScreenSize()
        val matches = findAllMatches(service.rootWindowNode(), query, viewId)
            .take(FindElementResultLimit)
        if (matches.isEmpty()) {
            error(
                buildString {
                    append("No screen element matched ")
                    append(if (query.isNotBlank()) "text '$query'" else "view id '$viewId'")
                    append(". Use read_screen to inspect the current screen contents.")
                }
            )
        }
        if (!click) {
            return JSONObject().apply {
                put("ok", true)
                put("count", matches.size)
                put("elements", JSONArray().apply { matches.forEach { put(it.json) } })
                put("stdout", "Found ${matches.size} matching elements.")
            }.toString()
        }
        val target = matches.first()
        val clicked = clickNode(target.node)
        if (!clicked) {
            val bounds = target.bounds
            if (bounds != null && !bounds.isEmpty) {
                val px = bounds.centerX().toFloat()
                val py = bounds.centerY().toFloat()
                service.tap(px, py)
                updateCursorPosition(px.toInt(), py.toInt())
                val fallbackNote = "Clicked element by tapping the center of its bounds."
                val base = clickedResult(target, fallbackNote)
                return if (base != null) {
                    mergeCapture(base, settings, workspaceDirectory)
                } else {
                    base ?: error("The matched element could not be clicked.")
                }
            }
            error("The matched element could not be clicked.")
        }
        val base = clickedResult(target, "Clicked the matched element through accessibility actions.")
        if (base == null) {
            error("The matched element could not be clicked.")
        }
        return mergeCapture(base, settings, workspaceDirectory)
    }

    private fun clickedResult(
        target: ScreenElementMatch,
        message: String,
    ): String? = runCatching {
        JSONObject().apply {
            put("ok", true)
            put("element", target.json)
            put("stdout", message)
        }.toString()
    }.getOrNull()

    private suspend fun mergeCapture(
        base: String,
        settings: AppSettings,
        workspaceDirectory: String,
    ): String {
        val captured = runCatching { captureAfterDelay(settings, workspaceDirectory, delayMillis = 600) }
            .getOrNull()
        return if (captured == null) {
            base
        } else {
            runCatching {
                val baseJson = JSONObject(base)
                val capturedJson = JSONObject(captured)
                capturedJson.keys().forEach { key -> baseJson.put(key, capturedJson.get(key)) }
                baseJson.put("ok", true)
                baseJson.put("stdout", JSONObject(base).optString("stdout"))
                baseJson.toString()
            }.getOrDefault(base)
        }
    }

    private fun clickNode(node: AccessibilityNodeInfo): Boolean {
        var current: AccessibilityNodeInfo? = node
        var depth = 0
        while (current != null && depth < 6) {
            if (current.isClickable && current.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
                return true
            }
            current = current.parent
            depth++
        }
        return false
    }

    private fun findAllMatches(
        root: AccessibilityNodeInfo?,
        query: String,
        viewId: String,
    ): List<ScreenElementMatch> {
        if (root == null) return emptyList()
        val screenSize = currentScreenSize()
        val normalizedQuery = query.lowercase()
        val normalizedViewId = viewId.lowercase()
        val matches = mutableListOf<ScreenElementMatch>()
        val queue = ArrayDeque<AccessibilityNodeInfo>()
        queue.add(root)
        var visited = 0
        while (queue.isNotEmpty() && visited < ScreenReadNodeLimit * 3) {
            val node = queue.removeFirst()
            visited++
            val text = node.text?.toString().orEmpty()
            val description = node.contentDescription?.toString().orEmpty()
            val nodeViewId = node.viewIdResourceName.orEmpty()
            val textMatches = normalizedQuery.isNotBlank() && (
                text.lowercase().contains(normalizedQuery) ||
                    description.lowercase().contains(normalizedQuery)
                )
            val idMatches = normalizedViewId.isNotBlank() && nodeViewId.lowercase().contains(normalizedViewId)
            if (textMatches || idMatches) {
                matches += ScreenElementMatch(
                    node = node,
                    json = JSONObject().apply {
                        if (text.isNotBlank()) put("text", text.take(160))
                        if (description.isNotBlank()) put("description", description.take(160))
                        if (nodeViewId.isNotBlank()) put("view_id", nodeViewId)
                        node.className?.toString()?.substringAfterLast('.')?.let { put("class", it) }
                        if (node.isClickable) put("clickable", true)
                    },
                    bounds = Rect().also { node.getBoundsInScreen(it) },
                )
                if (matches.size >= FindElementResultLimit) break
            }
            for (childIndex in 0 until node.childCount) {
                node.getChild(childIndex)?.let { queue.add(it) }
            }
        }
        // Best match first: exact label match, then starts-with, then contains.
        return matches.sortedWith(
            compareByDescending<ScreenElementMatch> { match ->
                when {
                    match.json.optString("text").equals(query, ignoreCase = true) -> 3
                    match.json.optString("text").startsWith(query, ignoreCase = true) -> 2
                    else -> 1
                }
            }
        )
    }

    private suspend fun captureAfterDelay(
        settings: AppSettings,
        workspaceDirectory: String,
        delayMillis: Long,
    ): String {
        if (delayMillis > 0) delay(delayMillis)
        val captureId = "capture-${System.currentTimeMillis()}"
        val previewFile = File(cacheDirectory, "$captureId.$AgentModeCaptureExtension")
        captureImageFile(previewFile)
        if (!previewFile.isFile || previewFile.length() <= 0L) {
            error("Agent Mode screenshot capture produced an empty file.")
        }
        val bytes = previewFile.readBytes()
        val latestPreviewFile = File(cacheDirectory, "latest.$AgentModeCaptureExtension")
        previewFile.copyTo(latestPreviewFile, overwrite = true)
        val previewPath = previewFile.absolutePath
        val workspacePath = "$workspaceDirectory/agent-mode/$captureId.$AgentModeCaptureExtension"
        runtimeWorkspaceFileBridge.writeWorkspaceBytes(
            settings = settings,
            absolutePath = workspacePath,
            bytes = bytes,
        ).getOrThrow()
        val state = _displayState.value
        _displayState.value = state.copy(
            latestPreviewPath = previewPath,
            latestWorkspacePath = workspacePath,
            lastUpdatedMillis = System.currentTimeMillis(),
            status = "Captured screen",
        )
        return JSONObject().apply {
            put("ok", true)
            put("width", state.width)
            put("height", state.height)
            put("screenshot_path", workspacePath)
            put("preview_path", previewPath)
            state.cursorX?.let { put("cursor_x", it) }
            state.cursorY?.let { put("cursor_y", it) }
            put("screenshot_mime_type", AgentModeCaptureMimeType)
            put("screenshot_base64", Base64.encodeToString(bytes, Base64.NO_WRAP))
            put("stdout", "Captured screen screenshot: $workspacePath")
        }.toString()
    }

    private fun updateCursorPosition(
        x: Int,
        y: Int,
        animationDurationMillis: Int = 220,
    ) {
        val state = _displayState.value
        _displayState.value = state.copy(
            cursorX = x.coerceIn(0, state.width),
            cursorY = y.coerceIn(0, state.height),
            cursorAnimationDurationMillis = animationDurationMillis.coerceIn(80, 1_200),
            lastUpdatedMillis = System.currentTimeMillis(),
        )
    }

    private suspend fun captureImageFile(outputFile: File) {
        val service = requireAccessibility()
        captureMutex.withLock {
            outputFile.parentFile?.mkdirs()
            runCatching { outputFile.delete() }
            val bitmap = service.captureScreen()
            try {
                val scaled = scaleBitmap(bitmap, AgentModeCaptureMaxEdge)
                outputFile.outputStream().use { output ->
                    scaled.compress(
                        Bitmap.CompressFormat.JPEG,
                        AgentModeCaptureJpegQuality,
                        output,
                    )
                }
            } finally {
                bitmap.recycle()
            }
            if (!outputFile.isFile || outputFile.length() <= 0L) {
                error("Screenshot capture produced an empty file.")
            }
        }
    }

    private fun scaleBitmap(bitmap: Bitmap, maxEdge: Int): Bitmap {
        val longestEdge = maxOf(bitmap.width, bitmap.height)
        if (longestEdge <= maxEdge) return bitmap
        val scale = maxEdge.toFloat() / longestEdge.toFloat()
        return Bitmap.createScaledBitmap(
            bitmap,
            (bitmap.width * scale).toInt().coerceAtLeast(1),
            (bitmap.height * scale).toInt().coerceAtLeast(1),
            true,
        )
    }

    // ──────────────────────────────────────────────────────────────────────────
    // Notifications
    // ──────────────────────────────────────────────────────────────────────────

    private fun notificationsResult(arguments: JSONObject): String {
        val action = arguments.optString("notification_action")
            .ifBlank { arguments.optString("mode", "list") }
            .lowercase()
        val listener = ArixNotificationAccess.service()
        if (listener == null) {
            error(
                "Notification access is not enabled. Enable 'Notification access' for Arix in " +
                    "Settings > Agent Mode, then try again."
            )
        }
        when (action) {
            "list" -> {
                val query = arguments.optString("query").trim().lowercase()
                val packageName = arguments.optString("package").trim()
                val maxResults = arguments.optInt(
                    "max_results",
                    arguments.optInt("maxResults", NotificationResultLimit),
                ).coerceIn(1, 200)
                val notifications = listener.snapshot()
                    .filter { notification ->
                        packageName.isBlank() || notification.packageName == packageName
                    }
                    .filter { notification ->
                        if (query.isBlank()) return@filter true
                        val extras = notification.notification?.extras
                        val title = extras?.getCharSequence(
                            android.app.Notification.EXTRA_TITLE,
                        )?.toString().orEmpty()
                        val text = extras?.getCharSequence(
                            android.app.Notification.EXTRA_TEXT,
                        )?.toString().orEmpty()
                        title.lowercase().contains(query) || text.lowercase().contains(query)
                    }
                    .take(maxResults)
                return JSONObject().apply {
                    put("ok", true)
                    put("count", notifications.size)
                    put(
                        "notifications",
                        JSONArray().apply {
                            notifications.forEach { notification ->
                                val extras = notification.notification?.extras
                                val title = extras?.getCharSequence(
                                    android.app.Notification.EXTRA_TITLE,
                                )?.toString().orEmpty()
                                val text = extras?.getCharSequence(
                                    android.app.Notification.EXTRA_TEXT,
                                )?.toString().orEmpty()
                                put(
                                    JSONObject().apply {
                                        put("package", notification.packageName)
                                        if (title.isNotBlank()) put("title", title.take(160))
                                        if (text.isNotBlank()) put("text", text.take(280))
                                        put("posted_at", notification.postTime)
                                        put("key", notification.key)
                                        put("is_clearable", notification.isClearable)
                                        put("ongoing", notification.isOngoing)
                                    }
                                )
                            }
                        },
                    )
                    put(
                        "stdout",
                        "Listed ${notifications.size} active notifications" +
                            (if (query.isNotBlank()) " matching '$query'." else "."),
                    )
                }.toString()
            }

            "dismiss" -> {
                val key = arguments.optString("key").trim()
                if (key.isBlank()) {
                    return invalidArguments("Missing required 'key' argument for dismiss.")
                }
                val dismissed = listener.dismiss(key)
                if (!dismissed) {
                    error("Notification '$key' could not be dismissed.")
                }
                return JSONObject().apply {
                    put("ok", true)
                    put("stdout", "Dismissed notification '$key'.")
                }.toString()
            }

            else -> return invalidArguments("notification_action must be 'list' or 'dismiss'.")
        }
    }

    // ──────────────────────────────────────────────────────────────────────────
    // Hardware & system control
    // ──────────────────────────────────────────────────────────────────────────

    private fun deviceInfoResult(): String {
        val batteryManager = appContext.getSystemService<BatteryManager>()
        val powerManager = appContext.getSystemService<PowerManager>()
        val batteryPercent = batteryManager
            ?.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
            ?.takeIf { it in 0..100 }
        val charging = batteryManager
            ?.getIntProperty(BatteryManager.BATTERY_PROPERTY_STATUS)
            ?.let { it == BatteryManager.BATTERY_STATUS_CHARGING || it == BatteryManager.BATTERY_STATUS_FULL }
        val screenSize = currentScreenSize()
        val memoryInfo = android.app.ActivityManager.MemoryInfo()
        (appContext.getSystemService(Context.ACTIVITY_SERVICE) as? android.app.ActivityManager)
            ?.getMemoryInfo(memoryInfo)
        return JSONObject().apply {
            put("ok", true)
            put(
                "device",
                JSONObject().apply {
                    put("model", Build.MODEL)
                    put("manufacturer", Build.MANUFACTURER)
                    put("android_version", Build.VERSION.RELEASE)
                    put("api_level", Build.VERSION.SDK_INT)
                },
            )
            put(
                "battery",
                JSONObject().apply {
                    batteryPercent?.let { put("percent", it) }
                    charging?.let { put("charging", it) }
                },
            )
            put(
                "display",
                JSONObject().apply {
                    put("width", screenSize.first)
                    put("height", screenSize.second)
                    put("interactive", powerManager?.isInteractive ?: true)
                    put(
                        "brightness",
                        runCatching {
                            Settings.System.getInt(
                                appContext.contentResolver,
                                Settings.System.SCREEN_BRIGHTNESS,
                            )
                        }.getOrNull(),
                    )
                    put(
                        "auto_brightness",
                        runCatching {
                            Settings.System.getInt(
                                appContext.contentResolver,
                                Settings.System.SCREEN_BRIGHTNESS_MODE,
                            ) == Settings.System.SCREEN_BRIGHTNESS_MODE_AUTOMATIC
                        }.getOrNull(),
                    )
                    put(
                        "screen_timeout_ms",
                        runCatching {
                            Settings.System.getInt(
                                appContext.contentResolver,
                                Settings.System.SCREEN_OFF_TIMEOUT,
                            )
                        }.getOrNull(),
                    )
                },
            )
            put(
                "audio",
                JSONObject().apply {
                    put("ringer_mode", ringerModeName())
                    put(
                        "music_volume",
                        audioManager.getStreamVolume(AudioManager.STREAM_MUSIC),
                    )
                    put("music_max_volume", audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC))
                    put(
                        "call_volume",
                        audioManager.getStreamVolume(AudioManager.STREAM_VOICE_CALL),
                    )
                    put("call_max_volume", audioManager.getStreamMaxVolume(AudioManager.STREAM_VOICE_CALL))
                    put(
                        "ring_volume",
                        audioManager.getStreamVolume(AudioManager.STREAM_RING),
                    )
                    put("ring_max_volume", audioManager.getStreamMaxVolume(AudioManager.STREAM_RING))
                    put(
                        "alarm_volume",
                        audioManager.getStreamVolume(AudioManager.STREAM_ALARM),
                    )
                    put("alarm_max_volume", audioManager.getStreamMaxVolume(AudioManager.STREAM_ALARM))
                },
            )
            if (memoryInfo.totalMem > 0) {
                put(
                    "memory",
                    JSONObject().apply {
                        put("total_mb", memoryInfo.totalMem / (1024 * 1024))
                        put("available_mb", memoryInfo.availMem / (1024 * 1024))
                        put("low_memory", memoryInfo.lowMemory)
                    },
                )
            }
            ArixAccessibility.service()?.lastWindowPackage?.takeIf { it.isNotBlank() }?.let {
                put("foreground_app", it)
            }
            put("stdout", "Collected device and system state.")
        }.toString()
    }

    private fun volumeResult(arguments: JSONObject): String {
        val action = arguments.optString("volume_action").ifBlank { "get" }.lowercase()
        val streamName = arguments.optString("stream").ifBlank { "music" }.lowercase()
        val streamType = when (streamName) {
            "music", "media" -> AudioManager.STREAM_MUSIC
            "ring", "ringer" -> AudioManager.STREAM_RING
            "alarm" -> AudioManager.STREAM_ALARM
            "call", "voice_call" -> AudioManager.STREAM_VOICE_CALL
            "system" -> AudioManager.STREAM_SYSTEM
            "notification", "notifications" -> AudioManager.STREAM_NOTIFICATION
            else -> return invalidArguments(
                "stream must be one of music, ring, alarm, call, system, notification."
            )
        }
        if (action == "get") {
            return JSONObject().apply {
                put("ok", true)
                put("stream", streamName)
                put("volume", audioManager.getStreamVolume(streamType))
                put("max_volume", audioManager.getStreamMaxVolume(streamType))
                put("ringer_mode", ringerModeName())
                put("stdout", "Stream '$streamName' volume is ${audioManager.getStreamVolume(streamType)} " +
                    "of ${audioManager.getStreamMaxVolume(streamType)}.")
            }.toString()
        }
        if (action != "set") {
            return invalidArguments("volume_action must be 'get' or 'set'.")
        }
        val level = arguments.optInt("level", -1)
        val delta = arguments.optInt("delta", 0)
        val maxVolume = audioManager.getStreamMaxVolume(streamType)
        val targetLevel = when {
            level >= 0 -> level.coerceIn(0, maxVolume)
            delta != 0 -> (audioManager.getStreamVolume(streamType) + delta).coerceIn(0, maxVolume)
            else -> return invalidArguments("Provide 'level' (absolute 0..max) or 'delta' (step).")
        }
        return try {
            audioManager.setStreamVolume(streamType, targetLevel, 0)
            JSONObject().apply {
                put("ok", true)
                put("stream", streamName)
                put("volume", audioManager.getStreamVolume(streamType))
                put("max_volume", maxVolume)
                put(
                    "stdout",
                    "Set '$streamName' volume to ${audioManager.getStreamVolume(streamType)} " +
                        "of $maxVolume.",
                )
            }.toString()
        } catch (securityException: SecurityException) {
            error(
                "Changing the ringer volume was blocked because Do Not Disturb access is not " +
                    "granted to Arix."
            )
        }
    }

    // ──────────────────────────────────────────────────────────────────────────
    // System settings modification (WRITE_SETTINGS)
    // ──────────────────────────────────────────────────────────────────────────

    private fun systemSettingsResult(arguments: JSONObject): String {
        val action = arguments.optString("settings_action").ifBlank { "get" }.lowercase()
        val key = arguments.optString("key").trim().lowercase()
        if (action == "get") {
            if (key.isBlank()) {
                return JSONObject().apply {
                    put("ok", true)
                    put(
                        "settings",
                        JSONObject().apply {
                            put(
                                "brightness",
                                runCatching {
                                    Settings.System.getInt(
                                        appContext.contentResolver,
                                        Settings.System.SCREEN_BRIGHTNESS,
                                    )
                                }.getOrNull(),
                            )
                            put(
                                "auto_brightness",
                                runCatching {
                                    Settings.System.getInt(
                                        appContext.contentResolver,
                                        Settings.System.SCREEN_BRIGHTNESS_MODE,
                                    ) == Settings.System.SCREEN_BRIGHTNESS_MODE_AUTOMATIC
                                }.getOrNull(),
                            )
                            put(
                                "screen_timeout_ms",
                                runCatching {
                                    Settings.System.getInt(
                                        appContext.contentResolver,
                                        Settings.System.SCREEN_OFF_TIMEOUT,
                                    )
                                }.getOrNull(),
                            )
                            put("can_write", Settings.System.canWrite(appContext))
                        },
                    )
                    put("stdout", "Read system settings. Use set to change them.")
                }.toString()
            }
            return readSingleSystemSetting(key)
        }
        if (action != "set") {
            return invalidArguments("settings_action must be 'get' or 'set'.")
        }
        if (!Settings.System.canWrite(appContext)) {
            error(
                "Arix does not have 'Modify system settings' permission. Enable it in " +
                    "Settings > Agent Mode, then try again."
            )
        }
        if (key.isBlank()) {
            return invalidArguments("Missing required 'key' for set. Supported keys: brightness, " +
                "auto_brightness, screen_timeout.")
        }
        when (key) {
            "brightness" -> {
                val value = arguments.optInt("value", -1)
                if (value < 0) return invalidArguments("brightness requires 'value' in 0..255.")
                val bounded = value.coerceIn(0, 255)
                val didWrite = Settings.System.putInt(
                    appContext.contentResolver,
                    Settings.System.SCREEN_BRIGHTNESS,
                    bounded,
                )
                if (!didWrite) error("Brightness could not be written.")
                return JSONObject().apply {
                    put("ok", true)
                    put("key", "brightness")
                    put("value", bounded)
                    put("stdout", "Set screen brightness to $bounded.")
                }.toString()
            }

            "auto_brightness" -> {
                val value = when (val rawValue = arguments.opt("value")) {
                    is Boolean -> rawValue
                    is Int -> rawValue != 0
                    is Long -> rawValue != 0L
                    is String -> rawValue.toBooleanStrictOrNull() ?: (rawValue == "1")
                    else -> true
                }
                val didWrite = Settings.System.putInt(
                    appContext.contentResolver,
                    Settings.System.SCREEN_BRIGHTNESS_MODE,
                    if (value) {
                        Settings.System.SCREEN_BRIGHTNESS_MODE_AUTOMATIC
                    } else {
                        Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL
                    },
                )
                if (!didWrite) error("Auto brightness could not be written.")
                return JSONObject().apply {
                    put("ok", true)
                    put("key", "auto_brightness")
                    put("value", value)
                    put("stdout", "Set auto brightness to $value.")
                }.toString()
            }

            "screen_timeout" -> {
                val value = arguments.optInt("value", -1)
                if (value < 0) {
                    return invalidArguments("screen_timeout requires 'value' in milliseconds.")
                }
                val bounded = value.coerceIn(1_000, 60 * 60 * 1000)
                val didWrite = Settings.System.putLong(
                    appContext.contentResolver,
                    Settings.System.SCREEN_OFF_TIMEOUT,
                    bounded.toLong(),
                )
                if (!didWrite) error("Screen timeout could not be written.")
                return JSONObject().apply {
                    put("ok", true)
                    put("key", "screen_timeout")
                    put("value", bounded)
                    put("stdout", "Set screen timeout to ${bounded / 1000} seconds.")
                }.toString()
            }

            else -> return invalidArguments(
                "Unsupported settings key '$key'. Supported keys: brightness, auto_brightness, " +
                    "screen_timeout. WRITE_SECURE_SETTINGS keys are not writable without an adb grant."
            )
        }
    }

    private fun readSingleSystemSetting(key: String): String {
        val value: Any? = when (key) {
            "brightness" -> runCatching {
                Settings.System.getInt(
                    appContext.contentResolver,
                    Settings.System.SCREEN_BRIGHTNESS,
                )
            }.getOrNull()

            "auto_brightness" -> runCatching {
                Settings.System.getInt(
                    appContext.contentResolver,
                    Settings.System.SCREEN_BRIGHTNESS_MODE,
                ) == Settings.System.SCREEN_BRIGHTNESS_MODE_AUTOMATIC
            }.getOrNull()

            "screen_timeout" -> runCatching {
                Settings.System.getInt(
                    appContext.contentResolver,
                    Settings.System.SCREEN_OFF_TIMEOUT,
                )
            }.getOrNull()

            else -> return invalidArguments(
                "Unsupported settings key '$key'. Supported keys: brightness, auto_brightness, " +
                    "screen_timeout."
            )
        }
        return JSONObject().apply {
            put("ok", true)
            put("key", key)
            put("value", value ?: JSONObject.NULL)
            put("stdout", "$key = $value")
        }.toString()
    }

    // ──────────────────────────────────────────────────────────────────────────
    // Telecom & call handling
    // ──────────────────────────────────────────────────────────────────────────

    private fun callResult(arguments: JSONObject): String {
        val action = arguments.optString("call_action").ifBlank { "state" }.lowercase()
        val telecomManager = appContext.getSystemService<android.telecom.TelecomManager>()
        return when (action) {
            "state" -> {
                if (!hasPermission(Manifest.permission.READ_PHONE_STATE)) {
                    error(
                        "Phone permission is not granted. Grant 'Phone' permission to Arix in " +
                            "Settings > Agent Mode, then try again."
                    )
                }
                val callState = callState()
                JSONObject().apply {
                    put("ok", true)
                    put("call_state", callState)
                    put("stdout", "Current call state: $callState.")
                }.toString()
            }

            "dial" -> {
                val number = arguments.optString("number").trim()
                if (number.isBlank()) {
                    return invalidArguments("Missing required 'number' argument for dial.")
                }
                val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:${Uri.encode(number)}"))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                runCatching { appContext.startActivity(intent) }
                    .onFailure { error("Could not open the dialer: ${it.message}") }
                JSONObject().apply {
                    put("ok", true)
                    put("stdout", "Opened the dialer with $number.")
                }.toString()
            }

            "answer" -> {
                if (!hasPermission(Manifest.permission.ANSWER_PHONE_CALLS)) {
                    error(
                        "Answer-call permission is not granted. Grant it in Settings > Agent Mode, " +
                            "then try again."
                    )
                }
                if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) {
                    error("Answering calls programmatically requires Android 8 or newer.")
                }
                runCatching { telecomManager?.acceptRingingCall() }
                    .onFailure { error("Could not answer the call: ${it.message}") }
                JSONObject().apply {
                    put("ok", true)
                    put("stdout", "Answered the ringing call.")
                }.toString()
            }

            "end" -> {
                if (!hasPermission(Manifest.permission.ANSWER_PHONE_CALLS)) {
                    error(
                        "Answer-call permission is not granted. Grant it in Settings > Agent Mode, " +
                            "then try again."
                    )
                }
                if (Build.VERSION.SDK_INT < Build.VERSION_CODES.P) {
                    error("Ending calls programmatically requires Android 9 or newer.")
                }
                val ended = runCatching { telecomManager?.endCall() }.getOrDefault(false)
                if (ended != true) {
                    error("No call could be ended. A call may not be active.")
                }
                JSONObject().apply {
                    put("ok", true)
                    put("stdout", "Ended the active call.")
                }.toString()
            }

            else -> invalidArguments("call_action must be one of state, dial, answer, end.")
        }
    }

    private fun callState(): String {
        val telephonyManager = appContext.getSystemService<TelephonyManager>() ?: return "unknown"
        return when (
            runCatching {
                @Suppress("DEPRECATION")
                telephonyManager.callState
            }.getOrDefault(TelephonyManager.CALL_STATE_IDLE)
        ) {
            TelephonyManager.CALL_STATE_RINGING -> "ringing"
            TelephonyManager.CALL_STATE_OFFHOOK -> "active"
            else -> "idle"
        }
    }

    // ──────────────────────────────────────────────────────────────────────────
    // Floating HUD
    // ──────────────────────────────────────────────────────────────────────────

    private fun hudResult(arguments: JSONObject): String {
        val visible = arguments.optString("visible").ifBlank { "show" }.lowercase() == "show"
        if (!Settings.canDrawOverlays(appContext)) {
            error(
                "Arix does not have 'Display over other apps' permission. Enable it in " +
                    "Settings > Agent Mode, then try again."
            )
        }
        if (visible) {
            AgentModeHudService.start(appContext)
        } else {
            AgentModeHudService.stop(appContext)
        }
        return JSONObject().apply {
            put("ok", true)
            put("visible", visible)
            put("stdout", if (visible) "Floating HUD shown." else "Floating HUD hidden.")
        }.toString()
    }

    // ──────────────────────────────────────────────────────────────────────────
    // Authorization
    // ──────────────────────────────────────────────────────────────────────────

    private fun inspectAuthorization(settings: AppSettings): AgentModeAuthorizationState {
        if (!settings.agentModeAuthorizationEnabled) {
            return AgentModeAuthorizationState(
                issue = AgentModeAuthorizationIssue.Disabled,
                detail = "Agent Mode is disabled.",
            )
        }
        if (!ArixAccessibility.isRunning) {
            return AgentModeAuthorizationState(
                issue = AgentModeAuthorizationIssue.AccessibilityDisabled,
                detail = "Enable the Arix accessibility service, then refresh Agent Mode status.",
            )
        }
        return AgentModeAuthorizationState(
            issue = AgentModeAuthorizationIssue.Ready,
            detail = "No-root Agent Mode is ready on the real screen.",
        )
    }

    // ──────────────────────────────────────────────────────────────────────────
    // Helpers
    // ──────────────────────────────────────────────────────────────────────────

    private fun requireAccessibility(): com.arix.app.agentmode.ArixAccessibilityService =
        com.arix.app.agentmode.ArixAccessibility.service()
            ?: error(
                "The Arix accessibility service is not enabled. Enable it in Settings > Agent Mode " +
                    "(or Android Settings > Accessibility) and try again."
            )

    private fun currentScreenSize(): Pair<Int, Int> {
        val display = displayManager.getDisplay(android.view.Display.DEFAULT_DISPLAY)
        val size = Point()
        @Suppress("DEPRECATION")
        display?.getRealSize(size)
        val metrics = appContext.resources.displayMetrics
        val width = (display?.mode?.physicalWidth ?: size.x).takeIf { it > 0 }
            ?: metrics.widthPixels.takeIf { it > 0 }
            ?: FallbackAgentDisplayWidth
        val height = (display?.mode?.physicalHeight ?: size.y).takeIf { it > 0 }
            ?: metrics.heightPixels.takeIf { it > 0 }
            ?: FallbackAgentDisplayHeight
        return width to height
    }

    private fun normalizeCoordinate(value: Double, dimensionSize: Int): Int =
        (value.coerceIn(0.0, 1000.0) * dimensionSize / 1000.0).toInt()

    private fun normalizePixel(pixel: Int, dimensionSize: Int): Int =
        (pixel * 1000L / dimensionSize.coerceAtLeast(1)).toInt().coerceIn(0, 1000)

    private fun currentDisplaysLocal(): List<AgentModeDisplayInfo> =
        displayManager.displays.map { display ->
            val size = Point()
            @Suppress("DEPRECATION")
            display.getSize(size)
            AgentModeDisplayInfo(
                displayId = display.displayId,
                name = display.name.orEmpty().ifBlank { "Primary display" },
                width = display.mode?.physicalWidth ?: size.x,
                height = display.mode?.physicalHeight ?: size.y,
                isArixDisplay = false,
            )
        }.sortedBy { it.displayId }

    private fun ringerModeName(): String = when (audioManager.ringerMode) {
        AudioManager.RINGER_MODE_SILENT -> "silent"
        AudioManager.RINGER_MODE_VIBRATE -> "vibrate"
        else -> "normal"
    }

    private fun hasPermission(permission: String): Boolean =
        ContextCompat.checkSelfPermission(appContext, permission) == PackageManager.PERMISSION_GRANTED

    private fun captureAgentModeFailed(
        settings: AppSettings,
        action: String,
        reason: String,
        message: String,
    ) {
        diagnosticLogger.event(
            category = "agent_mode",
            event = "action_failed",
            level = "warn",
            details = mapOf(
                "action" to action,
                "reason" to reason,
                "message" to message,
                "authorization_enabled" to settings.agentModeAuthorizationEnabled,
                "accessibility_running" to ArixAccessibility.isRunning,
                "session_active" to _displayState.value.isActive,
            ),
        )
        ArixAnalytics.capture(
            event = "agent mode failed",
            properties = mapOf(
                "action" to action,
                "reason" to reason,
                "message" to message.take(280),
                "authorization_enabled" to settings.agentModeAuthorizationEnabled,
                "accessibility_running" to ArixAccessibility.isRunning,
            ),
        )
    }

    private fun invalidArguments(message: String): String =
        JSONObject().apply {
            put("ok", false)
            put("errmsg", message)
        }.toString()

    private fun toolError(
        message: String,
        action: String,
    ): String = JSONObject().apply {
        put("ok", false)
        put("action", action)
        put("errmsg", message)
        put("stdout", "")
    }.toString()

    private data class ScreenElementMatch(
        val node: AccessibilityNodeInfo,
        val json: JSONObject,
        val bounds: Rect?,
    )
}

data class AgentModeDisplayState(
    val isActive: Boolean = false,
    val displayId: Int? = null,
    val width: Int = FallbackAgentDisplayWidth,
    val height: Int = FallbackAgentDisplayHeight,
    val displays: List<AgentModeDisplayInfo> = emptyList(),
    val latestPreviewPath: String = "",
    val latestWorkspacePath: String = "",
    val cursorX: Int? = null,
    val cursorY: Int? = null,
    val cursorAnimationDurationMillis: Int = 220,
    val isLivePreviewActive: Boolean = false,
    val lastUpdatedMillis: Long = 0L,
    val status: String = "",
)

data class AgentModeDisplayInfo(
    val displayId: Int,
    val name: String,
    val width: Int,
    val height: Int,
    val isArixDisplay: Boolean,
)

data class AgentModeInstalledAppInfo(
    val packageName: String,
    val appName: String,
    val activityName: String,
    val isSystemApp: Boolean,
    val isEnabled: Boolean,
)

enum class AgentModeAuthorizationIssue {
    Disabled,
    Ready,
    AccessibilityDisabled,
    Error,
}

data class AgentModeAuthorizationState(
    val issue: AgentModeAuthorizationIssue = AgentModeAuthorizationIssue.Disabled,
    val detail: String = "",
) {
    val isReady: Boolean
        get() = issue == AgentModeAuthorizationIssue.Ready
}
