package com.arix.app.agentmode

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Path
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.Display
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException
import kotlinx.coroutines.suspendCancellableCoroutine

/**
 * No-root Agent Mode backbone. The accessibility service provides:
 *  - gesture injection (tap / long-press / swipe) via dispatchGesture
 *  - global key actions (back / home / recents / notifications / quick settings / lock screen)
 *  - text entry into the focused field (set-text or clipboard paste)
 *  - structured screen reading (accessibility node trees, view ids, bounds)
 *  - element lookup + click by text or view id
 *  - full-screen capture on Android 11+ via takeScreenshot
 *
 * No root, no Shizuku, and no virtual display are involved: the agent drives
 * the real foreground screen, which is exactly what a user watching the device
 * would expect from an assistant-operated session.
 */
class ArixAccessibilityService : AccessibilityService() {

    private val mainHandler = Handler(Looper.getMainLooper())

    @Volatile
    var lastWindowPackage: String = ""
        private set

    override fun onServiceConnected() {
        super.onServiceConnected()
        activeInstance = this
        Log.i(Tag, "Arix accessibility service connected.")
    }

    override fun onDestroy() {
        activeInstance = null
        super.onDestroy()
    }

    override fun onUnbind(intent: Intent?): Boolean {
        activeInstance = null
        return super.onUnbind(intent)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val packageName = event?.packageName?.toString().orEmpty()
        if (packageName.isNotBlank()) {
            lastWindowPackage = packageName
        }
    }

    override fun onInterrupt() {
        // Nothing to interrupt: no feedback channels are registered.
    }

    fun realScreenSize(): Pair<Int, Int> {
        val metrics = resources.displayMetrics
        return metrics.widthPixels to metrics.heightPixels
    }

    suspend fun tap(x: Float, y: Float): Unit = dispatchTapOrSwipe(
        fromX = x,
        fromY = y,
        toX = x,
        toY = y,
        durationMillis = TapDurationMillis,
    )

    suspend fun longPress(x: Float, y: Float): Unit = dispatchTapOrSwipe(
        fromX = x,
        fromY = y,
        toX = x,
        toY = y,
        durationMillis = LongPressDurationMillis,
    )

    suspend fun swipe(
        fromX: Float,
        fromY: Float,
        toX: Float,
        toY: Float,
        durationMillis: Long,
    ): Unit = dispatchTapOrSwipe(
        fromX = fromX,
        fromY = fromY,
        toX = toX,
        toY = toY,
        durationMillis = durationMillis.coerceIn(MinGestureDurationMillis, MaxGestureDurationMillis),
    )

    private suspend fun dispatchTapOrSwipe(
        fromX: Float,
        fromY: Float,
        toX: Float,
        toY: Float,
        durationMillis: Long,
    ): Unit = suspendCancellableCoroutine { continuation ->
        val posted = mainHandler.post {
            val path = Path().apply {
                moveTo(fromX, fromY)
                lineTo(toX, toY)
            }
            val stroke = GestureDescription.StrokeDescription(path, 0L, durationMillis)
            val gesture = GestureDescription.Builder().addStroke(stroke).build()
            val callback = object : GestureResultCallback() {
                override fun onCompleted(gestureDescription: GestureDescription?) {
                    if (continuation.isActive) continuation.resume(Unit)
                }

                override fun onCancelled(gestureDescription: GestureDescription?) {
                    if (continuation.isActive) {
                        continuation.resumeWithException(
                            IllegalStateException(
                                "Gesture was cancelled by the system or by a newer gesture."
                            )
                        )
                    }
                }
            }
            val accepted = try {
                dispatchGesture(gesture, callback, mainHandler)
            } catch (throwable: Throwable) {
                if (continuation.isActive) {
                    continuation.resumeWithException(
                        IllegalStateException("Gesture dispatch failed: ${throwable.message}")
                    )
                }
                return@post
            }
            if (!accepted && continuation.isActive) {
                continuation.resumeWithException(
                    IllegalStateException("Gesture dispatch was rejected by the system.")
                )
            }
        }
        if (!posted && continuation.isActive) {
            continuation.resumeWithException(
                IllegalStateException("Gesture could not be scheduled on the main thread.")
            )
        }
    }

    fun globalAction(actionId: Int): Boolean = performGlobalAction(actionId)

    fun focusedEditableNode(): AccessibilityNodeInfo? {
        val root = rootInActiveWindow ?: return null
        return runCatching {
            root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
                ?: root.findFocus(AccessibilityNodeInfo.FOCUS_ACCESSIBILITY)
        }.getOrNull()
    }

    fun rootWindowNode(): AccessibilityNodeInfo? = rootInActiveWindow

    suspend fun captureScreen(): Bitmap {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R) {
            error("Accessibility screenshots require Android 11 (API 30) or newer.")
        }
        return suspendCancellableCoroutine { continuation ->
            val posted = mainHandler.post {
                try {
                    takeScreenshot(
                        Display.DEFAULT_DISPLAY,
                        java.util.concurrent.Executor { runnable -> mainHandler.post(runnable) },
                        object : TakeScreenshotCallback {
                            override fun onSuccess(screenshot: ScreenshotResult) {
                                val hardwareBuffer = screenshot.hardwareBuffer
                                if (hardwareBuffer == null) {
                                    if (continuation.isActive) {
                                        continuation.resumeWithException(
                                            IllegalStateException("Screenshot returned no pixel buffer.")
                                        )
                                    }
                                    return
                                }
                                try {
                                    val bitmap = screenshotToSoftwareBitmap(
                                        hardwareBuffer,
                                        screenshot.colorSpace,
                                    )
                                    if (bitmap == null) {
                                        if (continuation.isActive) {
                                            continuation.resumeWithException(
                                                IllegalStateException("Screenshot bitmap could not be copied.")
                                            )
                                        }
                                    } else if (continuation.isActive) {
                                        continuation.resume(bitmap)
                                    }
                                } catch (throwable: Throwable) {
                                    if (continuation.isActive) {
                                        continuation.resumeWithException(
                                            IllegalStateException("Screenshot failed: ${throwable.message}")
                                        )
                                    }
                                } finally {
                                    hardwareBuffer.close()
                                }
                            }

                            override fun onFailure(errorCode: Int) {
                                if (continuation.isActive) {
                                    continuation.resumeWithException(
                                        IllegalStateException("Screenshot failed with error code $errorCode.")
                                    )
                                }
                            }
                        },
                    )
                } catch (throwable: Throwable) {
                    if (continuation.isActive) {
                        continuation.resumeWithException(
                            IllegalStateException("Screenshot request failed: ${throwable.message}")
                        )
                    }
                    return@post
                }
            }
            if (!posted && continuation.isActive) {
                continuation.resumeWithException(
                    IllegalStateException("Screenshot could not be scheduled on the main thread.")
                )
            }
        }
    }

    /** Copy the screenshot hardware buffer into a software bitmap usable for JPEG encoding. */
    private fun screenshotToSoftwareBitmap(
        hardwareBuffer: android.hardware.HardwareBuffer,
        colorSpace: android.graphics.ColorSpace?,
    ): Bitmap? {
        val hardwareBitmap = Bitmap.wrapHardwareBuffer(hardwareBuffer, colorSpace) ?: return null
        return runCatching {
            val softwareBitmap = hardwareBitmap.copy(Bitmap.Config.ARGB_8888, false)
            softwareBitmap
        }.getOrNull().also {
            hardwareBitmap.recycle()
        }
    }

    private companion object {
        const val Tag = "ArixAccessibility"
        const val TapDurationMillis = 60L
        const val LongPressDurationMillis = 600L
        const val MinGestureDurationMillis = 16L
        const val MaxGestureDurationMillis = 10_000L
    }
}

@Volatile
private var activeInstance: ArixAccessibilityService? = null

object ArixAccessibility {
    val isRunning: Boolean
        get() = activeInstance != null

    fun service(): ArixAccessibilityService? = activeInstance
}
