package com.arix.app.voice

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.first
import java.io.File

private val Context.voiceDataStore by preferencesDataStore(name = "arix_voice")

/**
 * v2.4.9: user-facing settings for the offline voice stack.
 *
 * STT  — Vosk small English model, downloaded on demand (~40 MB).
 * Wake — always-on "Arix" / "Hey Arix" keyword spotting via the same Vosk
 *        model, running in a microphone foreground service (user toggle).
 * TTS  — Kokoro (free, offline, ONNX int8 English model ~80 MB) with male
 *        voices, running via sherpa-onnx. Optimized for mid-range arm64
 *        devices like the Poco X2 (2 threads, int8 quantization).
 */
data class ArixVoiceSettings(
    /** Voice input (STT) is enabled in the composer. */
    val voiceInputEnabled: Boolean = true,
    /** "Arix" / "Hey Arix" wake word listener is active. */
    val wakeWordEnabled: Boolean = false,
    /** Arix speaks replies out loud with offline Kokoro TTS. */
    val ttsEnabled: Boolean = false,
    /** Kokoro speaker id (see ArixTtsEngine.kokoroVoices). */
    val ttsSpeakerId: Int = ArixTtsEngine.DefaultSpeakerId,
    /** TTS speaking rate (0.5 slow .. 1.5 fast). */
    val ttsSpeed: Float = 1.0f,
    /** Vosk model directory path once installed. */
    val voskModelPath: String = "",
    /** Kokoro model directory path once installed. */
    val kokoroModelPath: String = "",
) {
    val voskModelInstalled: Boolean get() = voskModelPath.isNotBlank() && File(voskModelPath).isDirectory
    val kokoroModelInstalled: Boolean get() = kokoroModelPath.isNotBlank() && File(kokoroModelPath).isDirectory
}

class ArixVoiceRepository(
    private val context: Context,
) {
    val settings: Flow<ArixVoiceSettings> = context.voiceDataStore.data.map { preferences ->
        ArixVoiceSettings(
            voiceInputEnabled = preferences[VOICE_INPUT_ENABLED] ?: true,
            wakeWordEnabled = preferences[WAKE_WORD_ENABLED] ?: false,
            ttsEnabled = preferences[TTS_ENABLED] ?: false,
            ttsSpeakerId = preferences[TTS_SPEAKER_ID] ?: ArixTtsEngine.DefaultSpeakerId,
            ttsSpeed = (preferences[TTS_SPEED] ?: 1.0f).coerceIn(0.5f, 1.5f),
            voskModelPath = preferences[VOSK_MODEL_PATH].orEmpty(),
            kokoroModelPath = preferences[KOKORO_MODEL_PATH].orEmpty(),
        )
    }

    suspend fun current(): ArixVoiceSettings = settings.first()

    suspend fun setVoiceInputEnabled(enabled: Boolean) {
        context.voiceDataStore.edit { it[VOICE_INPUT_ENABLED] = enabled }
    }

    suspend fun setWakeWordEnabled(enabled: Boolean) {
        context.voiceDataStore.edit { it[WAKE_WORD_ENABLED] = enabled }
    }

    suspend fun setTtsEnabled(enabled: Boolean) {
        context.voiceDataStore.edit { it[TTS_ENABLED] = enabled }
    }

    suspend fun setTtsSpeakerId(speakerId: Int) {
        context.voiceDataStore.edit { it[TTS_SPEAKER_ID] = speakerId }
    }

    suspend fun setTtsSpeed(speed: Float) {
        context.voiceDataStore.edit { it[TTS_SPEED] = speed.coerceIn(0.5f, 1.5f) }
    }

    suspend fun setVoskModelPath(path: String) {
        context.voiceDataStore.edit { it[VOSK_MODEL_PATH] = path }
    }

    suspend fun setKokoroModelPath(path: String) {
        context.voiceDataStore.edit { it[KOKORO_MODEL_PATH] = path }
    }

    /** Model files live in app-private storage; user can wipe them from
     *  Settings → Voice. */
    fun modelsRoot(): File = File(context.filesDir, "arix-voice/models").apply { mkdirs() }

    fun voskModelDirectory(): File = File(modelsRoot(), "vosk-model-small-en-us-0.15")

    fun kokoroModelDirectory(): File = File(modelsRoot(), "kokoro-int8-en-v0_19")

    private companion object {
        val VOICE_INPUT_ENABLED = booleanPreferencesKey("voice_input_enabled")
        val WAKE_WORD_ENABLED = booleanPreferencesKey("wake_word_enabled")
        val TTS_ENABLED = booleanPreferencesKey("tts_enabled")
        val TTS_SPEAKER_ID = intPreferencesKey("tts_speaker_id")
        val TTS_SPEED = floatPreferencesKey("tts_speed")
        val VOSK_MODEL_PATH = stringPreferencesKey("vosk_model_path")
        val KOKORO_MODEL_PATH = stringPreferencesKey("kokoro_model_path")
    }
}
