package com.arix.app.voice

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import org.json.JSONObject
import org.vosk.Model
import org.vosk.Recognizer
import org.vosk.android.RecognitionListener
import org.vosk.android.SpeechService
import java.io.File
import java.util.concurrent.atomic.AtomicReference
import kotlin.coroutines.resume

/**
 * v2.4.9: offline speech-to-text for the composer's voice input button.
 *
 * Runs the small Vosk model fully on-device (16 kHz mono mic → partial and
 * final transcripts). Nothing leaves the phone.
 */
class ArixSttEngine(
    private val context: Context,
    private val modelManager: ArixVoiceModelManager,
) {
    sealed interface State {
        data object Idle : State
        data object Initializing : State
        data object Listening : State
        data class Partial(val text: String) : State
        data class Final(val text: String) : State
        data class Error(val message: String) : State
    }

    private val _state = MutableStateFlow<State>(State.Idle)
    val state: StateFlow<State> = _state.asStateFlow()

    private val speechService = AtomicReference<SpeechService?>(null)
    private val model = AtomicReference<Model?>(null)
    private var startJob: Job? = null

    fun hasMicPermission(): Boolean = ContextCompat.checkSelfPermission(
        context,
        Manifest.permission.RECORD_AUDIO,
    ) == PackageManager.PERMISSION_GRANTED

    /**
     * Starts a recognition session. Transcript updates flow through [state].
     * Returns false (and sets an error state) when the mic permission is
     * missing or the model is unavailable.
     */
    fun startListening(scope: CoroutineScope) {
        if (startJob?.isActive == true) return
        if (!hasMicPermission()) {
            _state.value = State.Error("Microphone permission is required for voice input.")
            return
        }
        startJob = scope.launch(Dispatchers.IO) {
            _state.value = State.Initializing
            try {
                val modelDirectory = resolveModelDirectory()
                val loadedModel = model.get() ?: Model(modelDirectory.absolutePath).also {
                    model.set(it)
                }
                // Free-form recognition (full vocabulary) for chat dictation.
                val recognizer = Recognizer(loadedModel, SampleRateHz)
                val service = SpeechService(recognizer, SampleRateHz)
                speechService.set(service)
                _state.value = State.Listening
                service.startListening(object : RecognitionListener {
                    override fun onPartialResult(hypothesis: String) {
                        val partial = runCatching { JSONObject(hypothesis).optString("partial") }
                            .getOrNull().orEmpty()
                        if (partial.isNotBlank()) _state.value = State.Partial(partial)
                    }

                    override fun onResult(hypothesis: String) {
                        val text = runCatching { JSONObject(hypothesis).optString("text") }
                            .getOrNull().orEmpty().trim()
                        if (text.isNotBlank()) _state.value = State.Final(text)
                    }

                    override fun onFinalResult(hypothesis: String) {
                        val text = runCatching { JSONObject(hypothesis).optString("text") }
                            .getOrNull().orEmpty().trim()
                        if (text.isNotBlank()) _state.value = State.Final(text)
                    }

                    override fun onError(exception: Exception) {
                        _state.value = State.Error(exception.message ?: "Speech recognition error.")
                    }

                    override fun onTimeout() {
                        // Silence timeout — stop cleanly; UI falls back to Idle.
                        stop()
                    }
                })
            } catch (throwable: Throwable) {
                if (throwable is kotlinx.coroutines.CancellationException) throw throwable
                stop()
                _state.value = State.Error(
                    throwable.message ?: "Could not start voice input. Is the offline model downloaded?"
                )
            }
        }
    }

    fun stop() {
        runCatching { speechService.getAndSet(null)?.stop() }
        if (_state.value !is State.Error) _state.value = State.Idle
    }

    fun shutdown() {
        stop()
        runCatching { speechService.getAndSet(null)?.shutdown() }
        runCatching { model.getAndSet(null)?.close() }
    }

    private suspend fun resolveModelDirectory(): File {
        // Prefer the persisted path; fall back to the canonical location.
        val persisted = runCatching { ArixVoiceRepository(context).current().voskModelPath }
            .getOrNull().orEmpty()
        val persistedDirectory = persisted.takeIf { it.isNotBlank() }?.let(::File)
        if (persistedDirectory?.isDirectory == true) return persistedDirectory
        val result = modelManager.ensureVoskModel().getOrNull()
        if (result != null && result.isDirectory) return result
        throw IllegalStateException("The offline Vosk model is not installed. Download it from Settings → Voice.")
    }

    companion object {
        const val SampleRateHz = 16_000f
    }
}

/** Awaits the next [ArixSttEngine.State.Final] emission (used by tests and
 *  the wake word path). */
suspend fun ArixSttEngine.awaitFinalText(scope: CoroutineScope): String? =
    suspendCancellableCoroutine { continuation ->
        val collector = scope.launch {
            state.collect { value ->
                if (value is ArixSttEngine.State.Final) {
                    if (continuation.isActive) continuation.resume(value.text)
                }
            }
        }
        continuation.invokeOnCancellation { collector.cancel() }
    }
