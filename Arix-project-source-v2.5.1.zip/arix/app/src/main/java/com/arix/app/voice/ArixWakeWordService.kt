package com.arix.app.voice

import android.app.Notification
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import com.arix.app.ArixApplication
import com.arix.app.MainActivity
import com.arix.app.R
import com.arix.app.WakeWordChannelId
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import org.json.JSONObject
import org.vosk.Model
import org.vosk.Recognizer
import org.vosk.android.RecognitionListener
import org.vosk.android.SpeechService
import java.io.File
import java.util.concurrent.atomic.AtomicReference

/**
 * v2.4.9: always-listening wake word service ("Arix" / "Hey Arix").
 *
 * Runs Vosk with a tiny closed grammar of wake phrases (much cheaper than
 * full-vocabulary decoding: the recognizer only hunts for the phrases, so
 * CPU usage per audio frame is lower, and accuracy for the wake phrase is
 * higher). When the phrase is heard, the service summons Arix (opens the
 * assistant overlay) and plays a short confirmation tone.
 *
 * The service only runs while the user keeps the toggle ON in
 * Settings → Voice; stopping the toggle stops the mic immediately.
 */
class ArixWakeWordService : Service() {
    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val speechService = AtomicReference<SpeechService?>(null)
    private val model = AtomicReference<Model?>(null)

    override fun onCreate() {
        super.onCreate()
        startRequested.set(true)
        startForegroundCompat()
        serviceScope.launch { runWakeWordLoop() }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startRequested.set(true)
        if (intent?.action == ActionStop) {
            stopSelf()
            return START_NOT_STICKY
        }
        return START_STICKY
    }

    override fun onDestroy() {
        startRequested.set(false)
        stopListening()
        runCatching { model.getAndSet(null)?.close() }
        serviceScope.cancel()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private suspend fun runWakeWordLoop() {
        try {
            val context = applicationContext
            val modelManager = (applicationContext as? com.arix.app.ArixApplication)
                ?.let { VoiceServiceLocator.modelManager(it) }
            if (modelManager == null) {
                updateNotification(context.getString(R.string.wake_word_notification_text_model_missing))
                return
            }
            val modelDirectory = resolveModelDirectory(modelManager) ?: run {
                updateNotification(context.getString(R.string.wake_word_notification_text_model_missing))
                return
            }
            val loadedModel = model.get() ?: Model(modelDirectory.absolutePath).also { model.set(it) }
            // Closed grammar: only the wake phrases (+ [unk]) are decodable.
            // "arix" alone can false-trigger from similar words, so it must be
            // spoken clearly; "hey arix" is the reliable form.
            val recognizer = Recognizer(loadedModel, ArixSttEngine.SampleRateHz, WakeGrammarJson)
            val service = SpeechService(recognizer, ArixSttEngine.SampleRateHz)
            speechService.set(service)
            updateNotification(getString(R.string.wake_word_notification_text_listening))
            service.startListening(object : RecognitionListener {
                override fun onPartialResult(hypothesis: String) {
                    if (containsWakePhrase(hypothesis, "partial")) {
                        onWakeWordDetected()
                    }
                }

                override fun onResult(hypothesis: String) {
                    if (containsWakePhrase(hypothesis, "text")) {
                        onWakeWordDetected()
                    }
                }

                override fun onFinalResult(hypothesis: String) {
                    if (containsWakePhrase(hypothesis, "text")) {
                        onWakeWordDetected()
                    }
                }

                override fun onError(exception: Exception) {
                    updateNotification(getString(R.string.wake_word_notification_text_error, exception.message ?: ""))
                }

                override fun onTimeout() {
                    // Vosk endpointing timeouts are normal in always-on mode;
                    // the SpeechService restarts its own stream.
                }
            })
        } catch (throwable: Throwable) {
            updateNotification(
                getString(R.string.wake_word_notification_text_error, throwable.message ?: "unknown error"),
            )
        }
    }

    private fun containsWakePhrase(hypothesis: String, jsonField: String): Boolean {
        val text = runCatching { JSONObject(hypothesis).optString(jsonField) }
            .getOrNull().orEmpty().lowercase()
        if (text.isBlank() || text == "[unk]") return false
        return WakePhrases.any { phrase -> text.contains(phrase) }
    }

    private fun onWakeWordDetected() {
        runCatching {
            ArixWakeFeedback.confirm(applicationContext)
        }
        // Give the confirmation tone a moment, then summon the assistant
        // overlay (the pill panel). Falling back to the main chat activity
        // when the assistant overlay cannot start (e.g. background
        // activity-start restrictions on Android 10+).
        val intent = Intent(applicationContext, com.arix.app.assistant.AssistantActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        val launched = runCatching { startActivity(intent) }.isSuccess
        if (!launched) {
            runCatching {
                startActivity(
                    Intent(applicationContext, MainActivity::class.java).apply {
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    },
                )
            }
        }
    }

    private fun stopListening() {
        runCatching { speechService.getAndSet(null)?.stop() }
        runCatching { speechService.getAndSet(null)?.shutdown() }
    }

    private fun resolveModelDirectory(modelManager: ArixVoiceModelManager): File? {
        val repository = modelManager.repository
        val persisted = runCatching {
            kotlinx.coroutines.runBlocking { repository.current().voskModelPath }
        }.getOrNull().orEmpty()
        persisted.takeIf { it.isNotBlank() }?.let(::File)?.takeIf { it.isDirectory }?.let { return it }
        val canonical = runCatching {
            kotlinx.coroutines.runBlocking { modelManager.ensureVoskModel().getOrNull() }
        }.getOrNull()
        return canonical?.takeIf { it.isDirectory }
    }

    private fun startForegroundCompat() {
        val notification = buildNotification(
            getString(R.string.wake_word_notification_text_starting),
        )
        ServiceCompat.startForeground(
            this,
            WakeWordNotificationId,
            notification,
            ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE,
        )
    }

    private fun updateNotification(text: String) {
        val manager = getSystemService(NOTIFICATION_SERVICE) as android.app.NotificationManager
        manager.notify(WakeWordNotificationId, buildNotification(text))
    }

    private fun buildNotification(text: String): Notification {
        val launchIntent = Intent(this, MainActivity::class.java)
        val contentIntent = PendingIntent.getActivity(
            this,
            0,
            launchIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
        val stopIntent = Intent(this, ArixWakeWordService::class.java).apply {
            action = ActionStop
        }
        val stopPendingIntent = PendingIntent.getService(
            this,
            1,
            stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
        return NotificationCompat.Builder(this, WakeWordChannelId)
            .setSmallIcon(R.drawable.ic_notification_small)
            .setContentTitle(getString(R.string.wake_word_notification_title))
            .setContentText(text)
            .setOngoing(true)
            .setSilent(true)
            .setPriority(NotificationCompat.PRIORITY_MIN)
            .setForegroundServiceBehavior(NotificationCompat.FOREGROUND_SERVICE_IMMEDIATE)
            .setContentIntent(contentIntent)
            .addAction(0, getString(R.string.wake_word_notification_stop), stopPendingIntent)
            .build()
    }

    companion object {
        private const val WakeWordNotificationId = 41002
        const val ActionStop = "com.arix.app.voice.STOP_WAKE_WORD"

        /** Wake phrases; matched case-insensitively inside recognized text. */
        val WakePhrases = listOf(
            "hey arix",
            "arix",
            "hey ariks",
            "hey iris",
            "hey alexis",
        )

        private val WakeGrammarJson = """["hey arix","arix","hey ariks","hey iris","hey alexis","[unk]"]"""

        private val startRequested = java.util.concurrent.atomic.AtomicBoolean(false)

        fun start(context: Context) {
            if (startRequested.compareAndSet(false, true)) {
                try {
                    androidx.core.content.ContextCompat.startForegroundService(
                        context.applicationContext,
                        Intent(context.applicationContext, ArixWakeWordService::class.java),
                    )
                } catch (t: Throwable) {
                    startRequested.set(false)
                    throw t
                }
            }
        }

        fun stop(context: Context) {
            startRequested.set(false)
            context.applicationContext.stopService(
                Intent(context.applicationContext, ArixWakeWordService::class.java),
            )
        }
    }
}

/** Short confirmation cue when the wake word fires (no network needed). */
private object ArixWakeFeedback {
    fun confirm(context: Context) {
        runCatching {
            val vibrator = androidx.core.content.ContextCompat.getSystemService(
                context,
                android.os.Vibrator::class.java,
            )
            vibrator?.vibrate(
                android.os.VibrationEffect.createOneShot(80L, android.os.VibrationEffect.DEFAULT_AMPLITUDE),
            )
        }
    }
}

/** Lazy service locator so the service can reach the app-scoped voice stack
 *  without reflection. */
object VoiceServiceLocator {
    @Volatile
    private var manager: ArixVoiceModelManager? = null

    fun modelManager(application: Context): ArixVoiceModelManager? {
        manager?.let { return it }
        val appContext = application.applicationContext
        val repository = ArixVoiceRepository(appContext)
        return ArixVoiceModelManager(appContext, repository).also { manager = it }
    }
}
