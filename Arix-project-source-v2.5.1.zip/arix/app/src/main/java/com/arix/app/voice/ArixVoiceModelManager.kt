package com.arix.app.voice

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.apache.commons.compress.archivers.tar.TarArchiveEntry
import org.apache.commons.compress.archivers.tar.TarArchiveInputStream
import org.apache.commons.compress.compressors.bzip2.BZip2CompressorInputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.IOException
import java.util.concurrent.TimeUnit
import java.util.zip.ZipInputStream

/**
 * v2.4.9: on-demand downloader + extractor for the offline voice models.
 *
 * Nothing is bundled inside the APK (keeps the install small); both models
 * are fetched on the first use from their official sources:
 *  - Vosk small en-us 0.15  → alphacephei.com (~40 MB zip)
 *  - Kokoro int8 en v0.19   → sherpa-onnx GitHub releases (~82 MB tar.bz2)
 */
class ArixVoiceModelManager(
    private val context: Context,
    internal val repository: ArixVoiceRepository,
) {
    sealed interface DownloadState {
        data object Idle : DownloadState
        data class Downloading(val model: String, val progressPercent: Int, val megabytesDone: Float, val megabytesTotal: Float) : DownloadState
        data class Extracting(val model: String) : DownloadState
        data class Done(val model: String, val success: Boolean, val error: String = "") : DownloadState
    }

    private val _downloadState = MutableStateFlow<DownloadState>(DownloadState.Idle)
    val downloadState: StateFlow<DownloadState> = _downloadState.asStateFlow()

    private val mutex = Mutex()
    private val httpClient = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .followRedirects(true)
        .build()

    val isVoskModelInstalled: Boolean
        get() = File(repository.voskModelDirectory(), "final.mdl").exists() ||
            File(repository.voskModelDirectory(), "am/final.mdl").exists()

    val isKokoroModelInstalled: Boolean
        get() = File(repository.kokoroModelDirectory(), "model.int8.onnx").exists()

    suspend fun ensureVoskModel(): Result<File> = installModel(
        model = "vosk",
        url = "https://alphacephei.com/vosk/models/vosk-model-small-en-us-0.15.zip",
        targetDirectory = repository.voskModelDirectory(),
        expectedSizeBytes = 41_205_931L,
    )

    suspend fun ensureKokoroModel(): Result<File> = installModel(
        model = "kokoro",
        url = "https://github.com/k2-fsa/sherpa-onnx/releases/download/tts-models/kokoro-int8-en-v0_19.tar.bz2",
        targetDirectory = repository.kokoroModelDirectory(),
        expectedSizeBytes = 0L,
    )

    private suspend fun installModel(
        model: String,
        url: String,
        targetDirectory: File,
        expectedSizeBytes: Long,
    ): Result<File> = mutex.withLock {
        if (targetDirectory.isDirectory && targetDirectory.exists()) {
            val ready = when (model) {
                "vosk" -> isVoskModelInstalled
                else -> isKokoroModelInstalled
            }
            if (ready) return@withLock Result.success(targetDirectory)
        }
        withContext(Dispatchers.IO) {
            try {
                val archiveFile = File(context.cacheDir, "voice-$model.download")
                archiveFile.delete()
                download(url, archiveFile, model, expectedSizeBytes)
                _downloadState.value = DownloadState.Extracting(model)
                targetDirectory.deleteRecursively()
                val extractedRoot = when {
                    archiveFile.name.endsWith(".zip") -> extractZip(archiveFile, targetDirectory.parentFile)
                    else -> extractTarBz2(archiveFile, targetDirectory.parentFile)
                }
                archiveFile.delete()
                if (extractedRoot == null) {
                    _downloadState.value = DownloadState.Done(model, false, "Extraction failed")
                    return@withContext Result.failure(IOException("Could not extract the $model model archive."))
                }
                // Persist the canonical model directory (works whether the
                // archive wrapped files in a top-level folder or not).
                val resolvedDirectory = when (model) {
                    "vosk" -> findVoskModelRoot(extractedRoot) ?: targetDirectory
                    else -> findKokoroModelRoot(extractedRoot) ?: targetDirectory
                }
                when (model) {
                    "vosk" -> repository.setVoskModelPath(resolvedDirectory.absolutePath)
                    else -> repository.setKokoroModelPath(resolvedDirectory.absolutePath)
                }
                _downloadState.value = DownloadState.Done(model, true)
                Result.success(resolvedDirectory)
            } catch (throwable: Throwable) {
                if (throwable is kotlinx.coroutines.CancellationException) throw throwable
                _downloadState.value = DownloadState.Done(model, false, throwable.message ?: "download failed")
                Result.failure(throwable)
            }
        }
    }

    private fun findVoskModelRoot(root: File): File? {
        if (File(root, "am/final.mdl").exists() || File(root, "final.mdl").exists()) return root
        return root.listFiles { file -> file.isDirectory }
            ?.mapNotNull { findVoskModelRoot(it) }
            ?.firstOrNull()
    }

    private fun findKokoroModelRoot(root: File): File? {
        if (File(root, "model.int8.onnx").exists()) return root
        return root.listFiles { file -> file.isDirectory }
            ?.mapNotNull { findKokoroModelRoot(it) }
            ?.firstOrNull()
    }

    private fun download(url: String, target: File, model: String, expectedSizeBytes: Long) {
        val request = Request.Builder().url(url).header("User-Agent", "Arix/${context.packageName}").build()
        httpClient.newCall(request).execute().use { response ->
            if (!response.isSuccessful) throw IOException("Download failed: HTTP ${response.code}")
            val body = response.body ?: throw IOException("Download failed: empty response")
            val totalBytes = if (body.contentLength() > 0) body.contentLength() else expectedSizeBytes
            var doneBytes = 0L
            body.byteStream().use { input ->
                FileOutputStream(target).use { output ->
                    val buffer = ByteArray(64 * 1024)
                    var read = input.read(buffer)
                    var lastProgress = -1
                    while (read >= 0) {
                        output.write(buffer, 0, read)
                        doneBytes += read
                        if (totalBytes > 0) {
                            val percent = ((doneBytes * 100) / totalBytes).toInt().coerceIn(0, 100)
                            if (percent != lastProgress) {
                                lastProgress = percent
                                _downloadState.value = DownloadState.Downloading(
                                    model = model,
                                    progressPercent = percent,
                                    megabytesDone = doneBytes / 1_048_576f,
                                    megabytesTotal = totalBytes / 1_048_576f,
                                )
                            }
                        }
                        read = input.read(buffer)
                    }
                }
            }
            if (totalBytes > 0 && doneBytes < totalBytes) {
                throw IOException("Download incomplete (${doneBytes}/${totalBytes} bytes)")
            }
        }
    }

    private fun extractZip(archive: File, targetParent: File): File? {
        ZipInputStream(FileInputStream(archive)).use { zip ->
            var entry = zip.nextEntry
            while (entry != null) {
                val sanitized = sanitizeEntryName(entry.name)
                if (sanitized != null) {
                    val destination = File(targetParent, sanitized)
                    if (entry.isDirectory) {
                        destination.mkdirs()
                    } else {
                        destination.parentFile?.mkdirs()
                        FileOutputStream(destination).use { output ->
                            zip.copyTo(output)
                        }
                    }
                }
                zip.closeEntry()
                entry = zip.nextEntry
            }
        }
        return targetParent
    }

    private fun extractTarBz2(archive: File, targetParent: File): File? {
        TarArchiveInputStream(BZip2CompressorInputStream(FileInputStream(archive))).use { tar ->
            var entry: TarArchiveEntry? = tar.nextTarEntry
            while (entry != null) {
                val sanitized = sanitizeEntryName(entry.name)
                if (sanitized != null) {
                    val destination = File(targetParent, sanitized)
                    if (entry.isDirectory) {
                        destination.mkdirs()
                    } else {
                        destination.parentFile?.mkdirs()
                        FileOutputStream(destination).use { output ->
                            tar.copyTo(output)
                        }
                    }
                }
                entry = tar.nextTarEntry
            }
        }
        return targetParent
    }

    /** Blocks path traversal (../) entries inside archives. */
    private fun sanitizeEntryName(name: String): String? {
        val normalized = name.replace('\\', '/')
        if (normalized.isBlank() || normalized.startsWith("/") || normalized.contains("../")) return null
        return normalized
    }

    /** Manual delete from Settings → Voice → storage. */
    suspend fun deleteModels(): Boolean = withContext(Dispatchers.IO) {
        repository.setVoskModelPath("")
        repository.setKokoroModelPath("")
        val root = repository.modelsRoot()
        val deleted = root.deleteRecursively()
        root.mkdirs()
        _downloadState.value = DownloadState.Idle
        deleted
    }

    fun modelStorageBytes(): Long {
        val root = repository.modelsRoot()
        return root.walkTopDown().filter { it.isFile }.sumOf { it.length() }
    }
}
