package com.arix.app.ui

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.ContextWrapper
import android.content.Intent
import android.content.Context
import android.net.Uri
import android.provider.Settings
import android.util.Patterns
import android.widget.Toast
import androidx.activity.compose.BackHandler
import com.arix.app.ArixLocaleManager
import com.arix.app.R
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.ime
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.ClickableText
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.ArrowUpward
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.Create
import androidx.compose.material.icons.rounded.GridView
import androidx.compose.material.icons.rounded.Image
import androidx.compose.material.icons.rounded.KeyboardVoice
import androidx.compose.material.icons.rounded.Lightbulb
import androidx.compose.material.icons.rounded.Menu
import androidx.compose.material.icons.rounded.MoreHoriz
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.Visibility
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.viewmodel.compose.viewModel
import com.arix.app.ArixApplication
import com.arix.app.data.ArixPrivacyPolicyUrl
import com.arix.app.data.ArixWebsiteUrl
import com.arix.app.data.AppLanguage
import com.arix.app.data.AppSettings
import com.arix.app.data.AutomaticModelPurpose
import com.arix.app.data.ProviderModelOption
import com.arix.app.data.PiExtensionUiRequest
import com.arix.app.data.availableModelOptions
import com.arix.app.data.isOnboardingComplete
import com.arix.app.data.resolveAutomaticModelKey
import com.arix.app.data.LocalRuntimeId
import com.arix.app.platform.LocalReduceMotion
import com.arix.app.mod.ArixNativeModState
import com.arix.app.runtime.LocalRuntimeIssue
import com.arix.app.runtime.LocalRuntimeSetupState
import com.arix.app.runtime.AndroidAlpineFileManagerRuntime
import com.arix.app.ui.theme.ArixBackground
import com.arix.app.ui.theme.ArixOnSurface
import com.arix.app.ui.theme.ArixOnSurfaceVariant
import com.arix.app.ui.theme.ArixPrimary
import com.arix.app.ui.theme.ArixScrim
import com.arix.app.ui.theme.ArixSurface
import com.arix.app.ui.theme.ArixSurfaceHigh
import com.arix.app.ui.theme.ArixSurfaceHigher
import com.arix.app.ui.theme.ArixTheme
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject


private data class SuggestionAction(
    val icon: ImageVector,
    val label: String,
    val tint: Color,
)

private sealed interface PendingSaveTarget {
    data class Attachment(val attachment: ChatAttachment) : PendingSaveTarget
    data class WorkspaceFile(val rawLink: String) : PendingSaveTarget
}

private const val ScreenTransitionDuration = 320
private val ScreenTransitionEasing = CubicBezierEasing(0.22f, 0.84f, 0.18f, 1f)
private const val PrivacyPolicyAnnotationTag = "privacy_policy"

private fun AppScreen.depth(): Int = when (this) {
    AppScreen.Onboarding -> 0
    AppScreen.Chat -> 1
    AppScreen.Tools -> 1
    AppScreen.Terminal -> 1
    AppScreen.Browser -> 1
    AppScreen.Files -> 1
    AppScreen.Settings -> 2
}

/** Screens owned by the bottom navigation bar (icon-only pill). */
private val AppScreen.isMainTab: Boolean
    get() = this == AppScreen.Chat || this == AppScreen.Tools ||
        this == AppScreen.Terminal || this == AppScreen.Browser ||
        this == AppScreen.Files

private fun ArixUiState.toArixExtensionContext(): JSONObject {
    val activeSession = sessions.firstOrNull { it.id == currentSessionId }
    val execution = sessionExecutionStates[currentSessionId]
    val selectedSkillIds = activeSession?.selectedSkillIds ?: draftSelectedSkillIds
    val selectedMcpServerIds = activeSession?.activeMcpServerIds ?: draftSelectedMcpServerIds
    return JSONObject().apply {
        put("screen", currentScreen.name.lowercase())
        put("session_id", currentSessionId)
        put("session_title", activeSession?.title.orEmpty())
        put("message_count", activeSession?.messages?.size ?: 0)
        put("draft_input", draftInput)
        put("is_running", execution?.isRunning == true)
        put("is_editing", editingMessageId != null)
        put("selected_model_key", activeSession?.selectedModelKey ?: draftSelectedModelKey)
        put("agent_mode_enabled", activeSession?.agentModeEnabled ?: draftAgentModeEnabled)
        put("selected_skill_ids", JSONArray(selectedSkillIds))
        put("selected_mcp_server_ids", JSONArray(selectedMcpServerIds))
        put("default_skill_ids", JSONArray(settings.defaultSelectedSkillIds))
        put(
            "skills",
            JSONArray().apply {
                installedSkills.forEach { skill ->
                    put(
                        JSONObject().apply {
                            put("id", skill.id)
                            put("name", skill.name)
                            put("description", skill.description)
                            put("action_label", skill.actionLabel)
                            put("enabled", skill.isEnabled)
                            put("selected", skill.id in selectedSkillIds)
                            put("default_selected", skill.id in settings.defaultSelectedSkillIds)
                        }
                    )
                }
            },
        )
        put("language", settings.language.storageValue)
        put("theme", settings.themeMode.storageValue)
        put("extension_count", installedPiExtensions.size)
        put("skill_count", installedSkills.count { it.isEnabled })
        put("mcp_server_count", mcpServers.count { it.isEnabled })
        put(
            "custom_messages",
            JSONArray(
                activeSession?.messages
                    ?.mapNotNull { message -> message.customExtensionMessageJson() }
                    ?.takeLast(8)
                    .orEmpty(),
            ),
        )
    }
}

private tailrec fun Context.findActivity(): Activity? = when (this) {
    is Activity -> this
    is ContextWrapper -> baseContext.findActivity()
    else -> null
}

@Composable
fun ArixApp(
    viewModel: ArixViewModel = viewModel(),
    onNotificationPermissionRequested: () -> Unit = {},
) {
    val uiState = viewModel.uiState.collectAsStateWithLifecycle().value
    val context = LocalContext.current
    val applicationLanguage = ArixLocaleManager.currentApplicationLanguage()
    val effectiveLanguage = applicationLanguage ?: uiState.settings.language
    val appRuntime = remember(context) {
        (context.applicationContext as ArixApplication).runtime
    }
    val extensionManager = appRuntime.arixAppExtensionManager
    val extensionState = extensionManager.state.collectAsStateWithLifecycle().value
    val piExtensionUiRequest = extensionManager.piUiRequest.collectAsStateWithLifecycle().value
    val nativeModState = appRuntime.nativeModManager.state.collectAsStateWithLifecycle().value
    val nativeComponents =
        appRuntime.modKernel.components.registrations.collectAsStateWithLifecycle().value
    val extensionContext = remember(uiState) {
        uiState.toArixExtensionContext()
    }
    val extensionController = remember(
        extensionState.snapshot,
        nativeComponents,
        uiState,
        extensionContext,
        viewModel,
    ) {
        ArixExtensionUiController(
            snapshot = extensionState.snapshot,
            runtimeError = extensionState.error,
            nativeComponents = nativeComponents,
            uiState = uiState,
            publicState = extensionContext,
            onHostCall = viewModel::handleArixExtensionHostCall,
            onAction = { extensionId, action, args ->
                extensionManager.invokeAction(extensionId, action, args)
            },
        )
    }

    LaunchedEffect(uiState.settings.language, applicationLanguage) {
        if (applicationLanguage == null) {
            ArixLocaleManager.applyIfChanged(uiState.settings.language)
        } else if (applicationLanguage != uiState.settings.language) {
            viewModel.updateAppLanguage(applicationLanguage)
        }
    }

    LaunchedEffect(extensionManager, extensionContext.toString(), uiState.alpineSetupState.isReady) {
        if (!uiState.alpineSetupState.isReady) return@LaunchedEffect
        extensionManager.start(extensionContext)
        extensionManager.updateContext(extensionContext)
    }

    LaunchedEffect(extensionManager, context) {
        extensionManager.notifications.collect { notification ->
            // v2.4.2: extension command output (e.g. "/mcp" server status) is
            // multi-line and needs more than the 2s short toast to be read.
            val duration = if (notification.message.length > 40) Toast.LENGTH_LONG else Toast.LENGTH_SHORT
            Toast.makeText(context, notification.message, duration).show()
        }
    }

    DisposableEffect(extensionManager, viewModel) {
        extensionManager.setHostHandler(viewModel::handleArixExtensionHostCall)
        onDispose {
            extensionManager.clearHostHandler()
        }
    }

    LaunchedEffect(uiState.currentScreen) {
        if (uiState.currentScreen == AppScreen.Settings) {
            viewModel.refreshUsageStatisticsSnapshots()
        }
    }

    CompositionLocalProvider(
        LocalArixExtensionUiController provides extensionController,
    ) {
        ArixTheme(
            themeMode = uiState.settings.themeMode,
            language = effectiveLanguage,
        ) {
            Surface(
                modifier = Modifier.fillMaxSize(),
                color = MaterialTheme.colorScheme.background,
            ) {
                Box(modifier = Modifier.fillMaxSize()) {
                    ArixExtensionComponentHost(
                        target = ArixExtensionComponentAppContent,
                        modifier = Modifier.fillMaxSize(),
                    ) {
                        ArixAppContent(
                                viewModel = viewModel,
                                uiState = uiState,
                                language = effectiveLanguage,
                                nativeModState = nativeModState,
                                onNotificationPermissionRequested = onNotificationPermissionRequested,
                                drawerOpenedEventRegistered =
                                    "drawer.opened" in extensionState.snapshot.eventNames,
                                onDrawerOpened = {
                                    extensionManager.emitEvent(
                                        event = "drawer.opened",
                                        context = extensionContext,
                                    )
                                },
                        )
                    }
                    ArixExtensionOverlaySlot(Modifier.fillMaxSize())
                }
            }
            piExtensionUiRequest?.let { request ->
                PiExtensionUiDialog(
                    request = request,
                    onResult = { value ->
                        extensionManager.respondToPiExtensionUiRequest(request.callId, value)
                    },
                )
            }
        }
    }
}

@Composable
private fun PiExtensionUiDialog(
    request: PiExtensionUiRequest,
    onResult: (Any?) -> Unit,
) {
    var input by remember(request.callId) { mutableStateOf("") }
    val dismissValue: Any? = if (request.method == "pi_extension_confirm") false else null
    AlertDialog(
        onDismissRequest = { onResult(dismissValue) },
        containerColor = ArixSurface,
        titleContentColor = ArixOnSurface,
        textContentColor = ArixOnSurfaceVariant,
        title = { Text(request.title) },
        text = {
            when (request.method) {
                "pi_extension_select" -> Column {
                    request.options.forEach { option ->
                        TextButton(
                            modifier = Modifier.fillMaxWidth(),
                            onClick = { onResult(option) },
                        ) {
                            Text(option, modifier = Modifier.fillMaxWidth())
                        }
                    }
                }

                "pi_extension_input" -> OutlinedTextField(
                    value = input,
                    onValueChange = { input = it },
                    modifier = Modifier.fillMaxWidth(),
                    placeholder = request.placeholder.takeIf(String::isNotBlank)?.let { placeholder ->
                        { Text(placeholder) }
                    },
                    singleLine = true,
                )

                else -> Text(request.message)
            }
        },
        confirmButton = {
            if (request.method != "pi_extension_select") {
                TextButton(
                    onClick = {
                        onResult(
                            if (request.method == "pi_extension_confirm") true else input,
                        )
                    },
                ) {
                    Text(stringResource(R.string.common_done))
                }
            }
        },
        dismissButton = {
            TextButton(onClick = { onResult(dismissValue) }) {
                Text(stringResource(R.string.common_cancel))
            }
        },
    )
}

@Composable
private fun ArixAppContent(
    viewModel: ArixViewModel,
    uiState: ArixUiState,
    language: AppLanguage,
    nativeModState: ArixNativeModState,
    onNotificationPermissionRequested: () -> Unit,
    drawerOpenedEventRegistered: Boolean,
    onDrawerOpened: () -> Unit,
) {
    val reduceMotion = LocalReduceMotion.current
    val drawerState = rememberDrawerState(initialValue = androidx.compose.material3.DrawerValue.Closed)
    val latestOnDrawerOpened by rememberUpdatedState(onDrawerOpened)
    val drawerOpenedEventGate = remember { ArixDrawerOpenedEventGate() }
    val scope = rememberCoroutineScope()
    val context = LocalContext.current

    LaunchedEffect(drawerState, drawerOpenedEventRegistered) {
        snapshotFlow { drawerState.currentValue to drawerState.targetValue }
            .distinctUntilChanged()
            .collect { (currentValue, targetValue) ->
                val shouldDispatchDrawerOpened = drawerOpenedEventGate.onDrawerSnapshotChanged(
                    currentOpen = currentValue == DrawerValue.Open,
                    targetOpen = targetValue == DrawerValue.Open,
                    eventRegistered = drawerOpenedEventRegistered,
                )
                if (shouldDispatchDrawerOpened) {
                    latestOnDrawerOpened()
                }
            }
    }

    val lifecycleOwner = LocalLifecycleOwner.current
    val clipboardManager = LocalClipboardManager.current
    val appRuntime = remember(context) {
        (context.applicationContext as ArixApplication).runtime
    }
    val workspaceFileBridge = appRuntime.workspaceFileBridge
    val alpineFileManagerRuntime = remember(appRuntime.alpineRuntime) {
        AndroidAlpineFileManagerRuntime(appRuntime.alpineRuntime)
    }
    val runtimeWorkspaceFileBridge = appRuntime.runtimeWorkspaceFileBridge
    val activeSession = uiState.sessions.firstOrNull { it.id == uiState.currentSessionId }
    val activeProviderConfig = uiState.providerConfigs.firstOrNull { it.isEnabled }
        ?: uiState.providerConfigs.firstOrNull()
    val currentSessionExecution = uiState.sessionExecutionStates[uiState.currentSessionId]
    val activeStreamingResponseGroupId = currentSessionExecution
        ?.takeIf { it.isRunning }
        ?.activeResponseGroupId
    val sessionMessages = activeSession?.messages.orEmpty()
    val currentMessages = remember(sessionMessages, activeStreamingResponseGroupId) {
        if (activeStreamingResponseGroupId == null) {
            sessionMessages
        } else {
            sessionMessages.filterNot { message ->
                message.isIncomplete && message.responseGroupId == activeStreamingResponseGroupId
            }
        }
    }
    val selectedSkillIds = activeSession?.selectedSkillIds ?: uiState.draftSelectedSkillIds
    val selectedMcpServerIds = activeSession?.activeMcpServerIds ?: uiState.draftSelectedMcpServerIds
    // v2.3.2: Agent Mode (accessibility) removed — never offered in the composer.
    val agentModeReady = false
    val agentModeSelected = activeSession?.agentModeEnabled ?: uiState.draftAgentModeEnabled
    val chromeAvailable = uiState.alpineSetupState.isReady &&
        uiState.settings.alpinePackageProfiles["chrome"]?.installed == true
    val chromeSelected = activeSession?.chromeEnabled ?: uiState.draftChromeEnabled
    val conversationModelOptions = remember(uiState.providerConfigs) {
        uiState.providerConfigs.availableModelOptions()
    }
    val selectedConversationModelKey = remember(
        activeSession?.selectedModelKey,
        uiState.draftSelectedModelKey,
        uiState.settings.defaultChatModelKey,
        conversationModelOptions,
    ) {
        resolveConversationModelKey(
            session = activeSession,
            draftSelectedModelKey = uiState.draftSelectedModelKey,
            defaultChatModelKey = uiState.settings.defaultChatModelKey,
            options = conversationModelOptions,
        )
    }
    val pendingToolInvocations = currentSessionExecution?.pendingToolInvocations.orEmpty()
    val pendingResponseBlocks = currentSessionExecution?.pendingResponseBlocks.orEmpty()
    val pendingAssistantText = currentSessionExecution?.pendingAssistantText.orEmpty()
    val pendingInputs = currentSessionExecution?.pendingInputs.orEmpty()
    val isCurrentSessionRunning = currentSessionExecution?.isRunning == true
    val currentWorkspaceDirectory = workspaceFileBridge.workspaceDirectory(
        sessionId = uiState.currentSessionId,
        mode = uiState.settings.agentWorkspaceMode,
    )
    val currentRuntimeWorkspaceDirectory = appRuntime.runtimeRouter.runtimeWorkspaceDirectory(
        settings = uiState.settings,
    )

    LaunchedEffect(viewModel, context) {
        viewModel.transientMessages.collectLatest { message ->
            Toast.makeText(context, message.resolve(context), Toast.LENGTH_SHORT).show()
        }
    }
    LaunchedEffect(uiState.settings.privacyPolicyAccepted) {
        if (uiState.settings.privacyPolicyAccepted) {
            onNotificationPermissionRequested()
        }
    }
    var pendingSaveTarget by remember { mutableStateOf<PendingSaveTarget?>(null) }
    var pendingSessionExportId by remember { mutableStateOf<String?>(null) }
    var pendingSkillZipCompletion by remember { mutableStateOf<((Boolean) -> Unit)?>(null) }
    var showAppDataExportWarning by remember { mutableStateOf(false) }
    val onPickedDocuments: (List<Uri>) -> Unit = { uris ->
        uris.forEach { uri ->
            runCatching {
                context.contentResolver.takePersistableUriPermission(
                    uri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION,
                )
            }
        }
        viewModel.appendDraftAttachments(uris)
    }
    val imagePicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickMultipleVisualMedia(),
        onResult = onPickedDocuments,
    )
    val filePicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetMultipleContents(),
        onResult = onPickedDocuments,
    )
    val skillFolderPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocumentTree(),
        onResult = { treeUri ->
            if (treeUri != null) {
                runCatching {
                    context.contentResolver.takePersistableUriPermission(
                        treeUri,
                        Intent.FLAG_GRANT_READ_URI_PERMISSION,
                    )
                }
                viewModel.installSkillFromDirectory(treeUri)
            }
        },
    )
    val skillZipPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument(),
        onResult = { zipUri ->
            val completion = pendingSkillZipCompletion
            pendingSkillZipCompletion = null
            if (zipUri != null) {
                runCatching {
                    context.contentResolver.takePersistableUriPermission(
                        zipUri,
                        Intent.FLAG_GRANT_READ_URI_PERMISSION,
                    )
                }
                viewModel.installSkillFromZip(zipUri) { success ->
                    completion?.invoke(success)
                }
            } else {
                completion?.invoke(false)
            }
        },
    )
    val piExtensionImportPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument(),
        onResult = { extensionUri ->
            if (extensionUri != null) {
                runCatching {
                    context.contentResolver.takePersistableUriPermission(
                        extensionUri,
                        Intent.FLAG_GRANT_READ_URI_PERMISSION,
                    )
                }
                viewModel.importPiExtension(extensionUri)
            }
        },
    )
    val saveAttachmentLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("*/*"),
        onResult = { destinationUri ->
            val saveTarget = pendingSaveTarget
            pendingSaveTarget = null

            if (saveTarget == null || destinationUri == null) {
                return@rememberLauncherForActivityResult
            }

            scope.launch {
                val didSave = withContext(Dispatchers.IO) {
                    when (saveTarget) {
                        is PendingSaveTarget.Attachment -> saveAttachmentToDocument(
                            context = context,
                            attachment = saveTarget.attachment,
                            destinationUri = destinationUri,
                        )

                        is PendingSaveTarget.WorkspaceFile -> runtimeWorkspaceFileBridge.saveWorkspaceFileToDocument(
                            settings = uiState.settings,
                            path = saveTarget.rawLink,
                            workingDirectory = currentRuntimeWorkspaceDirectory,
                            destinationUri = destinationUri,
                        )
                    }
                }
                Toast.makeText(
                    context,
                    context.getString(if (didSave) R.string.file_saved else R.string.file_could_not_save),
                    Toast.LENGTH_SHORT,
                ).show()
            }
        },
    )
    val sessionExportLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/json"),
        onResult = { destinationUri ->
            val sessionId = pendingSessionExportId
            pendingSessionExportId = null
            if (sessionId != null && destinationUri != null) {
                viewModel.exportSessionToUri(sessionId, destinationUri)
            }
        },
    )
    val appDataExportLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/json"),
        onResult = { destinationUri ->
            if (destinationUri != null) {
                viewModel.exportAllDataToUri(destinationUri)
            }
        },
    )
    val logExportLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("text/plain"),
        onResult = { destinationUri ->
            if (destinationUri != null) {
                viewModel.exportLogsToUri(destinationUri)
            }
        },
    )
    val appDataImportLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument(),
        onResult = { sourceUri ->
            if (sourceUri != null) {
                runCatching {
                    context.contentResolver.takePersistableUriPermission(
                        sourceUri,
                        Intent.FLAG_GRANT_READ_URI_PERMISSION,
                    )
                }
                viewModel.importAllDataFromUri(sourceUri)
            }
        },
    )
    if (drawerState.isOpen) {
        BackHandler {
            scope.launch { drawerState.close() }
        }
    }

    ModalNavigationDrawer(
        drawerState = drawerState,
        gesturesEnabled = uiState.currentScreen == AppScreen.Chat,
        scrimColor = ArixScrim,
        drawerContent = {
            ConversationDrawer(
                sessions = uiState.sessions,
                selectedSessionId = uiState.currentSessionId,
                sessionExecutionStates = uiState.sessionExecutionStates,
                unviewedCompletedSessionIds = uiState.unviewedCompletedSessionIds,
                onNewChat = {
                    viewModel.startNewChat()
                    scope.launch { drawerState.close() }
                },
                onSessionSelected = { sessionId ->
                    viewModel.selectSession(sessionId)
                    scope.launch { drawerState.close() }
                },
                onRenameSession = viewModel::renameSession,
                onExportSession = { session ->
                    pendingSessionExportId = session.id
                    sessionExportLauncher.launch("${session.title.ifBlank { "arix-session" }}.json")
                },
                onDeleteSession = viewModel::deleteSession,
                onSettingsSelected = {
                    scope.launch {
                        drawerState.close()
                        viewModel.openSettings()
                    }
                },
            )
        },
    ) {
        if (!uiState.isStartupRouteResolved) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(ArixBackground)
            )
        } else {
            Box(modifier = Modifier.fillMaxSize()) {
            AnimatedContent(
                targetState = uiState.currentScreen,
                transitionSpec = {
                    if (reduceMotion) {
                        return@AnimatedContent fadeIn(tween(80)) togetherWith fadeOut(tween(60))
                    }
                    val isForward = targetState.depth() > initialState.depth()
                    val enterSlide = slideInHorizontally(
                        animationSpec = tween(ScreenTransitionDuration, easing = ScreenTransitionEasing),
                        initialOffsetX = { if (isForward) it / 3 else -it / 3 },
                    ) + fadeIn(tween(ScreenTransitionDuration, easing = ScreenTransitionEasing))
                    val exitSlide = slideOutHorizontally(
                        animationSpec = tween(ScreenTransitionDuration, easing = ScreenTransitionEasing),
                        targetOffsetX = { if (isForward) -it / 3 else it / 3 },
                    ) + fadeOut(tween(ScreenTransitionDuration, easing = ScreenTransitionEasing))
                    enterSlide togetherWith exitSlide
                },
                label = "app_screen_transition",
            ) { currentScreen ->
                when (currentScreen) {
                    AppScreen.Onboarding -> OnboardingScreen(
                        initialStep = uiState.onboardingStep,
                        replayMode = uiState.isOnboardingReplay,
                        setupPreviewMode = uiState.developerAlpineSetupPreviewState != null,
                        existingProviderConfig = activeProviderConfig,
                        isFetchingModels = uiState.isFetchingModels,
                        providerAuthState = uiState.providerAuthState,
                        piCoreSetupState = uiState.developerAlpineSetupPreviewState
                            ?: uiState.piCoreSetupState,
                        alpineSetupState = if (uiState.developerAlpineSetupPreviewState != null) {
                            LocalRuntimeSetupState(
                                runtimeId = LocalRuntimeId.Alpine,
                                issue = LocalRuntimeIssue.Ready,
                            )
                        } else {
                            uiState.alpineSetupState
                        },
                        tavilyApiKey = uiState.settings.tavilyApiKey,
                        onFetchModels = viewModel::fetchModels,
                        onStartProviderLogin = viewModel::startProviderLogin,
                        onSubmitProviderAuthPrompt = viewModel::submitProviderAuthPrompt,
                        onClearProviderAuthState = viewModel::clearProviderAuthState,
                        onSkip = viewModel::skipOnboarding,
                        onClose = viewModel::closeOnboarding,
                        onCompleteProviderSetup = viewModel::completeOnboardingProviderSetup,
                        onSaveTavilyApiKey = viewModel::saveOnboardingTavilyApiKey,
                        onInitializeAlpineRuntime = {
                            if (uiState.developerAlpineSetupPreviewState != null) {
                                viewModel.restartDeveloperAlpineSetupPreview()
                            } else {
                                viewModel.initializeAlpineRuntime(makeDefault = true)
                            }
                        },
                        onRetryAlpineSetup = {
                            if (uiState.developerAlpineSetupPreviewState != null) {
                                viewModel.restartDeveloperAlpineSetupPreview()
                            } else {
                                viewModel.retryAlpineRuntimeSetup(makeDefault = true)
                            }
                        },
                        onRefreshAlpineSetup = {
                            if (uiState.developerAlpineSetupPreviewState != null) {
                                viewModel.restartDeveloperAlpineSetupPreview()
                            } else {
                                viewModel.refreshAlpineSetup(startPiIfReady = true)
                            }
                        },
                        onCompleteFollowUp = viewModel::completeFollowUpOnboarding,
                    )

                    AppScreen.Chat -> ArixExtensionComponentHost(
                        target = ArixExtensionComponentChatScreen,
                        modifier = Modifier.fillMaxSize(),
                    ) {
                        ConversationScreen(
                    conversationStateKey = uiState.currentSessionId,
                    messages = currentMessages,
                    workspaceDirectory = currentRuntimeWorkspaceDirectory,
                    pendingToolInvocations = pendingToolInvocations,
                    pendingToolInvocationStateKey = "pending-tools-${uiState.currentSessionId}",
                    pendingResponseBlocks = pendingResponseBlocks,
                    pendingAssistantText = pendingAssistantText,
                    pendingStatusText = currentSessionExecution?.pendingStatusText.orEmpty(),
                    pendingStatusDetail = currentSessionExecution?.pendingStatusDetail.orEmpty(),
                    activeTurnStartedAtMillis = currentSessionExecution?.activeTurnStartedAtMillis,
                    isCompacting = uiState.compactingSessionId == uiState.currentSessionId,
                    pendingInputs = pendingInputs,
                    inputValue = uiState.draftInput,
                    draftAttachments = uiState.draftAttachments,
                    modelOptions = conversationModelOptions,
                    modelCatalogInfo = uiState.modelCatalogInfo,
                    selectedModelKey = selectedConversationModelKey,
                    reasoningEffort = uiState.settings.reasoningEffort,
                    thinkingLevelsByProviderModel = uiState.thinkingLevelsByProviderModel,
                    thinkingLevelClampsByProviderModel = uiState.thinkingLevelClampsByProviderModel,
                    availableSkills = uiState.installedSkills.filter { it.isEnabled },
                    availableMcpServers = uiState.mcpServers.filter { it.isEnabled },
                    selectedSkillIds = selectedSkillIds,
                    selectedMcpServerIds = selectedMcpServerIds,
                    agentModeAvailable = agentModeReady,
                    agentModeSelected = agentModeSelected,
                    agentModeDisplayState = uiState.chromeDisplayState,
                    chromeAvailable = chromeAvailable,
                    chromeSelected = chromeSelected,
                    chromeDisplayState = uiState.chromeDisplayState,
                    isEditing = uiState.editingMessageId != null,
                    showStarterPromptHint = uiState.showStarterPromptHint,
                    voiceInputEnabled = uiState.voiceSettings.voiceInputEnabled && uiState.voiceSettings.voskModelInstalled,
                    voiceInputState = uiState.voiceInputState,
                    onStartVoiceInput = viewModel::startVoiceInput,
                    onStopVoiceInput = viewModel::stopVoiceInput,
                    onVoiceTranscriptFinal = viewModel::appendVoiceTranscript,
                    onInputChanged = viewModel::updateDraftInput,
                    onModelSelected = viewModel::setCurrentChatModelSelectionAndResolveThinkingLevels,
                    onModelSelectorOpened = viewModel::refreshCurrentChatThinkingLevels,
                    onReasoningEffortSelected = viewModel::setReasoningEffort,
                    onRemoveDraftAttachment = viewModel::removeDraftAttachment,
                    onSetSkillSelected = viewModel::setComposerSkillSelected,
                    onSetMcpServerSelected = viewModel::setComposerMcpServerSelected,
                    onSetAgentModeSelected = viewModel::setComposerAgentModeSelected,
                    onSetChromeSelected = viewModel::setComposerChromeSelected,
                    onCancelEdit = viewModel::cancelMessageEdit,
                    onSend = viewModel::sendCurrentMessage,
                    onQueueFollowUp = viewModel::queueCurrentMessage,
                    onSteerFollowUp = viewModel::steerCurrentMessage,
                    onMenu = { scope.launch { drawerState.open() } },
                    onNewChat = viewModel::startNewChat,
                    onPickImages = {
                        imagePicker.launch(
                            PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                        )
                    },
                    onPickFiles = { filePicker.launch("*/*") },
                    onSaveAttachment = { attachment ->
                        pendingSaveTarget = PendingSaveTarget.Attachment(attachment)
                        saveAttachmentLauncher.launch(attachment.name)
                    },
                    onOpenLink = { rawLink ->
                        scope.launch {
                            handleAssistantLink(
                                context = context,
                                rawLink = rawLink,
                                onSaveWorkspaceFile = { fileLink ->
                                    pendingSaveTarget = PendingSaveTarget.WorkspaceFile(fileLink)
                                    saveAttachmentLauncher.launch(
                                        workspaceFileBridge.resolveWorkspaceDownloadName(fileLink)
                                    )
                                },
                            )
                        }
                    },
                    onEditMessage = { messageId ->
                        activeSession?.let { viewModel.startEditingUserMessage(it.id, messageId) }
                    },
                    onDeleteMessage = { messageId ->
                        activeSession?.let { viewModel.deleteMessage(it.id, messageId) }
                    },
                    onRedoAgentMessage = { messageId ->
                        activeSession?.let { viewModel.redoAgentMessage(it.id, messageId) }
                    },
                    onRetryUserMessage = { messageId ->
                        activeSession?.let { viewModel.retryUserMessage(it.id, messageId) }
                    },
                    onSwitchUserMessageBranch = { messageId, delta ->
                        activeSession?.let { viewModel.switchUserMessageBranch(it.id, messageId, delta) }
                    },
                    onCopyMessage = { message ->
                        clipboardManager.setText(AnnotatedString(message.text))
                        Toast.makeText(context, context.getString(R.string.file_reply_copied), Toast.LENGTH_SHORT).show()
                    },
                    onPauseGeneration = viewModel::pauseGeneration,
                    onDismissStarterPromptHint = viewModel::dismissStarterPromptHint,
                            isSending = isCurrentSessionRunning,
                            bottomBarReserve = if (uiState.currentScreen.isMainTab) {
                                ArixBottomNavBarHeight + 16.dp
                            } else {
                                0.dp
                            },
                        )
                    }

                    AppScreen.Tools -> ArixToolsScreen(
                        bottomBarReserve = ArixBottomNavBarHeight + 16.dp,
                        onBack = { viewModel.openMainTab(AppScreen.Chat) },
                    )

                    AppScreen.Terminal -> Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(bottom = ArixBottomNavBarHeight + 16.dp),
                    ) {
                        AlpineTerminalScreen(
                            createLaunchSpec = viewModel::createAlpineTerminalLaunchSpec,
                            onBack = { viewModel.openMainTab(AppScreen.Chat) },
                        )
                    }

                    AppScreen.Browser -> Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(bottom = ArixBottomNavBarHeight + 16.dp),
                    ) {
                        AlpineChromeScreen(
                            onStart = viewModel::startAlpineChrome,
                            onShouldShowKeyboard = viewModel::shouldShowAlpineChromeKeyboard,
                            onViewportSize = viewModel::updateAlpineChromeViewport,
                            onBack = { viewModel.openMainTab(AppScreen.Chat) },
                        )
                    }

                    // v2.4.2: Alpine file manager as a first-class bottom tab.
                    // Opens straight into /workspace (agent files, uploads,
                    // generated media) and falls back to a friendly setup card
                    // when the Alpine runtime has not been initialized yet.
                    AppScreen.Files -> Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(bottom = ArixBottomNavBarHeight + 16.dp),
                    ) {
                        if (uiState.alpineSetupState.isReady) {
                            AndroidAlpineFileManagerScreen(
                                runtime = alpineFileManagerRuntime,
                                initialPath = AlpineFilesTabInitialPath,
                                onBack = { viewModel.openMainTab(AppScreen.Chat) },
                            )
                        } else {
                            AlpineFilesSetupPrompt(
                                detail = uiState.alpineSetupState.detail,
                                onInitialize = { viewModel.initializeAlpineRuntime() },
                            )
                        }
                    }

                    AppScreen.Settings -> ArixExtensionComponentHost(
                        target = ArixExtensionComponentSettingsScreen,
                        modifier = Modifier.fillMaxSize(),
                    ) {
                        SettingsScreen(
                    systemPrompt = uiState.settings.systemPrompt,
                    tavilyApiKey = uiState.settings.tavilyApiKey,
                    tavilyBaseUrl = uiState.settings.tavilyBaseUrl,
                    llmInactivityReconnectTimeoutSeconds = uiState.settings.llmInactivityReconnectTimeoutSeconds,
                    keepTasksRunningInBackground = uiState.settings.keepTasksRunningInBackground,
                    notifyOnTaskCompletion = uiState.settings.notifyOnTaskCompletion,
                    agentWorkspaceMode = uiState.settings.agentWorkspaceMode,
                    autoCleanOldCommandHistory =
                        uiState.settings.autoCleanOldCommandHistory,
                    oldCommandHistoryRetentionHours =
                        uiState.settings.oldCommandHistoryRetentionHours,
                    language = language,
                    themeMode = uiState.settings.themeMode,
                    defaultChatModelKey = uiState.settings.defaultChatModelKey,
                    defaultTitleModelKey = uiState.settings.defaultTitleModelKey,
                    defaultNamingModelKey = uiState.settings.defaultNamingModelKey,
                    defaultCompactingModelKey = uiState.settings.defaultCompactingModelKey,
                    providerConfigs = uiState.providerConfigs,
                    usageStatisticsSnapshots = uiState.usageStatisticsSnapshots,
                    scheduledTasks = uiState.scheduledTasks,
                    alpineSetupState = uiState.alpineSetupState,
                    enabledRuntimeIds = uiState.settings.enabledRuntimeIds,
                    defaultRuntimeId = uiState.settings.defaultRuntimeId,
                    alpinePackageProfiles = uiState.settings.alpinePackageProfiles,
                    alpinePackageInstallProgress = uiState.alpinePackageInstallProgress,
                    alpineFileManagerRuntime = alpineFileManagerRuntime,
                    installedSkills = uiState.installedSkills,
                    installedPiExtensions = uiState.installedPiExtensions,
                    hasLoadedInstalledPiExtensions = uiState.hasLoadedInstalledPiExtensions,
                    nativeModState = nativeModState,
                    piExtensionCatalog = uiState.piExtensionCatalog,
                    isLoadingPiExtensions = uiState.isLoadingPiExtensions,
                    piExtensionCatalogError = uiState.piExtensionCatalogError,
                    piExtensionOperationSource = uiState.piExtensionOperationSource,
                    selectedPiPackageDetails = uiState.selectedPiPackageDetails,
                    selectedPiPackageSource = uiState.selectedPiPackageSource,
                    isLoadingPiPackageDetails = uiState.isLoadingPiPackageDetails,
                    piPackageDetailsError = uiState.piPackageDetailsError,
                    mcpServers = uiState.mcpServers,
                    isFetchingModels = uiState.isFetchingModels,
                    providerAuthState = uiState.providerAuthState,
                    onSave = viewModel::saveSettings,
                    onUpsertProviderConfig = viewModel::upsertProviderConfig,
                    onRemoveProviderConfig = viewModel::removeProviderConfig,
                    onSetProviderEnabled = viewModel::setProviderEnabled,
                    onFetchModels = viewModel::fetchModels,
                    onStartProviderLogin = viewModel::startProviderLogin,
                    onSubmitProviderAuthPrompt = viewModel::submitProviderAuthPrompt,
                    onClearProviderAuthState = viewModel::clearProviderAuthState,
                    onImportSkillFolder = { skillFolderPicker.launch(null) },
                    onImportSkillZip = { onComplete ->
                        pendingSkillZipCompletion = onComplete
                        skillZipPicker.launch(arrayOf("application/zip", "application/octet-stream", "*/*"))
                    },
                    onInstallSkillUrl = { url, onComplete ->
                        viewModel.installSkillFromRemote(url, onComplete)
                    },
                    onToggleSkillEnabled = viewModel::setSkillEnabled,
                    onRemoveSkill = viewModel::removeSkill,
                    onReinstallBuiltInSkill = viewModel::reinstallBuiltInSkill,
                    onRefreshPiExtensions = viewModel::refreshPiExtensions,
                    onInstallPiExtensionPackage = viewModel::installPiExtensionPackage,
                    onLoadPiPackageDetails = viewModel::loadPiPackageDetails,
                     onUpdatePiExtensionPackage = viewModel::updatePiExtensionPackage,
                     onRemovePiExtension = viewModel::removePiExtension,
                     onSetPiExtensionEnabled = viewModel::setPiExtensionEnabled,
                     onImportPiExtension = {
                        piExtensionImportPicker.launch(
                            arrayOf(
                                "application/zip",
                                "application/javascript",
                                "text/javascript",
                                "text/typescript",
                                "application/octet-stream",
                                "*/*",
                            )
                        )
                    },
                    onAllowNativeModsOnNextStart =
                        appRuntime.nativeModManager::allowNativeModsOnNextStart,
                    onDisableNativeModsOnNextStart =
                        appRuntime.nativeModManager::requestDisableOnNextStart,
                    onSaveHttpMcpServer = viewModel::saveStreamableHttpMcpServer,
                    onSaveStdIoMcpServer = viewModel::saveStdIoMcpServer,
                    onToggleMcpServerEnabled = viewModel::setMcpServerEnabled,
                    onRemoveMcpServer = viewModel::removeMcpServer,
                    onTestMcpServer = viewModel::testMcpServer,
                    onSaveScheduledTask = viewModel::saveScheduledTask,
                    onToggleScheduledTaskEnabled = viewModel::setScheduledTaskEnabled,
                    onRemoveScheduledTask = viewModel::removeScheduledTask,
                    onImportAppData = {
                        appDataImportLauncher.launch(arrayOf("application/json", "text/*", "*/*"))
                    },
                    onExportAppData = {
                        showAppDataExportWarning = true
                    },
                    onExportLogs = {
                        logExportLauncher.launch("arix-logs.txt")
                    },
                    onInitializeAlpineRuntime = { viewModel.initializeAlpineRuntime(makeDefault = false) },
                    onResetAlpineRuntime = viewModel::resetAlpineRuntime,
                    onRefreshAlpineSetup = { viewModel.refreshAlpineSetup(startPiIfReady = true) },
                    onInstallAlpinePackageProfile = viewModel::installAlpinePackageProfile,
                    onCreateAlpineTerminalLaunchSpec = viewModel::createAlpineTerminalLaunchSpec,
                    onStartAlpineChrome = viewModel::startAlpineChrome,
                    onShouldShowAlpineChromeKeyboard = viewModel::shouldShowAlpineChromeKeyboard,
                    onSetDefaultRuntime = viewModel::setDefaultRuntime,
                    onReplayOnboarding = viewModel::openOnboardingFromSettings,
                    onReplayFollowUpOnboarding = viewModel::openFollowUpOnboardingFromSettings,
                    onReplayAlpineSetupPreview = viewModel::openDeveloperAlpineSetupPreview,
                    onOpenWebsite = { openExternalUrl(context, ArixWebsiteUrl) },
                    onOpenPrivacyPolicy = { openExternalUrl(context, ArixPrivacyPolicyUrl) },
                    voiceSettings = uiState.voiceSettings,
                    voiceDownloadState = uiState.voiceDownloadState,
                    isVoskModelInstalled = viewModel.isVoiceModelInstalled("vosk"),
                    isKokoroModelInstalled = viewModel.isVoiceModelInstalled("kokoro"),
                    voiceModelStorageBytes = viewModel.voiceModelStorageBytes(),
                    onSetVoiceInputEnabled = viewModel::setVoiceInputEnabled,
                    onSetWakeWordEnabled = viewModel::setWakeWordEnabled,
                    onSetTtsEnabled = viewModel::setTtsEnabled,
                    onSetTtsSpeakerId = viewModel::setTtsSpeakerId,
                    onSetTtsSpeed = viewModel::setTtsSpeed,
                    onDownloadVoiceModel = viewModel::downloadVoiceModel,
                    onDeleteVoiceModels = viewModel::deleteVoiceModels,
                    onTestTtsVoice = viewModel::testTtsVoice,
                            onBack = viewModel::closeSettings,
                        )
                    }
        }
            }

            // Floating bottom navigation (Home / Tools / Terminal / Browser).
            if (uiState.currentScreen.isMainTab) {
                val imeVisibleNow = WindowInsets.ime.getBottom(LocalDensity.current) > 0
                ArixBottomNavBar(
                    currentScreen = uiState.currentScreen,
                    imeVisible = imeVisibleNow,
                    onSelect = viewModel::openMainTab,
                    modifier = Modifier.align(Alignment.BottomCenter),
                )
            }
            }
        }

        if (uiState.isStartupRouteResolved && !uiState.settings.privacyPolicyAccepted) {
            PrivacyPolicyConsentDialog(
                onOpenPolicy = { openPrivacyPolicy(context) },
                onAccept = viewModel::acceptPrivacyPolicy,
                onDecline = { context.findActivity()?.finishAffinity() },
            )
        }
        if (showAppDataExportWarning) {
            AlertDialog(
                onDismissRequest = { showAppDataExportWarning = false },
                containerColor = ArixSurface,
                titleContentColor = ArixOnSurface,
                textContentColor = ArixOnSurfaceVariant,
                title = {
                    Text(stringResource(R.string.settings_export_app_data_warning_title))
                },
                text = {
                    Text(stringResource(R.string.settings_export_app_data_warning_message))
                },
                confirmButton = {
                    TextButton(
                        onClick = {
                            showAppDataExportWarning = false
                            appDataExportLauncher.launch("arix-data.json")
                        },
                    ) {
                        Text(stringResource(R.string.common_export))
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showAppDataExportWarning = false }) {
                        Text(stringResource(R.string.common_cancel))
                    }
                },
            )
        }
    }
}

@Composable
private fun PrivacyPolicyConsentDialog(
    onOpenPolicy: () -> Unit,
    onAccept: () -> Unit,
    onDecline: () -> Unit,
) {
    AlertDialog(
        onDismissRequest = {},
        containerColor = ArixSurface,
        titleContentColor = ArixOnSurface,
        textContentColor = ArixOnSurfaceVariant,
        title = {
            Text(
                text = stringResource(R.string.app_privacy_policy_title),
                style = MaterialTheme.typography.titleLarge,
            )
        },
        text = {
            val policyText = stringResource(R.string.app_privacy_policy_title)
            val messagePrefix = stringResource(R.string.app_privacy_policy_message_prefix)
            val messageSuffix = stringResource(R.string.app_privacy_policy_message_suffix)
            val annotatedText = buildAnnotatedString {
                append(messagePrefix)
                pushStringAnnotation(
                    tag = PrivacyPolicyAnnotationTag,
                    annotation = ArixPrivacyPolicyUrl,
                )
                withStyle(SpanStyle(color = Color(0xFF3B82F6))) {
                    append(policyText)
                }
                pop()
                append(messageSuffix)
            }
            ClickableText(
                text = annotatedText,
                style = MaterialTheme.typography.bodyMedium.copy(color = ArixOnSurfaceVariant),
                onClick = { offset ->
                    annotatedText
                        .getStringAnnotations(PrivacyPolicyAnnotationTag, offset, offset)
                        .firstOrNull()
                        ?.let { onOpenPolicy() }
                },
            )
        },
        confirmButton = {
            Button(
                onClick = onAccept,
                colors = ButtonDefaults.buttonColors(
                    containerColor = ArixPrimary,
                    contentColor = Color.White,
                ),
            ) {
                Text(text = stringResource(R.string.common_agree))
            }
        },
        dismissButton = {
            TextButton(onClick = onDecline) {
                Text(
                    text = stringResource(R.string.common_decline),
                    color = ArixOnSurfaceVariant,
                )
            }
        },
    )
}

private fun saveAttachmentToDocument(
    context: android.content.Context,
    attachment: ChatAttachment,
    destinationUri: Uri,
): Boolean = runCatching {
    val resolver = context.contentResolver
    val sourceUri = Uri.parse(attachment.uri)
    val expectedSize = resolver.openAssetFileDescriptor(sourceUri, "r")?.use { descriptor ->
        descriptor.length.takeIf { it >= 0L }
    }
    var copiedBytes = 0L
    resolver.openInputStream(sourceUri)?.use { input ->
        resolver.openOutputStream(destinationUri, "w")?.use { output ->
            copiedBytes = input.copyTo(output)
            output.flush()
        }
    } != null && (expectedSize == null || expectedSize == copiedBytes)
}.getOrDefault(false)

private suspend fun handleAssistantLink(
    context: android.content.Context,
    rawLink: String,
    onSaveWorkspaceFile: (String) -> Unit,
) {
    parseAssistantLocalFileLink(rawLink)?.let { localPath ->
        onSaveWorkspaceFile(localPath)
        return
    }

    val normalizedLink = normalizeAssistantLink(rawLink)
    if (looksLikeWorkspaceFileLink(normalizedLink)) {
        onSaveWorkspaceFile(normalizedLink)
        return
    }

    val intent = Intent(Intent.ACTION_VIEW, Uri.parse(normalizedLink)).apply {
        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    }
    launchIntentSafely(context, intent) {
        Toast.makeText(context, context.getString(R.string.app_unable_to_open_link), Toast.LENGTH_SHORT).show()
    }
}

private fun normalizeAssistantLink(rawLink: String): String {
    val trimmed = rawLink.trim().removeSurrounding("<", ">")
    if (trimmed.isBlank()) return trimmed
    if (looksLikeWorkspaceFileLink(trimmed)) return trimmed
    if (trimmed.contains("://")) return trimmed
    if (trimmed.startsWith("www.", ignoreCase = true)) {
        return "https://$trimmed"
    }
    return if (Patterns.WEB_URL.matcher(trimmed).matches() && !trimmed.startsWith("/")) {
        "https://$trimmed"
    } else {
        trimmed
    }
}

private fun looksLikeWorkspaceFileLink(rawLink: String): Boolean {
    val trimmed = rawLink.trim()
    if (trimmed.isBlank()) return false
    if (trimmed.startsWith("file://", ignoreCase = true)) return true
    if (trimmed.startsWith("~/")) return true
    if (trimmed.startsWith("/")) return true
    return false
}

private fun resolveConversationModelKey(
    session: ChatSession?,
    draftSelectedModelKey: String,
    defaultChatModelKey: String,
    options: List<ProviderModelOption>,
): String {
    val preferredKey = session?.selectedModelKey
        ?.takeIf { key -> options.any { it.key == key } }
        ?: draftSelectedModelKey.takeIf { key -> options.any { it.key == key } }
        ?: defaultChatModelKey.takeIf { key -> options.any { it.key == key } }
    return preferredKey ?: options.resolveAutomaticModelKey(AutomaticModelPurpose.Chat)
}

private fun openPrivacyPolicy(
    context: android.content.Context,
) {
    openExternalUrl(context, ArixPrivacyPolicyUrl)
}

private fun openExternalUrl(
    context: android.content.Context,
    url: String,
) {
    val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    }
    launchIntentSafely(context, intent) {
        Toast.makeText(context, context.getString(R.string.app_unable_to_open_link), Toast.LENGTH_SHORT).show()
    }
}

private fun launchIntentSafely(
    context: android.content.Context,
    intent: Intent,
    fallback: (() -> Unit)? = null,
) {
    val launchResult = runCatching {
        context.startActivity(intent)
    }
    if (launchResult.isSuccess) {
        return
    }

    val failure = launchResult.exceptionOrNull()
    if (failure is ActivityNotFoundException || failure is SecurityException) {
        if (fallback != null) {
            fallback()
        } else {
            Toast.makeText(context, context.getString(R.string.app_unable_to_open_screen), Toast.LENGTH_SHORT).show()
        }
    } else if (fallback != null) {
        fallback()
    } else {
        Toast.makeText(context, context.getString(R.string.app_unable_to_open_screen), Toast.LENGTH_SHORT).show()
    }
}

@Composable
private fun ChatScreen(
    messages: List<ChatMessage>,
    inputValue: String,
    onInputChanged: (String) -> Unit,
    onSend: () -> Unit,
    onMenu: () -> Unit,
    onNewChat: () -> Unit,
    isSending: Boolean,
) {
    val listState = rememberLazyListState()

    LaunchedEffect(messages.size, isSending) {
        if (messages.isNotEmpty()) {
            listState.animateScrollToItem(messages.lastIndex)
        }
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        containerColor = ArixBackground,
        topBar = { ChatTopBar(onMenu, onNewChat) },
        bottomBar = { ComposerBar(inputValue, onInputChanged, onSend, messages.isNotEmpty(), isSending) },
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        listOf(ArixBackground, Color(0xFF0B0B0D), Color(0xFF070708))
                    )
                )
                .padding(innerPadding)
        ) {
            if (messages.isEmpty()) {
                EmptyChatState()
            } else {
                LazyColumn(
                    state = listState,
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 20.dp),
                    contentPadding = PaddingValues(top = 12.dp, bottom = 24.dp),
                    verticalArrangement = Arrangement.spacedBy(18.dp),
                ) {
                    items(messages, key = { it.id }) { message ->
                        MessageBubble(message = message)
                    }
                    if (isSending) {
                        item {
                            TypingIndicator()
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ChatTopBar(
    onMenu: () -> Unit,
    onNewChat: () -> Unit,
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .statusBarsPadding()
            .padding(horizontal = 16.dp, vertical = 10.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        SurfaceIconButton(Icons.Rounded.Menu, stringResource(R.string.common_menu), onMenu)
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            SurfaceIconButton(Icons.Rounded.Create, stringResource(R.string.common_new_chat), onNewChat)
            SurfaceIconButton(Icons.Rounded.MoreHoriz, stringResource(R.string.common_more), {})
        }
    }
}

@Composable
private fun EmptyChatState() {
    val actions = listOf(
        SuggestionAction(Icons.Rounded.Image, stringResource(R.string.chat_create_image), Color(0xFF22C55E)),
        SuggestionAction(Icons.Rounded.Lightbulb, stringResource(R.string.chat_brainstorm), Color(0xFFFACC15)),
        SuggestionAction(Icons.Rounded.Visibility, stringResource(R.string.chat_analyze_images), ArixPrimary),
        SuggestionAction(Icons.Rounded.AutoAwesome, stringResource(R.string.common_more), ArixPrimary),
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 22.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Text(
            text = stringResource(R.string.chat_welcome_help),
            style = MaterialTheme.typography.headlineMedium,
            color = ArixOnSurface,
        )
        Spacer(modifier = Modifier.height(28.dp))
        Column(
            modifier = Modifier.fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                actions.take(2).forEach { action ->
                    SuggestionChip(Modifier.weight(1f), action)
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                actions.drop(2).forEach { action ->
                    SuggestionChip(Modifier.weight(1f), action)
                }
            }
        }
    }
}

@Composable
private fun SuggestionChip(
    modifier: Modifier = Modifier,
    action: SuggestionAction,
) {
    Row(
        modifier = modifier
            .clip(RoundedCornerShape(22.dp))
            .background(Color(0xFF0C0D10))
            .padding(horizontal = 16.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        Icon(
            imageVector = action.icon,
            contentDescription = null,
            tint = action.tint,
        )
        Text(
            text = action.label,
            style = MaterialTheme.typography.labelLarge,
            color = ArixOnSurface,
        )
    }
}

@Composable
private fun MessageBubble(message: ChatMessage) {
    if (message.author == MessageAuthor.User) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.End,
        ) {
            Text(
                text = message.text,
                modifier = Modifier
                    .clip(RoundedCornerShape(22.dp))
                    .background(
                        Brush.horizontalGradient(listOf(Color(0xFF5B36D7), Color(0xFF6E48FF)))
                    )
                    .padding(horizontal = 18.dp, vertical = 14.dp),
                style = MaterialTheme.typography.bodyLarge,
                color = Color.White,
            )
        }
    } else {
        Column(
            modifier = Modifier.fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            Text(
                text = "Arix",
                style = MaterialTheme.typography.labelLarge,
                color = ArixOnSurfaceVariant,
            )
            Text(
                text = message.text,
                style = MaterialTheme.typography.bodyLarge,
                color = ArixOnSurface,
            )
            Spacer(modifier = Modifier.height(8.dp))
        }
    }
}

@Composable
private fun TypingIndicator() {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        CircularProgressIndicator(
            modifier = Modifier.size(18.dp),
            color = ArixPrimary,
            strokeWidth = 2.dp,
        )
        Text(
            text = stringResource(R.string.chat_arix_is_thinking),
            style = MaterialTheme.typography.bodyMedium,
            color = ArixOnSurfaceVariant,
        )
    }
}

@Composable
private fun ComposerBar(
    value: String,
    onValueChange: (String) -> Unit,
    onSend: () -> Unit,
    hasMessages: Boolean,
    isSending: Boolean,
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .imePadding()
            .navigationBarsPadding()
            .padding(horizontal = 14.dp, vertical = 12.dp)
            .clip(RoundedCornerShape(28.dp))
            .background(ArixSurfaceHigher)
            .padding(horizontal = 10.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        CircleAction(Icons.Rounded.Add, {})
        Spacer(modifier = Modifier.width(10.dp))
        Box(
            modifier = Modifier.weight(1f),
            contentAlignment = Alignment.CenterStart,
        ) {
            if (value.isEmpty()) {
                Text(
                    text = if (hasMessages) stringResource(R.string.chat_reply_to_arix) else stringResource(R.string.chat_ask_arix),
                    color = ArixOnSurfaceVariant,
                    style = MaterialTheme.typography.bodyLarge,
                )
            }
            BasicTextField(
                value = value,
                onValueChange = onValueChange,
                enabled = !isSending,
                modifier = Modifier.fillMaxWidth(),
                textStyle = MaterialTheme.typography.bodyLarge.copy(color = ArixOnSurface),
                cursorBrush = SolidColor(ArixOnSurface),
            )
        }
        Spacer(modifier = Modifier.width(8.dp))
        IconButton(onClick = {}, enabled = !isSending) {
            Icon(
                imageVector = Icons.Rounded.KeyboardVoice,
                contentDescription = stringResource(R.string.chat_voice),
                tint = ArixOnSurfaceVariant,
            )
        }
        CircleAction(
            icon = if (value.isBlank()) Icons.Rounded.AutoAwesome else Icons.Rounded.ArrowUpward,
            onClick = onSend,
            enabled = !isSending,
            containerColor = ArixPrimary,
            contentColor = Color.White,
        )
    }
}

@Composable
private fun AppDrawer(
    sessions: List<ChatSession>,
    selectedSessionId: String,
    onNewChat: () -> Unit,
    onSessionSelected: (String) -> Unit,
    onSettingsSelected: () -> Unit,
) {
    ModalDrawerSheet(
        modifier = Modifier.width(312.dp),
        drawerContainerColor = ArixSurface,
        drawerShape = RoundedCornerShape(topEnd = 28.dp, bottomEnd = 28.dp),
    ) {
        Column(
            modifier = Modifier
                .fillMaxHeight()
                .padding(horizontal = 14.dp, vertical = 16.dp)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .statusBarsPadding(),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                SearchBarStub(modifier = Modifier.weight(1f))
                SurfaceIconButton(Icons.Rounded.Create, stringResource(R.string.common_new_chat), onNewChat)
            }

            Spacer(modifier = Modifier.height(14.dp))
            DrawerPrimaryAction(Icons.Rounded.Create, stringResource(R.string.common_new_chat), onNewChat)
            DrawerPrimaryAction(Icons.Rounded.Image, stringResource(R.string.chat_images), {})
            DrawerPrimaryAction(Icons.Rounded.GridView, stringResource(R.string.chat_apps), {})
            DrawerPrimaryAction(Icons.Rounded.AutoAwesome, stringResource(R.string.chat_gpts), {})

            Spacer(modifier = Modifier.height(18.dp))
            Text(
                text = stringResource(R.string.chat_recent),
                style = MaterialTheme.typography.labelLarge,
                color = ArixOnSurfaceVariant,
                modifier = Modifier.padding(horizontal = 8.dp),
            )
            Spacer(modifier = Modifier.height(10.dp))
            if (sessions.isEmpty()) {
                Text(
                    text = stringResource(R.string.chat_no_conversations_yet),
                    style = MaterialTheme.typography.bodyMedium,
                    color = ArixOnSurfaceVariant,
                    modifier = Modifier
                        .weight(1f)
                        .padding(horizontal = 8.dp, vertical = 10.dp),
                )
            } else {
                Column(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(6.dp),
                ) {
                    sessions.forEach { session ->
                        SessionRow(
                            session = session,
                            selected = session.id == selectedSessionId,
                            onClick = { onSessionSelected(session.id) },
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(4.dp))
            Spacer(modifier = Modifier.height(12.dp))
            DrawerPrimaryAction(Icons.Rounded.Settings, stringResource(R.string.settings_title), onSettingsSelected)
            Spacer(modifier = Modifier.height(8.dp))
        }
    }
}

@Composable
private fun SearchBarStub(modifier: Modifier = Modifier) {
    Row(
        modifier = modifier
            .clip(RoundedCornerShape(22.dp))
            .background(ArixSurfaceHigher)
            .padding(horizontal = 14.dp, vertical = 11.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        Icon(
            imageVector = Icons.Rounded.Search,
            contentDescription = null,
            tint = ArixOnSurfaceVariant,
        )
        Text(
            text = stringResource(R.string.common_search),
            style = MaterialTheme.typography.bodyMedium,
            color = ArixOnSurfaceVariant,
        )
    }
}

@Composable
private fun DrawerPrimaryAction(
    icon: ImageVector,
    label: String,
    onClick: () -> Unit,
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 10.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Icon(imageVector = icon, contentDescription = null, tint = ArixOnSurface)
        Text(
            text = label,
            style = MaterialTheme.typography.bodyLarge,
            color = ArixOnSurface,
        )
    }
}

@Composable
private fun SessionRow(
    session: ChatSession,
    selected: Boolean,
    onClick: () -> Unit,
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .background(if (selected) ArixSurfaceHigher else Color.Transparent)
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 12.dp)
    ) {
        Text(
            text = session.title,
            style = MaterialTheme.typography.labelLarge,
            color = ArixOnSurface,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
        )
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = session.preview.ifBlank { stringResource(R.string.chat_empty_draft) },
            style = MaterialTheme.typography.bodySmall,
            color = ArixOnSurfaceVariant,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
        )
    }
}

// SettingsScreen is now in SettingsScreen.kt

@Composable
private fun SurfaceIconButton(
    icon: ImageVector,
    contentDescription: String,
    onClick: () -> Unit,
) {
    Box(
        modifier = Modifier
            .size(44.dp)
            .shadow(12.dp, CircleShape, ambientColor = ArixScrim, spotColor = ArixScrim)
            .clip(CircleShape)
            .background(ArixSurface.copy(alpha = 0.88f))
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Icon(
            imageVector = icon,
            contentDescription = contentDescription,
            tint = ArixOnSurface,
        )
    }
}

@Composable
private fun CircleAction(
    icon: ImageVector,
    onClick: () -> Unit,
    enabled: Boolean = true,
    containerColor: Color = ArixSurfaceHigh,
    contentColor: Color = ArixOnSurface,
) {
    Box(
        modifier = Modifier
            .size(38.dp)
            .clip(CircleShape)
            .background(if (enabled) containerColor else containerColor.copy(alpha = 0.45f))
            .clickable(enabled = enabled, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = if (enabled) contentColor else contentColor.copy(alpha = 0.45f),
        )
    }
}

@Preview(showBackground = true, backgroundColor = 0xFF000000)
@Composable
private fun ArixAppPreview() {
    ArixTheme {
        ChatScreen(
            messages = defaultPreviewMessages(),
            inputValue = "",
            onInputChanged = {},
            onSend = {},
            onMenu = {},
            onNewChat = {},
            isSending = false,
        )
    }
}

private fun defaultPreviewMessages(): List<ChatMessage> = listOf(
    ChatMessage("preview-user", MessageAuthor.User, "How should I wire this app to an LLM API?"),
    ChatMessage(
        "preview-agent",
        MessageAuthor.Agent,
        "Start with persistent settings, then call a configurable OpenAI-compatible chat endpoint from the composer.",
    ),
)
