package com.arix.app.voice

import android.content.Context
import com.k2fsa.sherpa.onnx.OfflineTts
import com.k2fsa.sherpa.onnx.OfflineTtsConfig
import com.k2fsa.sherpa.onnx.OfflineTtsKokoroModelConfig
import com.k2fsa.sherpa.onnx.OfflineTtsModelConfig
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.io.File
import java.util.concurrent.atomic.AtomicReference

/**
 * v2.4.9: offline text-to-speech with Kokoro (free, Apache-2.0 ONNX voice
 * model) via sherpa-onnx.
 *
 * The English int8-quantized model runs comfortably on mid-range arm64
 * hardware (e.g. Poco X2 / Snapdragon 730G) — generation runs on 2 CPU
 * threads and plays through AudioTrack in fully offline mode.
 *
 * Voice is MALE by default (am_michael); the full Kokoro speaker list is
 * exposed for the Settings → Voice picker.
 */
class ArixTtsEngine(
    private val context: Context,
    private val modelManager: ArixVoiceModelManager,
) {
    sealed interface State {
        data object Idle : State
        data object Loading : State
        data class Generating(val text: String) : State
        data class Speaking(val text: String) : State
        data class Error(val message: String) : State
    }

    private val _state = MutableStateFlow<State>(State.Idle)
    val state: StateFlow<State> = _state.asStateFlow()

    private val offlineTts = AtomicReference<OfflineTts?>(null)
    private val initMutex = Mutex()
    private val audioTrack = AtomicReference<android.media.AudioTrack?>(null)
    private var speakJob: Job? = null
    @Volatile
    private var currentSpeakerId: Int = DefaultSpeakerId
    @Volatile
    private var currentSpeed: Float = 1.0f

    /**
     * Loads the model if needed (idempotent) and speaks [text].
     * Set [interrupt] true (default) to stop any playback in progress.
     */
    fun speak(
        text: String,
        speakerId: Int = currentSpeakerId,
        speed: Float = currentSpeed,
        scope: CoroutineScope,
        interrupt: Boolean = true,
    ) {
        if (text.isBlank()) return
        currentSpeakerId = speakerId
        currentSpeed = speed.coerceIn(0.5f, 1.5f)
        if (interrupt) stopSpeaking()
        speakJob = scope.launch(Dispatchers.IO) {
            try {
                val tts = ensureEngine()
                _state.value = State.Generating(text)
                val generated = tts.generate(
                    text.take(MaxTextLength),
                    sid = speakerId,
                    speed = currentSpeed,
                )
                val samples = generated.samples
                if (samples == null || samples.isEmpty()) {
                    _state.value = State.Error("TTS produced no audio.")
                    return@launch
                }
                _state.value = State.Speaking(text)
                playSamples(samples, generated.sampleRate)
                _state.value = State.Idle
            } catch (throwable: Throwable) {
                if (throwable is kotlinx.coroutines.CancellationException) throw throwable
                _state.value = State.Error(
                    throwable.message ?: "Kokoro TTS failed. Is the offline model downloaded?"
                )
            }
        }
    }

    fun stopSpeaking() {
        speakJob?.cancel()
        speakJob = null
        runCatching { audioTrack.getAndSet(null)?.stop() }
        if (_state.value !is State.Error) _state.value = State.Idle
    }

    fun shutdown() {
        stopSpeaking()
        runCatching { offlineTts.getAndSet(null)?.release() }
    }

    private suspend fun ensureEngine(): OfflineTts = initMutex.withLock {
        offlineTts.get()?.let { return it }
        _state.value = State.Loading
        val modelDirectory = resolveModelDirectory()
        val config = OfflineTtsConfig(
            model = OfflineTtsModelConfig(
                kokoro = OfflineTtsKokoroModelConfig(
                    model = File(modelDirectory, "model.int8.onnx").absolutePath,
                    voices = File(modelDirectory, "voices.bin").absolutePath,
                    tokens = File(modelDirectory, "tokens.txt").absolutePath,
                    dataDir = File(modelDirectory, "espeak-ng-data").absolutePath,
                    lengthScale = 1.0f,
                ),
                numThreads = NumThreads,
                debug = false,
                provider = "cpu",
            ),
            ruleFsts = "",
            ruleFars = "",
            maxNumSentences = 1,
            silenceScale = 0.5f,
        )
        val engine = OfflineTts(assetManager = null, config = config)
        offlineTts.set(engine)
        return engine
    }

    private fun playSamples(samples: FloatArray, sampleRate: Int) {
        val track = android.media.AudioTrack(
            android.media.AudioManager.STREAM_MUSIC,
            sampleRate,
            android.media.AudioFormat.CHANNEL_OUT_MONO,
            android.media.AudioFormat.ENCODING_PCM_FLOAT,
            samples.size * 4,
            android.media.AudioTrack.MODE_STATIC,
        )
        audioTrack.set(track)
        track.write(samples, 0, samples.size, android.media.AudioTrack.WRITE_BLOCKING)
        track.play()
        // MODE_STATIC plays the whole buffer; wait for completion so the
        // state machine reports Speaking for the actual duration.
        val durationMs = (samples.size * 1000L / sampleRate).coerceAtMost(120_000L)
        Thread.sleep(durationMs)
        runCatching { track.stop() }
        runCatching { track.release() }
        if (audioTrack.get() === track) audioTrack.set(null)
    }

    private suspend fun resolveModelDirectory(): File {
        val persisted = runCatching { ArixVoiceRepository(context).current().kokoroModelPath }
            .getOrNull().orEmpty()
        val persistedDirectory = persisted.takeIf { it.isNotBlank() }?.let(::File)
        if (persistedDirectory?.isDirectory == true) return persistedDirectory
        val result = modelManager.ensureKokoroModel().getOrNull()
        if (result != null && result.isDirectory) return result
        throw IllegalStateException("The offline Kokoro voice model is not installed. Download it from Settings → Voice.")
    }

    /** Preloads the model so the first spoken reply has no warm-up lag. */
    fun preload(scope: CoroutineScope) {
        scope.launch(Dispatchers.IO) {
            runCatching { ensureEngine() }
        }
    }

    companion object {
        const val NumThreads = 2
        const val MaxTextLength = 1200

        /** Kokoro en-v0.19 voices.bin speaker map (53 speakers). */
        const val SpeakerAmMichael = 16
        const val SpeakerAmOnyx = 17
        const val SpeakerAmAdam = 11

        const val DefaultSpeakerId = SpeakerAmMichael

        val kokoroVoices: List<Pair<String, Int>> = listOf(
            "af_alloy" to 0, "af_aoede" to 1, "af_bella" to 2, "af_heart" to 3,
            "af_jessica" to 4, "af_kore" to 5, "af_nicole" to 6, "af_nova" to 7,
            "af_river" to 8, "af_sarah" to 9, "af_sky" to 10,
            "am_adam" to 11, "am_echo" to 12, "am_eric" to 13, "am_fenrir" to 14,
            "am_liam" to 15, "am_michael" to 16, "am_onyx" to 17, "am_puck" to 18,
            "am_santa" to 19,
            "bf_alice" to 20, "bf_emma" to 21, "bf_isabella" to 22, "bf_lily" to 23,
            "bm_daniel" to 24, "bm_fable" to 25, "bm_george" to 26, "bm_lewis" to 27,
            "ef_dora" to 28, "em_alex" to 29, "ff_siwis" to 30,
            "hf_alpha" to 31, "hf_beta" to 32, "hm_omega" to 33, "hm_psi" to 34,
            "if_sara" to 35, "im_nicola" to 36,
            "jf_alpha" to 37, "jf_gongitsune" to 38, "jf_nezumi" to 39, "jf_tebukuro" to 40,
            "jm_kumo" to 41,
            "pf_dora" to 42, "pm_alex" to 43, "pm_santa" to 44,
            "zf_xiaobei" to 45, "zf_xiaoni" to 46, "zf_xiaoxiao" to 47, "zf_xiaoyi" to 48,
            "zm_yunjian" to 49, "zm_yunxi" to 50, "zm_yunxia" to 51, "zm_yunyang" to 52,
        )

        /** Male voices offered in the picker (American + British male). */
        val maleVoices: List<Pair<String, Int>> = kokoroVoices.filter { (name, _) ->
            name.startsWith("am_") || name.startsWith("bm_") || name.startsWith("hm_") ||
                name.startsWith("pm_") || name.startsWith("em_") || name.startsWith("jm_")
        }
    }
}
