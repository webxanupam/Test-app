package com.arix.app.data

import com.arix.app.runtime.RuntimeRouter
import org.json.JSONArray
import org.json.JSONObject

data class ArixToolExecutionResult(
    val toolName: String,
    val argumentsJson: String,
    val rawOutput: String,
) {
    val visibleOutput: String = rawOutput
    val isError: Boolean = !ArixToolExecutor.inferToolOutputOk(rawOutput)
}

/**
 * Adapter for Arix-owned host capabilities only. Pi Coding Agent owns all
 * filesystem, shell, search, Skill, Extension, and image-reading mechanics.
 *
 * v2.4.9: no hardcoded device-control host tool — the agent uses the bash tool
 * to run `adb shell` commands directly (adb shell input tap, adb shell
 * uiautomator dump, etc.) through the bundled arix-adb helper. The only host
 * tool retained is agent_mode, which reads the screen as structured text
 * (uiautomator dump — no screenshots, nothing saved to storage).
 */
class ArixToolExecutor(
    private val runtimeRouter: RuntimeRouter,
    private val agentModeController: ArixAgentModeController? = null,
) {
    suspend fun execute(
        settings: AppSettings,
        workspaceDirectory: String,
        toolName: String,
        argumentsJson: String,
        selfManagementTool: ArixSelfManagementTool? = null,
        currentRuntimeId: LocalRuntimeId = settings.defaultRuntimeId ?: LocalRuntimeId.Alpine,
        onRuntimeChanged: suspend (LocalRuntimeId) -> Unit = {},
        onProgress: (suspend (String) -> Unit)? = null,
    ): ArixToolExecutionResult {
        val rawOutput = when (toolName) {
            "agent_mode" -> agentModeController?.execute(argumentsJson)
                ?: JSONObject()
                    .put("ok", false)
                    .put("errmsg", "Agent Mode is not available. Use bash with `adb shell` commands for device control.")
                    .toString()

            "arix_runtime_manage" -> executeRuntimeManage(
                settings = settings,
                currentRuntimeId = currentRuntimeId,
                workspaceDirectory = workspaceDirectory,
                argumentsJson = argumentsJson,
                onRuntimeChanged = onRuntimeChanged,
            )

            in SelfManagementToolNames -> selfManagementTool?.execute(
                toolName = toolName,
                argumentsJson = argumentsJson,
            ) ?: unavailableToolOutput(toolName)

            else -> JSONObject()
                .put("ok", false)
                .put("error", "Unknown Arix host tool '$toolName'.")
                .toString()
        }
        return ArixToolExecutionResult(toolName, argumentsJson, rawOutput)
    }

    private suspend fun executeRuntimeManage(
        settings: AppSettings,
        currentRuntimeId: LocalRuntimeId,
        workspaceDirectory: String,
        argumentsJson: String,
        onRuntimeChanged: suspend (LocalRuntimeId) -> Unit,
    ): String {
        val arguments = runCatching { JSONObject(argumentsJson) }.getOrNull()
            ?: return JSONObject().put("ok", false).put("errmsg", "Invalid JSON arguments.").toString()
        val action = arguments.optString("action").trim()
        if (action == "status") {
            val states = listOf(LocalRuntimeId.Alpine).associateWith { runtimeId ->
                runtimeRouter.runtimeById(runtimeId).inspectSetup()
            }
            return JSONObject().apply {
                put("ok", true)
                put("action", "status")
                put("runtime", currentRuntimeId.storageValue)
                put("cwd", workspaceDirectory)
                put("available", JSONObject().apply {
                    states.forEach { (runtimeId, state) -> put(runtimeId.storageValue, state.isReady) }
                })
            }.toString()
        }
        if (action != "set") {
            return JSONObject().put("ok", false).put("errmsg", "action must be 'status' or 'set'.").toString()
        }
        val requested = LocalRuntimeId.fromStorage(arguments.optString("runtime"))
            ?: return JSONObject().put("ok", false).put("errmsg", "runtime must be 'alpine'.").toString()
        if (requested != LocalRuntimeId.Alpine) {
            return JSONObject().put("ok", false).put("errmsg", "Alpine is the only local runtime.").toString()
        }
        val setup = runtimeRouter.runtimeById(requested).inspectSetup()
        val enabled = settings.enabledRuntimeIds.isEmpty() || requested in settings.enabledRuntimeIds
        if (!setup.isReady || !enabled) {
            return JSONObject().apply {
                put("ok", false)
                put("errmsg", "${requested.displayName} runtime is unavailable.")
                put("detail", setup.detail)
                put("runtime", currentRuntimeId.storageValue)
                put("cwd", workspaceDirectory)
            }.toString()
        }
        onRuntimeChanged(requested)
        return JSONObject().apply {
            put("ok", true)
            put("action", "set")
            put("runtime", requested.storageValue)
            put("cwd", workspaceDirectory)
        }.toString()
    }

    companion object {
        val hostToolNames: Set<String> = setOf(
            "agent_mode",
            *SelfManagementToolNames.toTypedArray(),
        )

        fun supports(toolName: String): Boolean = toolName in hostToolNames

        fun hostToolDefinitions(
            selfManagementTool: ArixSelfManagementTool? = null,
        ): JSONArray = JSONArray().apply {
            put(agentModeToolDefinition())
            selfManagementTool?.toolDefinitions()?.forEach { definition ->
                put(
                    flattenOpenAiToolDefinition(
                        definition = definition,
                        executionMode = if (
                            definition.optJSONObject("function")?.optString("name") == "arix_config_get"
                        ) "parallel" else "sequential",
                    ),
                )
            }
        }

        fun inferToolOutputOk(output: String): Boolean {
            val parsed = runCatching { JSONObject(output) }.getOrNull() ?: return true
            return parsed.optBoolean("ok", !parsed.optBoolean("err", false))
        }
    }
}

private val SelfManagementToolNames = setOf(
    "arix_config_get",
    "arix_config_set",
    "arix_skill_manage",
    "arix_runtime_manage",
    "arix_scheduled_task_manage",
    "arix_extension_manage",
    "arix_developer_manage",
)

private fun unavailableToolOutput(toolName: String): String = JSONObject()
    .put("ok", false)
    .put("errmsg", "Host dependency for '$toolName' is not available.")
    .toString()

private fun flattenOpenAiToolDefinition(
    definition: JSONObject,
    executionMode: String,
): JSONObject {
    val function = definition.optJSONObject("function") ?: JSONObject()
    return JSONObject().apply {
        put("name", function.optString("name"))
        put("description", function.optString("description"))
        put("parameters", relaxStrictOptionalParameters(function.optJSONObject("parameters")))
        put("execution_mode", executionMode)
    }
}

private fun relaxStrictOptionalParameters(parameters: JSONObject?): JSONObject {
    val relaxed = JSONObject((parameters ?: JSONObject().put("type", "object")).toString())
    val properties = relaxed.optJSONObject("properties") ?: return relaxed
    val required = relaxed.optJSONArray("required") ?: return relaxed
    relaxed.put("required", JSONArray().apply {
        for (index in 0 until required.length()) {
            val name = required.optString(index)
            if (name.isNotBlank() && !properties.optJSONObject(name).allowsNull()) put(name)
        }
    })
    return relaxed
}

private fun JSONObject?.allowsNull(): Boolean = when (val type = this?.opt("type")) {
    "null" -> true
    is JSONArray -> (0 until type.length()).any { type.optString(it) == "null" }
    else -> false
}

/**
 * v2.4.9: agent_mode provides text-based screen awareness via
 * `adb shell uiautomator dump` (no screenshots, no image storage). The
 * agent uses the bash tool for all device control (adb shell input tap,
 * adb shell input swipe, adb shell input text, etc.) — there is no
 * hardcoded device-control host tool.
 */
private fun agentModeToolDefinition(): JSONObject = JSONObject().apply {
    put("name", "agent_mode")
    put(
        "description",
        "Read the device screen as structured text (OCR-like awareness via uiautomator): every " +
            "visible element with text, description, id, bounds and clickable/scrollable flags. " +
            "NO screenshots are taken — nothing is stored as an image. Decide yourself what the " +
            "elements mean and interact with them. For device control (tapping, swiping, typing, " +
            "pressing keys) use the bash tool with `adb shell input tap X Y`, `adb shell input " +
            "swipe X1 Y1 X2 Y2`, `adb shell input text \"...\"`, `adb shell input keyevent " +
            "KEYCODE_BACK`, etc. First-time setup: pair the device's Wireless debugging service " +
            "(Android 11+) and run `arix-adb pair 127.0.0.1:PORT CODE` then `arix-adb connect " +
            "127.0.0.1:PORT` in the Alpine terminal tab.",
    )
    put("parameters", JSONObject().apply {
        put("type", "object")
        put("properties", JSONObject().apply {
            put("action", JSONObject().put("type", "string").put(
                "description", "One of: read_screen (default — reads the screen as text), status. Screenshots are intentionally unavailable."
            ))
        })
        put("required", JSONArray().put("action"))
        put("additionalProperties", false)
    })
    put("execution_mode", "sequential")
}
