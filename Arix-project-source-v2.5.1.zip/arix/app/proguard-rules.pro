# Project-specific ProGuard rules can be added here when needed.

# com.rosan.app_process intentionally references hidden Android framework
# classes that are present on-device but unavailable to R8's android.jar.
-dontwarn android.app.ActivityThread
-dontwarn android.app.ContextImpl
-dontwarn android.app.LoadedApk

# Flexmark's BitFieldSet reflects enum constant names at runtime.
# Keep its enum members stable in release builds.
-keepclassmembers enum com.vladsch.flexmark.** {
    *;
}

# Size optimization: flatten obfuscated package hierarchy and let R8 widen
# access for better inlining. No reflection-based features are affected.
-repackageclasses ''
-allowaccessmodification

# v2.4.7 additional size optimizations (no features removed):
-optimizationpasses 5
-assumenosideeffects class kotlin.Metadata { *; }
-assumenosideeffects class android.util.Log {
    public static *** v(...);
    public static *** d(...);
    public static *** i(...);
    public static *** w(...);
    public static *** e(...);
}
-assumenosideeffects class kotlin.coroutines.jvm.internal.DebugMetadataKt { *; }

# v2.4.7: keep ADB controller entry points so reflection-based action
# dispatch keeps working after R8 obfuscation.
-keep class com.arix.app.data.ArixSystemControlTool { *; }
-keep class com.arix.app.data.ArixSystemControlTool$Companion { *; }

# v2.4.9: offline voice engines use JNI native registration — their class and
# member names must survive R8 or the native side cannot bind them.
-keep class org.vosk.** { *; }
-keep class com.k2fsa.sherpa.onnx.** { *; }
-dontwarn org.vosk.**
-dontwarn com.k2fsa.sherpa.onnx.**

# commons-compress (model archive extraction) uses reflection for optional
# codecs; only tar/bzip2 are used and present.
-dontwarn org.apache.commons.compress.**
