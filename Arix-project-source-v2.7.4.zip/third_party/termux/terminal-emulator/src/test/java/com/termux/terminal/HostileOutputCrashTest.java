package com.termux.terminal;

/**
 * v2.4.4 regression tests for the "type in terminal → app crash" bug.
 *
 * The emulator's buffer layer (TerminalRow / TerminalBuffer) used to throw
 * IllegalArgumentException on out-of-range writes, wide characters in the
 * last column, and bad CSI/DECSTBM parameters. Those throws surfaced on the
 * app's MAIN thread from TerminalSession.MainThreadHandler while processing
 * pty output (the shell echoing typed/pasted input), killing the process.
 *
 * These tests feed the exact hostile sequences through the public append()
 * path and assert that nothing throws and the terminal keeps working.
 */
public class HostileOutputCrashTest extends TerminalTestCase {

    /** Wide (2-cell) characters written when the cursor is at the last column. */
    public void testWideCharAtLastColumnDoesNotThrow() {
        withTerminalSized(5, 3);
        // Place cursor at the last column and emit a CJK wide char.
        enterString("\033[1;5H");
        enterString("語");
        // And again with the cursor one past the last column (corrupt state).
        enterString("\033[1;6H");
        enterString("語");
        // Autowrap disabled variant — emulator ignores the wide char.
        enterString("\033[?7l");
        enterString("語語語");
        enterString("\033[?7h");
        // The terminal must still be usable afterwards.
        enterString("ok");
    }

    /** Malformed CSI copy/erase/scroll-region parameters that used to throw. */
    public void testHostileCsiParametersDoNotThrow() {
        withTerminalSized(10, 4);
        // DECSTBM with inverted margins (top > bottom).
        enterString("\033[3;1r");
        // ECH with huge count.
        enterString("\033[999999999X");
        // Scroll up/down with huge counts.
        enterString("\033[999999S");
        enterString("\033[999999T");
        // Terminal still functional after the abuse.
        enterString("still alive");
    }

    /** Combining-character floods and truncated UTF-8 sequences. */
    public void testCombiningAndBrokenUtf8DoesNotThrow() {
        withTerminalSized(8, 3);
        // Combining char written at column 0 of a row.
        enterString("\u0308\u0308\u0308");
        // A flood of combining chars (row bookkeeping stress).
        StringBuilder combiningFlood = new StringBuilder();
        for (int i = 0; i < 500; i++) combiningFlood.append("\u0301");
        enterString(combiningFlood.toString());
        // Broken/truncated UTF-8 bytes fed directly through append().
        mTerminal.append(new byte[]{(byte) 0xF0, (byte) 0x9F, (byte) 0x98}, 3); // no final byte
        mTerminal.append(new byte[]{(byte) 0xC2}, 1); // orphaned 2-byte lead
        mTerminal.append(new byte[]{(byte) 0x80, (byte) 0x80, (byte) 0x80}, 3); // stray continuations
        // Still alive.
        enterString("done");
    }

    /** Direct TerminalRow bounds abuse — used to throw IllegalArgumentException. */
    public void testTerminalRowBoundsAreIgnoredNotThrown() {
        TerminalRow row = new TerminalRow(10, 0);
        // Out-of-range columns: previously `throw new IllegalArgumentException`.
        row.setChar(-1, 'x', 0);
        row.setChar(10, 'x', 0);
        row.setChar(9999, 'x', 0);
        // Wide char exactly at the last column: previously threw
        // "Cannot put wide character in last column". Now recovered with a
        // space (the row may keep one trailing padding char — the point is
        // that nothing throws and the row stays walkable).
        row.setChar(9, 0x8A9E /* CJK wide */, 0);
        assertTrue(row.getSpaceUsed() >= 10);
        // findStartOfColumn with a corrupt/unknown column returns a sane index.
        int idx = row.findStartOfColumn(3);
        assertTrue(idx >= 0 && idx <= row.getSpaceUsed());
    }

    /** TerminalBuffer.setChar / blockSet / blockCopy / scroll bounds are ignored. */
    public void testTerminalBufferBoundsAreIgnoredNotThrown() {
        withTerminalSized(6, 3);
        TerminalBuffer buffer = mTerminal.getScreen();
        buffer.setChar(-1, 0, 'x', 0);
        buffer.setChar(0, -1, 'x', 0);
        buffer.setChar(999, 999, 'x', 0);
        buffer.blockSet(-5, -5, 100, 100, 32, 0);
        buffer.blockCopy(0, 0, 100, 100, -50, -50);
        buffer.scrollDownOneLine(-1, 999, 0);
        buffer.externalToInternalRow(-99999);
        buffer.externalToInternalRow(99999);
        // Still functional.
        enterString("ok");
    }
}
