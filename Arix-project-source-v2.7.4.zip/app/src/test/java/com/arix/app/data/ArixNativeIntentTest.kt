package com.arix.app.data

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * Verifies the client-side intent router that turns anime / QR / system
 * commands into instant native tool turns (and leaves normal conversation to
 * the LLM). v2.5.2: movie commands are intentionally NOT matched anymore —
 * the movie_explorer chat command was removed (watchonlinemovies scraper);
 * movie requests flow to the LLM while the Tools tab movie tool is untouched.
 */
class ArixNativeIntentTest {

    @Test
    fun qrCommandsAreDetected() {
        val qr = ArixNativeIntent.match("create a qr code for https://example.com")
        assertTrue(qr is ArixNativeIntent.QrCode)
        assertEquals("https://example.com", (qr as ArixNativeIntent.QrCode).data)

        val wifi = ArixNativeIntent.match("QR code: WIFI:T:WPA;S:Net;P:pass;;")
        assertTrue(wifi is ArixNativeIntent.QrCode)
        assertEquals("WIFI:T:WPA;S:Net;P:pass;;", (wifi as ArixNativeIntent.QrCode).data)

        val plain = ArixNativeIntent.match("generate qr of hello world")
        assertTrue(plain is ArixNativeIntent.QrCode)
        assertEquals("hello world", (plain as ArixNativeIntent.QrCode).data)
    }

    @Test
    fun qrWithoutPayloadIsIgnored() {
        assertNull(ArixNativeIntent.match("what is a qr code"))
        assertNull(ArixNativeIntent.match("qr"))
    }

    @Test
    fun movieCommandsGoToTheModel() {
        // v2.5.2: movie_explorer was removed — every movie phrasing now
        // returns null and is handled as a normal conversation turn.
        assertNull(ArixNativeIntent.match("show latest movies"))
        assertNull(ArixNativeIntent.match("new movies please"))
        assertNull(ArixNativeIntent.match("more movies"))
        assertNull(ArixNativeIntent.match("movies page 3"))
        assertNull(ArixNativeIntent.match("search movie dunki"))
        assertNull(ArixNativeIntent.match("play movie iron man"))
    }

    @Test
    fun systemCommandsAreDetected() {
        assertTrue(ArixNativeIntent.match("open youtube") is ArixNativeIntent.OpenApp)
        assertEquals("youtube", (ArixNativeIntent.match("open youtube") as ArixNativeIntent.OpenApp).target)
        assertTrue(ArixNativeIntent.match("please launch whatsapp") is ArixNativeIntent.OpenApp)
        assertTrue(ArixNativeIntent.match("open wifi settings") is ArixNativeIntent.OpenSettings)
        assertEquals("wifi", (ArixNativeIntent.match("open wifi settings") as ArixNativeIntent.OpenSettings).page)
        assertTrue(ArixNativeIntent.match("open bluetooth settings") is ArixNativeIntent.OpenSettings)
        assertTrue(ArixNativeIntent.match("open https://example.com") is ArixNativeIntent.OpenUrl)
        assertTrue(ArixNativeIntent.match("turn on bluetooth") is ArixNativeIntent.OpenSettings)
    }

    @Test
    fun normalConversationGoesToTheModel() {
        assertNull(ArixNativeIntent.match("what is your favorite movie?"))
        assertNull(ArixNativeIntent.match("write a review of the movie inception"))
        assertNull(ArixNativeIntent.match("hello"))
        assertNull(ArixNativeIntent.match("https://example.com"))
        assertNull(ArixNativeIntent.match("thanks"))
        assertNull(ArixNativeIntent.match("what apps do I have installed"))
        assertNull(ArixNativeIntent.match("how do I open the settings"))
    }

    @Test
    fun animeCommandsAreDetected() {
        assertTrue(ArixNativeIntent.match("show latest anime") is ArixNativeIntent.AnimeList)
        assertTrue(ArixNativeIntent.match("more anime") is ArixNativeIntent.AnimeList)
        assertTrue(ArixNativeIntent.match("anime page 2") is ArixNativeIntent.AnimeList)
        val search = ArixNativeIntent.match("search anime one piece")
        assertTrue(search is ArixNativeIntent.AnimeSearch)
        assertEquals("one piece", (search as ArixNativeIntent.AnimeSearch).query)
        val watch = ArixNativeIntent.match("watch anime naruto")
        assertTrue(watch is ArixNativeIntent.AnimeWatch)
        assertEquals("naruto", (watch as ArixNativeIntent.AnimeWatch).query)
    }
}
