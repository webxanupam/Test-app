package com.arix.app.data

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

class V246SourceGuardTest {
    private fun moduleDir(): File {
        var dir: File? = File(System.getProperty("user.dir"))
        repeat(6) {
            val direct = File(dir, "src/main/java/com/arix/app")
            if (direct.isDirectory) return dir!!
            dir = dir?.parentFile
        }
        throw IllegalStateException("app module directory not found")
    }

    private fun appSource(relative: String): String =
        File(moduleDir(), "src/main/java/com/arix/app/$relative").readText()

    @Test
    fun visualDisplayRendersExactlyOnePreviewPanel() {
        val src = appSource("ui/ConversationUi.kt")
        assertTrue(src.contains("agentModePreviewUnfiltered && !chromePreviewVisible"))
    }

    @Test
    fun chatPreviewWebViewIsTransparentOverTheDarkBackdrop() {
        val src = appSource("ui/ConversationUi.kt")
        assertTrue(src.contains("transparentBackground = true"))
    }

    @Test
    fun chromiumBootsOnAboutBlank() {
        // v2.4.8: reverted to Aether's about:blank start page.
        val src = appSource("data/AlpineChromeController.kt")
        assertTrue(src.contains("about:blank"))
    }

    @Test
    fun vncViewerSurfacesConnectionErrorsViaWatchdog() {
        val src = appSource("ui/AlpineChromeScreen.kt")
        assertTrue(src.contains("watchVncConnection"))
        assertTrue(src.contains("arix-vnc-status-visible"))
    }

    @Test
    fun noHardcodedSystemControlTool() {
        // v2.4.8: ArixSystemControlTool was removed entirely.
        // The agent uses bash with `adb shell` commands for device control.
        val executor = appSource("data/ArixToolExecutor.kt")
        assertFalse(executor.contains("system_control"))
        assertFalse(executor.contains("ArixSystemControlTool"))
        assertTrue(executor.contains("agent_mode"))
    }

    @Test
    fun agentModeControllerUsesAdbForScreenRead() {
        // v2.4.9: screenshots were replaced by text-based screen awareness
        // (uiautomator dump). No image capture, no storage writes.
        val src = appSource("data/ArixAgentModeController.kt")
        assertTrue(src.contains("uiautomator dump"))
        assertTrue(src.contains("arix-adb"))
        assertFalse(src.contains("screencap -p"))
    }

    @Test
    fun toolHeaderIsCenteredWithoutSubtitle() {
        val src = appSource("ui/ArixToolsUi.kt")
        assertTrue(src.contains("align(Alignment.CenterStart)"))
        assertTrue(src.contains("align(Alignment.Center)"))
    }

    @Test
    fun toolScreensHaveClearHeaderToContentSpacing() {
        val src = appSource("ui/ArixToolsUi.kt")
        assertTrue(src.contains("Spacer(Modifier.height(14.dp))"))
    }
}
