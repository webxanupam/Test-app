package com.arix.app

import android.os.Build
import androidx.test.core.app.ApplicationProvider
import java.io.File
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import org.robolectric.annotation.LooperMode

/**
 * v2.7.1 regression tests for the crash-on-launch bug:
 *
 *     E AndroidRuntime: lv0: Alpine host runtime is incomplete.
 *
 * Root causes fixed in v2.7.1:
 *  1. The v2.7.0 Get Started flow dropped the old onboarding's AlpineSetup
 *     step, so the runtime was never installed on fresh installs.
 *  2. Nothing repaired a partially-installed runtime (rootfs present, host
 *     proot/loader/libtalloc missing) on later launches.
 *  3. Concurrent initialize() calls raced through the shared staging
 *     directory, each deleting the other's files mid-extraction — the exact
 *     mechanism that produces the "incomplete" on-disk state.
 *
 * Note on the JVM: Robolectric has no /system/bin/linker64, so the final
 * inspectSetup after a successful install reports Failed("Android dynamic
 * linker is unavailable") — an environment artifact that cannot occur on a
 * real device. These tests therefore pin the FILE-LEVEL outcome of the
 * self-heal (all host runtime binaries extracted, rootfs complete) and the
 * serialized install behavior.
 */
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [30], application = ArixApplication::class)
@LooperMode(LooperMode.Mode.PAUSED)
class AlpineSelfHealTest {

    private lateinit var app: ArixApplication

    @Before
    fun setUp() {
        app = ApplicationProvider.getApplicationContext()
        // The Alpine runtime requires an arm64-v8a device; Robolectric's
        // default simulated ABIs do not include it, so force it the way a
        // real arm64 phone reports.
        Build::class.java.getDeclaredField("SUPPORTED_ABIS").apply {
            isAccessible = true
        }.set(null, arrayOf("arm64-v8a", "armeabi-v7a", "armeabi"))
    }

    private fun runtimeRoot(): File = File(app.filesDir, "runtimes/alpine")

    private fun assertHostRuntimeFilesInstalled() {
        val runtimeRoot = runtimeRoot()
        assertTrue("bin/proot missing", File(runtimeRoot, "bin/proot").isFile)
        assertTrue("libexec/proot/loader missing", File(runtimeRoot, "libexec/proot/loader").isFile)
        assertTrue("lib/libtalloc.so.2 missing", File(runtimeRoot, "lib/libtalloc.so.2").isFile)
        val rootfs = File(runtimeRoot, "rootfs")
        assertTrue("rootfs/bin/sh missing", File(rootfs, "bin/sh").existsNoFollowCompat())
        assertTrue("rootfs/etc/alpine-release missing", File(rootfs, "etc/alpine-release").isFile)
    }

    private fun java.io.File.existsNoFollowCompat(): Boolean =
        java.nio.file.Files.exists(toPath(), java.nio.file.LinkOption.NOFOLLOW_LINKS)

    /**
     * The exact on-disk state behind the user's crash: rootfs present, host
     * runtime binaries (bin/proot, libexec/proot/loader, lib/libtalloc.so.2)
     * missing. initialize() must reinstall everything.
     */
    @Test
    fun initializeRepairsIncompleteHostRuntime() = runBlocking {
        val runtimeRoot = runtimeRoot()
        runtimeRoot.deleteRecursively()
        val rootfs = File(runtimeRoot, "rootfs")
        rootfs.mkdirs()
        File(rootfs, "bin").mkdirs()
        File(rootfs, "bin/sh").writeText("#!/bin/sh\n")
        File(rootfs, "etc").mkdirs()
        File(rootfs, "etc/alpine-release").writeText("3.23.4\n")
        File(runtimeRoot, "workspace").mkdirs()

        val state = app.runtime.alpineRuntime.initialize()

        assertHostRuntimeFilesInstalled()
        assertTrue(
            "expected Ready or the JVM-only linker artifact, was ${state.issue}: ${state.detail}",
            state.isReady || state.detail.contains("linker"),
        )
    }

    /**
     * Fresh install: nothing on disk. initialize() must extract the full
     * runtime (the step the v2.7.0 onboarding dropped).
     */
    @Test
    fun initializeInstallsFreshRuntime() = runBlocking {
        runtimeRoot().deleteRecursively()

        app.runtime.alpineRuntime.initialize()

        assertHostRuntimeFilesInstalled()
    }

    /**
     * Calling initialize() again must never leave the runtime broken: on a
     * real device a Ready runtime is a no-op (initializeLocked returns the
     * state unchanged), and even a persistently-Failed state (impossible on
     * real hardware — only the JVM's missing /system/bin/linker64) is
     * re-installed into a COMPLETE tree, never corrupted. Pin the file-level
     * invariant both ways.
     */
    @Test
    fun repeatedInitializeKeepsRuntimeComplete() = runBlocking {
        runtimeRoot().deleteRecursively()
        app.runtime.alpineRuntime.initialize()
        assertHostRuntimeFilesInstalled()

        Thread.sleep(10)
        app.runtime.alpineRuntime.initialize()

        assertHostRuntimeFilesInstalled()
    }

    /**
     * v2.7.1 concurrency fix: two initialize() calls racing (startup
     * self-heal + a UI-triggered setup) must not corrupt each other through
     * the shared staging directory. Both must observe a complete runtime.
     */
    @Test
    fun concurrentInitializesDoNotCorruptTheRuntime() = runBlocking {
        runtimeRoot().deleteRecursively()

        val results: List<com.arix.app.runtime.LocalRuntimeSetupState> =
            kotlinx.coroutines.coroutineScope {
                val jobs = (1..3).map {
                    async(Dispatchers.IO) {
                        app.runtime.alpineRuntime.initialize()
                    }
                }
                jobs.map { deferred -> deferred.await() }
            }
        assertHostRuntimeFilesInstalled()
        // Every caller sees a terminal state; at least one installed.
        assertTrue(results.all { state ->
            state.isReady || state.detail.contains("linker") || state.issue.name == "UnsupportedAbi"
        })
    }
}
