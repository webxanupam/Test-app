package com.arix.app.ui

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

/**
 * Regression guard for the v2.4.5 StackOverflowError fix.
 *
 * Root cause (P0, confirmed): `ArixTerminalViewClient` declared constructor
 * properties named `readControlKey` / `readAltKey` (function types) while also
 * overriding the identically-named `TerminalViewClient` methods:
 *
 *     override fun readControlKey(): Boolean = readControlKey()
 *
 * Kotlin resolves the right-hand `readControlKey()` to the member function
 * (member functions win over a same-named property's invoke convention), so
 * the override called itself infinitely. `TerminalView.onKeyDown()` /
 * `inputCodePoint()` poll `mClient.readControlKey()/readAltKey()` on every
 * keypress, so every typed character crashed the main thread with
 * `java.lang.StackOverflowError`.
 *
 * `ArixTerminalViewClient` is a private class inside AlpineTerminalScreen.kt,
 * so this guard scans the source file — both for the exact historical pattern
 * and for any future name collision between an `override fun` and a
 * `private val` of function type in the same class.
 */
class TerminalClientRecursionGuardTest {

    private fun sourceFile(): File {
        // Gradle unit tests run with the module directory as working dir.
        val moduleDir = File(System.getProperty("user.dir"))
        val direct = File(moduleDir, "src/main/java/com/arix/app/ui/AlpineTerminalScreen.kt")
        if (direct.isFile) return direct
        // Fallback: walk up from the working dir until the file is found.
        var dir: File? = moduleDir
        repeat(6) {
            val candidate = File(dir, "app/src/main/java/com/arix/app/ui/AlpineTerminalScreen.kt")
            if (candidate.isFile) return candidate
            dir = dir?.parentFile
        }
        throw IllegalStateException("AlpineTerminalScreen.kt not found from ${moduleDir.absolutePath}")
    }

    /** Strips line and block comments so documentation text (which may quote
     *  the historical bug pattern) cannot trigger the guards. */
    private fun codeOnly(src: String): String {
        val withoutBlockComments = src.replace(Regex("/\\*[\\s\\S]*?\\*/"), "")
        return withoutBlockComments.lineSequence()
            .map { line -> line.substringBefore("//") }
            .joinToString("\n")
    }

    @Test
    fun viewClientKeyReadOverridesDoNotSelfRecurse() {
        val src = codeOnly(sourceFile().readText())

        assertFalse(
            "readControlKey() override must not call itself (StackOverflowError regression)",
            src.contains("override fun readControlKey(): Boolean = readControlKey()"),
        )
        assertFalse(
            "readAltKey() override must not call itself (StackOverflowError regression)",
            src.contains("override fun readAltKey(): Boolean = readAltKey()"),
        )
        // The fixed wiring: overrides delegate to the renamed state callbacks.
        assertTrue(src.contains("override fun readControlKey(): Boolean = readControlKeyState()"))
        assertTrue(src.contains("override fun readAltKey(): Boolean = readAltKeyState()"))
        // Constructor properties were renamed so the collision cannot come back.
        assertFalse(src.contains("private val readControlKey:"))
        assertFalse(src.contains("private val readAltKey:"))
    }

    @Test
    fun constructorCallSiteUsesRenamedStateCallbacks() {
        val src = codeOnly(sourceFile().readText())
        assertTrue(src.contains("readControlKeyState = { controlDown }"))
        assertTrue(src.contains("readAltKeyState = { altDown }"))
        assertFalse(src.contains("readControlKey = {"))
        assertFalse(src.contains("readAltKey = {"))
    }

    @Test
    fun noOverrideInAlpineTerminalScreenInvokesSameNamedPropertyDirectly() {
        val src = codeOnly(sourceFile().readText())
        // Generic guard: `override fun name(...) = name(` where both sides
        // match is the self-call shape that produced the crash.
        val selfCall = Regex("override\\s+fun\\s+(\\w+)\\s*\\([^)]*\\)[^=]*=\\s*\\1\\s*\\(")
        val matches = selfCall.findAll(src).map { it.groupValues[1] }.toList()
        assertTrue(
            "Self-recursive overrides found: $matches",
            matches.isEmpty(),
        )
    }
}
