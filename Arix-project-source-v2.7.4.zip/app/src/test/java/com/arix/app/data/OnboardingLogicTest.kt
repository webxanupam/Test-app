package com.arix.app.data

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class OnboardingLogicTest {
    @Test
    fun freshInstallLaunchesOnboarding() {
        val settings = AppSettings()

        assertTrue(settings.shouldLaunchOnboarding())
        assertFalse(settings.isOnboardingComplete())
    }

    @Test
    fun seenButIncompleteSetupDoesNotRelaunchOnboarding() {
        val settings = AppSettings(
            onboardingSeenVersion = CurrentOnboardingVersion,
            onboardingCompletedVersion = 0,
        )

        assertFalse(settings.shouldLaunchOnboarding())
    }

    @Test
    fun providerValidationUsesPiAuthenticationCapabilities() {
        assertFalse(
            AppSettings(
                piProviderId = "openai",
                providerAuthMethod = ProviderAuthMethod.ApiKey,
                apiKey = "",
                baseUrl = "https://api.openai.com/v1",
                modelId = "gpt-5.4",
            ).isProviderSetupValid()
        )
        assertFalse(
            AppSettings(
                piProviderId = "openai-codex",
                providerAuthMethod = ProviderAuthMethod.ApiKey,
                apiKey = "",
                baseUrl = "",
                modelId = "gpt-5.3-codex-spark",
            ).isProviderSetupValid()
        )
        assertTrue(
            AppSettings(
                piProviderId = "google-vertex",
                providerAuthMethod = ProviderAuthMethod.Ambient,
                apiKey = "",
                baseUrl = "",
                modelId = "",
            ).isProviderSetupValid()
        )
        assertTrue(
            AppSettings(
                piProviderId = "openai-compatible",
                apiKey = "",
                baseUrl = "http://10.0.2.2:11434/v1",
                modelId = "local-model",
            ).isProviderSetupValid()
        )
    }

    @Test
    fun freshInstallStartsWithNoEnabledRuntime() {
        val settings = AppSettings()

        assertTrue(settings.enabledRuntimeIds.isEmpty())
        assertTrue(settings.defaultRuntimeId == null)
    }

    @Test
    fun enablingSecondRuntimeDoesNotOverrideExistingDefaultWhenRequested() {
        val alpineDefault = AppSettings(
            enabledRuntimeIds = setOf(LocalRuntimeId.Alpine),
            defaultRuntimeId = LocalRuntimeId.Alpine,
            alpineSetupCompleted = true,
        )

        val withTermux = alpineDefault.enableRuntimeForTest(
            runtimeId = LocalRuntimeId.Termux,
            makeDefault = false,
        )

        assertTrue(LocalRuntimeId.Alpine in withTermux.enabledRuntimeIds)
        assertTrue(LocalRuntimeId.Termux in withTermux.enabledRuntimeIds)
        assertTrue(withTermux.defaultRuntimeId == LocalRuntimeId.Alpine)
    }
}

private fun AppSettings.enableRuntimeForTest(
    runtimeId: LocalRuntimeId,
    makeDefault: Boolean,
): AppSettings {
    val enabled = enabledRuntimeIds + runtimeId
    return copy(
        alpineSetupCompleted = alpineSetupCompleted || runtimeId == LocalRuntimeId.Alpine,
        enabledRuntimeIds = enabled,
        defaultRuntimeId = if (makeDefault) runtimeId else defaultRuntimeId,
    )
}