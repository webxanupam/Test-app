package com.arix.app.data

import java.util.concurrent.TimeUnit
import okhttp3.mockwebserver.MockResponse
import okhttp3.mockwebserver.MockWebServer
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * Regression test for the v2.4.5 server-probe timeout fix.
 *
 * `isServerReachable(streamUrl, timeoutMillis = 4_000)` documented that a
 * probe "answers within [timeoutMillis]", but the parameter was never
 * applied: the probe ran on `ArixMediaApi.embedClient` (7s connect + 10s
 * read), so a dead CDN stalled the episode card for up to ~17s per wave
 * instead of the designed 4s. The fix applies OkHttp's per-call timeout.
 *
 * MockWebServer verifies both directions:
 *  - a server that stalls before headers is marked unreachable within ~the
 *    requested budget (not the 17s worst case);
 *  - a healthy server is still reported reachable (selection behavior
 *    preserved for live hosts).
 */
class ArixAnimeSiteServerProbeTest {

    @Test
    fun probeTimesOutWithinRequestedBudget() {
        val server = MockWebServer()
        // Headers delayed far beyond the probe budget: the old code would
        // have blocked here for ~10s (embedClient read timeout). Kept short
        // enough that MockWebServer.shutdown() does not stall the suite.
        server.enqueue(
            MockResponse()
                .setResponseCode(200)
                .setHeadersDelay(1_500, TimeUnit.MILLISECONDS),
        )
        server.start()
        try {
            val url = server.url("/stream/master.m3u8").toString()
            val startedAt = System.currentTimeMillis()
            val reachable = ArixAnimeSiteClient.isServerReachable(url, timeoutMillis = 500)
            val elapsed = System.currentTimeMillis() - startedAt

            assertFalse("A server slower than the probe budget must be unreachable", reachable)
            assertTrue(
                "Probe must honor timeoutMillis (elapsed ${elapsed}ms, budget 500ms + slack)",
                elapsed < 4_000,
            )
        } finally {
            // The delayed response keeps the dispatcher busy briefly; a
            // shutdown hiccup must never fail the test itself.
            runCatching { server.shutdown() }
        }
    }

    @Test
    fun healthyServerIsStillReachable() {
        val server = MockWebServer()
        server.enqueue(
            MockResponse()
                .setResponseCode(206)
                .setBody("0123456789"),
        )
        server.start()
        try {
            val url = server.url("/stream/episode.mp4").toString()
            val reachable = ArixAnimeSiteClient.isServerReachable(url, timeoutMillis = 4_000)
            assertTrue("A responsive server must stay reachable (ordering preserved)", reachable)
        } finally {
            server.shutdown()
        }
    }

    @Test
    fun embedPageUrlsRemainReachableCandidatesWithoutARequest() {
        // HTML embed pages short-circuit as reachable (the stream only exists
        // after JS runs) — behavior that must not change with the timeout fix.
        val reachable = ArixAnimeSiteClient.isServerReachable(
            "https://example.com/embed/abc123",
            timeoutMillis = 500,
        )
        assertTrue(reachable)
    }
}
