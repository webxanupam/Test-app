package com.arix.app.data.pi

import com.arix.app.data.AppSettings
import com.arix.app.data.LocalRuntimeId
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class PiAgentPromptTest {
    @Test
    fun instructionsOnlyAppendArixRuntimeConstraints() {
        val instructions = buildPiAgentInstructions(
            settings = AppSettings(),
            workspaceDirectory = "/workspace",
            runtimeId = LocalRuntimeId.Alpine,
            agentModeEnabled = false,
        )

        assertTrue(instructions.contains("current local runtime is alpine"))
        assertTrue(instructions.contains("use read on the provided path"))
        assertFalse(instructions.contains("analyze_image"))
        assertFalse(instructions.contains("fetch_web_url"))
        assertFalse(instructions.contains("mcp_"))
        assertFalse(instructions.contains("<active_skill"))
    }

    @Test
    fun browserToolIsAlwaysDocumentedAndChromeModeAddsVisualPreview() {
        // v2.4.9: the agent browser is always available (user request), so its
        // instructions are always present; the Chrome visual mode only adds
        // the live-preview note.
        val baseInstructions = buildPiAgentInstructions(
            settings = AppSettings(),
            workspaceDirectory = "/workspace",
            runtimeId = LocalRuntimeId.Alpine,
            agentModeEnabled = false,
        )
        val chromeInstructions = buildPiAgentInstructions(
            settings = AppSettings(),
            workspaceDirectory = "/workspace",
            runtimeId = LocalRuntimeId.Alpine,
            agentModeEnabled = false,
            chromeEnabled = true,
        )

        assertTrue(baseInstructions.contains("Agent browser"))
        assertTrue(baseInstructions.contains("browser` tool is always available"))
        assertFalse(baseInstructions.contains("live preview"))
        assertTrue(chromeInstructions.contains("live preview"))
    }

    @Test
    fun screenReadInstructionsForbidScreenshots() {
        val instructions = buildPiAgentInstructions(
            settings = AppSettings(),
            workspaceDirectory = "/workspace",
            runtimeId = LocalRuntimeId.Alpine,
            agentModeEnabled = false,
        )
        assertTrue(instructions.contains("read_screen"))
        assertTrue(instructions.contains("uiautomator"))
        assertTrue(instructions.contains("Never run `adb shell screencap`"))
    }
}
