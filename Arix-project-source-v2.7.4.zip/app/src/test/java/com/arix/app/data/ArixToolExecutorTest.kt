package com.arix.app.data

import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ArixToolExecutorTest {
    @Test
    fun hostToolDefinitionsExposeAgentModeAndSelfManagement() {
        val definitions = ArixToolExecutor.hostToolDefinitions()
        // v2.4.8: agent_mode is the only always-on host tool (no system_control).
        assertEquals("agent_mode", definitions.getJSONObject(0).getString("name"))
    }

    @Test
    fun hostToolDefinitionsExposeFlattenedShape() {
        val definitions = ArixToolExecutor.hostToolDefinitions()
        val definition = definitions.getJSONObject(0)
        assertEquals("agent_mode", definition.optString("name"))
        assertTrue(definition.has("parameters"))
        assertTrue(definition.optString("description").isNotBlank())
    }

    @Test
    fun hostToolNamesCoverAgentModeAndSelfManagement() {
        assertTrue(ArixToolExecutor.supports("agent_mode"))
        assertFalse(ArixToolExecutor.supports("system_control"))
        assertFalse(ArixToolExecutor.supports("android_shell"))
        assertTrue(ArixToolExecutor.supports("arix_config_get"))
        assertFalse(ArixToolExecutor.supports("chrome"))
    }

    @Test
    fun inferToolOutputOkHonorsArixJsonFlags() {
        assertTrue(ArixToolExecutor.inferToolOutputOk("""{"ok":true}"""))
        assertFalse(ArixToolExecutor.inferToolOutputOk("""{"ok":false}"""))
        assertFalse(ArixToolExecutor.inferToolOutputOk("""{"err":true}"""))
        assertTrue(ArixToolExecutor.inferToolOutputOk("plain text"))
    }

    @Test
    fun executionResultFlagsErrorOutput() {
        val ok = ArixToolExecutionResult("agent_mode", "{}", """{"ok":true}""")
        val failed = ArixToolExecutionResult("agent_mode", "{}", """{"ok":false,"errmsg":"nope"}""")
        assertFalse(ok.isError)
        assertTrue(failed.isError)
    }
}
