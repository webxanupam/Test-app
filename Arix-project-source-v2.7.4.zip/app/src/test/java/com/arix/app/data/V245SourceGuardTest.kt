package com.arix.app.data

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

/**
 * Source-guard regression tests for v2.4.5 fixes that cannot be exercised by
 * plain JVM unit tests because they live behind Android-runtime constructors
 * (AlpineRuntime needs a Context + proot; McpClientManager needs a live
 * runtime; PiKernelBridge boots a node process). Each assertion pins the
 * exact code shape that the corresponding bug fix introduced so a future
 * refactor cannot silently reintroduce the defect.
 */
class V245SourceGuardTest {

    private fun moduleDir(): File {
        var dir: File? = File(System.getProperty("user.dir"))
        repeat(6) {
            val direct = File(dir, "src/main/java/com/arix/app")
            if (direct.isDirectory) return dir!!
            dir = dir?.parentFile
        }
        throw IllegalStateException("app module directory not found")
    }

    private fun appSource(relative: String): String =
        File(moduleDir(), "src/main/java/com/arix/app/$relative").readText()

    @Test
    fun mcpBrokerScriptsEscapeServerIdInShellAssignment() {
        // Bug: `root='${brokerRootPath()}'` embedded an unescaped server id
        // (restorable from backup-imported settings) inside single quotes —
        // an id containing `'` broke out into arbitrary shell. Fix: every
        // interpolation site passes through escapeForSingleQuoted.
        val src = appSource("data/McpClientManager.kt")
        assertTrue(src.contains("root='\${escapeForSingleQuoted(brokerRootPath())}'"))
        assertFalse(src.contains("root='\${brokerRootPath()}'"))
    }

    @Test
    fun alpineTarExtractionUsesStrictContainmentPrefix() {
        // Bug: `target.path.startsWith(canonicalRoot.path)` let a sibling
        // directory like "../rootfs-evil" pass (prefix without separator).
        // Fix: containment requires the separator (or an exact-root match).
        val src = appSource("runtime/AlpineRuntime.kt")
        assertTrue(src.contains("canonicalRoot.path + File.separator"))
        // The weak form must not remain anywhere in extraction code.
        assertFalse(src.contains("startsWith(canonicalRoot.path)"))
    }

    @Test
    fun bridgeFailPendingRequestsDoesNotSkipDeadGeneration() {
        // Bug: when a restart installed a new process before failPendingRequests
        // acquired the mutex, the `return` left the dead generation's pending
        // requests suspended forever (run_turn/subscribe have no timeout).
        // Fix: log-and-continue — the generation filter fails exactly the dead
        // generation's requests.
        val src = appSource("data/pi/PiKernelBridge.kt")
        val fn = src.substringAfter("private suspend fun failPendingRequests(")
        assertTrue("failPendingRequests must exist", fn.isNotBlank())
        assertFalse(
            "failPendingRequests must not early-return when the process was replaced",
            fn.substringBefore("private fun nextRequestId").contains("return\n"),
        )
    }

    @Test
    fun bridgeUnsubscribesStaleExtensionSubscribers() {
        // Bug: a terminated subscribe request left its id registered in the
        // bridge's arixSubscriberRequestIds forever; host calls route to the
        // first (stale) id and time out. Fix: request() finally sends
        // unsubscribe_arix_extensions with the dead id.
        val src = appSource("data/pi/PiKernelBridge.kt")
        assertTrue(src.contains("\"unsubscribe_arix_extensions\""))
        assertTrue(src.contains("JSONObject().put(\"request_id\", id)"))
    }

    @Test
    fun chromeControllerSweepsAndKillsGuestProcesses() {
        // Bug: proot children (chromium/Xvnc/openbox/websockify) survived
        // stop()/app-kill, keeping ports 9222/5900/6080 occupied and enabling
        // false attach to an orphaned browser. Fix: launch-script sweep +
        // awaited guest-side kill on stop.
        val src = appSource("data/AlpineChromeController.kt")
        assertTrue("launch script must sweep stale guest processes", src.contains("pkill -KILL -x"))
        assertTrue("stop must terminate guest process tree", src.contains("killGuestChromeProcesses()"))
        assertTrue(src.contains("private suspend fun stopLocked(): String {"))
    }

    @Test
    fun timeoutCancellationNoLongerWedgesProviderAuthAndPiSetupStates() {
        // Bug: TimeoutCancellationException (a CancellationException subclass)
        // wedged the provider-login screen ("Waiting for authorization." with
        // isRunning=true) and the Pi setup spinner (isChecking=true) forever.
        // Fix: timeouts fall through to the error path.
        val vm = appSource("ui/ArixViewModel.kt")
        assertTrue(
            "provider auth timeout must reach the error path",
            vm.contains("throwable !is TimeoutCancellationException) return@fold"),
        )
        assertTrue(
            "pi core setup timeout must reach the Failed phase",
            vm.contains("throwable !is TimeoutCancellationException) throw throwable"),
        )
    }
}
