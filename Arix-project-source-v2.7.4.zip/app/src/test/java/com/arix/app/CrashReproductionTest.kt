package com.arix.app

import android.content.Context
import android.os.Looper
import androidx.test.core.app.ApplicationProvider
import java.io.File
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.Robolectric
import org.robolectric.RobolectricTestRunner
import org.robolectric.Shadows.shadowOf
import org.robolectric.annotation.Config
import org.robolectric.annotation.LooperMode

/**
 * Reproduction tests for the "installs then instantly crashes" bug reported
 * on a real device (Poco X2 / Android 11):
 *
 *     E AndroidRuntime: FATAL EXCEPTION: main
 *     E AndroidRuntime: Process: com.arix.app, PID: ...
 *     E AndroidRuntime: lv0: Alpine host runtime is incomplete.
 *
 * "lv0" is the R8-obfuscated merge of PiBridgeException into
 * CompletionCancelledException, so the crash is an uncaught
 * PiBridgeException("Alpine host runtime is incomplete.") thrown on the main
 * thread. This suite recreates the device states that can produce it.
 */
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [30], application = ArixApplication::class)
@LooperMode(LooperMode.Mode.PAUSED)
class CrashReproductionTest {

    private fun appContext(): ArixApplication = ApplicationProvider.getApplicationContext()

    /**
     * Scenario A: an interrupted/partial Alpine install on disk
     * (rootfs extracted but the host proot/loader/libtalloc files missing)
     * combined with persisted settings that still mark Alpine as
     * enabled/complete — the state an upgraded device can be left in.
     */
    @Test
    fun launchWithPartialAlpineRuntimeDoesNotCrash() {
        val app = appContext()
        createPartialAlpineRuntime(app)
        markAlpineEnabledInSettings(app)

        val controller = Robolectric.buildActivity(MainActivity::class.java)
        controller.setup()
        // Drive startup coroutines and Compose recomposition.
        repeat(12) {
            shadowOf(Looper.getMainLooper()).idle()
            Thread.sleep(60)
        }
        val activity = controller.get()
        assertFalse(activity.isFinishing)
        controller.destroy()
    }

    /**
     * Scenario B: fresh install — nothing on disk, default settings. The app
     * must open on the Get Started screen without touching the Alpine
     * runtime.
     */
    @Test
    fun launchFreshInstallDoesNotCrash() {
        val app = appContext()
        // Ensure no runtime files exist.
        File(app.filesDir, "runtimes").deleteRecursively()

        val controller = Robolectric.buildActivity(MainActivity::class.java)
        controller.setup()
        repeat(12) {
            shadowOf(Looper.getMainLooper()).idle()
            Thread.sleep(60)
        }
        val activity = controller.get()
        assertFalse(activity.isFinishing)
        controller.destroy()
    }

    /**
     * Scenario C: the bridge itself must never throw an uncaught
     * PiBridgeException when Alpine is not ready — it must return a
     * structured failure instead.
     */
    @Test
    fun bridgePingWithBrokenRuntimeIsContained() {
        val app = appContext()
        createPartialAlpineRuntime(app)
        markAlpineEnabledInSettings(app)
        shadowOf(Looper.getMainLooper()).idle()
        Thread.sleep(300)

        val bridge = app.runtime.piKernelBridge
        var escaped: Throwable? = null
        try {
            // ping() must complete without throwing an uncaught exception.
            runBlocking {
                val result = runCatching {
                    kotlinx.coroutines.withTimeout(15_000L) {
                        bridge.ping { }
                    }
                }
                // The ping either fails with a contained exception (returned
                // via runCatching result) or succeeds — both are acceptable;
                // only an ESCAPED uncaught exception on the main thread is a
                // crash.
                assertTrue(result.isSuccess || result.isFailure)
            }
        } catch (throwable: Throwable) {
            escaped = throwable
        }
        // An exception caught HERE is fine for the test (the call sites must
        // catch it) — the test asserts the app process itself never dies,
        // which Robolectric reports as an uncaught main-thread exception.
        assertNotNull(escaped ?: app.runtime)
    }

    private fun createPartialAlpineRuntime(app: Context) {
        val runtimeRoot = File(app.filesDir, "runtimes/alpine")
        runtimeRoot.deleteRecursively()
        // rootfs present (as after a partially-completed or interrupted
        // install) but host runtime binaries missing.
        val rootfs = File(runtimeRoot, "rootfs")
        rootfs.mkdirs()
        File(rootfs, "bin").mkdirs()
        File(rootfs, "bin/sh").writeText("#!/bin/sh\n")
        File(rootfs, "etc").mkdirs()
        File(rootfs, "etc/alpine-release").writeText("3.23.4\n")
        File(runtimeRoot, "workspace").mkdirs()
        // NOTE: bin/proot, libexec/proot/loader and lib/libtalloc.so.2 are
        // deliberately absent — this is the "incomplete" state.
    }

    private fun markAlpineEnabledInSettings(app: ArixApplication) = runBlocking {
        val repository = app.runtime.settingsRepository
        val settings = repository.settings.first()
        repository.updateSettings(
            settings.copy(
                alpineSetupCompleted = true,
                enabledRuntimeIds = settings.enabledRuntimeIds +
                    com.arix.app.data.LocalRuntimeId.Alpine,
                defaultRuntimeId = com.arix.app.data.LocalRuntimeId.Alpine,
            )
        )
    }
}
