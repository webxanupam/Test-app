package com.arix.app.ui

import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import org.json.JSONObject

/**
 * v2.4.8: minimal intent-based system actions for the native chat intents
 * (open_app, open_settings, open_url). This is NOT a host tool — it is only
 * used by the chat's native intent router when the user types a command
 * like "open gmail". The agent itself uses bash with `adb shell` for all
 * device control; there is no hardcoded system_control host tool.
 */
object ArixNativeSystemBridge {
    fun execute(context: Context, arguments: JSONObject): String {
        val action = arguments.optString("action").trim().lowercase()
        return when (action) {
            "open_app" -> openApp(context, arguments.optString("target").ifBlank { arguments.optString("app") }.trim())
            "open_settings" -> openSettings(context, arguments.optString("page").trim().lowercase())
            "open_url" -> openUrl(context, arguments.optString("url").trim())
            else -> JSONObject().put("ok", false).put("errmsg", "Unknown action '$action'.").toString()
        }
    }

    private fun openApp(context: Context, target: String): String {
        if (target.isBlank()) return JSONObject().put("ok", false).put("errmsg", "Provide the app name or package.").toString()
        val manager = context.packageManager
        val launchables = manager.getInstalledApplications(0).filter { manager.getLaunchIntentForPackage(it.packageName) != null }
        val resolved = launchables.firstOrNull { it.packageName.equals(target, ignoreCase = true) }
            ?: launchables.map { it to manager.getApplicationLabel(it).toString() }
                .firstOrNull { (info, label) -> label.equals(target, ignoreCase = true) || label.contains(target, ignoreCase = true) }?.first
            ?: return JSONObject().put("ok", false).put("errmsg", "No app matched '$target'.").toString()
        val label = manager.getApplicationLabel(resolved).toString()
        val launch = manager.getLaunchIntentForPackage(resolved.packageName)
            ?: return JSONObject().put("ok", false).put("errmsg", "App '$label' has no launch intent.").toString()
        return runCatching {
            context.startActivity(launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            JSONObject().put("ok", true).put("action", "open_app").put("app", label).put("detail", "Launched $label.").toString()
        }.getOrElse { JSONObject().put("ok", false).put("errmsg", "Could not launch: ${it.message}").toString() }
    }

    private fun openSettings(context: Context, page: String): String {
        val intent = when (page) {
            "", "main", "home" -> Intent(Settings.ACTION_SETTINGS)
            "wifi" -> Intent(Settings.ACTION_WIFI_SETTINGS)
            "bluetooth" -> Intent(Settings.ACTION_BLUETOOTH_SETTINGS)
            "apps" -> Intent(Settings.ACTION_MANAGE_APPLICATIONS_SETTINGS)
            "notifications" -> Intent("android.settings.NOTIFICATION_SETTINGS")
            "sound" -> Intent(Settings.ACTION_SOUND_SETTINGS)
            "display" -> Intent(Settings.ACTION_DISPLAY_SETTINGS)
            "battery" -> Intent(Settings.ACTION_BATTERY_SAVER_SETTINGS)
            "storage" -> Intent(Settings.ACTION_INTERNAL_STORAGE_SETTINGS)
            "location" -> Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS)
            "security" -> Intent(Settings.ACTION_SECURITY_SETTINGS)
            "developer" -> Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS)
            "about" -> Intent(Settings.ACTION_DEVICE_INFO_SETTINGS)
            else -> null
        } ?: return JSONObject().put("ok", false).put("errmsg", "Unknown settings page '$page'.").toString()
        return runCatching {
            context.startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            JSONObject().put("ok", true).put("action", "open_settings").put("page", page).toString()
        }.getOrElse { JSONObject().put("ok", false).put("errmsg", "Could not open: ${it.message}").toString() }
    }

    private fun openUrl(context: Context, url: String): String {
        if (url.isBlank()) return JSONObject().put("ok", false).put("errmsg", "Provide the URL.").toString()
        return runCatching {
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(intent)
            JSONObject().put("ok", true).put("action", "open_url").put("url", url).toString()
        }.getOrElse { JSONObject().put("ok", false).put("errmsg", "Could not open URL: ${it.message}").toString() }
    }
}
