package com.arix.app.data

import com.arix.app.runtime.RuntimeRouter
import org.json.JSONArray
import org.json.JSONObject

data class ArixToolExecutionResult(
    val toolName: String,
    val argumentsJson: String,
    val rawOutput: String,
) {
    val visibleOutput: String = rawOutput
    val isError: Boolean = !ArixToolExecutor.inferToolOutputOk(rawOutput)
}

/**
 * Adapter for Arix-owned host capabilities only. Pi Coding Agent owns all
 * filesystem, shell, search, Skill, Extension, and image-reading mechanics.
 *
 * v2.4.9: no hardcoded device-control host tool — the agent uses the bash tool
 * to run `adb shell` commands directly (adb shell input tap, adb shell
 * uiautomator dump, etc.) through the bundled arix-adb helper. The only host
 * tool retained is agent_mode, which reads the screen as structured text
 * (uiautomator dump — no screenshots, nothing saved to storage).
 *
 * v2.6.2: MCP host tools — `arix_mcp_list` and `arix_mcp_call` expose the
 * app's native MCP connections to the agent as first-class tools, and every
 * connected MCP tool is also registered under its namespaced call name with
 * its real input schema. All calls flow through McpClientManager's
 * auto-reconnect, so a disconnected server is reconnected (and the turn
 * waits) instead of the agent silently failing over to another method.
 */
class ArixToolExecutor(
    private val runtimeRouter: RuntimeRouter,
    private val agentModeController: ArixAgentModeController? = null,
    private val mcpClientManager: McpClientManager? = null,
) {
    suspend fun execute(
        settings: AppSettings,
        workspaceDirectory: String,
        toolName: String,
        argumentsJson: String,
        selfManagementTool: ArixSelfManagementTool? = null,
        currentRuntimeId: LocalRuntimeId = settings.defaultRuntimeId ?: LocalRuntimeId.Alpine,
        onRuntimeChanged: suspend (LocalRuntimeId) -> Unit = {},
        onProgress: (suspend (String) -> Unit)? = null,
    ): ArixToolExecutionResult {
        val rawOutput = when {
            toolName == "agent_mode" -> agentModeController?.execute(argumentsJson)
                ?: JSONObject()
                    .put("ok", false)
                    .put("errmsg", "Agent Mode is not available. Use bash with `adb shell` commands for device control.")
                    .toString()

            toolName == "arix_runtime_manage" -> executeRuntimeManage(
                settings = settings,
                currentRuntimeId = currentRuntimeId,
                workspaceDirectory = workspaceDirectory,
                argumentsJson = argumentsJson,
                onRuntimeChanged = onRuntimeChanged,
            )

            toolName == "arix_mcp_list" -> executeMcpList()

            toolName == "arix_mcp_call" -> executeMcpCall(argumentsJson, onProgress)

            // v2.6.2: namespaced MCP tools (mcp__<server>__<tool> or
            // <server>:<tool>) route straight into the MCP manager with the
            // full auto-reconnect treatment.
            toolName.startsWith("mcp__") || toolName.contains(':') && toolName.substringBefore(':').let { serverKey ->
                mcpClientManager?.serversProvider?.invoke()?.any {
                    it.id.equals(serverKey, ignoreCase = true) || it.displayName.equals(serverKey, ignoreCase = true)
                } == true
            } -> executeMcpToolByName(toolName, argumentsJson, onProgress)

            toolName in SelfManagementToolNames -> selfManagementTool?.execute(
                toolName = toolName,
                argumentsJson = argumentsJson,
            ) ?: unavailableToolOutput(toolName)

            else -> JSONObject()
                .put("ok", false)
                .put("error", "Unknown Arix host tool '$toolName'.")
                .toString()
        }
        return ArixToolExecutionResult(toolName, argumentsJson, rawOutput)
    }

    private suspend fun executeRuntimeManage(
        settings: AppSettings,
        currentRuntimeId: LocalRuntimeId,
        workspaceDirectory: String,
        argumentsJson: String,
        onRuntimeChanged: suspend (LocalRuntimeId) -> Unit,
    ): String {
        val arguments = runCatching { JSONObject(argumentsJson) }.getOrNull()
            ?: return JSONObject().put("ok", false).put("errmsg", "Invalid JSON arguments.").toString()
        val action = arguments.optString("action").trim()
        if (action == "status") {
            val states = listOf(LocalRuntimeId.Alpine).associateWith { runtimeId ->
                runtimeRouter.runtimeById(runtimeId).inspectSetup()
            }
            return JSONObject().apply {
                put("ok", true)
                put("action", "status")
                put("runtime", currentRuntimeId.storageValue)
                put("cwd", workspaceDirectory)
                put("available", JSONObject().apply {
                    states.forEach { (runtimeId, state) -> put(runtimeId.storageValue, state.isReady) }
                })
            }.toString()
        }
        if (action != "set") {
            return JSONObject().put("ok", false).put("errmsg", "action must be 'status' or 'set'.").toString()
        }
        val requested = LocalRuntimeId.fromStorage(arguments.optString("runtime"))
            ?: return JSONObject().put("ok", false).put("errmsg", "runtime must be 'alpine'.").toString()
        if (requested != LocalRuntimeId.Alpine) {
            return JSONObject().put("ok", false).put("errmsg", "Alpine is the only local runtime.").toString()
        }
        val setup = runtimeRouter.runtimeById(requested).inspectSetup()
        val enabled = settings.enabledRuntimeIds.isEmpty() || requested in settings.enabledRuntimeIds
        if (!setup.isReady || !enabled) {
            return JSONObject().apply {
                put("ok", false)
                put("errmsg", "${requested.displayName} runtime is unavailable.")
                put("detail", setup.detail)
                put("runtime", currentRuntimeId.storageValue)
                put("cwd", workspaceDirectory)
            }.toString()
        }
        onRuntimeChanged(requested)
        return JSONObject().apply {
            put("ok", true)
            put("action", "set")
            put("runtime", requested.storageValue)
            put("cwd", workspaceDirectory)
        }.toString()
    }

    /** v2.6.2: `arix_mcp_list` — servers, statuses, tools and their fields. */
    private suspend fun executeMcpList(): String {
        val manager = mcpClientManager
            ?: return JSONObject()
                .put("ok", false)
                .put("errmsg", "MCP is not available in this build.")
                .toString()
        val result = manager.listTools(null)
        return result.fold(
            onSuccess = { output ->
                // Annotate with live per-server connection status.
                runCatching {
                    val parsed = JSONObject(output)
                    val statuses = JSONObject()
                    manager.snapshots().forEach { snapshot ->
                        statuses.put(
                            snapshot.config.id,
                            JSONObject()
                                .put("name", snapshot.config.displayName)
                                .put("status", snapshot.status.name.lowercase())
                                .put("enabled", snapshot.config.isEnabled)
                                .put(
                                    "error",
                                    snapshot.errorMessage.takeIf { it.isNotBlank() } ?: "",
                                ),
                        )
                    }
                    parsed.put("servers", statuses)
                    parsed.put("stdout", "Listed ${parsed.optJSONArray("tools")?.length() ?: 0} MCP tools.")
                    parsed.toString()
                }.getOrDefault(output)
            },
            onFailure = { throwable ->
                JSONObject()
                    .put("ok", false)
                    .put("errmsg", throwable.message ?: "MCP list failed.")
                    .toString()
            },
        )
    }

    /**
     * v2.6.2: `arix_mcp_call` — calls an MCP tool by call name
     * (mcp__server__tool / server:tool / "server": "name" form). The call
     * auto-reconnects the owning server when needed and WAITS for the
     * reconnection (bounded) — the agent turn stays alive the whole time.
     */
    private suspend fun executeMcpCall(
        argumentsJson: String,
        onProgress: (suspend (String) -> Unit)?,
    ): String {
        val manager = mcpClientManager
            ?: return JSONObject()
                .put("ok", false)
                .put("errmsg", "MCP is not available in this build.")
                .toString()
        val arguments = runCatching { JSONObject(argumentsJson) }.getOrNull()
            ?: return JSONObject().put("ok", false).put("errmsg", "Invalid JSON arguments.").toString()
        val callName = arguments.optString("tool").trim()
            .ifBlank { arguments.optString("call_name").trim() }
            .ifBlank { arguments.optString("name").trim() }
        if (callName.isBlank()) {
            return JSONObject()
                .put("ok", false)
                .put("errmsg", "'tool' (the MCP tool call name) is required. Use arix_mcp_list to discover names.")
                .toString()
        }
        val callArguments = arguments.optJSONObject("arguments") ?: JSONObject()
        onProgress?.invoke(
            JSONObject()
                .put("ok", true)
                .put("status", "Calling MCP tool $callName…")
                .put("stdout", "Calling MCP tool $callName…")
                .toString()
        )
        val result = manager.callToolByName(callName, callArguments.toString())
        return result.fold(
            onSuccess = { output -> enrichMcpCallOutput(output, callName) },
            onFailure = { throwable ->
                JSONObject()
                    .put("ok", false)
                    .put("errmsg", throwable.message ?: "MCP tool call failed.")
                    .put("stdout", "MCP tool '$callName' failed: ${throwable.message}")
                    .toString()
            },
        )
    }

    /** v2.6.2: direct call for namespaced MCP tool host tools. */
    private suspend fun executeMcpToolByName(
        toolName: String,
        argumentsJson: String,
        onProgress: (suspend (String) -> Unit)?,
    ): String {
        val manager = mcpClientManager
            ?: return JSONObject()
                .put("ok", false)
                .put("errmsg", "MCP is not available in this build.")
                .toString()
        val result = manager.callToolByName(toolName, argumentsJson)
        return result.fold(
            onSuccess = { output -> enrichMcpCallOutput(output, toolName) },
            onFailure = { throwable ->
                JSONObject()
                    .put("ok", false)
                    .put("errmsg", throwable.message ?: "MCP tool call failed.")
                    .put("stdout", "MCP tool '$toolName' failed: ${throwable.message}")
                    .toString()
            },
        )
    }

    /**
     * v2.6.2: marks a successful MCP call output with the widget hint the
     * chat renderer auto-detects (`widget: "mcp_data"` + the raw MCP result
     * under `result`) so movie-style results render as native chat widgets.
     */
    private fun enrichMcpCallOutput(output: String, callName: String): String =
        runCatching {
            val parsed = JSONObject(output)
            if (parsed.has("widget")) return output
            parsed.put("widget", "mcp_data")
            parsed.put("mcp_call_name", callName)
            parsed.put("stdout", parsed.optString("stdout").ifBlank { "Called MCP tool $callName." })
            parsed.toString()
        }.getOrDefault(output)

    /**
     * v2.6.2: turn-scoped host tool definitions — the static set plus every
     * connected MCP tool under its namespaced call name.
     */
    suspend fun hostToolDefinitionsForTurn(
        selfManagementTool: ArixSelfManagementTool? = null,
    ): JSONArray = ArixToolExecutor.hostToolDefinitionsWithMcp(
        selfManagementTool = selfManagementTool,
        mcpClientManager = mcpClientManager,
    )

    companion object {
        val hostToolNames: Set<String> = setOf(
            "agent_mode",
            "arix_mcp_list",
            "arix_mcp_call",
            *SelfManagementToolNames.toTypedArray(),
        )

        fun supports(toolName: String): Boolean =
            toolName in hostToolNames || toolName.startsWith("mcp__") ||
                (
                    toolName.contains(':') &&
                        !toolName.startsWith("arix_") &&
                        // Guard against unrelated ':' usage — MCP legacy names
                        // are "serverName:toolName" with no further colons.
                        toolName.count { it == ':' } == 1
                    )

        fun hostToolDefinitions(
            selfManagementTool: ArixSelfManagementTool? = null,
        ): JSONArray = JSONArray().apply {
            put(agentModeToolDefinition())
            put(mcpListToolDefinition())
            put(mcpCallToolDefinition())
            selfManagementTool?.toolDefinitions()?.forEach { definition ->
                put(
                    flattenOpenAiToolDefinition(
                        definition = definition,
                        executionMode = if (
                            definition.optJSONObject("function")?.optString("name") == "arix_config_get"
                        ) "parallel" else "sequential",
                    ),
                )
            }
        }

        /**
         * v2.6.2: host tool definitions PLUS every currently connected MCP
         * tool, each registered under its namespaced call name with the
         * server's real input schema — the agent sees the movie API's
         * search / stream / poster tools exactly like native tools.
         */
        suspend fun hostToolDefinitionsWithMcp(
            selfManagementTool: ArixSelfManagementTool? = null,
            mcpClientManager: McpClientManager? = null,
        ): JSONArray {
            val base = hostToolDefinitions(selfManagementTool)
            val manager = mcpClientManager ?: return base
            runCatching {
                manager.toolBindings().forEach { binding ->
                    base.put(
                        JSONObject().apply {
                            put("name", binding.namespacedToolName)
                            put(
                                "description",
                                "[MCP ${binding.serverName}] ${binding.description.ifBlank { binding.toolName }} — call this directly; Arix auto-reconnects the server if needed.",
                            )
                            put(
                                "parameters",
                                relaxStrictOptionalParameters(binding.inputSchema),
                            )
                            put("execution_mode", "sequential")
                        },
                    )
                }
            }
            return base
        }

        fun inferToolOutputOk(output: String): Boolean {
            val parsed = runCatching { JSONObject(output) }.getOrNull() ?: return true
            return parsed.optBoolean("ok", !parsed.optBoolean("err", false))
        }
    }
}

private val SelfManagementToolNames = setOf(
    "arix_config_get",
    "arix_config_set",
    "arix_skill_manage",
    "arix_runtime_manage",
    "arix_scheduled_task_manage",
    "arix_extension_manage",
    "arix_developer_manage",
)

private fun unavailableToolOutput(toolName: String): String = JSONObject()
    .put("ok", false)
    .put("errmsg", "Host dependency for '$toolName' is not available.")
    .toString()

private fun flattenOpenAiToolDefinition(
    definition: JSONObject,
    executionMode: String,
): JSONObject {
    val function = definition.optJSONObject("function") ?: JSONObject()
    return JSONObject().apply {
        put("name", function.optString("name"))
        put("description", function.optString("description"))
        put("parameters", relaxStrictOptionalParameters(function.optJSONObject("parameters")))
        put("execution_mode", executionMode)
    }
}

private fun relaxStrictOptionalParameters(parameters: JSONObject?): JSONObject {
    val relaxed = JSONObject((parameters ?: JSONObject().put("type", "object")).toString())
    val properties = relaxed.optJSONObject("properties") ?: return relaxed
    val required = relaxed.optJSONArray("required") ?: return relaxed
    relaxed.put("required", JSONArray().apply {
        for (index in 0 until required.length()) {
            val name = required.optString(index)
            if (name.isNotBlank() && !properties.optJSONObject(name).allowsNull()) put(name)
        }
    })
    return relaxed
}

private fun JSONObject?.allowsNull(): Boolean = when (val type = this?.opt("type")) {
    "null" -> true
    is JSONArray -> (0 until type.length()).any { type.optString(it) == "null" }
    else -> false
}

/**
 * v2.4.9: agent_mode provides text-based screen awareness via
 * `adb shell uiautomator dump` (no screenshots, no image storage). The
 * agent uses the bash tool for all device control (adb shell input tap,
 * adb shell input swipe, adb shell input text, etc.) — there is no
 * hardcoded device-control host tool.
 */
private fun agentModeToolDefinition(): JSONObject = JSONObject().apply {
    put("name", "agent_mode")
    put(
        "description",
        "Read the device screen as structured text (OCR-like awareness via uiautomator): every " +
            "visible element with text, description, id, bounds and clickable/scrollable flags. " +
            "NO screenshots are taken — nothing is stored as an image. Decide yourself what the " +
            "elements mean and interact with them. For device control (tapping, swiping, typing, " +
            "pressing keys) use the bash tool with `adb shell input tap X Y`, `adb shell input " +
            "swipe X1 Y1 X2 Y2`, `adb shell input text \"...\"`, `adb shell input keyevent " +
            "KEYCODE_BACK`, etc. First-time setup: pair the device's Wireless debugging service " +
            "(Android 11+) and run `arix-adb pair 127.0.0.1:PORT CODE` then `arix-adb connect " +
            "127.0.0.1:PORT` in the Alpine terminal tab.",
    )
    put("parameters", JSONObject().apply {
        put("type", "object")
        put("properties", JSONObject().apply {
            put("action", JSONObject().put("type", "string").put(
                "description", "One of: read_screen (default — reads the screen as text), status. Screenshots are intentionally unavailable."
            ))
        })
        put("required", JSONArray().put("action"))
        put("additionalProperties", false)
    })
    put("execution_mode", "sequential")
}

/** v2.6.2: arix_mcp_list — discover MCP servers, tools and option fields. */
private fun mcpListToolDefinition(): JSONObject = JSONObject().apply {
    put("name", "arix_mcp_list")
    put(
        "description",
        "List the user's connected MCP (Model Context Protocol) servers with live connection " +
            "status, every tool they expose (namespaced call names like mcp__<server>__<tool>), " +
            "each tool's input fields, resources and prompts. Use this FIRST whenever the user " +
            "asks about movies, streams, posters or any data that might come from their MCP " +
            "connections. If a server shows a bad status, do not switch methods — call the tool " +
            "anyway; Arix auto-reconnects the server and waits for it.",
    )
    put("parameters", JSONObject().apply {
        put("type", "object")
        put("properties", JSONObject().apply {
            put("server", JSONObject().put("type", "string").put(
                "description", "Optional server id or name to filter to one MCP server."
            ))
        })
        put("additionalProperties", false)
    })
    put("execution_mode", "sequential")
}

/** v2.6.2: arix_mcp_call — call any MCP tool with auto-reconnect. */
private fun mcpCallToolDefinition(): JSONObject = JSONObject().apply {
    put("name", "arix_mcp_call")
    put(
        "description",
        "Call an MCP tool by its call name. Accepts the namespaced form " +
            "(mcp__<server>__<tool>), the legacy form (<server>:<tool>) or a plain tool name " +
            "when it is unique. Arix automatically reconnects the MCP server if it is not " +
            "connected and waits for the reconnection before executing — you do NOT need to " +
            "fall back to other methods when a connection dropped, just call the tool. " +
            "Structured results (title / poster / stream / url fields) are rendered to the " +
            "user as interactive cards automatically.",
    )
    put("parameters", JSONObject().apply {
        put("type", "object")
        put("properties", JSONObject().apply {
            put("tool", JSONObject().put("type", "string").put(
                "description", "The MCP tool call name from arix_mcp_list, e.g. mcp__movies__search or movies:search."
            ))
            put("arguments", JSONObject().put("type", "object").put(
                "description", "The tool's input arguments as a JSON object (see the tool's fields from arix_mcp_list)."
            ))
        })
        put("required", JSONArray().put("tool"))
        put("additionalProperties", false)
    })
    put("execution_mode", "sequential")
}
