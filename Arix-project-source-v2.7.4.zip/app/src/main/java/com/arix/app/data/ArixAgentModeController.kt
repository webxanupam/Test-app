package com.arix.app.data

import android.content.Context
import com.arix.app.runtime.AlpineRuntime
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import org.xmlpull.v1.XmlPullParser
import org.xmlpull.v1.XmlPullParserFactory
import java.io.StringReader

/**
 * v2.4.9: screen-awareness Agent Mode controller — no screenshots.
 *
 * The agent gets text-based screen awareness through `adb shell uiautomator
 * dump` (an OCR-like structured read of everything visible on screen: texts,
 * descriptions, controls and their bounds). Nothing is captured as an image
 * and nothing is written to device storage beyond a transient XML that is
 * deleted immediately after being read.
 *
 * There is deliberately NO hardcoded "brain" here: the controller returns the
 * raw structured screen tree and the AI agent itself decides what to do with
 * it. A safetynet fallback (`dumpsys window` + `dumpsys activity`) keeps the
 * agent minimally aware (focused window / current app) whenever the
 * uiautomator read fails.
 *
 * All device actions (tapping, swiping, typing, pressing keys) are done by
 * the agent through the bash tool with `adb shell input ...` commands —
 * there is no separate system_control host tool.
 *
 * First-time ADB setup (one-time, on the device):
 *   1. Settings → System → Developer options → Wireless debugging → ON
 *   2. Open "Pair device with pairing code" — note IP:PORT + 6-digit code
 *   3. In the Alpine terminal tab: arix-adb pair 127.0.0.1:PORT CODE
 *   4. Then: arix-adb connect 127.0.0.1:PORT
 */
class ArixAgentModeController(
    private val context: Context,
    private val alpineRuntimeProvider: () -> AlpineRuntime? = { null },
) {
    suspend fun execute(argumentsJson: String): String {
        val arguments = runCatching { JSONObject(argumentsJson) }.getOrNull()
            ?: return failure("Arguments were not valid JSON.")
        val action = arguments.optString("action").trim().lowercase().ifBlank { "read_screen" }
        return when (action) {
            "read_screen", "read", "screen" -> readScreen()
            "screenshot" -> failure(
                "Screenshots are disabled. Use action=read_screen instead — it reads the screen " +
                    "as text (uiautomator dump) with zero image storage.",
            )
            "status" -> status()
            else -> failure("Unknown action '$action'. Use 'read_screen' or 'status'.")
        }
    }

    private suspend fun status(): String {
        val runtime = alpineRuntimeProvider()
            ?: return failure("Alpine runtime is not ready. Open Settings → Alpine → install the 'ADB tools' preset.")
        val available = isAdbAvailable(runtime)
        return JSONObject().apply {
            put("ok", true)
            put("action", "status")
            put("adb_available", available)
            if (!available) {
                put("detail", "ADB is not installed. Install the 'ADB tools' preset in Settings → Alpine → Packages, then pair via Wireless debugging.")
            } else {
                put("detail", "ADB is available. Use agent_mode action=read_screen for screen awareness, and bash with `adb shell` commands for device control.")
            }
        }.toString()
    }

    /**
     * Text-based screen read via `uiautomator dump`. Returns the full
     * structured element tree so the agent (not hardcoded logic) decides
     * what is on screen and what to do next.
     */
    private suspend fun readScreen(): String {
        val runtime = alpineRuntimeProvider()
            ?: return failure("Alpine runtime is not ready. Cannot read the screen.")
        if (!isAdbAvailable(runtime)) {
            return failure("ADB is not installed. Install the 'ADB tools' preset in Settings → Alpine → Packages, then pair via Wireless debugging.")
        }
        return withContext(Dispatchers.IO) {
            val remotePath = "/sdcard/arix_screen_${System.currentTimeMillis()}.xml"
            val dumpCommand = """
                set -e
                arix-adb shell 'uiautomator dump $remotePath' 2>&1 || true
                arix-adb shell 'cat $remotePath' 2>/dev/null || true
                arix-adb shell 'rm -f $remotePath' 2>/dev/null || true
                arix-adb shell 'dumpsys window windows 2>/dev/null | grep -E "mCurrentFocus|mFocusedApp" | head -2' 2>/dev/null || true
            """.trimIndent()
            val result = runCatching { JSONObject(runtime.executeCommand(dumpCommand, runtime.homeDirectory, 30_000L)) }
                .getOrElse { throwable ->
                    return@withContext failure("adb screen read failed: ${throwable.message ?: "unknown error"}")
                }
            val stdout = result.optString("stdout", "")
            val focusInfo = extractFocusInfo(stdout)
            val xml = extractXml(stdout)
            val screenTree = if (xml.isNotBlank()) parseScreenTree(xml) else ""

            // Safetynet: uiautomator may fail (locked screen, insecure popup,
            // animation in progress). Never leave the agent blind — report the
            // focused window/app so the model can still reason and recover.
            if (screenTree.isBlank()) {
                if (focusInfo.isNotBlank()) {
                    return@withContext JSONObject().apply {
                        put("ok", true)
                        put("action", "read_screen")
                        put("mode", "safetynet")
                        put("window", focusInfo)
                        put(
                            "detail",
                            "uiautomator dump returned no XML (the screen may be locked, showing a " +
                                "secure system dialog, or an animation was running). Safetynet fallback " +
                                "provides the focused window only. Wait a moment and try again, or " +
                                "unlock/wake the device with `adb shell input keyevent KEYCODE_WAKEUP`.",
                        )
                    }.toString()
                }
                return@withContext failure(
                    result.optString("stderr", "").ifBlank {
                        "adb uiautomator dump failed. Make sure the device is paired and connected " +
                            "(arix-adb connect 127.0.0.1:PORT) and the screen is awake and unlocked."
                    },
                )
            }
            JSONObject().apply {
                put("ok", true)
                put("action", "read_screen")
                if (focusInfo.isNotBlank()) put("window", focusInfo)
                put("screen", screenTree)
                put(
                    "detail",
                    "Structured screen contents (uiautomator): each line is [bounds] class | " +
                        "text | description | id. Decide yourself what to interact with; tap with " +
                        "`adb shell input tap X Y` using the bounds center.",
                )
            }.toString()
        }
    }

    private fun extractFocusInfo(stdout: String): String = stdout
        .lineSequence()
        .filter { it.contains("mCurrentFocus") || it.contains("mFocusedApp") }
        .map { it.trim().substringBefore(" (").substringBefore("}").trim() }
        .filter { it.isNotBlank() }
        .distinct()
        .joinToString("\n")
        .take(500)

    /** Pulls the XML document out of mixed adb output (dump prints chatter
     *  before/around the XML). Looks for the hierarchy root element. */
    private fun extractXml(stdout: String): String {
        val start = stdout.indexOf("<?xml")
        val hierarchyStart = stdout.indexOf("<hierarchy")
        val effectiveStart = when {
            start >= 0 -> start
            hierarchyStart >= 0 -> hierarchyStart
            else -> return ""
        }
        val end = stdout.lastIndexOf("</hierarchy>")
        if (end < effectiveStart) return ""
        return stdout.substring(effectiveStart, end + "</hierarchy>".length)
    }

    /**
     * Converts the uiautomator XML into a compact indented text tree. Every
     * visible element is kept — the decision of what matters belongs to the
     * AI agent, not to hardcoded host-side filtering.
     */
    private fun parseScreenTree(xml: String): String {
        val builder = StringBuilder()
        return runCatching {
            val parser = XmlPullParserFactory.newInstance().apply {
                isNamespaceAware = false
            }.newPullParser()
            parser.setInput(StringReader(xml))
            var depth = -1
            var event = parser.eventType
            while (event != XmlPullParser.END_DOCUMENT) {
                when (event) {
                    XmlPullParser.START_TAG -> {
                        if (parser.name == "hierarchy") {
                            event = parser.next()
                            continue
                        }
                        if (parser.name == "node") {
                            depth += 1
                            val text = parser.getAttributeValue(null, "text").orEmpty().trim()
                            val desc = parser.getAttributeValue(null, "content-desc").orEmpty().trim()
                            val clazz = parser.getAttributeValue(null, "class").orEmpty()
                                .substringAfterLast('.')
                            val resId = parser.getAttributeValue(null, "resource-id").orEmpty()
                                .substringAfterLast('/')
                            val bounds = parser.getAttributeValue(null, "bounds").orEmpty()
                            val clickable = parser.getAttributeValue(null, "clickable") == "true"
                            val scrollable = parser.getAttributeValue(null, "scrollable") == "true"
                            val hasContent = text.isNotBlank() || desc.isNotBlank() || clickable || scrollable
                            val indent = "  ".repeat(depth.coerceAtMost(30))
                            if (hasContent || clazz.isNotBlank()) {
                                builder.append(indent)
                                    .append(bounds)
                                    .append(' ').append(clazz)
                                if (clickable) builder.append(" [clickable]")
                                if (scrollable) builder.append(" [scrollable]")
                                if (text.isNotBlank()) builder.append(" | text=\"").append(text.take(160)).append('"')
                                if (desc.isNotBlank()) builder.append(" | desc=\"").append(desc.take(160)).append('"')
                                if (resId.isNotBlank()) builder.append(" | id=").append(resId)
                                builder.append('\n')
                            }
                            if (builder.length > MaxScreenTreeChars) {
                                builder.append("…(truncated)\n")
                                return@runCatching builder.toString()
                            }
                        }
                    }
                    XmlPullParser.END_TAG -> {
                        if (parser.name == "node") depth -= 1
                    }
                }
                event = parser.next()
            }
            if (builder.isBlank()) "" else builder.toString()
        }.getOrDefault("")
    }

    private suspend fun isAdbAvailable(runtime: AlpineRuntime): Boolean = withContext(Dispatchers.IO) {
        val result = runtime.executeCommand(
            "command -v adb >/dev/null 2>&1 && command -v arix-adb >/dev/null 2>&1 && echo ok",
            runtime.homeDirectory,
            10_000L,
        )
        JSONObject(result).optBoolean("ok") &&
            JSONObject(result).optString("stdout", "").contains("ok")
    }

    private fun failure(message: String): String = JSONObject()
        .put("ok", false)
        .put("errmsg", message)
        .toString()

    private companion object {
        const val MaxScreenTreeChars = 40_000
    }
}
