package com.arix.app.data

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.Settings
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

/**
 * v2.4.1 — phone-storage access gate for the built-in Alpine VM.
 *
 * The VM reaches the phone's real shared storage through proot bind mounts
 * (see AlpineRuntime.phoneStorageBinds); the app uid just needs the matching
 * Android permission. Arix targets API 28, so it runs under the *legacy*
 * external-storage model:
 *
 *  - Android 8–10: the classic READ/WRITE_EXTERNAL_STORAGE runtime dialog.
 *  - Android 11+:  the "All files access" (MANAGE_EXTERNAL_STORAGE) toggle in
 *                  system settings, which is the only reliable full-path
 *                  grant for third-party apps.
 *
 * Once granted, `ls /sdcard` inside the Alpine shell, the agent's shell
 * filesystem tools and the in-app file manager all see the real files.
 */
object ArixStorageAccess {
    const val StoragePermissionRequestCode = 4711

    /** Legacy runtime grant (READ or WRITE) — the pre-Android-11 path. */
    fun hasLegacyStorageGrant(context: Context): Boolean {
        val read = ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.READ_EXTERNAL_STORAGE,
        ) == PackageManager.PERMISSION_GRANTED
        val write = ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.WRITE_EXTERNAL_STORAGE,
        ) == PackageManager.PERMISSION_GRANTED
        return read || write
    }

    /**
     * All-files access (Android 11+).
     *
     * v2.4.3 fix: wrapped defensively — `Environment.isExternalStorageManager()`
     * can throw on some environments (Robolectric sandboxes, certain OEM
     * frameworks), and an unhandled exception here crashed MainActivity
     * startup (the whole app failed to open). A failed probe simply means
     * "not granted" and the legacy grant is consulted instead.
     */
    fun isAllFilesAccessGranted(context: Context): Boolean =
        Build.VERSION.SDK_INT >= Build.VERSION_CODES.R &&
            runCatching { Environment.isExternalStorageManager() }.getOrDefault(false)

    /** True when the VM can read the phone's real storage right now. */
    fun hasPhoneStorageAccess(context: Context): Boolean =
        isAllFilesAccessGranted(context) || hasLegacyStorageGrant(context)

    /** Checks direct file-path readability of the shared-storage root. */
    fun canBrowsePhoneStorage(): Boolean = runCatching {
        val root = Environment.getExternalStorageDirectory()
        root.isDirectory && root.canRead()
    }.getOrDefault(false)

    /**
     * Requests storage access the appropriate way for this Android version.
     * Returns true when a request surface (dialog or settings page) was
     * actually opened.
     */
    fun requestPhoneStorageAccess(activity: Activity): Boolean {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            // v2.4.3: same defensive probe as isAllFilesAccessGranted.
            if (runCatching { Environment.isExternalStorageManager() }.getOrDefault(false)) return false
            return openAllFilesAccessSettings(activity)
        }
        ActivityCompat.requestPermissions(
            activity,
            arrayOf(
                Manifest.permission.READ_EXTERNAL_STORAGE,
                Manifest.permission.WRITE_EXTERNAL_STORAGE,
            ),
            StoragePermissionRequestCode,
        )
        return true
    }

    /** Deep-links to this app's "All files access" toggle. */
    fun openAllFilesAccessSettings(activity: Activity): Boolean {
        val targeted = Intent(
            Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
            Uri.parse("package:${activity.packageName}"),
        )
        if (runCatching { activity.startActivity(targeted) }.isSuccess) return true
        val generic = Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION)
        return runCatching { activity.startActivity(generic) }.isSuccess
    }
}
