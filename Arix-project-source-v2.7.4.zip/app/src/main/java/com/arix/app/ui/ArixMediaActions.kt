package com.arix.app.ui

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.core.content.FileProvider
import com.arix.app.data.ArixMediaApi
import java.io.File
import java.io.InputStream
import java.io.OutputStream
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.Request

/**
 * v2.4.1 — shared download/share actions for media produced by the agent
 * (chat-rendered images, generated files in the Alpine workspace).
 *
 * Reuses the FileProvider cache path declared for the assistant
 * (assistant_local_open/) so no new manifest plumbing is needed.
 *
 * v2.6.1 — remote file responses (PDF/zip/image/… links in answers) get a
 * dedicated streaming path: downloads flow in bounded 64 KB chunks straight
 * into MediaStore / the share cache, so multi-megabyte files never sit fully
 * in memory (critical for low-RAM mid-range devices).
 */
object ArixMediaActions {

    /** v2.6.1: hard cap for streamed remote downloads (512 MB). */
    private const val MaxRemoteFileBytes = 512L * 1024L * 1024L

    private const val StreamCopyBufferBytes = 64 * 1024

    /**
     * Saves media bytes into the system Downloads collection via
     * [ArixMediaDownloads]; returns the resulting content uri. Runs blocking
     * IO — call from Dispatchers.IO.
     */
    fun downloadToDownloads(
        context: Context,
        fileName: String,
        mimeType: String,
        bytes: ByteArray,
    ): Uri = ArixMediaDownloads.saveToDownloads(context, fileName, mimeType, bytes)

    /**
     * v2.6.1: streams a remote file URL into the system Downloads collection
     * without buffering the whole body in memory. Returns the number of bytes
     * written. Runs blocking IO — call from Dispatchers.IO.
     */
    fun downloadUrlToDownloads(
        context: Context,
        url: String,
        fileName: String,
        mimeType: String,
    ): Long {
        val appContext = context.applicationContext
        val connection = openRemoteStream(url)
        connection.use { bodyStream ->
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.Q) {
                val values = android.content.ContentValues().apply {
                    put(android.provider.MediaStore.Downloads.DISPLAY_NAME, fileName)
                    put(android.provider.MediaStore.Downloads.MIME_TYPE, mimeType.ifBlank { "application/octet-stream" })
                    put(android.provider.MediaStore.Downloads.IS_PENDING, 1)
                }
                val resolver = appContext.contentResolver
                val collection = android.provider.MediaStore.Downloads.getContentUri(
                    android.provider.MediaStore.VOLUME_EXTERNAL_PRIMARY,
                )
                val itemUri = resolver.insert(collection, values)
                    ?: error("The download could not be created in the system Downloads store.")
                try {
                    val written = resolver.openOutputStream(itemUri)?.use { output ->
                        copyWithLimit(bodyStream, output)
                    } ?: error("The download file could not be written.")
                    values.clear()
                    values.put(android.provider.MediaStore.Downloads.IS_PENDING, 0)
                    resolver.update(itemUri, values, null, null)
                    return written
                } catch (throwable: Throwable) {
                    runCatching { resolver.delete(itemUri, null, null) }
                    error("The download failed: ${throwable.message}")
                }
            }
            @Suppress("DEPRECATION")
            val downloadsDirectory = android.os.Environment
                .getExternalStoragePublicDirectory(android.os.Environment.DIRECTORY_DOWNLOADS)
            downloadsDirectory.mkdirs()
            val targetFile = File(downloadsDirectory, fileName)
            targetFile.outputStream().use { output ->
                return copyWithLimit(bodyStream, output)
            }
        }
    }

    /**
     * v2.6.1: streams a remote file URL into the share cache so it can be
     * shared through the FileProvider. Returns the staged file. Runs blocking
     * IO — call from Dispatchers.IO.
     */
    suspend fun stageShareUrlFile(
        context: Context,
        url: String,
        fileName: String,
    ): File = withContext(Dispatchers.IO) {
        val appContext = context.applicationContext
        val shareDir = File(appContext.cacheDir, "assistant-local-open").apply { mkdirs() }
        // Keep the directory tiny: drop everything older than the new file.
        shareDir.listFiles()?.forEach { it.delete() }
        val safeName = fileName.replace(Regex("[^A-Za-z0-9._ ()-]"), "_").ifBlank { "arix-file" }
        val staged = File(shareDir, safeName)
        openRemoteStream(url).use { input ->
            staged.outputStream().use { output ->
                copyWithLimit(input, output)
            }
        }
        staged
    }

    /** v2.6.1: opens a remote file URL and returns its (already connected)
     *  response body stream. Caller MUST close it. */
    private fun openRemoteStream(url: String): InputStream {
        val request = Request.Builder()
            .url(url)
            .header("User-Agent", ArixMediaApi.BrowserUserAgent)
            .get()
            .build()
        val response = com.arix.app.data.ArixMediaApi.httpClient.newCall(request).execute()
        if (!response.isSuccessful) {
            response.close()
            error("Download failed (HTTP ${response.code})")
        }
        return response.body?.byteStream()
            ?: error("The server returned an empty file.")
    }

    private fun copyWithLimit(input: InputStream, output: OutputStream): Long {
        val buffer = ByteArray(StreamCopyBufferBytes)
        var total = 0L
        while (true) {
            val read = input.read(buffer)
            if (read < 0) break
            total += read
            if (total > MaxRemoteFileBytes) {
                error("The file is larger than 512 MB and cannot be downloaded.")
            }
            output.write(buffer, 0, read)
        }
        output.flush()
        return total
    }

    /**
     * Stages [bytes] into the shared cache directory (evicting older staged
     * files) so they can be shared through the FileProvider. Runs on IO.
     */
    suspend fun stageShareFile(
        context: Context,
        fileName: String,
        bytes: ByteArray,
    ): File = withContext(Dispatchers.IO) {
        val appContext = context.applicationContext
        val shareDir = File(appContext.cacheDir, "assistant-local-open").apply { mkdirs() }
        // Keep the directory tiny: drop everything older than the new file.
        shareDir.listFiles()?.forEach { it.delete() }
        val safeName = fileName.replace(Regex("[^A-Za-z0-9._ ()-]"), "_").ifBlank { "arix-file" }
        File(shareDir, safeName).apply { writeBytes(bytes) }
    }

    /**
     * Opens the system share sheet for a previously staged file. Must be
     * called from the main thread.
     */
    fun shareStagedFile(
        context: Context,
        file: File,
        mimeType: String,
    ): Boolean = runCatching {
        val appContext = context.applicationContext
        val uri = FileProvider.getUriForFile(
            appContext,
            "${appContext.packageName}.fileprovider",
            file,
        )
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = mimeType.ifBlank { "application/octet-stream" }
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        appContext.startActivity(
            Intent.createChooser(intent, file.name).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
        )
        true
    }.getOrDefault(false)

    /**
     * Convenience for small in-memory payloads: stages and shares in one
     * synchronous call (main thread; the cache write is tiny).
     */
    fun shareBytes(
        context: Context,
        fileName: String,
        mimeType: String,
        bytes: ByteArray,
    ): Boolean = runCatching {
        val appContext = context.applicationContext
        val shareDir = File(appContext.cacheDir, "assistant-local-open").apply { mkdirs() }
        shareDir.listFiles()?.forEach { it.delete() }
        val safeName = fileName.replace(Regex("[^A-Za-z0-9._ ()-]"), "_").ifBlank { "arix-file" }
        val shareFile = File(shareDir, safeName)
        shareFile.writeBytes(bytes)
        shareStagedFile(context, shareFile, mimeType)
    }.getOrDefault(false)

    /** Human-friendly byte size for file cards. */
    fun formatFileSize(bytes: Long): String {
        if (bytes <= 0) return ""
        val kb = bytes / 1024.0
        val mb = kb / 1024.0
        val gb = mb / 1024.0
        return when {
            gb >= 1 -> "%.2f GB".format(gb)
            mb >= 1 -> "%.1f MB".format(mb)
            kb >= 1 -> "%.0f KB".format(kb)
            else -> "$bytes B"
        }
    }
}
