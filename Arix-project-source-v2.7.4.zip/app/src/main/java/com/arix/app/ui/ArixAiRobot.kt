package com.arix.app.ui

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.drawscope.scale
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.PI
import kotlin.math.sin
import kotlin.random.Random

/**
 * v2.5.2: the home-screen hero — a large, friendly, futuristic AI assistant
 * robot drawn entirely with Compose Canvas (no raster assets: zero APK cost,
 * resolution independent, and every part is animated so it feels alive):
 *
 *  - glossy violet/blue robotic body with rim lights and specular highlights
 *  - dark black-glass face with glowing expressive eyes (pulse + blink +
 *    subtle look-around) and a voice equalizer bar
 *  - a small glowing antenna on the head with a radar ping
 *  - a glowing "A" emblem on the chest
 *  - gentle floating above a rotating holographic energy ring
 *  - soft neon particles drifting around the body
 */
@Composable
internal fun ArixAiAssistantRobot(
    modifier: Modifier = Modifier,
) {
    val textMeasurer = rememberTextMeasurer()
    val aGlyph = remember {
        textMeasurer.measure(
            text = "A",
            style = TextStyle(
                fontFamily = FontFamily.SansSerif,
                fontWeight = FontWeight.Bold,
                fontSize = 26.sp,
                letterSpacing = 0.sp,
            ),
        )
    }

    val transition = rememberInfiniteTransition(label = "arix_robot")
    val floatPhase by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(3600, easing = LinearEasing), RepeatMode.Reverse),
        label = "robot_float",
    )
    val breathe by transition.animateFloat(
        initialValue = 0.30f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(2600, easing = LinearEasing), RepeatMode.Reverse),
        label = "robot_breathe",
    )
    val eyePulse by transition.animateFloat(
        initialValue = 0.78f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(1700, easing = LinearEasing), RepeatMode.Reverse),
        label = "robot_eye_pulse",
    )
    val antennaGlow by transition.animateFloat(
        initialValue = 0.45f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(1300, easing = LinearEasing), RepeatMode.Reverse),
        label = "robot_antenna_glow",
    )
    val ringSweep by transition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(tween(7200, easing = LinearEasing), RepeatMode.Restart),
        label = "robot_ring_sweep",
    )
    val particlePhase by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(9200, easing = LinearEasing), RepeatMode.Restart),
        label = "robot_particles",
    )

    // Expressive blink: a quick eye-close every few seconds.
    var blink by remember { mutableStateOf(1f) }
    LaunchedEffect(Unit) {
        val random = Random(7)
        while (true) {
            kotlinx.coroutines.delay(3200L + random.nextLong(2600L))
            blink = 0.08f
            kotlinx.coroutines.delay(110L)
            blink = 1f
        }
    }

    val particles = remember { buildRobotParticles() }

    Box(modifier = modifier, contentAlignment = Alignment.Center) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val artScale = minOf(
                size.width / 260.dp.toPx(),
                size.height / 330.dp.toPx(),
            ).coerceAtLeast(0.35f)
            val bob = sin(floatPhase * PI).toFloat()
            val bobOffset = (-7.dp.toPx()) + 14.dp.toPx() * bob
            val lookX = 3.2f * sin(floatPhase * 2f * PI.toFloat())

            // Art space: (0,0) is the robot center, units are dp-based.
            translate(left = size.width / 2f, top = size.height / 2f) {
                scale(scale = artScale, pivot = Offset.Zero) {
                    drawRobotArt(
                        aGlyphWidth = aGlyph.size.width.toFloat(),
                        aGlyphHeight = aGlyph.size.height.toFloat(),
                        bobOffset = bobOffset,
                        bob = bob,
                        breathe = breathe,
                        eyePulse = eyePulse,
                        antennaGlow = antennaGlow,
                        ringSweep = ringSweep,
                        particlePhase = particlePhase,
                        blink = blink,
                        lookX = lookX,
                        particles = particles,
                    ) { aTopLeft, aColor, aAlpha, aBlur ->
                        drawText(
                            textLayoutResult = aGlyph,
                            color = aColor,
                            topLeft = aTopLeft,
                            alpha = aAlpha,
                            shadow = Shadow(
                                color = Color(0xFF8F6BFF).copy(alpha = 0.85f),
                                blurRadius = aBlur,
                            ),
                        )
                    }
                }
            }
        }
    }
}

/** Neon particle spec around the robot (fixed seed → stable layout). */
private data class RobotParticle(
    val side: Int,
    val xFrac: Float,
    val yDp: Float,
    val driftDp: Float,
    val sizeDp: Float,
    val color: Color,
    val phase: Float,
    val front: Boolean,
    val wobble: Float,
)

private fun buildRobotParticles(): List<RobotParticle> {
    val random = Random(42)
    val colors = listOf(
        Color(0xFFB79CFF),
        Color(0xFF8FBCFF),
        Color(0xFFFFFFFF),
        Color(0xFF9D6BFF),
        Color(0xFF7AA2F7),
    )
    return List(16) { index ->
        RobotParticle(
            side = if (index % 2 == 0) -1 else 1,
            xFrac = 0.42f + random.nextFloat() * 0.55f,
            yDp = -150f + random.nextFloat() * 210f,
            driftDp = 34f + random.nextFloat() * 46f,
            sizeDp = 1.6f + random.nextFloat() * 2.4f,
            color = colors[index % colors.size],
            phase = random.nextFloat(),
            front = index % 3 == 0,
            wobble = random.nextFloat() * (2f * PI.toFloat()),
        )
    }
}

private val RobotBodyLight = Color(0xFFEDE6FF)
private val RobotBodyMid = Color(0xFFA78BFA)
private val RobotBodyDeep = Color(0xFF6D47E0)
private val RobotBodyShadow = Color(0xFF4A2FA8)
private val RobotRimBlue = Color(0xFF8FD0FF)
private val RobotGlassTop = Color(0xFF0B0B14)
private val RobotGlassBottom = Color(0xFF191527)
private val RobotEyeGlowBlue = Color(0xFF6BB8FF)
private val RobotEyeCore = Color(0xFFF2F7FF)
private val RobotOrbCore = Color(0xFFFFFFFF)
private val RobotOrbGlow = Color(0xFF9D7BFF)
private val RobotRingViolet = Color(0xFFA78BFA)
private val RobotRingBlue = Color(0xFF7AA2F7)
private val RobotRingWhite = Color(0xFFDDE9FF)
private val RobotGlyph = Color(0xFFE8F4FF)

private fun DrawScope.drawRobotArt(
    aGlyphWidth: Float,
    aGlyphHeight: Float,
    bobOffset: Float,
    bob: Float,
    breathe: Float,
    eyePulse: Float,
    antennaGlow: Float,
    ringSweep: Float,
    particlePhase: Float,
    blink: Float,
    lookX: Float,
    particles: List<RobotParticle>,
    drawAGlyph: DrawScope.(Offset, Color, Float, Float) -> Unit,
) {
    fun dp(value: Float): Float = value.dp.toPx()
    fun offset(x: Float, y: Float): Offset = Offset(dp(x), dp(y))

    val ringCenter = offset(0f, 98f)

    /* ── ambient aura ─────────────────────────────────────────────────── */
    val auraRadius = dp(150f) * (0.92f + 0.08f * breathe)
    val auraCenter = offset(0f, -10f)
    drawCircle(
        brush = Brush.radialGradient(
            colors = listOf(
                Color(0xFF8B5CF6).copy(alpha = 0.20f * breathe + 0.05f),
                Color(0xFF7AA2F7).copy(alpha = 0.10f * breathe),
                Color.Transparent,
            ),
            center = auraCenter,
            radius = auraRadius,
        ),
        radius = auraRadius,
        center = auraCenter,
    )
    val headAuraCenter = offset(0f, -40f)
    drawCircle(
        brush = Brush.radialGradient(
            colors = listOf(
                Color(0xFFB79CFF).copy(alpha = 0.12f * breathe),
                Color.Transparent,
            ),
            center = headAuraCenter,
            radius = dp(110f),
        ),
        radius = dp(110f),
        center = headAuraCenter,
    )

    /* ── particles behind the robot ───────────────────────────────────── */
    drawParticles(particles, onlyFront = false, phase = particlePhase, breathe = breathe, dp = ::dp)

    /* ── holographic ring under the robot ─────────────────────────────── */
    drawHoloRing(
        center = ringCenter,
        rx = dp(104f) * (1f + 0.035f * bob),
        ry = dp(16f) * (1f + 0.035f * bob),
        sweep = ringSweep,
        breathe = breathe,
        dp = ::dp,
    )

    /* ── the robot (floats above the ring) ────────────────────────────── */
    translate(top = bobOffset) {
        drawAntenna(glow = antennaGlow, breathe = breathe, dp = ::dp)
        drawEars(dp = ::dp)
        drawNeck(dp = ::dp)
        drawArms(dp = ::dp)
        drawHead(dp = ::dp)
        drawFace(eyePulse = eyePulse, blink = blink, lookX = lookX, dp = ::dp)
        drawBody(dp = ::dp)
        drawChestEmblem(
            aGlyphWidth = aGlyphWidth,
            aGlyphHeight = aGlyphHeight,
            breathe = breathe,
            drawAGlyph = drawAGlyph,
            dp = ::dp,
        )
    }

    /* ── particles in front of the robot ──────────────────────────────── */
    drawParticles(particles, onlyFront = true, phase = particlePhase, breathe = breathe, dp = ::dp)
}

/* ── parts ─────────────────────────────────────────────────────────────── */

private fun DrawScope.drawHead(dp: (Float) -> Float) {
    val left = dp(-74f)
    val top = dp(-150f)
    val width = dp(148f)
    val height = dp(100f)
    val corner = CornerRadius(dp(50f), dp(50f))

    drawRoundRect(
        brush = Brush.verticalGradient(
            colors = listOf(RobotBodyLight, RobotBodyMid, RobotBodyDeep),
            startY = top,
            endY = top + height,
        ),
        topLeft = Offset(left, top),
        size = Size(width, height),
        cornerRadius = corner,
    )
    // Left rim light (blue).
    drawRoundRect(
        brush = Brush.horizontalGradient(
            colors = listOf(RobotRimBlue.copy(alpha = 0.65f), Color.Transparent),
            startX = left,
            endX = left + width * 0.45f,
        ),
        topLeft = Offset(left, top),
        size = Size(width, height),
        cornerRadius = corner,
    )
    // Top sheen.
    drawRoundRect(
        brush = Brush.verticalGradient(
            colors = listOf(Color.White.copy(alpha = 0.55f), Color.Transparent),
            startY = top,
            endY = top + height * 0.38f,
        ),
        topLeft = Offset(left + dp(6f), top + dp(4f)),
        size = Size(width - dp(12f), height * 0.5f),
        cornerRadius = CornerRadius(dp(46f), dp(46f)),
    )
    // Specular hotspot (upper-left, tilted).
    rotate(degrees = -16f, pivot = Offset(left + width * 0.32f, top + height * 0.28f)) {
        drawOval(
            brush = Brush.radialGradient(
                colors = listOf(Color.White.copy(alpha = 0.42f), Color.Transparent),
                center = Offset(left + width * 0.32f, top + height * 0.28f),
                radius = dp(34f),
            ),
            topLeft = Offset(left + width * 0.32f - dp(24f), top + height * 0.28f - dp(9f)),
            size = Size(dp(48f), dp(18f)),
        )
    }
    // Hairline edge.
    drawRoundRect(
        color = Color(0x2EFFFFFF),
        topLeft = Offset(left, top),
        size = Size(width, height),
        cornerRadius = corner,
        style = Stroke(width = dp(1f)),
    )
}

private fun DrawScope.drawFace(
    eyePulse: Float,
    blink: Float,
    lookX: Float,
    dp: (Float) -> Float,
) {
    val left = dp(-58f)
    val top = dp(-140f)
    val width = dp(116f)
    val height = dp(74f)
    val corner = CornerRadius(dp(30f), dp(30f))

    // Black glass.
    drawRoundRect(
        brush = Brush.verticalGradient(
            colors = listOf(RobotGlassTop, RobotGlassBottom),
            startY = top,
            endY = top + height,
        ),
        topLeft = Offset(left, top),
        size = Size(width, height),
        cornerRadius = corner,
    )
    // Inner neon rim on the glass edge.
    drawRoundRect(
        brush = Brush.verticalGradient(
            colors = listOf(
                Color(0xFF8F6BFF).copy(alpha = 0.45f),
                Color(0xFF6BB8FF).copy(alpha = 0.22f),
            ),
            startY = top,
            endY = top + height,
        ),
        topLeft = Offset(left, top),
        size = Size(width, height),
        cornerRadius = corner,
        style = Stroke(width = dp(1.4f)),
    )
    // Glass reflection streak across the top.
    rotate(degrees = -8f, pivot = Offset(left + width * 0.5f, top + height * 0.22f)) {
        drawRoundRect(
            brush = Brush.horizontalGradient(
                colors = listOf(
                    Color.Transparent,
                    Color.White.copy(alpha = 0.10f),
                    Color.Transparent,
                ),
                startX = left,
                endX = left + width,
            ),
            topLeft = Offset(left + dp(10f), top + dp(4f)),
            size = Size(width - dp(20f), dp(16f)),
            cornerRadius = CornerRadius(dp(8f), dp(8f)),
        )
    }

    // ── glowing expressive eyes ──
    val eyeCenters = listOf(
        Offset(dp(-23f) + dp(lookX), dp(-103f)),
        Offset(dp(23f) + dp(lookX), dp(-103f)),
    )
    val eyeWidth = dp(24f)
    val eyeHeight = dp(18f) * blink
    val eyeCorner = CornerRadius(dp(9f), dp(9f))
    eyeCenters.forEach { center ->
        // Halo layers.
        repeat(3) { ring ->
            val expand = dp(4f + ring * 5f)
            drawRoundRect(
                brush = Brush.radialGradient(
                    colors = listOf(
                        Color(0xFF9D7BFF).copy(alpha = (0.28f - ring * 0.07f) * eyePulse * blink),
                        Color(0xFF6BB8FF).copy(alpha = (0.14f - ring * 0.04f) * eyePulse),
                        Color.Transparent,
                    ),
                    center = center,
                    radius = expand + dp(14f),
                ),
                topLeft = Offset(
                    center.x - eyeWidth / 2 - expand,
                    center.y - eyeHeight / 2 - expand * blink,
                ),
                size = Size(eyeWidth + expand * 2, eyeHeight + expand * 2),
                cornerRadius = CornerRadius(dp(12f), dp(12f)),
            )
        }
        // Core eye.
        drawRoundRect(
            brush = Brush.verticalGradient(
                colors = listOf(RobotEyeCore, RobotEyeGlowBlue),
                startY = center.y - eyeHeight / 2,
                endY = center.y + eyeHeight / 2,
            ),
            topLeft = Offset(center.x - eyeWidth / 2, center.y - eyeHeight / 2),
            size = Size(eyeWidth, eyeHeight),
            cornerRadius = eyeCorner,
        )
        // Bright center spark.
        if (blink > 0.5f) {
            drawRoundRect(
                color = Color.White,
                topLeft = Offset(center.x - eyeWidth * 0.18f, center.y - eyeHeight * 0.28f),
                size = Size(eyeWidth * 0.36f, eyeHeight * 0.5f),
                cornerRadius = CornerRadius(dp(4f), dp(4f)),
            )
        }
    }
    // Voice equalizer mouth bar (the "assistant is alive" cue).
    val mouthY = dp(-84f)
    val mouthWidth = dp(30f) * (0.7f + 0.3f * eyePulse)
    drawRoundRect(
        brush = Brush.horizontalGradient(
            colors = listOf(
                Color(0xFF8F6BFF).copy(alpha = 0.0f),
                Color(0xFFB79CFF).copy(alpha = 0.85f * eyePulse),
                Color(0xFF8FD0FF).copy(alpha = 0.0f),
            ),
            startX = dp(-15f),
            endX = dp(15f),
        ),
        topLeft = Offset(-mouthWidth / 2, mouthY - dp(1.6f)),
        size = Size(mouthWidth, dp(3.2f)),
        cornerRadius = CornerRadius(dp(1.6f), dp(1.6f)),
    )
}

private fun DrawScope.drawAntenna(
    glow: Float,
    breathe: Float,
    dp: (Float) -> Float,
) {
    // Halo behind the orb.
    val orbCenter = Offset(0f, dp(-183f))
    drawCircle(
        brush = Brush.radialGradient(
            colors = listOf(
                RobotOrbGlow.copy(alpha = 0.55f * glow),
                RobotOrbGlow.copy(alpha = 0.18f * glow),
                Color.Transparent,
            ),
            center = orbCenter,
            radius = dp(26f),
        ),
        radius = dp(26f),
        center = orbCenter,
    )
    // Stalk.
    drawRoundRect(
        brush = Brush.horizontalGradient(
            colors = listOf(RobotBodyLight, RobotBodyMid, RobotBodyShadow),
            startX = dp(-3f),
            endX = dp(3f),
        ),
        topLeft = Offset(dp(-2.6f), dp(-176f)),
        size = Size(dp(5.2f), dp(30f)),
        cornerRadius = CornerRadius(dp(2.6f), dp(2.6f)),
    )
    // Orb with white core.
    drawCircle(
        brush = Brush.radialGradient(
            colors = listOf(RobotOrbCore, RobotOrbGlow, Color(0xFF5B3FC4)),
            center = Offset(orbCenter.x - dp(2f), orbCenter.y - dp(2f)),
            radius = dp(10f),
        ),
        radius = dp(9f) * (0.92f + 0.08f * glow),
        center = orbCenter,
    )
    // Radar ping ring around the orb.
    drawCircle(
        color = RobotOrbGlow.copy(alpha = 0.35f * (1f - breathe)),
        radius = dp(12f) + dp(14f) * breathe,
        center = orbCenter,
        style = Stroke(width = dp(1.2f)),
    )
}

private fun DrawScope.drawEars(dp: (Float) -> Float) {
    listOf(-1, 1).forEach { side ->
        val leftX = dp(side * 74f - 9f)
        val top = dp(-129f)
        val width = dp(18f)
        val height = dp(58f)
        drawRoundRect(
            brush = Brush.verticalGradient(
                colors = listOf(RobotBodyMid, RobotBodyDeep, RobotBodyShadow),
                startY = top,
                endY = top + height,
            ),
            topLeft = Offset(leftX, top),
            size = Size(width, height),
            cornerRadius = CornerRadius(dp(9f), dp(9f)),
        )
        // Neon accent light on each pod.
        drawCircle(
            color = RobotRimBlue.copy(alpha = 0.9f),
            radius = dp(3.4f),
            center = Offset(dp(side * 74f), dp(-112f)),
        )
        drawCircle(
            color = RobotOrbGlow.copy(alpha = 0.4f),
            radius = dp(6.5f),
            center = Offset(dp(side * 74f), dp(-112f)),
        )
    }
}

private fun DrawScope.drawNeck(dp: (Float) -> Float) {
    drawRoundRect(
        brush = Brush.verticalGradient(
            colors = listOf(RobotBodyDeep, RobotBodyShadow),
            startY = dp(-56f),
            endY = dp(-38f),
        ),
        topLeft = Offset(dp(-15f), dp(-56f)),
        size = Size(dp(30f), dp(18f)),
        cornerRadius = CornerRadius(dp(7f), dp(7f)),
    )
}

private fun DrawScope.drawArms(dp: (Float) -> Float) {
    listOf(-1, 1).forEach { side ->
        val top = dp(-28f)
        val height = dp(64f)
        val width = dp(26f)
        val left = dp(side * 97f - 13f)
        drawRoundRect(
            brush = Brush.verticalGradient(
                colors = listOf(RobotBodyMid, RobotBodyDeep, RobotBodyShadow),
                startY = top,
                endY = top + height,
            ),
            topLeft = Offset(left, top),
            size = Size(width, height),
            cornerRadius = CornerRadius(dp(13f), dp(13f)),
        )
        // Fore-edge light.
        drawRoundRect(
            brush = Brush.horizontalGradient(
                colors = listOf(
                    if (side < 0) RobotRimBlue.copy(alpha = 0.55f) else Color.Transparent,
                    if (side < 0) Color.Transparent else RobotRimBlue.copy(alpha = 0.55f),
                ),
                startX = left,
                endX = left + width,
            ),
            topLeft = Offset(left, top),
            size = Size(width, height),
            cornerRadius = CornerRadius(dp(13f), dp(13f)),
        )
    }
}

private fun DrawScope.drawBody(dp: (Float) -> Float) {
    val left = dp(-68f)
    val top = dp(-42f)
    val width = dp(136f)
    val height = dp(112f)
    val corner = CornerRadius(dp(48f), dp(48f))

    drawRoundRect(
        brush = Brush.verticalGradient(
            colors = listOf(RobotBodyLight, RobotBodyMid, RobotBodyDeep, RobotBodyShadow),
            startY = top,
            endY = top + height,
        ),
        topLeft = Offset(left, top),
        size = Size(width, height),
        cornerRadius = corner,
    )
    // Rim lights.
    drawRoundRect(
        brush = Brush.horizontalGradient(
            colors = listOf(RobotRimBlue.copy(alpha = 0.50f), Color.Transparent),
            startX = left,
            endX = left + width * 0.40f,
        ),
        topLeft = Offset(left, top),
        size = Size(width, height),
        cornerRadius = corner,
    )
    drawRoundRect(
        brush = Brush.horizontalGradient(
            colors = listOf(Color.Transparent, Color(0xFFB79CFF).copy(alpha = 0.30f)),
            startX = left + width * 0.6f,
            endX = left + width,
        ),
        topLeft = Offset(left, top),
        size = Size(width, height),
        cornerRadius = corner,
    )
    // Top sheen.
    drawRoundRect(
        brush = Brush.verticalGradient(
            colors = listOf(Color.White.copy(alpha = 0.45f), Color.Transparent),
            startY = top,
            endY = top + height * 0.30f,
        ),
        topLeft = Offset(left + dp(10f), top + dp(6f)),
        size = Size(width - dp(20f), height * 0.34f),
        cornerRadius = CornerRadius(dp(42f), dp(42f)),
    )
    // Specular hotspot.
    rotate(degrees = -12f, pivot = Offset(left + width * 0.30f, top + height * 0.30f)) {
        drawOval(
            brush = Brush.radialGradient(
                colors = listOf(Color.White.copy(alpha = 0.38f), Color.Transparent),
                center = Offset(left + width * 0.30f, top + height * 0.30f),
                radius = dp(36f),
            ),
            topLeft = Offset(left + width * 0.30f - dp(26f), top + height * 0.30f - dp(11f)),
            size = Size(dp(52f), dp(22f)),
        )
    }
    // Panel seam.
    drawLine(
        brush = Brush.horizontalGradient(
            colors = listOf(Color.Transparent, Color.White.copy(alpha = 0.22f), Color.Transparent),
            startX = left + dp(10f),
            endX = left + width - dp(10f),
        ),
        start = Offset(left + dp(10f), top + height * 0.52f),
        end = Offset(left + width - dp(10f), top + height * 0.52f),
        strokeWidth = dp(1f),
    )
    // Hairline edge.
    drawRoundRect(
        color = Color(0x2EFFFFFF),
        topLeft = Offset(left, top),
        size = Size(width, height),
        cornerRadius = corner,
        style = Stroke(width = dp(1f)),
    )
}

private fun DrawScope.drawChestEmblem(
    aGlyphWidth: Float,
    aGlyphHeight: Float,
    breathe: Float,
    drawAGlyph: DrawScope.(Offset, Color, Float, Float) -> Unit,
    dp: (Float) -> Float,
) {
    val center = Offset(0f, dp(10f))
    val radius = dp(30f)

    // Glow halo behind the emblem.
    drawCircle(
        brush = Brush.radialGradient(
            colors = listOf(
                Color(0xFF9D7BFF).copy(alpha = 0.30f * breathe + 0.10f),
                Color.Transparent,
            ),
            center = center,
            radius = radius * 1.6f,
        ),
        radius = radius * 1.6f,
        center = center,
    )
    // Dark glass disc.
    drawCircle(
        brush = Brush.verticalGradient(
            colors = listOf(RobotGlassBottom, RobotGlassTop),
            startY = center.y - radius,
            endY = center.y + radius,
        ),
        radius = radius,
        center = center,
    )
    // Gradient ring.
    drawCircle(
        brush = Brush.sweepGradient(
            colors = listOf(
                RobotRingViolet,
                RobotRingBlue,
                RobotRingWhite,
                RobotRingViolet,
            ),
            center = center,
        ),
        radius = radius,
        center = center,
        style = Stroke(width = dp(2.4f)),
    )
    // The glowing "A" AI mark, centered and scaled to the emblem.
    val glyphScale = (radius * 1.1f) / aGlyphHeight.coerceAtLeast(1f)
    translate(left = center.x, top = center.y) {
        scale(scale = glyphScale, pivot = Offset.Zero) {
            val topLeft = Offset(-aGlyphWidth / 2f, -aGlyphHeight / 2f)
            drawAGlyph(topLeft, RobotGlyph, 1f, dp(9f) / glyphScale)
        }
    }
}

private fun DrawScope.drawHoloRing(
    center: Offset,
    rx: Float,
    ry: Float,
    sweep: Float,
    breathe: Float,
    dp: (Float) -> Float,
) {
    val ringRect = Rect(
        left = center.x - rx,
        top = center.y - ry,
        right = center.x + rx,
        bottom = center.y + ry,
    )
    // Soft under-glow.
    drawOval(
        brush = Brush.radialGradient(
            colors = listOf(
                Color(0xFFB79CFF).copy(alpha = 0.22f * breathe + 0.06f),
                Color(0xFF7AA2F7).copy(alpha = 0.10f * breathe),
                Color.Transparent,
            ),
            center = center,
            radius = rx,
        ),
        topLeft = ringRect.topLeft,
        size = ringRect.size,
    )
    // Base ring.
    drawArc(
        color = RobotRingViolet.copy(alpha = 0.30f),
        startAngle = 0f,
        sweepAngle = 360f,
        useCenter = false,
        topLeft = ringRect.topLeft,
        size = ringRect.size,
        style = Stroke(width = dp(3f), cap = StrokeCap.Round),
    )
    // Rotating energy sweep.
    drawArc(
        brush = Brush.sweepGradient(
            colors = listOf(
                RobotRingViolet.copy(alpha = 0.0f),
                RobotRingViolet.copy(alpha = 0.85f),
                RobotRingBlue.copy(alpha = 0.85f),
                RobotRingWhite.copy(alpha = 0.95f),
                RobotRingViolet.copy(alpha = 0.0f),
            ),
            center = center,
        ),
        startAngle = sweep,
        sweepAngle = 300f,
        useCenter = false,
        topLeft = ringRect.topLeft,
        size = ringRect.size,
        style = Stroke(width = dp(4f), cap = StrokeCap.Round),
    )
    // Bright comet head running the opposite way.
    drawArc(
        color = Color(0xFFEAF2FF).copy(alpha = 0.9f),
        startAngle = -sweep * 1.6f,
        sweepAngle = 52f,
        useCenter = false,
        topLeft = ringRect.topLeft,
        size = ringRect.size,
        style = Stroke(width = dp(4.5f), cap = StrokeCap.Round),
    )
    // Contact glow right under the floating robot.
    val contactRect = Rect(
        left = center.x - rx * 0.62f,
        top = center.y - ry * 0.9f,
        right = center.x + rx * 0.62f,
        bottom = center.y + ry * 0.9f,
    )
    drawArc(
        color = Color(0xFF8FD0FF).copy(alpha = 0.35f),
        startAngle = 196f,
        sweepAngle = 148f,
        useCenter = false,
        topLeft = contactRect.topLeft,
        size = contactRect.size,
        style = Stroke(width = dp(2f), cap = StrokeCap.Round),
    )
}

private fun DrawScope.drawParticles(
    particles: List<RobotParticle>,
    onlyFront: Boolean,
    phase: Float,
    breathe: Float,
    dp: (Float) -> Float,
) {
    particles.filter { it.front == onlyFront }.forEach { particle ->
        val tt = (phase + particle.phase) % 1f
        val alphaK = sin(tt * PI.toFloat())
        if (alphaK <= 0.01f) return@forEach
        val x = dp(particle.side * (26f + particle.xFrac * 74f)) +
            sin(tt * 2f * PI.toFloat() + particle.wobble) * dp(4f)
        val y = dp(particle.yDp) - dp(particle.driftDp) * tt
        val radius = dp(particle.sizeDp) * (0.55f + 0.45f * alphaK)
        drawCircle(
            color = particle.color.copy(alpha = alphaK * (0.35f + 0.65f * breathe)),
            radius = radius,
            center = Offset(x, y),
        )
        // Faint glow halo for the larger motes.
        if (particle.sizeDp > 2.6f) {
            drawCircle(
                color = particle.color.copy(alpha = alphaK * 0.18f * breathe),
                radius = radius * 2.4f,
                center = Offset(x, y),
            )
        }
    }
}
