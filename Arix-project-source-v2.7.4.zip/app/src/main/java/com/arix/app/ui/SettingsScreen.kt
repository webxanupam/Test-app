package com.arix.app.ui
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Image
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.relocation.BringIntoViewRequester
import androidx.compose.foundation.relocation.bringIntoViewRequester
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.automirrored.rounded.ArrowForwardIos
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Download
import androidx.compose.material.icons.rounded.Memory
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.UploadFile
import androidx.compose.material.icons.rounded.ArrowDropDown
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.Grid4x4
import androidx.compose.material.icons.rounded.SupportAgent
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Cloud
import androidx.compose.material.icons.rounded.Code
import androidx.compose.material.icons.rounded.DarkMode
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.Extension
import androidx.compose.material.icons.rounded.FileUpload
import androidx.compose.material.icons.rounded.Folder
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.Link
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Schedule
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Terminal
import androidx.compose.material.icons.rounded.Public
import androidx.compose.material.icons.rounded.WarningAmber
import androidx.compose.material.icons.rounded.WbSunny
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.saveable.rememberSaveableStateHolder
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import com.arix.app.BuildConfig

import com.arix.app.R
import java.util.Locale
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import kotlin.math.roundToInt
import com.arix.app.data.ArixAppExtensionError
import com.arix.app.data.AgentWorkspaceMode
import com.arix.app.data.AutomaticModelPurpose
import com.arix.app.data.ChatUsageStatisticsSnapshot
import com.arix.app.data.AppLanguage
import com.arix.app.data.AppThemeMode
import com.arix.app.data.LlmProviderConfig
import com.arix.app.data.PiProviderCatalog
import com.arix.app.data.ArixLocalModels
import com.arix.app.data.LocalRuntimeId
import com.arix.app.data.McpServerTestOperation
import com.arix.app.data.InstalledPiExtension
import com.arix.app.data.PiExtensionCatalogEntry
import com.arix.app.data.PiExtensionInstallKind
import com.arix.app.data.PiPackageCompatibilityIssue
import com.arix.app.data.PiPackageDetails
import com.arix.app.data.PackageProfileState
import com.arix.app.data.ProviderModelOption
import com.arix.app.data.ScheduledTask
import com.arix.app.data.ScheduledTaskCreator
import com.arix.app.data.ScheduledTaskSchedule
import com.arix.app.data.formatScheduledTaskTime
import com.arix.app.data.summary
import com.arix.app.data.availableModelOptions
import com.arix.app.data.availableModels
import com.arix.app.data.enabledModels
import com.arix.app.data.ProviderAuthMethod
import com.arix.app.data.pi.PiProviderAuthState
import com.arix.app.data.findModelOption
import com.arix.app.data.normalizeLlmInactivityReconnectTimeoutSeconds
import com.arix.app.data.normalizeOldCommandHistoryRetentionHours
import com.arix.app.data.normalizeTavilyBaseUrl
import com.arix.app.data.quickActionLabel
import com.arix.app.data.resolveAutomaticModelKey
import com.arix.app.data.sortedForAutomaticModelPurpose
import com.arix.app.mod.ArixNativeModState
import com.arix.app.runtime.LocalRuntimeIssue
import org.json.JSONArray
import org.json.JSONObject
import com.arix.app.runtime.LocalRuntimeSetupState
import com.arix.app.runtime.AlpineSetupActivity
import com.arix.app.runtime.AlpineSetupProgress
import com.arix.app.runtime.AlpineTerminalLaunchSpec
import com.arix.app.runtime.AndroidAlpineFileManagerRuntime
import com.arix.app.ui.theme.ArixOnSurface
import com.arix.app.ui.theme.ArixOnPrimary
import com.arix.app.ui.theme.ArixOnSurfaceVariant
import com.arix.app.ui.theme.ArixPrimary
import com.arix.app.ui.theme.ArixScrim
import com.arix.app.ui.theme.ArixSettingsBackground
import com.arix.app.ui.theme.ArixSurface
import com.arix.app.ui.theme.ArixSurfaceHigh
import com.arix.app.ui.theme.ArixSurfaceHigher
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

// -----------------------------------------------------------------------------
// Page enum - drives the local in-composable navigation
// -----------------------------------------------------------------------------

private enum class SettingsPage {
    Hub,
    Providers,
    DefaultModels,
    DefaultChatModel,
    DefaultTitleModel,
    DefaultNamingModel,
    DefaultCompactingModel,
    AddProvider,
    EditProvider,
    Personalization,
    WebTools,
    Reliability,
    ExtensionSettings,
    ExtensionSettingsCategory,
    Skills,
    AddSkill,
    Extensions,
    PackageDetail,
    McpServers,
    AddMcpServer,
    EditMcpServer,
    ScheduledTasks,
    AddScheduledTask,
    EditScheduledTask,
    Alpine,
    AlpineTerminal,
    AlpineFiles,
    AlpineChrome,
    RuntimeDefaults,
    Statistics,
    Storage,
    LocalModels,
    Developer,
    About,
}

private const val SettingsAutoRefreshIntervalMillis = 5_000L

private fun SettingsPage.depth(): Int = when (this) {
    SettingsPage.Hub -> 0
    SettingsPage.Providers,
    SettingsPage.Personalization,
    SettingsPage.WebTools,
    SettingsPage.Reliability,
    SettingsPage.ExtensionSettings,
    SettingsPage.Skills,
    SettingsPage.Extensions,
    SettingsPage.McpServers,
    SettingsPage.ScheduledTasks,
    SettingsPage.Alpine,
    SettingsPage.RuntimeDefaults,
    SettingsPage.Statistics,
    SettingsPage.Storage,
    SettingsPage.LocalModels,
    SettingsPage.Developer,
    SettingsPage.About -> 1
    SettingsPage.DefaultModels,
    SettingsPage.AddProvider,
    SettingsPage.EditProvider,
    SettingsPage.AddSkill,
    SettingsPage.PackageDetail,
    SettingsPage.AddMcpServer,
    SettingsPage.EditMcpServer,
    SettingsPage.AddScheduledTask,
    SettingsPage.EditScheduledTask,
    SettingsPage.AlpineTerminal,
    SettingsPage.AlpineFiles,
    SettingsPage.AlpineChrome,
    SettingsPage.ExtensionSettingsCategory -> 2
    SettingsPage.DefaultChatModel,
    SettingsPage.DefaultTitleModel,
    SettingsPage.DefaultNamingModel,
    SettingsPage.DefaultCompactingModel -> 3
}

private fun formatTaskMinute(minuteOfDay: Int): String {
    val normalized = minuteOfDay.coerceIn(0, 1_439)
    return "%02d:%02d".format(Locale.US, normalized / 60, normalized % 60)
}

private fun parseTaskMinute(value: String): Int? {
    val parts = value.trim().split(':')
    if (parts.size != 2) return null
    val hour = parts[0].toIntOrNull() ?: return null
    val minute = parts[1].toIntOrNull() ?: return null
    if (hour !in 0..23 || minute !in 0..59) return null
    return hour * 60 + minute
}

private fun parseTaskTimes(value: String): List<Int> =
    value.split(',', ';', '\n')
        .mapNotNull(::parseTaskMinute)
        .distinct()
        .sorted()

private fun parseTaskDays(value: String): List<Int> =
    value.split(',', ';', ' ')
        .mapNotNull { raw ->
            val normalized = raw.trim().lowercase(Locale.US)
            when (normalized.take(3)) {
                "mon" -> 1
                "tue" -> 2
                "wed" -> 3
                "thu" -> 4
                "fri" -> 5
                "sat" -> 6
                "sun" -> 7
                else -> normalized.toIntOrNull()
            }?.takeIf { it in 1..7 }
        }
        .distinct()
        .sorted()

// -----------------------------------------------------------------------------
// Animation constants
// -----------------------------------------------------------------------------

private const val PageTransitionDuration = 320
private val PageTransitionEasing = CubicBezierEasing(0.22f, 0.84f, 0.18f, 1f)
private val SettingsTopFadeHeight = 40.dp
private val StatisticsInputColor = Color(0xFF5D7CFF)
private val StatisticsOutputColor = Color(0xFF7B68EE)
private val StatisticsReasoningColor = Color(0xFFA9B8FF)
private val StatisticsNeutralChartColor = Color(0xFFDCE4FF)



@Composable
private fun settingsEnabledProvidersSummary(enabledCount: Int): String =
    stringResource(R.string.settings_enabled_providers_count, enabledCount)

@Composable
private fun settingsReleaseSummary(versionName: String): String =
    stringResource(R.string.settings_release_summary, versionName)

private fun settingsTopOverlayBodyGradient(): Brush = Brush.verticalGradient(
    colorStops = arrayOf(
        0.0f to ArixSettingsBackground.copy(alpha = 0.96f),
        0.18f to ArixSettingsBackground.copy(alpha = 0.86f),
        0.42f to ArixSettingsBackground.copy(alpha = 0.48f),
        0.72f to ArixSettingsBackground.copy(alpha = 0.22f),
        1.0f to ArixSettingsBackground.copy(alpha = 0.12f),
    )
)

private fun settingsTopOverlayTailGradient(): Brush = Brush.verticalGradient(
    colorStops = arrayOf(
        0.0f to ArixSettingsBackground.copy(alpha = 0.12f),
        0.42f to ArixSettingsBackground.copy(alpha = 0.05f),
        1.0f to Color.Transparent,
    )
)

// -----------------------------------------------------------------------------
// Root composable - drop-in replacement for the old SettingsScreen in ArixApp
// -----------------------------------------------------------------------------

@Composable
fun SettingsScreen(
    systemPrompt: String,
    tavilyApiKey: String,
    tavilyBaseUrl: String,
    llmInactivityReconnectTimeoutSeconds: Int,
    keepTasksRunningInBackground: Boolean,
    notifyOnTaskCompletion: Boolean,
    agentWorkspaceMode: AgentWorkspaceMode,
    autoCleanOldCommandHistory: Boolean,
    oldCommandHistoryRetentionHours: Int,
    language: AppLanguage,
    themeMode: AppThemeMode,
    defaultChatModelKey: String,
    defaultTitleModelKey: String,
    defaultNamingModelKey: String,
    defaultCompactingModelKey: String,
    providerConfigs: List<LlmProviderConfig>,
    usageStatisticsSnapshots: List<ChatUsageStatisticsSnapshot>,
    scheduledTasks: List<ScheduledTask>,
    alpineSetupState: LocalRuntimeSetupState,
    enabledRuntimeIds: Set<LocalRuntimeId>,
    defaultRuntimeId: LocalRuntimeId?,
    alpinePackageProfiles: Map<String, PackageProfileState>,
    alpinePackageInstallProgress: Map<String, AlpineSetupProgress>,
    alpineFileManagerRuntime: AndroidAlpineFileManagerRuntime,
    installedSkills: List<com.arix.app.data.InstalledSkill>,
    installedPiExtensions: List<InstalledPiExtension>,
    hasLoadedInstalledPiExtensions: Boolean,
    nativeModState: ArixNativeModState,
    piExtensionCatalog: List<PiExtensionCatalogEntry>,
    isLoadingPiExtensions: Boolean,
    piExtensionCatalogError: String,
    piExtensionOperationSource: String,
    selectedPiPackageDetails: PiPackageDetails?,
    selectedPiPackageSource: String,
    isLoadingPiPackageDetails: Boolean,
    piPackageDetailsError: String,
    mcpServers: List<com.arix.app.data.McpServerConfig>,
    isFetchingModels: Boolean,
    providerAuthState: PiProviderAuthState,
    onSave: (
        String,
        String,
        String,
        Int,
        Boolean,
        Boolean,
        AgentWorkspaceMode,
        Boolean,
        Int,
        AppLanguage,
        AppThemeMode,
        String,
        String,
        String,
        String,
    ) -> Unit,
    onUpsertProviderConfig: (LlmProviderConfig) -> Unit,
    onRemoveProviderConfig: (String) -> Unit,
    onSetProviderEnabled: (String, Boolean) -> Unit,
    onFetchModels: (LlmProviderConfig, (List<String>) -> Unit) -> Unit,
    onStartProviderLogin: (String, String, ProviderAuthMethod, String) -> Unit,
    onSubmitProviderAuthPrompt: (String, String, Boolean) -> Unit,
    onClearProviderAuthState: () -> Unit,
    onImportSkillFolder: () -> Unit,
    onImportSkillZip: ((Boolean) -> Unit) -> Unit,
    onInstallSkillUrl: (String, (Boolean) -> Unit) -> Unit,
    onToggleSkillEnabled: (String, Boolean) -> Unit,
    onRemoveSkill: (String) -> Unit,
    onReinstallBuiltInSkill: (String) -> Unit = {},
    onRefreshPiExtensions: () -> Unit,
    onInstallPiExtensionPackage: (String) -> Unit,
    onLoadPiPackageDetails: (PiExtensionCatalogEntry) -> Unit,
    onUpdatePiExtensionPackage: (String) -> Unit,
    onRemovePiExtension: (InstalledPiExtension) -> Unit,
    onSetPiExtensionEnabled: (InstalledPiExtension, Boolean) -> Unit,
    onImportPiExtension: () -> Unit,
    onAllowNativeModsOnNextStart: () -> Unit,
    onDisableNativeModsOnNextStart: () -> Unit,
    onSaveHttpMcpServer: (String?, String, String, String) -> Unit,
    onSaveStdIoMcpServer: (String?, String, String, String, String, String, LocalRuntimeId?) -> Unit,
    onToggleMcpServerEnabled: (String, Boolean) -> Unit,
    onRemoveMcpServer: (String) -> Unit,
    onTestMcpServer: (String, McpServerTestOperation, (String) -> Unit) -> Unit,
    onDetectMcpServer: (String?, String, String, String, (com.arix.app.data.McpServerDetection) -> Unit) -> Unit,
    mcpServerSnapshots: List<com.arix.app.data.McpServerSnapshot> = emptyList(),
    onSaveScheduledTask: (String?, String, String, ScheduledTaskSchedule, Boolean) -> Unit,
    onToggleScheduledTaskEnabled: (String, Boolean) -> Unit,
    onRemoveScheduledTask: (String) -> Unit,
    onImportAppData: () -> Unit,
    onExportAppData: () -> Unit,
    onExportLogs: () -> Unit,
    onInitializeAlpineRuntime: () -> Unit,
    onResetAlpineRuntime: () -> Unit,
    onRefreshAlpineSetup: () -> Unit,
    onInstallAlpinePackageProfile: (String) -> Unit,
    onCreateAlpineTerminalLaunchSpec: suspend () -> Result<AlpineTerminalLaunchSpec>,
    onStartAlpineChrome: suspend () -> Result<Unit>,
    onShouldShowAlpineChromeKeyboard: suspend (Int, Int) -> Result<Boolean>,
    onSetDefaultRuntime: (LocalRuntimeId) -> Unit,
    onOpenWebsite: () -> Unit,
    onOpenPrivacyPolicy: () -> Unit,
    onBack: () -> Unit,
) {
    val context = LocalContext.current
    // Mutable field values - survive recomposition & config changes
    var systemPromptValue by rememberSaveable(stateSaver = TextFieldValue.Saver) {
        mutableStateOf(TextFieldValue(systemPrompt))
    }
    var tavilyApiKeyValue by rememberSaveable(stateSaver = TextFieldValue.Saver) {
        mutableStateOf(TextFieldValue(tavilyApiKey))
    }
    var tavilyBaseUrlValue by rememberSaveable(stateSaver = TextFieldValue.Saver) {
        mutableStateOf(TextFieldValue(tavilyBaseUrl))
    }
    var llmInactivityReconnectTimeoutValue by rememberSaveable(stateSaver = TextFieldValue.Saver) {
        mutableStateOf(TextFieldValue(llmInactivityReconnectTimeoutSeconds.toString()))
    }
    var keepTasksRunningInBackgroundValue by rememberSaveable {
        mutableStateOf(keepTasksRunningInBackground)
    }
    var notifyOnTaskCompletionValue by rememberSaveable {
        mutableStateOf(notifyOnTaskCompletion)
    }
    var agentWorkspaceModeValue by rememberSaveable {
        mutableStateOf(agentWorkspaceMode)
    }
    var autoCleanOldCommandHistoryValue by rememberSaveable {
        mutableStateOf(autoCleanOldCommandHistory)
    }
    var oldCommandHistoryRetentionHoursValue by rememberSaveable(stateSaver = TextFieldValue.Saver) {
        mutableStateOf(TextFieldValue(oldCommandHistoryRetentionHours.toString()))
    }
    var languageValue by rememberSaveable {
        mutableStateOf(language)
    }
    var themeModeValue by rememberSaveable {
        mutableStateOf(themeMode)
    }
    LaunchedEffect(
        autoCleanOldCommandHistory,
        oldCommandHistoryRetentionHours,
    ) {
        autoCleanOldCommandHistoryValue = autoCleanOldCommandHistory
        oldCommandHistoryRetentionHoursValue = TextFieldValue(oldCommandHistoryRetentionHours.toString())
    }
    LaunchedEffect(language) {
        languageValue = language
    }
    var defaultChatModelKeyValue by rememberSaveable { mutableStateOf(defaultChatModelKey) }
    var defaultTitleModelKeyValue by rememberSaveable { mutableStateOf(defaultTitleModelKey) }
    var defaultNamingModelKeyValue by rememberSaveable { mutableStateOf(defaultNamingModelKey) }
    var defaultCompactingModelKeyValue by rememberSaveable { mutableStateOf(defaultCompactingModelKey) }

    val enabledModelOptions = remember(providerConfigs) { providerConfigs.availableModelOptions() }

    // Track which provider is being edited
    var editingProviderId by rememberSaveable { mutableStateOf<String?>(null) }
    var editingMcpServerId by rememberSaveable { mutableStateOf<String?>(null) }
    var editingScheduledTaskId by rememberSaveable { mutableStateOf<String?>(null) }
    fun persistSettings() {
        onSave(
            systemPromptValue.text,
            tavilyApiKeyValue.text,
            normalizeTavilyBaseUrl(tavilyBaseUrlValue.text),
            normalizeLlmInactivityReconnectTimeoutSeconds(
                llmInactivityReconnectTimeoutValue.text.trim().toIntOrNull()
            ),
            keepTasksRunningInBackgroundValue,
            notifyOnTaskCompletionValue,
            agentWorkspaceModeValue,
            autoCleanOldCommandHistoryValue,
            normalizeOldCommandHistoryRetentionHours(
                oldCommandHistoryRetentionHoursValue.text.trim().toIntOrNull()
            ),
            languageValue,
            themeModeValue,
            defaultChatModelKeyValue,
            defaultTitleModelKeyValue,
            defaultNamingModelKeyValue,
            defaultCompactingModelKeyValue,
        )
    }

    fun persistAndExit() {
        persistSettings()
        onBack()
    }

    LifecycleEventEffect(Lifecycle.Event.ON_STOP) {
        persistSettings()
    }

    // Local page navigation
    var currentPage by rememberSaveable { mutableStateOf(SettingsPage.Hub.name) }
    val page = SettingsPage.valueOf(currentPage)
    var selectedPiPackageSourceValue by rememberSaveable { mutableStateOf("") }
    var selectedExtensionSettingsId by rememberSaveable { mutableStateOf("") }
    var selectedExtensionSettingsCategoryId by rememberSaveable { mutableStateOf("") }
    val extensionSettings = LocalArixExtensionUiController.current
        ?.snapshot
        ?.settings
        .orEmpty()

    // Determine parent page for back navigation
    fun parentPage(): SettingsPage = when (page) {
        SettingsPage.DefaultModels -> SettingsPage.Providers
        SettingsPage.DefaultChatModel,
        SettingsPage.DefaultTitleModel,
        SettingsPage.DefaultNamingModel,
        SettingsPage.DefaultCompactingModel -> SettingsPage.DefaultModels
        SettingsPage.AddProvider, SettingsPage.EditProvider -> SettingsPage.Providers
        SettingsPage.AddSkill -> SettingsPage.Skills
        SettingsPage.PackageDetail -> SettingsPage.Extensions
        SettingsPage.ExtensionSettings -> SettingsPage.Hub
        SettingsPage.ExtensionSettingsCategory -> SettingsPage.ExtensionSettings
        SettingsPage.AddMcpServer, SettingsPage.EditMcpServer -> SettingsPage.McpServers
        SettingsPage.AddScheduledTask, SettingsPage.EditScheduledTask -> SettingsPage.ScheduledTasks
        SettingsPage.AlpineTerminal,
        SettingsPage.AlpineFiles,
        SettingsPage.AlpineChrome -> SettingsPage.Alpine
        else -> SettingsPage.Hub
    }

    BackHandler {
        when (page) {
            SettingsPage.Hub -> persistAndExit()
            else -> currentPage = parentPage().name
        }
    }

    val pageStateHolder = rememberSaveableStateHolder()
    AnimatedContent(
        targetState = page,
        transitionSpec = {
            val isForward = targetState.depth() > initialState.depth()
            val enterSlide = slideInHorizontally(
                animationSpec = tween(PageTransitionDuration, easing = PageTransitionEasing),
                initialOffsetX = { if (isForward) it / 3 else -it / 3 },
            ) + fadeIn(tween(PageTransitionDuration, easing = PageTransitionEasing))
            val exitSlide = slideOutHorizontally(
                animationSpec = tween(PageTransitionDuration, easing = PageTransitionEasing),
                targetOffsetX = { if (isForward) -it / 3 else it / 3 },
            ) + fadeOut(tween(PageTransitionDuration, easing = PageTransitionEasing))
            enterSlide togetherWith exitSlide
        },
        label = "settings_page_transition",
    ) { targetPage ->
        pageStateHolder.SaveableStateProvider(targetPage.name) {
            when (targetPage) {
            SettingsPage.Hub -> SettingsHub(
                activeProviderName = providerConfigs.count { it.isEnabled }.let { enabledCount ->
                    when {
                        enabledCount > 1 -> settingsEnabledProvidersSummary(enabledCount)
                        enabledCount == 1 -> providerConfigs.firstOrNull { it.isEnabled }?.name.orEmpty()
                        enabledModelOptions.isNotEmpty() -> enabledModelOptions.first().fullLabel
                        else -> stringResource(R.string.settings_no_providers_configured)
                    }
                },
                systemPromptSnippet = systemPromptValue.text.take(60),
                tavilyConfigured = tavilyApiKeyValue.text.isNotBlank(),
                reliabilitySummary = buildString {
                    append(
                        stringResource(
                            R.string.settings_reconnect_after_seconds,
                            normalizeLlmInactivityReconnectTimeoutSeconds(
                                llmInactivityReconnectTimeoutValue.text.trim().toIntOrNull()
                            ),
                        )
                    )
                    append(" · ")
                    append(
                        stringResource(
                            if (keepTasksRunningInBackgroundValue) {
                                R.string.settings_background_runs_on
                            } else {
                                R.string.settings_background_runs_off
                            },
                        )
                    )
                },
                alpineReady = alpineSetupState.isReady,
                defaultRuntimeId = defaultRuntimeId,
                showRuntimeDefaults = alpineSetupState.isReady,
                skillCount = installedSkills.size,
                piExtensionCount = installedPiExtensions.size,
                piExtensionsLoaded = hasLoadedInstalledPiExtensions,
                extensionSettings = extensionSettings,
                onOpenExtensionSettings = { id ->
                    selectedExtensionSettingsId = id
                    selectedExtensionSettingsCategoryId = ""
                    currentPage = SettingsPage.ExtensionSettings.name
                },
                mcpServerCount = mcpServers.size,
                scheduledTaskCount = scheduledTasks.size,
                statisticsSummary = buildSettingsStatisticsSummary(usageStatisticsSnapshots),
                onNavigate = { page ->
                    currentPage = page.name
                },
                onBack = ::persistAndExit,
            )

            SettingsPage.Providers -> ProvidersListPage(
                providerConfigs = providerConfigs,
                onSetProviderEnabled = onSetProviderEnabled,
                onOpenDefaultModels = { currentPage = SettingsPage.DefaultModels.name },
                onEdit = { id ->
                    editingProviderId = id
                    currentPage = SettingsPage.EditProvider.name
                },
                onRemove = onRemoveProviderConfig,
                onAddNew = { currentPage = SettingsPage.AddProvider.name },
                onOpenLocalModels = { currentPage = SettingsPage.LocalModels.name },
                onBack = { currentPage = SettingsPage.Hub.name },
            )

            SettingsPage.DefaultModels -> DefaultModelsPage(
                modelOptions = enabledModelOptions,
                defaultChatModelKey = defaultChatModelKeyValue,
                defaultTitleModelKey = defaultTitleModelKeyValue,
                defaultNamingModelKey = defaultNamingModelKeyValue,
                defaultCompactingModelKey = defaultCompactingModelKeyValue,
                onOpenDefaultChatModel = { currentPage = SettingsPage.DefaultChatModel.name },
                onOpenDefaultTitleModel = { currentPage = SettingsPage.DefaultTitleModel.name },
                onOpenDefaultNamingModel = { currentPage = SettingsPage.DefaultNamingModel.name },
                onOpenDefaultCompactingModel = { currentPage = SettingsPage.DefaultCompactingModel.name },
                onBack = { currentPage = SettingsPage.Providers.name },
            )

            SettingsPage.DefaultChatModel -> ModelSelectionListPage(
                title = stringResource(R.string.settings_default_chat_model),
                subtitle = stringResource(R.string.settings_default_chat_model_subtitle),
                selectedKey = defaultChatModelKeyValue,
                options = enabledModelOptions,
                purpose = AutomaticModelPurpose.Chat,
                automaticLabel = enabledModelOptions.findModelOption(
                    enabledModelOptions.resolveAutomaticModelKey(AutomaticModelPurpose.Chat)
                )?.fullLabel?.let { stringResource(R.string.settings_automatic_model_with_name, it) }
                    ?: stringResource(R.string.settings_automatic_model),
                automaticSubtitle = stringResource(R.string.settings_prioritize_sota_models),
                onSelected = {
                    defaultChatModelKeyValue = it
                    persistSettings()
                },
                onBack = { currentPage = SettingsPage.DefaultModels.name },
            )

            SettingsPage.DefaultTitleModel -> ModelSelectionListPage(
                title = stringResource(R.string.settings_default_title_model),
                subtitle = stringResource(R.string.settings_default_title_model_subtitle),
                selectedKey = defaultTitleModelKeyValue,
                options = enabledModelOptions,
                purpose = AutomaticModelPurpose.Title,
                automaticLabel = enabledModelOptions.findModelOption(
                    enabledModelOptions.resolveAutomaticModelKey(AutomaticModelPurpose.Title)
                        .ifBlank { enabledModelOptions.resolveAutomaticModelKey(AutomaticModelPurpose.Chat) }
                )?.fullLabel?.let { stringResource(R.string.settings_automatic_model_with_name, it) }
                    ?: stringResource(R.string.settings_automatic_model),
                automaticSubtitle = stringResource(R.string.settings_prioritize_sota_models),
                onSelected = {
                    defaultTitleModelKeyValue = it
                    persistSettings()
                },
                onBack = { currentPage = SettingsPage.DefaultModels.name },
            )

            SettingsPage.DefaultNamingModel -> ModelSelectionListPage(
                title = stringResource(R.string.settings_default_naming_model),
                subtitle = stringResource(R.string.settings_default_naming_model_subtitle),
                selectedKey = defaultNamingModelKeyValue,
                options = enabledModelOptions,
                purpose = AutomaticModelPurpose.Naming,
                automaticLabel = enabledModelOptions.findModelOption(
                    enabledModelOptions.resolveAutomaticModelKey(AutomaticModelPurpose.Naming)
                        .ifBlank { enabledModelOptions.resolveAutomaticModelKey(AutomaticModelPurpose.Chat) }
                )?.fullLabel?.let { stringResource(R.string.settings_automatic_model_with_name, it) }
                    ?: stringResource(R.string.settings_automatic_model),
                automaticSubtitle = stringResource(R.string.settings_prioritize_sota_models),
                onSelected = {
                    defaultNamingModelKeyValue = it
                    persistSettings()
                },
                onBack = { currentPage = SettingsPage.DefaultModels.name },
            )

            SettingsPage.DefaultCompactingModel -> ModelSelectionListPage(
                title = stringResource(R.string.settings_default_compacting_model),
                subtitle = stringResource(R.string.settings_default_compacting_model_subtitle),
                selectedKey = defaultCompactingModelKeyValue,
                options = enabledModelOptions,
                purpose = AutomaticModelPurpose.Compacting,
                automaticLabel = enabledModelOptions.findModelOption(
                    enabledModelOptions.resolveAutomaticModelKey(AutomaticModelPurpose.Compacting)
                        .ifBlank { enabledModelOptions.resolveAutomaticModelKey(AutomaticModelPurpose.Chat) }
                )?.fullLabel?.let { stringResource(R.string.settings_automatic_model_with_name, it) }
                    ?: stringResource(R.string.settings_automatic_model),
                automaticSubtitle = stringResource(R.string.settings_prioritize_efficient_summary_models),
                onSelected = {
                    defaultCompactingModelKeyValue = it
                    persistSettings()
                },
                onBack = { currentPage = SettingsPage.DefaultModels.name },
            )

            SettingsPage.AddProvider -> ProviderEditPage(
                existingConfig = null,
                existingProviderIds = providerConfigs.map { it.providerId }.toSet(),
                isFetchingModels = isFetchingModels,
                onSave = { config ->
                    onUpsertProviderConfig(config)
                    currentPage = SettingsPage.Providers.name
                },
                onModelEnabledChange = {},
                onFetchModels = onFetchModels,
                authState = providerAuthState,
                onStartProviderLogin = onStartProviderLogin,
                onSubmitAuthPrompt = onSubmitProviderAuthPrompt,
                onClearAuthState = onClearProviderAuthState,
                onBack = { currentPage = SettingsPage.Providers.name },
            )

            SettingsPage.EditProvider -> {
                val configToEdit = providerConfigs.firstOrNull { it.id == editingProviderId }
                ProviderEditPage(
                    existingConfig = configToEdit,
                    existingProviderIds = providerConfigs.map { it.providerId }.toSet(),
                    isFetchingModels = isFetchingModels,
                    onSave = { config ->
                        onUpsertProviderConfig(config)
                        currentPage = SettingsPage.Providers.name
                    },
                    onModelEnabledChange = onUpsertProviderConfig,
                    onFetchModels = onFetchModels,
                    authState = providerAuthState,
                    onStartProviderLogin = onStartProviderLogin,
                    onSubmitAuthPrompt = onSubmitProviderAuthPrompt,
                    onClearAuthState = onClearProviderAuthState,
                    onBack = { currentPage = SettingsPage.Providers.name },
                )
            }

            SettingsPage.Personalization -> PersonalizationPage(
                title = stringResource(R.string.settings_personalization),
                systemPromptValue = systemPromptValue,
                onSystemPromptChanged = { systemPromptValue = it },
                onBack = { currentPage = SettingsPage.Hub.name },
            )

            SettingsPage.WebTools -> WebToolsPage(
                title = stringResource(R.string.settings_web_tools),
                tavilyApiKeyValue = tavilyApiKeyValue,
                onTavilyApiKeyChanged = { tavilyApiKeyValue = it },
                tavilyBaseUrlValue = tavilyBaseUrlValue,
                onTavilyBaseUrlChanged = { tavilyBaseUrlValue = it },
                onBack = { currentPage = SettingsPage.Hub.name },
            )

            SettingsPage.Reliability -> ReliabilityPage(
                title = stringResource(R.string.settings_reliability),
                llmInactivityReconnectTimeoutValue = llmInactivityReconnectTimeoutValue,
                onLlmInactivityReconnectTimeoutChanged = { llmInactivityReconnectTimeoutValue = it },
                keepTasksRunningInBackground = keepTasksRunningInBackgroundValue,
                onKeepTasksRunningInBackgroundChanged = { keepTasksRunningInBackgroundValue = it },
                notifyOnTaskCompletion = notifyOnTaskCompletionValue,
                onNotifyOnTaskCompletionChanged = { notifyOnTaskCompletionValue = it },
                onBack = { currentPage = SettingsPage.Hub.name },
            )
            SettingsPage.ExtensionSettings -> {
                val selected = extensionSettings.firstOrNull { it.id == selectedExtensionSettingsId }
                if (selected == null) {
                    currentPage = SettingsPage.Hub.name
                } else if (selected.categories.isNotEmpty()) {
                    ArixExtensionSettingsCategoriesPage(
                        page = selected,
                        onCategorySelected = { categoryId ->
                            selectedExtensionSettingsCategoryId = categoryId
                            currentPage = SettingsPage.ExtensionSettingsCategory.name
                        },
                        onBack = { currentPage = SettingsPage.Hub.name },
                    )
                } else {
                    ArixExtensionSettingsPage(
                        page = selected,
                        category = null,
                        onBack = { currentPage = SettingsPage.Hub.name },
                    )
                }
            }

            SettingsPage.ExtensionSettingsCategory -> {
                val selectedPage = extensionSettings.firstOrNull { it.id == selectedExtensionSettingsId }
                val selectedCategory = selectedPage?.categories?.firstOrNull { it.id == selectedExtensionSettingsCategoryId }
                if (selectedPage == null || selectedCategory == null) {
                    currentPage = SettingsPage.ExtensionSettings.name
                } else {
                    ArixExtensionSettingsPage(
                        page = selectedPage,
                        category = selectedCategory,
                        onCategorySelected = { categoryId ->
                            selectedExtensionSettingsCategoryId = categoryId
                            currentPage = SettingsPage.ExtensionSettingsCategory.name
                        },
                        onBack = { currentPage = SettingsPage.ExtensionSettings.name },
                    )
                }
            }

            SettingsPage.Skills -> SkillsListPage(
                title = stringResource(R.string.settings_agent_skills),
                installedSkills = installedSkills,
                onToggleSkillEnabled = onToggleSkillEnabled,
                onRemoveSkill = onRemoveSkill,
                onAddNew = { currentPage = SettingsPage.AddSkill.name },
                onReinstallBuiltIn = onReinstallBuiltInSkill,
                onBack = { currentPage = SettingsPage.Hub.name },
            )

            SettingsPage.AddSkill -> AddSkillPage(
                title = stringResource(R.string.settings_agent_skills),
                onImportSkillFolder = onImportSkillFolder,
                onImportSkillZip = { callback ->
                    onImportSkillZip { success ->
                        callback(success)
                        if (success) currentPage = SettingsPage.Skills.name
                    }
                },
                onInstallSkillUrl = { url, callback ->
                    onInstallSkillUrl(url) { success ->
                        callback(success)
                        if (success) currentPage = SettingsPage.Skills.name
                    }
                },
                onBack = { currentPage = SettingsPage.Skills.name },
            )

            SettingsPage.Extensions -> PiExtensionsPage(
                installedExtensions = installedPiExtensions,
                hasLoadedInstalledExtensions = hasLoadedInstalledPiExtensions,
                nativeModState = nativeModState,
                catalog = piExtensionCatalog,
                isLoading = isLoadingPiExtensions,
                catalogError = piExtensionCatalogError,
                operationSource = piExtensionOperationSource,
                onRefresh = onRefreshPiExtensions,
                onUpdate = onUpdatePiExtensionPackage,
                onRemove = onRemovePiExtension,
                onSetEnabled = onSetPiExtensionEnabled,
                onImport = onImportPiExtension,
                onAllowNativeModsOnNextStart = onAllowNativeModsOnNextStart,
                onDisableNativeModsOnNextStart = onDisableNativeModsOnNextStart,
                onSelectPackage = { entry ->
                    selectedPiPackageSourceValue = entry.source
                    onLoadPiPackageDetails(entry)
                    currentPage = SettingsPage.PackageDetail.name
                },
                onBack = { currentPage = SettingsPage.Hub.name },
            )

            SettingsPage.PackageDetail -> {
                val entry = piExtensionCatalog.firstOrNull {
                    it.source == selectedPiPackageSourceValue
                }
                if (entry == null) {
                    LaunchedEffect(Unit) {
                        currentPage = SettingsPage.Extensions.name
                    }
                } else {
                    LaunchedEffect(entry.source) {
                        if (
                            selectedPiPackageSource != entry.source ||
                            (
                                selectedPiPackageDetails == null &&
                                    !isLoadingPiPackageDetails &&
                                    piPackageDetailsError.isBlank()
                                )
                        ) {
                            onLoadPiPackageDetails(entry)
                        }
                    }
                    PiPackageDetailPage(
                        entry = entry,
                        details = selectedPiPackageDetails
                            ?.takeIf { selectedPiPackageSource == entry.source },
                        installed = installedPiExtensions.any {
                            it.kind == PiExtensionInstallKind.Package && it.source == entry.source
                        },
                        isLoading = isLoadingPiPackageDetails,
                        error = piPackageDetailsError,
                        isOperating = piExtensionOperationSource == entry.source,
                        onRetry = { onLoadPiPackageDetails(entry) },
                        onInstall = { onInstallPiExtensionPackage(entry.source) },
                        onBack = { currentPage = SettingsPage.Extensions.name },
                    )
                }
            }

            SettingsPage.McpServers -> McpServersListPage(
                title = stringResource(R.string.settings_mcp_servers),
                mcpServers = mcpServers,
                mcpServerSnapshots = mcpServerSnapshots,
                onToggleMcpServerEnabled = onToggleMcpServerEnabled,
                onRemoveMcpServer = onRemoveMcpServer,
                onTestMcpServer = onTestMcpServer,
                onEdit = { serverId ->
                    editingMcpServerId = serverId
                    currentPage = SettingsPage.EditMcpServer.name
                },
                onAddNew = { currentPage = SettingsPage.AddMcpServer.name },
                onBack = { currentPage = SettingsPage.Hub.name },
            )

            SettingsPage.AddMcpServer -> AddMcpServerPage(
                title = stringResource(R.string.settings_mcp_servers),
                existingServer = null,
                onDetectMcpServer = onDetectMcpServer,
                onSaveHttpMcpServer = { serverId, name, url, headers ->
                    onSaveHttpMcpServer(serverId, name, url, headers)
                    currentPage = SettingsPage.McpServers.name
                },
                onSaveStdIoMcpServer = { serverId, name, cmd, args, wd, env, runtimeEnvironment ->
                    onSaveStdIoMcpServer(serverId, name, cmd, args, wd, env, runtimeEnvironment)
                    currentPage = SettingsPage.McpServers.name
                },
                onBack = { currentPage = SettingsPage.McpServers.name },
            )

            SettingsPage.EditMcpServer -> AddMcpServerPage(
                title = stringResource(R.string.settings_mcp_servers),
                existingServer = mcpServers.firstOrNull { it.id == editingMcpServerId },
                onDetectMcpServer = onDetectMcpServer,
                onSaveHttpMcpServer = { serverId, name, url, headers ->
                    onSaveHttpMcpServer(serverId, name, url, headers)
                    currentPage = SettingsPage.McpServers.name
                },
                onSaveStdIoMcpServer = { serverId, name, cmd, args, wd, env, runtimeEnvironment ->
                    onSaveStdIoMcpServer(serverId, name, cmd, args, wd, env, runtimeEnvironment)
                    currentPage = SettingsPage.McpServers.name
                },
                onBack = { currentPage = SettingsPage.McpServers.name },
            )

            SettingsPage.ScheduledTasks -> ScheduledTasksPage(
                tasks = scheduledTasks,
                onToggleEnabled = onToggleScheduledTaskEnabled,
                onRemove = onRemoveScheduledTask,
                onEdit = { taskId ->
                    editingScheduledTaskId = taskId
                    currentPage = SettingsPage.EditScheduledTask.name
                },
                onAddNew = { currentPage = SettingsPage.AddScheduledTask.name },
                onBack = { currentPage = SettingsPage.Hub.name },
            )

            SettingsPage.AddScheduledTask -> ScheduledTaskEditPage(
                existingTask = null,
                onSave = { name, prompt, schedule, enabled ->
                    onSaveScheduledTask(null, name, prompt, schedule, enabled)
                    currentPage = SettingsPage.ScheduledTasks.name
                },
                onBack = { currentPage = SettingsPage.ScheduledTasks.name },
            )

            SettingsPage.EditScheduledTask -> ScheduledTaskEditPage(
                existingTask = scheduledTasks.firstOrNull { it.id == editingScheduledTaskId },
                onSave = { name, prompt, schedule, enabled ->
                    onSaveScheduledTask(editingScheduledTaskId, name, prompt, schedule, enabled)
                    currentPage = SettingsPage.ScheduledTasks.name
                },
                onBack = { currentPage = SettingsPage.ScheduledTasks.name },
            )

            SettingsPage.Alpine -> AlpineSettingsPage(
                title = "Alpine",
                setupState = alpineSetupState,
                packageProfiles = alpinePackageProfiles,
                installProgress = alpinePackageInstallProgress,
                isDefaultRuntime = defaultRuntimeId == LocalRuntimeId.Alpine,
                onInitialize = onInitializeAlpineRuntime,
                onReset = onResetAlpineRuntime,
                onRefresh = onRefreshAlpineSetup,
                onInstallPackageProfile = onInstallAlpinePackageProfile,
                onSetDefault = { onSetDefaultRuntime(LocalRuntimeId.Alpine) },
                onOpenTerminal = { currentPage = SettingsPage.AlpineTerminal.name },
                onOpenFiles = { currentPage = SettingsPage.AlpineFiles.name },
                onOpenChrome = { currentPage = SettingsPage.AlpineChrome.name },
                onBack = { currentPage = SettingsPage.Hub.name },
            )

            SettingsPage.AlpineTerminal -> AlpineTerminalScreen(
                createLaunchSpec = onCreateAlpineTerminalLaunchSpec,
                onBack = { currentPage = SettingsPage.Alpine.name },
            )

            SettingsPage.AlpineFiles -> {
                AndroidAlpineFileManagerScreen(
                    runtime = alpineFileManagerRuntime,
                    onBack = { currentPage = SettingsPage.Alpine.name },
                )
            }

            SettingsPage.AlpineChrome -> AlpineChromeScreen(
                onStart = onStartAlpineChrome,
                onShouldShowKeyboard = onShouldShowAlpineChromeKeyboard,
                onBack = { currentPage = SettingsPage.Alpine.name },
            )

            SettingsPage.RuntimeDefaults -> RuntimeDefaultsPage(
                title = stringResource(R.string.settings_runtime_defaults),
                alpineReady = alpineSetupState.isReady,
                enabledRuntimeIds = enabledRuntimeIds,
                defaultRuntimeId = defaultRuntimeId,
                onSetDefaultRuntime = onSetDefaultRuntime,
                onBack = { currentPage = SettingsPage.Hub.name },
            )

            SettingsPage.Statistics -> StatisticsSettingsPage(
                title = stringResource(R.string.settings_statistics),
                usageStatisticsSnapshots = usageStatisticsSnapshots,
                onBack = { currentPage = SettingsPage.Hub.name },
            )

            SettingsPage.Storage -> StorageSettingsPage(
                title = stringResource(R.string.settings_storage),
                onResetAlpineRuntime = onResetAlpineRuntime,
                onBack = { currentPage = SettingsPage.Hub.name },
            )

            SettingsPage.LocalModels -> LocalModelsSettingsPage(
                title = stringResource(R.string.settings_local_models),
                onBack = { currentPage = SettingsPage.Hub.name },
            )

            SettingsPage.Developer -> DeveloperSettingsPage(
                title = stringResource(R.string.settings_developer),
                onImportAppData = onImportAppData,
                onExportAppData = onExportAppData,
                onExportLogs = onExportLogs,
                developerRoleFallbackProviders = providerConfigs.filter {
                    it.developerRoleUnsupported
                },
                onClearDeveloperRoleFallback = { configId ->
                    providerConfigs.firstOrNull { it.id == configId }?.let { config ->
                        onUpsertProviderConfig(
                            config.copy(developerRoleUnsupported = false),
                        )
                    }
                },
                autoCleanOldCommandHistory = autoCleanOldCommandHistoryValue,
                oldCommandHistoryRetentionHours = oldCommandHistoryRetentionHoursValue,
                onAutoCleanOldCommandHistoryChanged = { autoCleanOldCommandHistoryValue = it },
                onOldCommandHistoryRetentionHoursChanged = { oldCommandHistoryRetentionHoursValue = it },
                onBack = { currentPage = SettingsPage.Hub.name },
            )

            SettingsPage.About -> AboutPage(
                title = stringResource(R.string.settings_about),
                onOpenWebsite = onOpenWebsite,
                onOpenPrivacyPolicy = onOpenPrivacyPolicy,
                onBack = { currentPage = SettingsPage.Hub.name },
            )
            }
        }
    }
}

// -----------------------------------------------------------------------------
// Hub
// -----------------------------------------------------------------------------

@Composable
private fun SettingsHub(
    activeProviderName: String,
    systemPromptSnippet: String,
    tavilyConfigured: Boolean,
    reliabilitySummary: String,
    alpineReady: Boolean,
    defaultRuntimeId: LocalRuntimeId?,
    showRuntimeDefaults: Boolean,
    skillCount: Int,
    piExtensionCount: Int,
    piExtensionsLoaded: Boolean,
    extensionSettings: List<com.arix.app.data.ArixAppExtensionSettingsPage>,
    onOpenExtensionSettings: (String) -> Unit,
    mcpServerCount: Int,
    scheduledTaskCount: Int,
    statisticsSummary: String,
    onNavigate: (SettingsPage) -> Unit,
    onBack: () -> Unit,
) {
    var topBarBodyHeightPx by remember { mutableIntStateOf(0) }
    val density = LocalDensity.current
    val fallbackTopBarBodyHeight = with(density) {
        WindowInsets.statusBars.getTop(this).toDp() + 68.dp
    }
    val topBarBodyHeight = with(density) {
        if (topBarBodyHeightPx > 0) topBarBodyHeightPx.toDp() else fallbackTopBarBodyHeight
    }
    Scaffold(
        modifier = Modifier.fillMaxSize(),
        containerColor = ArixSettingsBackground,
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(top = topBarBodyHeight)
                    .padding(horizontal = 20.dp)
                    .imePadding()
                    .navigationBarsPadding(),
            ) {
                Spacer(Modifier.height(6.dp))
                ArixExtensionSlot(ArixExtensionSlotSettingsHub)
                if (
                    LocalArixExtensionUiController.current
                        ?.snapshot
                        ?.surfacesAt(ArixExtensionSlotSettingsHub)
                        .orEmpty()
                        .isNotEmpty()
                ) {
                    Spacer(Modifier.height(16.dp))
                }

                Spacer(Modifier.height(16.dp))

            // Configuration card
            SettingsCardGroup {
                SettingsNavRow(
                    icon = Icons.Rounded.Cloud,
                    title = stringResource(R.string.settings_model_providers),
                    subtitle = activeProviderName,
                    onClick = { onNavigate(SettingsPage.Providers) },
                )
                CardDivider()
                SettingsNavRow(
                    icon = Icons.Rounded.Person,
                    title = stringResource(R.string.settings_personalization),
                    subtitle = systemPromptSnippet.ifBlank { stringResource(R.string.settings_custom_instructions) },
                    onClick = { onNavigate(SettingsPage.Personalization) },
                )
                CardDivider()
                SettingsNavRow(
                    icon = Icons.Rounded.Refresh,
                    title = stringResource(R.string.settings_reliability),
                    subtitle = reliabilitySummary,
                    onClick = { onNavigate(SettingsPage.Reliability) },
                )
            }

            if (extensionSettings.isNotEmpty()) {
                Spacer(Modifier.height(16.dp))
                SettingsCardGroup {
                    extensionSettings.forEachIndexed { index, settingPage ->
                        if (index > 0) CardDivider()
                        SettingsNavRow(
                            icon = extensionIcon(settingPage.icon),
                            title = settingPage.title,
                            subtitle = settingPage.subtitle.ifBlank { settingPage.extensionName },
                            onClick = { onOpenExtensionSettings(settingPage.id) },
                        )
                    }
                }
            }

            Spacer(Modifier.height(16.dp))

            // Extensions card
            SettingsCardGroup {
                SettingsNavRow(
                    icon = Icons.Rounded.Extension,
                    title = stringResource(R.string.settings_agent_skills),
                    subtitle = stringResource(R.string.settings_skills_count_configured, skillCount),
                    onClick = { onNavigate(SettingsPage.Skills) },
                )
                CardDivider()
                SettingsNavRow(
                    iconPainter = painterResource(R.drawable.pi_logo_on_light),
                    title = stringResource(R.string.settings_pi_extensions),
                    subtitle = if (piExtensionsLoaded) {
                        stringResource(
                            R.string.settings_pi_extensions_count_configured,
                            piExtensionCount,
                        )
                    } else {
                        stringResource(R.string.settings_loading_installed_extensions)
                    },
                    onClick = { onNavigate(SettingsPage.Extensions) },
                )
                CardDivider()
                SettingsNavRow(
                    icon = Icons.Rounded.Schedule,
                    title = stringResource(R.string.settings_scheduled_tasks),
                    subtitle = stringResource(R.string.settings_scheduled_tasks_count_configured, scheduledTaskCount),
                    onClick = { onNavigate(SettingsPage.ScheduledTasks) },
                )
                CardDivider()
                SettingsNavRow(
                    icon = Icons.Rounded.Code,
                    title = "Alpine",
                    subtitle = if (alpineReady) { stringResource(R.string.settings_alpine_subtitle_ready) } else { stringResource(R.string.settings_alpine_subtitle_setup) },
                    onClick = { onNavigate(SettingsPage.Alpine) },
                )
                if (showRuntimeDefaults) {
                    CardDivider()
                    SettingsNavRow(
                        icon = Icons.Rounded.Check,
                        title = stringResource(R.string.settings_runtime_defaults),
                        subtitle = defaultRuntimeId?.displayName ?: stringResource(R.string.settings_runtime_defaults_hint),
                        onClick = { onNavigate(SettingsPage.RuntimeDefaults) },
                    )
                }
            }

            Spacer(Modifier.height(16.dp))

            SettingsCardGroup {
                SettingsNavRow(
                    icon = LucideIcons.ChartNoAxesColumn,
                    title = stringResource(R.string.settings_statistics),
                    subtitle = statisticsSummary.ifBlank { stringResource(R.string.settings_statistics_empty) },
                    onClick = { onNavigate(SettingsPage.Statistics) },
                )
                CardDivider()
                SettingsNavRow(
                    icon = Icons.Rounded.DeleteOutline,
                    title = stringResource(R.string.settings_storage),
                    subtitle = stringResource(R.string.settings_storage_hint),
                    onClick = { onNavigate(SettingsPage.Storage) },
                )
            }

            Spacer(Modifier.height(16.dp))

            // About card
            SettingsCardGroup {
                SettingsNavRow(
                    icon = Icons.Rounded.Code,
                    title = stringResource(R.string.settings_developer),
                    subtitle = stringResource(R.string.settings_developer_subtitle),
                    onClick = { onNavigate(SettingsPage.Developer) },
                )
            }

            Spacer(Modifier.height(16.dp))

            SettingsCardGroup {
                SettingsNavRow(
                    icon = Icons.Rounded.Info,
                    title = stringResource(R.string.settings_about),
                    subtitle = settingsReleaseSummary(BuildConfig.VERSION_NAME),
                    onClick = { onNavigate(SettingsPage.About) },
                )
            }

            Spacer(Modifier.height(32.dp))
            }

            SettingsTopBarOverlay(
                modifier = Modifier.align(Alignment.TopCenter),
                title = stringResource(R.string.settings_title),
                onBack = onBack,
                onBodyHeightChanged = { topBarBodyHeightPx = it },
            )
        }
    }
}

// -----------------------------------------------------------------------------
// Statistics
// -----------------------------------------------------------------------------

@Composable
private fun StatisticsSettingsPage(
    title: String,
    usageStatisticsSnapshots: List<ChatUsageStatisticsSnapshot>,
    onBack: () -> Unit,
) {
    val report = remember(usageStatisticsSnapshots) { buildUsageStatisticsReport(usageStatisticsSnapshots) }
    SubPageScaffold(title = title, onBack = onBack) {
        SettingsCardGroup {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp),
            ) {
                Text(
                    text = stringResource(R.string.statistics_overview),
                    style = MaterialTheme.typography.titleMedium,
                    color = ArixOnSurface,
                )
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    StatisticsMetricTile(
                        label = stringResource(R.string.statistics_total_tokens),
                        value = formatSettingsTokenCount(report.totalTokens),
                        modifier = Modifier.weight(1f),
                    )
                    StatisticsMetricTile(
                        label = stringResource(R.string.statistics_sessions),
                        value = report.sessionCount.toString(),
                        modifier = Modifier.weight(1f),
                    )
                }
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    StatisticsMetricTile(
                        label = stringResource(R.string.statistics_average_speed),
                        value = report.averageOutputTokensPerSecond?.let(::formatSettingsTokenRate)
                            ?: stringResource(R.string.statistics_unavailable),
                        modifier = Modifier.weight(1f),
                    )
                    StatisticsMetricTile(
                        label = stringResource(R.string.statistics_average_latency),
                        value = report.averageFirstTokenLatencyMillis?.let(::formatSettingsDuration)
                            ?: stringResource(R.string.statistics_unavailable),
                        modifier = Modifier.weight(1f),
                    )
                }
            }
        }

        Spacer(Modifier.height(16.dp))

        SettingsCardGroup {
            StatisticsChartSection(
                title = stringResource(R.string.statistics_daily_token_usage),
                subtitle = stringResource(R.string.statistics_recent_7_days),
            ) {
                TokenBarChart(points = report.dailyTokenUsage.takeLast(7))
            }
        }

        Spacer(Modifier.height(16.dp))

        SettingsCardGroup {
            StatisticsChartSection(
                title = stringResource(R.string.statistics_recent_token_usage),
                subtitle = stringResource(R.string.statistics_recent_14_days),
            ) {
                TokenLineChart(points = report.dailyTokenUsage.takeLast(14))
            }
        }

        Spacer(Modifier.height(16.dp))

        SettingsCardGroup {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp),
            ) {
                Text(
                    text = stringResource(R.string.statistics_historical_token_usage),
                    style = MaterialTheme.typography.titleMedium,
                    color = ArixOnSurface,
                )
                HistoryPeakRow(
                    label = stringResource(R.string.statistics_peak_day),
                    value = report.peakDay?.let { "${it.label} · ${formatSettingsTokenCount(it.tokens)}" }
                        ?: stringResource(R.string.statistics_unavailable),
                )
                HistoryPeakRow(
                    label = stringResource(R.string.statistics_largest_turn),
                    value = report.largestTurnTokens?.let(::formatSettingsTokenCount)
                        ?: stringResource(R.string.statistics_unavailable),
                )
                HistoryPeakRow(
                    label = stringResource(R.string.statistics_recorded_turns),
                    value = report.turnCount.toString(),
                )
            }
        }

        Spacer(Modifier.height(16.dp))

        SettingsCardGroup {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp),
            ) {
                Text(
                    text = stringResource(R.string.statistics_token_mix),
                    style = MaterialTheme.typography.titleMedium,
                    color = ArixOnSurface,
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(26.dp),
                ) {
                    TokenMixPieChart(
                        inputTokens = report.inputTokens,
                        outputTokens = report.outputTokens,
                        reasoningTokens = report.reasoningTokens,
                        modifier = Modifier.size(112.dp),
                    )
                    Column(
                        modifier = Modifier
                            .weight(1f)
                            .padding(start = 4.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        TokenMixLegend(stringResource(R.string.statistics_input), StatisticsInputColor, report.inputTokens)
                        TokenMixLegend(stringResource(R.string.statistics_output), StatisticsOutputColor, report.outputTokens)
                        TokenMixLegend(stringResource(R.string.statistics_reasoning), StatisticsReasoningColor, report.reasoningTokens)
                    }
                }
            }
        }

        Spacer(Modifier.height(16.dp))

        SettingsCardGroup {
            StatisticsChartSection(
                title = stringResource(R.string.statistics_speed),
                subtitle = stringResource(R.string.statistics_speed_subtitle),
            ) {
                SpeedBarChart(points = report.recentSpeedSamples.takeLast(12))
            }
        }
    }
}

@Composable
private fun StatisticsMetricTile(
    label: String,
    value: String,
    modifier: Modifier = Modifier,
) {
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(18.dp))
            .background(ArixSurfaceHigh)
            .padding(horizontal = 12.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(4.dp),
    ) {
        Text(
            text = value,
            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.SemiBold),
            color = ArixOnSurface,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
        )
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            color = ArixOnSurfaceVariant,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
        )
    }
}

@Composable
private fun StatisticsChartSection(
    title: String,
    subtitle: String,
    chart: @Composable () -> Unit,
) {
    Column(
        modifier = Modifier.padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Text(
            text = title,
            style = MaterialTheme.typography.titleMedium,
            color = ArixOnSurface,
        )
        Text(
            text = subtitle,
            style = MaterialTheme.typography.bodySmall,
            color = ArixOnSurfaceVariant,
        )
        chart()
    }
}

@Composable
private fun TokenBarChart(points: List<DailyTokenUsage>) {
    val maxTokens = points.maxOfOrNull { it.tokens }?.coerceAtLeast(1L) ?: 1L
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .height(164.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = Alignment.Bottom,
    ) {
        points.forEach { point ->
            val fraction = point.tokens.toFloat() / maxTokens
            Column(
                modifier = Modifier.weight(1f),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Bottom,
            ) {
                Text(
                    text = formatSettingsTokenCount(point.tokens),
                    style = MaterialTheme.typography.labelSmall,
                    color = ArixOnSurfaceVariant,
                    maxLines = 1,
                )
                Spacer(Modifier.height(6.dp))
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height((18 + 96 * fraction).dp)
                        .clip(RoundedCornerShape(topStart = 10.dp, topEnd = 10.dp, bottomStart = 6.dp, bottomEnd = 6.dp))
                        .background(ArixPrimary.copy(alpha = 0.18f + 0.44f * fraction)),
                )
                Spacer(Modifier.height(6.dp))
                Text(
                    text = point.shortLabel,
                    style = MaterialTheme.typography.labelSmall,
                    color = ArixOnSurfaceVariant,
                    maxLines = 1,
                )
            }
        }
    }
}

@Composable
private fun TokenLineChart(points: List<DailyTokenUsage>) {
    var selectedIndex by remember(points) { mutableStateOf<Int?>(null) }
    val selectedPoint = selectedIndex?.let(points::getOrNull)
    val lineColor = StatisticsInputColor
    val fillColor = StatisticsInputColor.copy(alpha = 0.12f)
    val labelColor = ArixOnSurfaceVariant
    val maxTokens = points.maxOfOrNull { it.tokens }?.coerceAtLeast(1L) ?: 1L
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        BoxWithConstraints(
            modifier = Modifier
                .fillMaxWidth()
                .height(150.dp)
                .clip(RoundedCornerShape(18.dp))
                .background(ArixSurfaceHigh)
                .pointerInput(points) {
                    detectTapGestures { offset ->
                        if (points.isEmpty()) return@detectTapGestures
                        val horizontalPadding = 24f
                        val chartWidth = (size.width - horizontalPadding * 2f).coerceAtLeast(1f)
                        val progress = ((offset.x - horizontalPadding) / chartWidth).coerceIn(0f, 1f)
                        selectedIndex = (progress * (points.size - 1)).roundToInt().coerceIn(0, points.lastIndex)
                    }
                },
        ) {
            val chartPadding = 12.dp
            val chartHeight = 126.dp
            val chartWidth = maxWidth - chartPadding * 2
            Canvas(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(12.dp),
            ) {
                if (points.isEmpty()) return@Canvas
                val step = if (points.size <= 1) 0f else size.width / (points.size - 1)
                val coordinates = points.mapIndexed { index, point ->
                    val x = if (points.size <= 1) size.width / 2f else step * index
                    val y = size.height - (point.tokens.toFloat() / maxTokens) * size.height
                    androidx.compose.ui.geometry.Offset(x, y)
                }
                for (index in 0 until coordinates.lastIndex) {
                    drawLine(
                        color = lineColor,
                        start = coordinates[index],
                        end = coordinates[index + 1],
                        strokeWidth = 5f,
                        cap = StrokeCap.Round,
                    )
                }
                coordinates.forEachIndexed { index, point ->
                    val selected = selectedIndex == index
                    drawCircle(color = fillColor, radius = if (selected) 17f else 12f, center = point)
                    drawCircle(color = if (selected) StatisticsOutputColor else lineColor, radius = if (selected) 7f else 5f, center = point)
                }
            }
            selectedPoint?.let { point ->
                val selectedX = if (points.size <= 1) {
                    maxWidth / 2
                } else {
                    chartPadding + chartWidth * (selectedIndex!!.toFloat() / points.lastIndex)
                }
                val selectedY = chartPadding + chartHeight * (1f - point.tokens.toFloat() / maxTokens)
                val tooltipWidth = 116.dp
                val tooltipX = (selectedX - tooltipWidth / 2)
                    .coerceIn(4.dp, (maxWidth - tooltipWidth - 4.dp).coerceAtLeast(4.dp))
                val tooltipY = (selectedY - 34.dp).coerceAtLeast(4.dp)
                Box(
                    modifier = Modifier
                        .offset(x = tooltipX, y = tooltipY)
                        .width(tooltipWidth)
                        .clip(RoundedCornerShape(10.dp))
                        .background(ArixSurface.copy(alpha = 0.96f))
                        .padding(horizontal = 8.dp, vertical = 6.dp),
                    contentAlignment = Alignment.Center,
                ) {
                    Text(
                        text = stringResource(
                            R.string.statistics_selected_day_tokens,
                            point.label,
                            formatSettingsTokenCount(point.tokens),
                        ),
                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Medium),
                        color = ArixOnSurface,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
            }
        }
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
        ) {
            points.firstOrNull()?.let {
                Text(it.shortLabel, style = MaterialTheme.typography.labelSmall, color = labelColor)
            }
            points.lastOrNull()?.let {
                Text(it.shortLabel, style = MaterialTheme.typography.labelSmall, color = labelColor)
            }
        }
    }
}

@Composable
private fun TokenMixPieChart(
    inputTokens: Long,
    outputTokens: Long,
    reasoningTokens: Long,
    modifier: Modifier = Modifier,
) {
    val values = listOf(inputTokens, outputTokens, reasoningTokens)
    val colors = listOf(StatisticsInputColor, StatisticsOutputColor, StatisticsReasoningColor)
    val total = values.sum()
    Canvas(modifier = modifier) {
        if (total <= 0L) {
            drawArc(
                color = StatisticsNeutralChartColor,
                startAngle = -90f,
                sweepAngle = 360f,
                useCenter = false,
                style = Stroke(width = size.minDimension * 0.20f, cap = StrokeCap.Butt),
            )
            return@Canvas
        }
        var startAngle = -90f
        values.forEachIndexed { index, value ->
            if (value <= 0L) return@forEachIndexed
            val sweep = 360f * value / total
            drawArc(
                color = colors[index],
                startAngle = startAngle,
                sweepAngle = sweep,
                useCenter = false,
                style = Stroke(width = size.minDimension * 0.20f, cap = StrokeCap.Butt),
            )
            startAngle += sweep
        }
    }
}

@Composable
private fun SpeedBarChart(points: List<SpeedSample>) {
    val visiblePoints = points.takeLast(7)
    if (visiblePoints.isEmpty()) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(132.dp)
                .clip(RoundedCornerShape(18.dp))
                .background(ArixSurfaceHigh),
            contentAlignment = Alignment.Center,
        ) {
            Text(
                text = stringResource(R.string.statistics_no_speed_samples),
                style = MaterialTheme.typography.bodyMedium,
                color = ArixOnSurfaceVariant,
            )
        }
        return
    }
    val maxSpeed = visiblePoints.maxOfOrNull { it.tokensPerSecond }?.coerceAtLeast(1.0) ?: 1.0
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .height(164.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = Alignment.Bottom,
    ) {
        visiblePoints.forEach { sample ->
            val speed = sample.tokensPerSecond
            val fraction = (speed / maxSpeed).toFloat()
            Column(
                modifier = Modifier.weight(1f),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Bottom,
            ) {
                Text(
                    text = formatSettingsTokenRate(speed),
                    style = MaterialTheme.typography.labelSmall,
                    color = ArixOnSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Clip,
                )
                Spacer(Modifier.height(6.dp))
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height((18 + 96 * fraction).dp)
                        .clip(RoundedCornerShape(topStart = 10.dp, topEnd = 10.dp, bottomStart = 6.dp, bottomEnd = 6.dp))
                        .background(ArixPrimary.copy(alpha = 0.18f + 0.44f * fraction)),
                )
                Spacer(Modifier.height(6.dp))
                Text(
                    text = sample.shortLabel,
                    style = MaterialTheme.typography.labelSmall,
                    color = ArixOnSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Clip,
                )
            }
        }
    }
}

@Composable
private fun TokenMixLegend(
    label: String,
    color: Color,
    tokens: Long,
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Box(
            modifier = Modifier
                .size(10.dp)
                .clip(CircleShape)
                .background(color),
        )
        Text(
            text = label,
            modifier = Modifier.weight(1f),
            style = MaterialTheme.typography.bodySmall,
            color = ArixOnSurfaceVariant,
        )
        Text(
            text = formatSettingsTokenCount(tokens),
            style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Medium),
            color = ArixOnSurface,
        )
    }
}

@Composable
private fun HistoryPeakRow(
    label: String,
    value: String,
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(ArixSurfaceHigh)
            .padding(horizontal = 14.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(
            text = label,
            modifier = Modifier.weight(1f),
            style = MaterialTheme.typography.bodyMedium,
            color = ArixOnSurfaceVariant,
        )
        Text(
            text = value,
            style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Medium),
            color = ArixOnSurface,
        )
    }
}

@Composable
private fun buildSettingsStatisticsSummary(
    usageStatisticsSnapshots: List<ChatUsageStatisticsSnapshot>,
): String {
    val report = buildUsageStatisticsReport(usageStatisticsSnapshots)
    return if (report.turnCount == 0) {
        ""
    } else {
        stringResource(
            R.string.settings_statistics_summary,
            formatSettingsTokenCount(report.totalTokens),
            report.turnCount,
        )
    }
}

private fun buildUsageStatisticsReport(
    usageStatisticsSnapshots: List<ChatUsageStatisticsSnapshot>,
): UsageStatisticsReport {
    val stats = usageStatisticsSnapshots.map { it.statistics }
    val zone = ZoneId.systemDefault()
    val today = LocalDate.now(zone)
    val daily = (13 downTo 0).map { daysAgo ->
        val date = today.minusDays(daysAgo.toLong())
        DailyTokenUsage(
            date = date,
            label = "${date.monthValue}/${date.dayOfMonth}",
            shortLabel = date.dayOfMonth.toString(),
            tokens = stats
                .filter { stat ->
                    val millis = stat.completedAtMillis.takeIf { it > 0L } ?: stat.startedAtMillis
                    millis > 0L && Instant.ofEpochMilli(millis).atZone(zone).toLocalDate() == date
                }
                .sumOf { it.totalTokens ?: 0L },
        )
    }
    val speedSamples = stats.mapNotNull { stat ->
        val speed = stat.outputTokensPerSecond ?: return@mapNotNull null
        val millis = stat.completedAtMillis.takeIf { it > 0L } ?: stat.startedAtMillis
        if (millis <= 0L) return@mapNotNull null
        val date = Instant.ofEpochMilli(millis).atZone(zone).toLocalDate()
        SpeedSample(
            date = date,
            label = "${date.monthValue}/${date.dayOfMonth}",
            shortLabel = "${date.monthValue}/${date.dayOfMonth}",
            tokensPerSecond = speed,
            timestampMillis = millis,
        )
    }.sortedBy { it.timestampMillis }
    val speeds = speedSamples.map { it.tokensPerSecond }
    val latencies = stats.mapNotNull { it.firstTokenLatencyMillis }
    return UsageStatisticsReport(
        totalTokens = stats.sumOf { it.totalTokens ?: 0L },
        inputTokens = stats.sumOf { it.inputTokens ?: 0L },
        outputTokens = stats.sumOf { it.outputTokens ?: 0L },
        reasoningTokens = stats.sumOf { it.reasoningTokens ?: 0L },
        sessionCount = usageStatisticsSnapshots.map { it.sessionId }.distinct().size,
        turnCount = stats.size,
        dailyTokenUsage = daily,
        peakDay = daily.maxByOrNull { it.tokens }?.takeIf { it.tokens > 0L },
        largestTurnTokens = stats.mapNotNull { it.totalTokens }.maxOrNull(),
        averageOutputTokensPerSecond = speeds.takeIf { it.isNotEmpty() }?.average(),
        averageFirstTokenLatencyMillis = latencies.takeIf { it.isNotEmpty() }?.average()?.roundToInt()?.toLong(),
        recentSpeedSamples = speedSamples,
    )
}

private fun formatSettingsTokenCount(tokens: Long): String = when {
    tokens >= 1_000_000L -> String.format(Locale.US, "%.1fM", tokens / 1_000_000.0)
    tokens >= 1_000L -> String.format(Locale.US, "%.1fK", tokens / 1_000.0)
    else -> tokens.toString()
}

private fun formatSettingsTokenRate(tokensPerSecond: Double): String =
    String.format(Locale.US, "%.1f tok/s", tokensPerSecond)

private fun formatSettingsDuration(millis: Long): String =
    if (millis >= 1_000L) {
        String.format(Locale.US, "%.2fs", millis / 1000.0)
    } else {
        "${millis}ms"
    }

private data class UsageStatisticsReport(
    val totalTokens: Long,
    val inputTokens: Long,
    val outputTokens: Long,
    val reasoningTokens: Long,
    val sessionCount: Int,
    val turnCount: Int,
    val dailyTokenUsage: List<DailyTokenUsage>,
    val peakDay: DailyTokenUsage?,
    val largestTurnTokens: Long?,
    val averageOutputTokensPerSecond: Double?,
    val averageFirstTokenLatencyMillis: Long?,
    val recentSpeedSamples: List<SpeedSample>,
)

private data class DailyTokenUsage(
    val date: LocalDate,
    val label: String,
    val shortLabel: String,
    val tokens: Long,
)

private data class SpeedSample(
    val date: LocalDate,
    val label: String,
    val shortLabel: String,
    val tokensPerSecond: Double,
    val timestampMillis: Long,
)

// -----------------------------------------------------------------------------
// Providers List Page (Multi-Provider)
// -----------------------------------------------------------------------------


@Composable
private fun ProvidersListPage(
    providerConfigs: List<LlmProviderConfig>,
    onSetProviderEnabled: (String, Boolean) -> Unit,
    onOpenDefaultModels: () -> Unit,
    onEdit: (String) -> Unit,
    onRemove: (String) -> Unit,
    onAddNew: () -> Unit,
    onOpenLocalModels: () -> Unit,
    onBack: () -> Unit,
) {
    SubPageScaffold(
        title = stringResource(R.string.settings_model_providers),
        onBack = onBack,
        trailingIcon = Icons.Rounded.Add,
        onTrailingAction = onAddNew,
    ) {
        if (providerConfigs.isEmpty()) {
            SettingsCardGroup {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    Text(
                        stringResource(R.string.settings_no_providers_configured),
                        style = MaterialTheme.typography.titleMedium,
                        color = ArixOnSurface,
                    )
                    Spacer(Modifier.height(8.dp))
                    Text(
                        stringResource(R.string.settings_add_provider_description),
                        style = MaterialTheme.typography.bodyMedium,
                        color = ArixOnSurfaceVariant,
                    )
                    Spacer(Modifier.height(16.dp))
                    SettingsActionButton(
                        label = stringResource(R.string.settings_add_provider),
                        onClick = onAddNew,
                    )
                }
            }
        } else {
            providerConfigs.forEach { config ->
                ProviderCard(
                    config = config,
                    onEnabledChange = { enabled -> onSetProviderEnabled(config.id, enabled) },
                    onEdit = { onEdit(config.id) },
                    onRemove = { onRemove(config.id) },
                )
                Spacer(Modifier.height(12.dp))
            }
        }

        Spacer(Modifier.height(8.dp))
        SettingsCardGroup {
            SettingsNavRow(
                icon = Icons.Rounded.AutoAwesome,
                title = stringResource(R.string.settings_default_models),
                subtitle = stringResource(R.string.settings_default_models_subtitle),
                onClick = onOpenDefaultModels,
            )
            CardDivider()
            SettingsNavRow(
                icon = Icons.Rounded.Memory,
                title = stringResource(R.string.settings_local_models),
                subtitle = stringResource(R.string.settings_local_models_hint),
                onClick = onOpenLocalModels,
            )
        }
    }
}

@Composable
private fun DefaultModelsPage(
    modelOptions: List<ProviderModelOption>,
    defaultChatModelKey: String,
    defaultTitleModelKey: String,
    defaultNamingModelKey: String,
    defaultCompactingModelKey: String,
    onOpenDefaultChatModel: () -> Unit,
    onOpenDefaultTitleModel: () -> Unit,
    onOpenDefaultNamingModel: () -> Unit,
    onOpenDefaultCompactingModel: () -> Unit,
    onBack: () -> Unit,
) {
    val automaticChatLabel = modelOptions.findModelOption(
        modelOptions.resolveAutomaticModelKey(AutomaticModelPurpose.Chat)
    )?.fullLabel
    val automaticTitleLabel = modelOptions.findModelOption(
        modelOptions.resolveAutomaticModelKey(AutomaticModelPurpose.Title)
            .ifBlank { modelOptions.resolveAutomaticModelKey(AutomaticModelPurpose.Chat) }
    )?.fullLabel
    val automaticNamingLabel = modelOptions.findModelOption(
        modelOptions.resolveAutomaticModelKey(AutomaticModelPurpose.Naming)
            .ifBlank { modelOptions.resolveAutomaticModelKey(AutomaticModelPurpose.Chat) }
    )?.fullLabel
    val automaticCompactingLabel = modelOptions.findModelOption(
        modelOptions.resolveAutomaticModelKey(AutomaticModelPurpose.Compacting)
            .ifBlank { modelOptions.resolveAutomaticModelKey(AutomaticModelPurpose.Chat) }
    )?.fullLabel
    SubPageScaffold(
        title = stringResource(R.string.settings_default_models),
        onBack = onBack,
    ) {
        SettingsCardGroup {
            SettingsNavRow(
                icon = Icons.Rounded.AutoAwesome,
                title = stringResource(R.string.settings_default_chat_model),
                subtitle = if (defaultChatModelKey.isBlank()) {
                    automaticChatLabel?.let { stringResource(R.string.settings_automatic_model_with_name, it) }
                        ?: stringResource(R.string.settings_automatic_model)
                } else {
                    modelOptions.findModelOption(defaultChatModelKey)?.fullLabel.orEmpty()
                },
                onClick = onOpenDefaultChatModel,
            )
            CardDivider()
            SettingsNavRow(
                icon = Icons.Rounded.Edit,
                title = stringResource(R.string.settings_default_title_model),
                subtitle = if (defaultTitleModelKey.isBlank()) {
                    automaticTitleLabel?.let { stringResource(R.string.settings_automatic_model_with_name, it) }
                        ?: stringResource(R.string.settings_automatic_model)
                } else {
                    modelOptions.findModelOption(defaultTitleModelKey)?.fullLabel.orEmpty()
                },
                onClick = onOpenDefaultTitleModel,
            )
            CardDivider()
            SettingsNavRow(
                icon = Icons.Rounded.Person,
                title = stringResource(R.string.settings_default_naming_model),
                subtitle = if (defaultNamingModelKey.isBlank()) {
                    automaticNamingLabel?.let { stringResource(R.string.settings_automatic_model_with_name, it) }
                        ?: stringResource(R.string.settings_automatic_model)
                } else {
                    modelOptions.findModelOption(defaultNamingModelKey)?.fullLabel.orEmpty()
                },
                onClick = onOpenDefaultNamingModel,
            )
            CardDivider()
            SettingsNavRow(
                icon = Icons.Rounded.AutoAwesome,
                title = stringResource(R.string.settings_default_compacting_model),
                subtitle = if (defaultCompactingModelKey.isBlank()) {
                    automaticCompactingLabel?.let { stringResource(R.string.settings_automatic_model_with_name, it) }
                        ?: stringResource(R.string.settings_automatic_model)
                } else {
                    modelOptions.findModelOption(defaultCompactingModelKey)?.fullLabel.orEmpty()
                },
                onClick = onOpenDefaultCompactingModel,
            )
        }
    }
}

@Composable
private fun ProviderCard(
    config: LlmProviderConfig,
    onEnabledChange: (Boolean) -> Unit,
    onEdit: () -> Unit,
    onRemove: () -> Unit,
) {
    val availableModels = config.availableModels()
    val enabledModels = config.enabledModels()
    val provider = PiProviderCatalog.resolve(config.piProviderId)

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(ArixSurface)
            .padding(16.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Checkbox(
            checked = config.isEnabled,
            onCheckedChange = { enabled -> onEnabledChange(enabled) },
        )

        Spacer(Modifier.width(10.dp))
        ProviderBrandIconBadge(
            provider = provider,
            badgeSize = 40.dp,
            iconSize = 25.dp,
            cornerRadius = 8.dp,
        )
        Spacer(Modifier.width(12.dp))

        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = config.name,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold,
                color = ArixOnSurface,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            Spacer(Modifier.height(2.dp))
            Text(
                text = "${provider.displayName} · ${config.providerId}",
                style = MaterialTheme.typography.bodySmall,
                color = ArixOnSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            Spacer(Modifier.height(2.dp))
            Text(
                text = stringResource(R.string.settings_provider_models_enabled_count, enabledModels.size, availableModels.size),
                style = MaterialTheme.typography.bodySmall,
                color = ArixOnSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }

        IconButton(onClick = onEdit) {
            Icon(
                Icons.Rounded.Edit,
                contentDescription = stringResource(R.string.action_edit),
                tint = ArixOnSurfaceVariant,
            )
        }

        IconButton(onClick = onRemove) {
            Icon(
                Icons.Rounded.Delete,
                contentDescription = stringResource(R.string.action_remove),
                tint = Color(0xFFD25757),
            )
        }
    }
}

@Composable
private fun ModelSelectionListPage(
    title: String,
    subtitle: String,
    selectedKey: String,
    options: List<ProviderModelOption>,
    purpose: AutomaticModelPurpose,
    automaticLabel: String,
    automaticSubtitle: String,
    onSelected: (String) -> Unit,
    onBack: () -> Unit,
) {
    val selectedOption = options.findModelOption(selectedKey)
    val sortedOptions = remember(options, purpose) {
        options.sortedForAutomaticModelPurpose(purpose)
    }
    var searchQuery by rememberSaveable(stateSaver = TextFieldValue.Saver) {
        mutableStateOf(TextFieldValue(""))
    }
    val trimmedSearchQuery = searchQuery.text.trim()
    val filteredOptions = remember(sortedOptions, trimmedSearchQuery) {
        if (trimmedSearchQuery.isBlank()) {
            sortedOptions
        } else {
            val needle = trimmedSearchQuery.lowercase()
            sortedOptions.filter { option ->
                option.fullLabel.contains(needle, ignoreCase = true) ||
                    option.modelId.contains(needle, ignoreCase = true) ||
                    option.providerName.contains(needle, ignoreCase = true) ||
                    option.providerId.contains(needle, ignoreCase = true) ||
                    PiProviderCatalog.resolve(option.piProviderId).displayName
                        .contains(needle, ignoreCase = true)
            }
        }
    }

    SubPageScaffold(
        title = title,
        onBack = onBack,
    ) {
        Text(
            text = subtitle,
            style = MaterialTheme.typography.bodyMedium,
            color = ArixOnSurfaceVariant,
        )
        Spacer(Modifier.height(14.dp))

        if (options.isEmpty()) {
            SettingsCardGroup {
                Column(
                    modifier = Modifier.padding(horizontal = 18.dp, vertical = 18.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp),
                ) {
                    Text(
                        text = stringResource(R.string.settings_no_enabled_models_available),
                        style = MaterialTheme.typography.titleMedium,
                        color = ArixOnSurface,
                    )
                    Text(
                        text = stringResource(R.string.settings_enable_provider_model_first),
                        style = MaterialTheme.typography.bodyMedium,
                        color = ArixOnSurfaceVariant,
                    )
                }
            }
            return@SubPageScaffold
        }

        SettingsCardGroup {
            ModelSelectionSearchField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
            )
        }
        Spacer(Modifier.height(12.dp))

        SettingsCardGroup {
            ModelSelectionListRow(
                title = automaticLabel,
                subtitle = automaticSubtitle,
                selected = selectedOption == null,
                onClick = { onSelected("") },
            )
            filteredOptions.forEach { option ->
                CardDivider()
                ModelSelectionListRow(
                    title = option.fullLabel,
                    subtitle = option.providerName,
                    selected = option.key == selectedOption?.key,
                    onClick = { onSelected(option.key) },
                )
            }
            if (filteredOptions.isEmpty()) {
                CardDivider()
                Text(
                    text = stringResource(R.string.settings_no_models_match_search),
                    style = MaterialTheme.typography.bodyMedium,
                    color = ArixOnSurfaceVariant,
                    modifier = Modifier.padding(horizontal = 18.dp, vertical = 18.dp),
                )
            }
        }
    }
}

@Composable
private fun ModelSelectionSearchField(
    value: TextFieldValue,
    onValueChange: (TextFieldValue) -> Unit,
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(
            imageVector = Icons.Rounded.Search,
            contentDescription = null,
            tint = ArixOnSurfaceVariant,
            modifier = Modifier.size(20.dp),
        )
        Spacer(Modifier.width(12.dp))
        BasicTextField(
            value = value,
            onValueChange = onValueChange,
            modifier = Modifier
                .weight(1f)
                .settingsBringIntoViewOnFocus(),
            textStyle = MaterialTheme.typography.bodyLarge.copy(color = ArixOnSurface),
            cursorBrush = SolidColor(ArixPrimary),
            singleLine = true,
            decorationBox = { innerTextField ->
                Box {
                    if (value.text.isEmpty()) {
                        Text(
                            text = stringResource(R.string.settings_search_models),
                            style = MaterialTheme.typography.bodyLarge,
                            color = ArixOnSurfaceVariant.copy(alpha = 0.5f),
                        )
                    }
                    innerTextField()
                }
            },
        )
    }
}

@Composable
private fun ModelSelectionListRow(
    title: String,
    subtitle: String,
    selected: Boolean,
    onClick: () -> Unit,
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .background(if (selected) ArixSettingsBackground.copy(alpha = 0.9f) else Color.Transparent)
            .clickable(onClick = onClick)
            .padding(horizontal = 18.dp, vertical = 18.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(4.dp),
        ) {
            Text(
                text = title,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold,
                color = ArixOnSurface,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
            )
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodyMedium,
                color = ArixOnSurfaceVariant,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
            )
        }
        Spacer(Modifier.width(14.dp))
        Icon(
            imageVector = Icons.Rounded.Check,
            contentDescription = null,
            tint = if (selected) ArixPrimary else Color.Transparent,
            modifier = Modifier.size(22.dp),
        )
    }
}

// -----------------------------------------------------------------------------
// Provider Edit Page (Add/Edit)
// -----------------------------------------------------------------------------

@Composable
private fun ProviderEditPage(
    existingConfig: LlmProviderConfig?,
    existingProviderIds: Set<String>,
    isFetchingModels: Boolean,
    onSave: (LlmProviderConfig) -> Unit,
    onModelEnabledChange: (LlmProviderConfig) -> Unit,
    onFetchModels: (LlmProviderConfig, (List<String>) -> Unit) -> Unit,
    authState: PiProviderAuthState,
    onStartProviderLogin: (String, String, ProviderAuthMethod, String) -> Unit,
    onSubmitAuthPrompt: (String, String, Boolean) -> Unit,
    onClearAuthState: () -> Unit,
    onBack: () -> Unit,
) {
    val isNew = existingConfig == null
    val formState = rememberProviderFormState(existingConfig)

    if (isNew) {
        SubPageScaffold(
            title = stringResource(R.string.settings_add_provider),
            onBack = onBack,
        ) {
            AddProviderWizard(
                state = formState,
                existingProviderIds = existingProviderIds,
                isFetchingModels = isFetchingModels,
                onFetchModels = onFetchModels,
                authState = authState,
                onStartProviderLogin = onStartProviderLogin,
                onSubmitAuthPrompt = onSubmitAuthPrompt,
                onClearAuthState = onClearAuthState,
                onSave = onSave,
            )
        }
        return
    }

    SubPageScaffold(
        title = stringResource(R.string.settings_edit_provider),
        onBack = onBack,
        trailingIcon = Icons.Rounded.Check,
        trailingEnabled = formState.isValid(existingProviderIds),
        onTrailingAction = {
            onSave(formState.buildConfig())
            onBack()
        },
    ) {
        ProviderConfigurationForm(
            state = formState,
            existingProviderIds = existingProviderIds,
            isFetchingModels = isFetchingModels,
            onFetchModels = onFetchModels,
            onModelEnabledChange = onModelEnabledChange,
            authState = authState,
            onStartProviderLogin = onStartProviderLogin,
            onSubmitAuthPrompt = onSubmitAuthPrompt,
            onClearAuthState = onClearAuthState,
        )
    }
}
// -----------------------------------------------------------------------------
// Personalization sub-page
// -----------------------------------------------------------------------------

@Composable
private fun PersonalizationPage(
    title: String,
    systemPromptValue: TextFieldValue,
    onSystemPromptChanged: (TextFieldValue) -> Unit,
    onBack: () -> Unit,
) {
    SubPageScaffold(
        title = title,
        onBack = onBack,
        trailingIcon = Icons.Rounded.Check,
        onTrailingAction = onBack,
    ) {
        SettingsCardGroup {
            ChatGptTextField(
                label = stringResource(R.string.settings_custom_instructions),
                value = systemPromptValue,
                onValueChange = onSystemPromptChanged,
                minLines = 8,
            )
        }

        Spacer(Modifier.height(8.dp))
        Text(
            text = stringResource(R.string.settings_custom_instructions_variables_hint),
            style = MaterialTheme.typography.bodySmall,
            color = ArixOnSurfaceVariant,
            modifier = Modifier.padding(horizontal = 4.dp),
        )
    }
}

// -----------------------------------------------------------------------------
// Skills List Page (Refactored)
// -----------------------------------------------------------------------------

@Composable
private fun ReliabilityPage(
    title: String,
    llmInactivityReconnectTimeoutValue: TextFieldValue,
    onLlmInactivityReconnectTimeoutChanged: (TextFieldValue) -> Unit,
    keepTasksRunningInBackground: Boolean,
    onKeepTasksRunningInBackgroundChanged: (Boolean) -> Unit,
    notifyOnTaskCompletion: Boolean,
    onNotifyOnTaskCompletionChanged: (Boolean) -> Unit,
    onBack: () -> Unit,
) {
    SubPageScaffold(
        title = title,
        onBack = onBack,
        trailingIcon = Icons.Rounded.Check,
        onTrailingAction = onBack,
    ) {
        Text(
            text = stringResource(R.string.settings_multitasking),
            style = MaterialTheme.typography.labelLarge,
            color = ArixOnSurface,
            modifier = Modifier.padding(horizontal = 4.dp),
        )
        Spacer(Modifier.height(8.dp))

        SettingsCardGroup {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp),
            ) {
                SettingsToggleRow(
                    title = stringResource(R.string.settings_keep_tasks_running_background),
                    subtitle = stringResource(R.string.settings_keep_tasks_running_background_subtitle),
                    checked = keepTasksRunningInBackground,
                    onCheckedChange = onKeepTasksRunningInBackgroundChanged,
                )
                Spacer(Modifier.height(4.dp))
                SettingsToggleRow(
                    title = stringResource(R.string.settings_notify_background_tasks_finish),
                    subtitle = stringResource(R.string.settings_notify_background_tasks_finish_subtitle),
                    checked = notifyOnTaskCompletion,
                    onCheckedChange = onNotifyOnTaskCompletionChanged,
                )
            }
        }

        Spacer(Modifier.height(16.dp))
        Text(
            text = stringResource(R.string.settings_reconnect),
            style = MaterialTheme.typography.labelLarge,
            color = ArixOnSurface,
            modifier = Modifier.padding(horizontal = 4.dp),
        )
        Spacer(Modifier.height(8.dp))

        SettingsCardGroup {
            ChatGptTextField(
                label = stringResource(R.string.settings_reconnect_after_idle_seconds),
                value = llmInactivityReconnectTimeoutValue,
                onValueChange = {
                    val digitsOnly = it.text.filter(Char::isDigit)
                    onLlmInactivityReconnectTimeoutChanged(
                        it.copy(
                            text = digitsOnly,
                            selection = androidx.compose.ui.text.TextRange(digitsOnly.length),
                        )
                    )
                },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            )
        }

        Spacer(Modifier.height(8.dp))
        Text(
            text = stringResource(R.string.settings_reconnect_after_idle_description),
            style = MaterialTheme.typography.bodySmall,
            color = ArixOnSurfaceVariant,
            modifier = Modifier.padding(horizontal = 4.dp),
        )
    }
}

/* --------------------------------------------------------- data & storage */

private fun formatStorageBytes(bytes: Long): String = when {
    bytes >= 1_048_576 -> "%.1f MB".format(bytes / 1_048_576.0)
    bytes >= 1_024 -> "%.1f KB".format(bytes / 1_024.0)
    else -> "$bytes B"
}

private fun querySavedQrCount(context: android.content.Context): Int {
    return runCatching {
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.Q) {
            val collection = android.provider.MediaStore.Downloads
                .getContentUri(android.provider.MediaStore.VOLUME_EXTERNAL_PRIMARY)
            context.contentResolver.query(
                collection,
                arrayOf(android.provider.MediaStore.Downloads._ID),
                "${android.provider.MediaStore.Downloads.DISPLAY_NAME} LIKE ?",
                arrayOf("qr-code-%"),
                null,
            )?.use { it.count } ?: 0
        } else {
            @Suppress("DEPRECATION")
            val downloads = android.os.Environment
                .getExternalStoragePublicDirectory(android.os.Environment.DIRECTORY_DOWNLOADS)
            downloads?.listFiles { file -> file.name.startsWith("qr-code-") }?.size ?: 0
        }
    }.getOrDefault(0)
}

private fun deleteSavedQrImages(context: android.content.Context): Int {
    var deleted = 0
    runCatching {
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.Q) {
            val collection = android.provider.MediaStore.Downloads
                .getContentUri(android.provider.MediaStore.VOLUME_EXTERNAL_PRIMARY)
            context.contentResolver.query(
                collection,
                arrayOf(android.provider.MediaStore.Downloads._ID),
                "${android.provider.MediaStore.Downloads.DISPLAY_NAME} LIKE ?",
                arrayOf("qr-code-%"),
                null,
            )?.use { cursor ->
                val idColumn = cursor.getColumnIndexOrThrow(android.provider.MediaStore.Downloads._ID)
                while (cursor.moveToNext()) {
                    val uri = android.content.ContentUris.withAppendedId(collection, cursor.getLong(idColumn))
                    if (context.contentResolver.delete(uri, null, null) > 0) deleted++
                }
            }
        } else {
            @Suppress("DEPRECATION")
            val downloads = android.os.Environment
                .getExternalStoragePublicDirectory(android.os.Environment.DIRECTORY_DOWNLOADS)
            downloads?.listFiles { file -> file.name.startsWith("qr-code-") }?.forEach {
                if (it.delete()) deleted++
            }
        }
    }
    return deleted
}

private fun directorySize(file: java.io.File?): Long {
    if (file == null || !file.exists()) return 0
    var total = 0L
    file.walkBottomUp().forEach { entry ->
        if (entry.isFile) total += entry.length()
    }
    return total
}

private fun clearAppCache(context: android.content.Context): Long {
    var freed = 0L
    listOfNotNull(context.cacheDir, context.externalCacheDir).forEach { root ->
        root.listFiles()?.forEach { entry ->
            if (entry.isDirectory) {
                freed += directorySize(entry)
                entry.deleteRecursively()
            } else {
                freed += entry.length()
                entry.delete()
            }
        }
    }
    return freed
}

@Composable
private fun StorageSettingsPage(
    title: String,
    onResetAlpineRuntime: () -> Unit,
    onBack: () -> Unit,
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var savedQrCount by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf<Int?>(null) }
    var cacheBytes by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf<Long?>(null) }
    var alpineWorkspaceBytes by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf<Long?>(null) }
    var alpineInstallBytes by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf<Long?>(null) }
    var skillsBytes by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf<Long?>(null) }
    var modelsBytes by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf<Long?>(null) }
    var diagnosticsBytes by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf<Long?>(null) }
    var cleaningQr by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf(false) }
    var cleaningCache by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf(false) }
    var cleaningWorkspace by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf(false) }
    var cleaningSkills by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf(false) }
    var cleaningModels by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf(false) }
    var cleaningDiagnostics by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf(false) }
    var resettingAlpine by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf(false) }
    var pendingAlpineReset by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf(false) }
    var feedback by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf("") }
    val cleanedLabel = stringResource(R.string.settings_storage_clean_done)
    val nothingLabel = stringResource(R.string.settings_storage_clean_nothing)
    val confirmAlpineLabel = stringResource(R.string.settings_storage_confirm_alpine)

    fun refresh() {
        scope.launch {
            data class StorageSnapshot(
                val qr: Int,
                val cache: Long,
                val workspace: Long,
                val install: Long,
                val skills: Long,
                val models: Long,
                val diagnostics: Long,
            )

            val snapshot = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
                val filesRoot = context.filesDir
                val runtimesRoot = java.io.File(filesRoot, "runtimes")
                val alpineRoot = java.io.File(runtimesRoot, "alpine")
                StorageSnapshot(
                    qr = querySavedQrCount(context),
                    cache = directorySize(context.cacheDir) + directorySize(context.externalCacheDir),
                    workspace = directorySize(java.io.File(alpineRoot, "workspace")),
                    install = directorySize(alpineRoot) + directorySize(java.io.File(runtimesRoot, "alpine-installing")),
                    skills = directorySize(java.io.File(filesRoot, "agent-skills")),
                    models = directorySize(java.io.File(filesRoot, ArixLocalModels.ModelsDirName)),
                    diagnostics = directorySize(java.io.File(filesRoot, "diagnostics")),
                )
            }
            savedQrCount = snapshot.qr
            cacheBytes = snapshot.cache
            alpineWorkspaceBytes = snapshot.workspace
            alpineInstallBytes = snapshot.install
            skillsBytes = snapshot.skills
            modelsBytes = snapshot.models
            diagnosticsBytes = snapshot.diagnostics
        }
    }

    androidx.compose.runtime.LaunchedEffect(Unit) { refresh() }

    SubPageScaffold(
        title = title,
        onBack = onBack,
    ) {
        if (feedback.isNotBlank()) {
            Text(
                text = feedback,
                style = MaterialTheme.typography.bodySmall,
                color = ArixPrimary,
                modifier = Modifier.padding(horizontal = 4.dp),
            )
            Spacer(Modifier.height(12.dp))
        }
        if (pendingAlpineReset) {
            Text(
                text = confirmAlpineLabel,
                style = MaterialTheme.typography.bodySmall,
                color = androidx.compose.ui.graphics.Color(0xFFE5757A),
                modifier = Modifier.padding(horizontal = 4.dp),
            )
            Spacer(Modifier.height(12.dp))
        }

        StorageSectionCard(
            title = stringResource(R.string.settings_storage_alpine_workspace),
            subtitle = if ((alpineWorkspaceBytes ?: 0L) > 0L) {
                stringResource(
                    R.string.settings_storage_alpine_workspace_hint,
                    formatStorageBytes(alpineWorkspaceBytes ?: 0L),
                )
            } else {
                stringResource(R.string.settings_storage_alpine_workspace_hint_empty)
            },
            buttonLabel = stringResource(R.string.settings_storage_clean_alpine_workspace),
            buttonIcon = Icons.Rounded.DeleteOutline,
            enabled = (alpineWorkspaceBytes ?: 0L) > 0L,
            isLoading = cleaningWorkspace,
            onAction = {
                cleaningWorkspace = true
                scope.launch {
                    val freed = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
                        val workspace = java.io.File(context.filesDir, "runtimes/alpine/workspace")
                        var total = 0L
                        workspace.listFiles()?.forEach { entry ->
                            total += directorySize(entry)
                            entry.deleteRecursively()
                        }
                        total
                    }
                    cleaningWorkspace = false
                    feedback = if (freed > 0L) cleanedLabel else nothingLabel
                    refresh()
                }
            },
        )

        Spacer(Modifier.height(16.dp))

        StorageSectionCard(
            title = stringResource(R.string.settings_storage_alpine_install),
            subtitle = if ((alpineInstallBytes ?: 0L) > 0L) {
                stringResource(
                    R.string.settings_storage_alpine_install_hint,
                    formatStorageBytes(alpineInstallBytes ?: 0L),
                )
            } else {
                stringResource(R.string.settings_storage_alpine_install_hint_empty)
            },
            buttonLabel = stringResource(R.string.settings_storage_reset_alpine),
            buttonIcon = Icons.Rounded.DeleteOutline,
            enabled = (alpineInstallBytes ?: 0L) > 0L,
            isLoading = resettingAlpine,
            onAction = {
                if (!pendingAlpineReset) {
                    pendingAlpineReset = true
                    feedback = ""
                } else {
                    pendingAlpineReset = false
                    resettingAlpine = true
                    onResetAlpineRuntime()
                    scope.launch {
                        kotlinx.coroutines.delay(2500)
                        resettingAlpine = false
                        feedback = cleanedLabel
                        refresh()
                    }
                }
            },
        )

        Spacer(Modifier.height(16.dp))

        StorageSectionCard(
            title = stringResource(R.string.settings_storage_skills),
            subtitle = if ((skillsBytes ?: 0L) > 0L) {
                stringResource(R.string.settings_storage_skills_hint, formatStorageBytes(skillsBytes ?: 0L))
            } else {
                stringResource(R.string.settings_storage_skills_hint_empty)
            },
            buttonLabel = stringResource(R.string.settings_storage_clean_skills),
            buttonIcon = Icons.Rounded.DeleteOutline,
            enabled = (skillsBytes ?: 0L) > 0L,
            isLoading = cleaningSkills,
            onAction = {
                cleaningSkills = true
                scope.launch {
                    kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
                        java.io.File(context.filesDir, "agent-skills").listFiles()?.forEach { it.deleteRecursively() }
                        java.io.File(context.filesDir, "agent-skills-tmp").listFiles()?.forEach { it.deleteRecursively() }
                    }
                    cleaningSkills = false
                    feedback = cleanedLabel
                    refresh()
                }
            },
        )

        Spacer(Modifier.height(16.dp))

        StorageSectionCard(
            title = stringResource(R.string.settings_storage_models),
            subtitle = if ((modelsBytes ?: 0L) > 0L) {
                stringResource(R.string.settings_storage_models_hint, formatStorageBytes(modelsBytes ?: 0L))
            } else {
                stringResource(R.string.settings_storage_models_hint_empty)
            },
            buttonLabel = stringResource(R.string.settings_storage_clean_models),
            buttonIcon = Icons.Rounded.DeleteOutline,
            enabled = (modelsBytes ?: 0L) > 0L,
            isLoading = cleaningModels,
            onAction = {
                cleaningModels = true
                scope.launch {
                    kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
                        ArixLocalModels.modelsDir(context).listFiles()?.forEach { it.delete() }
                    }
                    cleaningModels = false
                    feedback = cleanedLabel
                    refresh()
                }
            },
        )

        Spacer(Modifier.height(16.dp))

        StorageSectionCard(
            title = stringResource(R.string.settings_storage_diagnostics),
            subtitle = if ((diagnosticsBytes ?: 0L) > 0L) {
                stringResource(R.string.settings_storage_diagnostics_hint, formatStorageBytes(diagnosticsBytes ?: 0L))
            } else {
                stringResource(R.string.settings_storage_diagnostics_hint_empty)
            },
            buttonLabel = stringResource(R.string.settings_storage_clean_diagnostics),
            buttonIcon = Icons.Rounded.DeleteOutline,
            enabled = (diagnosticsBytes ?: 0L) > 0L,
            isLoading = cleaningDiagnostics,
            onAction = {
                cleaningDiagnostics = true
                scope.launch {
                    kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
                        java.io.File(context.filesDir, "diagnostics").listFiles()?.forEach { it.delete() }
                    }
                    cleaningDiagnostics = false
                    feedback = cleanedLabel
                    refresh()
                }
            },
        )

        Spacer(Modifier.height(16.dp))

        StorageSectionCard(
            title = stringResource(R.string.settings_storage_saved_qr),
            subtitle = if (savedQrCount != null && savedQrCount!! > 0) {
                stringResource(R.string.settings_storage_saved_qr_hint, savedQrCount!!)
            } else {
                stringResource(R.string.settings_storage_saved_qr_hint_empty)
            },
            buttonLabel = stringResource(R.string.settings_storage_clean_saved_qr),
            buttonIcon = Icons.Rounded.DeleteOutline,
            enabled = (savedQrCount ?: 0) > 0,
            isLoading = cleaningQr,
            onAction = {
                cleaningQr = true
                scope.launch {
                    val deleted = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
                        deleteSavedQrImages(context)
                    }
                    cleaningQr = false
                    feedback = if (deleted > 0) cleanedLabel else nothingLabel
                    refresh()
                }
            },
        )

        Spacer(Modifier.height(16.dp))

        StorageSectionCard(
            title = stringResource(R.string.settings_storage_app_cache),
            subtitle = stringResource(
                R.string.settings_storage_app_cache_hint,
                formatStorageBytes(cacheBytes ?: 0L),
            ),
            buttonLabel = stringResource(R.string.settings_storage_clear_cache),
            buttonIcon = Icons.Rounded.DeleteOutline,
            enabled = (cacheBytes ?: 0L) > 0L,
            isLoading = cleaningCache,
            onAction = {
                cleaningCache = true
                scope.launch {
                    kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
                        com.arix.app.data.ArixMediaApi.clearCaches()
                        clearAppCache(context)
                    }
                    cleaningCache = false
                    feedback = cleanedLabel
                    refresh()
                }
            },
        )
    }
}

@Composable
private fun LocalModelsSettingsPage(
    title: String,
    onBack: () -> Unit,
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var specs by androidx.compose.runtime.remember {
        androidx.compose.runtime.mutableStateOf<com.arix.app.data.ArixLocalModels.DeviceSpecs?>(null)
    }
    var recommendedModel by androidx.compose.runtime.remember {
        androidx.compose.runtime.mutableStateOf<com.arix.app.data.ArixLocalModels.LocalModelInfo?>(null)
    }
    var downloadedIds by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf<Set<String>>(emptySet()) }
    var importedFiles by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf<List<java.io.File>>(emptyList()) }
    var progress by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf<Map<String, Int>>(emptyMap()) }
    var feedback by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf("") }
    var importing by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf(false) }

    val importFailedLabel = stringResource(R.string.settings_local_models_import_failed)
    val importedOkLabel = stringResource(R.string.settings_local_models_imported_ok)
    val downloadFailedLabel = stringResource(R.string.settings_local_models_download_failed)
    val downloadSavedDownloadsLabel = stringResource(R.string.settings_local_models_saved_downloads)
    val downloadSavedAppLabel = stringResource(R.string.settings_local_models_saved_app)
    val deletedLabel = stringResource(R.string.settings_local_models_deleted)

    fun refresh() {
        scope.launch {
            val nextSpecs = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
                com.arix.app.data.ArixLocalModels.deviceSpecs(context)
            }
            // v2.2.8: the recommendation is computed OFF the composition — the
            // old code called recommendedModel(context) directly during render,
            // which re-ran device probing (incl. a GL call) on the UI thread
            // and crashed the app on open.
            val nextRecommended = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
                nextSpecs?.let {
                    runCatching { com.arix.app.data.ArixLocalModels.recommendedModel(context) }.getOrNull()
                }
            }
            val downloaded = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
                com.arix.app.data.ArixLocalModels.catalog
                    .filter { com.arix.app.data.ArixLocalModels.isDownloaded(context, it) }
                    .map { it.id }
                    .toSet()
            }
            val imported = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
                com.arix.app.data.ArixLocalModels.listModelFiles(context)
            }
            specs = nextSpecs
            recommendedModel = nextRecommended
            downloadedIds = downloaded
            importedFiles = imported
        }
    }

    androidx.compose.runtime.LaunchedEffect(Unit) { refresh() }
    androidx.compose.runtime.LaunchedEffect(Unit) {
        // Poll active download progress while the page is open.
        while (true) {
            kotlinx.coroutines.delay(700)
            val active = com.arix.app.data.ArixLocalModels.catalog.mapNotNull { model ->
                com.arix.app.data.ArixLocalModels.activeProgress(model.id)?.let { model.id to it }
            }.toMap()
            if (active.isNotEmpty() || progress.isNotEmpty()) progress = active
            if (active.isEmpty() && progress.isEmpty()) {
                // Detect a finished download so the list flips to "Downloaded".
                val downloaded = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
                    com.arix.app.data.ArixLocalModels.catalog
                        .filter { com.arix.app.data.ArixLocalModels.isDownloaded(context, it) }
                        .map { it.id }
                        .toSet()
                }
                if (downloaded != downloadedIds) downloadedIds = downloaded
            }
        }
    }

    val modelImportPicker = androidx.activity.compose.rememberLauncherForActivityResult(
        contract = androidx.activity.result.contract.ActivityResultContracts.OpenDocument(),
    ) { uri ->
        if (uri != null) {
            importing = true
            scope.launch {
                val result = com.arix.app.data.ArixLocalModels.importModel(context, uri)
                importing = false
                feedback = result.fold(
                    onSuccess = { importedOkLabel },
                    onFailure = { importFailedLabel.format(it.message ?: "unknown error") },
                )
                refresh()
            }
        }
    }

    val catalogNames = com.arix.app.data.ArixLocalModels.catalog.map { it.filename }.toSet()
    val extraImports = importedFiles.filter { it.name !in catalogNames }

    SubPageScaffold(
        title = title,
        onBack = onBack,
    ) {
        if (feedback.isNotBlank()) {
            Text(
                text = feedback,
                style = MaterialTheme.typography.bodySmall,
                color = ArixPrimary,
                modifier = Modifier.padding(horizontal = 4.dp),
            )
            Spacer(Modifier.height(12.dp))
        }

        specs?.let { deviceSpecs ->
            val recommended = recommendedModel
            SettingsCardGroup {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp),
                ) {
                    Text(
                        text = stringResource(R.string.settings_local_models_recommend),
                        style = MaterialTheme.typography.labelLarge,
                        color = ArixOnSurface,
                    )
                    Text(
                        text = stringResource(
                            R.string.settings_local_models_device_specs,
                            deviceSpecs.totalRamMb,
                            deviceSpecs.freeStorageMb / 1024L,
                            deviceSpecs.abi,
                        ),
                        style = MaterialTheme.typography.bodySmall,
                        color = ArixOnSurfaceVariant,
                    )
                    recommended?.let { model ->
                        Text(
                            text = model.displayName,
                            style = MaterialTheme.typography.bodyMedium,
                            color = ArixPrimary,
                        )
                        Text(
                            text = model.description,
                            style = MaterialTheme.typography.bodySmall,
                            color = ArixOnSurfaceVariant,
                        )
                    }
                }
            }

            Spacer(Modifier.height(16.dp))

            Text(
                text = stringResource(R.string.settings_local_models_catalog),
                style = MaterialTheme.typography.labelLarge,
                color = ArixOnSurface,
                modifier = Modifier.padding(horizontal = 4.dp),
            )
            Spacer(Modifier.height(8.dp))

            com.arix.app.data.ArixLocalModels.catalog.forEach { model ->
                val compatibility = com.arix.app.data.ArixLocalModels.checkCompatibility(deviceSpecs, model)
                val downloaded = model.id in downloadedIds
                val modelProgress = progress[model.id]
                SettingsCardGroup {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = androidx.compose.ui.Alignment.CenterVertically,
                        ) {
                            Text(
                                text = model.displayName,
                                style = MaterialTheme.typography.labelLarge,
                                color = ArixOnSurface,
                                modifier = Modifier.weight(1f),
                            )
                            Text(
                                text = when {
                                    downloaded -> stringResource(
                                        R.string.settings_local_models_downloaded,
                                        formatStorageBytes(model.sizeMb.toLong() * 1024L * 1024L),
                                    )
                                    compatibility.compatible -> stringResource(R.string.settings_local_models_compatible)
                                    else -> stringResource(R.string.settings_local_models_incompatible)
                                },
                                style = MaterialTheme.typography.labelMedium,
                                color = if (downloaded || compatibility.compatible) ArixPrimary else androidx.compose.ui.graphics.Color(0xFFE5757A),
                            )
                        }
                        Text(
                            text = model.description,
                            style = MaterialTheme.typography.bodySmall,
                            color = ArixOnSurfaceVariant,
                        )
                        if (!compatibility.compatible && !downloaded) {
                            Text(
                                text = buildString {
                                    if (!compatibility.ramOk) {
                                        append(stringResource(R.string.settings_local_models_needs_ram, model.minRamMb))
                                        append(' ')
                                    }
                                    if (!compatibility.diskOk) {
                                        append(stringResource(R.string.settings_local_models_needs_disk, model.sizeMb))
                                    }
                                    if (model.requiresGpu && !compatibility.gpuOk) {
                                        if (isNotEmpty()) append("\n")
                                        append(stringResource(R.string.settings_local_models_gpu_required))
                                    }
                                },
                                style = MaterialTheme.typography.bodySmall,
                                color = androidx.compose.ui.graphics.Color(0xFFE5757A),
                            )
                        }
                        if (modelProgress != null) {
                            androidx.compose.material3.LinearProgressIndicator(
                                progress = { modelProgress / 100f },
                                modifier = Modifier.fillMaxWidth(),
                                color = ArixPrimary,
                            )
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            when {
                                modelProgress != null -> SettingsActionButton(
                                    label = stringResource(R.string.settings_local_models_cancel),
                                    onClick = { com.arix.app.data.ArixLocalModels.cancelDownload(model.id) },
                                    icon = Icons.Rounded.Close,
                                )

                                downloaded -> SettingsActionButton(
                                    label = stringResource(R.string.settings_local_models_delete),
                                    onClick = {
                                        scope.launch {
                                            kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
                                                com.arix.app.data.ArixLocalModels.downloadedFile(context, model)?.let {
                                                    com.arix.app.data.ArixLocalModels.deleteModel(context, it)
                                                }
                                            }
                                            feedback = deletedLabel
                                            refresh()
                                        }
                                    },
                                    icon = Icons.Rounded.DeleteOutline,
                                )

                                else -> SettingsActionButton(
                                    label = stringResource(R.string.settings_local_models_download),
                                    onClick = {
                                        feedback = ""
                                        scope.launch {
                                            val result = com.arix.app.data.ArixLocalModels.downloadModel(
                                                context,
                                                model,
                                                onProgress = { percent ->
                                                    progress = progress + (model.id to (percent * 100).toInt())
                                                },
                                            )
                                            result.fold(
                                                onSuccess = { outcome ->
                                                    progress = progress - model.id
                                                    feedback = if (outcome.downloadsCopy != null) {
                                                        downloadSavedDownloadsLabel
                                                    } else {
                                                        downloadSavedAppLabel
                                                    }
                                                    refresh()
                                                },
                                                onFailure = {
                                                    if (it.message != "cancelled") {
                                                        feedback = downloadFailedLabel.format(it.message ?: "unknown error")
                                                    }
                                                    progress = progress - model.id
                                                },
                                            )
                                        }
                                    },
                                    enabled = compatibility.compatible,
                                    icon = Icons.Rounded.Download,
                                )
                            }
                        }
                    }
                }
                Spacer(Modifier.height(12.dp))
            }
        }

        SettingsCardGroup {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp),
            ) {
                Text(
                    text = stringResource(R.string.settings_local_models_import),
                    style = MaterialTheme.typography.labelLarge,
                    color = ArixOnSurface,
                )
                SettingsActionButton(
                    label = stringResource(R.string.settings_local_models_import),
                    onClick = { modelImportPicker.launch(arrayOf("*/*")) },
                    enabled = !importing,
                    isLoading = importing,
                    icon = Icons.Rounded.UploadFile,
                )
                if (extraImports.isNotEmpty()) {
                    extraImports.forEach { file ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = androidx.compose.ui.Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = file.name,
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = ArixOnSurface,
                                )
                                Text(
                                    text = formatStorageBytes(file.length()),
                                    style = MaterialTheme.typography.bodySmall,
                                    color = ArixOnSurfaceVariant,
                                )
                            }
                            SettingsActionButton(
                                label = stringResource(R.string.settings_local_models_delete),
                                onClick = {
                                    scope.launch {
                                        kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
                                            com.arix.app.data.ArixLocalModels.deleteModel(context, file)
                                        }
                                        feedback = deletedLabel
                                        refresh()
                                    }
                                },
                                icon = Icons.Rounded.DeleteOutline,
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun StorageSectionCard(
    title: String,
    subtitle: String,
    buttonLabel: String,
    buttonIcon: androidx.compose.ui.graphics.vector.ImageVector?,
    enabled: Boolean,
    isLoading: Boolean,
    onAction: () -> Unit,
) {
    SettingsCardGroup {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.labelLarge,
                    color = ArixOnSurface,
                )
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = ArixOnSurfaceVariant,
                )
            }
            SettingsActionButton(
                label = buttonLabel,
                onClick = onAction,
                enabled = enabled,
                isLoading = isLoading,
                icon = buttonIcon,
            )
        }
    }
}

@Composable
private fun ArixExtensionSettingsCategoriesPage(
    page: com.arix.app.data.ArixAppExtensionSettingsPage,
    onCategorySelected: (String) -> Unit,
    onBack: () -> Unit,
) {
    val controller = LocalArixExtensionUiController.current
    val trailingIcon = settingsTrailingIcon(page.trailingIcon)
    SubPageScaffold(
        title = page.title,
        onBack = onBack,
        trailingIcon = trailingIcon,
        onTrailingAction = {
            if (page.trailingCategory.isNotBlank()) {
                onCategorySelected(page.trailingCategory)
            } else if (page.trailingAction.isNotBlank()) {
                controller?.onAction?.invoke(page.extensionId, page.trailingAction, page.trailingArgs)
            } else {
                onBack()
            }
        },
    ) {
        if (page.subtitle.isNotBlank()) {
            Text(page.subtitle, style = MaterialTheme.typography.bodySmall, color = ArixOnSurfaceVariant, modifier = Modifier.padding(horizontal = 4.dp))
            Spacer(Modifier.height(12.dp))
        }
        if (page.sections.isNotEmpty()) {
            ArixExtensionSettingsSections(page.sections, page, controller, onCategorySelected)
            Spacer(Modifier.height(16.dp))
        }
        val visibleCategories = page.categories.filterNot(com.arix.app.data.ArixAppExtensionSettingsCategory::hidden)
        SettingsCardGroup {
            visibleCategories.forEachIndexed { index, category ->
                SettingsNavRow(
                    icon = extensionIcon(category.icon),
                    title = category.title,
                    subtitle = category.subtitle,
                ) { onCategorySelected(category.id) }
                if (index < visibleCategories.lastIndex) CardDivider()
            }
        }
    }
}

@Composable
private fun ArixExtensionSettingsSections(
    sections: List<JSONObject>,
    page: com.arix.app.data.ArixAppExtensionSettingsPage,
    controller: ArixExtensionUiController?,
    onCategorySelected: (String) -> Unit = {},
) {
    sections.forEachIndexed { sectionIndex, section ->
        val sectionTitle = section.optString("title")
        val sectionDescription = section.optString("description")
        if (sectionIndex > 0) Spacer(Modifier.height(16.dp))
        if (sectionTitle.isNotBlank() || sectionDescription.isNotBlank()) {
            if (sectionTitle.isNotBlank()) {
                Text(
                    sectionTitle,
                    style = MaterialTheme.typography.labelLarge,
                    color = ArixOnSurface,
                    modifier = Modifier.padding(horizontal = 4.dp),
                )
            }
            if (sectionDescription.isNotBlank()) {
                if (sectionTitle.isNotBlank()) Spacer(Modifier.height(4.dp))
                Text(
                    sectionDescription,
                    style = MaterialTheme.typography.bodySmall,
                    color = ArixOnSurfaceVariant,
                    modifier = Modifier.padding(horizontal = 4.dp),
                )
            }
            Spacer(Modifier.height(8.dp))
        }

        val settings = section.optJSONArray("settings") ?: JSONArray()
        var index = 0
        while (index < settings.length()) {
            val setting = settings.optJSONObject(index) ?: run { index += 1; continue }
            val type = setting.optString("type").ifBlank { "text" }
            when (type) {
                "item-card", "card" -> {
                    ArixExtensionItemCard(
                        setting = setting,
                        page = page,
                        controller = controller,
                        onCategorySelected = onCategorySelected,
                    )
                    Spacer(Modifier.height(12.dp))
                    index += 1
                }
                "empty-state" -> {
                    ArixExtensionEmptyState(
                        setting = setting,
                        page = page,
                        controller = controller,
                        onCategorySelected = onCategorySelected,
                    )
                    Spacer(Modifier.height(12.dp))
                    index += 1
                }
                else -> {
                    val group = mutableListOf<JSONObject>()
                    while (index < settings.length()) {
                        val next = settings.optJSONObject(index) ?: break
                        val nextType = next.optString("type").ifBlank { "text" }
                        if (nextType == "item-card" || nextType == "card" || nextType == "empty-state") break
                        group.add(next)
                        index += 1
                    }
                    SettingsCardGroup {
                        Column {
                            group.forEachIndexed { groupIndex, itemSetting ->
                                ArixExtensionControlRow(
                                    setting = itemSetting,
                                    page = page,
                                    controller = controller,
                                    onCategorySelected = onCategorySelected,
                                )
                                val itemType = itemSetting.optString("type").ifBlank { "text" }
                                if (groupIndex < group.size - 1 && itemType !in setOf("divider", "spacer")) CardDivider()
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ArixExtensionControlRow(
    setting: JSONObject,
    page: com.arix.app.data.ArixAppExtensionSettingsPage,
    controller: ArixExtensionUiController?,
    onCategorySelected: (String) -> Unit,
) {
    val uriHandler = LocalUriHandler.current
    val id = "${page.id}:${setting.optString("id")}"
    val type = setting.optString("type").ifBlank { "text" }
    val label = setting.optString("label").ifBlank { setting.optString("title") }
    val description = setting.optString("description").ifBlank { setting.optString("subtitle") }
    val action = setting.optString("action").ifBlank {
        "settings:${page.localId}:${setting.optString("id")}"
    }

    fun update(value: Any?) {
        controller?.onAction?.invoke(
            page.extensionId,
            "settings:${page.localId}:${setting.optString("id")}",
            JSONObject().put("setting", setting.optString("id")).put("value", value),
        )
    }

    when (type) {
        "toggle" -> {
            var checked by remember(id, setting.optBoolean("value")) {
                mutableStateOf(setting.optBoolean("value"))
            }
            Box(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 14.dp)) {
                SettingsToggleRow(label, description, checked) {
                    checked = it
                    update(it)
                }
            }
        }
        "select", "dropdown", "segmented", "tab", "tabs" -> {
            val options = setting.optJSONArray("options") ?: JSONArray()
            var selected by remember(id, setting.optString("value")) {
                mutableStateOf(setting.optString("value"))
            }
            if (type == "segmented" || type == "tab" || type == "tabs") {
                Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp)) {
                    Text(label, style = MaterialTheme.typography.bodyMedium, color = ArixOnSurface)
                    if (description.isNotBlank()) Text(description, style = MaterialTheme.typography.bodySmall, color = ArixOnSurfaceVariant)
                    Spacer(Modifier.height(8.dp))
                    SingleChoiceSegmentedButtonRow(Modifier.fillMaxWidth()) {
                        for (optionIndex in 0 until options.length()) {
                            val option = options.optJSONObject(optionIndex) ?: continue
                            val value = option.optString("value")
                            SegmentedButton(
                                selected = selected == value,
                                onClick = { selected = value; update(value) },
                                shape = SegmentedButtonDefaults.itemShape(optionIndex, options.length()),
                            ) { Text(option.optString("label").ifBlank { value }) }
                        }
                    }
                }
            } else {
                val selectedLabel = (0 until options.length())
                    .mapNotNull(options::optJSONObject)
                    .firstOrNull { it.optString("value") == selected }
                    ?.optString("label")
                    .orEmpty()
                SelectionDropdownField(
                    label = label,
                    supportingText = description,
                    selectedLabel = selectedLabel.ifBlank { selected },
                    options = (0 until options.length()).mapNotNull { optionIndex ->
                        val option = options.optJSONObject(optionIndex) ?: return@mapNotNull null
                        val value = option.optString("value")
                        SelectionOption(
                            key = value,
                            title = option.optString("label").ifBlank { value },
                            subtitle = option.optString("description"),
                            selected = selected == value,
                            onClick = { selected = value; update(value) },
                        )
                    },
                )
            }
        }
        "slider" -> {
            val minimum = setting.optDouble("min", 0.0).toFloat()
            val maximum = setting.optDouble("max", 1.0).toFloat().coerceAtLeast(minimum + 0.0001f)
            val step = setting.optDouble("step", 0.01).toFloat().takeIf { it > 0f } ?: 0.01f
            val discreteSteps = (((maximum - minimum) / step).roundToInt() - 1).coerceAtLeast(0)
            var value by remember(id, setting.optDouble("value", minimum.toDouble())) {
                mutableStateOf(setting.optDouble("value", minimum.toDouble()).toFloat().coerceIn(minimum, maximum))
            }
            Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp)) {
                Text(label, style = MaterialTheme.typography.bodyMedium, color = ArixOnSurface)
                if (description.isNotBlank()) {
                    Text(description, style = MaterialTheme.typography.bodySmall, color = ArixOnSurfaceVariant)
                }
                Slider(
                    value = value,
                    onValueChange = { value = it },
                    onValueChangeFinished = { update(value) },
                    valueRange = minimum..maximum,
                    steps = discreteSteps.takeIf { it in 1..20 } ?: 0,
                )
            }
        }
        "button" -> {
            val buttonIcon = setting.optString("icon")
                .takeIf(String::isNotBlank)
                ?.let(::extensionIcon)
            val buttonModifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp)
            val onClick: () -> Unit = {
                controller?.onAction?.invoke(
                    page.extensionId,
                    action,
                    setting.optJSONObject("args") ?: JSONObject(),
                )
            }
            when (setting.optString("tone").lowercase()) {
                "neutral", "secondary", "danger", "error" -> SettingsSubtleActionButton(
                    label = label,
                    onClick = onClick,
                    modifier = buttonModifier,
                    enabled = setting.optBoolean("enabled", true),
                    icon = buttonIcon,
                )
                else -> SettingsActionButton(
                    label = label,
                    onClick = onClick,
                    modifier = buttonModifier,
                    enabled = setting.optBoolean("enabled", true),
                    icon = buttonIcon,
                )
            }
        }
        "link" -> SettingsNavRow(
            icon = Icons.Rounded.Link,
            title = label,
            subtitle = description,
            enabled = setting.optBoolean("enabled", true),
        ) {
            val category = setting.optString("category")
            val url = setting.optString("url")
            when {
                category.isNotBlank() -> onCategorySelected(category)
                url.isNotBlank() -> runCatching { uriHandler.openUri(url) }
                else -> controller?.onAction?.invoke(
                    page.extensionId,
                    action,
                    setting.optJSONObject("args") ?: JSONObject(),
                )
            }
        }
        "action-row", "chips" -> {
            val actions = setting.optJSONArray("actions") ?: JSONArray()
            Row(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                for (actionIndex in 0 until actions.length()) {
                    val item = actions.optJSONObject(actionIndex) ?: continue
                    val itemLabel = item.optString("label")
                    val itemAction = item.optString("action")
                    val itemCategory = item.optString("category")
                    val itemArgs = item.optJSONObject("args") ?: JSONObject()
                    SettingsSubtleActionButton(
                        label = itemLabel,
                        enabled = item.optBoolean("enabled", true),
                        onClick = {
                            when {
                                itemCategory.isNotBlank() -> onCategorySelected(itemCategory)
                                itemAction.isNotBlank() -> controller?.onAction?.invoke(page.extensionId, itemAction, itemArgs)
                            }
                        },
                        modifier = Modifier.weight(1f),
                    )
                }
            }
        }
        "detail-line", "key-value" -> {
            val value = setting.optString("value").ifBlank { description }
            Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp)) {
                Text(label, style = MaterialTheme.typography.labelSmall, color = ArixOnSurfaceVariant)
                Text(value, style = MaterialTheme.typography.bodySmall, color = ArixOnSurface)
            }
        }
        "pill", "badge" -> {
            Box(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp)) {
                ActionPreviewPill(label)
            }
        }
        "result-card", "callout" -> {
            val value = setting.optString("text").ifBlank { setting.optString("value").ifBlank { label } }
            val title = setting.optString("title")
            Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp)) {
                if (title.isNotBlank()) {
                    Text(title, style = MaterialTheme.typography.labelMedium, color = ArixOnSurface)
                    Spacer(Modifier.height(4.dp))
                }
                Text(value, style = MaterialTheme.typography.bodySmall, color = ArixOnSurfaceVariant)
            }
        }
        "divider" -> CardDivider()
        "spacer" -> Spacer(Modifier.height(setting.optInt("size", 8).coerceAtLeast(1).dp))
        "label" -> Text(label, color = ArixOnSurfaceVariant, modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp))
        else -> {
            var value by rememberSaveable(id, stateSaver = TextFieldValue.Saver) {
                mutableStateOf(TextFieldValue(setting.optString("value")))
            }
            ChatGptTextField(
                label = label,
                value = value,
                minLines = if (type == "textarea" || setting.optBoolean("multiline")) 4 else 1,
                isSecret = type == "password" || setting.optBoolean("secret"),
                placeholder = setting.optString("placeholder").ifBlank { label },
                supportingText = description,
                keyboardOptions = if (type == "number") KeyboardOptions(keyboardType = KeyboardType.Number) else KeyboardOptions.Default,
                onValueChange = { value = it; update(it.text) },
            )
        }
    }
}

@Composable
private fun ArixExtensionItemCard(
    setting: JSONObject,
    page: com.arix.app.data.ArixAppExtensionSettingsPage,
    controller: ArixExtensionUiController?,
    onCategorySelected: (String) -> Unit,
) {
    val id = "${page.id}:${setting.optString("id")}"
    val title = setting.optString("title").ifBlank { setting.optString("label") }
    val subtitle = setting.optString("subtitle").ifBlank { setting.optString("tag") }
    val pill = setting.optString("pill").ifBlank { setting.optString("badge") }
    val editAction = setting.optString("editAction")
    val editCategory = setting.optString("editCategory")
    val editArgs = setting.optJSONObject("editArgs") ?: JSONObject()
    val deleteAction = setting.optString("deleteAction")
    val deleteArgs = setting.optJSONObject("deleteArgs") ?: JSONObject()
    val toggleAction = setting.optString("toggleAction")
    val hasToggle = setting.has("checked") || setting.has("value") || toggleAction.isNotBlank()
    var expanded by rememberSaveable(id) { mutableStateOf(setting.optBoolean("expanded", false)) }
    var checked by remember(id, setting.optBoolean("checked", setting.optBoolean("value", true))) {
        mutableStateOf(setting.optBoolean("checked", setting.optBoolean("value", true)))
    }
    val actions = setting.optJSONArray("actions") ?: JSONArray()
    val details = setting.optJSONArray("details") ?: JSONArray()
    val resultText = setting.optString("resultText").ifBlank { setting.optString("result").ifBlank { setting.optString("status") } }
    val subSettings = setting.optJSONArray("settings") ?: JSONArray()

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(ArixSurfaceHigh)
            .animateContentSize()
            .padding(16.dp),
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold,
                    color = ArixOnSurface,
                )
                if (subtitle.isNotBlank()) {
                    Spacer(Modifier.height(4.dp))
                    Text(
                        text = subtitle,
                        style = MaterialTheme.typography.labelSmall,
                        color = ArixOnSurfaceVariant,
                    )
                }
                if (pill.isNotBlank()) {
                    Spacer(Modifier.height(8.dp))
                    ActionPreviewPill(label = pill)
                }
            }
            IconButton(onClick = { expanded = !expanded }, modifier = Modifier.size(36.dp)) {
                Icon(
                    if (expanded) Icons.Rounded.ArrowDropDown else Icons.AutoMirrored.Rounded.ArrowForwardIos,
                    contentDescription = if (expanded) stringResource(R.string.action_collapse) else stringResource(R.string.action_expand),
                    tint = ArixOnSurfaceVariant,
                    modifier = Modifier.size(20.dp),
                )
            }
            if (editAction.isNotBlank() || editCategory.isNotBlank()) {
                IconButton(
                    onClick = {
                        if (editCategory.isNotBlank()) {
                            onCategorySelected(editCategory)
                        } else if (editAction.isNotBlank()) {
                            controller?.onAction?.invoke(page.extensionId, editAction, editArgs)
                        }
                    },
                    modifier = Modifier.size(36.dp),
                ) {
                    Icon(
                        Icons.Rounded.Edit,
                        contentDescription = stringResource(R.string.action_edit),
                        tint = ArixOnSurface,
                        modifier = Modifier.size(18.dp),
                    )
                }
            }
            if (deleteAction.isNotBlank()) {
                IconButton(
                    onClick = {
                        controller?.onAction?.invoke(page.extensionId, deleteAction, deleteArgs)
                    },
                    modifier = Modifier.size(36.dp),
                ) {
                    Icon(
                        Icons.Rounded.Delete,
                        contentDescription = stringResource(R.string.action_remove),
                        tint = Color(0xFFD25757),
                        modifier = Modifier.size(20.dp),
                    )
                }
            }
        }

        if (hasToggle) {
            Spacer(Modifier.height(12.dp))
            SettingsToggleRow(
                title = "",
                subtitle = "",
                checked = checked,
                onCheckedChange = {
                    checked = it
                    if (toggleAction.isNotBlank()) {
                        controller?.onAction?.invoke(
                            page.extensionId,
                            toggleAction,
                            JSONObject()
                                .put("setting", setting.optString("id"))
                                .put("value", it)
                                .put("checked", it),
                        )
                    }
                },
            )
        }

        if (expanded) {
            if (actions.length() > 0) {
                Spacer(Modifier.height(14.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    for (actionIndex in 0 until actions.length()) {
                        val item = actions.optJSONObject(actionIndex) ?: continue
                        val itemLabel = item.optString("label")
                        val itemAction = item.optString("action")
                        val itemCategory = item.optString("category")
                        val itemArgs = item.optJSONObject("args") ?: JSONObject()
                        SettingsSubtleActionButton(
                            label = itemLabel,
                            enabled = item.optBoolean("enabled", true),
                            onClick = {
                                if (itemCategory.isNotBlank()) {
                                    onCategorySelected(itemCategory)
                                } else if (itemAction.isNotBlank()) {
                                    controller?.onAction?.invoke(page.extensionId, itemAction, itemArgs)
                                }
                            },
                            modifier = Modifier.weight(1f),
                        )
                    }
                }
            }

            if (details.length() > 0) {
                Spacer(Modifier.height(14.dp))
                for (detailIndex in 0 until details.length()) {
                    val detail = details.optJSONObject(detailIndex) ?: continue
                    val detailLabel = detail.optString("label")
                    val detailValue = detail.optString("value")
                    Column(Modifier.fillMaxWidth().padding(top = 8.dp)) {
                        Text(detailLabel, style = MaterialTheme.typography.labelSmall, color = ArixOnSurfaceVariant)
                        Text(detailValue, style = MaterialTheme.typography.bodySmall, color = ArixOnSurface)
                    }
                }
            }

            if (resultText.isNotBlank()) {
                Spacer(Modifier.height(14.dp))
                SettingsCardGroup {
                    Text(
                        text = resultText,
                        modifier = Modifier.padding(16.dp),
                        style = MaterialTheme.typography.bodySmall,
                        color = ArixOnSurfaceVariant,
                    )
                }
            }

            if (subSettings.length() > 0) {
                Spacer(Modifier.height(14.dp))
                SettingsCardGroup {
                    Column {
                        for (subIndex in 0 until subSettings.length()) {
                            val subSetting = subSettings.optJSONObject(subIndex) ?: continue
                            ArixExtensionControlRow(
                                setting = subSetting,
                                page = page,
                                controller = controller,
                                onCategorySelected = onCategorySelected,
                            )
                            val subType = subSetting.optString("type").ifBlank { "text" }
                            if (subIndex < subSettings.length() - 1 && subType !in setOf("divider", "spacer")) CardDivider()
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ArixExtensionEmptyState(
    setting: JSONObject,
    page: com.arix.app.data.ArixAppExtensionSettingsPage,
    controller: ArixExtensionUiController?,
    onCategorySelected: (String) -> Unit,
) {
    val title = setting.optString("title").ifBlank { setting.optString("label") }
    val description = setting.optString("description").ifBlank { setting.optString("subtitle") }
    val buttonLabel = setting.optString("buttonLabel").ifBlank { "Add" }
    val action = setting.optString("action")
    val category = setting.optString("category")
    val args = setting.optJSONObject("args") ?: JSONObject()

    SettingsCardGroup {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            if (title.isNotBlank()) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleMedium,
                    color = ArixOnSurface,
                )
                Spacer(Modifier.height(8.dp))
            }
            if (description.isNotBlank()) {
                Text(
                    text = description,
                    style = MaterialTheme.typography.bodyMedium,
                    color = ArixOnSurfaceVariant,
                )
                Spacer(Modifier.height(16.dp))
            }
            if (buttonLabel.isNotBlank()) {
                SettingsActionButton(
                    label = buttonLabel,
                    onClick = {
                        if (category.isNotBlank()) {
                            onCategorySelected(category)
                        } else if (action.isNotBlank()) {
                            controller?.onAction?.invoke(page.extensionId, action, args)
                        }
                    },
                )
            }
        }
    }
}

@Composable
private fun ArixExtensionSettingsPage(
    page: com.arix.app.data.ArixAppExtensionSettingsPage,
    category: com.arix.app.data.ArixAppExtensionSettingsCategory?,
    onBack: () -> Unit,
    onCategorySelected: (String) -> Unit = {},
) {
    val controller = LocalArixExtensionUiController.current
    val trailingIcon = settingsTrailingIcon(category?.trailingIcon?.ifBlank { null } ?: page.trailingIcon)
    val trailingAction = category?.trailingAction?.ifBlank { null } ?: page.trailingAction
    val trailingCategory = category?.trailingCategory?.ifBlank { null } ?: page.trailingCategory
    val trailingArgs = category?.trailingArgs?.takeIf { it.length() > 0 } ?: page.trailingArgs
    SubPageScaffold(
        title = category?.title ?: page.title,
        onBack = onBack,
        trailingIcon = trailingIcon,
        onTrailingAction = {
            if (!trailingCategory.isNullOrBlank()) {
                onCategorySelected(trailingCategory)
            } else if (trailingAction.isNotBlank()) {
                controller?.onAction?.invoke(page.extensionId, trailingAction, trailingArgs)
            } else {
                onBack()
            }
        },
    ) {
        if (category != null && category.subtitle.isNotBlank()) {
            Text(category.subtitle, style = MaterialTheme.typography.bodySmall, color = ArixOnSurfaceVariant, modifier = Modifier.padding(horizontal = 4.dp))
            Spacer(Modifier.height(12.dp))
        }
        ArixExtensionSettingsSections(category?.sections ?: page.sections, page, controller)
    }
}

private fun settingsTrailingIcon(name: String): ImageVector? {
    if (name.isBlank()) return null
    return when (name.lowercase()) {
        "none", "hidden", "false" -> null
        else -> extensionIcon(name)
    }
}


@Composable
private fun WebToolsPage(
    title: String,
    tavilyApiKeyValue: TextFieldValue,
    onTavilyApiKeyChanged: (TextFieldValue) -> Unit,
    tavilyBaseUrlValue: TextFieldValue,
    onTavilyBaseUrlChanged: (TextFieldValue) -> Unit,
    onBack: () -> Unit,
) {
    SubPageScaffold(
        title = title,
        onBack = onBack,
        trailingIcon = Icons.Rounded.Check,
        onTrailingAction = onBack,
    ) {
        SettingsCardGroup {
            ChatGptTextField(
                label = stringResource(R.string.settings_tavily_api_key),
                value = tavilyApiKeyValue,
                onValueChange = onTavilyApiKeyChanged,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                isSecret = true,
            )
            CardDivider()
            ChatGptTextField(
                label = stringResource(R.string.settings_tavily_base_url),
                value = tavilyBaseUrlValue,
                onValueChange = onTavilyBaseUrlChanged,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri),
            )
        }

        Spacer(Modifier.height(8.dp))
        Text(
            text = stringResource(R.string.settings_web_tools_description),
            style = MaterialTheme.typography.bodySmall,
            color = ArixOnSurfaceVariant,
            modifier = Modifier.padding(horizontal = 4.dp),
        )
    }
}

@Composable
private fun SkillsListPage(
    title: String,
    installedSkills: List<com.arix.app.data.InstalledSkill>,
    onToggleSkillEnabled: (String, Boolean) -> Unit,
    onRemoveSkill: (String) -> Unit,
    onAddNew: () -> Unit,
    onReinstallBuiltIn: (String) -> Unit = {},
    onBack: () -> Unit,
) {
    SubPageScaffold(
        title = title,
        onBack = onBack,
        trailingIcon = Icons.Rounded.Add,
        onTrailingAction = onAddNew,
    ) {
        Text(
            text = stringResource(R.string.settings_skills_description),
            style = MaterialTheme.typography.bodySmall,
            color = ArixOnSurfaceVariant,
            modifier = Modifier.padding(horizontal = 4.dp),
        )

        Spacer(Modifier.height(16.dp))

        // Built-in skills section: everything from the curated catalog that is
        // not currently installed can be re-added with one tap.
        val builtInCatalog = com.arix.app.data.ArixBuiltInSkills.all
        val installedIds = installedSkills.map { it.id }.toSet()
        val removedBuiltIns = builtInCatalog.filter { it.id !in installedIds }
        if (builtInCatalog.isNotEmpty()) {
            Text(
                text = "Built-in skills",
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.SemiBold,
                color = ArixOnSurface,
            )
            Spacer(Modifier.height(8.dp))
            builtInCatalog.forEach { builtIn ->
                val installed = installedSkills.firstOrNull { it.id == builtIn.id }
                if (installed != null) {
                    SkillCard(
                        skill = installed,
                        onToggleEnabled = { enabled -> onToggleSkillEnabled(installed.id, enabled) },
                        onRemove = { onRemoveSkill(installed.id) },
                    )
                } else {
                    RemovedBuiltInSkillCard(
                        name = builtIn.name,
                        description = builtIn.description,
                        onReinstall = { onReinstallBuiltIn(builtIn.id) },
                    )
                }
                Spacer(Modifier.height(12.dp))
            }
            if (installedSkills.any { it.source.kind != com.arix.app.data.SkillInstallKind.Builtin }) {
                Spacer(Modifier.height(8.dp))
                Text(
                    text = "Your skills",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.SemiBold,
                    color = ArixOnSurface,
                )
                Spacer(Modifier.height(8.dp))
            }
        }

        val userSkills = installedSkills.filter {
            it.source.kind != com.arix.app.data.SkillInstallKind.Builtin
        }
        if (installedSkills.isEmpty() && builtInCatalog.isEmpty()) {
            SettingsCardGroup {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    Text(
                        stringResource(R.string.settings_no_skills_installed),
                        style = MaterialTheme.typography.titleMedium,
                        color = ArixOnSurface,
                    )
                    Spacer(Modifier.height(8.dp))
                    Text(
                        stringResource(R.string.settings_import_skills_description),
                        style = MaterialTheme.typography.bodyMedium,
                        color = ArixOnSurfaceVariant,
                    )
                    Spacer(Modifier.height(16.dp))
                    SettingsActionButton(
                        label = stringResource(R.string.settings_add_skill),
                        onClick = onAddNew,
                    )
                }
            }
        } else {
            userSkills.forEach { skill ->
                SkillCard(
                    skill = skill,
                    onToggleEnabled = { enabled -> onToggleSkillEnabled(skill.id, enabled) },
                    onRemove = { onRemoveSkill(skill.id) },
                )
                Spacer(Modifier.height(12.dp))
            }
        }
    }
}

@Composable
private fun RemovedBuiltInSkillCard(
    name: String,
    description: String,
    onReinstall: () -> Unit,
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(ArixSurface.copy(alpha = 0.7f))
            .padding(16.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = name,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold,
                color = ArixOnSurfaceVariant,
            )
            Spacer(Modifier.height(4.dp))
            Text(
                text = description,
                style = MaterialTheme.typography.bodySmall,
                color = ArixOnSurfaceVariant,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
            )
        }
        Spacer(Modifier.width(10.dp))
        Text(
            text = "Add",
            style = MaterialTheme.typography.labelMedium,
            fontWeight = FontWeight.SemiBold,
            color = ArixPrimary,
            modifier = Modifier
                .clip(RoundedCornerShape(10.dp))
                .background(ArixPrimary.copy(alpha = 0.14f))
                .clickable(onClick = onReinstall)
                .padding(horizontal = 14.dp, vertical = 8.dp),
        )
    }
}

@Composable
private fun SkillCard(
    skill: com.arix.app.data.InstalledSkill,
    onToggleEnabled: (Boolean) -> Unit,
    onRemove: () -> Unit,
) {
    var expanded by rememberSaveable(skill.id) { mutableStateOf(false) }
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(ArixSurface)
            .animateContentSize()
            .padding(16.dp),
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = skill.name,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold,
                    color = ArixOnSurface,
                )
                if (skill.description.isNotBlank()) {
                    Spacer(Modifier.height(4.dp))
                    Text(
                        text = skill.description,
                        style = MaterialTheme.typography.bodySmall,
                        color = ArixOnSurfaceVariant,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
                Spacer(Modifier.height(8.dp))
                ActionPreviewPill(label = skill.quickActionLabel())
            }
            IconButton(onClick = { expanded = !expanded }, modifier = Modifier.size(36.dp)) {
                Icon(
                    if (expanded) Icons.Rounded.ArrowDropDown else Icons.AutoMirrored.Rounded.ArrowForwardIos,
                    contentDescription = if (expanded) stringResource(R.string.action_collapse) else stringResource(R.string.action_expand),
                    tint = ArixOnSurfaceVariant,
                    modifier = Modifier.size(20.dp),
                )
            }
            IconButton(onClick = onRemove, modifier = Modifier.size(36.dp)) {
                Icon(
                    Icons.Rounded.Delete,
                    contentDescription = stringResource(R.string.action_remove),
                    tint = Color(0xFFD25757),
                    modifier = Modifier.size(20.dp),
                )
            }
        }

        Spacer(Modifier.height(12.dp))
        SettingsToggleRow(
            title = "",
            subtitle = "",
            checked = skill.isEnabled,
            onCheckedChange = onToggleEnabled,
        )
        if (expanded) {
            Spacer(Modifier.height(14.dp))
            Spacer(Modifier.height(14.dp))
            DetailLine(stringResource(R.string.settings_skill_id), skill.id)
            DetailLine(stringResource(R.string.settings_skill_files), "${skill.resourceEntries.size}")
            DetailLine(stringResource(R.string.settings_skill_allowed_tools), skill.allowedTools.ifEmpty { listOf(stringResource(R.string.settings_any)) }.joinToString(", "))
            if (skill.compatibility.isNotBlank()) {
                DetailLine(stringResource(R.string.settings_skill_compatibility), skill.compatibility)
            }
            if (skill.source.label.isNotBlank()) {
                DetailLine(stringResource(R.string.settings_skill_source), skill.source.label)
            }
            DetailLine(stringResource(R.string.settings_skill_path), skill.skillRootPath)
        }
    }
}

// -----------------------------------------------------------------------------
// Add Skill Page
// -----------------------------------------------------------------------------

@Composable
private fun AddSkillPage(
    title: String,
    onImportSkillFolder: () -> Unit,
    onImportSkillZip: ((Boolean) -> Unit) -> Unit,
    onInstallSkillUrl: (String, (Boolean) -> Unit) -> Unit,
    onBack: () -> Unit,
) {
    var selectedTab by rememberSaveable { mutableIntStateOf(0) }
    var skillUrlValue by rememberSaveable(stateSaver = TextFieldValue.Saver) {
        mutableStateOf(TextFieldValue(""))
    }
    var isInstalling by remember { mutableStateOf(false) }

    val tabOptions = listOf(
        stringResource(R.string.settings_skill_source_folder),
        "Zip",
        "URL",
    )

    SubPageScaffold(title = title, onBack = onBack) {
        Text(
            text = stringResource(R.string.settings_add_skill_description),
            style = MaterialTheme.typography.bodySmall,
            color = ArixOnSurfaceVariant,
            modifier = Modifier.padding(horizontal = 4.dp),
        )

        Spacer(Modifier.height(16.dp))

        // Segmented button row
        SingleChoiceSegmentedButtonRow(modifier = Modifier.fillMaxWidth()) {
            tabOptions.forEachIndexed { index, label ->
                SegmentedButton(
                    shape = SegmentedButtonDefaults.itemShape(index = index, count = tabOptions.size),
                    onClick = { selectedTab = index },
                    selected = selectedTab == index,
                    colors = SegmentedButtonDefaults.colors(
                        activeContainerColor = ArixPrimary,
                        activeContentColor = Color.White,
                        inactiveContainerColor = ArixSurfaceHigh,
                        inactiveContentColor = ArixOnSurface,
                    ),
                ) {
                    Text(label)
                }
            }
        }

        Spacer(Modifier.height(20.dp))

        when (selectedTab) {
            0 -> {
                // Folder import
                SettingsCardGroup {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                    ) {
                        Icon(
                            Icons.Rounded.Folder,
                            contentDescription = null,
                            tint = ArixOnSurfaceVariant,
                            modifier = Modifier.size(48.dp),
                        )
                        Spacer(Modifier.height(12.dp))
                        Text(
                            stringResource(R.string.settings_select_skill_folder_description),
                            style = MaterialTheme.typography.bodyMedium,
                            color = ArixOnSurfaceVariant,
                        )
                        Spacer(Modifier.height(16.dp))
                        SettingsActionButton(
                            label = stringResource(R.string.settings_choose_folder),
                            onClick = {
                                onImportSkillFolder()
                                // Will navigate back via callback on success
                            },
                        )
                    }
                }
            }

            1 -> {
                // Zip import
                SettingsCardGroup {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                    ) {
                        Icon(
                            Icons.Rounded.Folder,
                            contentDescription = null,
                            tint = ArixOnSurfaceVariant,
                            modifier = Modifier.size(48.dp),
                        )
                        Spacer(Modifier.height(12.dp))
                        Text(
                            stringResource(R.string.settings_select_skill_zip_description),
                            style = MaterialTheme.typography.bodyMedium,
                            color = ArixOnSurfaceVariant,
                        )
                        Spacer(Modifier.height(16.dp))
                        SettingsActionButton(
                            label = stringResource(R.string.settings_choose_zip),
                            onClick = {
                                onImportSkillZip {}
                            },
                        )
                    }
                }
            }

            2 -> {
                // URL import
                SettingsCardGroup {
                    ChatGptTextField(
                        label = stringResource(R.string.settings_remote_skill_url),
                        value = skillUrlValue,
                        onValueChange = { skillUrlValue = it },
                    )
                }

                Spacer(Modifier.height(8.dp))
                Text(
                    text = stringResource(R.string.settings_remote_skill_url_description),
                    style = MaterialTheme.typography.bodySmall,
                    color = ArixOnSurfaceVariant,
                    modifier = Modifier.padding(horizontal = 4.dp),
                )

                Spacer(Modifier.height(16.dp))

                if (isInstalling) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.Center,
                    ) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(24.dp),
                            strokeWidth = 2.dp,
                            color = ArixPrimary,
                        )
                        Spacer(Modifier.width(12.dp))
                        Text(stringResource(R.string.settings_installing), color = ArixOnSurfaceVariant)
                    }
                } else {
                    SettingsActionButton(
                        label = stringResource(R.string.settings_install_from_url),
                        onClick = {
                            if (skillUrlValue.text.isNotBlank()) {
                                isInstalling = true
                                onInstallSkillUrl(skillUrlValue.text) { success ->
                                    isInstalling = false
                                    if (success) {
                                        skillUrlValue = TextFieldValue("")
                                    }
                                }
                            }
                        },
                        modifier = Modifier.fillMaxWidth(),
                    )
                }
            }
        }
    }
}

@Composable
private fun NativeModStatusCard(
    state: ArixNativeModState,
    onAllowNativeModsOnNextStart: () -> Unit,
    onDisableNativeModsOnNextStart: () -> Unit,
) {
    val safeMode = state.safeModeActive
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(
                if (safeMode) {
                    Color(0xFFFFB020).copy(alpha = 0.14f)
                } else {
                    ArixSurfaceHigh
                }
            )
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Row(
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Icon(
                imageVector = if (safeMode) {
                    Icons.Rounded.WarningAmber
                } else {
                    Icons.Rounded.Code
                },
                contentDescription = null,
                tint = if (safeMode) Color(0xFFFFB020) else ArixPrimary,
                modifier = Modifier.size(22.dp),
            )
            Text(
                text = stringResource(
                    if (safeMode) {
                        R.string.settings_native_mod_safe_mode_title
                    } else {
                        R.string.settings_native_mod_active_title
                    }
                ),
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold,
                color = ArixOnSurface,
            )
        }
        Text(
            text = if (safeMode) {
                stringResource(R.string.settings_native_mod_safe_mode_body)
            } else {
                stringResource(
                    R.string.settings_native_mod_active_summary,
                    state.loaded.size,
                    state.discovered.size,
                )
            },
            style = MaterialTheme.typography.bodyMedium,
            color = ArixOnSurfaceVariant,
        )
        if (state.suspectedCrashModId.isNotBlank()) {
            Text(
                text = stringResource(
                    R.string.settings_native_mod_suspected,
                    state.suspectedCrashModId,
                ),
                style = MaterialTheme.typography.bodySmall,
                color = ArixOnSurfaceVariant,
            )
        }
        state.failures.take(4).forEach { failure ->
            Text(
                text = stringResource(
                    R.string.settings_native_mod_failure,
                    failure.id,
                    failure.message,
                ),
                style = MaterialTheme.typography.bodySmall,
                color = Color(0xFFFFB020),
            )
        }
        if (state.restartRequired) {
            Text(
                text = stringResource(R.string.settings_native_mod_restart_required),
                style = MaterialTheme.typography.bodySmall,
                color = ArixOnSurface,
                fontWeight = FontWeight.Medium,
            )
        }
        Spacer(Modifier.height(2.dp))
        if (safeMode) {
            SettingsActionButton(
                label = stringResource(R.string.settings_native_mod_enable_next_start),
                onClick = onAllowNativeModsOnNextStart,
                modifier = Modifier.fillMaxWidth(),
            )
        } else {
            SettingsSubtleActionButton(
                label = stringResource(R.string.settings_native_mod_disable_next_start),
                onClick = onDisableNativeModsOnNextStart,
                modifier = Modifier.fillMaxWidth(),
            )
        }
    }
}

@Composable
private fun ScriptExtensionStatusCard(
    runtimeError: String,
    errors: List<ArixAppExtensionError>,
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.72f))
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Row(
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Icon(
                imageVector = Icons.Rounded.WarningAmber,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.error,
                modifier = Modifier.size(22.dp),
            )
            Text(
                text = stringResource(R.string.settings_script_extension_errors_title),
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold,
                color = ArixOnSurface,
            )
        }
        runtimeError.takeIf(String::isNotBlank)?.let { message ->
            Text(
                text = message,
                style = MaterialTheme.typography.bodySmall,
                color = ArixOnSurface,
            )
        }
        errors.takeLast(5).forEach { error ->
            Text(
                text = stringResource(
                    R.string.settings_script_extension_error_item,
                    error.phase,
                    error.extensionId.ifBlank { error.path },
                    error.message,
                ),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.error,
            )
        }
    }
}

@Composable
private fun PiExtensionsPage(
    installedExtensions: List<InstalledPiExtension>,
    hasLoadedInstalledExtensions: Boolean,
    nativeModState: ArixNativeModState,
    catalog: List<PiExtensionCatalogEntry>,
    isLoading: Boolean,
    catalogError: String,
    operationSource: String,
    onRefresh: () -> Unit,
    onUpdate: (String) -> Unit,
    onRemove: (InstalledPiExtension) -> Unit,
    onSetEnabled: (InstalledPiExtension, Boolean) -> Unit,
    onImport: () -> Unit,
    onAllowNativeModsOnNextStart: () -> Unit,
    onDisableNativeModsOnNextStart: () -> Unit,
    onSelectPackage: (PiExtensionCatalogEntry) -> Unit,
    onBack: () -> Unit,
) {
    val scriptExtensionController = LocalArixExtensionUiController.current
    val scriptExtensionErrors = scriptExtensionController?.snapshot?.errors.orEmpty()
    val scriptExtensionRuntimeError = scriptExtensionController?.runtimeError.orEmpty()
    var selectedTab by rememberSaveable { mutableIntStateOf(0) }
    var searchValue by rememberSaveable(stateSaver = TextFieldValue.Saver) {
        mutableStateOf(TextFieldValue(""))
    }
    LaunchedEffect(Unit) {
        onRefresh()
    }
    val installedSources = installedExtensions
        .filter { it.kind == PiExtensionInstallKind.Package }
        .map { it.source }
        .toSet()
    val query = searchValue.text.trim()
    val visibleCatalog = catalog
        .asSequence()
        .filter { entry ->
            query.isBlank() || listOf(
                entry.name,
                entry.description,
                entry.author,
                entry.source,
            ).any { it.contains(query, ignoreCase = true) }
        }
        .take(40)
        .toList()

    SubPageScaffold(
        title = stringResource(R.string.settings_pi_extensions),
        onBack = onBack,
        trailingIcon = Icons.Rounded.FileUpload,
        trailingEnabled = operationSource.isBlank(),
        trailingLoading = operationSource == "import",
        trailingContentDescription = stringResource(R.string.settings_import_extension),
        onTrailingAction = onImport,
    ) {
        Text(
            text = stringResource(R.string.settings_pi_extensions_warning),
            style = MaterialTheme.typography.bodySmall,
            color = ArixOnSurfaceVariant,
            modifier = Modifier.padding(horizontal = 4.dp),
        )

        if (scriptExtensionRuntimeError.isNotBlank() || scriptExtensionErrors.isNotEmpty()) {
            Spacer(Modifier.height(14.dp))
            ScriptExtensionStatusCard(
                runtimeError = scriptExtensionRuntimeError,
                errors = scriptExtensionErrors,
            )
        }

        if (
            nativeModState.safeModeActive ||
            nativeModState.discovered.isNotEmpty() ||
            nativeModState.loaded.isNotEmpty() ||
            nativeModState.failures.isNotEmpty()
        ) {
            Spacer(Modifier.height(14.dp))
            NativeModStatusCard(
                state = nativeModState,
                onAllowNativeModsOnNextStart = onAllowNativeModsOnNextStart,
                onDisableNativeModsOnNextStart = onDisableNativeModsOnNextStart,
            )
        }

        Spacer(Modifier.height(16.dp))

        val tabs = listOf(
            stringResource(R.string.settings_extension_installed),
            stringResource(R.string.settings_extension_discover),
        )
        SingleChoiceSegmentedButtonRow(modifier = Modifier.fillMaxWidth()) {
            tabs.forEachIndexed { index, label ->
                SegmentedButton(
                    shape = SegmentedButtonDefaults.itemShape(index = index, count = tabs.size),
                    onClick = { selectedTab = index },
                    selected = selectedTab == index,
                    colors = SegmentedButtonDefaults.colors(
                        activeContainerColor = ArixPrimary,
                        activeContentColor = ArixOnPrimary,
                        inactiveContainerColor = ArixSurfaceHigh,
                        inactiveContentColor = ArixOnSurface,
                    ),
                ) {
                    Text(label)
                }
            }
        }

        Spacer(Modifier.height(18.dp))

        when (selectedTab) {
            0 -> {
                if (!hasLoadedInstalledExtensions) {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(vertical = 32.dp),
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(22.dp),
                            strokeWidth = 2.dp,
                            color = ArixPrimary,
                        )
                        Spacer(Modifier.width(12.dp))
                        Text(
                            stringResource(R.string.settings_loading_installed_extensions),
                            color = ArixOnSurfaceVariant,
                        )
                    }
                } else if (installedExtensions.isEmpty()) {
                    SettingsCardGroup {
                        Column(
                            modifier = Modifier.fillMaxWidth().padding(24.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                        ) {
                            Text(
                                stringResource(R.string.settings_no_extensions_installed),
                                style = MaterialTheme.typography.titleMedium,
                                color = ArixOnSurface,
                            )
                            Spacer(Modifier.height(8.dp))
                            Text(
                                stringResource(R.string.settings_install_or_import_extension),
                                style = MaterialTheme.typography.bodyMedium,
                                color = ArixOnSurfaceVariant,
                            )
                            Spacer(Modifier.height(16.dp))
                            SettingsActionButton(
                                label = stringResource(R.string.settings_import_extension),
                                onClick = onImport,
                                enabled = operationSource.isBlank(),
                                isLoading = operationSource == "import",
                            )
                        }
                    }
                } else {
                    installedExtensions.forEach { extension ->
                        InstalledPiExtensionCard(
                            extension = extension,
                            isOperating = operationSource == extension.id ||
                                operationSource == extension.source,
                            actionsEnabled = operationSource.isBlank(),
                            onUpdate = { onUpdate(extension.source) },
                            onRemove = { onRemove(extension) },
                            onSetEnabled = { enabled -> onSetEnabled(extension, enabled) },
                        )
                        Spacer(Modifier.height(10.dp))
                    }
                }
            }

            else -> {
                SettingsCardGroup {
                    ChatGptTextField(
                        label = stringResource(R.string.settings_search_extensions),
                        value = searchValue,
                        onValueChange = { searchValue = it },
                    )
                }
                Spacer(Modifier.height(14.dp))

                when {
                    isLoading && catalog.isEmpty() -> {
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(vertical = 32.dp),
                            horizontalArrangement = Arrangement.Center,
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(22.dp),
                                strokeWidth = 2.dp,
                                color = ArixPrimary,
                            )
                            Spacer(Modifier.width(12.dp))
                            Text(
                                stringResource(R.string.settings_loading_extensions),
                                color = ArixOnSurfaceVariant,
                            )
                        }
                    }

                    catalogError.isNotBlank() && catalog.isEmpty() -> {
                        SettingsCardGroup {
                            Column(modifier = Modifier.padding(18.dp)) {
                                Text(
                                    text = catalogError,
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = ArixOnSurfaceVariant,
                                )
                                Spacer(Modifier.height(14.dp))
                                SettingsActionButton(
                                    label = stringResource(R.string.action_retry),
                                    onClick = onRefresh,
                                )
                            }
                        }
                    }

                    visibleCatalog.isEmpty() -> {
                        Text(
                            text = stringResource(R.string.settings_no_extensions_found),
                            style = MaterialTheme.typography.bodyMedium,
                            color = ArixOnSurfaceVariant,
                            modifier = Modifier.padding(vertical = 24.dp, horizontal = 4.dp),
                        )
                    }

                    else -> visibleCatalog.forEach { entry ->
                        PiExtensionCatalogCard(
                            entry = entry,
                            installed = installedSources.contains(entry.source),
                            onClick = { onSelectPackage(entry) },
                        )
                        Spacer(Modifier.height(10.dp))
                    }
                }
            }
        }
    }
}

@Composable
private fun PiExtensionCatalogCard(
    entry: PiExtensionCatalogEntry,
    installed: Boolean,
    onClick: () -> Unit,
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .background(ArixSurfaceHigh)
            .clickable(onClick = onClick)
            .padding(16.dp),
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.Top,
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = entry.name,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold,
                    color = ArixOnSurface,
                )
                Spacer(Modifier.height(4.dp))
                Text(
                    text = buildString {
                        if (entry.author.isNotBlank()) append(entry.author)
                        if (entry.author.isNotBlank() && entry.monthlyDownloads > 0) append(" · ")
                        if (entry.monthlyDownloads > 0) {
                            append(formatExtensionDownloads(entry.monthlyDownloads))
                            append("/mo")
                        }
                    },
                    style = MaterialTheme.typography.bodySmall,
                    color = ArixOnSurfaceVariant,
                )
            }
            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                if (entry.compatibilityIssue != null) {
                    Icon(
                        imageVector = Icons.Rounded.WarningAmber,
                        contentDescription = stringResource(R.string.settings_package_may_be_incompatible),
                        tint = Color(0xFFFFB020),
                        modifier = Modifier.size(22.dp),
                    )
                }
                if (installed) {
                    ActionPreviewPill(
                        label = stringResource(R.string.settings_extension_installed),
                    )
                }
            }
        }
        if (entry.description.isNotBlank()) {
            Spacer(Modifier.height(10.dp))
            Text(
                text = entry.description,
                style = MaterialTheme.typography.bodyMedium,
                color = ArixOnSurfaceVariant,
                maxLines = 3,
                overflow = TextOverflow.Ellipsis,
            )
        }
        Spacer(Modifier.height(10.dp))
        Text(
            text = entry.source,
            style = MaterialTheme.typography.labelMedium,
            color = ArixOnSurfaceVariant,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
        )
    }
}

@Composable
private fun PiPackageDetailPage(
    entry: PiExtensionCatalogEntry,
    details: PiPackageDetails?,
    installed: Boolean,
    isLoading: Boolean,
    error: String,
    isOperating: Boolean,
    onRetry: () -> Unit,
    onInstall: () -> Unit,
    onBack: () -> Unit,
) {
    val uriHandler = LocalUriHandler.current
    val compatibilityIssue = details?.compatibilityIssue ?: entry.compatibilityIssue
    var showInstallWarning by rememberSaveable(entry.source) { mutableStateOf(false) }

    if (showInstallWarning && compatibilityIssue != null) {
        PiPackageInstallWarningDialog(
            packageName = entry.name,
            warning = piPackageCompatibilityMessage(compatibilityIssue),
            onDismiss = { showInstallWarning = false },
            onContinue = {
                showInstallWarning = false
                onInstall()
            },
        )
    }

    SubPageScaffold(
        title = entry.name,
        onBack = onBack,
    ) {
        when {
            isLoading && details == null -> {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(vertical = 40.dp),
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(24.dp),
                        strokeWidth = 2.dp,
                        color = ArixPrimary,
                    )
                    Spacer(Modifier.width(12.dp))
                    Text(
                        text = stringResource(R.string.settings_loading_package_details),
                        color = ArixOnSurfaceVariant,
                    )
                }
            }

            details == null -> {
                SettingsCardGroup {
                    Column(modifier = Modifier.padding(18.dp)) {
                        Text(
                            text = error.ifBlank {
                                stringResource(R.string.settings_package_details_unavailable)
                            },
                            style = MaterialTheme.typography.bodyMedium,
                            color = ArixOnSurfaceVariant,
                        )
                        Spacer(Modifier.height(14.dp))
                        SettingsActionButton(
                            label = stringResource(R.string.action_retry),
                            onClick = onRetry,
                        )
                        if (!installed) {
                            Spacer(Modifier.height(10.dp))
                            if (isOperating) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(22.dp),
                                    strokeWidth = 2.dp,
                                    color = ArixPrimary,
                                )
                            } else {
                                SettingsActionButton(
                                    label = stringResource(R.string.settings_install_package),
                                    onClick = {
                                        if (compatibilityIssue == null) {
                                            onInstall()
                                        } else {
                                            showInstallWarning = true
                                        }
                                    },
                                    modifier = Modifier.fillMaxWidth(),
                                )
                            }
                        }
                    }
                }
            }

            else -> {
                Text(
                    text = details.name,
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.SemiBold,
                    color = ArixOnSurface,
                )
                if (details.description.isNotBlank()) {
                    Spacer(Modifier.height(8.dp))
                    Text(
                        text = details.description,
                        style = MaterialTheme.typography.bodyLarge,
                        color = ArixOnSurfaceVariant,
                    )
                }

                if (compatibilityIssue != null) {
                    Spacer(Modifier.height(16.dp))
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color(0xFFFFB020).copy(alpha = 0.14f))
                            .padding(14.dp),
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        verticalAlignment = Alignment.Top,
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.WarningAmber,
                            contentDescription = null,
                            tint = Color(0xFFFFB020),
                            modifier = Modifier.size(22.dp),
                        )
                        Text(
                            text = piPackageCompatibilityMessage(compatibilityIssue),
                            style = MaterialTheme.typography.bodyMedium,
                            color = ArixOnSurface,
                            modifier = Modifier.weight(1f),
                        )
                    }
                }

                Spacer(Modifier.height(18.dp))
                when {
                    isOperating -> {
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(vertical = 10.dp),
                            horizontalArrangement = Arrangement.Center,
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(22.dp),
                                strokeWidth = 2.dp,
                                color = ArixPrimary,
                            )
                            Spacer(Modifier.width(10.dp))
                            Text(
                                text = stringResource(R.string.settings_installing),
                                color = ArixOnSurfaceVariant,
                            )
                        }
                    }

                    installed -> {
                        ActionPreviewPill(
                            label = stringResource(R.string.settings_extension_installed),
                        )
                    }

                    else -> {
                        SettingsActionButton(
                            label = stringResource(R.string.settings_install_package),
                            onClick = {
                                if (compatibilityIssue == null) {
                                    onInstall()
                                } else {
                                    showInstallWarning = true
                                }
                            },
                            modifier = Modifier.fillMaxWidth(),
                        )
                    }
                }

                Spacer(Modifier.height(20.dp))
                SettingsCardGroup {
                    Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp)) {
                        PackageDetailLine(stringResource(R.string.settings_package_source), details.source)
                        PackageDetailLine(stringResource(R.string.settings_package_version), details.version)
                        PackageDetailLine(stringResource(R.string.settings_package_published), details.published)
                        PackageDetailLine(stringResource(R.string.settings_package_downloads), details.downloads)
                        PackageDetailLine(stringResource(R.string.settings_package_author), details.author)
                        PackageDetailLine(stringResource(R.string.settings_package_license), details.license)
                        PackageDetailLine(stringResource(R.string.settings_package_types), details.types.joinToString(", "))
                        PackageDetailLine(stringResource(R.string.settings_package_size), details.size)
                        PackageDetailLine(stringResource(R.string.settings_package_dependencies), details.dependencies)
                    }
                }

                val links = listOf(
                    stringResource(R.string.settings_package_npm) to details.npmUrl,
                    stringResource(R.string.settings_package_repository) to details.repositoryUrl,
                ).filter { it.second.isNotBlank() }
                if (links.isNotEmpty()) {
                    Spacer(Modifier.height(14.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        links.forEach { (label, url) ->
                            SmallChipButton(
                                label = label,
                                onClick = { runCatching { uriHandler.openUri(url) } },
                            )
                        }
                    }
                }

                if (details.readmeMarkdown.isNotBlank()) {
                    Spacer(Modifier.height(24.dp))
                    Text(
                        text = stringResource(R.string.settings_package_readme),
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold,
                        color = ArixOnSurface,
                    )
                    Spacer(Modifier.height(12.dp))
                    MarkdownContent(
                        markdown = details.readmeMarkdown,
                        onLinkClick = { url -> runCatching { uriHandler.openUri(url) } },
                    )
                }
            }
        }
    }
}

@Composable
private fun PackageDetailLine(
    label: String,
    value: String,
) {
    if (value.isBlank()) return
    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 7.dp),
        horizontalArrangement = Arrangement.spacedBy(14.dp),
        verticalAlignment = Alignment.Top,
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.bodySmall,
            color = ArixOnSurfaceVariant,
            modifier = Modifier.width(96.dp),
        )
        Text(
            text = value,
            style = MaterialTheme.typography.bodyMedium,
            color = ArixOnSurface,
            modifier = Modifier.weight(1f),
        )
    }
}

@Composable
private fun piPackageCompatibilityMessage(
    issue: PiPackageCompatibilityIssue,
): String = when (issue) {
    PiPackageCompatibilityIssue.InteractiveUi ->
        stringResource(R.string.settings_package_incompatible_interactive_ui)
    PiPackageCompatibilityIssue.Theme ->
        stringResource(R.string.settings_package_incompatible_theme)
    PiPackageCompatibilityIssue.Prompt ->
        stringResource(R.string.settings_package_incompatible_prompt)
    PiPackageCompatibilityIssue.Platform ->
        stringResource(R.string.settings_package_incompatible_platform)
}

@Composable
private fun PiPackageInstallWarningDialog(
    packageName: String,
    warning: String,
    onDismiss: () -> Unit,
    onContinue: () -> Unit,
) {
    Dialog(onDismissRequest = onDismiss) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 18.dp)
                .shadow(22.dp, RoundedCornerShape(28.dp), ambientColor = ArixScrim, spotColor = ArixScrim)
                .clip(RoundedCornerShape(28.dp))
                .background(ArixSurfaceHigh)
                .padding(20.dp),
        ) {
            Row(
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Icon(
                    imageVector = Icons.Rounded.WarningAmber,
                    contentDescription = null,
                    tint = Color(0xFFFFB020),
                    modifier = Modifier.size(24.dp),
                )
                Text(
                    text = stringResource(R.string.settings_package_install_warning_title),
                    style = MaterialTheme.typography.titleMedium,
                    color = ArixOnSurface,
                )
            }
            Spacer(Modifier.height(10.dp))
            Text(
                text = stringResource(
                    R.string.settings_package_install_warning_body,
                    packageName,
                    warning,
                ),
                style = MaterialTheme.typography.bodyMedium,
                color = ArixOnSurfaceVariant,
            )
            Spacer(Modifier.height(18.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                SettingsSubtleActionButton(
                    label = stringResource(R.string.action_cancel),
                    onClick = onDismiss,
                    modifier = Modifier.weight(1f),
                )
                SettingsActionButton(
                    label = stringResource(R.string.settings_install_anyway),
                    onClick = onContinue,
                    modifier = Modifier.weight(1f),
                )
            }
        }
    }
}

@Composable
private fun InstalledPiExtensionCard(
    extension: InstalledPiExtension,
    isOperating: Boolean,
    actionsEnabled: Boolean,
    onUpdate: () -> Unit,
    onRemove: () -> Unit,
    onSetEnabled: (Boolean) -> Unit,
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .background(ArixSurfaceHigh)
            .padding(16.dp),
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.Top,
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = extension.name,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold,
                    color = ArixOnSurface,
                )
                if (extension.version.isNotBlank()) {
                    Spacer(Modifier.height(3.dp))
                    Text(
                        text = "v${extension.version}",
                        style = MaterialTheme.typography.bodySmall,
                        color = ArixOnSurfaceVariant,
                    )
                }
            }
            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                if (isOperating) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(22.dp),
                        strokeWidth = 2.dp,
                        color = ArixPrimary,
                    )
                }
                Switch(
                    checked = extension.isEnabled,
                    onCheckedChange = onSetEnabled,
                    enabled = actionsEnabled && !isOperating,
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = ArixOnPrimary,
                        checkedTrackColor = ArixPrimary,
                    ),
                )
            }
        }
        if (extension.description.isNotBlank()) {
            Spacer(Modifier.height(10.dp))
            Text(
                text = extension.description,
                style = MaterialTheme.typography.bodyMedium,
                color = ArixOnSurfaceVariant,
                maxLines = 3,
                overflow = TextOverflow.Ellipsis,
            )
        }
        run {
            val extensionLabel = if (extension.extensionCount > 0) {
                stringResource(R.string.settings_package_extensions_count, extension.extensionCount)
            } else null
            val arixExtensionLabel = if (extension.arixExtensionCount > 0) {
                stringResource(
                    R.string.settings_package_arix_extensions_count,
                    extension.arixExtensionCount,
                )
            } else null
            val nativeEntrypointLabel = if (extension.nativeEntrypointCount > 0) {
                stringResource(
                    R.string.settings_package_native_mods_count,
                    extension.nativeEntrypointCount,
                )
            } else null
            val skillLabel = if (extension.skillCount > 0) {
                stringResource(R.string.settings_package_skills_count, extension.skillCount)
            } else null
            val promptLabel = if (extension.promptCount > 0) {
                stringResource(R.string.settings_package_prompts_count, extension.promptCount)
            } else null
            val themeLabel = if (extension.themeCount > 0) {
                stringResource(R.string.settings_package_themes_count, extension.themeCount)
            } else null
            val resources = listOfNotNull(
                extensionLabel,
                arixExtensionLabel,
                nativeEntrypointLabel,
                skillLabel,
                promptLabel,
                themeLabel,
            )
            if (resources.isNotEmpty()) {
                Spacer(Modifier.height(8.dp))
                Text(
                    text = resources.joinToString(" · "),
                    style = MaterialTheme.typography.bodySmall,
                    color = ArixOnSurfaceVariant,
                )
            }
        }
        Spacer(Modifier.height(10.dp))
        Text(
            text = extension.source,
            style = MaterialTheme.typography.labelMedium,
            color = ArixOnSurfaceVariant,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
        )
        if (!isOperating) {
            Spacer(Modifier.height(12.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                if (extension.kind == PiExtensionInstallKind.Package) {
                    SmallChipButton(
                        label = stringResource(R.string.settings_update),
                        onClick = onUpdate,
                        enabled = actionsEnabled,
                    )
                }
                SmallChipButton(
                    label = stringResource(R.string.action_remove),
                    onClick = onRemove,
                    isDestructive = true,
                    enabled = actionsEnabled,
                )
            }
        }
    }
}

private fun formatExtensionDownloads(downloads: Long): String = when {
    downloads >= 1_000_000 -> String.format(Locale.US, "%.1fM", downloads / 1_000_000.0)
    downloads >= 1_000 -> String.format(Locale.US, "%.1fK", downloads / 1_000.0)
    else -> downloads.toString()
}

// -----------------------------------------------------------------------------
// MCP Servers List Page (Refactored)
// -----------------------------------------------------------------------------

/**
 * v2.6.2: live connection status pill for an MCP server card
 * (Ready = green, Connecting = amber pulse, Disconnected = neutral, Error = red).
 */
@Composable
private fun McpConnectionStatusPill(status: com.arix.app.data.McpConnectionStatus) {
    val (label, container, content) = when (status) {
        com.arix.app.data.McpConnectionStatus.Ready -> Triple("Connected", Color(0xFF1F7A45), Color(0xFFB7F0CC))
        com.arix.app.data.McpConnectionStatus.Connecting -> Triple("Connecting…", Color(0xFF8D6C2F), Color(0xFFFFF3DE))
        com.arix.app.data.McpConnectionStatus.Error -> Triple("Error", Color(0xFF7A1F1F), Color(0xFFF6C6C6))
        com.arix.app.data.McpConnectionStatus.Disconnected -> Triple("Disconnected", Color(0xFF4A4A52), Color(0xFFD6D6DE))
    }
    Text(
        text = label,
        style = MaterialTheme.typography.labelSmall,
        color = content,
        modifier = Modifier
            .clip(RoundedCornerShape(7.dp))
            .background(container)
            .padding(horizontal = 7.dp, vertical = 3.dp),
    )
}

/**
 * v2.6.2 (fix #2 — MCP auto-detect visual): renders the detected tools and
 * option fields of a probed MCP server — connection status header, one card
 * per tool with its call name and field chips (name · type · required), plus
 * resource/prompt counts. E.g. a movie API shows its search tool with the
 * `query`, `title`, `stream`, `poster` fields before the connection is saved.
 */
@OptIn(androidx.compose.foundation.layout.ExperimentalLayoutApi::class)
@Composable
private fun McpDetectionResultCard(detection: com.arix.app.data.McpServerDetection) {
    SettingsCardGroup {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                McpConnectionStatusPill(
                    status = if (detection.ok) {
                        com.arix.app.data.McpConnectionStatus.Ready
                    } else {
                        com.arix.app.data.McpConnectionStatus.Error
                    },
                )
                Spacer(Modifier.width(8.dp))
                Text(
                    text = detection.serverName,
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.SemiBold,
                    color = ArixOnSurface,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f),
                )
            }
            if (detection.ok) {
                if (detection.protocolVersion.isNotBlank()) {
                    Text(
                        text = buildString {
                            append("Protocol ")
                            append(detection.protocolVersion)
                            if (detection.serverInfo.isNotBlank()) append(" · ")
                            append(detection.serverInfo)
                        },
                        style = MaterialTheme.typography.labelSmall,
                        color = ArixOnSurfaceVariant,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
                Text(
                    text = when {
                        detection.tools.isNotEmpty() -> "Detected ${detection.tools.size} tool${if (detection.tools.size == 1) "" else "s"}" +
                            (
                                if (detection.resources.isNotEmpty()) {
                                    " · ${detection.resources.size} resource${if (detection.resources.size == 1) "" else "s"}"
                                } else {
                                    ""
                                }
                                ) +
                                (
                                    if (detection.prompts.isNotEmpty()) {
                                        " · ${detection.prompts.size} prompt${if (detection.prompts.size == 1) "" else "s"}"
                                    } else {
                                        ""
                                    }
                                    )
                        else -> "Connected — the server exposes no tools"
                    },
                    style = MaterialTheme.typography.labelMedium,
                    color = ArixPrimary,
                )
            } else if (detection.errorMessage.isNotBlank()) {
                Text(
                    text = detection.errorMessage,
                    style = MaterialTheme.typography.bodySmall,
                    color = Color(0xFFE5484D),
                    maxLines = 3,
                    overflow = TextOverflow.Ellipsis,
                )
            }
            detection.tools.take(8).forEach { tool ->
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(ArixSurfaceHigher)
                        .padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp),
                ) {
                    Text(
                        text = tool.name,
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.SemiBold,
                        color = ArixOnSurface,
                    )
                    if (tool.description.isNotBlank()) {
                        Text(
                            text = tool.description,
                            style = MaterialTheme.typography.labelSmall,
                            color = ArixOnSurfaceVariant,
                            maxLines = 3,
                            overflow = TextOverflow.Ellipsis,
                        )
                    }
                    if (tool.fields.isNotEmpty()) {
                        Text(
                            text = "Fields",
                            style = MaterialTheme.typography.labelSmall,
                            color = ArixOnSurfaceVariant,
                        )
                        // Flow of field chips: name · type, required ones highlighted.
                        androidx.compose.foundation.layout.FlowRow(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp),
                        ) {
                            tool.fields.take(14).forEach { field ->
                                Text(
                                    text = buildString {
                                        append(field.name)
                                        append(" · ")
                                        append(field.kind.label)
                                        if (field.isRequired) append(" · required")
                                    },
                                    style = MaterialTheme.typography.labelSmall,
                                    color = if (field.isRequired) ArixOnPrimary else ArixOnSurfaceVariant,
                                    maxLines = 1,
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(
                                            if (field.isRequired) ArixPrimary else ArixSurfaceHigh,
                                        )
                                        .padding(horizontal = 8.dp, vertical = 4.dp),
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun McpServersListPage(
    title: String,
    mcpServers: List<com.arix.app.data.McpServerConfig>,
    mcpServerSnapshots: List<com.arix.app.data.McpServerSnapshot> = emptyList(),
    onToggleMcpServerEnabled: (String, Boolean) -> Unit,
    onRemoveMcpServer: (String) -> Unit,
    onTestMcpServer: (String, McpServerTestOperation, (String) -> Unit) -> Unit,
    onEdit: (String) -> Unit,
    onAddNew: () -> Unit,
    onBack: () -> Unit,
) {
    var testResultText by rememberSaveable { mutableStateOf("") }
    // v2.6.2: live connection status per server (auto-refreshed by the
    // ViewModel's snapshot flow — Ready / Connecting / Disconnected / Error).
    val snapshotsById = remember(mcpServerSnapshots) {
        mcpServerSnapshots.associateBy { it.config.id }
    }
    SubPageScaffold(
        title = title,
        onBack = onBack,
        trailingIcon = Icons.Rounded.Add,
        onTrailingAction = onAddNew,
    ) {
        Text(
            text = stringResource(R.string.settings_mcp_servers_description),
            style = MaterialTheme.typography.bodySmall,
            color = ArixOnSurfaceVariant,
            modifier = Modifier.padding(horizontal = 4.dp),
        )

        Spacer(Modifier.height(16.dp))

        if (mcpServers.isEmpty()) {
            SettingsCardGroup {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    Text(
                        stringResource(R.string.settings_no_mcp_servers),
                        style = MaterialTheme.typography.titleMedium,
                        color = ArixOnSurface,
                    )
                    Spacer(Modifier.height(8.dp))
                    Text(
                        stringResource(R.string.settings_add_mcp_server_description),
                        style = MaterialTheme.typography.bodyMedium,
                        color = ArixOnSurfaceVariant,
                    )
                    Spacer(Modifier.height(16.dp))
                    SettingsActionButton(
                        label = stringResource(R.string.settings_add_server),
                        onClick = onAddNew,
                    )
                }
            }
        } else {
            mcpServers.forEach { server ->
                McpServerCard(
                    server = server,
                    snapshot = snapshotsById[server.id],
                    onToggleEnabled = { enabled -> onToggleMcpServerEnabled(server.id, enabled) },
                    onEdit = { onEdit(server.id) },
                    onRemove = { onRemoveMcpServer(server.id) },
                    onTest = { operation ->
                        onTestMcpServer(server.id, operation) { result ->
                            testResultText = result
                        }
                    },
                )
                Spacer(Modifier.height(12.dp))
            }
            if (testResultText.isNotBlank()) {
                SettingsCardGroup {
                    Text(
                        text = testResultText,
                        modifier = Modifier.padding(16.dp),
                        style = MaterialTheme.typography.bodySmall,
                        color = ArixOnSurfaceVariant,
                    )
                }
            }
        }
    }
}

@Composable
private fun McpServerCard(
    server: com.arix.app.data.McpServerConfig,
    snapshot: com.arix.app.data.McpServerSnapshot? = null,
    onToggleEnabled: (Boolean) -> Unit,
    onEdit: () -> Unit,
    onRemove: () -> Unit,
    onTest: (McpServerTestOperation) -> Unit,
) {
    var expanded by rememberSaveable(server.id) { mutableStateOf(false) }
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(ArixSurfaceHigh)
            .animateContentSize()
            .padding(16.dp),
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = server.displayName,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold,
                        color = ArixOnSurface,
                    )
                    Spacer(Modifier.width(8.dp))
                    // v2.6.2: live connection status pill.
                    snapshot?.let { snap ->
                        McpConnectionStatusPill(status = snap.status)
                    }
                }
                Spacer(Modifier.height(4.dp))
                Text(
                    text = server.transport.transportType.storageValue.uppercase(),
                    style = MaterialTheme.typography.labelSmall,
                    color = ArixOnSurfaceVariant,
                )
                // v2.6.2: tools count + error detail straight from the live session.
                snapshot?.let { snap ->
                    if (snap.tools.isNotEmpty()) {
                        Spacer(Modifier.height(4.dp))
                        Text(
                            text = "${snap.tools.size} tools available",
                            style = MaterialTheme.typography.labelSmall,
                            color = ArixPrimary,
                        )
                    }
                    if (snap.status == com.arix.app.data.McpConnectionStatus.Error && snap.errorMessage.isNotBlank()) {
                        Spacer(Modifier.height(4.dp))
                        Text(
                            text = snap.errorMessage,
                            style = MaterialTheme.typography.labelSmall,
                            color = Color(0xFFE5484D),
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis,
                        )
                    }
                }
                Spacer(Modifier.height(8.dp))
                ActionPreviewPill(label = server.quickActionLabel())
            }
            IconButton(onClick = { expanded = !expanded }, modifier = Modifier.size(36.dp)) {
                Icon(
                    if (expanded) Icons.Rounded.ArrowDropDown else Icons.AutoMirrored.Rounded.ArrowForwardIos,
                    contentDescription = if (expanded) stringResource(R.string.action_collapse) else stringResource(R.string.action_expand),
                    tint = ArixOnSurfaceVariant,
                    modifier = Modifier.size(20.dp),
                )
            }
            IconButton(onClick = onEdit, modifier = Modifier.size(36.dp)) {
                Icon(
                    Icons.Rounded.Edit,
                    contentDescription = stringResource(R.string.action_edit),
                    tint = ArixOnSurface,
                    modifier = Modifier.size(18.dp),
                )
            }
            IconButton(onClick = onRemove, modifier = Modifier.size(36.dp)) {
                Icon(
                    Icons.Rounded.Delete,
                    contentDescription = stringResource(R.string.action_remove),
                    tint = Color(0xFFD25757),
                    modifier = Modifier.size(20.dp),
                )
            }
        }

        Spacer(Modifier.height(12.dp))
        SettingsToggleRow(
            title = "",
            subtitle = "",
            checked = server.isEnabled,
            onCheckedChange = onToggleEnabled,
        )
        if (expanded) {
            Spacer(Modifier.height(14.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                SettingsSubtleActionButton(
                    label = stringResource(R.string.settings_mcp_tools),
                    onClick = { onTest(McpServerTestOperation.ListTools) },
                    modifier = Modifier.weight(1f),
                )
                SettingsSubtleActionButton(
                    label = stringResource(R.string.settings_mcp_resources),
                    onClick = { onTest(McpServerTestOperation.ListResources) },
                    modifier = Modifier.weight(1f),
                )
                SettingsSubtleActionButton(
                    label = stringResource(R.string.settings_mcp_prompts),
                    onClick = { onTest(McpServerTestOperation.ListPrompts) },
                    modifier = Modifier.weight(1f),
                )
            }
            Spacer(Modifier.height(14.dp))
            DetailLine(stringResource(R.string.settings_server_id), server.id)
            DetailLine(stringResource(R.string.settings_quick_action), server.quickActionLabel())
            DetailLine(stringResource(R.string.settings_transport), server.transport.transportType.storageValue.uppercase())
            when (val transport = server.transport) {
                is com.arix.app.data.McpTransportConfig.StreamableHttp -> {
                    DetailLine("URL", transport.url)
                    DetailLine(stringResource(R.string.settings_headers), transport.headers.size.toString())
                }

                is com.arix.app.data.McpTransportConfig.StdIo -> {
                    DetailLine(stringResource(R.string.settings_command), transport.command)
                    if (transport.workingDirectory.isNotBlank()) {
                        DetailLine(stringResource(R.string.settings_working_dir), transport.workingDirectory)
                    }
                    DetailLine(stringResource(R.string.settings_environment), transport.environment.size.toString())
                }
            }
            DetailLine(stringResource(R.string.settings_connect_timeout), "${server.connectTimeoutMillis} ms")
            DetailLine(stringResource(R.string.settings_request_timeout), "${server.requestTimeoutMillis} ms")
        }
    }
}

// -----------------------------------------------------------------------------
// Scheduled Tasks
// -----------------------------------------------------------------------------

@Composable
private fun ScheduledTasksPage(
    tasks: List<ScheduledTask>,
    onToggleEnabled: (String, Boolean) -> Unit,
    onRemove: (String) -> Unit,
    onEdit: (String) -> Unit,
    onAddNew: () -> Unit,
    onBack: () -> Unit,
) {
    SubPageScaffold(
        title = stringResource(R.string.settings_scheduled_tasks),
        onBack = onBack,
        trailingIcon = Icons.Rounded.Add,
        onTrailingAction = onAddNew,
    ) {
        Text(
            text = stringResource(R.string.settings_scheduled_tasks_description),
            style = MaterialTheme.typography.bodySmall,
            color = ArixOnSurfaceVariant,
            modifier = Modifier.padding(horizontal = 4.dp),
        )
        Spacer(Modifier.height(16.dp))

        if (tasks.isEmpty()) {
            SettingsCardGroup {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    Text(
                        text = stringResource(R.string.settings_no_scheduled_tasks),
                        style = MaterialTheme.typography.titleMedium,
                        color = ArixOnSurface,
                    )
                    Spacer(Modifier.height(8.dp))
                    Text(
                        text = stringResource(R.string.settings_create_scheduled_task_description),
                        style = MaterialTheme.typography.bodyMedium,
                        color = ArixOnSurfaceVariant,
                    )
                    Spacer(Modifier.height(16.dp))
                    SettingsActionButton(
                        label = stringResource(R.string.settings_add_task),
                        onClick = onAddNew,
                    )
                }
            }
        } else {
            tasks.sortedWith(compareBy<ScheduledTask> { it.nextRunAtMillis ?: Long.MAX_VALUE }.thenBy { it.name })
                .forEach { task ->
                    ScheduledTaskCard(
                        task = task,
                        onToggleEnabled = { enabled -> onToggleEnabled(task.id, enabled) },
                        onEdit = { onEdit(task.id) },
                        onRemove = { onRemove(task.id) },
                    )
                    Spacer(Modifier.height(12.dp))
                }
        }
    }
}

@Composable
private fun ScheduledTaskCard(
    task: ScheduledTask,
    onToggleEnabled: (Boolean) -> Unit,
    onEdit: () -> Unit,
    onRemove: () -> Unit,
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(ArixSurfaceHigh)
            .padding(16.dp),
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = task.name,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold,
                    color = ArixOnSurface,
                )
                Spacer(Modifier.height(4.dp))
                Text(
                    text = task.schedule.summary(),
                    style = MaterialTheme.typography.bodySmall,
                    color = ArixOnSurfaceVariant,
                )
            }
            IconButton(onClick = onEdit, modifier = Modifier.size(36.dp)) {
                Icon(
                    Icons.Rounded.Edit,
                    contentDescription = stringResource(R.string.action_edit),
                    tint = ArixOnSurface,
                    modifier = Modifier.size(18.dp),
                )
            }
            IconButton(onClick = onRemove, modifier = Modifier.size(36.dp)) {
                Icon(
                    Icons.Rounded.Delete,
                    contentDescription = stringResource(R.string.action_delete),
                    tint = Color(0xFFD25757),
                    modifier = Modifier.size(20.dp),
                )
            }
        }
        Spacer(Modifier.height(12.dp))
        Text(
            text = task.prompt.take(160),
            style = MaterialTheme.typography.bodySmall,
            color = ArixOnSurface,
        )
        Spacer(Modifier.height(12.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.Bottom,
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = task.nextRunAtMillis?.formatScheduledTaskTime()
                        ?.let { stringResource(R.string.settings_next_run, it) }
                        ?: stringResource(R.string.settings_no_next_run_scheduled),
                    style = MaterialTheme.typography.bodySmall,
                    color = ArixOnSurfaceVariant,
                )
                Text(
                    text = if (task.createdBy == ScheduledTaskCreator.Agent) {
                        stringResource(R.string.settings_created_by_agent)
                    } else {
                        stringResource(R.string.settings_created_manually)
                    },
                    style = MaterialTheme.typography.labelSmall,
                    color = ArixOnSurfaceVariant,
                )
            }
            Switch(
                checked = task.isEnabled,
                onCheckedChange = onToggleEnabled,
            )
        }
    }
}

@Composable
private fun ScheduledTaskEditPage(
    existingTask: ScheduledTask?,
    onSave: (String, String, ScheduledTaskSchedule, Boolean) -> Unit,
    onBack: () -> Unit,
) {
    val existingInterval = existingTask?.schedule as? ScheduledTaskSchedule.Interval
    val existingDaily = existingTask?.schedule as? ScheduledTaskSchedule.Daily
    val existingWeekly = existingTask?.schedule as? ScheduledTaskSchedule.Weekly
    var nameValue by rememberSaveable(existingTask?.id, stateSaver = TextFieldValue.Saver) {
        mutableStateOf(TextFieldValue(existingTask?.name.orEmpty()))
    }
    var promptValue by rememberSaveable(existingTask?.id, stateSaver = TextFieldValue.Saver) {
        mutableStateOf(TextFieldValue(existingTask?.prompt.orEmpty()))
    }
    var enabledValue by rememberSaveable(existingTask?.id) {
        mutableStateOf(existingTask?.isEnabled ?: true)
    }
    var scheduleMode by rememberSaveable(existingTask?.id) {
        mutableIntStateOf(
            when (existingTask?.schedule) {
                is ScheduledTaskSchedule.Daily -> 1
                is ScheduledTaskSchedule.Weekly -> 2
                else -> 0
            }
        )
    }
    var intervalMinutesValue by rememberSaveable(existingTask?.id, stateSaver = TextFieldValue.Saver) {
        mutableStateOf(TextFieldValue(((existingInterval?.intervalMillis ?: 60L * 60L * 1000L) / 60_000L).toString()))
    }
    var activeStartValue by rememberSaveable(existingTask?.id, stateSaver = TextFieldValue.Saver) {
        mutableStateOf(TextFieldValue(existingInterval?.activeStartMinuteOfDay?.let(::formatTaskMinute).orEmpty()))
    }
    var activeEndValue by rememberSaveable(existingTask?.id, stateSaver = TextFieldValue.Saver) {
        mutableStateOf(TextFieldValue(existingInterval?.activeEndMinuteOfDay?.let(::formatTaskMinute).orEmpty()))
    }
    var dailyTimesValue by rememberSaveable(existingTask?.id, stateSaver = TextFieldValue.Saver) {
        mutableStateOf(TextFieldValue(existingDaily?.timesMinutesOfDay?.joinToString(",") { formatTaskMinute(it) } ?: "09:00"))
    }
    var weeklyDaysValue by rememberSaveable(existingTask?.id, stateSaver = TextFieldValue.Saver) {
        mutableStateOf(TextFieldValue(existingWeekly?.daysOfWeek?.joinToString(",") ?: "1"))
    }
    var weeklyTimeValue by rememberSaveable(existingTask?.id, stateSaver = TextFieldValue.Saver) {
        mutableStateOf(TextFieldValue(existingWeekly?.minuteOfDay?.let(::formatTaskMinute) ?: "09:00"))
    }

    fun buildSchedule(): ScheduledTaskSchedule? = when (scheduleMode) {
        0 -> ScheduledTaskSchedule.Interval(
            intervalMillis = (intervalMinutesValue.text.trim().toLongOrNull() ?: 60L).coerceAtLeast(1L) * 60_000L,
            activeStartMinuteOfDay = parseTaskMinute(activeStartValue.text),
            activeEndMinuteOfDay = parseTaskMinute(activeEndValue.text),
        )
        1 -> parseTaskTimes(dailyTimesValue.text).takeIf { it.isNotEmpty() }?.let { times ->
            ScheduledTaskSchedule.Daily(timesMinutesOfDay = times)
        }
        else -> {
            val days = parseTaskDays(weeklyDaysValue.text)
            val time = parseTaskMinute(weeklyTimeValue.text)
            if (days.isEmpty() || time == null) null else ScheduledTaskSchedule.Weekly(days, time)
        }
    }

    SubPageScaffold(
        title = if (existingTask == null) {
            stringResource(R.string.settings_add_scheduled_task)
        } else {
            stringResource(R.string.settings_edit_scheduled_task)
        },
        onBack = onBack,
        trailingIcon = Icons.Rounded.Check,
        trailingEnabled = nameValue.text.isNotBlank() && promptValue.text.isNotBlank(),
        onTrailingAction = {
            buildSchedule()?.let { schedule ->
                onSave(nameValue.text, promptValue.text, schedule, enabledValue)
            }
        },
    ) {
        SettingsCardGroup {
            ChatGptTextField(
                label = stringResource(R.string.settings_name),
                value = nameValue,
                onValueChange = { nameValue = it },
            )
            CardDivider()
            ChatGptTextField(
                label = stringResource(R.string.settings_prompt),
                value = promptValue,
                minLines = 4,
                onValueChange = { promptValue = it },
            )
        }
        Spacer(Modifier.height(16.dp))
        SettingsCardGroup {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp),
            ) {
                SettingsToggleRow(
                    title = stringResource(R.string.settings_enabled),
                    subtitle = stringResource(R.string.settings_disabled_tasks_saved_subtitle),
                    checked = enabledValue,
                    onCheckedChange = { enabledValue = it },
                )
            }
        }
        Spacer(Modifier.height(16.dp))
        SingleChoiceSegmentedButtonRow(modifier = Modifier.fillMaxWidth()) {
            listOf(
                stringResource(R.string.settings_schedule_interval),
                stringResource(R.string.settings_schedule_daily),
                stringResource(R.string.settings_schedule_weekly),
            ).forEachIndexed { index, label ->
                SegmentedButton(
                    shape = SegmentedButtonDefaults.itemShape(index = index, count = 3),
                    onClick = { scheduleMode = index },
                    selected = scheduleMode == index,
                    colors = SegmentedButtonDefaults.colors(
                        activeContainerColor = ArixPrimary,
                        activeContentColor = Color.White,
                        inactiveContainerColor = ArixSurfaceHigh,
                        inactiveContentColor = ArixOnSurface,
                    ),
                ) {
                    Text(label)
                }
            }
        }
        Spacer(Modifier.height(16.dp))
        SettingsCardGroup {
            when (scheduleMode) {
                0 -> {
                    ChatGptTextField(
                        label = stringResource(R.string.settings_every_n_minutes),
                        value = intervalMinutesValue,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        onValueChange = { intervalMinutesValue = it.copy(text = it.text.filter(Char::isDigit)) },
                    )
                    CardDivider()
                    ChatGptTextField(
                        label = stringResource(R.string.settings_active_start_time),
                        value = activeStartValue,
                        onValueChange = { activeStartValue = it },
                    )
                    CardDivider()
                    ChatGptTextField(
                        label = stringResource(R.string.settings_active_end_time),
                        value = activeEndValue,
                        onValueChange = { activeEndValue = it },
                    )
                }
                1 -> ChatGptTextField(
                    label = stringResource(R.string.settings_times_comma_separated),
                    value = dailyTimesValue,
                    onValueChange = { dailyTimesValue = it },
                )
                else -> {
                    ChatGptTextField(
                        label = stringResource(R.string.settings_days_of_week_input),
                        value = weeklyDaysValue,
                        onValueChange = { weeklyDaysValue = it },
                    )
                    CardDivider()
                    ChatGptTextField(
                        label = stringResource(R.string.settings_time_hhmm),
                        value = weeklyTimeValue,
                        onValueChange = { weeklyTimeValue = it },
                    )
                }
            }
        }
        Spacer(Modifier.height(8.dp))
        Text(
            text = stringResource(R.string.settings_interval_window_hint),
            style = MaterialTheme.typography.bodySmall,
            color = ArixOnSurfaceVariant,
            modifier = Modifier.padding(horizontal = 4.dp),
        )
    }
}

// -----------------------------------------------------------------------------
// Add MCP Server Page
// -----------------------------------------------------------------------------

@Composable
private fun AddMcpServerPage(
    title: String,
    existingServer: com.arix.app.data.McpServerConfig?,
    onDetectMcpServer: (String?, String, String, String, (com.arix.app.data.McpServerDetection) -> Unit) -> Unit = { _, _, _, _, _ -> },
    onSaveHttpMcpServer: (String?, String, String, String) -> Unit,
    onSaveStdIoMcpServer: (String?, String, String, String, String, String, LocalRuntimeId?) -> Unit,
    onBack: () -> Unit,
) {
    val isEditing = existingServer != null
    val existingHttpTransport = existingServer?.transport as? com.arix.app.data.McpTransportConfig.StreamableHttp
    val existingStdIoTransport = existingServer?.transport as? com.arix.app.data.McpTransportConfig.StdIo
    var selectedTab by rememberSaveable(existingServer?.id) {
        mutableIntStateOf(if (existingStdIoTransport != null) 1 else 0)
    }

    // v2.6.2 (fix #2): auto-detect state — probes the entered server and
    // visualizes its tools + option fields before saving. (Plain remember:
    // the detection payload is not parcelable.)
    var isDetecting by rememberSaveable(existingServer?.id) { mutableStateOf(false) }
    var detectionResult by remember(existingServer?.id) { mutableStateOf<com.arix.app.data.McpServerDetection?>(null) }

    var httpServerNameValue by rememberSaveable(existingServer?.id, stateSaver = TextFieldValue.Saver) {
        mutableStateOf(TextFieldValue(existingServer?.displayName.orEmpty()))
    }
    var httpServerUrlValue by rememberSaveable(existingServer?.id, stateSaver = TextFieldValue.Saver) {
        mutableStateOf(TextFieldValue(existingHttpTransport?.url.orEmpty()))
    }
    var httpHeadersValue by rememberSaveable(existingServer?.id, stateSaver = TextFieldValue.Saver) {
        mutableStateOf(
            TextFieldValue(
                existingHttpTransport?.headers
                    ?.joinToString("\n") { header -> "${header.key}=${header.value}" }
                    .orEmpty()
            )
        )
    }

    var stdioServerNameValue by rememberSaveable(existingServer?.id, stateSaver = TextFieldValue.Saver) {
        mutableStateOf(TextFieldValue(existingServer?.displayName.orEmpty()))
    }
    var stdioCommandValue by rememberSaveable(existingServer?.id, stateSaver = TextFieldValue.Saver) {
        mutableStateOf(TextFieldValue(existingStdIoTransport?.command.orEmpty()))
    }
    var stdioArgumentsValue by rememberSaveable(existingServer?.id, stateSaver = TextFieldValue.Saver) {
        mutableStateOf(TextFieldValue(existingStdIoTransport?.arguments?.joinToString(" ").orEmpty()))
    }
    var stdioWorkingDirectoryValue by rememberSaveable(existingServer?.id, stateSaver = TextFieldValue.Saver) {
        mutableStateOf(TextFieldValue(existingStdIoTransport?.workingDirectory.orEmpty()))
    }
    var stdioEnvValue by rememberSaveable(existingServer?.id, stateSaver = TextFieldValue.Saver) {
        mutableStateOf(
            TextFieldValue(
                existingStdIoTransport?.environment
                    ?.joinToString("\n") { env -> "${env.key}=${env.value}" }
                    .orEmpty()
            )
        )
    }
    var stdioRuntimeEnvironment by rememberSaveable(existingServer?.id) {
        mutableStateOf(existingStdIoTransport?.runtimeEnvironment)
    }

    val tabOptions = listOf("HTTP", stringResource(R.string.settings_stdio))

    SubPageScaffold(title = title, onBack = onBack) {
        Text(
            text = if (isEditing) {
                stringResource(R.string.settings_update_mcp_server_description)
            } else {
                stringResource(R.string.settings_add_mcp_server_page_description)
            },
            style = MaterialTheme.typography.bodySmall,
            color = ArixOnSurfaceVariant,
            modifier = Modifier.padding(horizontal = 4.dp),
        )

        Spacer(Modifier.height(16.dp))

        // Segmented button row
        SingleChoiceSegmentedButtonRow(modifier = Modifier.fillMaxWidth()) {
            tabOptions.forEachIndexed { index, label ->
                SegmentedButton(
                    shape = SegmentedButtonDefaults.itemShape(index = index, count = tabOptions.size),
                    onClick = { selectedTab = index },
                    selected = selectedTab == index,
                    colors = SegmentedButtonDefaults.colors(
                        activeContainerColor = ArixPrimary,
                        activeContentColor = Color.White,
                        inactiveContainerColor = ArixSurfaceHigh,
                        inactiveContentColor = ArixOnSurface,
                    ),
                ) {
                    Text(label)
                }
            }
        }

        Spacer(Modifier.height(20.dp))

        when (selectedTab) {
            0 -> {
                // HTTP server
                SettingsCardGroup {
                    ChatGptTextField(stringResource(R.string.settings_server_name), httpServerNameValue) { httpServerNameValue = it }
                    CardDivider()
                    ChatGptTextField(stringResource(R.string.settings_server_url), httpServerUrlValue) { httpServerUrlValue = it }
                    CardDivider()
                    ChatGptTextField(stringResource(R.string.settings_headers), httpHeadersValue, minLines = 2) { httpHeadersValue = it }
                }
                Spacer(Modifier.height(4.dp))
                Text(
                    stringResource(R.string.settings_optional_headers_hint),
                    style = MaterialTheme.typography.bodySmall,
                    color = ArixOnSurfaceVariant,
                    modifier = Modifier.padding(horizontal = 4.dp),
                )
                Spacer(Modifier.height(16.dp))

                // v2.6.2 (fix #2): Auto-detect — connects to the entered server,
                // lists its tools and visualizes every detected option field
                // (name / type / required) before the user commits to saving.
                SettingsSubtleActionButton(
                    label = if (isDetecting) "Detecting fields…" else "Auto-detect fields",
                    onClick = {
                        val name = httpServerNameValue.text.trim()
                        val url = httpServerUrlValue.text.trim()
                        if (url.startsWith("http")) {
                            isDetecting = true
                            detectionResult = null
                            onDetectMcpServer(existingServer?.id, name, url, httpHeadersValue.text) { detection ->
                                isDetecting = false
                                detectionResult = detection
                            }
                        }
                    },
                    modifier = Modifier.fillMaxWidth(),
                )
                detectionResult?.let { detection ->
                    Spacer(Modifier.height(12.dp))
                    McpDetectionResultCard(detection = detection)
                }
                Spacer(Modifier.height(16.dp))
                SettingsActionButton(
                    label = if (isEditing) stringResource(R.string.settings_save_http_server) else stringResource(R.string.settings_add_http_server),
                    onClick = {
                        if (httpServerNameValue.text.isNotBlank() && httpServerUrlValue.text.isNotBlank()) {
                            onSaveHttpMcpServer(
                                existingServer?.id,
                                httpServerNameValue.text,
                                httpServerUrlValue.text,
                                httpHeadersValue.text,
                            )
                        }
                    },
                    modifier = Modifier.fillMaxWidth(),
                )
            }

            1 -> {
                // Stdio server
                SettingsCardGroup {
                    ChatGptTextField(stringResource(R.string.settings_server_name), stdioServerNameValue) { stdioServerNameValue = it }
                    CardDivider()
                    ChatGptTextField(stringResource(R.string.settings_command), stdioCommandValue, minLines = 2) { stdioCommandValue = it }
                    CardDivider()
                    ChatGptTextField(stringResource(R.string.settings_arguments), stdioArgumentsValue, minLines = 2) { stdioArgumentsValue = it }
                    CardDivider()
                    ChatGptTextField(stringResource(R.string.settings_working_directory), stdioWorkingDirectoryValue) { stdioWorkingDirectoryValue = it }
                    CardDivider()
                    ChatGptTextField(stringResource(R.string.settings_environment), stdioEnvValue, minLines = 2) { stdioEnvValue = it }
                }
                Spacer(Modifier.height(4.dp))
                Text(
                    stringResource(R.string.settings_optional_environment_hint),
                    style = MaterialTheme.typography.bodySmall,
                    color = ArixOnSurfaceVariant,
                    modifier = Modifier.padding(horizontal = 4.dp),
                )
                Spacer(Modifier.height(16.dp))
                SettingsCardGroup {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(
                            text = stringResource(R.string.settings_runtime_environment),
                            style = MaterialTheme.typography.labelLarge,
                            color = ArixOnSurface,
                        )
                        Text(
                            text = stringResource(R.string.settings_runtime_environment_default_help),
                            style = MaterialTheme.typography.bodySmall,
                            color = ArixOnSurfaceVariant,
                        )
                        SettingsChoiceRow(
                            title = stringResource(R.string.settings_default_runtime),
                            subtitle = stringResource(R.string.settings_default_runtime_help),
                            selected = stdioRuntimeEnvironment == null,
                            onClick = { stdioRuntimeEnvironment = null },
                        )
                        SettingsChoiceRow(
                            title = "Alpine",
                            subtitle = stringResource(R.string.settings_runtime_alpine_stdio_subtitle),
                            selected = stdioRuntimeEnvironment == LocalRuntimeId.Alpine,
                            onClick = { stdioRuntimeEnvironment = LocalRuntimeId.Alpine },
                        )
                    }
                }
                Spacer(Modifier.height(16.dp))
                SettingsActionButton(
                    label = if (isEditing) stringResource(R.string.settings_save_stdio_server) else stringResource(R.string.settings_add_stdio_server),
                    onClick = {
                        if (stdioServerNameValue.text.isNotBlank() && stdioCommandValue.text.isNotBlank()) {
                            onSaveStdIoMcpServer(
                                existingServer?.id,
                                stdioServerNameValue.text,
                                stdioCommandValue.text,
                                stdioArgumentsValue.text,
                                stdioWorkingDirectoryValue.text,
                                stdioEnvValue.text,
                                stdioRuntimeEnvironment,
                            )
                        }
                    },
                    modifier = Modifier.fillMaxWidth(),
                )
            }
        }
    }
}

// -----------------------------------------------------------------------------

// -----------------------------------------------------------------------------


@Composable
private fun RuntimeCleanupDeveloperSettingsSection(
    autoCleanOldCommandHistory: Boolean,
    oldCommandHistoryRetentionHours: TextFieldValue,
    onAutoCleanOldCommandHistoryChanged: (Boolean) -> Unit,
    onOldCommandHistoryRetentionHoursChanged: (TextFieldValue) -> Unit,
) {
    SettingsCardGroup {
        Column(modifier = Modifier.padding(16.dp)) {
            SettingsToggleRow(
                title = stringResource(R.string.settings_old_command_history_retention_hours),
                subtitle = stringResource(R.string.settings_old_command_history_retention_hours_description),
                checked = autoCleanOldCommandHistory,
                onCheckedChange = onAutoCleanOldCommandHistoryChanged,
            )
            AnimatedVisibility(visible = autoCleanOldCommandHistory) {
                Column {
                    Spacer(Modifier.height(12.dp))
                    ChatGptTextField(
                        value = oldCommandHistoryRetentionHours,
                        onValueChange = { value ->
                            onOldCommandHistoryRetentionHoursChanged(
                                value.copy(text = value.text.filter(Char::isDigit)),
                            )
                        },
                        label = stringResource(R.string.settings_old_command_history_retention_hours_value),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    )
                    Spacer(Modifier.height(4.dp))
                    Text(
                        text = stringResource(R.string.settings_old_command_history_retention_hours_value_description),
                        style = MaterialTheme.typography.bodySmall,
                        color = ArixOnSurfaceVariant,
                        modifier = Modifier.padding(horizontal = 16.dp),
                    )
                }
            }
        }
    }
}

@Composable
private fun RuntimeDefaultsPage(
    title: String,
    alpineReady: Boolean,
    enabledRuntimeIds: Set<LocalRuntimeId>,
    defaultRuntimeId: LocalRuntimeId?,
    onSetDefaultRuntime: (LocalRuntimeId) -> Unit,
    onBack: () -> Unit,
) {
    SubPageScaffold(title = title, onBack = onBack) {
        Text(
            text = stringResource(R.string.settings_runtime_defaults_help_alpine_only),
            style = MaterialTheme.typography.bodySmall,
            color = ArixOnSurfaceVariant,
            modifier = Modifier.padding(horizontal = 4.dp),
        )
        Spacer(Modifier.height(16.dp))
        SettingsCardGroup {
            Column(modifier = Modifier.padding(16.dp)) {
                SettingsChoiceRow(
                    title = "Alpine",
                    subtitle = if (alpineReady) {
                        stringResource(R.string.settings_connected)
                    } else {
                        stringResource(R.string.settings_setup_required)
                    },
                    selected = defaultRuntimeId == LocalRuntimeId.Alpine,
                    onClick = { onSetDefaultRuntime(LocalRuntimeId.Alpine) },
                )
            }
        }
    }
}

@Composable
private fun AlpineSettingsPage(
    title: String,
    setupState: LocalRuntimeSetupState,
    packageProfiles: Map<String, PackageProfileState>,
    installProgress: Map<String, AlpineSetupProgress>,
    isDefaultRuntime: Boolean,
    onInitialize: () -> Unit,
    onReset: () -> Unit,
    onRefresh: () -> Unit,
    onInstallPackageProfile: (String) -> Unit,
    onSetDefault: () -> Unit,
    onOpenTerminal: () -> Unit,
    onOpenFiles: () -> Unit,
    onOpenChrome: () -> Unit,
    onBack: () -> Unit,
) {
    LaunchedEffect(Unit) {
        onRefresh()
    }
    SubPageScaffold(
        title = title,
        onBack = onBack,
        trailingIcon = Icons.Rounded.Terminal,
        trailingEnabled = setupState.isReady,
        trailingContentDescription = stringResource(R.string.settings_open_terminal),
        onTrailingAction = onOpenTerminal,
        secondaryTrailingIcon = Icons.Rounded.Folder,
        secondaryTrailingEnabled = setupState.isReady,
        secondaryTrailingContentDescription = "Open files",
        onSecondaryTrailingAction = onOpenFiles,
        tertiaryTrailingIcon = Icons.Rounded.Public,
        tertiaryTrailingEnabled = packageProfiles["chrome"]?.installed == true,
        tertiaryTrailingContentDescription = stringResource(R.string.settings_open_chrome),
        onTertiaryTrailingAction = onOpenChrome,
    ) {
        Text(
            text = stringResource(R.string.settings_alpine_description),
            style = MaterialTheme.typography.bodySmall,
            color = ArixOnSurfaceVariant,
            modifier = Modifier.padding(horizontal = 4.dp),
        )

        Spacer(Modifier.height(16.dp))

        SettingsCardGroup {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = stringResource(R.string.settings_runtime_status),
                    style = MaterialTheme.typography.labelLarge,
                    color = ArixOnSurface,
                )
                Spacer(Modifier.height(6.dp))
                Text(
                    text = alpineSetupStatusText(setupState),
                    style = MaterialTheme.typography.bodySmall,
                    color = ArixOnSurfaceVariant,
                )
                if (setupState.detail.isNotBlank()) {
                    Spacer(Modifier.height(8.dp))
                    Text(
                        text = setupState.detail,
                        style = MaterialTheme.typography.bodySmall,
                        color = ArixOnSurfaceVariant,
                    )
                }
                Spacer(Modifier.height(14.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    SettingsActionButton(
                        label = when (setupState.issue) {
                            LocalRuntimeIssue.Ready -> stringResource(R.string.settings_ready)
                            else -> stringResource(R.string.settings_initialize)
                        },
                        onClick = onInitialize,
                        modifier = Modifier.weight(1f),
                        enabled = !setupState.isReady,
                    )
                    SettingsSubtleActionButton(
                        label = stringResource(R.string.common_refresh),
                        onClick = onRefresh,
                        modifier = Modifier.weight(1f),
                    )
                }
                Spacer(Modifier.height(10.dp))
                SettingsSubtleActionButton(
                    label = stringResource(R.string.settings_reset_alpine_data),
                    onClick = onReset,
                    modifier = Modifier.fillMaxWidth(),
                )
                if (setupState.isReady && !isDefaultRuntime) {
                    Spacer(Modifier.height(10.dp))
                    SettingsActionButton(
                        label = stringResource(R.string.settings_use_as_default_runtime),
                        onClick = onSetDefault,
                        modifier = Modifier.fillMaxWidth(),
                    )
                }
            }
        }

        Spacer(Modifier.height(16.dp))

        SettingsCardGroup {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = stringResource(R.string.settings_environment_presets),
                    style = MaterialTheme.typography.labelLarge,
                    color = ArixOnSurface,
                )
                Spacer(Modifier.height(6.dp))
                Text(
                    text = stringResource(R.string.settings_environment_presets_description),
                    style = MaterialTheme.typography.bodySmall,
                    color = ArixOnSurfaceVariant,
                )
                Spacer(Modifier.height(12.dp))
                AlpineProfileRow(
                    title = stringResource(R.string.settings_python_environment),
                    subtitle = "python3, pip, virtualenv",
                    profileState = packageProfiles["python"],
                    installProgress = installProgress["python"],
                    enabled = setupState.isReady,
                    onInstall = { onInstallPackageProfile("python") },
                )
                CardDivider()
                AlpineProfileRow(
                    title = stringResource(R.string.settings_node_environment),
                    subtitle = "nodejs, npm",
                    profileState = packageProfiles["node"],
                    installProgress = installProgress["node"],
                    enabled = setupState.isReady,
                    onInstall = { onInstallPackageProfile("node") },
                )
                CardDivider()
                AlpineProfileRow(
                    title = stringResource(R.string.settings_git_ripgrep_tools),
                    subtitle = "git, ripgrep",
                    profileState = packageProfiles["git_search"],
                    installProgress = installProgress["git_search"],
                    enabled = setupState.isReady,
                    onInstall = { onInstallPackageProfile("git_search") },
                )
                CardDivider()
                AlpineProfileRow(
                    title = stringResource(R.string.settings_ssh_tools),
                    subtitle = "openssh-client",
                    profileState = packageProfiles["ssh"],
                    installProgress = installProgress["ssh"],
                    enabled = setupState.isReady,
                    onInstall = { onInstallPackageProfile("ssh") },
                )
                CardDivider()
                // v2.4.3: ADB tools preset — installs Alpine's android-tools
                // (adb + fastboot) so the Alpine terminal can run the ADB
                // daemon, connect to THIS device and execute Android shell
                // commands (see the in-guest `arix-adb` helper).
                AlpineProfileRow(
                    title = stringResource(R.string.settings_adb_tools),
                    subtitle = stringResource(R.string.settings_adb_tools_subtitle),
                    profileState = packageProfiles["adb"],
                    installProgress = installProgress["adb"],
                    enabled = setupState.isReady,
                    onInstall = { onInstallPackageProfile("adb") },
                )
                // v2.7.4 (user request): the "Agent browser" (chromium, noVNC,
                // Noto fonts) preset row was removed from Settings → Alpine.
                // The Browser tab auto-installs the Chromium + noVNC packages
                // on first launch (see AlpineChromeController.
                // ensureChromePackagesInstalled), so the manual entry was
                // redundant.
            }
        }
    }
}

@Composable
private fun AlpineProfileRow(
    title: String,
    subtitle: String,
    profileState: PackageProfileState?,
    installProgress: AlpineSetupProgress?,
    enabled: Boolean,
    onInstall: () -> Unit,
) {
    val isInstalling = installProgress != null
    val progressText = installProgress?.let { alpinePackageProgressText(it) }
    val progressButtonText = installProgress?.let { alpinePackageProgressValue(it) }
    val persistedError = profileState?.lastError
        ?.takeUnless { it == "Installing..." }
        .orEmpty()
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.bodyMedium, color = ArixOnSurface)
            Spacer(Modifier.height(2.dp))
            Text(subtitle, style = MaterialTheme.typography.bodySmall, color = ArixOnSurfaceVariant)
            if (progressText != null) {
                Spacer(Modifier.height(4.dp))
                Text(
                    text = progressText,
                    style = MaterialTheme.typography.bodySmall,
                    color = ArixPrimary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            } else if (persistedError.isNotBlank()) {
                Spacer(Modifier.height(4.dp))
                Text(
                    text = persistedError,
                    style = MaterialTheme.typography.bodySmall,
                    color = ArixOnSurfaceVariant,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                )
            }
        }
        SettingsSubtleActionButton(
            label = when {
                isInstalling -> progressButtonText.orEmpty()
                profileState?.installed == true -> stringResource(R.string.settings_installed)
                else -> stringResource(R.string.common_install)
            },
            onClick = onInstall,
            enabled = enabled && profileState?.installed != true && !isInstalling,
        )
    }
}


@Composable
private fun alpineSetupStatusText(
    setupState: LocalRuntimeSetupState,
): String = when (setupState.issue) {
    LocalRuntimeIssue.Ready -> stringResource(R.string.settings_alpine_status_ready)
    LocalRuntimeIssue.NotConfigured,
    LocalRuntimeIssue.NotInstalled -> stringResource(R.string.settings_alpine_status_not_installed)
    LocalRuntimeIssue.UnsupportedAbi -> stringResource(R.string.settings_alpine_status_unsupported_abi)
    LocalRuntimeIssue.MissingAssets -> stringResource(R.string.settings_alpine_status_missing_assets)
    LocalRuntimeIssue.Failed -> stringResource(R.string.settings_alpine_status_failed)
    LocalRuntimeIssue.PermissionMissing,
    LocalRuntimeIssue.ExternalAppsDisabled,
    LocalRuntimeIssue.DispatchFailed -> stringResource(R.string.settings_alpine_status_not_ready)
}











@Composable
private fun DeveloperSettingsPage(
    title: String,
    onImportAppData: () -> Unit,
    onExportAppData: () -> Unit,
    onExportLogs: () -> Unit,
    developerRoleFallbackProviders: List<LlmProviderConfig>,
    onClearDeveloperRoleFallback: (String) -> Unit,
    autoCleanOldCommandHistory: Boolean,
    oldCommandHistoryRetentionHours: TextFieldValue,
    onAutoCleanOldCommandHistoryChanged: (Boolean) -> Unit,
    onOldCommandHistoryRetentionHoursChanged: (TextFieldValue) -> Unit,
    onBack: () -> Unit,
) {
    SubPageScaffold(title = title, onBack = onBack) {
        Text(
            text = stringResource(R.string.settings_developer_description),
            style = MaterialTheme.typography.bodySmall,
            color = ArixOnSurfaceVariant,
            modifier = Modifier.padding(horizontal = 4.dp),
        )

        Spacer(Modifier.height(16.dp))

        SettingsCardGroup {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = stringResource(R.string.settings_app_data),
                    style = MaterialTheme.typography.labelLarge,
                    color = ArixOnSurface,
                )
                Spacer(Modifier.height(6.dp))
                Text(
                    text = stringResource(R.string.settings_app_data_description),
                    style = MaterialTheme.typography.bodySmall,
                    color = ArixOnSurfaceVariant,
                )
                Spacer(Modifier.height(16.dp))
                SettingsSubtleActionButton(
                    label = stringResource(R.string.settings_import_app_data),
                    onClick = onImportAppData,
                    modifier = Modifier.fillMaxWidth(),
                )
                Spacer(Modifier.height(10.dp))
                SettingsSubtleActionButton(
                    label = stringResource(R.string.settings_export_app_data),
                    onClick = onExportAppData,
                    modifier = Modifier.fillMaxWidth(),
                )
            }
        }

        Spacer(Modifier.height(14.dp))

        SettingsCardGroup {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = stringResource(R.string.settings_logs),
                    style = MaterialTheme.typography.labelLarge,
                    color = ArixOnSurface,
                )
                Spacer(Modifier.height(6.dp))
                Text(
                    text = stringResource(R.string.settings_logs_description),
                    style = MaterialTheme.typography.bodySmall,
                    color = ArixOnSurfaceVariant,
                )
                Spacer(Modifier.height(16.dp))
                SettingsSubtleActionButton(
                    label = stringResource(R.string.settings_export_logs),
                    onClick = onExportLogs,
                    modifier = Modifier.fillMaxWidth(),
                )
            }
        }


        Spacer(Modifier.height(14.dp))

        if (developerRoleFallbackProviders.isNotEmpty()) {
            SettingsCardGroup {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = stringResource(R.string.settings_developer_role_fallbacks),
                        style = MaterialTheme.typography.labelLarge,
                        color = ArixOnSurface,
                    )
                    Spacer(Modifier.height(6.dp))
                    Text(
                        text = stringResource(
                            R.string.settings_developer_role_fallbacks_description,
                        ),
                        style = MaterialTheme.typography.bodySmall,
                        color = ArixOnSurfaceVariant,
                    )
                    developerRoleFallbackProviders.forEach { config ->
                        Spacer(Modifier.height(16.dp))
                        SettingsToggleRow(
                            title = config.name,
                            subtitle = config.providerId,
                            checked = true,
                            onCheckedChange = { enabled ->
                                if (!enabled) onClearDeveloperRoleFallback(config.id)
                            },
                        )
                    }
                }
            }

            Spacer(Modifier.height(14.dp))
        }

        RuntimeCleanupDeveloperSettingsSection(
            autoCleanOldCommandHistory = autoCleanOldCommandHistory,
            oldCommandHistoryRetentionHours = oldCommandHistoryRetentionHours,
            onAutoCleanOldCommandHistoryChanged = onAutoCleanOldCommandHistoryChanged,
            onOldCommandHistoryRetentionHoursChanged = onOldCommandHistoryRetentionHoursChanged,
        )
    }
}

// -----------------------------------------------------------------------------
// Assistant settings page
// -----------------------------------------------------------------------------
// v2.7.3: removed — the Assistant entry was dropped from the Settings hub per
// product decision. The assistant activity itself (quick-settings tile,
// default-assistant role) remains functional; only its settings surface is
// gone. The Voice settings page was already removed in v2.6.1.

// -----------------------------------------------------------------------------
// Shared building blocks
// -----------------------------------------------------------------------------

// Sub-page scaffold

@Composable
private fun AboutPage(
    title: String,
    onOpenWebsite: () -> Unit,
    onOpenPrivacyPolicy: () -> Unit,
    onBack: () -> Unit,
) {
    val releaseLabel = stringResource(R.string.settings_release_summary, BuildConfig.VERSION_NAME)
    SubPageScaffold(title = title, onBack = onBack) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 4.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Image(
                painter = painterResource(R.drawable.arix_mark),
                contentDescription = stringResource(R.string.settings_arix_logo),
                modifier = Modifier.size(112.dp),
            )
            Spacer(Modifier.height(14.dp))
            Text(
                text = "Arix",
                style = MaterialTheme.typography.titleLarge,
                color = ArixOnSurface,
            )
            Spacer(Modifier.height(4.dp))
            Text(
                text = releaseLabel,
                style = MaterialTheme.typography.bodyMedium,
                color = ArixOnSurfaceVariant,
            )
        }

        Spacer(Modifier.height(24.dp))

        SettingsCardGroup {
            AboutInfoRow(label = stringResource(R.string.settings_author), value = stringResource(R.string.settings_author_name))
            CardDivider()
            AboutInfoRow(label = stringResource(R.string.settings_version), value = releaseLabel)
            CardDivider()
            SettingsNavRow(
                icon = Icons.Rounded.Link,
                title = stringResource(R.string.settings_website),
                subtitle = "",
                onClick = onOpenWebsite,
            )
            CardDivider()
            SettingsNavRow(
                icon = Icons.Rounded.Link,
                title = stringResource(R.string.settings_privacy_policy),
                subtitle = "",
                onClick = onOpenPrivacyPolicy,
            )
        }

    }
}

@Composable
private fun AboutInfoRow(
    label: String,
    value: String,
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 15.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.bodyMedium,
            color = ArixOnSurfaceVariant,
            modifier = Modifier.width(84.dp),
        )
        Text(
            text = value,
            style = MaterialTheme.typography.bodyLarge,
            color = ArixOnSurface,
            modifier = Modifier.weight(1f),
        )
    }
}

@Composable
private fun SubPageScaffold(
    title: String,
    onBack: () -> Unit,
    trailingIcon: ImageVector? = null,
    trailingEnabled: Boolean = true,
    trailingLoading: Boolean = false,
    trailingContentDescription: String = title,
    onTrailingAction: (() -> Unit)? = null,
    secondaryTrailingIcon: ImageVector? = null,
    secondaryTrailingEnabled: Boolean = true,
    secondaryTrailingContentDescription: String = title,
    onSecondaryTrailingAction: (() -> Unit)? = null,
    tertiaryTrailingIcon: ImageVector? = null,
    tertiaryTrailingEnabled: Boolean = true,
    tertiaryTrailingContentDescription: String = title,
    onTertiaryTrailingAction: (() -> Unit)? = null,
    content: @Composable () -> Unit,
) {
    var topBarBodyHeightPx by remember { mutableIntStateOf(0) }
    val density = LocalDensity.current
    val fallbackTopBarBodyHeight = with(density) {
        WindowInsets.statusBars.getTop(this).toDp() + 68.dp
    }
    val topBarBodyHeight = with(density) {
        if (topBarBodyHeightPx > 0) topBarBodyHeightPx.toDp() else fallbackTopBarBodyHeight
    }
    Scaffold(
        modifier = Modifier.fillMaxSize(),
        containerColor = ArixSettingsBackground,
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(top = topBarBodyHeight)
                    .padding(horizontal = 20.dp)
                    .imePadding()
                    .navigationBarsPadding(),
            ) {
                Spacer(Modifier.height(6.dp))
                content()
                Spacer(Modifier.height(32.dp))
            }

            SettingsTopBarOverlay(
                modifier = Modifier.align(Alignment.TopCenter),
                title = title,
                onBack = onBack,
                trailingIcon = trailingIcon,
                trailingEnabled = trailingEnabled,
                trailingLoading = trailingLoading,
                trailingContentDescription = trailingContentDescription,
                onTrailingAction = onTrailingAction,
                secondaryTrailingIcon = secondaryTrailingIcon,
                secondaryTrailingEnabled = secondaryTrailingEnabled,
                secondaryTrailingContentDescription = secondaryTrailingContentDescription,
                onSecondaryTrailingAction = onSecondaryTrailingAction,
                tertiaryTrailingIcon = tertiaryTrailingIcon,
                tertiaryTrailingEnabled = tertiaryTrailingEnabled,
                tertiaryTrailingContentDescription = tertiaryTrailingContentDescription,
                onTertiaryTrailingAction = onTertiaryTrailingAction,
                onBodyHeightChanged = { topBarBodyHeightPx = it },
            )
        }
    }
}

// Top bar

@Composable
private fun SettingsTopBarOverlay(
    modifier: Modifier = Modifier,
    title: String,
    onBack: () -> Unit,
    trailingIcon: ImageVector? = null,
    trailingEnabled: Boolean = true,
    trailingLoading: Boolean = false,
    trailingContentDescription: String = title,
    onTrailingAction: (() -> Unit)? = null,
    secondaryTrailingIcon: ImageVector? = null,
    secondaryTrailingEnabled: Boolean = true,
    secondaryTrailingContentDescription: String = title,
    onSecondaryTrailingAction: (() -> Unit)? = null,
    tertiaryTrailingIcon: ImageVector? = null,
    tertiaryTrailingEnabled: Boolean = true,
    tertiaryTrailingContentDescription: String = title,
    onTertiaryTrailingAction: (() -> Unit)? = null,
    onBodyHeightChanged: (Int) -> Unit,
) {
    Column(
        modifier = modifier.fillMaxWidth(),
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(settingsTopOverlayBodyGradient())
                .onSizeChanged { onBodyHeightChanged(it.height) },
        ) {
            SettingsTopBar(
                title = title,
                onBack = onBack,
                trailingIcon = trailingIcon,
                trailingEnabled = trailingEnabled,
                trailingLoading = trailingLoading,
                trailingContentDescription = trailingContentDescription,
                onTrailingAction = onTrailingAction,
                secondaryTrailingIcon = secondaryTrailingIcon,
                secondaryTrailingEnabled = secondaryTrailingEnabled,
                secondaryTrailingContentDescription = secondaryTrailingContentDescription,
                onSecondaryTrailingAction = onSecondaryTrailingAction,
                tertiaryTrailingIcon = tertiaryTrailingIcon,
                tertiaryTrailingEnabled = tertiaryTrailingEnabled,
                tertiaryTrailingContentDescription = tertiaryTrailingContentDescription,
                onTertiaryTrailingAction = onTertiaryTrailingAction,
            )
        }
        Spacer(
            modifier = Modifier
                .fillMaxWidth()
                .height(SettingsTopFadeHeight)
                .background(settingsTopOverlayTailGradient())
        )
    }
}

@Composable
private fun SettingsTopBar(
    title: String,
    onBack: () -> Unit,
    trailingIcon: ImageVector? = null,
    trailingEnabled: Boolean = true,
    trailingLoading: Boolean = false,
    trailingContentDescription: String = title,
    onTrailingAction: (() -> Unit)? = null,
    secondaryTrailingIcon: ImageVector? = null,
    secondaryTrailingEnabled: Boolean = true,
    secondaryTrailingContentDescription: String = title,
    onSecondaryTrailingAction: (() -> Unit)? = null,
    tertiaryTrailingIcon: ImageVector? = null,
    tertiaryTrailingEnabled: Boolean = true,
    tertiaryTrailingContentDescription: String = title,
    onTertiaryTrailingAction: (() -> Unit)? = null,
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .statusBarsPadding()
            .padding(horizontal = 16.dp, vertical = 12.dp),
    ) {
        SettingsCircleButton(
            icon = Icons.AutoMirrored.Rounded.ArrowBack,
            contentDescription = stringResource(R.string.common_back),
            onClick = onBack,
            modifier = Modifier.align(Alignment.CenterStart),
        )
        Text(
            text = title,
            style = MaterialTheme.typography.titleMedium,
            color = ArixOnSurface,
            modifier = Modifier
                .align(Alignment.Center)
                .offset(x = if (tertiaryTrailingIcon != null) (-48).dp else 0.dp),
        )
        Row(
            modifier = Modifier.align(Alignment.CenterEnd),
            horizontalArrangement = Arrangement.spacedBy(4.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            if (tertiaryTrailingIcon != null && onTertiaryTrailingAction != null) {
                SettingsCircleButton(
                    icon = tertiaryTrailingIcon,
                    contentDescription = tertiaryTrailingContentDescription,
                    enabled = tertiaryTrailingEnabled,
                    onClick = onTertiaryTrailingAction,
                )
            }
            if (secondaryTrailingIcon != null && onSecondaryTrailingAction != null) {
                SettingsCircleButton(
                    icon = secondaryTrailingIcon,
                    contentDescription = secondaryTrailingContentDescription,
                    enabled = secondaryTrailingEnabled,
                    onClick = onSecondaryTrailingAction,
                )
            }
            if (trailingLoading) {
                Box(modifier = Modifier.size(44.dp), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(20.dp),
                        strokeWidth = 2.dp,
                        color = ArixPrimary,
                    )
                }
            } else if (trailingIcon != null && onTrailingAction != null) {
                SettingsCircleButton(
                    icon = trailingIcon,
                    contentDescription = trailingContentDescription,
                    enabled = trailingEnabled,
                    onClick = onTrailingAction,
                )
            } else if (secondaryTrailingIcon == null) {
                Spacer(Modifier.size(44.dp))
            }
        }
    }
}

@Composable
private fun alpinePackageProgressText(progress: AlpineSetupProgress): String {
    val value = alpinePackageProgressValue(progress)
    return when (progress.activity) {
        AlpineSetupActivity.Extracting ->
            stringResource(R.string.settings_profile_extracting_rate, value)
        AlpineSetupActivity.Downloading ->
            stringResource(R.string.settings_profile_downloading_rate, value)
        AlpineSetupActivity.Installing ->
            stringResource(R.string.settings_profile_installing_percent, value)
        AlpineSetupActivity.None ->
            stringResource(R.string.settings_profile_processing_rate, value)
    }
}

private fun alpinePackageProgressValue(progress: AlpineSetupProgress): String =
    if (progress.activity == AlpineSetupActivity.Installing) {
        "${progress.progressPercent ?: 0}%"
    } else {
        formatTransferRate(progress.bytesPerSecond)
    }

private fun formatTransferRate(bytesPerSecond: Long): String {
    val rate = bytesPerSecond.coerceAtLeast(0L).toDouble()
    return when {
        rate >= 1024.0 * 1024.0 ->
            String.format(Locale.US, "%.1f MB/s", rate / (1024.0 * 1024.0))
        rate >= 1024.0 ->
            String.format(Locale.US, "%.0f KB/s", rate / 1024.0)
        else -> String.format(Locale.US, "%.0f B/s", rate)
    }
}

@Composable
private fun SettingsCircleButton(
    icon: ImageVector,
    contentDescription: String,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    onClick: () -> Unit,
) {
    Box(
        modifier = modifier
            .size(44.dp)
            .shadow(10.dp, RoundedCornerShape(50), ambientColor = ArixScrim, spotColor = ArixScrim)
            .clip(RoundedCornerShape(50))
            .background(if (enabled) ArixSurface else ArixSurface.copy(alpha = 0.55f))
            .clickable(enabled = enabled, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Icon(
            icon,
            contentDescription = contentDescription,
            tint = if (enabled) ArixOnSurface else ArixOnSurface.copy(alpha = 0.45f),
        )
    }
}
