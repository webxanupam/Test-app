package com.arix.app.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowForward
import androidx.compose.material.icons.rounded.Bolt
import androidx.compose.material.icons.rounded.VerifiedUser
import androidx.compose.material.icons.rounded.ViewInAr
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import com.arix.app.R
import com.arix.app.ui.theme.ArixBackground
import com.arix.app.ui.theme.ArixOnSurface
import com.arix.app.ui.theme.ArixOnSurfaceVariant
import com.arix.app.ui.theme.ArixOutlineSoft
import com.arix.app.ui.theme.ArixPrimary
import com.arix.app.ui.theme.ArixSurface
import com.arix.app.ui.theme.ArixSurfaceVariant
import kotlinx.coroutines.delay

private const val LandingContentFadeDuration = 920
private val LandingTourEasing = CubicBezierEasing(0.22f, 0.84f, 0.18f, 1f)

/**
 * v2.7.0: the single first-run "Get Started" screen (replaces the old
 * multi-step onboarding flow). Matches the reference mock:
 * deep-dark canvas with a violet aura behind the Arix mark, a
 * "Welcome to Arix" headline (brand in violet), three glassy feature
 * cards, and a gradient violet "Get started" pill.
 */
@Composable
fun GetStartedScreen(
    onGetStarted: () -> Unit,
    onSkip: () -> Unit,
) {
    var contentVisible by remember { mutableStateOf(false) }
    var actionsVisible by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        delay(180)
        contentVisible = true
        delay(240)
        actionsVisible = true
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(ArixBackground),
    ) {
        // Soft violet aura behind the mark (radial, clipped to the canvas).
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(320.dp),
        ) {
            Box(
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .padding(top = 74.dp)
                    .size(300.dp)
                    .clip(CircleShape)
                    .background(
                        Brush.radialGradient(
                            colors = listOf(
                                ArixPrimary.copy(alpha = 0.24f),
                                ArixPrimary.copy(alpha = 0.08f),
                                Color.Transparent,
                            ),
                        ),
                    ),
            )
        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState()),
        ) {
            GetStartedTopBar(onSkip = onSkip)
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 28.dp),
            ) {
                Spacer(modifier = Modifier.height(12.dp))
                AnimatedVisibility(
                    visible = contentVisible,
                    modifier = Modifier.fillMaxWidth(),
                    enter = fadeIn(
                        animationSpec = tween(
                            durationMillis = LandingContentFadeDuration,
                            easing = LandingTourEasing,
                        ),
                    ),
                    label = "get_started_hero",
                ) {
                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalAlignment = Alignment.CenterHorizontally,
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            // Glow halo around the app mark.
                            Box(
                                modifier = Modifier
                                    .size(124.dp)
                                    .clip(CircleShape)
                                    .background(
                                        Brush.radialGradient(
                                            colors = listOf(
                                                ArixPrimary.copy(alpha = 0.34f),
                                                ArixPrimary.copy(alpha = 0.10f),
                                                Color.Transparent,
                                            ),
                                        ),
                                    ),
                            )
                            Image(
                                painter = painterResource(R.drawable.arix_mark),
                                contentDescription = stringResource(R.string.onboarding_arix_icon),
                                modifier = Modifier.size(104.dp),
                            )
                        }
                        Spacer(modifier = Modifier.height(26.dp))
                        Text(
                            text = buildAnnotatedString {
                                val title = stringResource(R.string.onboarding_welcome_title)
                                val brandIndex = title.indexOf("Arix")
                                if (brandIndex >= 0) {
                                    append(title.substring(0, brandIndex))
                                    withStyle(SpanStyle(color = ArixPrimary)) {
                                        append("Arix")
                                    }
                                    append(title.substring(brandIndex + 4))
                                } else {
                                    append(title)
                                }
                            },
                            modifier = Modifier.fillMaxWidth(),
                            style = MaterialTheme.typography.headlineMedium.copy(
                                fontWeight = FontWeight.SemiBold,
                            ),
                            color = ArixOnSurface,
                            textAlign = TextAlign.Center,
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = stringResource(R.string.onboarding_welcome_subtitle),
                            modifier = Modifier.fillMaxWidth(),
                            style = MaterialTheme.typography.bodyMedium,
                            color = ArixOnSurfaceVariant,
                            textAlign = TextAlign.Center,
                        )
                    }
                }

                Spacer(modifier = Modifier.height(34.dp))
                AnimatedVisibility(
                    visible = actionsVisible,
                    modifier = Modifier.fillMaxWidth(),
                    enter = fadeIn(
                        animationSpec = tween(
                            durationMillis = LandingContentFadeDuration,
                            easing = LandingTourEasing,
                        ),
                    ) + slideInVertically(
                        animationSpec = tween(
                            durationMillis = 480,
                            easing = LandingTourEasing,
                        ),
                        initialOffsetY = { it / 10 },
                    ),
                    label = "get_started_features",
                ) {
                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        verticalArrangement = Arrangement.spacedBy(12.dp),
                    ) {
                        GetStartedFeatureCard(
                            icon = Icons.Rounded.Bolt,
                            title = stringResource(R.string.get_started_feature_device_title),
                            description = stringResource(
                                R.string.get_started_feature_device_description,
                            ),
                        )
                        GetStartedFeatureCard(
                            icon = Icons.Rounded.ViewInAr,
                            title = stringResource(R.string.get_started_feature_everything_title),
                            description = stringResource(
                                R.string.get_started_feature_everything_description,
                            ),
                        )
                        GetStartedFeatureCard(
                            icon = Icons.Rounded.VerifiedUser,
                            title = stringResource(R.string.get_started_feature_security_title),
                            description = stringResource(
                                R.string.get_started_feature_security_description,
                            ),
                        )
                    }
                }

                Spacer(modifier = Modifier.height(30.dp))
                AnimatedVisibility(
                    visible = actionsVisible,
                    modifier = Modifier.fillMaxWidth(),
                    enter = fadeIn(
                        animationSpec = tween(
                            durationMillis = LandingContentFadeDuration,
                            delayMillis = 160,
                            easing = LandingTourEasing,
                        ),
                    ),
                    label = "get_started_cta",
                ) {
                    Button(
                        onClick = onGetStarted,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(56.dp)
                            .background(
                                brush = Brush.horizontalGradient(
                                    colors = listOf(
                                        Color(0xFFA78BFA),
                                        Color(0xFF7C3AED),
                                    ),
                                ),
                                shape = RoundedCornerShape(28.dp),
                            ),
                        shape = RoundedCornerShape(28.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color.Transparent,
                            contentColor = Color.White,
                        ),
                        contentPadding = androidx.compose.foundation.layout.PaddingValues(
                            start = 24.dp,
                            end = 18.dp,
                        ),
                    ) {
                        Text(
                            text = stringResource(R.string.get_started),
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.SemiBold,
                            ),
                        )
                        Spacer(modifier = Modifier.weight(1f))
                        Icon(
                            imageVector = Icons.AutoMirrored.Rounded.ArrowForward,
                            contentDescription = null,
                            modifier = Modifier.size(20.dp),
                        )
                    }
                }
                Spacer(modifier = Modifier.navigationBarsPadding().height(24.dp))
            }
        }
    }
}

@Composable
private fun GetStartedTopBar(onSkip: () -> Unit) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .background(ArixBackground)
            .statusBarsPadding()
            .padding(horizontal = 12.dp, vertical = 8.dp),
    ) {
        TextButton(onClick = onSkip) {
            Text(
                text = stringResource(R.string.close_label),
                color = ArixOnSurfaceVariant,
                style = MaterialTheme.typography.labelLarge,
            )
        }
    }
}

@Composable
private fun GetStartedFeatureCard(
    icon: ImageVector,
    title: String,
    description: String,
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .background(ArixSurface.copy(alpha = 0.55f))
            .border(
                width = 1.dp,
                color = ArixOutlineSoft.copy(alpha = 0.45f),
                shape = RoundedCornerShape(20.dp),
            )
            .padding(horizontal = 16.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        Box(
            modifier = Modifier
                .size(44.dp)
                .clip(CircleShape)
                .background(ArixSurfaceVariant.copy(alpha = 0.7f)),
            contentAlignment = Alignment.Center,
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = ArixPrimary,
                modifier = Modifier.size(22.dp),
            )
        }
        Column(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(2.dp),
        ) {
            Text(
                text = title,
                style = MaterialTheme.typography.titleMedium.copy(
                    fontWeight = FontWeight.SemiBold,
                ),
                color = ArixOnSurface,
                maxLines = 1,
            )
            Text(
                text = description,
                style = MaterialTheme.typography.bodySmall,
                color = ArixOnSurfaceVariant,
                maxLines = 2,
            )
        }
    }
}
