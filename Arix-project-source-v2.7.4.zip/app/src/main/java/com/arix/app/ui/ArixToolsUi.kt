package com.arix.app.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.foundation.lazy.items as rowItems
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.ChevronRight
import androidx.compose.material.icons.rounded.CloudUpload
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Construction
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.Download
import androidx.compose.material.icons.rounded.InsertDriveFile
import androidx.compose.material.icons.rounded.Link
import androidx.compose.material.icons.rounded.Mail
import androidx.compose.material.icons.rounded.Movie
import androidx.compose.material.icons.rounded.PlayCircle
import androidx.compose.material.icons.rounded.QrCode2
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material.icons.rounded.SmartDisplay
// Android Shell tool removed in v2.4.7 — replaced by ADB-backed system_control.
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.Image
import androidx.compose.ui.platform.LocalContext
// ArixAndroidShell import removed — tool was retired in v2.4.7.
import com.arix.app.data.ArixAnimeSiteClient
import com.arix.app.data.ArixFileShareClient
import com.arix.app.data.ArixMediaApi
import com.arix.app.data.ArixMovieBoxClient
import com.arix.app.data.ArixQrEncoder
import com.arix.app.data.ArixQrPng
import com.arix.app.ui.theme.ArixBackground
import com.arix.app.ui.theme.ArixBackgroundGradientTop
import com.arix.app.ui.theme.ArixOnSurface
import com.arix.app.ui.theme.ArixOnSurfaceVariant
import com.arix.app.ui.theme.ArixOutline
import com.arix.app.ui.theme.ArixPrimary
import com.arix.app.ui.theme.ArixSurface
import com.arix.app.ui.theme.ArixSurfaceHigh
import com.arix.app.ui.theme.ArixSurfaceHigher
import com.arix.app.ui.theme.ArixSurfaceVariant
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject

/* ============================================================ tools hub */

enum class ArixToolId(val title: String, val description: String, val icon: ImageVector) {
    Movies(
        title = "Watch Movies & Series",
        description = "Stream movies and series with search, trending picks and a multi-server player.",
        icon = Icons.Rounded.Movie,
    ),
    QrGenerator(
        title = "QR Code Generator",
        description = "Turn any text, link, or Wi-Fi payload into a scannable QR code — with instant download and share.",
        icon = Icons.Rounded.QrCode2,
    ),
    Anime(
        title = "Watch Anime",
        description = "Latest anime and Hindi-dubbed episodes with multi-server playback.",
        icon = Icons.Rounded.SmartDisplay,
    ),
    FileShare(
        title = "File Share",
        description = "Upload any file and get a direct download link instantly — copy or share it with Server 1, 2, 3, 4 & 5.",
        icon = Icons.Rounded.CloudUpload,
    ),
    // v2.4.7: Android Shell entry removed — replaced by ADB system_control.
}

/**
 * Tools hub — premium dark card grid. Each card has an icon, a title and a
 * description; tapping opens the tool full-screen.
 */
@Composable
fun ArixToolsScreen(
    modifier: Modifier = Modifier,
    bottomBarReserve: Dp = 0.dp,
    onBack: () -> Unit = {},
) {
    var openTool by remember { mutableStateOf<ArixToolId?>(null) }
    BackHandler(enabled = openTool != null) { openTool = null }
    val tool = openTool
    if (tool != null) {
        when (tool) {
            ArixToolId.Movies -> ArixMoviesToolScreen(
                onBack = { openTool = null },
                bottomBarReserve = bottomBarReserve,
            )
            ArixToolId.QrGenerator -> ArixQrToolScreen(
                onBack = { openTool = null },
                bottomBarReserve = bottomBarReserve,
            )
            ArixToolId.Anime -> ArixAimeToolScreen(
                onBack = { openTool = null },
                bottomBarReserve = bottomBarReserve,
            )
            ArixToolId.FileShare -> ArixFileShareToolScreen(
                onBack = { openTool = null },
                bottomBarReserve = bottomBarReserve,
            )
            // v2.4.7: AndroidShell case removed with the enum entry.
        }
        return
    }

    // v2.4.3: premium AMOLED hub — deep navy gradient canvas, glass entry
    // cards and a compact header with a circular back affordance.
    // v2.4.6: layout polish — content moved up (tighter header padding, no
    // extra spacer), tighter card spacing, larger polished cards.
    Column(
        modifier = modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    listOf(ArixBackgroundGradientTop, ArixBackground, ArixSurface)
                )
            )
            .statusBarsPadding()
            .padding(bottom = bottomBarReserve),
    ) {
        ArixToolScreenHeader(
            title = "Tools",
            onBack = onBack,
        )
        // v2.4.7: 14dp spacer so header does not touch the card list.
        Spacer(Modifier.height(14.dp))
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            ArixToolEntry.entries.forEach { entry ->
                ArixToolCard(
                    icon = entry.id.icon,
                    title = entry.id.title,
                    description = entry.id.description,
                    accent = entry.accent,
                    onClick = { openTool = entry.id },
                )
            }
            Spacer(Modifier.height(12.dp))
        }
    }
}

private enum class ArixToolEntry(val id: ArixToolId, val accent: Color) {
    Movies(ArixToolId.Movies, Color(0xFF8B5CF6)),
    Qr(ArixToolId.QrGenerator, Color(0xFF38BDF8)),
    Anime(ArixToolId.Anime, Color(0xFFF472B6)),
    FileShare(ArixToolId.FileShare, Color(0xFF34D399)),
}

@Composable
private fun ArixToolScreenHeader(
    title: String,
    subtitle: String = "",
    onBack: (() -> Unit)? = null,
) {
    // v2.4.7: header rebuilt to match Settings — back at CenterStart,
    // title at Center, no subtitle rendered, generous top/bottom padding.
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .padding(
                start = 12.dp,
                end = 20.dp,
                top = 14.dp,
                bottom = 14.dp,
            ),
    ) {
        if (onBack != null) {
            Box(
                modifier = Modifier
                    .align(Alignment.CenterStart)
                    .size(38.dp)
                    .shadow(
                        elevation = 4.dp,
                        shape = CircleShape,
                        ambientColor = Color(0x22000000),
                        spotColor = Color(0x2A000000),
                    )
                    .clip(CircleShape)
                    .background(ArixSurfaceHigher.copy(alpha = 0.92f))
                    .border(1.dp, Color(0x16FFFFFF), CircleShape)
                    .clickable(onClick = onBack),
                contentAlignment = Alignment.Center,
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Rounded.ArrowBack,
                    contentDescription = "Back",
                    tint = ArixOnSurface,
                    modifier = Modifier.size(19.dp),
                )
            }
        }
        Text(
            text = title,
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.SemiBold,
            fontSize = 20.sp,
            color = ArixOnSurface,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.align(Alignment.Center),
        )
    }
}

@Composable
private fun ArixToolCard(
    icon: ImageVector,
    title: String,
    description: String,
    accent: Color,
    onClick: () -> Unit,
) {
    // v2.4.3: glass entry card — 20dp radius, translucent gradient surface,
    // hairline border, very light shadow. Generous 16dp padding keeps the
    // touch target comfortable.
    // v2.4.6: premium polish — larger 24dp radius, consistent card height
    // (96dp floor so every row reads the same size), larger 58dp icon
    // container, stronger-but-subtle border + shadow depth, tighter text
    // hierarchy (18sp title / 12sp description) and a fixed 30dp chevron
    // slot so every chevron aligns identically across cards. Same icons,
    // labels, colors and click behavior — layout/typography only.
    val cardShape = RoundedCornerShape(24.dp)
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .heightIn(min = 96.dp)
            .shadow(
                elevation = 6.dp,
                shape = cardShape,
                ambientColor = Color(0x28000000),
                spotColor = Color(0x33000000),
            )
            .clip(cardShape)
            .background(
                Brush.verticalGradient(
                    listOf(
                        ArixSurfaceHigh.copy(alpha = 0.82f),
                        ArixSurface.copy(alpha = 0.55f),
                    ),
                ),
            )
            .border(1.dp, Color(0x16FFFFFF), cardShape)
            .clickable(onClick = onClick)
            .padding(horizontal = 18.dp, vertical = 16.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(
            modifier = Modifier
                .size(58.dp)
                .clip(RoundedCornerShape(18.dp))
                .background(
                    Brush.linearGradient(
                        listOf(accent.copy(alpha = 0.30f), accent.copy(alpha = 0.10f))
                    )
                ),
            contentAlignment = Alignment.Center,
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = accent,
                modifier = Modifier.size(28.dp),
            )
        }
        Spacer(Modifier.width(16.dp))
        Column(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(3.dp),
        ) {
            Text(
                text = title,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold,
                fontSize = 17.sp,
                color = ArixOnSurface,
                // v2.3.0: clamp so long tool names can never push the chevron
                // out of bounds or overflow the card.
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            Text(
                text = description,
                style = MaterialTheme.typography.bodySmall,
                fontSize = 12.sp,
                lineHeight = 16.sp,
                color = ArixOnSurfaceVariant,
                maxLines = 3,
                overflow = TextOverflow.Ellipsis,
            )
        }
        // v2.4.6: fixed-size chevron slot — every card's chevron sits in the
        // same 30dp end slot, vertically centered, so the column of chevrons
        // aligns perfectly down the screen.
        Box(
            modifier = Modifier.size(30.dp),
            contentAlignment = Alignment.Center,
        ) {
            Icon(
                imageVector = Icons.Rounded.ChevronRight,
                contentDescription = null,
                tint = ArixOnSurfaceVariant,
                modifier = Modifier.size(22.dp),
            )
        }
    }
}

/* ========================================================== QR tool */

@Composable
private fun ArixQrToolScreen(
    onBack: () -> Unit,
    bottomBarReserve: Dp,
) {
    val context = LocalContext.current
    var payload by remember { mutableStateOf("") }
    var bitmap by remember { mutableStateOf<ImageBitmap?>(null) }
    var providerLabel by remember { mutableStateOf("") }
    var working by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf("") }
    var savedMessage by remember { mutableStateOf("") }
    val scope = rememberCoroutineScope()

    fun generate(value: String) {
        val data = value.trim()
        if (data.isEmpty() || working) return
        working = true
        error = ""
        savedMessage = ""
        scope.launch {
            val result = withContext(Dispatchers.IO) {
                runCatching {
                    // 1. On-device encoder — instant and offline.
                    val matrix = ArixQrEncoder.encode(data.toByteArray(Charsets.UTF_8))
                    val png = ArixQrPng.render(matrix, sizePx = 512)
                    val bmp = android.graphics.BitmapFactory.decodeByteArray(png, 0, png.size)
                    bmp to "On-device"
                }.recoverCatching {
                    // 2. Free API fallback #1 — qrserver.
                    val url = "https://api.qrserver.com/v1/create-qr-code/?size=512x512&data=" +
                        android.net.Uri.encode(data)
                    fetchQrFromApi(url)
                }.recoverCatching {
                    // 3. Free API fallback #2 — quickchart.
                    val url = "https://quickchart.io/qr?size=512&text=" + android.net.Uri.encode(data)
                    fetchQrFromApi(url)
                }.getOrNull()
            }
            working = false
            if (result == null) {
                bitmap = null
                error = "QR generation failed. Check the payload and your connection, then try again."
            } else {
                bitmap = result.first.asImageBitmap()
                providerLabel = result.second
            }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    listOf(ArixBackgroundGradientTop, ArixBackground, ArixSurface)
                )
            )
            .statusBarsPadding()
            .padding(bottom = bottomBarReserve),
    ) {
        ArixToolScreenHeader(title = "QR Code Generator", onBack = onBack)
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            OutlinedTextField(
                value = payload,
                onValueChange = { payload = it },
                placeholder = { Text("Enter text, a link, or a Wi-Fi payload…") },
                modifier = Modifier.fillMaxWidth(),
                minLines = 2,
                shape = RoundedCornerShape(16.dp),
                singleLine = false,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                keyboardActions = KeyboardActions(onDone = { generate(payload) }),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = ArixPrimary,
                    unfocusedBorderColor = ArixOutline,
                    cursorColor = ArixPrimary,
                    focusedTextColor = ArixOnSurface,
                    unfocusedTextColor = ArixOnSurface,
                ),
            )

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ArixQuickPayloadChip("Link") {
                    payload = if (payload.startsWith("http")) payload else "https://"
                }
                ArixQuickPayloadChip("Wi-Fi") {
                    payload = "WIFI:T:WPA;S:YourNetwork;P:YourPassword;;"
                }
                ArixQuickPayloadChip("Email") {
                    payload = "mailto:"
                }
                ArixQuickPayloadChip("Phone") {
                    payload = "tel:"
                }
            }

            ArixToolPrimaryButton(
                label = if (working) "Generating…" else "Generate QR code",
                enabled = payload.isNotBlank() && !working,
                onClick = { generate(payload) },
            )

            if (error.isNotBlank()) {
                ArixToolMessageLine(error, isError = true)
            }
            if (savedMessage.isNotBlank()) {
                ArixToolMessageLine(savedMessage, isError = false)
            }

            bitmap?.let { qr ->
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(20.dp))
                        .background(ArixSurfaceHigh.copy(alpha = 0.95f))
                        .border(1.dp, ArixOutline.copy(alpha = 0.5f), RoundedCornerShape(20.dp))
                        .padding(18.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(14.dp),
                ) {
                    Image(
                        bitmap = qr,
                        contentDescription = "QR code",
                        modifier = Modifier
                            .fillMaxWidth(0.72f)
                            .aspectRatio(1f)
                            .clip(RoundedCornerShape(14.dp)),
                        contentScale = ContentScale.Fit,
                    )
                    Text(
                        text = buildString {
                            append(ArixQrPng.describeData(payload))
                            if (providerLabel.isNotBlank()) append(" · $providerLabel")
                        },
                        style = MaterialTheme.typography.labelSmall,
                        color = ArixOnSurfaceVariant,
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        ArixToolSecondaryButton(
                            label = "Download",
                            icon = Icons.Rounded.Download,
                            onClick = {
                                scope.launch {
                                    val bytes = withContext(Dispatchers.IO) {
                                        runCatching {
                                            val matrix = ArixQrEncoder.encode(payload.trim().toByteArray(Charsets.UTF_8))
                                            ArixQrPng.render(matrix, sizePx = 512)
                                        }.getOrNull()
                                    }
                                    if (bytes == null) {
                                        error = "The QR file could not be produced."
                                        savedMessage = ""
                                    } else {
                                        val saved = runCatching {
                                            com.arix.app.ui.ArixMediaDownloads.saveToDownloads(
                                                context,
                                                "arix-qr-${System.currentTimeMillis()}.png",
                                                "image/png",
                                                bytes,
                                            )
                                            true
                                        }.isSuccess
                                        error = ""
                                        savedMessage = if (saved) "Saved to Downloads." else "Download failed."
                                    }
                                }
                            },
                        )
                        ArixToolSecondaryButton(
                            label = "Share",
                            icon = Icons.Rounded.Share,
                            onClick = {
                                scope.launch {
                                    val bytes = withContext(Dispatchers.IO) {
                                        runCatching {
                                            val matrix = ArixQrEncoder.encode(payload.trim().toByteArray(Charsets.UTF_8))
                                            ArixQrPng.render(matrix, sizePx = 512)
                                        }.getOrNull()
                                    }
                                    if (bytes != null) {
                                        withContext(Dispatchers.Main) {
                                            ArixQrShare.sharePng(context, bytes)
                                        }
                                    } else {
                                        error = "The QR file could not be produced."
                                    }
                                }
                            },
                        )
                    }
                }
            }
            Spacer(Modifier.height(20.dp))
        }
    }
}

/** Downloads a QR PNG from a free public API (fallback path). */
private fun fetchQrFromApi(url: String): Pair<android.graphics.Bitmap, String> {
    val request = okhttp3.Request.Builder()
        .url(url)
        .header("User-Agent", ArixMediaApi.BrowserUserAgent)
        .build()
    ArixMediaApi.httpClient.newCall(request).execute().use { response ->
        if (!response.isSuccessful) error("QR API returned HTTP ${response.code}")
        val bytes = response.body?.byteStream()?.use { it.readBytes() } ?: error("Empty QR response")
        val bitmap = android.graphics.BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
            ?: error("QR API returned an invalid image")
        return bitmap to "qrserver API"
    }
}

@Composable
private fun ArixQuickPayloadChip(label: String, onClick: () -> Unit) {
    Text(
        text = label,
        style = MaterialTheme.typography.labelMedium,
        color = ArixOnSurfaceVariant,
        modifier = Modifier
            .clip(RoundedCornerShape(10.dp))
            .background(ArixSurfaceVariant.copy(alpha = 0.5f))
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 7.dp),
    )
}

/* ==================================================== shared tool bits */

@Composable
internal fun ArixToolPrimaryButton(
    label: String,
    enabled: Boolean = true,
    onClick: () -> Unit,
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(50.dp)
            .clip(RoundedCornerShape(15.dp))
            .background(
                if (enabled) {
                    Brush.horizontalGradient(
                        listOf(ArixPrimary.copy(alpha = 0.85f), ArixPrimary.copy(alpha = 0.6f))
                    )
                } else {
                    Brush.horizontalGradient(
                        listOf(
                            ArixSurfaceVariant.copy(alpha = 0.5f),
                            ArixSurfaceVariant.copy(alpha = 0.5f),
                        )
                    )
                }
            )
            .clickable(enabled = enabled, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.titleSmall,
            fontWeight = FontWeight.SemiBold,
            color = if (enabled) Color(0xFF1D1030) else ArixOnSurfaceVariant,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.padding(horizontal = 14.dp),
        )
    }
}

@Composable
internal fun ArixToolSecondaryButton(
    label: String,
    icon: ImageVector,
    onClick: () -> Unit,
) {
    Row(
        modifier = Modifier
            .clip(RoundedCornerShape(12.dp))
            .background(ArixSurfaceVariant.copy(alpha = 0.55f))
            .border(1.dp, ArixOutline.copy(alpha = 0.5f), RoundedCornerShape(12.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 9.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        Icon(imageVector = icon, contentDescription = null, tint = ArixOnSurface, modifier = Modifier.size(16.dp))
        Text(
            text = label,
            style = MaterialTheme.typography.labelMedium,
            color = ArixOnSurface,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
        )
    }
}

@Composable
internal fun ArixToolMessageLine(text: String, isError: Boolean, modifier: Modifier = Modifier) {
    Text(
        text = text,
        style = MaterialTheme.typography.bodySmall,
        color = if (isError) Color(0xFFE5757A) else ArixPrimary,
        modifier = modifier.fillMaxWidth(),
        maxLines = 3,
        overflow = TextOverflow.Ellipsis,
    )
}

@Composable
internal fun ArixToolProviderChip(
    label: String,
    selected: Boolean,
    onClick: () -> Unit,
) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(12.dp))
            .background(
                if (selected) ArixPrimary.copy(alpha = 0.22f)
                else ArixSurfaceVariant.copy(alpha = 0.45f)
            )
            .border(
                width = 1.dp,
                color = if (selected) ArixPrimary.copy(alpha = 0.55f) else ArixOutline.copy(alpha = 0.4f),
                shape = RoundedCornerShape(12.dp),
            )
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 8.dp),
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelMedium,
            fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal,
            color = if (selected) ArixPrimary else ArixOnSurfaceVariant,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
        )
    }
}

/**
 * v2.4.3: premium pill search field — fully rounded 50dp glass bar with a
 * violet focus ring, leading search glyph, trailing clear button and a
 * compact gradient action chip. Reads as one polished control on the AMOLED
 * background instead of a boxed outline field.
 */
@Composable
internal fun ArixToolSearchField(
    value: String,
    onValueChange: (String) -> Unit,
    onSearch: () -> Unit,
    placeholder: String,
) {
    var focused by remember { mutableStateOf(false) }
    val fieldShape = RoundedCornerShape(percent = 50)
    val borderColor by animateColorAsState(
        targetValue = if (focused) ArixPrimary.copy(alpha = 0.65f) else Color(0x14FFFFFF),
        animationSpec = tween(durationMillis = 160),
        label = "tool_search_border",
    )
    BasicTextField(
        value = value,
        onValueChange = onValueChange,
        singleLine = true,
        textStyle = MaterialTheme.typography.bodyMedium.copy(
            color = ArixOnSurface,
        ),
        cursorBrush = Brush.verticalGradient(listOf(ArixPrimary, ArixPrimary)),
        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
        keyboardActions = KeyboardActions(onSearch = { onSearch() }),
        modifier = Modifier
            .fillMaxWidth()
            .shadow(
                elevation = 5.dp,
                shape = fieldShape,
                ambientColor = Color(0x24000000),
                spotColor = Color(0x2C000000),
            )
            .clip(fieldShape)
            .background(
                Brush.horizontalGradient(
                    listOf(
                        ArixSurfaceHigh.copy(alpha = 0.85f),
                        ArixSurface.copy(alpha = 0.62f),
                    ),
                ),
            )
            .border(1.dp, borderColor, fieldShape)
            .onFocusChanged { focused = it.isFocused },
        decorationBox = { innerTextField ->
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(min = 50.dp)
                    .padding(start = 16.dp, end = 7.dp, top = 6.dp, bottom = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                Icon(
                    imageVector = Icons.Rounded.Search,
                    contentDescription = null,
                    tint = if (focused) ArixPrimary else ArixOnSurfaceVariant.copy(alpha = 0.85f),
                    modifier = Modifier.size(18.dp),
                )
                Box(
                    modifier = Modifier.weight(1f),
                    contentAlignment = Alignment.CenterStart,
                ) {
                    if (value.isEmpty()) {
                        Text(
                            text = placeholder,
                            style = MaterialTheme.typography.bodyMedium,
                            color = ArixOnSurfaceVariant.copy(alpha = 0.75f),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                        )
                    }
                    innerTextField()
                }
                if (value.isNotEmpty()) {
                    Box(
                        modifier = Modifier
                            .size(28.dp)
                            .clip(CircleShape)
                            .background(ArixSurfaceVariant.copy(alpha = 0.55f))
                            .clickable { onValueChange("") },
                        contentAlignment = Alignment.Center,
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Close,
                            contentDescription = "Clear",
                            tint = ArixOnSurfaceVariant,
                            modifier = Modifier.size(14.dp),
                        )
                    }
                }
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(
                            Brush.linearGradient(
                                listOf(
                                    Color(0xFF9D6BFF).copy(alpha = 0.85f),
                                    Color(0xFF6E3FE8).copy(alpha = 0.85f),
                                ),
                            ),
                        )
                        .clickable(onClick = onSearch),
                    contentAlignment = Alignment.Center,
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Search,
                        contentDescription = "Search",
                        tint = Color(0xFFF6F2FF),
                        modifier = Modifier.size(17.dp),
                    )
                }
            }
        },
    )
}

/* ======================================================= movies tool */

/**
 * v2.4.1: the CineHub/Cinemeta provider was removed after repeated embed
 * failures — MovieBox is now the single, always-on source with category
 * chips, search, episodes, subtitles and downloads.
 */
@Composable
private fun ArixMoviesToolScreen(
    onBack: () -> Unit,
    bottomBarReserve: Dp,
) {
    var query by remember { mutableStateOf("") }

    // MovieBox provider state
    var boxItems by remember { mutableStateOf<List<ArixMovieBoxClient.Subject>>(emptyList()) }
    var boxPage by remember { mutableStateOf(1) }
    var boxMode by remember { mutableStateOf("latest") } // latest | search | category
    var boxLoading by remember { mutableStateOf(false) }
    var boxError by remember { mutableStateOf("") }
    var boxDetail by remember { mutableStateOf<ArixMovieBoxClient.Detail?>(null) }
    var boxPlaying by remember { mutableStateOf(false) }
    // v2.3.0: every browse section the Movie tab exposes (Trending Movie,
    // Action, Horror, …) surfaced as chips, exactly like the site.
    var boxCategories by remember { mutableStateOf<List<ArixMovieBoxClient.Category>>(emptyList()) }
    var boxCategory by remember { mutableStateOf("") }

    val scope = rememberCoroutineScope()

    fun loadBox(page: Int, mode: String, keyword: String) {
        boxLoading = true
        boxError = ""
        scope.launch {
            val result = withContext(Dispatchers.IO) {
                runCatching {
                    if (mode == "search") {
                        ArixMovieBoxClient.search(keyword, page = page, perPage = 36)
                    } else {
                        // v2.3.0: browse defaults to LATEST — the trending feed
                        // re-ordered by release date (newest first), matching
                        // what the user asked for instead of “Trending now”.
                        ArixMovieBoxClient.trending(page = page, perPage = 36)
                            .sortedByDescending { it.year }
                    }
                }.getOrElse { emptyList() }
            }
            boxLoading = false
            boxItems = result
            boxPage = page
            boxMode = mode
            if (result.isEmpty()) {
                boxError = if (mode == "search") {
                    "No results found for \"$keyword\"."
                } else {
                    "Could not reach MovieBox right now — check your connection and retry."
                }
            }
        }
    }

    fun selectBoxCategory(category: ArixMovieBoxClient.Category) {
        boxCategory = category.title
        boxMode = "category"
        boxItems = category.items
        boxError = ""
    }

    // Initial load
    LaunchedEffect(Unit) {
        if (boxItems.isEmpty() && !boxLoading) {
            loadBox(1, "latest", "")
            // Load every browse section once for the category chips.
            if (boxCategories.isEmpty()) {
                val categories = withContext(Dispatchers.IO) {
                    runCatching { ArixMovieBoxClient.categories() }.getOrDefault(emptyList())
                }
                boxCategories = categories
            }
        }
    }

    // MovieBox detail overlay with its own back handling.
    boxDetail?.let { detail ->
        BackHandler { boxDetail = null; boxPlaying = false }
        ArixMovieBoxDetailScreen(
            detail = detail,
            playing = boxPlaying,
            onPlayToggle = { boxPlaying = it },
            onOpenSubject = { subject ->
                boxDetail = null
                boxPlaying = false
                scope.launch {
                    boxLoading = true
                    val loaded = withContext(Dispatchers.IO) {
                        runCatching { ArixMovieBoxClient.detail(subject.detailPath) }.getOrNull()
                    }
                    boxLoading = false
                    if (loaded != null) boxDetail = loaded else boxError = "Could not load that title."
                }
            },
            onBack = {
                boxDetail = null
                boxPlaying = false
            },
            bottomBarReserve = bottomBarReserve,
        )
        return
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    listOf(ArixBackgroundGradientTop, ArixBackground, ArixSurface)
                )
            )
            .statusBarsPadding()
            .padding(bottom = bottomBarReserve),
    ) {
        ArixToolScreenHeader(
            title = "Watch Movies & Series",
            onBack = onBack,
        )
        Column(Modifier.padding(horizontal = 20.dp)) {
            ArixToolSearchField(
                value = query,
                onValueChange = { query = it },
                placeholder = "search here",
                onSearch = {
                    val keyword = query.trim()
                    if (keyword.length >= 2) {
                        loadBox(1, "search", keyword)
                    }
                },
            )
            // v2.4.7: 12dp spacer so the search pill does not touch the chips.
            Spacer(Modifier.height(12.dp))
        }

        if (boxError.isNotBlank()) {
            ArixToolMessageLine(boxError, isError = true, modifier = Modifier.padding(horizontal = 20.dp))
        }
        // v2.3.0: category chips — every section the MovieBox Movie
        // tab provides (Latest / Trending Movie / Action / Horror …).
        if (boxCategories.isNotEmpty()) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 20.dp)
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        ArixToolProviderChip(
                            label = "Latest",
                            selected = boxMode != "search" && boxCategory.isBlank(),
                            onClick = {
                                boxCategory = ""
                                loadBox(1, "latest", "")
                            },
                        )
                        boxCategories.forEach { category ->
                            ArixToolProviderChip(
                                label = category.title.take(20),
                                selected = boxCategory == category.title,
                                onClick = { selectBoxCategory(category) },
                            )
                        }
                    }
                    Spacer(Modifier.height(10.dp))
                }
                Text(
                    text = when {
                        boxMode == "search" -> "Search results"
                        boxCategory.isNotBlank() -> boxCategory
                        else -> "Latest movies"
                    },
                    style = MaterialTheme.typography.titleSmall,
                    color = ArixOnSurface,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp),
                )
                if (boxLoading && boxItems.isEmpty()) {
                    Box(Modifier.fillMaxWidth().weight(1f), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator(color = ArixPrimary, strokeWidth = 3.dp)
                    }
                } else {
                    LazyVerticalGrid(
                        columns = GridCells.Fixed(3),
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f),
                        contentPadding = PaddingValues(start = 20.dp, end = 20.dp, top = 4.dp, bottom = 16.dp),
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp),
                    ) {
                        items(
                            boxItems,
                            key = { it.detailPath.ifBlank { it.subjectId }.ifBlank { it.title } },
                        ) { subject ->
                            ArixPosterGridCell(
                                title = subject.title,
                                imageUrl = subject.coverUrl,
                                badge = when {
                                    // WeFeed convention: subjectType 1 = movie, 2 = series.
                                    subject.subjectType == 2 -> "Series"
                                    subject.year.isNotBlank() -> subject.year.take(4)
                                    else -> null
                                },
                            ) {
                                scope.launch {
                                    boxLoading = true
                                    val detail = withContext(Dispatchers.IO) {
                                        runCatching { ArixMovieBoxClient.detail(subject.detailPath) }.getOrNull()
                                    }
                                    boxLoading = false
                                    if (detail != null) boxDetail = detail
                                    else boxError = "Could not load that title."
                                }
                            }
                        }
                        if (boxMode == "latest") {
                            item(key = "load-more", span = { GridItemSpan(3) }) {
                                ArixGridFooter(
                                    label = if (boxLoading) "Loading…" else "Load more",
                                    enabled = !boxLoading,
                                ) { loadBox(boxPage + 1, boxMode, query.trim()) }
                            }
                        }
                    }
                }
    }
}

/* --------------------------------------------------- MovieBox detail */

@Composable
private fun ArixMovieBoxDetailScreen(
    detail: ArixMovieBoxClient.Detail,
    playing: Boolean,
    onPlayToggle: (Boolean) -> Unit,
    onOpenSubject: (ArixMovieBoxClient.Subject) -> Unit,
    onBack: () -> Unit,
    bottomBarReserve: Dp,
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var recommendations by remember { mutableStateOf<List<ArixMovieBoxClient.Subject>>(emptyList()) }
    var recommendationsLoaded by remember { mutableStateOf(false) }
    var playerModel by remember { mutableStateOf<ArixMoviePlayerModel?>(null) }
    var playError by remember { mutableStateOf("") }
    var selectedSeason by remember(detail) { mutableStateOf(detail.episodes.firstOrNull()?.season ?: 0) }
    var selectedEpisode by remember(detail) { mutableStateOf(detail.episodes.firstOrNull()?.episode ?: 0) }
    var subtitleUrl by remember { mutableStateOf("") }
    // v2.3.0: subtitles now arrive per play-stream (stream id) instead of
    // from the legacy detail `caption_list`, which the live API no longer
    // returns.
    var streamCaptions by remember { mutableStateOf<List<ArixMovieBoxClient.Caption>>(emptyList()) }

    val seasons = remember(detail) { detail.episodes.map { it.season }.distinct().sorted() }
    val visibleEpisodes = remember(detail, selectedSeason) {
        detail.episodes.filter { it.season == selectedSeason }
    }

    LaunchedEffect(detail.subject.subjectId) {
        if (!recommendationsLoaded && detail.subject.subjectId.isNotBlank()) {
            val recs = withContext(Dispatchers.IO) {
                runCatching { ArixMovieBoxClient.detailRec(detail.subject.subjectId) }.getOrDefault(emptyList())
            }
            recommendations = recs.filter { it.detailPath.isNotBlank() && it.detailPath != detail.subject.detailPath }
            recommendationsLoaded = true
        }
    }

    fun startPlayback(season: Int, episode: Int) {
        playError = ""
        playerModel = null
        streamCaptions = emptyList()
        onPlayToggle(true)
        scope.launch {
            val loaded = withContext(Dispatchers.IO) {
                runCatching {
                    val sources = ArixMovieBoxClient.play(
                        subjectId = detail.subject.subjectId,
                        detailPath = detail.subject.detailPath,
                        season = season,
                        episode = episode,
                    )
                    if (sources.isEmpty()) error("No playable stream was returned for this title.")
                    val downloads = runCatching {
                        ArixMovieBoxClient.download(
                            subjectId = detail.subject.subjectId,
                            detailPath = detail.subject.detailPath,
                            season = season,
                            episode = episode,
                        )
                    }.getOrDefault(emptyList())
                    // Subtitle tracks belong to the play stream; load them for
                    // the first stream so the chips render next to the player.
                    val captions = runCatching {
                        ArixMovieBoxClient.captions(
                            streamId = sources.first().streamId,
                            subjectId = detail.subject.subjectId,
                            detailPath = detail.subject.detailPath,
                        )
                    }.getOrDefault(emptyList())
                    ArixMoviePlayerModel(
                        title = detail.subject.title,
                        description = detail.subject.description,
                        thumbnail = detail.subject.coverUrl,
                        url = detail.subject.detailPath,
                        servers = sources.mapIndexed { index, source ->
                            ArixMovieServerModel(
                                label = buildString {
                                    append(source.quality)
                                    if (source.lineLabel.isNotBlank()) append(" · ").append(source.lineLabel)
                                    if (source.quality.isBlank() && source.lineLabel.isBlank()) {
                                        append("Server ").append(index + 1)
                                    }
                                },
                                url = source.url,
                                directUrl = source.url, // MovieBox returns direct .mp4/.m3u8 streams
                                // The MovieBox CDN validates Referer against its play page
                                // origin; without it the media requests fail with 429.
                                pageOrigin = "https://newfilm122.xyz/",
                            )
                        },
                        // v2.6.2 (fix #4): the "Web player" embed fallback server was
                        // removed — the movie tool is now fully native (OkHttp API +
                        // Compose UI + Media3/ExoPlayer playback, no WebView). Every
                        // listed server plays through the native ExoPlayer stage.
                        downloads = downloads.map { ArixMovieDownloadModel(it.quality.ifBlank { "Download" }, it.label, it.url) },
                    ) to captions
                }.getOrNull()
            }
            if (loaded == null) {
                playError = "Could not start playback. Try again or pick another title."
                onPlayToggle(false)
            } else {
                playerModel = loaded.first
                streamCaptions = loaded.second
            }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(ArixBackground)
            .statusBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp)
            .padding(bottom = bottomBarReserve + 12.dp),
    ) {
        ArixToolScreenHeader(
            title = detail.subject.title.ifBlank { "Details" },
            onBack = onBack,
        )

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(20.dp))
                .background(ArixSurfaceHigh.copy(alpha = 0.95f))
                .border(1.dp, ArixOutline.copy(alpha = 0.45f), RoundedCornerShape(20.dp))
                .padding(14.dp),
            horizontalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            val poster = rememberRemoteImage(ArixMediaApi.thumbUrl(detail.subject.coverUrl))
            Box(
                modifier = Modifier
                    .width(108.dp)
                    .aspectRatio(0.68f)
                    .clip(RoundedCornerShape(12.dp))
                    .background(ArixSurfaceVariant.copy(alpha = 0.4f)),
                contentAlignment = Alignment.Center,
            ) {
                if (poster != null) {
                    Image(
                        bitmap = poster,
                        contentDescription = null,
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Crop,
                    )
                } else {
                    Icon(
                        imageVector = Icons.Rounded.Movie,
                        contentDescription = null,
                        tint = ArixOnSurfaceVariant,
                        modifier = Modifier.size(28.dp),
                    )
                }
            }
            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(6.dp),
            ) {
                if (detail.subject.rating > 0.0) {
                    Text(
                        text = "★ ${detail.subject.rating}",
                        style = MaterialTheme.typography.labelLarge,
                        color = Color(0xFFF5C518),
                        fontWeight = FontWeight.SemiBold,
                    )
                }
                Text(
                    text = detail.subject.description.ifBlank { "No description available for this title." },
                    style = MaterialTheme.typography.bodySmall,
                    color = ArixOnSurfaceVariant,
                    maxLines = 6,
                    overflow = TextOverflow.Ellipsis,
                )
            }
        }

        Spacer(Modifier.height(12.dp))

        // Seasons (series only)
        if (seasons.size > 1 || (seasons.isNotEmpty() && seasons.first() > 0)) {
            Text(
                text = "Seasons",
                style = MaterialTheme.typography.titleSmall,
                color = ArixOnSurface,
                fontWeight = FontWeight.SemiBold,
            )
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                rowItems(seasons) { season ->
                    ArixToolProviderChip(
                        label = if (season == 0) "Season 1" else "Season $season",
                        selected = selectedSeason == season,
                        onClick = { selectedSeason = season },
                    )
                }
            }
            Spacer(Modifier.height(10.dp))
            if (visibleEpisodes.isNotEmpty()) {
                Text(
                    text = "Episodes",
                    style = MaterialTheme.typography.titleSmall,
                    color = ArixOnSurface,
                    fontWeight = FontWeight.SemiBold,
                )
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    rowItems(visibleEpisodes.take(200)) { episode ->
                        ArixToolProviderChip(
                            label = episode.title.ifBlank { "EP ${episode.episode}" },
                            selected = selectedEpisode == episode.episode,
                            onClick = {
                                selectedEpisode = episode.episode
                                startPlayback(episode.season, episode.episode)
                            },
                        )
                    }
                }
                Spacer(Modifier.height(12.dp))
            }
        }

        ArixToolPrimaryButton(
            label = when {
                playError.isNotBlank() -> "Retry — Watch now"
                playerModel == null && !playing -> "Watch now"
                else -> "Watch now"
            },
            enabled = true,
            onClick = {
                val episode = visibleEpisodes.firstOrNull { it.episode == selectedEpisode }
                    ?: visibleEpisodes.firstOrNull()
                startPlayback(selectedSeason, episode?.episode ?: 0)
            },
        )

        if (playError.isNotBlank()) {
            Spacer(Modifier.height(8.dp))
            ArixToolMessageLine(playError, isError = true)
        }

        // Subtitles (per play stream — loaded together with the player)
        if (streamCaptions.isNotEmpty()) {
            Spacer(Modifier.height(12.dp))
            Text(
                text = "Subtitles",
                style = MaterialTheme.typography.titleSmall,
                color = ArixOnSurface,
                fontWeight = FontWeight.SemiBold,
            )
            Spacer(Modifier.height(6.dp))
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                rowItems(streamCaptions.take(16)) { caption ->
                    ArixToolProviderChip(
                        label = caption.language.ifBlank { caption.format },
                        selected = false,
                        onClick = {
                            if (caption.url.isNotBlank()) {
                                subtitleUrl = caption.url
                                runCatching {
                                    context.startActivity(
                                        android.content.Intent(
                                            android.content.Intent.ACTION_VIEW,
                                            android.net.Uri.parse(caption.url),
                                        ),
                                    )
                                }
                            } else {
                                playError = "That subtitle track could not be loaded."
                            }
                        },
                    )
                }
            }
        }

        // Legacy fallback: captions attached to the detail payload.
        if (streamCaptions.isEmpty() && detail.captions.isNotEmpty()) {
            Spacer(Modifier.height(12.dp))
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                rowItems(detail.captions.take(12)) { caption ->
                    ArixToolProviderChip(
                        label = caption.language.ifBlank { caption.format },
                        selected = false,
                        onClick = {
                            scope.launch {
                                val url = withContext(Dispatchers.IO) {
                                    runCatching {
                                        ArixMovieBoxClient.captionUrl(
                                            id = caption.id,
                                            subjectId = detail.subject.subjectId,
                                            detailPath = detail.subject.detailPath,
                                            format = caption.format,
                                        )
                                    }.getOrDefault("")
                                }
                                if (url.isNotBlank()) {
                                    subtitleUrl = url
                                    runCatching {
                                        context.startActivity(
                                            android.content.Intent(
                                                android.content.Intent.ACTION_VIEW,
                                                android.net.Uri.parse(url),
                                            ),
                                        )
                                    }
                                } else {
                                    playError = "That subtitle track could not be loaded."
                                }
                            }
                        },
                    )
                }
            }
        }

        playerModel?.let { model ->
            Spacer(Modifier.height(14.dp))
            MoviePlayerWidget(model, Modifier.fillMaxWidth())
        }

        // Recommendations
        if (recommendations.isNotEmpty()) {
            Spacer(Modifier.height(16.dp))
            Text(
                text = "You may also like",
                style = MaterialTheme.typography.titleSmall,
                color = ArixOnSurface,
                fontWeight = FontWeight.SemiBold,
            )
            Spacer(Modifier.height(8.dp))
            LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                rowItems(recommendations.take(20)) { subject ->
                    Column(
                        modifier = Modifier
                            .width(108.dp)
                            .clip(RoundedCornerShape(14.dp))
                            .background(ArixSurfaceHigher.copy(alpha = 0.9f))
                            .clickable { onOpenSubject(subject) }
                            .padding(6.dp),
                        verticalArrangement = Arrangement.spacedBy(5.dp),
                    ) {
                        val recPoster = rememberRemoteImage(ArixMediaApi.thumbUrl(subject.coverUrl))
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .aspectRatio(0.68f)
                                .clip(RoundedCornerShape(10.dp))
                                .background(ArixSurfaceVariant.copy(alpha = 0.4f)),
                            contentAlignment = Alignment.Center,
                        ) {
                            if (recPoster != null) {
                                Image(
                                    bitmap = recPoster,
                                    contentDescription = subject.title,
                                    modifier = Modifier.fillMaxSize(),
                                    contentScale = ContentScale.Crop,
                                )
                            } else {
                                Icon(
                                    imageVector = Icons.Rounded.Movie,
                                    contentDescription = null,
                                    tint = ArixOnSurfaceVariant,
                                    modifier = Modifier.size(22.dp),
                                )
                            }
                        }
                        Text(
                            text = subject.title,
                            style = MaterialTheme.typography.labelSmall,
                            color = ArixOnSurface,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis,
                        )
                    }
                }
            }
        }
        Spacer(Modifier.height(20.dp))
    }
}

/* ==================================================== poster grid bits */

@Composable
private fun ArixPosterGridCell(
    modifier: Modifier = Modifier,
    title: String,
    imageUrl: String,
    badge: String? = null,
    onClick: () -> Unit,
) {
    val poster = rememberRemoteImage(if (imageUrl.isBlank()) "" else ArixMediaApi.thumbUrl(imageUrl))
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(14.dp))
            .background(ArixSurfaceHigher.copy(alpha = 0.9f))
            .clickable(onClick = onClick)
            .padding(6.dp),
        verticalArrangement = Arrangement.spacedBy(5.dp),
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .aspectRatio(0.68f)
                .clip(RoundedCornerShape(10.dp))
                .background(ArixSurfaceVariant.copy(alpha = 0.4f)),
        ) {
            if (poster != null) {
                Image(
                    bitmap = poster,
                    contentDescription = title,
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop,
                )
            } else {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = Icons.Rounded.PlayCircle,
                        contentDescription = null,
                        tint = ArixOnSurfaceVariant.copy(alpha = 0.6f),
                        modifier = Modifier.size(24.dp),
                    )
                }
            }
            if (badge != null) {
                Text(
                    text = badge,
                    style = MaterialTheme.typography.labelSmall,
                    color = Color(0xFF1D1030),
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(5.dp)
                        .clip(RoundedCornerShape(7.dp))
                        .background(ArixPrimary.copy(alpha = 0.85f))
                        .padding(horizontal = 6.dp, vertical = 2.dp),
                )
            }
        }
        Text(
            text = title,
            style = MaterialTheme.typography.labelSmall,
            color = ArixOnSurface,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.padding(horizontal = 2.dp),
        )
    }
}

@Composable
private fun ArixGridFooter(label: String, enabled: Boolean, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 14.dp)
            .clip(RoundedCornerShape(14.dp))
            .background(ArixSurfaceVariant.copy(alpha = 0.4f))
            .clickable(enabled = enabled, onClick = onClick)
            .padding(vertical = 12.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelMedium,
            color = if (enabled) ArixPrimary else ArixOnSurfaceVariant,
            fontWeight = FontWeight.SemiBold,
        )
    }
}

/* ======================================================== anime tool */

/**
 * v2.4.1: the AniList-backed provider 1 was removed — AnimeSalt is now the
 * single always-on source (latest, search, movie pages and episodes).
 */
@Composable
private fun ArixAimeToolScreen(
    onBack: () -> Unit,
    bottomBarReserve: Dp,
) {
    var query by remember { mutableStateOf("") }
    var items by remember { mutableStateOf<List<ArixAnimeSiteClient.AnimeItem>>(emptyList()) }
    var page by remember { mutableStateOf(1) }
    var mode by remember { mutableStateOf("latest") }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf("") }
    var player by remember { mutableStateOf<ArixAnimePlayerModel?>(null) }
    val scope = rememberCoroutineScope()

    fun load(loadPage: Int, loadMode: String, keyword: String) {
        loading = true
        error = ""
        scope.launch {
            val result = withContext(Dispatchers.IO) {
                runCatching {
                    if (loadMode == "search") {
                        ArixAnimeSiteClient.searchFrom(ArixAnimeSiteClient.SourceAnimeSalt, keyword, limit = 36)
                    } else {
                        ArixAnimeSiteClient.latestFrom(ArixAnimeSiteClient.SourceAnimeSalt, loadPage, limit = 36)
                    }
                }.getOrElse { emptyList() }
            }
            loading = false
            items = result
            page = loadPage
            mode = loadMode
            if (result.isEmpty()) {
                error = if (loadMode == "search") {
                    "No anime found for \"$keyword\"."
                } else {
                    "The anime provider is not responding right now — check your connection and retry."
                }
            }
        }
    }

    LaunchedEffect(Unit) {
        if (items.isEmpty() && !loading) load(1, "latest", "")
    }
    player?.let { model ->
        BackHandler { player = null }
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(ArixBackground)
                .statusBarsPadding()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp)
                .padding(bottom = bottomBarReserve + 12.dp),
        ) {
            ArixToolScreenHeader(
                title = model.title.ifBlank { "Watch Anime" },
                onBack = { player = null },
            )
            AnimePlayerWidget(model, Modifier.fillMaxWidth())
        }
        return
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    listOf(ArixBackgroundGradientTop, ArixBackground, ArixSurface)
                )
            )
            .statusBarsPadding()
            .padding(bottom = bottomBarReserve),
    ) {
        ArixToolScreenHeader(
            title = "Watch Anime",
            onBack = onBack,
        )
        Column(Modifier.padding(horizontal = 20.dp)) {
            ArixToolSearchField(
                value = query,
                onValueChange = { query = it },
                placeholder = "search here",
                onSearch = {
                    val keyword = query.trim()
                    if (keyword.length >= 2) load(1, "search", keyword)
                },
            )
        }

        if (error.isNotBlank()) {
            ArixToolMessageLine(error, isError = true, modifier = Modifier.padding(horizontal = 20.dp))
        }
        Text(
            text = if (mode == "search") "Search results" else "Latest anime",
            style = MaterialTheme.typography.titleSmall,
            color = ArixOnSurface,
            fontWeight = FontWeight.SemiBold,
            modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp),
        )
        if (loading && items.isEmpty()) {
            Box(Modifier.fillMaxWidth().weight(1f), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = ArixPrimary, strokeWidth = 3.dp)
            }
        } else {
            LazyVerticalGrid(
                columns = GridCells.Fixed(3),
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentPadding = PaddingValues(start = 20.dp, end = 20.dp, top = 4.dp, bottom = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                items(
                    items,
                    key = { it.url },
                ) { item ->
                    ArixPosterGridCell(
                        title = item.title,
                        imageUrl = item.thumbnail,
                        badge = item.meta.take(12).ifBlank { null },
                    ) {
                        scope.launch {
                            loading = true
                            error = ""
                            val detail = withContext(Dispatchers.IO) {
                                runCatching { ArixAnimeSiteClient.fetchEpisodes(item.url) }.getOrNull()
                            }
                            loading = false
                            if (detail == null || detail.episodes.isEmpty()) {
                                error = "No episodes were found for \"${item.title.take(36)}\"."
                            } else {
                                player = ArixAnimePlayerModel(
                                    title = detail.title.ifBlank { item.title },
                                    thumbnail = detail.thumbnail.ifBlank { item.thumbnail },
                                    source = detail.source,
                                    url = detail.url,
                                    description = detail.description,
                                    episodes = detail.episodes.take(300).map { episode ->
                                        ArixAnimeEpisodeModel(episode.number, episode.name, episode.url)
                                    },
                                    servers = emptyList(),
                                    languages = emptyList(),
                                    selectedEpisode = detail.episodes.firstOrNull()?.number ?: 1,
                                    episodeName = detail.episodes.firstOrNull()?.name.orEmpty(),
                                )
                            }
                        }
                    }
                }
                if (mode == "latest") {
                    item(key = "load-more", span = { GridItemSpan(3) }) {
                        ArixGridFooter(
                            label = if (loading) "Loading…" else "Load more",
                            enabled = !loading,
                        ) { load(page + 1, "latest", "") }
                    }
                }
            }
        }
    }
}


/* ==================================================== file share tool */

/**
 * File Share tool — upload any file to a free public host and get a direct
 * download URL with copy + share actions. Server chips at the top switch
 * between Filebin (Server 1), tmpfiles.org (Server 2), GoFile (Server 3),
 * qu.ax (Server 4) and x0.at (Server 5).
 */
@Composable
private fun ArixFileShareToolScreen(
    onBack: () -> Unit,
    bottomBarReserve: Dp,
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var server by remember { mutableStateOf(ArixFileShareClient.ServerFilebin) }
    var pickedUri by remember { mutableStateOf<android.net.Uri?>(null) }
    var pickedName by remember { mutableStateOf("") }
    var uploading by remember { mutableStateOf(false) }
    var result by remember { mutableStateOf<ArixFileShareClient.UploadResult?>(null) }
    var error by remember { mutableStateOf("") }
    var copied by remember { mutableStateOf(false) }

    val filePicker = androidx.activity.compose.rememberLauncherForActivityResult(
        contract = androidx.activity.result.contract.ActivityResultContracts.GetContent(),
    ) { uri ->
        if (uri != null) {
            pickedUri = uri
            result = null
            error = ""
            copied = false
            pickedName = runCatching {
                context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
                    if (cursor.moveToFirst()) {
                        val index = cursor.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME)
                        if (index >= 0) cursor.getString(index) else null
                    } else {
                        null
                    }
                }
            }.getOrNull() ?: uri.lastPathSegment?.substringAfterLast('/') ?: "file"
        }
    }

    fun upload() {
        val uri = pickedUri ?: return
        if (uploading) return
        uploading = true
        error = ""
        copied = false
        result = null
        scope.launch {
            val outcome = withContext(Dispatchers.IO) {
                runCatching { ArixFileShareClient.upload(context, uri, server) }
            }
            uploading = false
            outcome.fold(
                onSuccess = { result = it },
                onFailure = { error = it.message ?: "The upload failed. Try another server." },
            )
        }
    }

    fun copyUrl(url: String) {
        runCatching {
            val clipboard = context.getSystemService(android.content.Context.CLIPBOARD_SERVICE)
                as android.content.ClipboardManager
            clipboard.setPrimaryClip(
                android.content.ClipData.newPlainText("Arix file link", url),
            )
            copied = true
        }
    }

    fun shareUrl(url: String) {
        runCatching {
            val intent = android.content.Intent(android.content.Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(android.content.Intent.EXTRA_TEXT, url)
            }
            context.startActivity(android.content.Intent.createChooser(intent, "Share file link"))
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    listOf(ArixBackgroundGradientTop, ArixBackground, ArixSurface)
                )
            )
            .statusBarsPadding()
            .padding(bottom = bottomBarReserve),
    ) {
        ArixToolScreenHeader(
            title = "File Share",
            onBack = onBack,
        )
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            // Server chips — Server 1 / 2 / 3 / 4 / 5.
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                listOf(
                    ArixFileShareClient.ServerFilebin,
                    ArixFileShareClient.ServerTmpFiles,
                    ArixFileShareClient.ServerGoFile,
                    ArixFileShareClient.ServerQuAx,
                    ArixFileShareClient.ServerX0,
                ).forEach { candidate ->
                    ArixToolProviderChip(
                        label = ArixFileShareClient.serverLabel(candidate),
                        selected = server == candidate,
                        onClick = { server = candidate },
                    )
                }
            }
            Text(
                text = ArixFileShareClient.serverHint(server),
                style = MaterialTheme.typography.labelSmall,
                color = ArixOnSurfaceVariant,
            )

            // Selected file card.
            if (pickedUri != null) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(18.dp))
                        .background(ArixSurfaceHigh.copy(alpha = 0.95f))
                        .border(1.dp, ArixOutline.copy(alpha = 0.45f), RoundedCornerShape(18.dp))
                        .padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Icon(
                        imageVector = Icons.Rounded.InsertDriveFile,
                        contentDescription = null,
                        tint = ArixPrimary,
                        modifier = Modifier.size(26.dp),
                    )
                    Spacer(Modifier.width(12.dp))
                    Column(
                        modifier = Modifier.weight(1f),
                        verticalArrangement = Arrangement.spacedBy(2.dp),
                    ) {
                        Text(
                            text = pickedName.ifBlank { "Selected file" },
                            style = MaterialTheme.typography.labelLarge,
                            color = ArixOnSurface,
                            fontWeight = FontWeight.SemiBold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                        )
                        Text(
                            text = "Ready to upload",
                            style = MaterialTheme.typography.labelSmall,
                            color = ArixOnSurfaceVariant,
                        )
                    }
                    Icon(
                        imageVector = Icons.Rounded.Close,
                        contentDescription = "Clear",
                        tint = ArixOnSurfaceVariant,
                        modifier = Modifier
                            .size(30.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .clickable {
                                pickedUri = null
                                pickedName = ""
                                result = null
                                error = ""
                                copied = false
                            }
                            .padding(6.dp),
                    )
                }
            }

            ArixToolPrimaryButton(
                label = when {
                    uploading -> "Uploading…"
                    pickedUri == null -> "Choose file"
                    else -> "Upload & get link"
                },
                enabled = !uploading,
                onClick = {
                    if (pickedUri == null) {
                        runCatching { filePicker.launch("*/*") }
                    } else {
                        upload()
                    }
                },
            )

            if (uploading) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(18.dp),
                        strokeWidth = 2.dp,
                        color = ArixPrimary,
                    )
                    Text(
                        text = "Uploading to ${ArixFileShareClient.serverLabel(server)}… this can take a while for big files.",
                        style = MaterialTheme.typography.bodySmall,
                        color = ArixOnSurfaceVariant,
                    )
                }
            }

            if (error.isNotBlank()) {
                ArixToolMessageLine(error, isError = true)
            }

            // Result card with the direct download link.
            result?.let { upload ->
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(20.dp))
                        .background(ArixSurfaceHigh.copy(alpha = 0.95f))
                        .border(1.dp, ArixOutline.copy(alpha = 0.5f), RoundedCornerShape(20.dp))
                        .padding(18.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Rounded.CheckCircle,
                            contentDescription = null,
                            tint = Color(0xFF34D399),
                            modifier = Modifier.size(20.dp),
                        )
                        Spacer(Modifier.width(8.dp))
                        Text(
                            text = "Direct download link",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.SemiBold,
                            color = ArixOnSurface,
                        )
                    }
                    Text(
                        text = upload.url,
                        style = MaterialTheme.typography.bodySmall,
                        color = ArixPrimary,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(10.dp))
                            .background(ArixSurfaceVariant.copy(alpha = 0.5f))
                            .clickable { copyUrl(upload.url) }
                            .padding(12.dp),
                        maxLines = 3,
                        overflow = TextOverflow.Ellipsis,
                    )
                    Text(
                        text = buildString {
                            append(upload.fileName)
                            append(" · ")
                            append(ArixFileShareClient.formatBytes(upload.sizeBytes))
                            append(" · ")
                            append(ArixFileShareClient.serverLabel(upload.server))
                        },
                        style = MaterialTheme.typography.labelSmall,
                        color = ArixOnSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        ArixToolSecondaryButton(
                            label = if (copied) "Copied!" else "Copy",
                            icon = Icons.Rounded.ContentCopy,
                            onClick = { copyUrl(upload.url) },
                        )
                        ArixToolSecondaryButton(
                            label = "Share",
                            icon = Icons.Rounded.Share,
                            onClick = { shareUrl(upload.url) },
                        )
                    }
                    Text(
                        text = "Tip: tap the link box to copy it. Anyone with the link can download the file.",
                        style = MaterialTheme.typography.labelSmall,
                        color = ArixOnSurfaceVariant,
                    )
                }
            }

            Text(
                text = "Files are uploaded to independent free hosts. Links expire after the host's retention window; keep a copy of anything important.",
                style = MaterialTheme.typography.labelSmall,
                color = ArixOnSurfaceVariant,
            )
            Spacer(Modifier.height(20.dp))
        }
    }
}

/* ==================================================== android shell tool */

// v2.4.7: the standalone Android Shell tool screen was removed along with
// the ArixAndroidShell/ArixAndroidShellTool classes and the Tools hub entry.
// The agent's system_control tool now drives device interactions through
// ADB (tap, swipe, screenshot, input text) and the Alpine terminal tab
// still provides an interactive shell when one is needed.
