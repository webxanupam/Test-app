package com.arix.app.data

import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/**
 * ArixWeatherClient — v2.6.1 native weather tool.
 *
 * Answers "weather in <city>" / "what's the temperature" chat messages with a
 * live in-chat weather card (no LLM round-trip, no API key):
 *
 *  - Geocoding:  https://geocoding-api.open-meteo.com/v1/search
 *  - Forecast:   https://api.open-meteo.com/v1/forecast (current + 5-day
 *                daily, auto timezone)
 *  - Fallback location when the message carries no city: IP geolocation via
 *    https://get.geojs.io/v1/ip/geo.json (then ipapi.co).
 *
 * All methods perform blocking network IO — call from Dispatchers.IO.
 */
object ArixWeatherClient {

    private val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .followRedirects(true)
        .build()

    /** Hard cap on the daily forecast rows handed to the widget. */
    private const val MaxDailyEntries = 5

    /* -------------------------------------------------------------- public */

    /**
     * Fetches the weather for [query] (a free-text place name, blank = use IP
     * geolocation) and returns the structured `weather` widget payload.
     */
    fun weatherOutputJson(query: String): String {
        val place = resolvePlace(query)
        val forecast = fetchForecast(place.latitude, place.longitude)

        val current = forecast.getJSONObject("current")
        val daily = forecast.optJSONArray("daily") ?: JSONArray()

        val dailyEntries = JSONArray()
        val count = daily.length().coerceAtMost(MaxDailyEntries)
        for (index in 0 until count) {
            val day = daily.optJSONObject(index) ?: continue
            dailyEntries.put(
                JSONObject()
                    .put("date", day.optString("time"))
                    .put("code", day.optInt("weather_code", 0))
                    .put("max", round1(day.optDouble("temperature_2m_max")))
                    .put("min", round1(day.optDouble("temperature_2m_min")))
                    .put("precipitation_probability", day.optInt("precipitation_probability_max", 0)),
            )
        }

        return JSONObject()
            .put("widget", "weather")
            .put("ok", true)
            .put("location", place.displayName)
            .put("latitude", place.latitude)
            .put("longitude", place.longitude)
            .put("timezone", forecast.optString("timezone"))
            .put("temperature", round1(current.optDouble("temperature_2m")))
            .put("apparent_temperature", round1(current.optDouble("apparent_temperature")))
            .put("humidity", current.optInt("relative_humidity_2m"))
            .put("wind_speed", round1(current.optDouble("wind_speed_10m")))
            .put("wind_direction", current.optInt("wind_direction_10m"))
            .put("is_day", current.optInt("is_day", 1) == 1)
            .put("code", current.optInt("weather_code", 0))
            .put("daily", dailyEntries)
            .toString()
    }

    /* ------------------------------------------------------------ internals */

    private data class Place(
        val displayName: String,
        val latitude: Double,
        val longitude: Double,
    )

    private fun resolvePlace(query: String): Place {
        val trimmed = query.trim()
        if (trimmed.isNotEmpty()) {
            geocode(trimmed)?.let { return it }
        }
        return ipLocate() ?: Place("Earth", 0.0, 0.0)
    }

    /** Resolves a place name through the Open-Meteo geocoding API. */
    private fun geocode(query: String): Place? {
        val url = "https://geocoding-api.open-meteo.com/v1/search" +
            "?name=${urlEncode(query)}&count=1&language=en&format=json"
        val body = getJson(url) ?: return null
        val results = body.optJSONArray("results") ?: return null
        val first = results.optJSONObject(0) ?: return null
        val name = first.optString("name")
        val admin = first.optString("admin1")
        val country = first.optString("country")
        val displayName = buildString {
            append(name)
            if (admin.isNotBlank() && !admin.equals(name, ignoreCase = true)) {
                append(", ")
                append(admin)
            }
            if (country.isNotBlank()) {
                append(", ")
                append(country)
            }
        }
        return Place(
            displayName = displayName,
            latitude = first.optDouble("latitude"),
            longitude = first.optDouble("longitude"),
        )
    }

    /** Best-effort IP geolocation (geojs first, ipapi.co as fallback). */
    private fun ipLocate(): Place? {
        runCatching {
            val body = getJson("https://get.geojs.io/v1/ip/geo.json") ?: return@runCatching
            val latitude = body.optDouble("latitude")
            val longitude = body.optDouble("longitude")
            if (latitude != 0.0 || longitude != 0.0) {
                return Place(
                    displayName = listOf(body.optString("city"), body.optString("region"), body.optString("country"))
                        .filter { it.isNotBlank() }
                        .joinToString(", "),
                    latitude = latitude,
                    longitude = longitude,
                )
            }
        }
        runCatching {
            val body = getJson("https://ipapi.co/json/") ?: return@runCatching
            val latitude = body.optDouble("latitude")
            val longitude = body.optDouble("longitude")
            if (latitude != 0.0 || longitude != 0.0) {
                return Place(
                    displayName = listOf(body.optString("city"), body.optString("region"), body.optString("country_name"))
                        .filter { it.isNotBlank() }
                        .joinToString(", "),
                    latitude = latitude,
                    longitude = longitude,
                )
            }
        }
        return null
    }

    private fun fetchForecast(latitude: Double, longitude: Double): JSONObject {
        val url = "https://api.open-meteo.com/v1/forecast" +
            "?latitude=${trimCoord(latitude)}&longitude=${trimCoord(longitude)}" +
            "&current=temperature_2m,relative_humidity_2m,apparent_temperature,is_day," +
            "weather_code,wind_speed_10m,wind_direction_10m" +
            "&daily=weather_code,temperature_2m_max,temperature_2m_min,precipitation_probability_max" +
            "&timezone=auto&forecast_days=${MaxDailyEntries + 1}"
        val body = getJson(url)
            ?: error("The weather service could not be reached. Check your connection and try again.")
        if (!body.has("current")) {
            error("The weather service returned an unexpected response.")
        }
        return body
    }

    private fun getJson(url: String): JSONObject? {
        val request = Request.Builder()
            .url(url)
            .header("User-Agent", ArixMediaApi.BrowserUserAgent)
            .get()
            .build()
        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) return null
            val text = response.body?.string() ?: return null
            if (text.isBlank()) return null
            return runCatching { JSONObject(text) }.getOrNull()
        }
    }

    private fun urlEncode(value: String): String =
        java.net.URLEncoder.encode(value, Charsets.UTF_8.name())

    private fun trimCoord(value: Double): String =
        String.format(java.util.Locale.US, "%.4f", value)

    private fun round1(value: Double): Double =
        Math.round(value * 10.0) / 10.0
}
