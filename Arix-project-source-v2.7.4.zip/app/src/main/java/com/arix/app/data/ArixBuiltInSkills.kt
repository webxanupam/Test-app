package com.arix.app.data

/**
 * ArixBuiltInSkills — curated skills that ship inside the app and install on
 * first launch (or when re-enabled from Settings → Agent Skills → Built-in).
 *
 * v2.7.3: the previous six generic built-in skills (Email, Web Research,
 * Code Review, Document Writer, Translator, Device Control) were replaced
 * with the built-in skill set from the upstream Aether project, adapted to
 * Arix naming. Each entry is a full SKILL.md document (frontmatter +
 * instructions). They are installed through the regular AgentSkillManager
 * pipeline so they behave exactly like imported skills: enable/disable
 * toggle, per-session composer chips, runtime mirroring — plus a Remove
 * action that permanently hides a built-in until it is re-added from the
 * Built-in section.
 */
const val CreateExtensionSkillId = "create-extension"

object ArixBuiltInSkills {

    data class BuiltInSkill(
        val id: String,
        val name: String,
        val description: String,
        val skillMd: String,
    )

    val all: List<BuiltInSkill> = listOf(
        BuiltInSkill(
            id = CreateExtensionSkillId,
            name = "Create Extension",
            description = "Create, install, and verify an Arix Extension when asked to customize " +
                "Arix's interface, behavior, tools, commands, hooks, settings, or Agent workflow.",
            skillMd = """
                ---
                name: Create Extension
                description: Create, install, and verify an Arix Extension when the user asks to customize Arix's interface, behavior, tools, commands, hooks, settings, or Agent workflow.
                compatibility: Arix 2.x
                metadata:
                  short-description: Build and load an Arix Extension
                ---

                # Create an Arix Extension

                Turn the requested Arix customization into a working Extension, install it, and verify that it loaded. Complete the workflow without asking the user to import files or operate the Extensions settings screen.

                ## Choose the extension surface

                - Use the Arix Script Extension API for native mobile UI, settings pages, composer widgets, message renderers, state, storage, actions, events, and interceptors. Script Extensions reload without restarting the app.
                - Add a standard Pi extension entry when the customization needs Agent tools, commands, hooks, or other Pi Coding Agent behavior. One package may expose both Pi and Arix entries from the same TypeScript file.
                - Use an Android Native Mod only when the user explicitly needs Android-only APIs that the Script API cannot provide. Native Mods are Android-only, trusted code, and require an app restart, so they do not satisfy an uninterrupted customization request.

                ## Read the authoritative references

                Read the sections relevant to the requested feature before implementing it:

                - Documentation site: https://webxanupam.blogspot.com/docs/extensions/overview.md
                - Extension API declarations and examples: the `examples/` directory of the Arix source checkout
                - Combined Pi and Arix example: the `examples/` directory of the Arix source checkout

                When the current workspace is an Arix source checkout, prefer its local docs, `packages/extension-api` declarations, and `examples/` files because they match the running source version.

                ## Build

                1. Inspect the current workspace and the user's request. Reuse an existing Extension package when one clearly owns the customization; otherwise create a focused package under `.arix/extensions-src/<slug>/` in the workspace.
                2. Create a valid `package.json` with a stable package name, version, `"type": "module"`, and the required manifests. Declare Arix Script entrypoints under `arix.extensions`, Pi entrypoints under `pi.extensions`, or both. Target Arix Script API version 2.
                3. Implement the smallest complete Extension that satisfies the request. Use `@baimoqilin/arix-extension-api` for Arix types and helpers; Arix supplies that module to the runtime. Follow the documented slot names, component targets, service contracts, and lifecycle cleanup behavior exactly.
                4. Check JSON syntax and run any available TypeScript or package tests. Keep runtime dependencies in `dependencies`; declaration-only and build dependencies belong in `devDependencies`.

                A minimal Script manifest has this shape:

                ```json
                {
                  "name": "arix-my-extension",
                  "version": "1.0.0",
                  "type": "module",
                  "arix": {
                    "api": { "min": 2, "max": 2 },
                    "extensions": ["./index.ts"]
                  },
                  "devDependencies": {
                    "@baimoqilin/arix-extension-api": "^2.0.0"
                  }
                }
                ```

                ## Install and load

                Use `arix_extension_manage`; do not leave installation to the user.

                1. Build an absolute local package source using the manifest name and directory: `npm:<package-name>@file:<absolute-package-directory>`.
                2. Call `arix_extension_manage` with `action: "install_package"` and that `source`. If the same source is already installed, use `action: "update_package"` after edits.
                3. Inspect the returned package and reload data. Then call `action: "list"` and verify that the package and expected Arix/Pi entrypoints are present and that no load error was returned.
                4. If loading fails, fix the source, update the package, and verify again. Use `action: "remove_package"` only to roll back a package that cannot be made valid or when the user asks to uninstall it.

                Script files are watched after a successful load, but local `file:` packages are installed into Arix's managed package directory. After changing the source package, call `update_package` so the installed copy is refreshed.
            """.trimIndent(),
        ),
    )

    fun byId(id: String): BuiltInSkill? = all.firstOrNull { it.id == id }
}
