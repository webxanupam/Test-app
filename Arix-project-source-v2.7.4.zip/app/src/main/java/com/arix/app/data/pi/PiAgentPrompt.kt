package com.arix.app.data.pi

import com.arix.app.data.AppSettings
import com.arix.app.data.LocalRuntimeId
import java.time.ZonedDateTime
import java.time.format.DateTimeFormatter
import java.util.Locale

private val DynamicPromptPlaceholderRegex = Regex("""\{\{\s*([A-Za-z0-9_-]+)\s*\}\}""")

internal fun buildPiAgentInstructions(
    settings: AppSettings,
    workspaceDirectory: String,
    runtimeId: LocalRuntimeId,
    agentModeEnabled: Boolean,
    chromeEnabled: Boolean = false,
): String = buildString {
    val configuredPrompt = expandDynamicPromptPlaceholders(settings.systemPrompt).trim()
    if (configuredPrompt.isNotBlank()) {
        append(configuredPrompt)
        append("\n\n")
    }
    append(
        "You are running inside Arix on Android. " +
            "The current local runtime is ${runtimeId.storageValue} and its session cwd is $workspaceDirectory. " +
            "User-uploaded files are placed under uploads/; use read on the provided path when image or file contents are needed. " +
            "Arix-owned configuration, Skill, runtime, Extension, scheduled-task, and developer operations are exposed only through available arix_* tools. " +
            "Never modify LLM provider credentials or model configuration through self-management tools. " +
            "Only claim device actions or command results that were actually observed."
    )
    append(
        "\n\nDevice control through ADB (no root, no accessibility service): " +
            "use the bash tool to run `adb shell` commands on this device. " +
            "First-time setup: ask the user to enable Wireless debugging (Android 11+) in Developer options, " +
            "pair via the Alpine terminal tab (`arix-adb pair 127.0.0.1:PORT CODE` then `arix-adb connect 127.0.0.1:PORT`). " +
            "Screen awareness: use the agent_mode tool with action=read_screen — it reads the screen as " +
            "structured text (every element's text, description, id, bounds, clickable flags) via uiautomator, " +
            "with no screenshots and no image storage. Read the screen YOURSELF and decide what is shown; " +
            "do not guess. If the read fails, the response includes a safetynet fallback with the focused window. " +
            "Interact using `adb shell input tap X Y` (use the center of the target's bounds), " +
            "`adb shell input swipe X1 Y1 X2 Y2 DURATION_MS` to swipe, " +
            "`adb shell input text \"...\"` to type, `adb shell input keyevent KEYCODE_BACK` to press keys. " +
            "Never run `adb shell screencap` — screenshots are disabled by design; read the screen as text instead. " +
            "Use `adb shell am start -n PACKAGE/ACTIVITY` or `adb shell monkey -p PACKAGE 1` to launch apps, " +
            "`adb shell pm list packages` to list installed apps, `adb shell dumpsys ...` to read system state."
    )
    append(
        "\n\nAgent browser: the `browser` tool is always available. Use it to browse the web, open " +
            "backend endpoints, log into services, and fetch data/API responses for any task — no " +
            "toggle needed. It controls Arix's own Chromium instance: navigate, click, type, read " +
            "the DOM (get_readable / get_text / find_elements), scroll and execute JS. Prefer " +
            "selectors and DOM-reading actions; use coordinates only as a fallback. For plain HTTP " +
            "requests without a browser, curl in bash is fine too."
    )
    if (chromeEnabled) {
        append(
            "\n\nThe user explicitly enabled the Chrome visual mode for this chat, so browser " +
                "actions also render their live preview in the conversation."
        )
    }
}

private fun expandDynamicPromptPlaceholders(
    prompt: String,
    now: ZonedDateTime = ZonedDateTime.now(),
): String {
    if (!prompt.contains("{{")) return prompt
    val values = mapOf(
        "current_datetime" to now.format(DateTimeFormatter.ISO_OFFSET_DATE_TIME),
        "current_date" to now.toLocalDate().toString(),
        "current_time" to now.toLocalTime().withNano(0).toString(),
        "timezone" to now.zone.id,
        "unix_timestamp" to now.toEpochSecond().toString(),
    )
    return DynamicPromptPlaceholderRegex.replace(prompt) { match ->
        values[match.groupValues[1].lowercase(Locale.US)] ?: match.value
    }
}
