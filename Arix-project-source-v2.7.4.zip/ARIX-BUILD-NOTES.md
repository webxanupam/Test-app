# Arix — Build & Signing Notes

This project is **Arix**, a rebrand of [Aether](https://github.com/Zhou-Shilin/Aether) (GPL-3.0).
All changes below were applied on top of upstream `c1c446e` (Aether 2.1.5).
It is an **Android-only** fork: all iOS targets, sources, scripts and the
iOS runtime submodule have been removed.

## v2.7.4 — Browser display launch fix, thinking-status error label fix, Alpine settings cleanup

1. **Browser tab could never start ("Chromium display exited before noVNC
   became available." / `/bin/sh: displayWidth: parameter not set`)**:
   - Root cause: the launch script in `AlpineChromeController.ensureStarted()`
     built its Xvnc/Chromium arguments with the Kotlin escapes
     `${'$'}{displayWidth}` / `${'$'}{displayHeight}`, which emit the LITERAL
     text `${displayWidth}` / `${displayHeight}` into the shell script. The
     shell variables `displayWidth`/`displayHeight` are never defined inside
     that script (they are Kotlin locals), so under `set -eu` the very first
     parameter expansion aborted the whole script with
     "displayWidth: parameter not set" before Xvnc, openbox, Chromium or
     websockify ever launched. `waitForNoVnc()` then saw the dead top process
     and surfaced "Chromium display exited before noVNC became available."
   - Fix: the two argument sites now use real Kotlin interpolation, so the
     measured container geometry is baked into the script as concrete numbers
     — `Xvnc … -geometry <W>x<H>` and `chromium … --window-size=<W>,<H>`.
     The generated script parses cleanly under `/bin/sh` (verified with
     `sh -n` and a full simulation of the Kotlin template).
   - Net effect: Xvnc starts with the exact WebView geometry, the Chromium
     window is maximized undecorated by the openbox rc.xml rules, and the
     noVNC canvas (`scale=true`) fills the full browser tab like the
     reference screenshot — no letterboxing, no title-bar gap, no crash.
2. **"Error" label above "Arix is working on this turn." while Arix thinks**:
   - Root cause: `ReconnectingStatusCard` renders its `detail` through
     `SyntaxHighlightedCodeBlock` with the hardcoded label `common_error`
     ("Error"). The live working status `StreamingStatus("Thinking",
     "Arix is working on this turn.")` carries that working sentence as its
     `detail`, so the live status card could paint the benign working text
     inside an error-styled, expandable code block with a red-ish "Error"
     heading — making every thinking turn look like a failure.
   - Fix: while `isRunning` (live streaming status) the card now renders the
     detail as plain muted secondary text below the shimmering status line,
     never through the error-labeled block; the tappable error-details block
     remains only for settled/committed statuses (reconnect outcomes, engine
     errors committed to history). Committed "Thinking" statuses were already
     impossible after the v2.7.3 state-layer fixes; this closes the last
     (live-rendering) path.
3. **Settings → Alpine: "Agent browser" install row removed** (user request):
   - The `settings_chrome_environment` preset row (chromium, noVNC, Noto
     fonts) is gone from the Environment presets card. The Browser tab
     already auto-installs the Chromium + noVNC packages on first launch
     (`AlpineChromeController.ensureChromePackagesInstalled()`), so the
     manual entry was redundant. The "Open browser" toolbar shortcut and the
     Browser tab itself are unchanged.
4. Build metadata: `versionCode` 44 → 45, `arix.versionName` 2.7.3 → 2.7.4.
   No feature or tool was removed; the release build keeps R8 minification,
   resource shrinking, arm64-v8a-only ABI, English-only locale filter,
   compressed legacy JNI packaging and the same release keystore.
5. Packaging: the v2.7.4 release APK container was re-compressed with maximum
   deflate (then re-aligned and re-signed with the same release keystore and
   identical certificate — it installs as an in-place update over v2.7.3),
   trimming ~165 KB with zero functional change. Build toolchain note: the
   Gradle build requires a full JDK with `javac` (a JRE-only `java-21`
   installation fails `:shared:compileReleaseJavaWithJavac` with
   "does not provide the required capabilities: [JAVA_COMPILER]");
   `gradle.properties` intentionally contains no machine-specific
   `org.gradle.java.home` path — point `JAVA_HOME` at your JDK instead.

## v2.7.3 — Error-state fix, browser fit, Aether skills, settings/timeline cleanup

1. **Chat turn error-state fix (state transitions at the source)**:
   - `PiAgentRunner.runTurn` now emits the initial "Thinking / Arix is
     working on this turn." streaming status INSIDE the try block, so the
     `finally` reset (`onStreamingStatus(null)`) is guaranteed to pair with
     it on every exit path (success, failure, cancellation).
   - `SessionExecutionManager`'s `onStreamingStatus` callback always applies
     status RESETS, even while a pause is being finalized — previously the
     `pauseRequested` guard skipped the reset and left the stale working
     status in the execution state.
   - `executeTurn`'s `onFailure` clears `pendingStatusText` /
     `pendingStatusDetail` (and completes pending reconnect blocks) at the
     exact moment the failure message is committed.
   - `executeTurn`'s `finally` now also resets `pendingStatusText` /
     `pendingStatusDetail` (they were missing from the per-turn teardown, so
     a stale status could survive until the whole run ended).
   - `finalizePausedTurn` uses the new `committedInterruptionStatus()` rule:
     only reconnect-style statuses are committed as the final status of an
     interrupted turn; the transient "Thinking / Arix is working on this
     turn." and "Agent engine error" statuses are never baked into the
     committed message, and the pending status state is cleared after
     finalizing.
   - Result: after a failed turn the UI shows only the actual error message
     ("Request failed: …"), never the stale working status. Successful-turn
     behavior is unchanged; `isSending` still resets through
     `runSession`'s unconditional `finally` and `pauseSession`.
2. **Embedded browser fit (Browser tab, Chromium over VNC)**:
   - The browser WebView reports its size on EVERY distinct change (the
     once-only report froze a provisional first measurement and never saw
     rotations).
   - `AlpineChromeController` live re-fits: when the container size changes
     while Chrome runs, the VNC display restarts with the new geometry after
     a 600 ms debounce (Xvnc geometry is fixed at launch); mid-restart size
     changes are picked up by a follow-up pass.
   - openbox is now given an rc.xml with per-app rules — Chromium windows map
     undecorated and maximized, so the browser window (tabs + address bar +
     page content) fills the entire VNC desktop with no title-bar gap.
   - The unconditional `Emulation.setDeviceMetricsOverride` at CDP attach
     was removed (Aether's attach behavior): it forced the page viewport to
     the full desktop size, making page content lay out taller than the
     visible content area and clip at the bottom.
   - The noVNC shell re-fits on WebView resize/orientationchange.
3. **Agent Skills replaced with the upstream Aether set**:
   - The six legacy built-in skills (Email, Web Research, Code Review,
     Document Writer, Translator, Device Control) are gone; the built-in
     catalog is now Aether's "Create Extension" skill, adapted to Arix
     (`arix_extension_manage`, `@baimoqilin/arix-extension-api`,
     `.arix/extensions-src/`). Upgrades uninstall the legacy built-ins via a
     replace-all migration in `syncBuiltInSkills()`.
   - `arix_extension_manage` gained `install_package` / `update_package` /
     `remove_package` actions (ported from Aether's self-management tool,
     backed by Arix's `PiExtensionManager`), so the Create Extension skill
     can actually install local `file:` packages.
   - Aether's `mcp-scripting` skill now ships inside the bundled
     pi-mcp-adapter extension (its package manifest already declared the
     skills directory).
4. **Settings cleanup**: the Assistant entry (hub card + Assistant page +
   role/overlay/pill/summon controls) was removed from Settings. The
   assistant activity itself (quick-settings tile, default-assistant role)
   remains functional.
5. **Timeline navigation removed**: the conversation timeline rail
   (drag-to-jump between turns with the floating preview bubble), its
   target/index computation and the shared `ConversationTimeline.kt` were
   deleted. In-message streaming timelines (pending work / reasoning trace)
   are different features and are untouched.
6. **Size**: kept every existing optimization intact — R8 minify + resource
   shrinking, arm64-v8a only, English-only locales (now via
   `androidResources.localeFilters`, replacing the deprecated
   `resourceConfigurations`), legacy compressed `.so` packaging, exclusion of
   extension banners/docs from APK assets, and `dependenciesInfo` stripping.
   No feature or functionality was removed for size; the release APK stays
   ~12.9 MB.

## v2.7.2 — Crash-on-launch fix (Alpine host runtime), self-healing runtime

v2.7.1 addressed build corruption, but devices still crashed on launch with:

```
E AndroidRuntime: FATAL EXCEPTION: main
E AndroidRuntime: Process: com.arix.app, PID: …
E AndroidRuntime: lv0: Alpine host runtime is incomplete.
```

`lv0` is the R8-merged name of `PiBridgeException`, so the crash is an
uncaught `PiBridgeException("Alpine host runtime is incomplete.")` thrown
from `PiKernelBridge.ensureNodeAvailable()` when the on-disk Alpine runtime
has a rootfs but is missing `bin/proot`, `libexec/proot/loader` or
`lib/libtalloc.so.2`. Diagnosis (compared against upstream Aether, which
does not crash):

1. **The v2.7.0 Get Started flow dropped the old onboarding's AlpineSetup
   step.** Upstream Aether's onboarding is
   `Landing → LocalRuntimeChoice → AlpineSetup → ProviderSetup`; v2.7.0
   replaced it with a single Get Started screen that jumps straight to
   Chat. Fresh installs therefore never extract the runtime at all, and
   nothing ever installs it later.
2. **Nothing self-heals a broken runtime.** A previous interrupted install
   (see 3) leaves the "rootfs present, host binaries missing" state on
   disk forever — every launch re-detects it and no code path repairs it,
   because `AlpineRuntime.initialize()` was only invoked from onboarding
   flows that no longer run.
3. **Concurrent installs corrupt each other.** `installFromAssets()` stages
   into the shared directory `runtimes/alpine-installing` and its first
   step is `stagingRoot.deleteRecursively()`. Two overlapping
   `initialize()` calls each wipe the other's staging tree mid-extraction;
   the activated runtime then has the rootfs but not the host binaries.
   This was reproduced on the JVM (Robolectric): two racing installs
   produced exactly the "incomplete" on-disk state.
4. `ensureNodeAvailable()` threw instead of repairing, and at least one
   main-thread path let that exception escape uncaught — taking the whole
   process down on launch.

Fixes (all verified by new regression tests; 261/261 green on debug AND
release variants):

1. **`ArixAppRuntime.initialize()` (Application startup) now self-heals the
   Alpine runtime on every launch** — a guarded `alpineRuntime.initialize()`
   call reinstalls from the bundled APK assets whenever the on-disk state is
   `NotInstalled` / `Failed` / `MissingAssets`. Repairs the user-visible
   crash state with no user action.
2. **`PiKernelBridge.ensureNodeAvailable()` repairs before throwing** — the
   Aether-style gate: if the runtime is not ready, reinstall from the
   bundled assets and re-inspect; only a state that is still broken after a
   reinstall throws. This kills the crash class at the source for every
   bridge entry path.
3. **`completeGetStarted()` / `skipGetStarted()` restore the first-run
   setup** — after Get Started (or Close), the full runtime install + Pi
   core bring-up runs (asset extraction with progress, then the bridge ping
   and node check), matching the AlpineSetup step the v2.7.0 flow removed.
4. **`AlpineRuntime` install lifecycle is now serialized** — a new
   `installMutex` makes `initialize()` and `reset()` mutually exclusive, so
   the startup self-heal, the Get Started setup and a Settings retry can
   never race through the shared staging directory again.
5. **`ArixForegroundService` scope gained a `CoroutineExceptionHandler`** —
   its `Dispatchers.Main.immediate` scope previously had none; any uncaught
   collector exception crashed the process on the main thread.

New regression tests (`AlpineSelfHealTest`, `CrashReproductionTest`) pin:
incomplete-host-runtime repair, fresh-install extraction, repeated-install
safety, three-way concurrent install serialization, and crash-free launch
with a partial runtime + Alpine-enabled persisted settings.

## v2.7.1 — Crash-on-launch fix (build-integrity), project cleanup

v2.7.0 APKs built on low-memory (4 GB) machines could install successfully
and then crash the instant the app process started. Root cause: v2.7.0 had
enabled `org.gradle.parallel=true`, `org.gradle.caching=true` and
`org.gradle.workers.max=2` in `gradle.properties`. Combined with the
1.4 GB Gradle daemon, the 1.5 GB Kotlin daemon, R8 full-mode and the
npm/pi-bridge build all running at once, an OOM-killed worker could leave a
partially-written APK (truncated dex / resources) that still passes the
installer's signature check but dies at first class load.

Verified clean (all on a fresh sequential build):

1. **Build determinism restored** — `workers.max=1`, `parallel=false`,
   `caching=false`. Packaged artifacts are always complete and reproducible.
   (No feature, dependency or behavior change — purely build integrity.)
2. **Full test suite green** — 254/254 unit tests pass on BOTH the debug and
   release variants, including the Robolectric `StartupSmokeTest` set that
   boots the real `ArixApplication` + `MainActivity` + `AssistantActivity`
   on a simulated Android 11 (API 30) device — the reported crash path.
3. **Release APK audit** — R8 mapping keeps every manifest component and all
   1,350 app classes referenced at runtime; all Get Started strings and
   `arix_mark` survive resource shrinking; arm64-v8a native libs
   (libtermux, libsqliteJni) intact; bridge.mjs + Alpine rootfs assets
   complete; v2 signature verifies.
4. **Project hygiene** — removed 21 stray `pi-bridge/session-*.jsonl` debug
   chat logs, the `.kotlin/` session directory and `.gradle/` state from
   the shipped source tree.
5. **Version bump** — versionCode 42 / versionName 2.7.1, same release
   keystore (`arix-release.jks`), so it installs as an in-place update over
   v2.5.x / v2.6.x / v2.7.0.

If a v2.7.0 APK crashes on launch, uninstall it (its dex is corrupt) and
install v2.7.1 — no data is lost beyond the app's own cache; chat history
and settings live in app-private storage that survives a reinstall only if
`adb backup`/MIUI backup was enabled, so ideally install v2.7.1 directly
over the top (it replaces the broken build in place).

## v2.6.1 release signing

The v2.6.1 APK is signed with the project's original release key
(`keystore/arix-release.jks` via `keystore.properties`, alias `arix`,
password `ArixRelease2026`) — the same certificate as v2.5.x/v2.6.0, so
v2.6.1 installs as an in-place update over any earlier build.

- Signature: APK Signature Scheme v2 (valid for minSdk 26 / Android 8.0+)
- Build: `./gradlew :app:assembleRelease` (R8 minified + resource shrinking
  enabled; **12.4 MB APK**, versionCode 39, arm64-v8a only — tuned for the
  Poco X2 / Android 11 / MIUI 12.5 target device)
- `local.properties` with `sdk.dir=/path/to/android-sdk` is required (it is
  machine-specific and therefore not shipped in the archive). A JDK 17+ must
  be available through `JAVA_HOME`.

## v2.6.1 — Mic permission fix, voice animation, stop button, crash fix, weather & file cards

1. **Mic permission bug fixed** ("granted but still shows *microphone
   permission required*"): the STT engine's `State.Error` was sticky by
   design — `stop()` preserved it, so the composer strip kept showing the
   permission error forever after the dialog grant. Three fixes: `stop()`
   now always resets to Idle; `ERROR_INSUFFICIENT_PERMISSIONS` fired by OEM
   recognizers (MIUI 12.5 included) even with RECORD_AUDIO granted now
   retries once with a fresh recognizer and only errors when the permission
   is genuinely missing; and the composer re-checks the permission on every
   `ON_RESUME` (fixes grants made through system Settings) and auto-retries
   a stale permission error the moment the flag flips to granted.
2. **Voice input animation**: the dictation strip now leads with a 5-bar
   waveform that reacts to the live microphone loudness (the recognizer's
   `onRmsChanged` is finally wired into a `StateFlow` → `ArixUiState`);
   recognizers that never report RMS get a gentle idle wave. The mic button
   keeps its pulse + color morph.
3. **Stop button placement**: while Arix is generating with an empty draft,
   the stop control now occupies the trailing slot **in place of the mic
   button** (voice input hidden) instead of rendering beside it. With a
   draft mid-generation the send button stays (follow-up menu preserved).
4. **Voice settings page removed**: Settings → Voice (the system-STT
   toggle) is gone together with `ArixVoiceRepository`, the `voiceSettings`
   UI-state mirror and its strings. The mic button itself is untouched and
   always available.
5. **`IllegalArgumentException: Can't represent a width of 0 and height of
   263604 in Constraints` fixed**: the reasoning-timeline rows used
   `height(IntrinsicSize.Min)`; huge tool results (an entire fetched
   movie-list page poured into the expanded tool card) made the intrinsic
   height exceed Compose's bit-packed Constraints ceiling and crashed the
   app after visible lag/jitter. The timeline connector line is now drawn
   with `drawBehind` (zero intrinsic measurement), tool-result text is
   capped at 6,000 chars in the expandable blocks, and streaming markdown
   is re-parsed at most ~10×/sec (token bursts batched, final text always
   flushed) — long "latest movies" answers no longer jank the UI.
6. **File-response widget cards**: bare remote FILE links (PDF/zip/image/
   audio/video/apk/docs…) in answers — bare URLs or single markdown links —
   now render as a widget card (type icon, name, origin, size) with
   **Download** and **Share** buttons. Downloads stream in 64 KB chunks
   straight into MediaStore (512 MB cap, never fully in memory — critical
   for the 6 GB RAM Poco X2). The workspace-file card got the same visual
   upgrade.
7. **Weather card widget**: "weather in Delhi", "what's the temperature"…
   are matched natively (no LLM round-trip) and answered with a live
   Open-Meteo card (keyless): current temperature, condition icon,
   feels-like / humidity / wind strip and a 5-day forecast rail. No city in
   the message → IP geolocation fallback.
8. **Size pass**: `com.google.android.material` (XML Material Components)
   was removed — the app is 100% Compose and the XML theme now derives from
   `Theme.AppCompat.DayNight.NoActionBar` (both activities are
   AppCompatActivities; window scaffolding identical). `androidx.documentfile`
   (previously a material transitive, used directly) is now declared
   explicitly. APK: 13.1 MB → 12.4 MB with zero features removed.

## v2.6.0 release signing

The v2.6.0 APK is signed with the project's original release key
(`keystore/arix-release.jks` via `keystore.properties`, alias `arix`,
password `ArixRelease2026`) — the same certificate as earlier v2.5.x builds,
so v2.6.0 installs as an in-place update without uninstalling.

- Signature: APK Signature Scheme v2 (valid for minSdk 26 / Android 8.0+)
- Build: `./gradlew :app:assembleRelease` (R8 minified + resource shrinking
  enabled; 13.1 MB APK)
- `local.properties` with `sdk.dir=/path/to/android-sdk` is required (it is
  machine-specific and therefore not shipped in the archive). A JDK 17+ must
  be available through `JAVA_HOME`.

## v2.6.0 — System-default STT, Gemini-style voice/send button, offline voice stack removed

1. **Kokoro TTS, Vosk STT and the "Hey Arix" wake word removed completely**
   (`voice/`): `ArixTtsEngine` (sherpa-onnx/Kokoro), `ArixSttEngine` (Vosk),
   `ArixVoiceModelManager` (on-demand ~40 MB + ~100 MB model downloads) and
   `ArixWakeWordService` (always-on microphone foreground service) were
   deleted together with their wiring (ViewModel, Settings → Voice page,
   manifest service/permissions, notification channel, ProGuard rules) and
   the `vosk-android`, `sherpa-onnx` and `commons-compress` dependencies.
   Nothing downloads models anymore; the wake-word toggle, TTS voice/rate
   pickers, model storage/delete rows are gone from Settings.
2. **System-default speech recognition** (`voice/ArixSystemSttEngine.kt`):
   voice input now uses `android.speech.SpeechRecognizer` — the device's own
   recognition service (the engine behind keyboard voice typing). Works in
   every language the system recognizer supports, needs no downloads and
   adds zero APK size. Partial transcripts stream live into the composer
   strip, finals are appended to the draft, a silence watchdog auto-stops
   the summoned assistant panel's auto-listen, "nothing was said" (NO_MATCH /
   SPEECH_TIMEOUT) ends quietly instead of showing an error, and real
   errors (no recognizer installed, network, permissions) are surfaced in
   the composer strip.
3. **Gemini-style voice/send button** (`ui/ConversationUi.kt` +
   `assistant/AssistantActivity.kt`): the send button's trailing slot now
   doubles as the voice input button, exactly like Google Gemini —
   empty input → the mic button is shown and send is hidden; the moment the
   user focuses the field and starts typing, the mic morphs (scale + fade
   `AnimatedContent`) into the send button; clearing the draft brings the
   mic back; while listening the button is a pulsating red stop control.
   Typing or tapping into the input field stops dictation first.
4. **Bug fixes**:
   - `gradle.properties` pointed `org.gradle.java.home` at a machine-specific
     absolute path (`/home/z/jdks/...`) — every build on any other machine
     failed before compiling anything. Gradle now resolves the JDK through
     the standard `JAVA_HOME` lookup.
   - The assistant panel's mic-permission flag was cached in a
     `remember(context)` that never refreshed after the runtime permission
     dialog — the first manual mic tap re-requested permission. It is now
     observable state updated by the permission launcher.
   - The assistant panel auto-started the mic even when text was shared in
     (ACTION_PROCESS_TEXT / ACTION_SEND), popping the recognizer over the
     prefilled draft. Auto-listen is skipped when a prefill exists (keyboard
     editing starts instead).
   - Dead `committedVoiceBase` state (write-only, never read) removed from
     the composer; the never-shown `Initializing` download-progress branch
     and unused `chat_voice_initializing` / `chat_voice_error` /
     wake-word / TTS strings were removed.
   - Speech recognizer errors no longer fail silently — they render in the
     live transcript strip.
5. **APK size**: dropping sherpa-onnx (native `.so` libraries for every ABI
   it shipped) and commons-compress removes several MB from the APK with
   zero feature loss — voice input still works via the OS recognizer.
   Version: 2.6.0, versionCode 38.

## v2.5.3 — Fault-tolerant model downloads (Kokoro SSL fix)

1. **Kokoro / Vosk downloads no longer abort on flaky networks**
   (`voice/ArixVoiceModelManager.kt`): the ~100 MB Kokoro tar.bz2 streamed
   from GitHub's release CDN frequently died mid-transfer on mobile networks
   with `SSL routines:OPENSSL_internal:DECRYPTION_FAILED_OR_BAD_RECORD_MAC`
   (TLS record corruption) — previously a single transport hiccup failed the
   entire download. Downloads are now fault-tolerant:
   - **Retry with resume**: up to 10 attempts with 1s→8s exponential backoff;
     the partial cache file is kept and each retry sends
     `Range: bytes=<n>-`, so the transfer **continues from the last byte**
     instead of restarting (both alphacephei.com and GitHub's release CDN
     advertise `Accept-Ranges`; verified). HTTP 206 = append-resume, a 200
     response to a Range request truncates and restarts, and 416 responses
     are reconciled against the `Content-Range` total.
   - **Poisoned connection recycling**: `Connection: close` on every request
     plus `connectionPool.evictAll()` before each retry, so a corrupted TLS
     session can never be silently reused.
   - **Cross-session resume**: the partial `voice-<model>.download` cache is
     no longer deleted at the start of an install — a download that failed
     yesterday resumes today. The cache is only dropped when the bytes prove
     unusable (permanent HTTP 4xx, or an extraction-stage failure on a fully
     downloaded archive).
   - **Progress now reports resume state** and the Kokoro progress estimate
     was corrected to the real release size (103,248,205 bytes; the server
     Content-Length stays authoritative).
   - Permanent client errors (dead URL → HTTP 4xx) fail fast with the real
     status code instead of burning ten retries.

## v2.5.2 — Voice fixes, robot home screen, voice-first assistant panel

1. **Vosk model download fixed** (`voice/ArixVoiceModelManager.kt`): the
   downloaded archive is cached as `voice-<model>.download`, so the old
   `archiveFile.name.endsWith(".zip")` check was always false — the Vosk ZIP
   was sent into the tar.bz2 extractor and failed with
   `"Stream is not in the BZip2 format"`. The container format is now
   resolved from the source URL **and verified with magic bytes** (PK zip
   header vs BZh), so a mirror serving a different container can never reach
   the wrong extractor. The completeness check now only trusts the
   server-provided Content-Length, and zero-byte downloads fail fast.
2. **Voice input button always visible** (`ui/ArixApp.kt`): the composer mic
   was gated on `voiceInputEnabled && voskModelInstalled` — on a fresh
   install the model was missing, so the button never appeared and the model
   could never download from the composer (chicken-and-egg). The button now
   shows whenever voice input is enabled; the first tap downloads the model
   on demand and streams live progress through the new
   `State.Initializing(detail)` strip text ("Downloading voice model… 47%
   (19.1 / 39.3 MB)").
3. **Home screen redesigned around the robot** (`ui/ArixAiRobot.kt` +
   `ui/ConversationUi.kt`): all four quick-action suggestion cards and the
   entire "Today's tip" card were removed (nothing replaces them). The hero
   is a large, fully animated 3D-style AI assistant drawn 100% with Compose
   Canvas (zero new APK assets): glossy violet/blue body with rim lights and
   specular highlights, black-glass face with glowing eyes that pulse, blink
   and glance around, a glowing antenna with radar ping, a chest "A" emblem
   with neon glow, slow floating above a rotating holographic energy ring,
   and drifting neon particles. The IST typewriter greeting stays.
4. **Voice-first summoned assistant panel** (`assistant/AssistantActivity.kt`):
   the panel now opens DIRECTLY expanded (no more collapsed pill requiring a
   second tap). On open it starts listening automatically (requests mic
   permission first if needed); a new silence watchdog in
   `voice/ArixSttEngine.kt` auto-stops the mic after ~10 s of the user not
   talking; tapping the input box stops listening; the mic button is always
   visible (same on-demand download fix as the main composer).
5. **movie_explorer chat command removed** (`data/ArixNativeTools.kt`,
   `ui/ArixViewModel.kt`): the client-side intent router no longer intercepts
   movie requests (it scraped the unreliable watchonlinemovies site); movie
   messages now flow to the LLM as normal turns. The Tools → "Watch Movies &
   Series" screen (MovieBox/WeFeed API) is untouched, and anime_explorer,
   qr_code and system_control commands work exactly as before. Historical
   movie_explorer tool invocations still render their widgets.
6. **Version**: 2.5.2, versionCode 36 (in-place upgrade, same signing key).

## v2.5.1 — Browser infobar fix, double-browser fix, version 2.5.1

1. **"--no-sandbox" browser warning fixed** (user report: the agent browser
   shows "You are using an unsupported command-line flag: --no-sandbox.
   Stability and security will suffer"): Chromium launches with
   `--test-type`, which makes `AddInfoBarsIfNecessary` return before
   `ShowBadFlagsPrompt` ever runs (Chromium `infobar_utils.cc` short-circuits
   on `switches::kTestType`) — the exact mechanism ChromeDriver uses. The
   flag changes nothing else. `--no-sandbox` itself stays: the browser runs
   as root inside the proot Alpine guest where the namespace sandbox cannot
   work and Chromium refuses to start without it. Both launchers were
   patched (`AlpineChromeController` shell launch + `SharedChromeManager`
   `ChromeArguments`).
2. **Double browser fixed** (three layers):
   - **Live panel no longer auto-shows** (`ui/ConversationUi.kt`): since
     v2.4.9 made the browser tool always-on, `chromeDisplayState.isActive`
     became true for every agentic browsing turn, so the live noVNC panel
     auto-rendered in the chat even with the Chrome toggle off — while the
     same browser was one tap away in the Browser tab. The live preview
     panel is now strictly opt-in via the Chrome toggle (the documented
     v2.4.9 design: "the Chrome mode toggle now only controls the extra
     visual live-preview rendering"). The agent keeps full always-on
     browser access; results and screenshots still flow through the tool
     output, and with the toggle off the browser tool rows stay in the
     pending tool list (previously they were hidden — folded into the
     panel — and the turn looked silent).
   - **Agent-mode panel can no longer leak the Chrome desktop**:
     `agentModeDisplayState` is the same object as `chromeDisplayState`
     (ArixApp passes `uiState.chromeDisplayState` for both), so a stale
     agent-mode draft flag plus a running agent browser used to render the
     browser under the "Agent Mode" panel via the `latestPreviewPath`
     fallback — a second copy of the same desktop. The agent-mode panel now
     requires real `agent_mode` tool invocations; the preview-path fallback
     is gone (it was chrome data, never agent-mode data). The v2.4.6
     one-panel dedup (`agentModePreviewVisible && !chromePreviewVisible`)
     still holds; an agent-mode turn also suppresses a stale chrome panel.
   - **Single-window guarantee** (`data/AlpineChromeController.kt`): after
     the CDP session connects, every page target other than the active one
     is closed through the DevTools HTTP API (`/json/close/{targetId}`), so
     exactly one Chromium window exists even if a crash-restore or a
     singleton race spawns extras. `--disable-session-crash-bubble` also
     kills the "Restore pages?" bubble after the app's sweep-kill restart
     cycle.
3. **Version**: 2.5.1, versionCode 35 (in-place upgrade over 2.4.9, same
   signing key).
4. **Tests**: `V251SourceGuardTest` (7 guards pinning every fix above);
   `V246SourceGuardTest`'s one-panel guard still passes unchanged.

## Identity

| Item | Value |
| --- | --- |
| App name | Arix |
| Application ID (package) | `com.arix.app` |
| Namespace (app module) | `com.arix.app` |
| Namespace (shared module) | `com.arix.app.shared` |
| Root project name | `Arix` |
| Version | 2.2.2 (versionCode 14) |
| Developer | Anupam |
| Website | https://webxanupam.blogspot.com |

## Changes applied to upstream

1. **Rebrand (complete)**: project name, package/namespace (`com.zhousl.aether` /
   `com.baimoqilin.aether` → `com.arix.app`), app label, user-visible strings,
   system prompts, HTTP user agent. A second, exhaustive pass renamed every
   remaining `Aether`/`aether` identifier (classes like `ArixViewModel`,
   internal keys, Termux workspace paths `~/.arix`, the JS bridge module,
   extension script API `arix.*`, compose resources, CI, docs, issue
   templates). Zero `Aether` strings remain inside the APK.
2. **English only**: removed Simplified Chinese and Persian locales
   (`values-zh-rCN`, `values-fa`, Vazirmatn fonts, RTL layout logic,
   non-English `AppLanguage` entries). `resourceConfigurations += "en"`
   strips locale resources from every dependency as well.
3. **Language option removed**: the Settings → General language picker is gone
   (English is the only interface language). The theme picker remains.
4. **About page**: author is **Anupam**, website links to
   https://webxanupam.blogspot.com, the upstream GitHub row was removed, and
   the privacy policy points to the project website.
5. **GitHub update system removed**: deleted `AppUpdateManager` (+ test), the
   in-app update checker / "Check GitHub Releases" settings row / update
   dialog / APK download+install flow, the nightly build type & CI workflow,
   the `UPDATE_CHANNEL` build config field, the `REQUEST_INSTALL_PACKAGES`
   permission, and the unused App-Store lookup service in `shared`.
6. **iOS fully removed**: `iosApp/`, `shared/src/iosMain`, `shared/src/iosTest`,
   the `third_party/ish-arm64` submodule (+ `.gitmodules`), iOS build scripts,
   `iosArm64`/`iosSimulatorArm64` targets, `ktor-client-darwin`, the iOS CI
   job. The `shared` module now targets Android only.
7. **Assistant mode (new)** — Gemini-style quick assistant:
   - `AssistantActivity`: a translucent bottom panel summoned from anywhere.
     Collapsed it shows a capsule pill ("Ask Arix"); tapping expands it into
     a compact chat with the current session, streaming responses, and an
     "Open in Arix" button. It shares the runtime, session engine and
     persisted chat state with the main app, so conversations continue
     seamlessly.
   - **Default assistant**: Settings → Assistant → "Set as default assistant"
     uses `RoleManager.ROLE_ASSISTANT` (Android 10+). When Arix is the default
     assistant, the system corner-swipe / assistant gesture summons the panel.
   - **Quick settings tile** (`ArixTileService`): add "Arix Assistant" from the
     QS panel edit mode; tapping summons the panel from anywhere.
   - **Floating pill** (`ArixOverlayPillService`): a draggable overlay pill
     (SYSTEM_ALERT_WINDOW) that snaps to screen edges. Tap to summon,
     long-press to hide. Toggled in Settings → Assistant.
   - **Overlay permission**: Settings → Assistant → "Display over other apps"
     opens the system overlay-permission screen (also required on MIUI for
     reliable background summoning).
   - **Text selection & share**: selecting text anywhere offers "Arix" in the
     selection menu (ACTION_PROCESS_TEXT); sharing plain text to Arix opens
     the panel pre-filled.
8. **Release signing** (replaces the removed nightly signing):
   `signingConfigs.release` reads `keystore.properties` in the project root.
9. **Size optimizations** (no features removed): R8 minify + resource shrinking
   (inherited from upstream), English-only resource filtering, dependency-info
   blob stripped from the APK, `-repackageclasses ''` +
   `-allowaccessmodification`, release lint gate disabled
   (`checkReleaseBuilds = false`), arm64-v8a only.
10. **v2.1.7 — crash fix + data carry-over**:
    - **Fixed the instant crash on open** introduced in v2.1.6: the new
      mod-service bookkeeping list in `ArixViewModel` was declared *after* the
      `init {}` block that uses it. Kotlin initializes properties in
      declaration order, so the list was still `null` when
      `registerCoreModServices()` appended to it, throwing an
      `NullPointerException` inside the ViewModel constructor for *every*
      launch of MainActivity or AssistantActivity. The list is now declared
      before `init`, and `onCleared` unregisters defensively.
    - **User data survives the v2.1.5 → v2.1.7 update**: v2.1.6's blanket
      rename had also renamed every persisted store file
      (`aether_chat_history.db`, `aether_settings`, `aether_chats`,
      `aether_agent_extensions`, `aether_scheduled_tasks`,
      `aether_pi_extension_state`, `aether_discovered_skills`,
      `aether_native_mods` → `arix_*`), which silently reset settings,
      provider keys and chat history. `LegacyAetherStoreMigrator` now runs
      once at app startup and copies the old files over the new names before
      any store is opened.
    - **Room schema v8** (`Migration7To8`): renames the legacy
      `chat_agent_messageId` column to `arixMessageId` by recreating
      `chat_agent_message_refs` (safe on minSdk 26, whose SQLite lacks
      `ALTER TABLE RENAME COLUMN`). The migration detects which of the two
      historical v7 shapes the database uses, so both v2.1.5 databases and
      databases created by the broken v2.1.6 upgrade cleanly. The historical
      `Migration5To6` SQL was restored to its original column names.
    - Verified with Robolectric startup smoke tests (Application, settings,
      chat state, MainActivity + AssistantActivity composition on a simulated
      API 30 device) plus a real-SQLite migration test: 353 unit tests, 0
      failures.

## v2.4.9 — Visual display cleanup, MCP battery fix, screen-read agent mode, offline voice stack

1. **No visual display in normal conversation** (user request): the
   `alwaysShowVisualInteractions` setting was REMOVED entirely (setting,
   repository key, settings toggle, and the `alwaysShowVisualFeedback` UI
   plumbing). The live visual panel now renders only when the session is an
   actual agentic/system task — Agent Mode selected with real invocations, or
   Chrome browsing with real browser invocations/preview. Plain chat turns
   never show a panel. Dead "visual interaction" tool-name matchers
   (system_control/tavily_search/fetch_web_url/web_search/web_fetch) and the
   "Always show visual interactions" strings were deleted.
2. **MCP no longer auto-connects** (user request: battery drain): the bundled
   pi-mcp-adapter reverted to LAZY connection. Only servers explicitly marked
   `eager`/`keep-alive` connect at load; default servers connect on first
   tool call and close after the idle timeout. The unconditional
   `markKeepAlive` (which kept every server alive and auto-reconnected them
   every 30 s forever) now applies only to explicitly eager/keep-alive
   servers.
3. **Agent Mode reads the screen instead of taking screenshots** (user
   request): `ArixAgentModeController.screenshot()` (adb shell screencap +
   adb pull into app storage) was replaced by `read_screen` —
   `adb shell uiautomator dump` parsed into a compact structured text tree
   (bounds, class, text, description, id, clickable/scrollable flags). No
   image is captured and nothing is stored; a transient XML on /sdcard is
   deleted immediately. A safetynet fallback (`dumpsys window`) reports the
   focused window when the dump fails so the agent is never blind. The tool
   definition and system prompt now teach the model to read the screen and
   decide itself (no hardcoded host-side "brain"), and explicitly forbid
   `screencap`.
4. **Agent browser always available** (user request: browse backend / fetch
   data): the `browser` tool is no longer gated behind the per-session Chrome
   toggle on Android — the agent can open Arix's Chromium on demand for any
   task (browse endpoints, log in, fetch data). The Chrome mode toggle now
   only controls the extra visual live-preview rendering.
5. **Pro composer + assistant panel** (user request): the assistant pill got
   a glowing pro restyle, and both the chat composer and the quick assistant
   panel gained a dedicated attach button (files route through the shared
   draft pipeline) plus an offline voice-input mic button next to send. The
   composer shows a live "Listening…" strip with partial transcripts while
   dictating.
6. **Offline voice stack** (user request): new Settings → Voice page.
   - STT: Vosk small en-US model (com.alphacephei:vosk-android), fully
     offline, downloaded on demand (~40 MB) from alphacephei.com.
   - Wake word: "Arix" / "Hey Arix" always-on listener
     (ArixWakeWordService, microphone foreground service + closed Vosk
     grammar) that summons the assistant overlay from anywhere.
   - TTS: free offline Kokoro (sherpa-onnx `com.github.k2-fsa.sherpa-onnx:
     sherpa-onnx:1.13.7`, int8 English model ~82 MB from the official
     sherpa-onnx releases, 2 CPU threads — sized for a Poco X2). Male voice
     by default (am_michael), 53-voice picker, rate slider, test button,
     auto-speak of completed replies.
   - Model download progress, storage usage and deletion all live in
     Settings → Voice; RECORD_AUDIO is requested at runtime only.
7. **Build/deps**: version 2.4.9 (versionCode 34); new deps vosk-android
   0.3.47, sherpa-onnx 1.13.7 (JitPack), commons-compress 1.27.1 (tar.bz2
   extraction). APK grows by the two offline engines' native libs (kept
   arm64-v8a only); all models stay out of the APK and download on demand.

## v2.4.6 — Double display fix, blank-browser fix, Tools polish, Android shell

Targeted fixes only — same functionality, labels, icons, colors and navigation
everywhere. 541 Android unit tests (265 app + 126 shared + 150
terminal-emulator, all re-run green) pass; release APK signed with the same
key as every release since v2.2.1 (SHA-256 `b4a16e88…3166b`), versionCode 31,
~13.79 MB (unchanged budget).

1. **Double visual display while browsing** (`ui/ConversationUi.kt`):
   `agentModeDisplayState` and `chromeDisplayState` are the SAME state object
   (`ArixApp` passes `uiState.chromeDisplayState` for both), so whenever both
   preview flags were true — always, with "Always show visual interactions"
   on (the default) — the pending timeline rendered the SAME virtual display
   twice, stacked, one as a live noVNC WebView and one as a bitmap panel.
   The agent-mode panel now yields whenever the Chrome panel is visible
   (`agentModePreviewUnfiltered && !chromePreviewVisible`); exactly one panel
   renders in every state. No other preview condition changed.
2. **Blank white browser display** (three root causes, three small fixes):
   - `data/AlpineChromeController.kt`: Chromium booted on `about:blank` —
     a full-bleed WHITE page that read as a broken display. It now boots on
     a small dark "Arix Browser — ready" start page (a data: URL — no server
     needed). The first agent `Page.navigate` replaces it exactly as before.
   - `ui/AlpineChromeScreen.kt`: the noVNC status bar is hidden by design, so
     a failed or stalled VNC connection was a silent blank screen. A
     connection watchdog now watches for the first painted framebuffer and,
     if none lands within 9 s, reveals a compact dark status bar so noVNC's
     own state text ("Connecting", "Something went wrong, connection is
     closed") is visible; it hides itself again the moment a frame lands.
   - `ui/ConversationUi.kt`: the chat live-view WebView painted a solid WHITE
     background until the noVNC page loaded — now transparent so the dark
     panel backdrop shows through while the viewer connects.
3. **Tools hub + tool screens layout polish** (`ui/ArixToolsUi.kt`):
   larger rounded entry cards (24 dp radius, 96 dp consistent height floor,
   58 dp icon containers, stronger-but-subtle border/shadow depth, 17 sp /
   12 sp typography hierarchy), a fixed 30 dp chevron slot so chevrons align
   perfectly down the screen, content moved up (4 dp header top inset, no
   extra spacer, 12 dp card spacing) — and a clear 18 dp gap between the
   header (back button, title, subtitle) and the search bar / first content
   row on EVERY tool screen (Movies, QR, Anime, File Share, details, player,
   hub). Labels, icons, accent colors and click behavior unchanged.
4. **Android shell — no root, no accessibility, no USB/wireless debugging**
   (`data/ArixAndroidShell.kt`): the device's own `/system/bin/sh` exec'd on
   a real pty through the same Termux `TerminalSession` JNI machinery that
   powers the Alpine tab (the pty helper is process-agnostic). Two surfaces:
   - **Android Shell tool screen** (Tools hub → "Android Shell"): a full
     interactive terminal (soft keyboard + extra-keys row, Ctrl/Alt latching)
     running with the app's own uid — getprop, pm, ps, df, toybox, logcat.
     `AlpineTerminalScreen` gained backward-compatible `screenTitle` /
     `showStoragePermissionBanner` parameters; the Alpine tab is unchanged.
   - **`android_shell` host tool** for the AI agent: one-shot commands via
     `sh -c` with a clamped timeout (1–120 s, default 15 s), concurrent
     stdout/stderr capture (no pipe deadlock), forceful kill on timeout and
     a head+tail 12 KB output cap for the LLM context. Registered in
     `ArixToolExecutor` + `ArixApplication` like `system_control`.
5. **Tests**: `ArixAndroidShellToolTest` (10 tests — JSON contract, timeout
   clamp, output capping, error paths, launch spec), `V246SourceGuardTest`
   (8 source guards pinning every fix above), `ArixToolExecutorTest` updated
   for the new always-on host tool. 265 app tests, 0 failures.
6. Size pass: no change needed — the APK stays at ~13.79 MB (R8 full mode +
   shrinkResources + en-only + arm64-v8a + compressed native libs were
   already optimal; the new shell tool adds ~66 KB compressed). No feature
   removed.

## v2.4.5 — Bug-fix audit: terminal P0, process lifecycle, bridge races, leak cleanup

Minimal, isolated fixes only — no architecture changes, no feature or API
removals, no behavior changes beyond the confirmed bugs below. 522 Android
unit tests (246 app + 126 shared + 150 terminal-emulator) pass; the 9
pre-existing pi-bridge node test failures (Aether→Arix rebrand drift in test
fixtures, byte-identical in the v2.4.4 source) are unchanged.

1. **P0 — Alpine terminal StackOverflowError on every keypress**
   (`ui/AlpineTerminalScreen.kt`): `ArixTerminalViewClient` declared ctor
   properties `readControlKey`/`readAltKey` that collided with the
   identically-named `TerminalViewClient` overrides. Kotlin resolves an
   override body's same-named invocation to the member function (member
   functions beat a same-named property's invoke convention), so
   `readControlKey()` called itself infinitely — and `TerminalView` polls
   `mClient.readControlKey()/readAltKey()` on every keypress, so ANY typed
   character crashed the main thread with `StackOverflowError` (8192 KB
   stack, the diagnostic signature seen across v2.4.x). Renamed the
   callbacks to `readControlKeyState`/`readAltKeyState`; `onCodePoint()`
   now reads the ALT state once through the renamed callback. CTRL/ALT
   state, latching, modifier consumption, paste and all input behavior are
   preserved exactly (same callbacks, same call order). Regression-guarded
   by `TerminalClientRecursionGuardTest` (comment-stripped source scan for
   the self-recursive override shape).
2. **Chromium/Xvnc/websockify orphaned processes** (`data/AlpineChromeController.kt`):
   `process.destroy()` only signals the top-level proot wrapper — proot does
   not forward signals to its tracees, so the in-guest EXIT trap does not
   reliably fire and Chromium/Xvnc/openbox/websockify survived app kill or
   stop, keeping ports 9222/5900/6080 occupied (and a fresh start could
   attach CDP to the orphaned browser). Two smallest-surface changes,
   mirroring the proven `SharedChromeManager` pattern: (a) the launch script
   sweeps stale guest processes (pkill TERM then KILL) BEFORE starting the
   new ones — this branch only runs when the previous session's top process
   is already dead, so a healthy session is never touched; (b) `stopLocked()`
   now awaits a short-lived guest-side kill script (bounded 10 s) so a
   following start can never race the cleanup.
3. **CDP WebSocket leak on failed start** (same file): if `connect()` or the
   initial `Page.enable`/`Runtime.enable`/`Emulation.*` commands timed out,
   the okhttp WebSocket kept connecting in the background forever. The setup
   block now closes the session on every failure path.
4. **Chrome screenshots leaked unboundedly** (same file): every Chrome action
   persisted a full-resolution JPEG into `filesDir/alpine-chrome/captures`
   and nothing ever deleted them. The JSON tool result carries
   `screenshot_base64`; nothing re-reads the files, so a 24-file rotation
   (`pruneOldCaptures`) safely bounds the disk footprint.
5. **Pi bridge pending requests could hang forever after a crash+restart**
   (`data/pi/PiKernelBridge.kt`): `failPendingRequests` returned early when a
   restart had already installed a new process — stranding every pending
   request of the DEAD generation; `run_turn`/`subscribe` have no timeout, so
   the chat showed "Thinking…" forever and the session wedged. The early
   return is gone; the existing generation filter already fails exactly the
   dead generation's requests (new-process requests are never touched).
6. **Stale bridge-side extension subscriber ids** (same file): a terminated
   `subscribe_arix_extensions` request left its id registered in the bridge
   forever; host calls route to the FIRST registered id, so after a
   resubscribe the extension `ctx.host` calls timed out (2 min) on the node
   side. `request()`'s `finally` now sends `unsubscribe_arix_extensions`
   (already implemented by the bridge) with `startIfNeeded=false`, best-effort.
7. **TimeoutCancellationException wedged two screens**
   (`ui/ArixViewModel.kt`): it is a `CancellationException` subclass, so the
   provider-OAuth failure branch silently returned (login stuck on "Waiting
   for authorization." with `isRunning=true` forever) and the Pi-core setup
   failure branch rethrew (spinner `isChecking=true` forever — every later
   refresh short-circuited). Both guards now let timeouts fall through to
   the error path; real scope cancellation (VM cleared) behaves exactly as
   before.
8. **Mid-turn message-injection polling died silently** (`data/pi/PiAgentRunner.kt`):
   a 15 s `steer()` timeout was rethrown as CancellationException, killing
   the polling job for the rest of the turn. A timeout now defers the
   message (existing follow-up replay path) and keeps polling; real
   cancellation still propagates.
9. **Alpine run logs leaked forever** (`runtime/AlpineRuntime.kt`): background
   runs left `runs/<runId>/` (stdout/stderr logs) on disk forever — the
   reaper removed only the in-memory entry, after which `fetchExecution`
   already answered "Unknown run_id", so the files were unreachable. The
   reaper now deletes the run directory when it removes the entry (same
   observable 5-minute window). `executeCommand` temp files are now deleted
   on the spawn-failure path and via `try/finally`.
10. **OkHttp Response leak on failed model downloads**
    (`data/ArixLocalModels.kt`): the two early returns (HTTP error / empty
    body) never closed the response — connection-pool pressure and "connection
    leaked" warnings on every 404/401 from gated catalog URLs. Now closed.
11. **WebViewFetcher native-memory leak** (`data/WebViewFetcher.kt` +
    `ArixViewModel.onCleared`): per-origin headless WebViews were never
    destroyed, and every AssistantActivity open created a fresh ViewModel
    with its own fetcher — Chromium instances accumulated per origin per
    open. `destroyAll()` releases them on VM clear (main-thread destroy;
    in-flight fetches fail fast through the existing error path).
12. **Hardening (no behavior change)**: tar extraction containment now uses
    the strict `canonicalRoot.path + File.separator` form used everywhere
    else in the file (a `../rootfs-evil` sibling previously passed the weak
    prefix check — bundled-asset trust makes this defense-in-depth); MCP
    broker shell scripts single-quote-escape the server id (a quote-bearing
    id from an imported backup could previously break out of the assignment);
    `isServerReachable` now applies its documented `timeoutMillis` budget
    via OkHttp's per-call timeout (a dead CDN stalled the episode card ~17 s
    instead of the designed 4 s; slow-but-live servers remain manually
    selectable at the tail).
13. **Audited and deliberately NOT changed** (reported in the audit report):
    all `runBlocking` media/anime call sites (verified `Dispatchers.IO` on
    every caller chain), `Channel.UNLIMITED` in the shared bridge client
    (lifetime-bounded; the app-side `PiKernelBridge` already guards its
    consumer; the shared client has no production caller in this Android
    fork), `platform = "ios"` occurrences (dead code — the Android app sends
    `platform: "android"` on every real request), Alpine storage binds
    (correct in granted/denied/revoked/granted-later/unavailable states),
    ARM64-only ABI (intentional), and the absence of a hard timeout on
    `run_turn` (long agent turns are legitimate; a watchdog would change
    behavior).
14. **Version**: 2.4.5 (versionCode 30) — in-place upgrade over v2.4.x, signed
    with the same release key. APK 13.78 MB, byte-for-byte the same size
    budget as v2.4.4 (R8 + resource shrinking + English-only resources +
    arm64-v8a only + compressed native libs; the remaining mass IS the
    Alpine rootfs, AI bridge and extensions — no further safe shrink exists
    without removing features).

## v2.4.4 — Terminal crash hardening, MCP auto-connect, build hygiene

1. **Alpine terminal crash (typing/pressing Enter) eliminated for good**
   (terminal-emulator / terminal-view / `AlpineTerminalScreen.kt`):
   - v2.4.3 removed the blocking input write, but a second, independent crash
     path remained: the terminal's buffer layer **threw
     `IllegalArgumentException` on the main thread** while processing the
     shell's echo/output — `TerminalRow.setChar()` ("Cannot put wide character
     in last column" / column out of range), `TerminalBuffer.setChar()`,
     `blockCopy()`, `blockSet()`, `scrollDownOneLine()`,
     `externalToInternalRow()`. Typing or pressing Enter is exactly what makes
     the shell echo output, which fed the parser until it hit one of these
     throws → uncaught exception → "Arix keeps stopping".
   - Every throw site in the VT100 data layer is now a guarded no-op (or a
     space-substitution for the wide-char-at-last-column case): worst case one
     garbled cell or skipped frame instead of a dead app.
   - `TerminalSession.MainThreadHandler.handleMessage` now wraps
     `emulator.append()` in a catch-all that logs, **resets the escape-sequence
     parser**, and keeps the session alive.
   - All four session threads (pty reader, pty writer, process waiter, input
     writer executor) catch `Throwable` — no session-thread failure can kill
     the process anymore.
   - `TerminalView.onDraw()` skips a damaged frame instead of crashing on an
     inconsistent row; `onSizeChanged()` bursts (Compose keyboard-open
     animations) are coalesced into one `updateSize()` per frame, removing the
     SIGWINCH/reflow storm that made the UI stutter for seconds while the
     keyboard opened.
   - `TerminalSession.updateSize()` no longer ioctls a closed pty fd after the
     process exits (fd-reuse corruption guard), and resize failures are logged
     instead of thrown.
   - `AlpineTerminalScreen` session client is fully defensive (clipboard,
     title, repaint callbacks wrapped), with the attached view registered
     explicitly.
   - New `HostileOutputCrashTest` (5 tests) feeds wide chars at the last
     column, hostile CSI/DECSTBM parameters, combining-char floods and broken
     UTF-8 through the public `append()` path — all pass crash-free.
2. **MCP auto-connect on every app open** (`extensions/pi-mcp-adapter/init.ts`):
   - Previously only servers explicitly marked `eager`/`keep-alive` connected
     when the adapter loaded; default-`lazy` servers waited for the first tool
     call. Because the Node bridge process dies with the app, MCP connections
     appeared "lost" after every reopen until something poked them.
   - The adapter now connects **every enabled MCP server at startup** and marks
     them all keep-alive: the 30-second health check auto-reconnects dropped
     connections and idle shutdown no longer closes servers while the app is
     open. The existing app-open prewarm (`prewarmPiExtensions`) boots the
     bridge and the adapter immediately, so servers reconnect automatically
     whenever Arix is opened.
3. **Build hygiene / unused-code audit** (no feature removed):
   - Audited every Gradle dependency — all are referenced by shipped code
     (appcompat, material theme base, sora-editor file editor, jsoup, flexmark,
     snakeyaml, media3, okhttp, posthog…). Nothing removable; the vendored
     Termux terminal-emulator/-view modules are **required** — they are the
     Alpine terminal UI itself.
   - terminal-emulator's JNI layer now compiles for `arm64-v8a` only (the one
     ABI the app packages), cutting ~75% of native build time with zero APK or
     runtime change.
4. **Version**: 2.4.4 (versionCode 29) — in-place upgrade over v2.4.x; signed
   with the same release key. APK size 13.78 MB (already optimal: R8 +
   resource shrinking + compressed native libs + minified pi-bridge bundle;
   remaining size is the Alpine rootfs and AI bridge features themselves).

## v2.4.3 — Terminal freeze/crash fix, Alpine ADB, premium home & Tools redesign

1. **Alpine terminal freeze → crash fixed at the root**
   (`third_party/termux/terminal-emulator/.../TerminalSession.java`):
   - Symptom: typing or pasting into the Alpine terminal froze the app for a
     few seconds, then it crashed (ANR).
   - Root cause: `TerminalSession.write()` performed a **blocking**
     `ByteQueue.write` (a 4 KB queue with `wait()` back-pressure) **on the UI
     thread** for every keystroke and paste. The proot-backed Alpine shell
     consumes pty input slowly (ptrace syscall translation), so the pty buffer
     plus the 4 KB queue filled up and the main thread blocked in `wait()` →
     ANR → crash. Pasting anything sizeable reproduced it instantly.
   - Fix: all input writes are now dispatched to a dedicated single
     background writer thread (`TermSessionInputWriter`); the payload is
     copied first so caller buffers stay reusable, the input queue was
     enlarged 4 KB → 256 KB to absorb large pastes, and the writer thread is
     shut down cleanly in `cleanupResources`. The UI thread can never block
     on a slow shell again — typing and pasting stay smooth under any load.
2. **Alpine ADB support — control this device from the Alpine terminal**
   (`runtime/AlpineRuntime.kt`, `ui/SettingsScreen.kt`):
   - New **ADB tools** environment preset (Settings → Alpine) installing
     Alpine's `android-tools` package (adb + fastboot) — verification command
     `adb --version && fastboot --version`.
   - New in-guest **`arix-adb` helper** (auto-installed to
     `/usr/local/bin/arix-adb` on every terminal launch, version-marked and
     idempotent): `arix-adb` connects to the phone and opens an Android shell,
     `arix-adb pair HOST:PORT CODE` pairs with Android 11+ Wireless debugging,
     `arix-adb connect [HOST:]PORT` saves the target for future shells,
     `arix-adb discover` lists mDNS ADB services, and any other arguments pass
     straight through to `adb`. First-time flow documented in the helper
     header (Developer options → Wireless debugging → pair → connect).
   - The phone's own LAN IP is exported as `ARIX_DEVICE_IP` so the helper can
     default to the right target host (loopback works for self-connections).
3. **Premium AMOLED home screen redesign** (`ui/ConversationUi.kt`,
   `shared/.../ui/theme/Color.kt`):
   - Dark palette deepened to a navy-black AMOLED base (`#0B0D17` background
     family, hue-shifted from charcoal while preserving the lightness ladder
     so contrast is unchanged) — the app-wide tokens all pick it up.
   - New empty-state composition: the Arix mark floating on a soft violet
     halo, the IST typewriter greeting (unchanged core behavior), hairline
     gradient divider, quiet subtitle — then four **glassmorphism quick-action
     cards** in a 2×2 grid: *Explain a concept*, *Help me write*, *Summarize
     a text*, *Give me ideas*. Tapping a card pre-fills the composer with a
     starter prompt through the normal `onInputChanged` pipeline (no new
     send path). Cards: 18 dp radius, translucent gradient surfaces,
     hairline white borders, very light shadows, ≥104 dp touch targets.
   - New compact **"Today's tip"** card below the shortcuts with a useful
     AI/productivity tip that rotates once per day (14 baked tips, keyed on
     day-of-year). Informational only — no interaction required.
4. **Tools screen UI upgrade** (`ui/ArixToolsUi.kt`):
   - Oversized bold headline replaced with a compact 20 sp / weight-600 title
     and smaller supporting subtitle.
   - New **circular glass back button** (38 dp, hairline border, soft shadow)
     across every tool screen, plus a back affordance on the Tools hub itself
     (returns to Home).
   - **Search field redesigned**: fully rounded 50 dp pill with animated
     violet focus ring, translucent glass gradient, leading search glyph,
     trailing clear button and a compact gradient action chip — replacing the
     boxed outline field.
   - Entry cards polished: glass gradient surfaces, hairline borders, soft
     shadows, consistent 20 dp radius.
5. **Startup robustness fix** (`data/ArixStorageAccess.kt`):
   `Environment.isExternalStorageManager()` is now probed defensively — on
   environments where the framework call throws (Robolectric sandboxes,
   certain OEM frameworks) the exception previously propagated out of
   `MainActivity.onCreate` and crashed the app on open. A failed probe now
   simply means "not granted" and the legacy grant is consulted.
6. **Size pass (no features removed)**: native libraries are compressed inside
   the APK (`useLegacyPackaging`) — the signed release APK drops from
   ~14.6 MB to **~13.8 MB** with identical functionality; the Alpine rootfs
   asset and minified Node bridge were verified already optimally packed.
7. Version 2.4.3 (versionCode 28), same signing key as every release since
   v2.2.1 (SHA-256 `b4a16e88…3166b` — in-place upgrade). 234 app unit tests +
   shared unit tests, 0 failures.

## v2.4.0 — Provider swaps, File Share tool, MovieBox poster fix, real model downloads

1. **Movies tool — provider 1 replaced** (`ui/ArixToolsUi.kt`, new
   `data/ArixCinemetaClient.kt`): the Watch-Movies web scraper chip is gone
   from the Tools screen (the scraper itself remains available to the in-chat
   agent tools). The new provider 1 "CineHub (Free)" is backed by the public
   Stremio **Cinemeta** catalog API — keyless, CDN-backed catalogs (`top` +
   newest `year` releases), genre chips (Action, Comedy, Horror, Sci-Fi,
   Thriller, Drama, Adventure, Animation), keyword search, and full detail
   metadata. Playback resolves three free embed-player servers per IMDb id
   (vidsrc.to / 2embed.cc / vidsrc.xyz) rendered in the existing hardened
   player WebView — the same architecture as the MovieBox "Web player"
   fallback. Search box placeholder reduced to exactly "search here".
2. **Anime tool — provider 1 replaced** (new `data/ArixAniListClient.kt`,
   `data/ArixAnimeSiteClient.kt`): AnimeLok is no longer provider 1. The new
   provider 1 uses the **AniList GraphQL API** (trending feed, search, episode
   counts, covers, descriptions — extremely stable, no key). Each episode
   resolves its servers by mapping the title to an IMDb id through the
   Cinemeta search catalog (cached per series) and building the same three
   free embed-player URLs; the player sends the embed host's own origin as
   Referer for that source. Anime search box placeholder is now "search here"
   as well.
3. **MovieBox poster bug fixed** (`data/ArixMovieBoxClient.kt`): every live
   WeFeed endpoint now returns `cover` as a JSON *object*
   (`{url, width, height, …}`) in camelCase payloads (`subjectList` /
   `items`). The old string-only read coerced the whole object into a garbage
   "URL" so **every MovieBox poster silently failed and the grid showed
   placeholders**. `parseSubject` now reads the object shape first (with
   string-key fallback), and `findSubjectArray` recognizes the
   `subjectList`/`items` keys explicitly.
4. **New File Share tool** (new `data/ArixFileShareClient.kt`, new
   `ArixFileShareToolScreen` in `ui/ArixToolsUi.kt`): pick any file, upload it
   to a free public host and get a **direct download URL** with Copy / Share
   buttons (tap the link box to copy too). Server chips at the top:
   **Server 1 — Pixeldrain** (anonymous multipart upload, direct
   `?download` link), **Server 2 — Filebin.net** (fresh random bin + PUT,
   6-day retention), **Server 3 — 0x0.st** (multipart, 512 MB cap) and
   **Server 4 — Litterbox** (72 h quick share). Uploads stream from the
   content resolver straight into OkHttp (no full in-memory copies), so large
   files work within ordinary heap limits; per-server failures return
   actionable messages pointing at the other servers.
5. **On-device AI model downloads fixed** (`data/ArixLocalModels.kt`): the
   old catalog shipped dead links — Gemma 3n E2B/E4B pointed at **gated**
   HuggingFace repos (HTTP 401) and the Qwen3 1.7B file name **did not
   exist** (HTTP 404), which is why every download looked broken. The catalog
   now lists verified, anonymously-downloadable LiteRT-LM files with real
   sizes: Gemma 4 E2B (2.5 GB), Gemma 4 E4B (3.5 GB), Qwen3 4B int4/int8,
   Qwen3 1.7B dynamic int4, Qwen3 0.6B — plus an updated download user agent.
6. **Stale test fixed**: `ArixToolExecutorTest` still referenced the removed
   `sanitizeToolOutputForConversation` / `agentModeEnabled` APIs (Agent Mode
   was deleted in v2.3.2), breaking `testReleaseUnitTest`. Rewritten against
   the current API surface. 234 unit tests, 0 failures.
7. Version 2.4.0 (versionCode 25), same signing key as every release since
   v2.2.1 (SHA-256 `b4a16e88…3166b` — in-place upgrade over v2.3.x installs).

## v2.2.9 — Premium bottom navigation + Tools hub, MovieBox API, built-in skills, MCP/subagent/accessibility fixes, Alpine ADB

1. **Premium bottom navigation + Tools hub** (`ui/ArixBottomNavBar.kt`, `ui/ArixToolsUi.kt`):
   - `AppScreen` gains `Tools`, `Terminal`, `Browser` tabs. A floating icon-only
     pill bar (Home / Tools / Terminal / Browser, no labels, violet active glow,
     hides while the IME is open) overlays the four main tab screens; the chat
     composer reserves bottom padding so it never slides under the bar.
   - Terminal opens the Alpine shell full-screen; Browser opens the agent-mode
     Chromium (noVNC) desktop — both one tap from anywhere in the app.
   - New Tools hub with premium dark cards (icon + title + description):
     **Watch Movies & Series**, **QR Code Generator**, **Watch Anime**.
2. **Movie Explorer + QR + Anime removed from `extensions/`**: the three bundled
   TypeScript extensions are gone (their powers now live in the native Tools
   screens and in-chat widgets). `PiExtensionState` prunes their stale entries
   via a versioned defaults migration (v2).
3. **Watch Movies & Series tool**: dual provider — (a) the watch-movies.com.pk
   scraper (direct-first fetch with the 15 public CORS proxies as validated
   fallback, multi-server player, download links) and (b) a native Kotlin port
   of the MovieBox / WeFeed H5 BFF client (`data/ArixMovieBoxClient.kt`):
   token bootstrap via `home` + `x-user` refresh, search, trending with
   pagination, details with seasons/episodes, recommendations, play streams,
   subtitle selection and download links — mapped onto the multi-server player.
4. **QR Code Generator tool**: on-device encoder with qrserver + quickchart
   free-API fallbacks, payload templates (Link / Wi-Fi / Email / Phone), and
   Download (MediaStore) + Share (FileProvider) actions.
5. **Watch Anime tool**: provider switcher with generic names (Provider 1 /
   Provider 2 — no site names in the UI), latest + search, episode strip and
   the multi-server player via per-provider scrapers
   (`ArixAnimeSiteClient.latestFrom/searchFrom`).
6. **Built-in agent skills** (`data/ArixBuiltInSkills.kt`): Email, Web
   Research, Code Review, Document Writer, Translator, Device Control install
   on first launch through the standard skill pipeline (`SkillInstallKind.Builtin`),
   with enable/disable toggles, Remove (stays removed — remembered in prefs),
   and one-tap re-add from Settings → Agent Skills → Built-in.
7. **MCP "extension not loaded yet" fixed (root cause)**: bundled extensions
   (web access / MCP / subagents) previously shipped DISABLED by default, so
   the Pi-side MCP extension never ran and every connect/reconnect died. They
   now ship enabled, stale v1 default snapshots migrate once, `withBridge`
   failures carry an actionable recovery hint, and failed extension actions
   surface as notifications instead of being silently dropped.
8. **Subagent "Create agent definition" fixed**: the action only needs host
   capabilities but was gated behind the Pi bridge guard; it now runs
   bridge-independent and opens chat with the definition prompt pre-filled.
9. **Accessibility status malfunction fixed**: status no longer equals "is a
   service object alive this instant". `ArixAccessibility.isServiceEnabled`
   reads `Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES` (+ manager fallback),
   `onUnbind` keeps the instance across OEM rebind cycles, a new
   `AccessibilityReconnecting` state renders as neutral instead of red, and a
   transient rebind window can no longer stop a running Agent Mode session.
10. **Alpine ADB tools**: new `adb` package profile (`android-tools` → adb +
    fastboot) in Settings → Alpine, plus an optional "Auto-allow debugging
    prompts" switch (auto-enabled on install). When on, the accessibility
    service detects the system "Allow USB debugging?" / wireless debugging
    dialogs and taps Allow automatically — pairing needs zero interaction.
11. **Always-show visual interactions**: new Agent Mode toggle (default on).
    The live visual panel now stays visible while browsing, web searching,
    running system control (opening apps, tapping, typing, swiping) and
    capturing screenshots — including tool rows that previously never surfaced
    the panel (`system_control`, `tavily_search`, `fetch_web_url`).
12. **Bug fixes found in audit**: `androidTestImplementation(libs.androidx.sqlite.bundled)`
    restored so `ChatRepositoryCheckpointInstrumentedTest` compiles again;
    JSONObject-vs-JSONArray mixup fixed in the MovieBox tab parser; APK size
    pass (extra META-INF/about excludes), versionCode 21 / versionName 2.2.9.
    Full build verified: 233 unit tests, 0 failures; androidTest compiles;
    release APK signed with the Arix keystore (~13.8 MB).

## v2.2.5 — Instant native tools (movies + QR), Data & storage settings, system_control tool, Alpine PATH fix

1. **Instant native Movie Explorer + QR Generator (client-side intent router)** —
   the root cause of "raw URLs first, widget minutes later" was the LLM
   round-trip: the model streamed a text answer with URLs, the extension tool
   ran afterwards, and only then did the widget card appear.
   - New `ArixNativeIntent` router matches clear movie/QR commands in
     `ArixViewModel.submitCurrentMessageNow` BEFORE any LLM call ("show latest
     movies", "search movie X", "play movie X", "more movies", "movies page 2",
     "create a qr code for …", "QR code: …").
   - `runNativeToolTurn` appends the user message plus an assistant message
     carrying a running `movie_explorer` / `qr_code` tool invocation, then
     completes it with the same `output_json` widget payload the extension
     emits — so the native widgets render IMMEDIATELY in chat, with zero raw
     URLs, zero LLM latency, and a friendly error message on failure.
   - Conversation-style questions ("what is your favorite movie?") still go to
     the model; the router only fires on imperative commands, and never while
     a turn is running, while editing, or with attachments/skills.
2. **QR codes are now generated 100% on-device** — new pure-Kotlin
   `ArixQrEncoder` (byte mode, ECC M, versions 1–40, penalty-optimal mask)
   plus `ArixQrPng` renderer (Bitmap → PNG, quiet zone). No network, no qr
   APIs, no retries: a code appears in well under a second even offline.
   The encoder was ported from a Python prototype that was verified
   matrix-identical to the reference `qrcode` library across v1–v32 with
   random payloads incl. UTF-8; `ArixQrEncoderTest` bakes four of those
   vectors into the JVM suite (4/4 green).
3. **Movie fetching is now parallel and much faster** — `MovieSiteClient`
   races 5 proxies at a time (3 waves over the shuffled 15) instead of
   sequential 12-second attempts, then falls back to both mirror domains
   direct. Live checks during this build: list + detail pages return 200 with
   the expected postbox / iframe / quality-h2 structure.
4. **Scroll conflict fixed** — the poster grid was a tall static 2-column
   block inside the chat list, so vertical drags scrolled the chat. It is now
   a horizontal `LazyRow` rail (122dp cards) that scrolls sideways
   independently; tap Play resolves servers natively and swaps the rail for
   the multi-server player in place.
5. **QR widget Share button** — `ArixQrShare` shares the PNG through the
   system sheet via FileProvider (`qr-share/` cache path added to
   `file_paths.xml`). Download (MediaStore) and Share both act instantly on
   the locally-generated image.
6. **New `system_control` host tool (always available, no Agent Mode)** —
   native no-root actions for the requests that previously answered "I'm
   unable": `open_settings` (28 named pages), `open_app` (fuzzy label/package
   launch), `list_apps`, `what_on_screen` (accessibility tree read with
   bounds), `global_action` (back/home/recents/notifications/quick settings/
   lock/screenshot), `open_url`, `volume`, `device_info`, `status`. When the
   accessibility service is off the tool returns actionable instructions
   instead of failing. The agent system prompt now tells the model to use
   `system_control` FIRST and never claim it is unable to open apps/settings.
7. **`sh: am: not found` fixed at the root** — Alpine executed commands with
   `/bin/sh -lc` (login shell), and Alpine's `/etc/profile` RESETS PATH,
   dropping `/system/bin`. Every executed command is now prefixed with an
   explicit `export PATH="/system/bin:/system/xbin:…:$PATH"` guard that runs
   after profile sourcing, and the prompt documents absolute paths
   (`/system/bin/am start …`) as a belt-and-braces fallback.
8. **Settings → Data & storage** — new page (hub row under Statistics) that
   counts and deletes QR images the app saved to the system Downloads store
   (MediaStore `qr-code-%` on Android 10+, public Downloads pre-10) and shows
   plus clears the app cache (posters, previews, temp files).
9. Version 2.2.5 (versionCode 17), same signing key as every release since
   v2.2.1 (SHA-256 `b4a16e88…3166b` — in-place upgrade). Tests: ArixQrEncoderTest,
   ArixNativeIntentTest, ArixToolExecutorTest, ConversationUiTest (19),
   ConversationMessagesTest, StartupSmokeTest (6), PiAgentPromptTest,
   RuntimeRouterTest — all green.

## v2.2.4 — Movie fetch rebuilt (proxy-first), native chat widgets, accessibility fix, Alpine system control, new home screen

1. **Movie Explorer network layer rebuilt** — the v2.2.3 chain still led with
   direct requests and URL-ENCODED proxy targets. Live testing proved the
   workers.dev CORS proxies **reject encoded targets (500/502)** and only
   return the movie HTML when the **raw URL** is appended — exactly what the
   reference implementation does. The fetch order is now: shuffled proxies
   (raw URL, 15 mirrors, 6 tried per request) → direct on both mirror
   domains → in-app WebView fallback. Verified live: latest list (24 movies,
   558 ms), `?s=` HTML search ("dunki" → 4 results), and detail pages
   (4 servers + 8 download links). The WP REST API remains a fallback with
   the same proxy-first order. Error messages now enumerate every attempted
   method so failures are diagnosable.
2. **Native in-chat widgets** (the rendering path that cannot break): the
   `qr_code` and `movie_explorer` tools now return a structured
   `output_json` payload with every result, and the conversation renders it
   directly — no extension-runtime round-trip involved:
   - **QR Code card**: the scannable image, payload, kind, provider and size
     with a **Download PNG** button that saves into the system Downloads
     collection (MediaStore on Android 10+).
   - **Movie poster grid**: two-column poster grid with a Play button on
     every poster; tapping Play resolves the movie's servers **natively**
     (`MovieSiteClient`, same proxy strategy in Kotlin) and swaps the grid
     for the multi-server player — instant playback with no agent
     round-trip — with a back button to return to the grid.
   - **Movie player**: title, description, server chips, a 16:9 embedded
     WebView stage with autoplay enabled, and the download links (opened
     externally).
   - The tools no longer mirror results through `app.appendCustomMessage`
     (removed to avoid double cards); the custom-message path remains
     available for the QR composer item and quick-generate settings page.
3. **Accessibility service fixed** — the real reason Agent Mode "didn't
   work after enabling": the service was declared `android:exported="false"`,
   which prevents the OS from ever binding it, so the toggle appeared on
   but the service never connected. Now `exported="true"` (still safe: only
   the OS can bind via the signature-level BIND_ACCESSIBILITY_SERVICE
   permission).
4. **Alpine system control (no root)**: the Alpine runtime now bind-mounts
   `/system` into the proot namespace and exports the Android runtime env
   (`ANDROID_ROOT`, `/system/bin` on PATH), so the agent's shell can run
   `am start` (launch apps / open links), `pm list packages`, `settings
   get/put` (respecting the WRITE_SETTINGS grant) and read `dumpsys`
   reports directly. The agent system prompt documents this split: shell
   for launching/settings/inspection, `agent_mode` for screen interaction.
5. **Home screen refresh** (per the reference mock): a violet-glow avatar
   with the sparkle mark above the greeting, quick-start chips (Ask
   anything / Summarize / Analyze / Create) that submit their starter
   prompts, and a rotating "TRY SOMETHING NEW" suggestion card that sends
   the shown prompt on tap. The IST typewriter greeting and the existing
   composer are unchanged.
6. Version bumped to 2.2.4 (versionCode 16).

## v2.2.3 — Termux removed, no-root Agent Mode, chat widgets & extension fixes

1. **Termux fully removed** (setup, options, runtime):
   - Settings pages for Termux setup and Root setup progress are gone; the
     runtime is the built-in Alpine VM only. `RuntimeRouter` maps the legacy
     Termux runtime id to Alpine for stored-settings compatibility.
   - `arix_termux_manage` self-management tool, the Termux runtime module,
     Shizuku/root bridge services, and the root setup controller were deleted;
     stale Termux strings were removed or reworded; obsolete tests retired.
   - The bundled `third_party/termux` terminal libraries remain — they render
     the **Alpine** terminal UI and have nothing to do with the removed
     Termux app integration.
2. **No-root Agent Mode (accessibility-based)** — replaces the old
   Termux/Shizuku/virtual-display pipeline with public, user-authorized APIs:
   - `ArixAccessibilityService`: gesture dispatch (tap / long-press / swipe),
     global key actions (back / home / recents / notifications / quick
     settings / lock screen), text entry into the focused field, structured
     screen reading (node tree with bounds / ids / text), element lookup and
     click by text or view id, and full-screen capture on Android 11+ via
     `takeScreenshot` (API-34 three-argument overload, hardware buffer copied
     to a software bitmap).
   - `ArixNotificationListenerService`: read / filter / dismiss notifications
     through the `notifications` action.
   - Direct framework APIs: `AudioManager` volume control, battery / power /
     device info, app listing and launching through Intents, URI opening.
   - `WRITE_SETTINGS` system settings modification (brightness, screen
     timeout, etc. after user grant) and `TelecomManager` call handling
     (place / answer with `ANSWER_PHONE_CALLS`).
   - `AgentModeHudService` (`SYSTEM_ALERT_WINDOW`): floating stop/status HUD
     shown while a session is active.
   - `agent_mode` tool action set: start, stop, status, list_apps, launch,
     open, tap, swipe, key, text, screenshot, read_screen, find_element,
     click_element, notifications, device_info, volume, settings, call, hud.
   - The live virtual-display preview surface was removed; the preview panel
     now shows the latest accessibility screenshot with the animated cursor.
3. **Extension chat widgets** (the missing rendering path — custom messages
   were stored but never displayed):
   - `app.appendCustomMessage` results now flow into the extension runtime
     host context (`custom_messages`), which renders each registered message
     type into a widget tree; the chat renders those trees inline (QR cards,
     movie poster grids, movie players) via the existing extension view
     renderer. Plain text remains as fallback while a tree loads.
   - `ArixAppExtensionSnapshot` parses `custom_messages`; new public
     composables `arixExtensionCustomMessageAvailable` /
     `ArixExtensionCustomMessageView` render them in the message list.
4. **QR Code Generator fixed**: the QR image now really appears in chat as a
   card. New **Download PNG** button saves the image into the system
   Downloads store via the new `app.saveMediaToDownloads` host method
   (MediaStore on Android 10+, legacy Downloads dir below). Generated PNGs
   are stored in the private `~/.arix/qr-codes` folder and the settings page
   gained a **Clean saved QR codes** action (plus a count refresh) so stored
   generated images can be wiped in one tap. The tool no longer claims a
   workspace path it cannot show.
5. **Movie Explorer fixed**: the source site now serves Cloudflare bot
   challenges to every non-browser TLS client (plain `fetch` receives 403
   regardless of headers — verified live). The fetch chain was rebuilt:
   - Direct requests try **both** domains (`watchonlinemovies` first, then
     `watch-movies`) with full browser request headers.
   - New **WebView fetch fallback**: a real in-app Chromium WebView
     (`WebViewFetcher`) loads the site origin, clears any challenge, and runs
     a same-origin `fetch()` inside the page — the exact engine that already
     plays the movie embeds. Exposed to extensions as `app.webFetch`; the
     movie extension installs it automatically.
   - Public CORS proxies remain the last resort; failures now report every
     attempted method instead of a bare "WP API failed".
6. **Home screen polish**: the composer input field gained a 1dp
   `ArixOutlineSoft` border (plus focus-state emphasis) and the IST greeting
   no longer shows the time/date clock line — just the greeting, the
   typewriter reveal, and "What can I help with?".
7. **Housekeeping**: unnecessary README files removed (examples, packages,
   bundled extensions — only the root README and build notes remain); unused
   root/Termux onboarding strings deleted; `Schedule` icon import cleaned up.
8. Version bumped to 2.2.3 (versionCode 15).

## v2.2.2 — Premium dark theme refresh + new logo

1. **Provider subscription authorization (investigated, left unchanged)**:
   Google Gemini was evaluated for the "Use a subscription" (OAuth sign-in)
   list in provider settings. The runtime provider catalog
   (`@earendil-works/pi-ai` 0.84.1, verified from the published package)
   implements Google **API-key auth only** — no OAuth flow exists for the
   `google` provider (only Anthropic, GitHub Copilot, OpenAI Codex, Kimi
   Coding, OpenRouter, xAI and Radius have OAuth). Enabling OAuth for Gemini
   would fail at runtime ("Pi provider google does not support OAuth"), so
   Gemini remains in the Recommended list with its supported API-key flow
   and was **not** added to subscription authorization.
2. **Premium dark palette refresh** (`shared/.../ui/theme/Color.kt`, dark
   palette only — the app is permanently dark):
   - Background deepened from `#151619` to a rich OLED-friendly charcoal
     `#0E0F13` with a subtle blue-violet undertone; the home gradient top is
     `#15171D`.
   - Surface elevation ladder retuned (`#171A1F` / `#1F2228` / `#272B32` /
     `#2F343C`) so cards, sheets and chips read as gentle lifts off the base.
   - Sidebar, settings background, outlines and dividers re-tuned to match;
     message bubble deepened to a richer violet `#2F2455`.
   - All UI reads these tokens, so the refresh applies app-wide without
     touching screens individually.
3. **Premium accents**: the home greeting headline now renders with a soft
   violet-to-white vertical gradient brush (readable on the deep background);
   the composer send/pause buttons use a refined violet gradient
   (`#9D6BFF → #6E3FE8`) instead of the flat purple.
4. **New logo (same design language, new colors)**: the Arix mark keeps the
   exact original geometry (verified: alpha channel bit-identical) while the
   colors change from *white circle + pink gradient* to *dark premium tile +
   violet gradient*:
   - Circle background: subtle dark tile gradient `#262733 → #121319`.
   - Blob: hue-shifted −60° (pink → violet) preserving the original
     lightness curve — `#D3B0FF` at the top to `#A341FF` at the bottom — now
     matching the app's violet accent family.
   - Glyph: warm white `#F5F4F0`. Blend pixels were alpha-unmixed so no
     halo artifacts remain (verified programmatically).
   - Replaced in all three locations: `app/src/main/res/drawable-nodpi/`,
     `shared/.../composeResources/drawable/`, `public/`.
   - Adaptive-icon background updated `#FFFFFF → #121319` so the launcher
     icon is a seamless dark tile with the floating violet mark.
5. Version bumped to 2.2.2 (versionCode 14).

## v2.2.1 — IST time-based home greeting

1. **New greeting header on the home (new-chat) screen**, computed from Indian
   Standard Time (`Asia/Kolkata`) regardless of device timezone:
   - `4:00–5:59` → "Good early morning, Sir"; `6:00–11:59` → "Good morning,
     Sir"; `12:00–16:59` → "Good afternoon, Sir"; `17:00–19:59` → "Good
     evening, Sir"; `20:00–23:59` and `0:00–3:59` → "Good night, Sir".
   - Below the greeting a live clock line shows the current IST date/time
     ("Mon, 29 Aug · 9:41 AM IST") with a schedule icon, refreshed every
     20 seconds.
2. **Onboarding-style typewriter animation**: the greeting reveals word by
   word using the same reveal-unit engine as the onboarding
   `StreamingStepMessage` (word/word+space units, 96–240 ms per unit, 180 ms
   on punctuation, instant when Reduce Motion is on). The animation keys on
   the greeting phrase only, so the ticking clock never restarts it.
3. **Hides when chatting starts**: the greeting block fades out when the
   composer is focused, and the whole empty state (greeting + clock + welcome
   line) disappears as soon as the conversation has messages — the message
   list replaces it.
4. Implementation: `IstGreetingHeader` / `GreetingRevealText` /
   `rememberIstNow` in app `ConversationUi.kt`, rendered from the live
   `ConversationScreen` empty branch (below the chat-empty extension slot);
   five new `greeting_*` strings in shared resources. Note: the upstream
   `ConversationEmptyState` (ConversationUi.kt) and `EmptyChatState`
   (ArixApp.kt, preview-only) composables are unreachable dead code that R8
   strips — the greeting intentionally attaches to the code path that
   actually renders.

## v2.2.0 — Dark-only theme + Movie Explorer & QR Code Generator

1. **Theme picker removed; the app is permanently dark themed**:
   - The Settings → General page (which contained only the theme selector)
     was removed from the settings hub, along with `GeneralSettingsPageV2`,
     the `SettingsPage.General` route, and the `onUpdateThemeMode` /
     `updateAppThemeMode` / `updateThemeMode` plumbing.
   - `AppThemeMode.fromStorage()` now always resolves to `Dark` (existing
     installs that stored `system`/`light` switch over automatically), the
     `AppSettings` default is `Dark`, and `ArixTheme` forces the dark
     palette regardless of the passed mode.
2. **New bundled extension: Movie Explorer** (`extensions/pi-movie-explorer`):
   - Agent tool `movie_explorer` with modes `latest` / `search` / `play`.
   - Latest movies and search via the source site homepage HTML and the
     WordPress JSON search API; playback resolves every embed server
     (Player 1..N) plus download links from the movie page, with the
     WordPress REST API (`/wp-json/wp/v2/posts?slug=…`) and public CORS
     proxies as automatic fallbacks. Note: the `_fields` query parameter
     triggers the site's Cloudflare — the extension never uses it.
   - Rich Arix cards: a poster grid (`movie-list`) where tapping Play opens
     the multi-server player instantly (no agent round-trip), and a
     `movie-player` card with server tabs, a fullscreen embed stage, and a
     download list.
3. **New bundled extension: QR Code Generator** (`extensions/pi-qr-generator`):
   - Agent tool `qr_code` (text/link/Wi-Fi/email payloads) rendered as an
     in-chat QR card and saved into the workspace `qr-codes/` directory.
   - Composer menu item "QR Code" encodes the current draft instantly, and
     Settings → QR Code Generator offers a quick-generate box.
   - Free keyless QR APIs with automatic fallback chain:
     api.qrserver.com (goqr.me) → quickchart.io → qrtag.net.
4. **New `qr` extension icon** mapped to `Icons.Rounded.QrCode2` in both the
   app and shared icon registries.
5. Both new extensions follow the existing preinstalled-extension pattern:
   they ship in the APK under `assets/extensions/` and appear in
   Settings → Extensions, disabled by default until the user enables them
   (existing installs that already have extension state stored will see them
   enabled).

## Using the assistant on MIUI (Android 11)

On MIUI 12.5 (e.g. Poco X2), for the most reliable summoning from anywhere:

1. Settings → Apps → Manage apps → Arix → Autostart: **on** (so the floating
   pill survives).
2. Arix → Other permissions: enable **Display pop-up windows while running in
   the background** (needed by the tile / floating pill to open the panel when
   Arix is in the background).
3. Settings → Assistant → Display over other apps → **Allow**.
4. Settings → Assistant → Set as default assistant → choose **Arix**.
   The bottom-corner assistant gesture now summons Arix.
5. Optionally enable the **Floating pill** toggle and add the **Arix Assistant**
   quick settings tile.

## Signing the release build

The release signing key is included so you can publish follow-up updates of this
same app identity:

- Keystore: `keystore/arix-release.jks`
- Config: `keystore.properties` (loaded by `app/build.gradle.kts`)
- Keystore password: `ArixRelease2026`
- Key alias: `arix`
- Key password: `ArixRelease2026`

> Keep these files private if you plan to distribute the app. Anyone holding the
> keystore can sign updates that install over your users' copies.

## Building the APK

Requirements: JDK 17+, Android SDK (platform 36, build-tools 36), Node.js 22+.

```bash
./gradlew :app:assembleRelease
# → app/build/outputs/apk/release/app-release.apk
```

The build automatically runs `npm install` + `npm run build` inside `pi-bridge/`
and bundles `bridge.mjs`, the preinstalled extensions, and the Alpine runtime
assets into the APK.
