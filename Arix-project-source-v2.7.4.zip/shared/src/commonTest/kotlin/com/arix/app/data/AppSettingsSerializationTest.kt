package com.arix.app.data

import kotlin.test.Test
import kotlin.test.assertEquals

class AppSettingsSerializationTest {
    @Test
    fun completeSettingsRoundTrip() {
        val settings = AppSettings(
            piProviderId = "anthropic",
            providerAuthMethod = ProviderAuthMethod.OAuth,
            oauthCredentialJson = "{\"access\":\"token\"}",
            providerEnvironmentVariables = listOf(PiProviderEnvironmentVariable("REGION", "test")),
            customHeaders = listOf(LlmCustomHeader("X-Test", "value")),
            reasoningEffort = "high",
            systemPrompt = "shared prompt",
            tavilyApiKey = "tavily-secret",
            tavilyBaseUrl = "https://search.example/",
            keepTasksRunningInBackground = false,
            notifyOnTaskCompletion = false,
            agentWorkspaceMode = AgentWorkspaceMode.PerSession,
            enabledRuntimeIds = setOf(LocalRuntimeId.Alpine),
            defaultRuntimeId = LocalRuntimeId.Alpine,
            alpinePackageProfiles = mapOf("chrome" to PackageProfileState("chrome", installed = true)),
            alpineEnvironmentVariables = listOf(AlpineEnvironmentVariable("A", "B")),
            language = AppLanguage.English,
            themeMode = AppThemeMode.Dark,
            defaultChatModelKey = "provider/chat-model",
            defaultTitleModelKey = "provider/title-model",
            defaultNamingModelKey = "provider/naming-model",
            defaultCompactingModelKey = "provider/compacting-model",
            defaultSelectedSkillIds = listOf("review", "research"),
            onboardingSeenVersion = CurrentOnboardingVersion,
            onboardingCompletedVersion = CurrentOnboardingVersion,
            compatibilityMode = true,
            privacyPolicyAccepted = true,
            lastUpdateCheckAtMillis = 1234L,
        )

        assertEquals(settings, parseAppSettings(serializeAppSettings(settings)))
    }

    @Test
    fun unknownFieldsRemainForwardCompatible() {
        val parsed = parseAppSettings("""{"themeMode":"Dark","futureValue":42}""")

        assertEquals(AppThemeMode.Dark, parsed.themeMode)
        assertEquals(DefaultReasoningEffort, parsed.reasoningEffort)
    }
}
