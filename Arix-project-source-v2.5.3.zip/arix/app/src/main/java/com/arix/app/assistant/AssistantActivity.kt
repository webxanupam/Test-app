package com.arix.app.assistant

import android.content.Intent
import android.os.Bundle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.Send
import androidx.compose.material.icons.rounded.AttachFile
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.KeyboardArrowUp
import androidx.compose.material.icons.rounded.Mic
import androidx.compose.material.icons.rounded.OpenInFull
import androidx.compose.material.icons.rounded.Stop
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.arix.app.MainActivity
import com.arix.app.R
import com.arix.app.ui.ArixViewModel
import com.arix.app.ui.theme.ArixTheme
import com.arix.app.ui.ArixUiState
import com.arix.app.ui.MessageAuthor

/**
 * Translucent overlay activity that hosts the quick assistant panel.
 *
 * It can be summoned by:
 *  - the system assistant gesture / long-press home (when Arix is the default assistant),
 *  - the quick settings tile,
 *  - the floating overlay pill,
 *  - the "Hey Arix" wake word (v2.4.9),
 *  - the Android text-selection menu (ACTION_PROCESS_TEXT),
 *  - share sheet (ACTION_SEND plain text).
 *
 * v2.4.9: pro UI pass — pill and panel restyled, and the composer gains an
 * attach button plus an offline voice-input (Vosk) mic button alongside send.
 *
 * It hosts its own [ArixViewModel] instance, which shares the application-wide
 * runtime, session execution engine and persisted chat state with the main app,
 * so conversations started here continue seamlessly inside Arix.
 */
class AssistantActivity : AppCompatActivity() {

    // Activity-scoped ViewModel (shares the app-wide runtime & chat state).
    // Uses the framework factory directly — works for AndroidViewModel without
    // any ktx dependency quirks.
    private val viewModel: ArixViewModel by androidx.lifecycle.ViewModelLazy(
        viewModelClass = ArixViewModel::class,
        storeProducer = { viewModelStore },
        factoryProducer = { defaultViewModelProviderFactory },
    )

    private val filePicker = registerForActivityResult(
        ActivityResultContracts.GetContent(),
    ) { uri ->
        uri?.let { picked ->
            // v2.4.9: attach button — routes the picked file into the shared
            // Arix conversation draft (same pipeline as the main composer).
            viewModel.appendDraftAttachments(listOf(picked))
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val prefillText = resolvePrefillText(intent)
        setContent {
            val uiState by viewModel.uiState.collectAsStateWithLifecycle()
            ArixTheme(themeMode = uiState.settings.themeMode) {
                AssistantOverlayScreen(
                    uiState = uiState,
                    prefillText = prefillText,
                    onInputChange = viewModel::updateDraftInput,
                    onSend = viewModel::sendCurrentMessage,
                    onAttach = { filePicker.launch("*/*") },
                    onRemoveAttachment = viewModel::removeDraftAttachment,
                    onStartVoiceInput = viewModel::startAssistantVoiceInput,
                    onStartManualVoiceInput = viewModel::startVoiceInput,
                    onStopVoiceInput = viewModel::stopVoiceInput,
                    onDismiss = ::finish,
                    onOpenApp = {
                        startActivity(
                            Intent(this, MainActivity::class.java).apply {
                                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            },
                        )
                        finish()
                    },
                )
            }
        }
    }

    private fun resolvePrefillText(intent: Intent?): String? = when (intent?.action) {
        Intent.ACTION_PROCESS_TEXT ->
            intent.getCharSequenceExtra(Intent.EXTRA_PROCESS_TEXT)?.toString()
        Intent.ACTION_SEND -> {
            val text = intent.getStringExtra(Intent.EXTRA_TEXT)
            if (Intent.ACTION_SEND == intent.type || "text/plain" == intent.type) text else null
        }
        else -> null
    }?.takeIf { it.isNotBlank() }
}

@Composable
private fun AssistantOverlayScreen(
    uiState: ArixUiState,
    prefillText: String?,
    onInputChange: (String) -> Unit,
    onSend: () -> Unit,
    onAttach: () -> Unit,
    onRemoveAttachment: (String) -> Unit,
    onStartVoiceInput: () -> Unit,
    onStartManualVoiceInput: () -> Unit,
    onStopVoiceInput: () -> Unit,
    onDismiss: () -> Unit,
    onOpenApp: () -> Unit,
) {
    // v2.5.2 fix: the panel opens DIRECTLY into the expanded input state when
    // summoned — no intermediate collapsed pill that needs a second tap. The
    // entrance animation is a single smooth slide-up.
    var expanded by rememberSaveable { mutableStateOf(true) }
    var input by rememberSaveable { mutableStateOf("") }
    val keyboard = LocalSoftwareKeyboardController.current
    val context = androidx.compose.ui.platform.LocalContext.current

    // v2.5.2: mic permission handling for the voice-first summon flow.
    val micPermissionLauncher = androidx.activity.compose.rememberLauncherForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.RequestPermission(),
    ) { granted ->
        if (granted) onStartVoiceInput()
    }
    val hasMicPermission = androidx.compose.runtime.remember(context) {
        androidx.core.content.ContextCompat.checkSelfPermission(
            context,
            android.Manifest.permission.RECORD_AUDIO,
        ) == android.content.pm.PackageManager.PERMISSION_GRANTED
    }

    // A one-shot prefill (from PROCESS_TEXT / SEND) opens the panel expanded.
    LaunchedEffect(prefillText) {
        if (!prefillText.isNullOrBlank() && input.isBlank()) {
            input = prefillText
            expanded = true
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0x59000000))
            .clickable(
                interactionSource = remember { androidx.compose.foundation.interaction.MutableInteractionSource() },
                indication = null,
            ) { onDismiss() },
    ) {
        Column(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .imePadding()
                .navigationBarsPadding()
                .padding(horizontal = 12.dp, vertical = 12.dp)
                .statusBarsPadding(),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            AnimatedVisibility(
                visible = !expanded,
                enter = fadeIn(tween(180)) + scaleIn(initialScale = 0.96f, animationSpec = tween(220)),
                exit = fadeOut(tween(120)) + scaleOut(targetScale = 0.96f, animationSpec = tween(160)),
            ) {
                AssistantPill(
                    onClick = {
                        expanded = true
                        keyboard?.show()
                    },
                )
            }
            AnimatedVisibility(
                visible = expanded,
                enter = slideInVertically(tween(240)) { it } + fadeIn(tween(180)),
                exit = slideOutVertically(tween(180)) { it } + fadeOut(tween(140)),
            ) {
                AssistantPanel(
                    uiState = uiState,
                    input = input,
                    onInputChange = { input = it },
                    onSend = {
                        val text = input.trim()
                        if (text.isNotEmpty() || uiState.draftAttachments.isNotEmpty()) {
                            onInputChange(text)
                            onSend()
                            input = ""
                        }
                    },
                    onAttach = onAttach,
                    onRemoveAttachment = onRemoveAttachment,
                    onStartVoiceInput = onStartVoiceInput,
                    onStartManualVoiceInput = onStartManualVoiceInput,
                    onStopVoiceInput = onStopVoiceInput,
                    hasMicPermission = hasMicPermission,
                    onMicPermissionNeeded = {
                        micPermissionLauncher.launch(android.Manifest.permission.RECORD_AUDIO)
                    },
                    onOpenApp = onOpenApp,
                    onDismiss = onDismiss,
                )
            }
        }
    }
}

@Composable
private fun AssistantPill(onClick: () -> Unit) {
    // v2.4.9 pro styling: soft glow ring, elevated capsule, subtle border.
    val glow by rememberInfiniteTransition(label = "pill_glow").animateFloat(
        initialValue = 0.85f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(1400), RepeatMode.Reverse),
        label = "pill_glow_alpha",
    )
    Surface(
        shape = RoundedCornerShape(percent = 50),
        color = MaterialTheme.colorScheme.surface.copy(alpha = 0.97f),
        tonalElevation = 4.dp,
        shadowElevation = 16.dp,
        border = androidx.compose.foundation.BorderStroke(
            width = 1.dp,
            color = MaterialTheme.colorScheme.primary.copy(alpha = 0.35f * glow),
        ),
        modifier = Modifier
            .fillMaxWidth()
            .height(60.dp)
            .clickable(onClick = onClick),
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(CircleShape)
                    .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.12f)),
                contentAlignment = Alignment.Center,
            ) {
                androidx.compose.foundation.Image(
                    painter = painterResource(R.drawable.arix_mark),
                    contentDescription = null,
                    modifier = Modifier
                        .size(32.dp)
                        .graphicsLayer {
                            alpha = glow
                        }
                        .clip(CircleShape),
                )
            }
            Spacer(Modifier.width(12.dp))
            Text(
                text = stringResource(R.string.assistant_pill_hint),
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.onSurface,
                modifier = Modifier.weight(1f),
            )
            Icon(
                imageVector = Icons.Rounded.KeyboardArrowUp,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.size(26.dp),
            )
        }
    }
}

@Composable
private fun AssistantPanel(
    uiState: ArixUiState,
    input: String,
    onInputChange: (String) -> Unit,
    onSend: () -> Unit,
    onAttach: () -> Unit,
    onRemoveAttachment: (String) -> Unit,
    onStartVoiceInput: () -> Unit,
    onStartManualVoiceInput: () -> Unit,
    onStopVoiceInput: () -> Unit,
    hasMicPermission: Boolean,
    onMicPermissionNeeded: () -> Unit,
    onOpenApp: () -> Unit,
    onDismiss: () -> Unit,
) {
    val focusRequester = remember { FocusRequester() }
    val keyboard = LocalSoftwareKeyboardController.current
    val listState = rememberLazyListState()
    val sessionTitle = uiState.sessions
        .firstOrNull { it.id == uiState.currentSessionId }
        ?.title
        .orEmpty()
    val visibleMessages = remember(uiState.sessions, uiState.currentSessionId) {
        uiState.sessions
            .firstOrNull { it.id == uiState.currentSessionId }
            ?.messages
            .orEmpty()
            .takeLast(40)
    }
    val providerReady = uiState.providerConfigs.any { it.isEnabled }
    val voiceInputState = uiState.voiceInputState
    val isListening = voiceInputState is com.arix.app.voice.ArixSttEngine.State.Listening ||
        voiceInputState is com.arix.app.voice.ArixSttEngine.State.Partial ||
        voiceInputState is com.arix.app.voice.ArixSttEngine.State.Initializing
    val attachments = uiState.draftAttachments
    val hasAttachment = attachments.isNotEmpty()
    val voiceInputEnabled = uiState.voiceSettings.voiceInputEnabled

    // Final transcripts land in the panel's input field (mirrors the main
    // composer's live dictation behavior).
    LaunchedEffect(voiceInputState) {
        val finalText = (voiceInputState as? com.arix.app.voice.ArixSttEngine.State.Final)?.text
        if (!finalText.isNullOrBlank()) {
            val current = input
            onInputChange(
                if (current.isBlank()) finalText
                else if (current.endsWith(" ")) current + finalText
                else "$current $finalText"
            )
        }
    }

    // v2.5.2 voice-first summon: the panel opens straight into listening (no
    // keyboard popping over the mic). The mic auto-stops on silence (watchdog
    // in the STT engine), and tapping the input box stops it for typing.
    LaunchedEffect(Unit) {
        if (!providerReady) return@LaunchedEffect
        if (voiceInputEnabled) {
            if (hasMicPermission) {
                onStartVoiceInput()
            } else {
                onMicPermissionNeeded()
            }
        } else {
            focusRequester.requestFocus()
            keyboard?.show()
        }
    }
    LaunchedEffect(visibleMessages.size, uiState.pendingAssistantText) {
        if (visibleMessages.isNotEmpty()) {
            listState.animateScrollToItem(visibleMessages.lastIndex)
        }
    }

    Surface(
        shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp),
        color = MaterialTheme.colorScheme.surface,
        tonalElevation = 4.dp,
        shadowElevation = 18.dp,
        modifier = Modifier
            .fillMaxWidth()
            .heightIn(max = 580.dp),
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {
            // Header
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(start = 16.dp, end = 6.dp, top = 10.dp, bottom = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                androidx.compose.foundation.Image(
                    painter = painterResource(R.drawable.arix_mark),
                    contentDescription = null,
                    modifier = Modifier
                        .size(30.dp)
                        .clip(CircleShape),
                )
                Spacer(Modifier.width(10.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = stringResource(R.string.app_name),
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onSurface,
                    )
                    if (sessionTitle.isNotBlank()) {
                        Text(
                            text = sessionTitle,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 1,
                        )
                    }
                }
                IconButton(onClick = onOpenApp) {
                    Icon(
                        imageVector = Icons.Rounded.OpenInFull,
                        contentDescription = stringResource(R.string.assistant_panel_open_app),
                        tint = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                IconButton(onClick = onDismiss) {
                    Icon(
                        imageVector = Icons.Rounded.Close,
                        contentDescription = stringResource(R.string.assistant_panel_close),
                        tint = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }

            // Conversation
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f, fill = false),
            ) {
                if (!providerReady) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 24.dp, vertical = 28.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                    ) {
                        Text(
                            text = stringResource(R.string.assistant_setup_prompt),
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            textAlign = TextAlign.Center,
                        )
                        Spacer(Modifier.height(16.dp))
                        androidx.compose.material3.Button(onClick = onOpenApp) {
                            Text(stringResource(R.string.assistant_setup_open_app))
                        }
                    }
                } else if (visibleMessages.isEmpty() && !uiState.isSending) {
                    Text(
                        text = stringResource(R.string.assistant_empty_state),
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        textAlign = TextAlign.Center,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 24.dp, vertical = 28.dp),
                    )
                } else {
                    LazyColumn(
                        state = listState,
                        modifier = Modifier.fillMaxWidth(),
                        contentPadding = androidx.compose.foundation.layout.PaddingValues(
                            horizontal = 16.dp,
                            vertical = 8.dp,
                        ),
                        verticalArrangement = Arrangement.spacedBy(10.dp),
                    ) {
                        items(visibleMessages, key = { it.id }) { message ->
                            AssistantMessageBubble(
                                text = message.text,
                                isUser = message.author == MessageAuthor.User,
                            )
                        }
                        if (uiState.isSending) {
                            item(key = "pending-response") {
                                AssistantPendingBubble(
                                    text = uiState.pendingAssistantText,
                                    status = uiState.pendingStatusText,
                                )
                            }
                        }
                    }
                }
            }

            // v2.4.9 pro composer: attach + input + voice + send.
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 10.dp),
            ) {
                attachments.forEach { attachment ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 6.dp)
                            .clip(RoundedCornerShape(14.dp))
                            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                            .padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.AttachFile,
                            contentDescription = stringResource(R.string.assistant_attach),
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(16.dp),
                        )
                        Spacer(Modifier.width(8.dp))
                        Text(
                            text = attachment.name.ifBlank { "Attachment" },
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurface,
                            maxLines = 1,
                            modifier = Modifier.weight(1f),
                        )
                        Icon(
                            imageVector = Icons.Rounded.Close,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier
                                .size(18.dp)
                                .clickable(onClick = { onRemoveAttachment(attachment.id) }),
                        )
                    }
                }
                if (isListening) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Box(
                            modifier = Modifier
                                .size(7.dp)
                                .clip(CircleShape)
                                .background(Color(0xFFE5484D)),
                        )
                        Spacer(Modifier.width(8.dp))
                        Text(
                            text = when (voiceInputState) {
                                is com.arix.app.voice.ArixSttEngine.State.Initializing ->
                                    // v2.5.2: live model-download progress while
                                    // the first summon fetches the Vosk model.
                                    voiceInputState.detail.ifBlank { stringResource(R.string.chat_voice_initializing) }
                                is com.arix.app.voice.ArixSttEngine.State.Partial ->
                                    voiceInputState.text.ifBlank { stringResource(R.string.chat_voice_listening) }
                                else -> stringResource(R.string.chat_voice_listening)
                            },
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 1,
                            modifier = Modifier.weight(1f),
                        )
                    }
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.Bottom,
                ) {
                    // Attach button (v2.4.9)
                    IconButton(
                        onClick = onAttach,
                        enabled = providerReady,
                        colors = IconButtonDefaults.iconButtonColors(
                            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f),
                            contentColor = MaterialTheme.colorScheme.onSurfaceVariant,
                        ),
                        modifier = Modifier
                            .padding(bottom = 4.dp)
                            .size(44.dp),
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.AttachFile,
                            contentDescription = stringResource(R.string.assistant_attach),
                            modifier = Modifier.size(20.dp),
                        )
                    }
                    Spacer(Modifier.width(8.dp))
                    OutlinedComposerField(
                        value = input,
                        onValueChange = onInputChange,
                        placeholder = stringResource(R.string.assistant_panel_input_hint),
                        modifier = Modifier
                            .weight(1f)
                            .focusRequester(focusRequester)
                            // v2.5.2: tapping the input box stops the mic —
                            // "if click the input box listening stop too".
                            .onFocusChanged { focusState ->
                                if (focusState.isFocused &&
                                    voiceInputState is com.arix.app.voice.ArixSttEngine.State.Listening
                                ) {
                                    onStopVoiceInput()
                                }
                            },
                        enabled = providerReady,
                        onSend = { onSend() },
                    )
                    Spacer(Modifier.width(8.dp))
                    // Offline voice input button (v2.5.2): always visible when
                    // voice input is enabled — the Vosk model downloads on
                    // demand from the first tap (no chicken-and-egg gate).
                    if (voiceInputEnabled) {
                        val pulse by animateFloatAsState(
                            targetValue = if (isListening) 1.1f else 1f,
                            animationSpec = infiniteRepeatable(tween(650), RepeatMode.Reverse),
                            label = "assistant_mic_pulse",
                        )
                        IconButton(
                            onClick = {
                                if (isListening) {
                                    onStopVoiceInput()
                                } else if (hasMicPermission) {
                                    onStartManualVoiceInput()
                                } else {
                                    onMicPermissionNeeded()
                                }
                            },
                            colors = IconButtonDefaults.iconButtonColors(
                                containerColor = if (isListening) Color(0xFFE5484D) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f),
                                contentColor = if (isListening) Color.White else MaterialTheme.colorScheme.onSurfaceVariant,
                            ),
                            modifier = Modifier
                                .padding(bottom = 4.dp)
                                .size(44.dp)
                                .graphicsLayer {
                                    scaleX = pulse
                                    scaleY = pulse
                                },
                        ) {
                            Icon(
                                imageVector = if (isListening) Icons.Rounded.Stop else Icons.Rounded.Mic,
                                contentDescription = stringResource(
                                    if (isListening) R.string.chat_voice_input_stop else R.string.assistant_voice_input,
                                ),
                                modifier = Modifier.size(19.dp),
                            )
                        }
                        Spacer(Modifier.width(8.dp))
                    }
                    IconButton(
                        onClick = onSend,
                        enabled = providerReady && (input.isNotBlank() || hasAttachment) && !uiState.isSending,
                        colors = IconButtonDefaults.iconButtonColors(
                            containerColor = MaterialTheme.colorScheme.primary,
                            contentColor = MaterialTheme.colorScheme.onPrimary,
                            disabledContainerColor = MaterialTheme.colorScheme.surfaceVariant,
                            disabledContentColor = MaterialTheme.colorScheme.onSurfaceVariant,
                        ),
                        modifier = Modifier
                            .padding(bottom = 4.dp)
                            .size(44.dp),
                    ) {
                        if (uiState.isSending) {
                            CircularProgressIndicator(
                                strokeWidth = 2.dp,
                                modifier = Modifier.size(20.dp),
                            )
                        } else {
                            Icon(
                                imageVector = Icons.AutoMirrored.Rounded.Send,
                                contentDescription = stringResource(R.string.assistant_panel_send),
                                modifier = Modifier.size(20.dp),
                            )
                        }
                    }
                }
            }
        }
    }
}

/** Pro-styled pill input field for the assistant composer. */
@Composable
private fun OutlinedComposerField(
    value: String,
    onValueChange: (String) -> Unit,
    placeholder: String,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    onSend: () -> Unit,
) {
    var focused by remember { mutableStateOf(false) }
    androidx.compose.material3.OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        placeholder = { Text(placeholder) },
        modifier = modifier,
        shape = RoundedCornerShape(24.dp),
        maxLines = 4,
        enabled = enabled,
        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
        keyboardActions = KeyboardActions(onSend = { onSend() }),
        colors = androidx.compose.material3.OutlinedTextFieldDefaults.colors(
            focusedBorderColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.65f),
            unfocusedBorderColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.35f),
            focusedContainerColor = MaterialTheme.colorScheme.surface,
            unfocusedContainerColor = MaterialTheme.colorScheme.surface,
        ),
    )
}

@Composable
private fun AssistantMessageBubble(
    text: String,
    isUser: Boolean,
) {
    if (isUser) {
        Box(
            modifier = Modifier.fillMaxWidth(),
            contentAlignment = Alignment.CenterEnd,
        ) {
            Surface(
                shape = RoundedCornerShape(18.dp, 18.dp, 6.dp, 18.dp),
                color = MaterialTheme.colorScheme.primaryContainer,
                modifier = Modifier.fillMaxWidth(0.85f),
            ) {
                Text(
                    text = text,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onPrimaryContainer,
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
                )
            }
        }
    } else {
        Text(
            text = text,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurface,
            modifier = Modifier
                .fillMaxWidth(0.95f)
                .padding(horizontal = 4.dp),
        )
    }
}

@Composable
private fun AssistantPendingBubble(
    text: String,
    status: String,
) {
    Column(modifier = Modifier.fillMaxWidth(0.95f)) {
        if (text.isNotBlank()) {
            Text(
                text = text,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurface,
            )
        } else {
            Row(verticalAlignment = Alignment.CenterVertically) {
                CircularProgressIndicator(
                    strokeWidth = 2.dp,
                    modifier = Modifier.size(16.dp),
                )
                Spacer(Modifier.width(8.dp))
                Text(
                    text = status.ifBlank {
                        stringResource(R.string.assistant_thinking)
                    },
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
        if (text.isNotBlank() && status.isNotBlank()) {
            Spacer(Modifier.height(4.dp))
            Text(
                text = status,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}
