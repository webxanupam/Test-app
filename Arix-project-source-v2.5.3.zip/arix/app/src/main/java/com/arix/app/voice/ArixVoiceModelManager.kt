package com.arix.app.voice

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.apache.commons.compress.archivers.tar.TarArchiveEntry
import org.apache.commons.compress.archivers.tar.TarArchiveInputStream
import org.apache.commons.compress.compressors.bzip2.BZip2CompressorInputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.IOException
import java.util.concurrent.TimeUnit
import java.util.zip.ZipInputStream

/**
 * v2.4.9: on-demand downloader + extractor for the offline voice models.
 *
 * Nothing is bundled inside the APK (keeps the install small); both models
 * are fetched on the first use from their official sources:
 *  - Vosk small en-us 0.15  → alphacephei.com (~40 MB zip)
 *  - Kokoro int8 en v0.19   → sherpa-onnx GitHub releases (~98 MB tar.bz2)
 *
 * v2.5.3: downloads are fault-tolerant. Transient failures — most notably
 * the BoringSSL "SSL routines:OPENSSL_internal:DECRYPTION_FAILED_OR_BAD_
 * RECORD_MAC" seen on flaky mobile networks when streaming the ~100 MB
 * Kokoro asset from GitHub — no longer abort the whole download: the
 * partial cache is kept, pooled connections are recycled, and the transfer
 * resumes via HTTP Range requests (both alphacephei.com and GitHub's
 * release CDN advertise Accept-Ranges). A partial file also survives app
 * restarts, so a failed download continues instead of restarting.
 */
class ArixVoiceModelManager(
    private val context: Context,
    internal val repository: ArixVoiceRepository,
) {
    sealed interface DownloadState {
        data object Idle : DownloadState
        data class Downloading(val model: String, val progressPercent: Int, val megabytesDone: Float, val megabytesTotal: Float) : DownloadState
        data class Extracting(val model: String) : DownloadState
        data class Done(val model: String, val success: Boolean, val error: String = "") : DownloadState
    }

    private val _downloadState = MutableStateFlow<DownloadState>(DownloadState.Idle)
    val downloadState: StateFlow<DownloadState> = _downloadState.asStateFlow()

    private val mutex = Mutex()
    private val httpClient = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .callTimeout(0, TimeUnit.SECONDS)
        .followRedirects(true)
        .retryOnConnectionFailure(true)
        .build()

    val isVoskModelInstalled: Boolean
        get() = File(repository.voskModelDirectory(), "final.mdl").exists() ||
            File(repository.voskModelDirectory(), "am/final.mdl").exists()

    val isKokoroModelInstalled: Boolean
        get() = File(repository.kokoroModelDirectory(), "model.int8.onnx").exists()

    suspend fun ensureVoskModel(): Result<File> = installModel(
        model = "vosk",
        url = "https://alphacephei.com/vosk/models/vosk-model-small-en-us-0.15.zip",
        targetDirectory = repository.voskModelDirectory(),
        expectedSizeBytes = 41_205_931L,
    )

    suspend fun ensureKokoroModel(): Result<File> = installModel(
        model = "kokoro",
        url = "https://github.com/k2-fsa/sherpa-onnx/releases/download/tts-models/kokoro-int8-en-v0_19.tar.bz2",
        targetDirectory = repository.kokoroModelDirectory(),
        // Progress estimate only (the server Content-Length stays
        // authoritative); verified against the live release asset.
        expectedSizeBytes = 103_248_205L,
    )

    private suspend fun installModel(
        model: String,
        url: String,
        targetDirectory: File,
        expectedSizeBytes: Long,
    ): Result<File> = mutex.withLock {
        if (targetDirectory.isDirectory && targetDirectory.exists()) {
            val ready = when (model) {
                "vosk" -> isVoskModelInstalled
                else -> isKokoroModelInstalled
            }
            if (ready) return@withLock Result.success(targetDirectory)
        }
        withContext(Dispatchers.IO) {
            // v2.5.3: the cache file is intentionally NOT deleted here — a
            // partial download from a previous failed attempt (this session
            // or an earlier one) is resumed via HTTP Range instead of being
            // thrown away. It is deleted when the bytes prove unusable.
            var downloadSucceeded = false
            try {
                val archiveFile = File(context.cacheDir, "voice-$model.download")
                download(url, archiveFile, model, expectedSizeBytes)
                downloadSucceeded = true
                _downloadState.value = DownloadState.Extracting(model)
                targetDirectory.deleteRecursively()
                // v2.5.2 fix: the archive is cached as "voice-<model>.download",
                // so the file NAME can never be used to detect the format (the
                // old `name.endsWith(".zip")` check was always false, which sent
                // the Vosk ZIP into the tar.bz2 extractor and failed with
                // "Stream is not in the BZip2 format"). The format is now
                // resolved from the source URL, with magic-byte sniffing as a
                // safety net for mirrors that serve a different container.
                val extractedRoot = when (resolveArchiveFormat(url, archiveFile)) {
                    ArchiveFormat.ZIP -> extractZip(archiveFile, targetDirectory.parentFile)
                    ArchiveFormat.TAR_BZ2 -> extractTarBz2(archiveFile, targetDirectory.parentFile)
                }
                archiveFile.delete()
                if (extractedRoot == null) {
                    // The bytes were unusable → drop the cache so the next
                    // attempt starts clean instead of re-extracting garbage.
                    archiveFile.delete()
                    _downloadState.value = DownloadState.Done(model, false, "Extraction failed")
                    return@withContext Result.failure(IOException("Could not extract the $model model archive."))
                }
                // Persist the canonical model directory (works whether the
                // archive wrapped files in a top-level folder or not).
                val resolvedDirectory = when (model) {
                    "vosk" -> findVoskModelRoot(extractedRoot) ?: targetDirectory
                    else -> findKokoroModelRoot(extractedRoot) ?: targetDirectory
                }
                when (model) {
                    "vosk" -> repository.setVoskModelPath(resolvedDirectory.absolutePath)
                    else -> repository.setKokoroModelPath(resolvedDirectory.absolutePath)
                }
                _downloadState.value = DownloadState.Done(model, true)
                Result.success(resolvedDirectory)
            } catch (throwable: Throwable) {
                if (throwable is kotlinx.coroutines.CancellationException) throw throwable
                // Extraction-stage failure on a fully downloaded archive →
                // the cache bytes are corrupt; remove them (download-stage
                // failures keep the partial file for Range resumption).
                if (downloadSucceeded) {
                    File(context.cacheDir, "voice-$model.download").delete()
                }
                _downloadState.value = DownloadState.Done(model, false, throwable.message ?: "download failed")
                Result.failure(throwable)
            }
        }
    }

    private fun findVoskModelRoot(root: File): File? {
        if (File(root, "am/final.mdl").exists() || File(root, "final.mdl").exists()) return root
        return root.listFiles { file -> file.isDirectory }
            ?.mapNotNull { findVoskModelRoot(it) }
            ?.firstOrNull()
    }

    private fun findKokoroModelRoot(root: File): File? {
        if (File(root, "model.int8.onnx").exists()) return root
        return root.listFiles { file -> file.isDirectory }
            ?.mapNotNull { findKokoroModelRoot(it) }
            ?.firstOrNull()
    }

    /** v2.5.2: archive container detection. The URL extension is the
     *  primary signal; magic bytes verify it (a mirror serving a different
     *  container can never crash the extractor again). */
    private enum class ArchiveFormat { ZIP, TAR_BZ2 }

    private fun resolveArchiveFormat(url: String, archiveFile: File): ArchiveFormat {
        val fromUrl = when {
            url.endsWith(".zip", ignoreCase = true) -> ArchiveFormat.ZIP
            url.endsWith(".tar.bz2", ignoreCase = true) ||
                url.endsWith(".bz2", ignoreCase = true) ||
                url.endsWith(".tbz2", ignoreCase = true) -> ArchiveFormat.TAR_BZ2
            else -> null
        }
        val magic = runCatching {
            FileInputStream(archiveFile).use { input ->
                val header = ByteArray(4)
                val read = input.read(header)
                if (read >= 3 && header[0] == 'B'.code.toByte() && header[1] == 'Z'.code.toByte() && header[2] == 'h'.code.toByte()) {
                    ArchiveFormat.TAR_BZ2
                } else if (read >= 4 && header[0] == 'P'.code.toByte() && header[1] == 'K'.code.toByte()) {
                    ArchiveFormat.ZIP
                } else {
                    null
                }
            }
        }.getOrNull()
        // Magic bytes win over the URL — they describe the actual bytes.
        return magic ?: fromUrl ?: ArchiveFormat.TAR_BZ2
    }

    /** Marks HTTP errors that retrying cannot fix (permanent 4xx on a clean
     *  request) so the retry loop below fails fast instead of burning the
     *  backoff schedule. */
    private class NonRetryableDownloadException(message: String) : IOException(message)

    /**
     * v2.5.3: fault-tolerant download. Transient transport failures — SSL
     * stream corruption ("DECRYPTION_FAILED_OR_BAD_RECORD_MAC"), socket
     * resets, premature EOFs, HTTP 5xx — are retried with exponential
     * backoff, and because the partial cache file is kept, every retry
     * RESUMES from the last byte via `Range: bytes=<n>-` instead of
     * restarting the (up to ~100 MB) transfer from zero. Pooled connections
     * are evicted before each retry so a poisoned TLS session can never be
     * reused, and each request carries `Connection: close` to keep the
     * transfer on a single fresh stream.
     */
    private suspend fun download(url: String, target: File, model: String, expectedSizeBytes: Long) {
        val maxAttempts = 10
        var lastError: IOException? = null
        for (attempt in 1..maxAttempts) {
            val alreadyDownloaded = if (target.exists()) target.length() else 0L
            try {
                downloadAttempt(url, target, model, expectedSizeBytes, alreadyDownloaded)
                return
            } catch (error: IOException) {
                if (error is NonRetryableDownloadException) throw error
                lastError = error
                // Recycle pooled connections: after a TLS record MAC failure
                // the pooled session is unusable and would fail again.
                httpClient.connectionPool.evictAll()
                if (attempt == maxAttempts) break
                // 1s, 2s, 4s, 8s, 8s … backoff before resuming.
                val backoffMs = 1000L shl (attempt - 1).coerceAtMost(3)
                delay(backoffMs)
            }
        }
        throw IOException(
            "Download failed after $maxAttempts attempts (last error: ${lastError?.message ?: "unknown"})",
            lastError,
        )
    }

    /** A single download pass; appends to [target] when the server honors
     *  the Range resume request (HTTP 206). */
    private fun downloadAttempt(
        url: String,
        target: File,
        model: String,
        expectedSizeBytes: Long,
        alreadyDownloaded: Long,
    ) {
        val request = Request.Builder()
            .url(url)
            .header("User-Agent", "Arix/${context.packageName}")
            .header("Connection", "close")
            .apply { if (alreadyDownloaded > 0) header("Range", "bytes=$alreadyDownloaded-") }
            .build()
        httpClient.newCall(request).execute().use { response ->
            when (response.code) {
                416 -> {
                    // "Range Not Satisfiable": usually means the cached partial
                    // already covers the whole asset. The Content-Range header
                    // carries the total ("bytes */N") — accept when we have it.
                    val totalFromRange = response.header("Content-Range")
                        ?.substringAfterLast("*/")
                        ?.toLongOrNull()
                    if (totalFromRange != null && target.length() >= totalFromRange) return
                    target.delete()
                    throw IOException("Download failed: HTTP 416")
                }
                in 400..499 -> {
                    // Permanent client error (dead URL, auth, …): the cached
                    // partial is worthless against this URL — drop it and
                    // fail fast instead of burning the retry schedule.
                    target.delete()
                    throw NonRetryableDownloadException("Download failed: HTTP ${response.code}")
                }
                else -> if (!response.isSuccessful) throw IOException("Download failed: HTTP ${response.code}")
            }
            val body = response.body ?: throw IOException("Download failed: empty response")
            // 206 = the server honors the Range header and streams only the
            // tail; anything else (200 = server ignored Range and is streaming
            // the whole asset) restarts the cache from byte zero.
            val resumed = response.code == 206 && alreadyDownloaded > 0
            val contentLength = body.contentLength()
            val totalBytes = when {
                resumed && contentLength >= 0 -> alreadyDownloaded + contentLength
                contentLength > 0 -> contentLength
                else -> expectedSizeBytes
            }
            // v2.5.2: only the server-provided Content-Length is authoritative
            // for the completeness check; expectedSizeBytes is just a progress
            // estimate, and mirrors occasionally ship slightly different sizes.
            val enforceExactSize = contentLength >= 0
            var doneBytes = if (resumed) alreadyDownloaded else 0L
            body.byteStream().use { input ->
                // Append when resuming; a plain FileOutputStream truncates a
                // stale cache when the server ignored the Range request.
                FileOutputStream(target, resumed).use { output ->
                    val buffer = ByteArray(64 * 1024)
                    var read = input.read(buffer)
                    var lastProgress = -1
                    while (read >= 0) {
                        output.write(buffer, 0, read)
                        doneBytes += read
                        if (totalBytes > 0) {
                            val percent = ((doneBytes * 100) / totalBytes).toInt().coerceIn(0, 100)
                            if (percent != lastProgress) {
                                lastProgress = percent
                                _downloadState.value = DownloadState.Downloading(
                                    model = model,
                                    progressPercent = percent,
                                    megabytesDone = doneBytes / 1_048_576f,
                                    megabytesTotal = totalBytes / 1_048_576f,
                                )
                            }
                        }
                        read = input.read(buffer)
                    }
                }
            }
            // v2.5.2: a zero-byte or tiny download is always broken.
            if (doneBytes < 1024) {
                throw IOException("Download incomplete (${doneBytes} bytes)")
            }
            if (enforceExactSize && totalBytes > 0 && doneBytes < totalBytes) {
                throw IOException("Download incomplete (${doneBytes}/${totalBytes} bytes)")
            }
        }
    }

    private fun extractZip(archive: File, targetParent: File): File? {
        ZipInputStream(FileInputStream(archive)).use { zip ->
            var entry = zip.nextEntry
            while (entry != null) {
                val sanitized = sanitizeEntryName(entry.name)
                if (sanitized != null) {
                    val destination = File(targetParent, sanitized)
                    if (entry.isDirectory) {
                        destination.mkdirs()
                    } else {
                        destination.parentFile?.mkdirs()
                        FileOutputStream(destination).use { output ->
                            zip.copyTo(output)
                        }
                    }
                }
                zip.closeEntry()
                entry = zip.nextEntry
            }
        }
        return targetParent
    }

    private fun extractTarBz2(archive: File, targetParent: File): File? {
        TarArchiveInputStream(BZip2CompressorInputStream(FileInputStream(archive))).use { tar ->
            var entry: TarArchiveEntry? = tar.nextTarEntry
            while (entry != null) {
                val sanitized = sanitizeEntryName(entry.name)
                if (sanitized != null) {
                    val destination = File(targetParent, sanitized)
                    if (entry.isDirectory) {
                        destination.mkdirs()
                    } else {
                        destination.parentFile?.mkdirs()
                        FileOutputStream(destination).use { output ->
                            tar.copyTo(output)
                        }
                    }
                }
                entry = tar.nextTarEntry
            }
        }
        return targetParent
    }

    /** Blocks path traversal (../) entries inside archives. */
    private fun sanitizeEntryName(name: String): String? {
        val normalized = name.replace('\\', '/')
        if (normalized.isBlank() || normalized.startsWith("/") || normalized.contains("../")) return null
        return normalized
    }

    /** Manual delete from Settings → Voice → storage. */
    suspend fun deleteModels(): Boolean = withContext(Dispatchers.IO) {
        repository.setVoskModelPath("")
        repository.setKokoroModelPath("")
        val root = repository.modelsRoot()
        val deleted = root.deleteRecursively()
        root.mkdirs()
        _downloadState.value = DownloadState.Idle
        deleted
    }

    fun modelStorageBytes(): Long {
        val root = repository.modelsRoot()
        return root.walkTopDown().filter { it.isFile }.sumOf { it.length() }
    }
}
