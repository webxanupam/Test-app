package com.arix.app.runtime

import android.content.Context
import android.net.TrafficStats
import android.os.Build
import com.arix.app.data.ArixDiagnosticLogger
import com.arix.app.data.AlpineEnvironmentVariable
import com.arix.app.data.LocalRuntimeId
import com.arix.app.data.normalizeAlpineEnvironmentVariables
import java.io.File
import java.io.InputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.zip.GZIPInputStream
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicInteger
import java.nio.file.Files
import java.nio.file.LinkOption
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.withContext
import org.json.JSONObject

private const val AlpineWatchWindowMillis = 45_000L
private const val AlpineDefaultTailBytes = 12 * 1024
private const val AlpineMaxTailBytes = 64 * 1024
private const val AlpineNetworkRateWindowMillis = 5_000L
private const val AlpineAssetRoot = "runtimes/alpine/arm64-v8a"
private const val AlpineHostLinker = "/system/bin/linker64"
private const val AlpineNetworkTraceUrl = "https://www.cloudflare.com/cdn-cgi/trace"
private const val AlpineNetworkDetectionTimeoutMillis = 4_000
private const val AlpineOfficialRepository = "https://dl-cdn.alpinelinux.org/alpine"
private const val AlpineChinaRepository = "https://mirrors.tuna.tsinghua.edu.cn/alpine"

/**
 * v2.4.1: guest paths that map onto the phone's real shared storage.
 * Mirrored by the proot bind mounts (see [AlpineRuntime.phoneStorageBinds])
 * and by [AlpineRuntime]'s guest-to-host file resolution.
 */
internal val PhoneStorageGuestRoots = listOf(
    "/sdcard",
    "/storage/emulated/0",
)
private val AlpineRootfsAssetCandidates = listOf(
    RootfsAsset("$AlpineAssetRoot/rootfs.tar.gz", compressed = true),
    RootfsAsset("$AlpineAssetRoot/rootfs.tar", compressed = false),
)

internal enum class ApkNetworkEnvironment {
    China,
    International,
    Unknown,
}

internal fun parseCloudflareCountryCode(trace: String): String? =
    trace.lineSequence()
        .firstOrNull { it.startsWith("loc=", ignoreCase = true) }
        ?.substringAfter('=')
        ?.trim()
        ?.takeIf { it.length == 2 }
        ?.uppercase()

internal fun apkRepositories(
    original: String,
    environment: ApkNetworkEnvironment,
): String =
    original.lines().flatMap { line ->
        val official = line
            .replace(Regex("https?://dl-cdn\\.alpinelinux\\.org/alpine"), AlpineOfficialRepository)
            .replace(Regex("https?://mirrors\\.tuna\\.tsinghua\\.edu\\.cn/alpine"), AlpineOfficialRepository)
        if (official == line &&
            "dl-cdn.alpinelinux.org/alpine" !in line &&
            "mirrors.tuna.tsinghua.edu.cn/alpine" !in line
        ) {
            listOf(line)
        } else {
            val china = official.replace(AlpineOfficialRepository, AlpineChinaRepository)
            when (environment) {
                ApkNetworkEnvironment.China -> listOf(china, official)
                ApkNetworkEnvironment.International -> listOf(official)
                ApkNetworkEnvironment.Unknown -> listOf(official, china)
            }
        }
    }.distinct().joinToString("\n")

internal fun chinaApkRepositories(original: String): String =
    apkRepositories(original, ApkNetworkEnvironment.China)

class AlpineRuntime(
    context: Context,
    private val diagnosticLogger: ArixDiagnosticLogger = ArixDiagnosticLogger.NoOp,
) : LocalRuntime {
    private val appContext = context.applicationContext
    private val runtimeRoot = File(appContext.filesDir, "runtimes/alpine")
    private val stagingRoot = File(runtimeRoot.parentFile, "alpine-installing")
    private val rootfsDir = File(runtimeRoot, "rootfs")
    private val workspaceDir = File(runtimeRoot, "workspace")
    private val hostBinDir = File(runtimeRoot, "bin")
    private val hostLibDir = File(runtimeRoot, "lib")
    private val hostTmpDir = File(runtimeRoot, "tmp")
    private val loaderDir = File(runtimeRoot, "libexec/proot")
    private val loaderFile = File(loaderDir, "loader")
    private val prootFile = File(hostBinDir, "proot")
    private val libTallocFile = File(hostLibDir, "libtalloc.so.2")
    private val runs = ConcurrentHashMap<String, AlpineRun>()
    private val nextRunId = AtomicInteger(1)
    private val packageInstallMutex = Mutex()
    private val apkRepositoryMutex = Mutex()
    @Volatile
    private var startupNetworkEnvironment: ApkNetworkEnvironment? = null
    @Volatile
    private var environmentVariables: List<AlpineEnvironmentVariable> = emptyList()

    override val id: LocalRuntimeId = LocalRuntimeId.Alpine
    override val displayName: String = "Alpine"
    override val homeDirectory: String = "/root"
    override val workspaceRoot: String = "/workspace"
    override val managedCommandsDirectory: String = "/root/.arix/bash-runs"

    internal fun resolveWorkspaceHostPath(
        path: String,
        workingDirectory: String = workspaceRoot,
    ): AlpineWorkspaceHostPath? {
        val normalizedWorkingDirectory = normalizePath(workingDirectory.trim())
            .ifBlank { workspaceRoot }
        val normalizedGuestPath = when {
            path.isBlank() -> normalizedWorkingDirectory
            path.startsWith("/") -> java.nio.file.Paths.get(path).normalize().toString()
            else -> java.nio.file.Paths.get(normalizedWorkingDirectory).resolve(path).normalize().toString()
        }
        if (
            normalizedGuestPath != workspaceRoot &&
            !normalizedGuestPath.startsWith("$workspaceRoot/")
        ) {
            return null
        }
        val relativePath = normalizedGuestPath.removePrefix(workspaceRoot).trimStart('/')
        val canonicalWorkspace = workspaceDir.canonicalFile
        val hostFile = File(canonicalWorkspace, relativePath).canonicalFile
        if (
            hostFile != canonicalWorkspace &&
            !hostFile.path.startsWith("${canonicalWorkspace.path}${File.separator}")
        ) {
            return null
        }
        return AlpineWorkspaceHostPath(
            guestPath = normalizedGuestPath,
            hostFile = hostFile,
        )
    }

    fun setEnvironmentVariables(variables: List<AlpineEnvironmentVariable>) {
        environmentVariables = normalizeAlpineEnvironmentVariables(variables)
    }

    suspend fun initialize(
        onProgress: (AlpineSetupProgress) -> Unit = {},
    ): LocalRuntimeSetupState = withContext(Dispatchers.IO) {
        inspectSetup().let { state ->
            if (
                state.issue != LocalRuntimeIssue.NotInstalled &&
                state.issue != LocalRuntimeIssue.Failed &&
                state.issue != LocalRuntimeIssue.MissingAssets
            ) {
                if (state.isReady) refreshApkRepositoriesForCurrentNetwork(onProgress)
                return@withContext state
            }
        }
        if (!isSupportedAbi()) return@withContext unsupportedAbiState()
        if (!hasBundledRuntimeAssets()) {
            return@withContext LocalRuntimeSetupState(
                runtimeId = id,
                issue = LocalRuntimeIssue.MissingAssets,
                detail = "Alpine runtime assets are not bundled in this build.",
            )
        }
        runCatching {
            installFromAssets(onProgress)
        }.fold(
            onSuccess = {
                inspectSetup().let { state ->
                    if (state.isReady) {
                        state.copy(detail = "Alpine runtime is ready.")
                    } else {
                        state
                    }
                }
            },
            onFailure = { throwable ->
                LocalRuntimeSetupState(
                    runtimeId = id,
                    issue = LocalRuntimeIssue.Failed,
                    detail = throwable.message ?: "Failed to install Alpine runtime.",
                )
            },
        )
    }

    suspend fun reset(): LocalRuntimeSetupState = withContext(Dispatchers.IO) {
        runs.values.forEach { run ->
            run.process?.takeIf(Process::isAlive)?.let { process ->
                run.cancelled = true
                runCatching { process.destroy() }
                if (!process.waitFor(800, TimeUnit.MILLISECONDS)) {
                    runCatching { process.destroyForcibly() }
                }
            }
        }
        runs.clear()
        check(!runtimeRoot.exists() || runtimeRoot.deleteRecursively()) {
            "Unable to reset Alpine runtime data."
        }
        check(!stagingRoot.exists() || stagingRoot.deleteRecursively()) {
            "Unable to reset incomplete Alpine installation data."
        }
        LocalRuntimeSetupState(
            runtimeId = id,
            issue = LocalRuntimeIssue.NotInstalled,
            detail = "Alpine runtime data was reset.",
        )
    }

    suspend fun createTerminalLaunchSpec(): AlpineTerminalLaunchSpec = withContext(Dispatchers.IO) {
        requireReady()
        ensureWorkspace()
        ensureGuestNetworkConfig()
        // v2.4.3: the arix-adb helper (adb daemon control on this same device)
        // is written into the guest so `arix-adb` works in every new shell.
        ensureAdbHelperScript()
        val command = buildAlpineInteractiveCommand()
        AlpineTerminalLaunchSpec(
            executable = command.first(),
            arguments = command.toTypedArray(),
            environment = buildAlpineProcessEnvironment()
                .map { (key, value) -> "$key=$value" }
                .toTypedArray(),
            workingDirectory = runtimeRoot.absolutePath,
        )
    }

    suspend fun installAsset(
        assetPath: String,
        guestPath: String,
        executable: Boolean = false,
    ): File = withContext(Dispatchers.IO) {
        requireReady()
        val normalizedGuestPath = normalizePath(guestPath)
        val target = guestPathToHostFile(normalizedGuestPath)
        copyAsset(assetPath, target, executable)
        target
    }

    suspend fun installPreinstalledExtensions(): Unit = withContext(Dispatchers.IO) {
        installAssetDirectoryRecursively("extensions", "/root/.arix/extensions", force = shouldRefreshBundledExtensions())
        writeBundledExtensionsVersionMarker()
    }

    internal fun installPreinstalledExtensionsSync() {
        installAssetDirectoryRecursively("extensions", "/root/.arix/extensions", force = shouldRefreshBundledExtensions())
        writeBundledExtensionsVersionMarker()
    }

    /**
     * v2.4.2: bundled extensions shipped in the APK evolve between app
     * releases (e.g. the v2.4.1 MCP adapter fixes), but
     * [installAssetDirectoryRecursively] deliberately never overwrites
     * existing files. That meant upgraded installs kept running the OLD
     * extension code from the previous release forever. A version marker
     * in the rootfs records which app version last refreshed the bundled
     * extensions; when it differs from the running version the assets are
     * re-installed with overwrite (removal markers are still honoured so
     * user-removed extensions stay removed).
     */
    private fun shouldRefreshBundledExtensions(): Boolean {
        val marker = guestPathToHostFile("/root/.arix/.bundled-extensions-version")
        return runCatching { marker.readText().trim() }.getOrDefault("") != bundledExtensionsVersion()
    }

    private fun writeBundledExtensionsVersionMarker() {
        runCatching {
            val marker = guestPathToHostFile("/root/.arix/.bundled-extensions-version")
            marker.parentFile?.mkdirs()
            marker.writeText(bundledExtensionsVersion())
        }
    }

    private fun bundledExtensionsVersion(): String = runCatching {
        appContext.packageManager.getPackageInfo(appContext.packageName, 0)
            .versionName ?: "unknown"
    }.getOrDefault("unknown")

    private fun installAssetDirectoryRecursively(
        assetDir: String,
        guestTargetDir: String,
        force: Boolean = false,
    ) {
        val list = runCatching { appContext.assets.list(assetDir) }.getOrNull() ?: return
        if (list.isEmpty()) return
        for (item in list) {
            if (
                assetDir.startsWith("extensions") &&
                guestPathToHostFile("/root/.arix/.removed-preinstalled-extensions/$item").existsNoFollow()
            ) {
                continue
            }
            val childAssetPath = "$assetDir/$item"
            val childGuestPath = "$guestTargetDir/$item"
            // Arix extensions are shared with user imports. Once a user owns a
            // top-level entry, never merge or overwrite it with bundled files
            // — unless the app version changed and a refresh is forced, in
            // which case bundled fixes must reach upgraded installs.
            val existingTarget = guestPathToHostFile(normalizePath(childGuestPath))
            if (existingTarget.existsNoFollow() && !force) continue
            val subList = runCatching { appContext.assets.list(childAssetPath) }.getOrNull()
            if (subList != null && subList.isNotEmpty()) {
                installAssetDirectoryRecursively(childAssetPath, childGuestPath, force)
            } else {
                runCatching {
                    val target = guestPathToHostFile(normalizePath(childGuestPath))
                    copyAsset(childAssetPath, target, executable = false)
                }
            }
        }
    }

    internal fun markPreinstalledExtensionRemoved(name: String) {
        val safeName = name.trim()
        require(safeName.isNotBlank() && '/' !in safeName && '\\' !in safeName) {
            "Invalid preinstalled extension name."
        }
        val marker = guestPathToHostFile("/root/.arix/.removed-preinstalled-extensions/$safeName")
        require(marker.parentFile?.mkdirs() != false || marker.parentFile?.isDirectory == true) {
            "Unable to store the removed preinstalled extension state."
        }
        marker.writeText("removed\n")
    }

    internal fun clearPreinstalledExtensionRemoved(name: String) {
        val marker = guestPathToHostFile("/root/.arix/.removed-preinstalled-extensions/$name")
        if (marker.existsNoFollow()) require(marker.delete()) {
            "Unable to restore the preinstalled extension state."
        }
    }

    internal suspend fun ensureGuestDirectory(guestPath: String): File = withContext(Dispatchers.IO) {
        requireReady()
        guestPathToHostFile(normalizePath(guestPath)).apply {
            require(mkdirs() || isDirectory) {
                "Unable to create Alpine directory: $guestPath"
            }
        }
    }

    internal suspend fun resolveGuestPath(guestPath: String): File = withContext(Dispatchers.IO) {
        requireReady()
        guestPathToHostFile(normalizePath(guestPath))
    }

    override suspend fun replaceHostDirectories(
        guestRootPath: String,
        signature: String,
        directories: Map<String, File>,
    ): Boolean = withContext(Dispatchers.IO) {
        requireReady()
        val targetRoot = guestPathToHostFile(normalizePath(guestRootPath))
        val signatureFileName = ".arix-mirror-signature"
        val currentSignature = File(targetRoot, signatureFileName)
            .takeIf(File::isFile)
            ?.readText()
        if (currentSignature == signature) return@withContext true

        val parent = targetRoot.parentFile
            ?: error("Unable to resolve Alpine mirror parent: $guestRootPath")
        require(parent.mkdirs() || parent.isDirectory) {
            "Unable to create Alpine mirror parent: $guestRootPath"
        }
        val staging = File(parent, ".${targetRoot.name}.staging-${UUID.randomUUID()}")
        val backup = File(parent, ".${targetRoot.name}.backup-${UUID.randomUUID()}")
        try {
            require(staging.mkdirs()) { "Unable to create Alpine mirror staging directory." }
            directories.toSortedMap().forEach { (name, source) ->
                require(name.matches(Regex("[A-Za-z0-9._-]+"))) {
                    "Invalid Alpine mirror directory name: $name"
                }
                val canonicalSource = source.canonicalFile
                require(canonicalSource.isDirectory) {
                    "Alpine mirror source is unavailable: ${source.path}"
                }
                copyDirectoryWithoutSymbolicLinks(canonicalSource, File(staging, name))
            }
            File(staging, signatureFileName).writeText(signature)

            if (targetRoot.exists()) {
                require(targetRoot.renameTo(backup)) {
                    "Unable to stage the existing Alpine mirror directory."
                }
            }
            if (!staging.renameTo(targetRoot)) {
                if (backup.exists()) backup.renameTo(targetRoot)
                error("Unable to activate the Alpine mirror directory.")
            }
            backup.deleteRecursively()
            true
        } finally {
            staging.deleteRecursively()
            if (backup.exists() && !targetRoot.exists()) backup.renameTo(targetRoot)
            if (targetRoot.exists()) backup.deleteRecursively()
        }
    }

    internal fun resolveManagedGuestPath(guestPath: String): File =
        guestPathToHostFile(normalizePath(guestPath))

    suspend fun startManagedProcess(
        command: String,
        workingDirectory: String = homeDirectory,
        redirectErrorStream: Boolean = false,
    ): Process = withContext(Dispatchers.IO) {
        val normalizedWorkingDirectory = normalizePath(workingDirectory)
        requireReady()
        ensureWorkspace()
        ensureGuestNetworkConfig()
        buildAlpineProcess(command, normalizedWorkingDirectory)
            .redirectErrorStream(redirectErrorStream)
            .start()
    }

    private suspend fun requireReady() {
        val setup = inspectSetup()
        if (!setup.isReady) {
            error(setup.detail.ifBlank { "Alpine runtime is not ready." })
        }
    }

    suspend fun installPackageProfile(
        profileId: String,
        onProgress: (AlpineSetupProgress) -> Unit = {},
    ): LocalRuntimeSetupState {
        packageInstallMutex.lock()
        return try {
            installPackageProfileLocked(profileId, onProgress)
        } finally {
            packageInstallMutex.unlock()
        }
    }

    private suspend fun installPackageProfileLocked(
        profileId: String,
        onProgress: (AlpineSetupProgress) -> Unit,
    ): LocalRuntimeSetupState {
        if (profileId !in AlpinePackageProfiles) {
            return LocalRuntimeSetupState(
                runtimeId = id,
                issue = LocalRuntimeIssue.Failed,
                detail = "Unknown Alpine package profile: $profileId",
            )
        }
        val setup = inspectSetup()
        if (!setup.isReady) return setup
        refreshApkRepositoriesForCurrentNetwork(onProgress)
        if (verifyPackageProfile(profileId)) {
            return LocalRuntimeSetupState(
                runtimeId = id,
                issue = LocalRuntimeIssue.Ready,
                detail = "Alpine profile $profileId is already installed.",
            )
        }
        val command = packageProfileInstallCommand(profileId)
            ?: return LocalRuntimeSetupState(
                runtimeId = id,
                issue = LocalRuntimeIssue.Failed,
                detail = "Unknown Alpine package profile: $profileId",
            )
        val progressTracker = AlpinePackageInstallProgressTracker()
        onProgress(progressTracker.onOutput("\$ $command\n"))
        val rateSampler = NetworkRateSampler { bytesPerSecond ->
            onProgress(progressTracker.onRate(bytesPerSecond))
        }
        rateSampler.start()
        val result = try {
            JSONObject(
                executeCommand(
                    command = command,
                    workingDirectory = homeDirectory,
                    awaitTimeoutMillis = 10 * 60 * 1000L,
                    onOutput = { output ->
                        onProgress(progressTracker.onOutput(output))
                    },
                )
            )
        } finally {
            rateSampler.stop()
        }
        return if (result.optBoolean("ok") || verifyPackageProfile(profileId)) {
            LocalRuntimeSetupState(
                runtimeId = id,
                issue = LocalRuntimeIssue.Ready,
                detail = "Installed Alpine profile $profileId.",
            )
        } else {
            LocalRuntimeSetupState(
                runtimeId = id,
                issue = LocalRuntimeIssue.Failed,
                detail = result.optString("errmsg").ifBlank { result.optString("stderr") },
            )
        }
    }

    fun packageProfileInstallCommand(profileId: String): String? {
        val packages = AlpinePackageProfiles[profileId] ?: return null
        return "apk add --no-cache --no-chown ${packages.joinToString(" ")}"
    }

    suspend fun isPackageProfileInstalled(profileId: String): Boolean =
        verifyPackageProfile(profileId)

    override suspend fun inspectSetup(): LocalRuntimeSetupState = withContext(Dispatchers.IO) {
        when {
            !isSupportedAbi() -> unsupportedAbiState()
            !hasBundledRuntimeAssets() -> LocalRuntimeSetupState(
                runtimeId = id,
                issue = LocalRuntimeIssue.MissingAssets,
                detail = "This build does not include Alpine proot/rootfs assets.",
            )
            !rootfsDir.isDirectory -> LocalRuntimeSetupState(
                runtimeId = id,
                issue = LocalRuntimeIssue.NotInstalled,
                detail = "Alpine rootfs is not installed.",
            )
            !prootFile.isFile || !loaderFile.isFile || !libTallocFile.isFile -> LocalRuntimeSetupState(
                runtimeId = id,
                issue = LocalRuntimeIssue.Failed,
                detail = "Alpine host runtime is incomplete.",
            )
            !File(AlpineHostLinker).isFile -> LocalRuntimeSetupState(
                runtimeId = id,
                issue = LocalRuntimeIssue.Failed,
                detail = "Android dynamic linker is unavailable: $AlpineHostLinker",
            )
            !File(rootfsDir, "bin/sh").existsNoFollow() -> LocalRuntimeSetupState(
                runtimeId = id,
                issue = LocalRuntimeIssue.Failed,
                detail = "Alpine rootfs is incomplete: /bin/sh is missing.",
            )
            !File(rootfsDir, "etc/alpine-release").existsNoFollow() -> LocalRuntimeSetupState(
                runtimeId = id,
                issue = LocalRuntimeIssue.Failed,
                detail = "Alpine rootfs is incomplete: /etc/alpine-release is missing.",
            )
            else -> LocalRuntimeSetupState(LocalRuntimeId.Alpine, LocalRuntimeIssue.Ready)
        }
    }

    override suspend fun execute(
        argumentsJson: String,
        onProgress: (suspend (String) -> Unit)?,
    ): String = withContext(Dispatchers.IO) {
        val arguments = runCatching { JSONObject(argumentsJson) }.getOrNull()
            ?: return@withContext invalidArguments("Arguments were not valid JSON.")
        val command = arguments.optString("command").trim()
        val workingDirectory = normalizePath(
            arguments.optString("working_directory").trim()
                .ifBlank { arguments.optString("workingDirectory").trim() }
                .ifBlank { homeDirectory }
        )
        if (command.isBlank()) return@withContext invalidArguments("Missing required 'command' argument.")

        val setup = inspectSetup()
        if (!setup.isReady) return@withContext setupError(command, workingDirectory, setup)

        ensureWorkspace()
        ensureGuestNetworkConfig()
        val runId = nextRunId()
        val runDir = File(runtimeRoot, "runs/$runId").apply { mkdirs() }
        val stdoutFile = File(runDir, "stdout.log")
        val stderrFile = File(runDir, "stderr.log")
        val run = AlpineRun(
            runId = runId,
            command = command,
            workingDirectory = workingDirectory,
            startedAtMillis = System.currentTimeMillis(),
            stdoutFile = stdoutFile,
            stderrFile = stderrFile,
        )
        runs[runId] = run

        val process = runCatching {
            buildAlpineProcess(command, workingDirectory)
                .redirectOutput(stdoutFile)
                .redirectError(stderrFile)
                .start()
        }.getOrElse { throwable ->
            runs.remove(runId)
            return@withContext commandError(
                command = command,
                workingDirectory = workingDirectory,
                runId = runId,
                message = throwable.message ?: "Failed to start Alpine command.",
            )
        }
        run.process = process
        AlpineRunReaper.watch(run, runs)

        try {
            val deadline = System.currentTimeMillis() + AlpineWatchWindowMillis
            while (System.currentTimeMillis() < deadline && process.isAlive) {
                delay(1_000L)
                onProgress?.invoke(snapshot(run, AlpineDefaultTailBytes))
            }
            snapshot(run, AlpineDefaultTailBytes)
        } catch (cancellationException: CancellationException) {
            runCatching { killExecutionByRunId(runId) }
            throw cancellationException
        }
    }

    override suspend fun fetchExecution(argumentsJson: String): String = withContext(Dispatchers.IO) {
        val arguments = runCatching { JSONObject(argumentsJson) }.getOrNull()
            ?: return@withContext invalidArguments("Arguments were not valid JSON.")
        val runId = arguments.optString("run_id").trim()
            .ifBlank { arguments.optString("runId").trim() }
        if (runId.isBlank()) return@withContext invalidArguments("Missing required 'run_id' argument.")
        val tailBytes = resolveTailBytes(arguments)
        runs[runId]?.let { return@withContext snapshot(it, tailBytes) }
        invalidArguments("Unknown Alpine run_id: $runId")
    }

    override suspend fun killExecution(argumentsJson: String): String = withContext(Dispatchers.IO) {
        val arguments = runCatching { JSONObject(argumentsJson) }.getOrNull()
            ?: return@withContext invalidArguments("Arguments were not valid JSON.")
        val runId = arguments.optString("run_id").trim()
            .ifBlank { arguments.optString("runId").trim() }
        val tailBytes = resolveTailBytes(arguments)
        killExecutionByRunId(runId, tailBytes)
    }

    override suspend fun killExecutionByRunId(
        runId: String,
        tailBytes: Int,
    ): String = withContext(Dispatchers.IO) {
        if (runId.isBlank()) return@withContext invalidArguments("Missing required run id.")
        val run = runs[runId] ?: return@withContext invalidArguments("Unknown Alpine run_id: $runId")
        run.process?.let { process ->
            if (process.isAlive) {
                run.cancelled = true
                runCatching { process.destroy() }
                if (!process.waitFor(800, TimeUnit.MILLISECONDS)) {
                    runCatching { process.destroyForcibly() }
                }
            }
        }
        snapshot(run, tailBytes)
    }

    override suspend fun executeCommand(
        command: String,
        workingDirectory: String,
        awaitTimeoutMillis: Long,
    ): String = executeCommand(command, workingDirectory, awaitTimeoutMillis, null)

    private suspend fun executeCommand(
        command: String,
        workingDirectory: String,
        awaitTimeoutMillis: Long,
        onOutput: ((String) -> Unit)?,
    ): String = withContext(Dispatchers.IO) {
        val normalizedWorkingDirectory = normalizePath(workingDirectory)
        val setup = inspectSetup()
        if (!setup.isReady) return@withContext setupError(command, normalizedWorkingDirectory, setup)
        ensureWorkspace()
        ensureGuestNetworkConfig()
        val startedAtMillis = System.currentTimeMillis()
        val stdoutFile = File.createTempFile("arix-alpine-stdout", ".log", runtimeRoot)
        val stderrFile = File.createTempFile("arix-alpine-stderr", ".log", runtimeRoot)
        val streamedStdout = StringBuilder()
        val streamedStderr = StringBuilder()
        val process = runCatching {
            buildAlpineProcess(command, normalizedWorkingDirectory).apply {
                if (onOutput == null) {
                    redirectOutput(stdoutFile)
                    redirectError(stderrFile)
                }
            }.start()
        }.getOrElse { throwable ->
            return@withContext commandError(
                command = command,
                workingDirectory = normalizedWorkingDirectory,
                message = throwable.message ?: "Failed to start Alpine command.",
            )
        }
        val outputThreads = if (onOutput != null) {
            listOf(
                streamProcessOutput(process.inputStream, streamedStdout, onOutput),
                streamProcessOutput(process.errorStream, streamedStderr, onOutput),
            )
        } else {
            emptyList()
        }
        val finished = process.waitFor(awaitTimeoutMillis, TimeUnit.MILLISECONDS)
        if (!finished) {
            runCatching { process.destroy() }
            if (!process.waitFor(800, TimeUnit.MILLISECONDS)) {
                runCatching { process.destroyForcibly() }
            }
        }
        outputThreads.forEach { thread -> runCatching { thread.join(500L) } }
        val stdout = if (onOutput == null) stdoutFile.readTextSafe() else streamedStdout.toString()
        val stderr = if (onOutput == null) stderrFile.readTextSafe() else streamedStderr.toString()
        stdoutFile.delete()
        stderrFile.delete()
        JSONObject().apply {
            put("ok", finished && process.exitValueSafe() == 0)
            put("command", command)
            put("working_directory", normalizedWorkingDirectory)
            put("duration_ms", System.currentTimeMillis() - startedAtMillis)
            put("stdout", stdout)
            put("stderr", stderr)
            put("exit_code", if (finished) process.exitValueSafe() else -1)
            put("err", if (finished) -1 else -2)
            put("errmsg", if (finished) "" else "Timed out waiting for Alpine to reply.")
        }.toString()
    }

    private fun streamProcessOutput(
        stream: InputStream,
        sink: StringBuilder,
        onOutput: (String) -> Unit,
    ): Thread = Thread(
        {
            val buffer = ByteArray(4096)
            runCatching {
                stream.use {
                    while (true) {
                        val read = it.read(buffer)
                        if (read == -1) break
                        if (read > 0) {
                            val chunk = String(buffer, 0, read, Charsets.UTF_8)
                            synchronized(sink) {
                                sink.append(chunk)
                                if (sink.length > 64_000) {
                                    sink.delete(0, sink.length - 64_000)
                                }
                            }
                            onOutput(chunk)
                        }
                    }
                }
            }
        },
        "arix-alpine-command-output",
    ).apply {
        isDaemon = true
        start()
    }

    private fun buildAlpineProcess(
        command: String,
        workingDirectory: String,
    ): ProcessBuilder {
        // /bin/sh -lc is a LOGIN shell: Alpine's /etc/profile resets PATH to
        // its default and drops /system/bin, which made `am`/`pm`/`settings`
        // unresolvable ("sh: am: not found"). Prepend an explicit PATH export
        // AFTER profile sourcing so the Android toolbox always stays on PATH.
        val pathGuard = "export PATH=\"/system/bin:/system/xbin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin:\$PATH\"; "
        val prootCommand = listOf(
            AlpineHostLinker,
            prootFile.absolutePath,
            "-0",
            "-r",
            rootfsDir.absolutePath,
            "-b",
            "${workspaceDir.absolutePath}:/workspace",
            "-b",
            "/dev",
            "-b",
            "/proc",
            "-b",
            "/sys",
            "-b",
            "/system",
        ) + phoneStorageBinds() + listOf(
            "-w",
            workingDirectory,
            "/bin/sh",
            "-lc",
            pathGuard + command,
        )
        return ProcessBuilder(prootCommand).apply {
            configureAlpineProcessEnvironment()
        }
    }

    private fun buildAlpineInteractiveProcess(): ProcessBuilder {
        val prootCommand = buildAlpineInteractiveCommand()
        return ProcessBuilder(prootCommand).apply {
            configureAlpineProcessEnvironment()
            environment()["PS1"] = "arix-alpine:\\w# "
            environment()["TERM"] = "xterm-256color"
        }
    }

    private fun buildAlpineInteractiveCommand(): List<String> =
        listOf(
            AlpineHostLinker,
            prootFile.absolutePath,
            "-0",
            "-r",
            rootfsDir.absolutePath,
            "-b",
            "${workspaceDir.absolutePath}:/workspace",
            "-b",
            "/dev",
            "-b",
            "/proc",
            "-b",
            "/sys",
            "-b",
            "/system",
        ) + phoneStorageBinds() + listOf(
            "-w",
            homeDirectory,
            "/bin/sh",
            "-i",
        )

    /**
     * v2.4.1: real phone storage binds. Arix targets API 28 (legacy external
     * storage), so once READ/WRITE_EXTERNAL_STORAGE is granted — or All-files
     * access is toggled on Android 11+ — the app uid has direct file-path
     * access to /storage/emulated/0. proot runs as that same uid, so binding
     * the directory exposes the phone's real storage inside the VM as
     * /sdcard (the familiar path) AND /storage/emulated/0 (the canonical
     * Android path). Binds are unconditional: access follows the granted
     * permission state, and re-granting needs no code change — only a new
     * shell session.
     */
    private fun phoneStorageBinds(): List<String> {
        val binds = mutableListOf<String>()
        runCatching {
            val externalRoot = android.os.Environment.getExternalStorageDirectory().canonicalFile
            if (externalRoot.isDirectory) {
                binds += "-b"
                binds += "${externalRoot.path}:/sdcard"
                binds += "-b"
                binds += "${externalRoot.path}:/storage/emulated/0"
            }
        }
        return binds
    }

    private fun ProcessBuilder.configureAlpineProcessEnvironment() {
        directory(runtimeRoot)
        environment().putAll(buildAlpineProcessEnvironment())
    }

    private fun buildAlpineProcessEnvironment(): Map<String, String> =
        buildMap {
            put("HOME", homeDirectory)
            put("PATH", "/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin:/system/bin")
            put("ARIX_RUNTIME", "alpine")
            put("ARIX_HOST_WORKSPACE", workspaceDir.absolutePath)
            put("PROOT_ROOTFS", rootfsDir.absolutePath)
            put("PROOT_BIN", prootFile.absolutePath)
            put("PROOT_LOADER", loaderFile.absolutePath)
            put("PROOT_TMP_DIR", hostTmpDir.absolutePath)
            put("LD_LIBRARY_PATH", hostLibDir.absolutePath)
            // v2.4.3: the phone's own LAN address so the arix-adb helper can
            // reach the local adbd over wireless debugging (loopback works for
            // the device itself; the LAN IP covers adb-from-another-interface
            // cases). Readable, no extra permission needed.
            deviceLanIpAddress()?.let { put("ARIX_DEVICE_IP", it) }
            // Android system tools (am / pm / settings / dumpsys) expect these.
            // BOOTCLASSPATH is intentionally inherited from the app process —
            // the Android runtime sets the correct framework classpath.
            put("ANDROID_ROOT", "/system")
            put("ANDROID_DATA", "/data")
            put("ANDROID_STORAGE", "/storage")
            put("PS1", "arix-alpine:\\w# ")
            put("TERM", "xterm-256color")
            put("COLORTERM", "truecolor")
        }.toMutableMap().also { environment ->
        environmentVariables.forEach { variable ->
            environment[variable.name] = variable.value
        }
    }

    /**
     * v2.4.3: best-effort look-up of the phone's own IPv4 address (Wi-Fi or
     * any other non-loopback, up interface). Used by the arix-adb helper as
     * the default ADB target host. Purely informational — adb still works
     * over 127.0.0.1 when the device's adbd listens on loopback.
     */
    private fun deviceLanIpAddress(): String? = runCatching {
        java.net.NetworkInterface.getNetworkInterfaces().asSequence()
            .filter { it.isUp && !it.isLoopback }
            .flatMap { it.inetAddresses.asSequence() }
            .firstOrNull { address ->
                !address.isLoopbackAddress &&
                    address is java.net.Inet4Address &&
                    !address.isLinkLocalAddress
            }
            ?.hostAddress
    }.getOrNull()

    /**
     * v2.4.3: writes the `arix-adb` helper into the guest (/usr/local/bin) so
     * the Alpine terminal can drive THIS phone with Android shell commands:
     * start the in-Alpine adb server, pair with Wireless debugging, connect to
     * the local device, then `arix-adb shell ...` / `adb ...` as usual.
     * Idempotent: rewrites only when missing or when the embedded version
     * changes.
     */
    private fun ensureAdbHelperScript() {
        runCatching {
            val target = guestPathToHostFile("/usr/local/bin/arix-adb")
            val currentMarker = AdbHelperMarker
            val existing = if (target.isFile) target.readTextSafe() else ""
            if (existing.contains(currentMarker)) return
            target.parentFile?.mkdirs()
            target.writeText(AdbHelperScript)
            target.setReadable(true, false)
            target.setWritable(true, true)
            target.setExecutable(true, false)
        }
    }

    private fun hasBundledRuntimeAssets(): Boolean =
        assetExists("$AlpineAssetRoot/proot.bin") &&
            assetExists("$AlpineAssetRoot/loader.bin") &&
            assetExists("$AlpineAssetRoot/libtalloc.so.2") &&
            AlpineRootfsAssetCandidates.any { assetExists(it.path) }

    private fun assetExists(path: String): Boolean =
        runCatching {
            appContext.assets.open(path).use { true }
        }.getOrDefault(false)

    private suspend fun installFromAssets(
        onProgress: (AlpineSetupProgress) -> Unit,
    ) {
        onProgress(AlpineSetupProgress(output = "Preparing Alpine runtime files...\n"))
        stagingRoot.apply {
            deleteRecursively()
            mkdirs()
        }
        val stagingBin = File(stagingRoot, "bin").apply { mkdirs() }
        val stagingLib = File(stagingRoot, "lib").apply { mkdirs() }
        val stagingLoader = File(stagingRoot, "libexec/proot").apply { mkdirs() }
        val stagingRootfs = File(stagingRoot, "rootfs").apply { mkdirs() }
        File(stagingRoot, "workspace").mkdirs()
        File(stagingRoot, "tmp").mkdirs()

        onProgress(AlpineSetupProgress(output = "Copying proot runtime...\n"))
        copyAsset("$AlpineAssetRoot/proot.bin", File(stagingBin, "proot"), executable = true)
        copyAsset("$AlpineAssetRoot/loader.bin", File(stagingLoader, "loader"), executable = true)
        copyAsset("$AlpineAssetRoot/libtalloc.so.2", File(stagingLib, "libtalloc.so.2"), executable = false)
        val rootfsAsset = AlpineRootfsAssetCandidates.firstOrNull { assetExists(it.path) }
            ?: error("Alpine rootfs asset is missing.")
        onProgress(
            AlpineSetupProgress(
                activity = AlpineSetupActivity.Extracting,
                output = "Extracting ${rootfsAsset.path}...\n",
            )
        )
        appContext.assets.open(rootfsAsset.path).use { stream ->
            if (rootfsAsset.compressed) {
                extractTarGz(stream, stagingRootfs, onProgress)
            } else {
                extractTar(stream, stagingRootfs, onProgress)
            }
        }
        File(stagingRoot, ".installed-version").writeText("alpine-3.23.4-aarch64\n")

        runtimeRoot.deleteRecursively()
        if (!stagingRoot.renameTo(runtimeRoot)) {
            copyDirectory(stagingRoot, runtimeRoot)
            stagingRoot.deleteRecursively()
        }
        ensureWorkspace()
        ensureGuestNetworkConfig()
        installPreinstalledExtensionsSync()
        refreshApkRepositoriesForCurrentNetwork(onProgress)
        onProgress(AlpineSetupProgress(output = "Alpine runtime files are ready.\n"))
    }

    suspend fun refreshApkRepositoriesForCurrentNetwork(
        onProgress: (AlpineSetupProgress) -> Unit = {},
    ) = withContext(Dispatchers.IO) {
        apkRepositoryMutex.lock()
        try {
            val environment = startupNetworkEnvironment ?: detectNetworkEnvironment().also {
                startupNetworkEnvironment = it
            }
            configureApkRepositories(environment, onProgress)
        } finally {
            apkRepositoryMutex.unlock()
        }
    }

    private fun detectNetworkEnvironment(): ApkNetworkEnvironment {
        val countryCode = runCatching {
            val connection = URL(AlpineNetworkTraceUrl).openConnection() as HttpURLConnection
            try {
                connection.requestMethod = "GET"
                connection.connectTimeout = AlpineNetworkDetectionTimeoutMillis
                connection.readTimeout = AlpineNetworkDetectionTimeoutMillis
                connection.setRequestProperty("Accept", "text/plain")
                connection.setRequestProperty("User-Agent", "Arix-Alpine-Network-Check")
                if (connection.responseCode !in 200..299) return@runCatching null
                connection.inputStream.bufferedReader().use { parseCloudflareCountryCode(it.readText()) }
            } finally {
                connection.disconnect()
            }
        }.getOrNull()
        return when {
            countryCode == null -> ApkNetworkEnvironment.Unknown
            countryCode.equals("CN", ignoreCase = true) -> ApkNetworkEnvironment.China
            else -> ApkNetworkEnvironment.International
        }
    }

    private fun configureApkRepositories(
        environment: ApkNetworkEnvironment,
        onProgress: (AlpineSetupProgress) -> Unit,
    ) {
        val repositories = File(rootfsDir, "etc/apk/repositories")
        if (!repositories.isFile) return
        val original = runCatching { repositories.readText() }.getOrNull() ?: return
        val updated = apkRepositories(original, environment)
        if (updated != original) {
            runCatching { repositories.writeText(updated) }.getOrNull() ?: return
            onProgress(
                AlpineSetupProgress(
                    output = when (environment) {
                        ApkNetworkEnvironment.China ->
                            "Using the Tsinghua Alpine mirror with the official CDN as fallback.\n"
                        ApkNetworkEnvironment.International ->
                            "Using the official Alpine CDN for the current network.\n"
                        ApkNetworkEnvironment.Unknown ->
                            "Network region detection failed; using official and China Alpine sources.\n"
                    },
                )
            )
        }
    }

    private fun copyAsset(
        assetPath: String,
        target: File,
        executable: Boolean,
    ) {
        target.parentFile?.mkdirs()
        appContext.assets.open(assetPath).use { input ->
            target.outputStream().use { output -> input.copyTo(output) }
        }
        target.setReadable(true, true)
        target.setWritable(true, true)
        if (executable) target.setExecutable(true, true)
    }

    private fun guestPathToHostFile(guestPath: String): File {
        val normalized = normalizePath(guestPath.trim())
        // v2.4.1: /sdcard and /storage/emulated/0 guest paths map onto the
        // phone's real shared storage (mirroring the proot bind mounts) so
        // the in-app file manager and filesystem tools can browse real
        // files once storage access is granted.
        PhoneStorageGuestRoots.forEach { guestRoot ->
            if (normalized == guestRoot || normalized.startsWith("$guestRoot/")) {
                val externalRoot = runCatching {
                    android.os.Environment.getExternalStorageDirectory().canonicalFile
                }.getOrNull() ?: File("/storage/emulated/0")
                val relative = normalized.removePrefix(guestRoot).trimStart('/')
                val target = if (relative.isBlank()) {
                    externalRoot
                } else {
                    File(externalRoot, relative).canonicalFile
                }
                require(
                    target.path == externalRoot.path ||
                        target.path.startsWith(externalRoot.path + File.separator)
                ) {
                    "Refusing to write outside phone storage: $guestPath"
                }
                return target
            }
        }
        // v2.4.2: /workspace is a proot BIND MOUNT onto workspaceDir (a
        // sibling of the rootfs, see buildAlpineProcessArguments), NOT a
        // directory inside the rootfs. Mapping it into rootfsDir made the
        // in-app file manager show /workspace as empty: files written by
        // the terminal/agent landed in workspaceDir while the manager
        // listed the shadowed rootfsDir/workspace directory. Resolve
        // /workspace guest paths onto the real bind source so the manager,
        // filesystem tools, and the terminal all see the same files.
        if (normalized == workspaceRoot || normalized.startsWith("$workspaceRoot/")) {
            ensureWorkspace()
            val canonicalWorkspace = workspaceDir.canonicalFile
            val relative = normalized.removePrefix(workspaceRoot).trimStart('/')
            val target = if (relative.isBlank()) {
                canonicalWorkspace
            } else {
                File(canonicalWorkspace, relative).canonicalFile
            }
            require(
                target.path == canonicalWorkspace.path ||
                    target.path.startsWith(canonicalWorkspace.path + File.separator)
            ) {
                "Refusing to write outside the Alpine workspace: $guestPath"
            }
            return target
        }
        val relativePath = normalized.trimStart('/')
        val target = if (relativePath.isBlank()) rootfsDir.canonicalFile else File(rootfsDir, relativePath).canonicalFile
        val canonicalRoot = rootfsDir.canonicalFile
        require(target.path == canonicalRoot.path || target.path.startsWith(canonicalRoot.path + File.separator)) {
            "Refusing to write outside Alpine rootfs: $guestPath"
        }
        return target
    }

    private fun extractTarGz(
        stream: InputStream,
        targetDirectory: File,
        onProgress: (AlpineSetupProgress) -> Unit,
    ) {
        GZIPInputStream(stream).use { gzip -> extractTar(gzip, targetDirectory, onProgress) }
    }

    private fun extractTar(
        stream: InputStream,
        targetDirectory: File,
        onProgress: (AlpineSetupProgress) -> Unit,
    ) {
        val progressReporter = ExtractionProgressReporter(onProgress)
        stream.use { tar ->
            val header = ByteArray(512)
            while (true) {
                val read = tar.readFullyOrEnd(header)
                if (read == 0) break
                if (read < 512) error("Invalid Alpine rootfs tar header.")
                if (header.all { it.toInt() == 0 }) break

                val name = header.tarString(0, 100)
                val prefix = header.tarString(345, 155)
                val path = listOf(prefix, name)
                    .filter(String::isNotBlank)
                    .joinToString("/")
                    .trimStart('/')
                val size = header.tarOctal(124, 12)
                val mode = header.tarOctal(100, 8).toInt()
                val type = header[156].toInt().toChar()
                val linkName = header.tarString(157, 100)
                val target = File(targetDirectory, path).canonicalFile
                val canonicalRoot = targetDirectory.canonicalFile
                if (!target.path.startsWith(canonicalRoot.path)) {
                    error("Refusing to extract path outside Alpine rootfs: $path")
                }

                when (type) {
                    '0', '\u0000' -> {
                        progressReporter.onEntry(path)
                        target.parentFile?.mkdirs()
                        target.outputStream().use { output ->
                            tar.copyExactlyTo(output, size, progressReporter::onBytes)
                        }
                        target.applyTarMode(mode)
                    }
                    '5' -> {
                        target.mkdirs()
                        target.applyTarMode(mode)
                    }
                    '2' -> {
                        target.parentFile?.mkdirs()
                        runCatching {
                            java.nio.file.Files.deleteIfExists(target.toPath())
                            java.nio.file.Files.createSymbolicLink(
                                target.toPath(),
                                java.nio.file.Paths.get(linkName),
                            )
                        }.onFailure {
                            File(target.parentFile, target.name).writeText(linkName)
                        }
                    }
                    else -> {
                        tar.skipExactly(size)
                    }
                }
                tar.skipPadding(size)
            }
        }
        progressReporter.finish()
    }

    private fun InputStream.readFullyOrEnd(buffer: ByteArray): Int {
        var offset = 0
        while (offset < buffer.size) {
            val read = read(buffer, offset, buffer.size - offset)
            if (read == -1) return offset
            offset += read
        }
        return offset
    }

    private fun InputStream.copyExactlyTo(
        output: java.io.OutputStream,
        byteCount: Long,
        onBytesCopied: (Int) -> Unit = {},
    ) {
        val buffer = ByteArray(DEFAULT_BUFFER_SIZE)
        var remaining = byteCount
        while (remaining > 0) {
            val read = read(buffer, 0, minOf(buffer.size.toLong(), remaining).toInt())
            if (read == -1) error("Unexpected end of Alpine rootfs tar entry.")
            output.write(buffer, 0, read)
            onBytesCopied(read)
            remaining -= read
        }
    }

    private fun InputStream.skipExactly(byteCount: Long) {
        var remaining = byteCount
        while (remaining > 0) {
            val skipped = skip(remaining)
            if (skipped <= 0) {
                if (read() == -1) error("Unexpected end of Alpine rootfs tar entry.")
                remaining--
            } else {
                remaining -= skipped
            }
        }
    }

    private fun InputStream.skipPadding(size: Long) {
        val padding = (512 - (size % 512)) % 512
        if (padding > 0) skipExactly(padding)
    }

    private fun ByteArray.tarString(
        offset: Int,
        length: Int,
    ): String {
        val end = (offset until offset + length)
            .firstOrNull { this[it].toInt() == 0 }
            ?: (offset + length)
        return copyOfRange(offset, end).toString(Charsets.UTF_8).trim()
    }

    private fun ByteArray.tarOctal(
        offset: Int,
        length: Int,
    ): Long =
        tarString(offset, length).trim().ifBlank { "0" }.toLong(8)

    private fun File.applyTarMode(mode: Int) {
        setReadable(true, mode and 0b100_000_000 == 0)
        setWritable(true, mode and 0b010_000_000 == 0)
        if (mode and 0b001_000_000 != 0) setExecutable(true, false)
    }

    private fun copyDirectory(
        source: File,
        target: File,
    ) {
        if (source.isDirectory) {
            target.mkdirs()
            source.listFiles().orEmpty().forEach { child ->
                copyDirectory(child, File(target, child.name))
            }
        } else {
            target.parentFile?.mkdirs()
            source.copyTo(target, overwrite = true)
        }
    }

    private fun copyDirectoryWithoutSymbolicLinks(
        source: File,
        target: File,
    ) {
        if (Files.isSymbolicLink(source.toPath())) return
        if (source.isDirectory) {
            require(target.mkdirs() || target.isDirectory) {
                "Unable to create Alpine mirror directory: ${target.path}"
            }
            source.listFiles().orEmpty().forEach { child ->
                copyDirectoryWithoutSymbolicLinks(child, File(target, child.name))
            }
        } else if (source.isFile) {
            target.parentFile?.mkdirs()
            source.copyTo(target, overwrite = true)
        }
    }

    private fun isSupportedAbi(): Boolean =
        Build.SUPPORTED_ABIS.any { it == "arm64-v8a" }

    private fun unsupportedAbiState(): LocalRuntimeSetupState =
        LocalRuntimeSetupState(
            runtimeId = id,
            issue = LocalRuntimeIssue.UnsupportedAbi,
            detail = "Alpine runtime currently supports arm64-v8a devices only. Device ABIs: ${Build.SUPPORTED_ABIS.joinToString()}",
        )

    private fun ensureWorkspace() {
        runtimeRoot.mkdirs()
        workspaceDir.mkdirs()
        hostTmpDir.mkdirs()
    }

    private fun ensureGuestNetworkConfig() {
        val resolvConf = File(rootfsDir, "etc/resolv.conf")
        if (!resolvConf.isFile || resolvConf.length() == 0L) {
            resolvConf.parentFile?.mkdirs()
            resolvConf.writeText(
                """
                nameserver 1.1.1.1
                nameserver 8.8.8.8
                options timeout:2 attempts:2
                """.trimIndent() + "\n"
            )
            resolvConf.setReadable(true, false)
            resolvConf.setWritable(true, true)
        }
        val apkWorld = File(rootfsDir, "lib/apk/db/world")
        if (!apkWorld.exists()) {
            apkWorld.parentFile?.mkdirs()
            apkWorld.writeText("")
            apkWorld.setReadable(true, false)
            apkWorld.setWritable(true, true)
        }
    }

    private suspend fun verifyPackageProfile(profileId: String): Boolean {
        val command = when (profileId) {
            "python" -> "python3 --version && pip3 --version && virtualenv --version"
            "node" -> "node --version && npm --version"
            "git_search" -> "git --version && rg --version && fd --version"
            "ssh" -> "ssh -V"
            "adb" -> "adb --version && fastboot --version"
            "chrome" ->
                "(chromium-browser --version || chromium --version) && " +
                    "command -v Xvnc && command -v openbox && " +
                    "command -v xprop && command -v websockify && test -d /usr/share/novnc"
            else -> return false
        }
        val result = JSONObject(executeCommand(command, homeDirectory, 30_000L))
        return result.optBoolean("ok")
    }

    private fun nextRunId(): String =
        "run-${System.currentTimeMillis()}-${nextRunId.getAndIncrement()}-${UUID.randomUUID().toString().take(8)}"

    private fun snapshot(
        run: AlpineRun,
        tailBytes: Int,
    ): String {
        val process = run.process
        val running = process?.isAlive == true
        val exitCode = if (!running && process != null) process.exitValueSafe() else JSONObject.NULL
        val status = when {
            running -> "running"
            run.cancelled -> "cancelled"
            exitCode == 0 -> "completed"
            else -> "failed"
        }
        return JSONObject().apply {
            put("ok", status == "completed" || status == "running")
            put("runtime", id.storageValue)
            put("run_id", run.runId)
            put("command", run.command)
            put("working_directory", run.workingDirectory)
            put("status", status)
            put("running", running)
            put("completed", !running)
            put("stdout", run.stdoutFile.tailText(tailBytes))
            put("stderr", run.stderrFile.tailText(tailBytes))
            put("stdout_bytes", run.stdoutFile.lengthSafe())
            put("stderr_bytes", run.stderrFile.lengthSafe())
            put("exit_code", exitCode)
            put("err", -1)
            put("duration_ms", System.currentTimeMillis() - run.startedAtMillis)
            if (status == "failed") put("errmsg", "Alpine command failed.")
            if (status == "cancelled") put("errmsg", "Stopped by user.")
        }.toString()
    }

    private fun setupError(
        command: String,
        workingDirectory: String,
        setup: LocalRuntimeSetupState,
    ): String = JSONObject().apply {
        put("ok", false)
        put("runtime", id.storageValue)
        put("command", command)
        put("working_directory", workingDirectory)
        put("stdout", "")
        put("stderr", "")
        put("exit_code", -1)
        put("err", -1)
        put("errmsg", setup.detail.ifBlank { "Alpine runtime is not ready." })
        put("setup_issue", setup.issue.name)
    }.toString()

    private fun commandError(
        command: String,
        workingDirectory: String,
        runId: String = "",
        message: String,
    ): String = JSONObject().apply {
        put("ok", false)
        put("runtime", id.storageValue)
        if (runId.isNotBlank()) put("run_id", runId)
        put("command", command)
        put("working_directory", workingDirectory)
        put("stdout", "")
        put("stderr", "")
        put("exit_code", -1)
        put("err", -1)
        put("errmsg", message)
    }.toString()

    private fun invalidArguments(message: String): String =
        JSONObject().put("ok", false).put("errmsg", message).toString()

    private fun resolveTailBytes(arguments: JSONObject): Int =
        arguments.optInt("tail_bytes", arguments.optInt("tailBytes", AlpineDefaultTailBytes))
            .coerceIn(1, AlpineMaxTailBytes)

    private fun File.tailText(maxBytes: Int): String {
        if (!isFile) return ""
        val bytes = readBytes()
        val start = (bytes.size - maxBytes).coerceAtLeast(0)
        return String(bytes.copyOfRange(start, bytes.size), Charsets.UTF_8)
    }

    private fun File.readTextSafe(): String =
        runCatching { readText() }.getOrDefault("")

    private fun File.lengthSafe(): Long =
        runCatching { length() }.getOrDefault(0L)

    private fun File.existsNoFollow(): Boolean =
        Files.exists(toPath(), LinkOption.NOFOLLOW_LINKS)

    private fun Process.exitValueSafe(): Int =
        runCatching { exitValue() }.getOrDefault(-1)

    private data class AlpineRun(
        val runId: String,
        val command: String,
        val workingDirectory: String,
        val startedAtMillis: Long,
        val stdoutFile: File,
        val stderrFile: File,
        @Volatile var process: Process? = null,
        @Volatile var cancelled: Boolean = false,
    )

    private object AlpineRunReaper {
        fun watch(
            run: AlpineRun,
            runs: ConcurrentHashMap<String, AlpineRun>,
        ) {
            Thread(
                {
                    runCatching { run.process?.waitFor() }
                    Thread.sleep(5 * 60 * 1000L)
                    if (run.process?.isAlive != true) {
                        runs.remove(run.runId, run)
                    }
                },
                "arix-alpine-run-${run.runId}",
            ).apply {
                isDaemon = true
                start()
            }
        }
    }

    companion object {
        val AlpinePackageProfiles: Map<String, List<String>> = mapOf(
            "python" to listOf("python3", "py3-pip", "py3-virtualenv"),
            "node" to listOf("nodejs", "npm"),
            "git_search" to listOf("git", "ripgrep", "fd"),
            "ssh" to listOf("openssh-client"),
            "adb" to listOf("android-tools"),
            "chrome" to listOf(
                "chromium",
                "font-noto",
                "font-noto-cjk",
                "openbox",
                "tigervnc",
                "xprop",
                "novnc",
                "websockify",
            ),
        )
    }

    /**
     * v2.4.3: the in-guest `arix-adb` helper. A regular val (not const) so
     * shell dollars can be emitted with the `${'$'}` idiom.
     */
    private val AdbHelperMarker = "arix-adb-helper v2.4.3"

    private val AdbHelperScript = """#!/bin/sh
# $AdbHelperMarker
# Arix ADB helper - control THIS phone from the Alpine terminal.
# Requires the "ADB tools" preset (Settings -> Alpine -> ADB tools),
# which installs the Alpine `android-tools` package (adb + fastboot).
#
# First-time setup (Android 11+ wireless debugging):
#   1. Phone Settings -> System -> Developer options -> Wireless debugging -> ON
#   2. Open "Pair device with pairing code" and note IP:PORT + 6-digit code
#   3. In this terminal:  arix-adb pair 127.0.0.1:PORT CODE
#   4. Then:              arix-adb connect 127.0.0.1:PORT
#      (wireless debugging shows a connect port on its main screen - use that)
#   5. Now everything works:  arix-adb shell, arix-adb devices, adb install ...
#
# Older devices with `adb tcpip 5555` enabled:  arix-adb connect  (defaults to 5555)

set -u

ADB_TARGET_FILE="${'$'}{HOME:-/root}/.arix/adb-target"

say() { printf '%s\n' "${'$'}*"; }

need_adb() {
    if ! command -v adb >/dev/null 2>&1; then
        say "adb is not installed in Alpine yet."
        say "Install it from Arix: Settings -> Alpine -> ADB tools."
        exit 1
    fi
}

saved_target() {
    if [ -f "${'$'}ADB_TARGET_FILE" ]; then
        cat "${'$'}ADB_TARGET_FILE" 2>/dev/null
    else
        echo "${'$'}{ARIX_DEVICE_IP:-127.0.0.1}:5555"
    fi
}

case "${'$'}{1:-}" in
    "")
        # Default: make sure the local device is connected, then drop into
        # an interactive Android shell on THIS phone.
        need_adb
        adb start-server >/dev/null 2>&1
        TARGET="${'$'}(saved_target)"
        if ! adb devices | grep -q 'device${'$'}'; then
            adb connect "${'$'}TARGET" >/dev/null 2>&1
        fi
        exec adb shell
        ;;
    pair)
        need_adb
        shift
        exec adb pair "${'$'}@"
        ;;
    connect)
        need_adb
        shift
        TARGET="${'$'}{1:-${'$'}(saved_target)}"
        case "${'$'}TARGET" in
            *:*) ;;
            *) TARGET="${'$'}{ARIX_DEVICE_IP:-127.0.0.1}:${'$'}TARGET" ;;
        esac
        mkdir -p "${'$'}(dirname "${'$'}ADB_TARGET_FILE")" 2>/dev/null
        echo "${'$'}TARGET" > "${'$'}ADB_TARGET_FILE" 2>/dev/null
        adb start-server >/dev/null 2>&1
        exec adb connect "${'$'}TARGET"
        ;;
    disconnect)
        need_adb
        shift
        TARGET="${'$'}{1:-${'$'}(saved_target)}"
        exec adb disconnect "${'$'}TARGET"
        ;;
    target)
        say "Saved ADB target: ${'$'}(saved_target)"
        say "Override with: arix-adb connect HOST:PORT"
        ;;
    discover|mdns)
        need_adb
        adb start-server >/dev/null 2>&1
        exec adb mdns services
        ;;
    help|-h|--help)
        say "arix-adb - talk to THIS phone over ADB from Alpine"
        say ""
        say "Usage:"
        say "  arix-adb                      connect to this phone + open a shell"
        say "  arix-adb connect [HOST:]PORT  connect (default: ${'$'}(saved_target))"
        say "  arix-adb pair HOST:PORT CODE  pair with Wireless debugging"
        say "  arix-adb disconnect [TARGET]  drop the connection"
        say "  arix-adb discover             list ADB services via mDNS"
        say "  arix-adb <adb args...>        run any raw adb command"
        say ""
        say "Tip: pair once from Developer options -> Wireless debugging,"
        say "then arix-adb connect saves the target for future shells."
        say "Device LAN IP: ${'$'}{ARIX_DEVICE_IP:-unknown} (loopback 127.0.0.1 usually works)"
        ;;
    *)
        need_adb
        exec adb "${'$'}@"
        ;;
esac
"""

    private class ExtractionProgressReporter(
        private val onProgress: (AlpineSetupProgress) -> Unit,
    ) {
        private var totalBytes = 0L
        private var sampledBytes = 0L
        private var sampledAtMillis = System.currentTimeMillis()
        private var lastEntryAtMillis = 0L

        fun onEntry(path: String) {
            val now = System.currentTimeMillis()
            if (lastEntryAtMillis == 0L || now - lastEntryAtMillis >= 120L) {
                lastEntryAtMillis = now
                onProgress(
                    AlpineSetupProgress(
                        activity = AlpineSetupActivity.Extracting,
                        output = "Extracting $path\n",
                    )
                )
            }
        }

        fun onBytes(byteCount: Int) {
            totalBytes += byteCount
            val now = System.currentTimeMillis()
            val elapsed = now - sampledAtMillis
            if (elapsed < 400L) return
            val bytesPerSecond = ((totalBytes - sampledBytes) * 1_000L / elapsed).coerceAtLeast(0L)
            sampledBytes = totalBytes
            sampledAtMillis = now
            onProgress(
                AlpineSetupProgress(
                    activity = AlpineSetupActivity.Extracting,
                    bytesPerSecond = bytesPerSecond,
                )
            )
        }

        fun finish() {
            val megabytes = totalBytes / (1024L * 1024L)
            onProgress(
                AlpineSetupProgress(
                    activity = AlpineSetupActivity.Extracting,
                    output = "Finished extracting the Alpine root filesystem ($megabytes MB).\n",
                )
            )
        }
    }

    private class NetworkRateSampler(
        private val onRate: (Long) -> Unit,
    ) {
        @Volatile
        private var running = false
        private var thread: Thread? = null

        fun start() {
            val initialBytes = TrafficStats.getUidRxBytes(android.os.Process.myUid())
            if (initialBytes == TrafficStats.UNSUPPORTED.toLong()) return
            running = true
            thread = Thread(
                {
                    var previousBytes = initialBytes
                    var previousAtMillis = System.currentTimeMillis()
                    runCatching {
                        while (running) {
                            Thread.sleep(AlpineNetworkRateWindowMillis)
                            val now = System.currentTimeMillis()
                            val currentBytes = TrafficStats.getUidRxBytes(android.os.Process.myUid())
                            val elapsed = now - previousAtMillis
                            if (currentBytes >= previousBytes && elapsed > 0L) {
                                onRate((currentBytes - previousBytes) * 1_000L / elapsed)
                            }
                            previousBytes = currentBytes
                            previousAtMillis = now
                        }
                    }
                },
                "arix-alpine-download-rate",
            ).apply {
                isDaemon = true
                start()
            }
        }

        fun stop() {
            running = false
            thread?.interrupt()
            thread = null
        }
    }
}

private data class RootfsAsset(
    val path: String,
    val compressed: Boolean,
)

data class AlpineTerminalLaunchSpec(
    val executable: String,
    val arguments: Array<String>,
    val environment: Array<String>,
    val workingDirectory: String,
)

enum class AlpineSetupActivity {
    None,
    Extracting,
    Downloading,
    Installing,
}

data class AlpineSetupProgress(
    val activity: AlpineSetupActivity = AlpineSetupActivity.None,
    val bytesPerSecond: Long = 0L,
    val progressPercent: Int? = null,
    val output: String = "",
)

internal class AlpinePackageInstallProgressTracker {
    private val outputTail = StringBuilder()
    private var activity = AlpineSetupActivity.Downloading
    private var bytesPerSecond = 0L
    private var progressPercent: Int? = null

    @Synchronized
    fun onOutput(output: String): AlpineSetupProgress {
        outputTail.append(output)
        if (outputTail.length > MaxTrackedOutputChars) {
            outputTail.delete(0, outputTail.length - MaxTrackedOutputChars)
        }
        ApkInstallProgressRegex.findAll(outputTail).lastOrNull()?.let { match ->
            val completed = match.groupValues[1].toIntOrNull() ?: 0
            val total = match.groupValues[2].toIntOrNull() ?: 0
            activity = AlpineSetupActivity.Installing
            progressPercent = if (total > 0) {
                (completed * 100 / total).coerceIn(0, 100)
            } else {
                null
            }
        }
        return snapshot(output)
    }

    @Synchronized
    fun onRate(rate: Long): AlpineSetupProgress {
        bytesPerSecond = rate.coerceAtLeast(0L)
        return snapshot()
    }

    private fun snapshot(output: String = ""): AlpineSetupProgress =
        AlpineSetupProgress(
            activity = activity,
            bytesPerSecond = bytesPerSecond,
            progressPercent = progressPercent,
            output = output,
        )

    private companion object {
        const val MaxTrackedOutputChars = 8_192
        val ApkInstallProgressRegex = Regex(
            """\((\d+)/(\d+)\)\s+(?:Installing|Upgrading|Downgrading|Replacing)\b""",
            RegexOption.IGNORE_CASE,
        )
    }
}

internal data class AlpineWorkspaceHostPath(
    val guestPath: String,
    val hostFile: File,
)
