# Arix — Build & Signing Notes

This project is **Arix**, a rebrand of [Aether](https://github.com/Zhou-Shilin/Aether) (GPL-3.0).
All changes below were applied on top of upstream `c1c446e` (Aether 2.1.5).
It is an **Android-only** fork: all iOS targets, sources, scripts and the
iOS runtime submodule have been removed.

## Identity

| Item | Value |
| --- | --- |
| App name | Arix |
| Application ID (package) | `com.arix.app` |
| Namespace (app module) | `com.arix.app` |
| Namespace (shared module) | `com.arix.app.shared` |
| Root project name | `Arix` |
| Version | 2.2.1 (versionCode 13) |
| Developer | Anupam |
| Website | https://webxanupam.blogspot.com |

## Changes applied to upstream

1. **Rebrand (complete)**: project name, package/namespace (`com.zhousl.aether` /
   `com.baimoqilin.aether` → `com.arix.app`), app label, user-visible strings,
   system prompts, HTTP user agent. A second, exhaustive pass renamed every
   remaining `Aether`/`aether` identifier (classes like `ArixViewModel`,
   internal keys, Termux workspace paths `~/.arix`, the JS bridge module,
   extension script API `arix.*`, compose resources, CI, docs, issue
   templates). Zero `Aether` strings remain inside the APK.
2. **English only**: removed Simplified Chinese and Persian locales
   (`values-zh-rCN`, `values-fa`, Vazirmatn fonts, RTL layout logic,
   non-English `AppLanguage` entries). `resourceConfigurations += "en"`
   strips locale resources from every dependency as well.
3. **Language option removed**: the Settings → General language picker is gone
   (English is the only interface language). The theme picker remains.
4. **About page**: author is **Anupam**, website links to
   https://webxanupam.blogspot.com, the upstream GitHub row was removed, and
   the privacy policy points to the project website.
5. **GitHub update system removed**: deleted `AppUpdateManager` (+ test), the
   in-app update checker / "Check GitHub Releases" settings row / update
   dialog / APK download+install flow, the nightly build type & CI workflow,
   the `UPDATE_CHANNEL` build config field, the `REQUEST_INSTALL_PACKAGES`
   permission, and the unused App-Store lookup service in `shared`.
6. **iOS fully removed**: `iosApp/`, `shared/src/iosMain`, `shared/src/iosTest`,
   the `third_party/ish-arm64` submodule (+ `.gitmodules`), iOS build scripts,
   `iosArm64`/`iosSimulatorArm64` targets, `ktor-client-darwin`, the iOS CI
   job. The `shared` module now targets Android only.
7. **Assistant mode (new)** — Gemini-style quick assistant:
   - `AssistantActivity`: a translucent bottom panel summoned from anywhere.
     Collapsed it shows a capsule pill ("Ask Arix"); tapping expands it into
     a compact chat with the current session, streaming responses, and an
     "Open in Arix" button. It shares the runtime, session engine and
     persisted chat state with the main app, so conversations continue
     seamlessly.
   - **Default assistant**: Settings → Assistant → "Set as default assistant"
     uses `RoleManager.ROLE_ASSISTANT` (Android 10+). When Arix is the default
     assistant, the system corner-swipe / assistant gesture summons the panel.
   - **Quick settings tile** (`ArixTileService`): add "Arix Assistant" from the
     QS panel edit mode; tapping summons the panel from anywhere.
   - **Floating pill** (`ArixOverlayPillService`): a draggable overlay pill
     (SYSTEM_ALERT_WINDOW) that snaps to screen edges. Tap to summon,
     long-press to hide. Toggled in Settings → Assistant.
   - **Overlay permission**: Settings → Assistant → "Display over other apps"
     opens the system overlay-permission screen (also required on MIUI for
     reliable background summoning).
   - **Text selection & share**: selecting text anywhere offers "Arix" in the
     selection menu (ACTION_PROCESS_TEXT); sharing plain text to Arix opens
     the panel pre-filled.
8. **Release signing** (replaces the removed nightly signing):
   `signingConfigs.release` reads `keystore.properties` in the project root.
9. **Size optimizations** (no features removed): R8 minify + resource shrinking
   (inherited from upstream), English-only resource filtering, dependency-info
   blob stripped from the APK, `-repackageclasses ''` +
   `-allowaccessmodification`, release lint gate disabled
   (`checkReleaseBuilds = false`), arm64-v8a only.
10. **v2.1.7 — crash fix + data carry-over**:
    - **Fixed the instant crash on open** introduced in v2.1.6: the new
      mod-service bookkeeping list in `ArixViewModel` was declared *after* the
      `init {}` block that uses it. Kotlin initializes properties in
      declaration order, so the list was still `null` when
      `registerCoreModServices()` appended to it, throwing an
      `NullPointerException` inside the ViewModel constructor for *every*
      launch of MainActivity or AssistantActivity. The list is now declared
      before `init`, and `onCleared` unregisters defensively.
    - **User data survives the v2.1.5 → v2.1.7 update**: v2.1.6's blanket
      rename had also renamed every persisted store file
      (`aether_chat_history.db`, `aether_settings`, `aether_chats`,
      `aether_agent_extensions`, `aether_scheduled_tasks`,
      `aether_pi_extension_state`, `aether_discovered_skills`,
      `aether_native_mods` → `arix_*`), which silently reset settings,
      provider keys and chat history. `LegacyAetherStoreMigrator` now runs
      once at app startup and copies the old files over the new names before
      any store is opened.
    - **Room schema v8** (`Migration7To8`): renames the legacy
      `chat_agent_messageId` column to `arixMessageId` by recreating
      `chat_agent_message_refs` (safe on minSdk 26, whose SQLite lacks
      `ALTER TABLE RENAME COLUMN`). The migration detects which of the two
      historical v7 shapes the database uses, so both v2.1.5 databases and
      databases created by the broken v2.1.6 upgrade cleanly. The historical
      `Migration5To6` SQL was restored to its original column names.
    - Verified with Robolectric startup smoke tests (Application, settings,
      chat state, MainActivity + AssistantActivity composition on a simulated
      API 30 device) plus a real-SQLite migration test: 353 unit tests, 0
      failures.

## v2.2.1 — IST time-based home greeting

1. **New greeting header on the home (new-chat) screen**, computed from Indian
   Standard Time (`Asia/Kolkata`) regardless of device timezone:
   - `4:00–5:59` → "Good early morning, Sir"; `6:00–11:59` → "Good morning,
     Sir"; `12:00–16:59` → "Good afternoon, Sir"; `17:00–19:59` → "Good
     evening, Sir"; `20:00–23:59` and `0:00–3:59` → "Good night, Sir".
   - Below the greeting a live clock line shows the current IST date/time
     ("Mon, 29 Aug · 9:41 AM IST") with a schedule icon, refreshed every
     20 seconds.
2. **Onboarding-style typewriter animation**: the greeting reveals word by
   word using the same reveal-unit engine as the onboarding
   `StreamingStepMessage` (word/word+space units, 96–240 ms per unit, 180 ms
   on punctuation, instant when Reduce Motion is on). The animation keys on
   the greeting phrase only, so the ticking clock never restarts it.
3. **Hides when chatting starts**: the greeting block fades out when the
   composer is focused, and the whole empty state (greeting + clock + welcome
   line) disappears as soon as the conversation has messages — the message
   list replaces it.
4. Implementation: `IstGreetingHeader` / `GreetingRevealText` /
   `rememberIstNow` in app `ConversationUi.kt`, rendered from the live
   `ConversationScreen` empty branch (below the chat-empty extension slot);
   five new `greeting_*` strings in shared resources. Note: the upstream
   `ConversationEmptyState` (ConversationUi.kt) and `EmptyChatState`
   (ArixApp.kt, preview-only) composables are unreachable dead code that R8
   strips — the greeting intentionally attaches to the code path that
   actually renders.

## v2.2.0 — Dark-only theme + Movie Explorer & QR Code Generator

1. **Theme picker removed; the app is permanently dark themed**:
   - The Settings → General page (which contained only the theme selector)
     was removed from the settings hub, along with `GeneralSettingsPageV2`,
     the `SettingsPage.General` route, and the `onUpdateThemeMode` /
     `updateAppThemeMode` / `updateThemeMode` plumbing.
   - `AppThemeMode.fromStorage()` now always resolves to `Dark` (existing
     installs that stored `system`/`light` switch over automatically), the
     `AppSettings` default is `Dark`, and `ArixTheme` forces the dark
     palette regardless of the passed mode.
2. **New bundled extension: Movie Explorer** (`extensions/pi-movie-explorer`):
   - Agent tool `movie_explorer` with modes `latest` / `search` / `play`.
   - Latest movies and search via the source site homepage HTML and the
     WordPress JSON search API; playback resolves every embed server
     (Player 1..N) plus download links from the movie page, with the
     WordPress REST API (`/wp-json/wp/v2/posts?slug=…`) and public CORS
     proxies as automatic fallbacks. Note: the `_fields` query parameter
     triggers the site's Cloudflare — the extension never uses it.
   - Rich Arix cards: a poster grid (`movie-list`) where tapping Play opens
     the multi-server player instantly (no agent round-trip), and a
     `movie-player` card with server tabs, a fullscreen embed stage, and a
     download list.
3. **New bundled extension: QR Code Generator** (`extensions/pi-qr-generator`):
   - Agent tool `qr_code` (text/link/Wi-Fi/email payloads) rendered as an
     in-chat QR card and saved into the workspace `qr-codes/` directory.
   - Composer menu item "QR Code" encodes the current draft instantly, and
     Settings → QR Code Generator offers a quick-generate box.
   - Free keyless QR APIs with automatic fallback chain:
     api.qrserver.com (goqr.me) → quickchart.io → qrtag.net.
4. **New `qr` extension icon** mapped to `Icons.Rounded.QrCode2` in both the
   app and shared icon registries.
5. Both new extensions follow the existing preinstalled-extension pattern:
   they ship in the APK under `assets/extensions/` and appear in
   Settings → Extensions, disabled by default until the user enables them
   (existing installs that already have extension state stored will see them
   enabled).

## Using the assistant on MIUI (Android 11)

On MIUI 12.5 (e.g. Poco X2), for the most reliable summoning from anywhere:

1. Settings → Apps → Manage apps → Arix → Autostart: **on** (so the floating
   pill survives).
2. Arix → Other permissions: enable **Display pop-up windows while running in
   the background** (needed by the tile / floating pill to open the panel when
   Arix is in the background).
3. Settings → Assistant → Display over other apps → **Allow**.
4. Settings → Assistant → Set as default assistant → choose **Arix**.
   The bottom-corner assistant gesture now summons Arix.
5. Optionally enable the **Floating pill** toggle and add the **Arix Assistant**
   quick settings tile.

## Signing the release build

The release signing key is included so you can publish follow-up updates of this
same app identity:

- Keystore: `keystore/arix-release.jks`
- Config: `keystore.properties` (loaded by `app/build.gradle.kts`)
- Keystore password: `ArixRelease2026`
- Key alias: `arix`
- Key password: `ArixRelease2026`

> Keep these files private if you plan to distribute the app. Anyone holding the
> keystore can sign updates that install over your users' copies.

## Building the APK

Requirements: JDK 17+, Android SDK (platform 36, build-tools 36), Node.js 22+.

```bash
./gradlew :app:assembleRelease
# → app/build/outputs/apk/release/app-release.apk
```

The build automatically runs `npm install` + `npm run build` inside `pi-bridge/`
and bundles `bridge.mjs`, the preinstalled extensions, and the Alpine runtime
assets into the APK.
