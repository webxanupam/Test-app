package com.arix.app.data

import org.junit.Assert.assertTrue
import org.junit.Test

class ArixSelfManagementToolRoutingTest {
    @Test
    fun scheduledTaskToolIsRoutedByPiHostExecutor() {
        assertTrue(ArixToolExecutor.supports("arix_scheduled_task_manage"))
    }

    @Test
    fun piExtensionToolIsRoutedByPiHostExecutor() {
        assertTrue(ArixToolExecutor.supports("arix_extension_manage"))
    }
}
