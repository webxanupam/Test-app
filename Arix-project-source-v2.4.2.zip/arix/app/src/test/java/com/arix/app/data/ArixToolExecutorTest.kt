package com.arix.app.data

import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ArixToolExecutorTest {
    @Test
    fun hostToolDefinitionsDoNotDuplicatePiNativeTools() {
        val definitions = ArixToolExecutor.hostToolDefinitions()
        // system_control is always available; nothing else leaks without
        // a self-management tool.
        assertEquals(1, definitions.length())
        assertEquals("system_control", definitions.getJSONObject(0).getString("name"))
    }

    @Test
    fun hostToolDefinitionsExposeFlattenedShape() {
        val definitions = ArixToolExecutor.hostToolDefinitions()
        val definition = definitions.getJSONObject(0)
        // OpenAI-style definitions are flattened to name/description/parameters
        // plus Arix execution_mode metadata.
        assertEquals("system_control", definition.optString("name"))
        assertTrue(definition.has("parameters"))
        assertTrue(definition.optString("description").isNotBlank())
    }

    @Test
    fun hostToolNamesCoverSystemAndSelfManagement() {
        assertTrue(ArixToolExecutor.supports("system_control"))
        assertTrue(ArixToolExecutor.supports("arix_config_get"))
        assertFalse(ArixToolExecutor.supports("agent_mode"))
        assertFalse(ArixToolExecutor.supports("mcp_list_tools"))
        assertFalse(ArixToolExecutor.supports("chrome"))
    }

    @Test
    fun inferToolOutputOkHonorsArixJsonFlags() {
        assertTrue(ArixToolExecutor.inferToolOutputOk("""{"ok":true}"""))
        assertFalse(ArixToolExecutor.inferToolOutputOk("""{"ok":false}"""))
        assertFalse(ArixToolExecutor.inferToolOutputOk("""{"err":true}"""))
        assertTrue(ArixToolExecutor.inferToolOutputOk("plain text"))
        assertTrue(ArixToolExecutor.inferToolOutputOk("""{"status":"fine"}"""))
    }

    @Test
    fun executionResultFlagsErrorOutput() {
        val ok = ArixToolExecutionResult("system_control", "{}", """{"ok":true}""")
        val failed = ArixToolExecutionResult("system_control", "{}", """{"ok":false,"errmsg":"nope"}""")
        assertFalse(ok.isError)
        assertTrue(failed.isError)
        assertEquals(failed.rawOutput, failed.visibleOutput)
    }
}
