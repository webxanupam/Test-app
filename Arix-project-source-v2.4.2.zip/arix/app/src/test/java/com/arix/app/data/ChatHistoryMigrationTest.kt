package com.arix.app.data

import androidx.sqlite.SQLiteConnection
import androidx.sqlite.SQLiteStatement
import androidx.sqlite.execSQL
import com.arix.app.data.chatdb.Migration7To8
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.sql.Connection
import java.sql.DriverManager
import java.sql.PreparedStatement
import java.sql.ResultSet

/**
 * Runs the Room 7 -> 8 migration against a REAL SQLite database (JDBC) to
 * prove that chat data written by v2.1.5 (legacy `aetherMessageId` schema)
 * survives the update, and that databases created by the broken v2.1.6 build
 * (already `arixMessageId`) migrate cleanly too.
 */
class ChatHistoryMigrationTest {

    private class JdbcStatement(private val statement: PreparedStatement) : SQLiteStatement {
        private var resultSet: ResultSet? = null
        private var executed = false

        override fun step(): Boolean {
            if (!executed) {
                executed = true
                val hasResultSet = statement.execute()
                resultSet = if (hasResultSet) statement.resultSet else null
            }
            return resultSet?.next() ?: false
        }

        override fun getText(index: Int): String = resultSet!!.getString(index + 1)
        override fun getBlob(index: Int): ByteArray = resultSet!!.getBytes(index + 1)
        override fun getDouble(index: Int): Double = resultSet!!.getDouble(index + 1)
        override fun getLong(index: Int): Long = resultSet!!.getLong(index + 1)
        override fun isNull(index: Int): Boolean = resultSet!!.getObject(index + 1) == null
        override fun getColumnCount(): Int = resultSet!!.metaData.columnCount
        override fun getColumnName(index: Int): String = resultSet!!.metaData.getColumnName(index + 1)
        override fun getColumnType(index: Int): Int = resultSet!!.metaData.getColumnType(index + 1)

        override fun reset() {
            executed = false
            resultSet = null
        }

        override fun clearBindings() {
            statement.clearParameters()
        }

        override fun bindBlob(index: Int, value: ByteArray) = statement.setBytes(index + 1, value)
        override fun bindDouble(index: Int, value: Double) = statement.setDouble(index + 1, value)
        override fun bindLong(index: Int, value: Long) = statement.setLong(index + 1, value)
        override fun bindText(index: Int, value: String) = statement.setString(index + 1, value)
        override fun bindNull(index: Int) = statement.setNull(index + 1, java.sql.Types.NULL)

        override fun close() {
            resultSet?.close()
            statement.close()
        }
    }

    private class JdbcConnection(private val connection: Connection) : SQLiteConnection {
        override fun prepare(sql: String): SQLiteStatement =
            JdbcStatement(connection.prepareStatement(sql))

        override fun close() {
            connection.close()
        }
    }

    private fun connection(): Pair<JdbcConnection, Connection> {
        val raw = DriverManager.getConnection("jdbc:sqlite::memory:")
        raw.createStatement().execute("PRAGMA foreign_keys=ON")
        return JdbcConnection(raw) to raw
    }

    private fun createV7Database(db: SQLiteConnection, messageColumn: String) {
        db.execSQL(
            """
            CREATE TABLE IF NOT EXISTS `chat_sessions` (
                `id` TEXT NOT NULL, `title` TEXT NOT NULL, `preview` TEXT NOT NULL,
                `hasCustomTitle` INTEGER NOT NULL, `agentModeEnabled` INTEGER NOT NULL,
                `chromeEnabled` INTEGER NOT NULL, `selectedModelKey` TEXT NOT NULL,
                `sortOrder` INTEGER NOT NULL, PRIMARY KEY(`id`)
            )
            """.trimIndent(),
        )
        db.execSQL(
            """
            CREATE TABLE IF NOT EXISTS `chat_messages` (
                `sessionId` TEXT NOT NULL, `id` TEXT NOT NULL, `position` INTEGER NOT NULL,
                `messageJson` TEXT NOT NULL, `author` TEXT NOT NULL, `text` TEXT NOT NULL,
                `createdAtMillis` INTEGER, `responseGroupId` TEXT, `displayKind` TEXT,
                `messageSchemaVersion` INTEGER NOT NULL, `hasUsageStatistics` INTEGER NOT NULL,
                `isIncomplete` INTEGER NOT NULL, PRIMARY KEY(`sessionId`, `id`),
                FOREIGN KEY(`sessionId`) REFERENCES `chat_sessions`(`id`)
                    ON UPDATE NO ACTION ON DELETE CASCADE
            )
            """.trimIndent(),
        )
        db.execSQL(
            """
            CREATE TABLE IF NOT EXISTS `chat_agent_sessions` (
                `chatSessionId` TEXT NOT NULL, `piSessionId` TEXT NOT NULL,
                `jsonlPath` TEXT NOT NULL, `runtime` TEXT NOT NULL,
                `migrationVersion` INTEGER NOT NULL, `updatedAtMillis` INTEGER NOT NULL,
                PRIMARY KEY(`chatSessionId`),
                FOREIGN KEY(`chatSessionId`) REFERENCES `chat_sessions`(`id`)
                    ON UPDATE NO ACTION ON DELETE CASCADE
            )
            """.trimIndent(),
        )
        db.execSQL(
            """
            CREATE TABLE IF NOT EXISTS `chat_agent_message_refs` (
                `chatSessionId` TEXT NOT NULL, `$messageColumn` TEXT NOT NULL,
                `piEntryId` TEXT NOT NULL, `ordinal` INTEGER NOT NULL,
                PRIMARY KEY(`chatSessionId`, `$messageColumn`, `piEntryId`),
                FOREIGN KEY(`chatSessionId`, `$messageColumn`) REFERENCES `chat_messages`(`sessionId`, `id`)
                    ON UPDATE NO ACTION ON DELETE CASCADE
            )
            """.trimIndent(),
        )
        db.execSQL(
            "CREATE INDEX IF NOT EXISTS `index_chat_agent_message_refs_chatSessionId_piEntryId` " +
                "ON `chat_agent_message_refs` (`chatSessionId`, `piEntryId`)",
        )
        db.execSQL(
            "CREATE INDEX IF NOT EXISTS `index_chat_agent_message_refs_chatSessionId_$messageColumn` " +
                "ON `chat_agent_message_refs` (`chatSessionId`, `$messageColumn`)",
        )
        db.execSQL(
            """
            CREATE TABLE IF NOT EXISTS `chat_workspace_file_refs` (
                `sessionId` TEXT NOT NULL, `messageId` TEXT NOT NULL, `path` TEXT NOT NULL,
                PRIMARY KEY(`sessionId`, `messageId`, `path`),
                FOREIGN KEY(`sessionId`, `messageId`) REFERENCES `chat_messages`(`sessionId`, `id`)
                    ON UPDATE NO ACTION ON DELETE CASCADE
            )
            """.trimIndent(),
        )
        db.execSQL(
            """
            CREATE TABLE IF NOT EXISTS `chat_state_meta` (
                `id` TEXT NOT NULL, `currentSessionId` INTEGER, `roomMigrationComplete` INTEGER NOT NULL,
                `workspaceFileRefsComplete` INTEGER NOT NULL, PRIMARY KEY(`id`),
                FOREIGN KEY(`currentSessionId`) REFERENCES `chat_sessions`(`id`)
                    ON UPDATE NO ACTION ON DELETE SET NULL
            )
            """.trimIndent(),
        )
        db.execSQL(
            "CREATE TABLE IF NOT EXISTS room_master_table (id INTEGER PRIMARY KEY, identity_hash TEXT)",
        )
        db.execSQL(
            "INSERT OR REPLACE INTO room_master_table (id,identity_hash) VALUES(42, '0c888bd5a00192a04946c93a6c0e73e0')",
        )
    }

    private fun insertSampleData(db: SQLiteConnection, messageColumn: String) {
        db.execSQL(
            "INSERT INTO chat_sessions (id, title, preview, hasCustomTitle, agentModeEnabled, chromeEnabled, selectedModelKey, sortOrder) " +
                "VALUES ('s1', 'Hello', 'Hi there', 0, 1, 0, 'openai/gpt-4o-mini', 1)",
        )
        db.execSQL(
            "INSERT INTO chat_messages (sessionId, id, position, messageJson, author, text, messageSchemaVersion, hasUsageStatistics, isIncomplete) " +
                "VALUES ('s1', 'm1', 0, '{}', 'USER', 'Hi', 1, 0, 0)",
        )
        db.execSQL(
            "INSERT INTO chat_messages (sessionId, id, position, messageJson, author, text, messageSchemaVersion, hasUsageStatistics, isIncomplete) " +
                "VALUES ('s1', 'm2', 1, '{}', 'ASSISTANT', 'Hello! How can I help?', 1, 0, 0)",
        )
        db.execSQL(
            "INSERT INTO chat_agent_message_refs (chatSessionId, `$messageColumn`, piEntryId, ordinal) " +
                "VALUES ('s1', 'm2', 'e1', 0)",
        )
        db.execSQL(
            "INSERT INTO chat_agent_message_refs (chatSessionId, `$messageColumn`, piEntryId, ordinal) " +
                "VALUES ('s1', 'm2', 'e2', 1)",
        )
    }

    private fun tableColumns(db: SQLiteConnection, table: String): List<String> {
        val columns = mutableListOf<String>()
        db.prepare("PRAGMA table_info(`$table`)").use { statement ->
            while (statement.step()) {
                columns += statement.getText(1)
            }
        }
        return columns
    }

    private fun indexNames(db: SQLiteConnection): List<String> {
        val names = mutableListOf<String>()
        db.prepare("SELECT name FROM sqlite_master WHERE type = 'index'").use { statement ->
            while (statement.step()) {
                names += statement.getText(0)
            }
        }
        return names
    }

    private fun countRows(db: SQLiteConnection, table: String): Int {
        db.prepare("SELECT COUNT(*) FROM `$table`").use { statement ->
            statement.step()
            return statement.getLong(0).toInt()
        }
    }

    private fun foreignKeyViolations(db: SQLiteConnection): Int {
        db.prepare("PRAGMA foreign_key_check").use { statement ->
            var violations = 0
            while (statement.step()) {
                violations += 1
            }
            return violations
        }
    }

    @Test
    fun migrationRenamesLegacyColumnAndPreservesData() {
        val (db, raw) = connection()
        raw.use {
            createV7Database(db, messageColumn = "aetherMessageId")
            insertSampleData(db, messageColumn = "aetherMessageId")

            Migration7To8.migrate(db)

            val columns = tableColumns(db, "chat_agent_message_refs")
            assertTrue(columns.contains("arixMessageId"))
            assertFalse(columns.contains("aetherMessageId"))
            assertEquals(2, countRows(db, "chat_agent_message_refs"))
            assertEquals(2, countRows(db, "chat_messages"))
            assertEquals(1, countRows(db, "chat_sessions"))
            val indexes = indexNames(db)
            assertTrue(indexes.contains("index_chat_agent_message_refs_chatSessionId_arixMessageId"))
            assertTrue(indexes.contains("index_chat_agent_message_refs_chatSessionId_piEntryId"))
            assertFalse(indexes.contains("index_chat_agent_message_refs_chatSessionId_aetherMessageId"))
            assertEquals(0, foreignKeyViolations(db))
        }
    }

    @Test
    fun migrationHandlesDatabasesAlreadyUsingNewColumn() {
        val (db, raw) = connection()
        raw.use {
            createV7Database(db, messageColumn = "arixMessageId")
            insertSampleData(db, messageColumn = "arixMessageId")

            Migration7To8.migrate(db)

            val columns = tableColumns(db, "chat_agent_message_refs")
            assertTrue(columns.contains("arixMessageId"))
            assertFalse(columns.contains("aetherMessageId"))
            assertEquals(2, countRows(db, "chat_agent_message_refs"))
            assertEquals(0, foreignKeyViolations(db))
        }
    }
}
