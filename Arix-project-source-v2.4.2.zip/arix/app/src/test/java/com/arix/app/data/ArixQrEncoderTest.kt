package com.arix.app.data

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * Verifies the native QR encoder against matrices produced by the reference
 * `qrcode` Python library (byte mode, ECC M, auto version + penalty-optimal
 * mask). Vectors baked from the reference implementation.
 */
class ArixQrEncoderTest {

    private data class Vector(
        val payload: String,
        val version: Int,
        val mask: Int,
        val size: Int,
        val rows: List<String>,
    )

    private val vectors = listOf(
        Vector(
            payload = "https://arix.app", version = 2, mask = 1, size = 25,
            rows = listOf(
                "1fdfe7f", "1045241", "175a85d", "174525d", "174935d", "1059c41", "1fd557f", "a800",
                "146fa25", "d193eb", "27afdd", "1a18448", "1c5ee61", "320f63", "1ada28d", "1848b8",
                "1cc3bf2", "15111", "1fd1d51", "1047710", "174cff3", "1748d96", "175603b", "1044970",
                "1fdbbc9",
            ),
        ),
        Vector(
            payload = "hello world", version = 1, mask = 3, size = 21,
            rows = listOf(
                "1fdb7f", "105f41", "17435d", "175d5d", "174e5d", "104f41", "1fd57f", "1f00",
                "16e74b", "dabfd", "376a3", "fa62a", "2f9c1", "1e74", "1fdff0", "1050af",
                "17490c", "17544e", "175924", "1046f1", "1fd6e4",
            ),
        ),
        Vector(
            payload = "WIFI:T:WPA;S:HomeNet;P:secretpass123;;", version = 3, mask = 3, size = 29,
            rows = listOf(
                "1fdaca7f", "105cd141", "1747f25d", "175fb95d", "174aac5d", "10411b41", "1fd5557f", "1e2f00",
                "16e28d4b", "79a8656", "9de9d5e", "70e1708", "1363793c", "11846a00", "4d38b3f", "1f8f4188",
                "49559d", "c2f6501", "15d9fc70", "2b7eae7", "ef5cdf7", "1e1514", "1fd95d52", "1055d510",
                "174129f8", "1759bfad", "17505425", "104f255a", "1fde17ae",
            ),
        ),
        Vector(
            payload = "https://example.com/very/long/path?query=value&x=1234567890", version = 4, mask = 1, size = 33,
            rows = listOf(
                "1fd9dcc7f", "104614441", "175c8cb5d", "174609d5d", "17482945d", "105de5441", "1fd55557f", "276100",
                "146812025", "49bf7349", "35d3aacd", "9ab7578", "fc094541", "163a063e7", "1ff877a1d", "1f1dc24e0",
                "4e73762", "c303634b", "9cbe22ad", "1f8db109a", "1175c43e3", "92e6efed", "1d4eae351", "1ec43ab",
                "1fc3973f2", "1e33911", "1fd772d5d", "104f97318", "1745047f3", "174eae4b3", "175472637", "1043457f8",
                "1fdcd1171",
            ),
        ),
    )

    private fun rowMatches(matrix: ArixQrEncoder.QrMatrix, rowIndex: Int, hex: String): Boolean {
        val expected = hex.toLong(16)
        for (col in 0 until matrix.size) {
            val expectedDark = (expected shr (matrix.size - 1 - col)) and 1L == 1L
            if (matrix.isDark(rowIndex, col) != expectedDark) return false
        }
        return true
    }

    @Test
    fun matricesMatchReferenceLibrary() {
        for (vector in vectors) {
            val matrix = ArixQrEncoder.encode(vector.payload.toByteArray(Charsets.UTF_8))
            assertEquals("size mismatch for ${vector.payload.take(20)}", vector.size.toLong(), matrix.size.toLong())
            assertEquals("version mismatch for ${vector.payload.take(20)}", vector.version.toLong(), matrix.version.toLong())
            vector.rows.forEachIndexed { index, hex ->
                assertTrue(
                    "row $index mismatch for ${vector.payload.take(20)} (expected $hex)",
                    rowMatches(matrix, index, hex),
                )
            }
        }
    }

    @Test
    fun versionSelectionMatchesCapacity() {
        // 14 bytes fit v1-M (16 data codewords minus 2 header)
        assertEquals(1, ArixQrEncoder.encode("12345678901234".toByteArray()).version)
        // 15 bytes overflow v1-M -> v2
        assertEquals(2, ArixQrEncoder.encode("123456789012345".toByteArray()).version)
    }

    @Test
    fun oversizedPayloadThrows() {
        val tooBig = ByteArray(2400) { 'x'.code.toByte() }
        var thrown = false
        try {
            ArixQrEncoder.encode(tooBig)
        } catch (expected: ArixQrEncoder.CapacityException) {
            thrown = true
        }
        assertTrue("CapacityException expected for oversized payloads", thrown)
    }

    @Test
    fun finderPatternsPresent() {
        val matrix = ArixQrEncoder.encode("test".toByteArray())
        // TL finder corner is dark in all four corners of the 7x7 pattern
        assertTrue(matrix.isDark(0, 0))
        assertTrue(matrix.isDark(6, 6))
        assertTrue(matrix.isDark(0, 6))
        assertTrue(matrix.isDark(6, 0))
        // dark module
        assertTrue(matrix.isDark(matrix.size - 8, 8))
    }
}
