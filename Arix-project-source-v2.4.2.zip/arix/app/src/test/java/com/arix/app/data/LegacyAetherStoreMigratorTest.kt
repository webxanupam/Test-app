package com.arix.app.data

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.io.File

/**
 * Verifies the one-time migration that carries v2.15 "aether_*" store files
 * (settings, chats, extensions, scheduled tasks, Room database, legacy
 * SharedPreferences) into the rebranded "arix_*" store files.
 */
// Uses a plain Application (NOT ArixApplication) so the migrator has not
// already run during application startup before the test seeds its legacy
// files. On a real device the migrator runs synchronously at the very start
// of ArixApplication.onCreate, before any store is opened.
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [30], application = android.app.Application::class)
class LegacyAetherStoreMigratorTest {

    private fun context(): Context = ApplicationProvider.getApplicationContext()

    private fun datastoreDir(context: Context): File = File(context.filesDir, "datastore")

    private fun prefsDir(context: Context): File = File(context.filesDir.parentFile, "shared_prefs")

    private fun databasesDir(context: Context): File = File(context.filesDir.parentFile, "databases")

    private fun writeFile(file: File, content: String) {
        file.parentFile.mkdirs()
        file.writeText(content)
    }

    @Test
    fun migratesAllLegacyStoresOnce() {
        val context = context()
        // Seed legacy v2.1.5 stores.
        writeFile(
            File(datastoreDir(context), "aether_settings.preferences_pb"),
            "legacy-settings",
        )
        writeFile(File(datastoreDir(context), "aether_chats.preferences_pb"), "legacy-chats")
        writeFile(
            File(datastoreDir(context), "aether_agent_extensions.preferences_pb"),
            "legacy-extensions",
        )
        writeFile(
            File(datastoreDir(context), "aether_scheduled_tasks.preferences_pb"),
            "legacy-tasks",
        )
        writeFile(
            File(datastoreDir(context), "aether_pi_extension_state.preferences_pb"),
            "legacy-pi-state",
        )
        writeFile(File(prefsDir(context), "aether_discovered_skills.xml"), "legacy-skills")
        writeFile(File(prefsDir(context), "aether_native_mods.xml"), "legacy-mods")
        writeFile(File(databasesDir(context), "aether_chat_history.db"), "legacy-db")
        writeFile(File(databasesDir(context), "aether_chat_history.db-wal"), "legacy-wal")

        LegacyAetherStoreMigrator.migrate(context)

        assertEquals("legacy-settings", File(datastoreDir(context), "arix_settings.preferences_pb").readText())
        assertEquals("legacy-chats", File(datastoreDir(context), "arix_chats.preferences_pb").readText())
        assertEquals("legacy-extensions", File(datastoreDir(context), "arix_agent_extensions.preferences_pb").readText())
        assertEquals("legacy-tasks", File(datastoreDir(context), "arix_scheduled_tasks.preferences_pb").readText())
        assertEquals("legacy-pi-state", File(datastoreDir(context), "arix_pi_extension_state.preferences_pb").readText())
        assertEquals("legacy-skills", File(prefsDir(context), "arix_discovered_skills.xml").readText())
        assertEquals("legacy-mods", File(prefsDir(context), "arix_native_mods.xml").readText())
        assertEquals("legacy-db", File(databasesDir(context), "arix_chat_history.db").readText())
        assertEquals("legacy-wal", File(databasesDir(context), "arix_chat_history.db-wal").readText())

        // Legacy files remain untouched (they are never deleted).
        assertTrue(File(datastoreDir(context), "aether_settings.preferences_pb").exists())

        // A second run must be a no-op: new values written after the first
        // migration survive because files are no longer copied.
        File(datastoreDir(context), "arix_settings.preferences_pb").writeText("new-settings")
        LegacyAetherStoreMigrator.migrate(context)
        assertEquals("new-settings", File(datastoreDir(context), "arix_settings.preferences_pb").readText())
    }

    @Test
    fun doesNothingOnFreshInstallWithoutLegacyFiles() {
        val context = context()
        LegacyAetherStoreMigrator.migrate(context)
        assertFalse(File(datastoreDir(context), "arix_settings.preferences_pb").exists())
        assertFalse(File(databasesDir(context), "arix_chat_history.db").exists())
        // The marker is still written so later runs are cheap.
        assertTrue(
            context.getSharedPreferences("arix_store_migration", Context.MODE_PRIVATE)
                .getBoolean("migrated_from_legacy_aether_stores", false),
        )
    }

    @Test
    fun replacesEmptyStoresLeftByBrokenBuild() {
        val context = context()
        writeFile(File(datastoreDir(context), "aether_settings.preferences_pb"), "legacy-settings")
        // A crashing v2.1.6 may have left an empty store behind.
        writeFile(File(datastoreDir(context), "arix_settings.preferences_pb"), "")

        LegacyAetherStoreMigrator.migrate(context)

        assertEquals("legacy-settings", File(datastoreDir(context), "arix_settings.preferences_pb").readText())
    }
}
