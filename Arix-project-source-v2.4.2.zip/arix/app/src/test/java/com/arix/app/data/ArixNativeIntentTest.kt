package com.arix.app.data

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * Verifies the client-side intent router that turns movie / QR commands into
 * instant native tool turns (and leaves normal conversation to the LLM).
 */
class ArixNativeIntentTest {

    @Test
    fun qrCommandsAreDetected() {
        val qr = ArixNativeIntent.match("create a qr code for https://example.com")
        assertTrue(qr is ArixNativeIntent.QrCode)
        assertEquals("https://example.com", (qr as ArixNativeIntent.QrCode).data)

        val wifi = ArixNativeIntent.match("QR code: WIFI:T:WPA;S:Net;P:pass;;")
        assertTrue(wifi is ArixNativeIntent.QrCode)
        assertEquals("WIFI:T:WPA;S:Net;P:pass;;", (wifi as ArixNativeIntent.QrCode).data)

        val plain = ArixNativeIntent.match("generate qr of hello world")
        assertTrue(plain is ArixNativeIntent.QrCode)
        assertEquals("hello world", (plain as ArixNativeIntent.QrCode).data)
    }

    @Test
    fun qrWithoutPayloadIsIgnored() {
        assertNull(ArixNativeIntent.match("what is a qr code"))
        assertNull(ArixNativeIntent.match("qr"))
    }

    @Test
    fun movieCommandsAreDetected() {
        assertTrue(ArixNativeIntent.match("show latest movies") is ArixNativeIntent.MovieList)
        assertTrue(ArixNativeIntent.match("new movies please") is ArixNativeIntent.MovieList)
        assertTrue(ArixNativeIntent.match("more movies") is ArixNativeIntent.MovieList)
        assertTrue(ArixNativeIntent.match("movies page 3") is ArixNativeIntent.MovieList)
        assertEquals(3, (ArixNativeIntent.match("movies page 3") as ArixNativeIntent.MovieList).page)

        val search = ArixNativeIntent.match("search movie dunki")
        assertTrue(search is ArixNativeIntent.MovieSearch)
        assertEquals("dunki", (search as ArixNativeIntent.MovieSearch).query)

        val play = ArixNativeIntent.match("play movie iron man")
        assertTrue(play is ArixNativeIntent.MoviePlayTitle)
        assertEquals("iron man", (play as ArixNativeIntent.MoviePlayTitle).title)
    }

    @Test
    fun systemCommandsAreDetected() {
        assertTrue(ArixNativeIntent.match("open youtube") is ArixNativeIntent.OpenApp)
        assertEquals("youtube", (ArixNativeIntent.match("open youtube") as ArixNativeIntent.OpenApp).target)
        assertTrue(ArixNativeIntent.match("please launch whatsapp") is ArixNativeIntent.OpenApp)
        assertTrue(ArixNativeIntent.match("open wifi settings") is ArixNativeIntent.OpenSettings)
        assertEquals("wifi", (ArixNativeIntent.match("open wifi settings") as ArixNativeIntent.OpenSettings).page)
        assertTrue(ArixNativeIntent.match("open bluetooth settings") is ArixNativeIntent.OpenSettings)
        assertTrue(ArixNativeIntent.match("open https://example.com") is ArixNativeIntent.OpenUrl)
        assertTrue(ArixNativeIntent.match("turn on bluetooth") is ArixNativeIntent.OpenSettings)
    }

    @Test
    fun normalConversationGoesToTheModel() {
        assertNull(ArixNativeIntent.match("what is your favorite movie?"))
        assertNull(ArixNativeIntent.match("write a review of the movie inception"))
        assertNull(ArixNativeIntent.match("hello"))
        assertNull(ArixNativeIntent.match("https://example.com"))
        assertNull(ArixNativeIntent.match("thanks"))
        assertNull(ArixNativeIntent.match("what apps do I have installed"))
        assertNull(ArixNativeIntent.match("how do I open the settings"))
    }

    @Test
    fun animeCommandsAreDetected() {
        assertTrue(ArixNativeIntent.match("show latest anime") is ArixNativeIntent.AnimeList)
        assertTrue(ArixNativeIntent.match("more anime") is ArixNativeIntent.AnimeList)
        assertTrue(ArixNativeIntent.match("anime page 2") is ArixNativeIntent.AnimeList)
        val search = ArixNativeIntent.match("search anime one piece")
        assertTrue(search is ArixNativeIntent.AnimeSearch)
        assertEquals("one piece", (search as ArixNativeIntent.AnimeSearch).query)
        val watch = ArixNativeIntent.match("watch anime naruto")
        assertTrue(watch is ArixNativeIntent.AnimeWatch)
        assertEquals("naruto", (watch as ArixNativeIntent.AnimeWatch).query)
    }
}
