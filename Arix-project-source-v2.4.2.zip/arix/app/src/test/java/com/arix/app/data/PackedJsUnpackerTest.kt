package com.arix.app.data

import org.junit.Test
import java.io.File

/**
 * Offline tests for the Dean-Edwards packed-JS unpacker and the direct-video
 * resolver, using a real pkembed embed page captured from the live site.
 */
class PackedJsUnpackerTest {

    private fun fixture(name: String): String {
        val url = javaClass.classLoader!!.getResource(name)
            ?: error("fixture $name not found")
        return File(url.toURI()).readText()
    }

    @Test
    fun unpacksPkembedPacker() {
        val html = fixture("pkembed_fixture.html")
        val scripts = ArixMediaApi.unpackAllPackedJs(html)
        check(scripts.isNotEmpty()) { "no packer decoded" }
        val videoScript = scripts.firstOrNull { it.contains("video") || it.contains("player") || it.contains("mp4") }
        checkNotNull(videoScript) { "no video script among ${scripts.size} decoded" }
    }

    @Test
    fun extractsDirectVideoFromPkembed() {
        val html = fixture("pkembed_fixture.html")
        val direct = ArixMediaApi.extractDirectVideoUrl(html)
        println("pkembed direct: $direct")
        check(direct.startsWith("https://")) { "no direct url extracted" }
        check(direct.contains(".mp4") || direct.contains(".m3u8")) { "not a media url: $direct" }
    }

    @Test
    fun handlesPagesWithoutPacker() {
        check(ArixMediaApi.unpackAllPackedJs("<html><body>hi</body></html>").isEmpty())
        check(ArixMediaApi.extractDirectVideoUrl("<html><body>hi</body></html>").isEmpty())
    }

    @Test
    fun decodesSyntheticPacker() {
        // payload: video src http://cdn.example.com/v/a.mp4 — token 1 = url,
        // token 2 = mp4 word; indexes are base36 of the token positions.
        val html = "eval(function(p,a,c,k,e,d){}('1 2 a.2',10,3,'|https://cdn.example.com/v/a.mp4|mp4'.split('|'),0,{}))"
        val decoded = ArixMediaApi.unpackAllPackedJs(html).joinToString("\n")
        println("synthetic decoded: $decoded")
        check(decoded.contains("https://cdn.example.com/v/a.mp4")) { "token substitution failed: $decoded" }
        val direct = ArixMediaApi.extractDirectVideoUrl(html)
        check(direct == "https://cdn.example.com/v/a.mp4") { "extraction failed: $direct" }
    }
}
