package com.arix.app

import android.os.Looper
import androidx.test.core.app.ApplicationProvider
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.Robolectric
import org.robolectric.RobolectricTestRunner
import org.robolectric.Shadows.shadowOf
import org.robolectric.annotation.Config
import org.robolectric.annotation.LooperMode

/**
 * JVM smoke tests that execute the real application startup path on a
 * simulated Android 11 (API 30) device, matching the Poco X2 / MIUI 12.5
 * target. If any of these fail, the app would crash on open on the device.
 */
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [30], application = ArixApplication::class)
@LooperMode(LooperMode.Mode.PAUSED)
class StartupSmokeTest {

    @Test
    fun applicationInitializesWithoutCrash() {
        val app = ApplicationProvider.getApplicationContext<ArixApplication>()
        assertNotNull(app)
        assertNotNull(app.runtime.settingsRepository)
        assertNotNull(app.runtime.chatRepository)
        assertNotNull(app.runtime.chatStateStore)
        assertNotNull(app.runtime.sessionExecutionManager)
        // Let background startup coroutines run to completion.
        shadowOf(Looper.getMainLooper()).idle()
        Thread.sleep(500)
    }

    @Test
    fun settingsRepositoryLoadsDefaults() = runBlocking {
        val app = ApplicationProvider.getApplicationContext<ArixApplication>()
        val settings = app.runtime.settingsRepository.settings.first()
        assertNotNull(settings)
        // Defaults must round-trip without throwing.
        assertTrue(settings.systemPrompt.isNotBlank())
    }

    @Test
    fun chatStateStoreProducesInitialState() = runBlocking {
        val app = ApplicationProvider.getApplicationContext<ArixApplication>()
        val state = app.runtime.chatStateStore.state.first()
        assertNotNull(state)
        assertNotNull(state.sessions)
    }

    @Test
    fun roomDatabaseFactoryExposesSingleton() {
        // Note: the bundled SQLite driver loads Android-native libraries that
        // cannot run under Robolectric; on-device DB open is exercised by the
        // activity tests via the chat state store instead.
        val app = ApplicationProvider.getApplicationContext<ArixApplication>()
        val db = com.arix.app.data.chatdb.AndroidChatHistoryDatabaseFactory
            .getInstance(app)
        assertNotNull(db)
    }

    @Test
    fun mainActivityLaunchesAndComposes() {
        val controller = Robolectric.buildActivity(MainActivity::class.java)
        controller.setup() // onCreate -> onStart -> onResume
        shadowOf(Looper.getMainLooper()).idle()
        // Drive several frames so Compose performs its initial composition.
        repeat(8) {
            shadowOf(Looper.getMainLooper()).idle()
            Thread.sleep(50)
        }
        val activity = controller.get()
        assertFalse(activity.isFinishing)
        controller.destroy()
    }

    @Test
    fun assistantActivityLaunchesAndComposes() {
        val controller = Robolectric.buildActivity(
            com.arix.app.assistant.AssistantActivity::class.java,
        )
        controller.setup()
        shadowOf(Looper.getMainLooper()).idle()
        repeat(8) {
            shadowOf(Looper.getMainLooper()).idle()
            Thread.sleep(50)
        }
        val activity = controller.get()
        assertFalse(activity.isFinishing)
        controller.destroy()
    }
}
