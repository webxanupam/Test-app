package com.arix.app.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.sp
import com.arix.app.data.AppLanguage
import com.arix.app.data.AppThemeMode
import com.arix.app.platform.LocalReduceMotion
import com.arix.app.platform.rememberPlatformAccessibilityPreferences

private val LightHighContrastArixColors = lightColorScheme(
    primary = LightHighContrastArixPalette.primary,
    onPrimary = LightHighContrastArixPalette.onPrimary,
    primaryContainer = LightHighContrastArixPalette.primaryContainer,
    onPrimaryContainer = LightHighContrastArixPalette.onPrimaryContainer,
    secondary = LightHighContrastArixPalette.secondary,
    onSecondary = LightHighContrastArixPalette.onSecondary,
    secondaryContainer = LightHighContrastArixPalette.secondaryContainer,
    onSecondaryContainer = LightHighContrastArixPalette.onSecondaryContainer,
    background = LightHighContrastArixPalette.background,
    surface = LightHighContrastArixPalette.surface,
    surfaceVariant = LightHighContrastArixPalette.surfaceVariant,
    surfaceContainerHighest = LightHighContrastArixPalette.surfaceVariant,
    onSurface = LightHighContrastArixPalette.onSurface,
    onSurfaceVariant = LightHighContrastArixPalette.onSurfaceVariant,
    tertiary = LightHighContrastArixPalette.tertiary,
    error = LightHighContrastArixPalette.error,
    outline = LightHighContrastArixPalette.outline,
)

private val DarkHighContrastArixColors = darkColorScheme(
    primary = DarkHighContrastArixPalette.primary,
    onPrimary = DarkHighContrastArixPalette.onPrimary,
    primaryContainer = DarkHighContrastArixPalette.primaryContainer,
    onPrimaryContainer = DarkHighContrastArixPalette.onPrimaryContainer,
    secondary = DarkHighContrastArixPalette.secondary,
    onSecondary = DarkHighContrastArixPalette.onSecondary,
    secondaryContainer = DarkHighContrastArixPalette.secondaryContainer,
    onSecondaryContainer = DarkHighContrastArixPalette.onSecondaryContainer,
    background = DarkHighContrastArixPalette.background,
    surface = DarkHighContrastArixPalette.surface,
    surfaceVariant = DarkHighContrastArixPalette.surfaceVariant,
    surfaceContainerHighest = DarkHighContrastArixPalette.surfaceVariant,
    onSurface = DarkHighContrastArixPalette.onSurface,
    onSurfaceVariant = DarkHighContrastArixPalette.onSurfaceVariant,
    tertiary = DarkHighContrastArixPalette.tertiary,
    error = DarkHighContrastArixPalette.error,
    outline = DarkHighContrastArixPalette.outline,
)

private val LightArixColors = lightColorScheme(
    primary = LightArixPalette.primary,
    onPrimary = LightArixPalette.onPrimary,
    primaryContainer = LightArixPalette.primaryContainer,
    onPrimaryContainer = LightArixPalette.onPrimaryContainer,
    secondary = LightArixPalette.secondary,
    onSecondary = LightArixPalette.onSecondary,
    secondaryContainer = LightArixPalette.secondaryContainer,
    onSecondaryContainer = LightArixPalette.onSecondaryContainer,
    background = LightArixPalette.background,
    surface = LightArixPalette.surface,
    surfaceVariant = LightArixPalette.surfaceVariant,
    surfaceContainerHighest = LightArixPalette.surfaceVariant,
    onSurface = LightArixPalette.onSurface,
    onSurfaceVariant = LightArixPalette.onSurfaceVariant,
    tertiary = LightArixPalette.tertiary,
    error = LightArixPalette.error,
    outline = LightArixPalette.outline,
)

private val DarkArixColors = darkColorScheme(
    primary = DarkArixPalette.primary,
    onPrimary = DarkArixPalette.onPrimary,
    primaryContainer = DarkArixPalette.primaryContainer,
    onPrimaryContainer = DarkArixPalette.onPrimaryContainer,
    secondary = DarkArixPalette.secondary,
    onSecondary = DarkArixPalette.onSecondary,
    secondaryContainer = DarkArixPalette.secondaryContainer,
    onSecondaryContainer = DarkArixPalette.onSecondaryContainer,
    background = DarkArixPalette.background,
    surface = DarkArixPalette.surface,
    surfaceVariant = DarkArixPalette.surfaceVariant,
    surfaceContainerHighest = DarkArixPalette.surfaceVariant,
    onSurface = DarkArixPalette.onSurface,
    onSurfaceVariant = DarkArixPalette.onSurfaceVariant,
    tertiary = DarkArixPalette.tertiary,
    error = DarkArixPalette.error,
    outline = DarkArixPalette.outline,
)


private fun getArixTypography(fontFamily: FontFamily) = Typography(
    headlineLarge = TextStyle(
        fontFamily = fontFamily,
        fontWeight = FontWeight.SemiBold,
        fontSize = 34.sp,
        lineHeight = 40.sp,
        letterSpacing = (-0.9).sp
    ),
    headlineMedium = TextStyle(
        fontFamily = fontFamily,
        fontWeight = FontWeight.SemiBold,
        fontSize = 29.sp,
        lineHeight = 36.sp,
        letterSpacing = (-0.5).sp
    ),
    titleLarge = TextStyle(
        fontFamily = fontFamily,
        fontWeight = FontWeight.SemiBold,
        fontSize = 24.sp,
        lineHeight = 31.sp
    ),
    titleMedium = TextStyle(
        fontFamily = fontFamily,
        fontWeight = FontWeight.Medium,
        fontSize = 18.sp,
        lineHeight = 25.sp
    ),
    bodyLarge = TextStyle(
        fontFamily = fontFamily,
        fontWeight = FontWeight.Normal,
        fontSize = 17.sp,
        lineHeight = 28.sp
    ),
    bodyMedium = TextStyle(
        fontFamily = fontFamily,
        fontWeight = FontWeight.Normal,
        fontSize = 15.sp,
        lineHeight = 24.sp
    ),
    bodySmall = TextStyle(
        fontFamily = fontFamily,
        fontWeight = FontWeight.Normal,
        fontSize = 13.sp,
        lineHeight = 18.sp
    ),
    labelLarge = TextStyle(
        fontFamily = fontFamily,
        fontWeight = FontWeight.Medium,
        fontSize = 14.sp,
        lineHeight = 20.sp
    ),
    labelMedium = TextStyle(
        fontFamily = fontFamily,
        fontWeight = FontWeight.Medium,
        fontSize = 13.sp,
        lineHeight = 18.sp
    )
)

@Composable
fun ArixTheme(
    themeMode: AppThemeMode = AppThemeMode.Dark,
    language: AppLanguage = AppLanguage.English,
    content: @Composable () -> Unit
) {
    // The theme picker was removed; Arix is permanently dark themed.
    val darkTheme = when (themeMode) {
        AppThemeMode.System -> true
        AppThemeMode.Light -> true
        AppThemeMode.Dark -> true
    }
    val accessibility = rememberPlatformAccessibilityPreferences()
    SideEffect {
        updateArixPalette(darkTheme, accessibility.increasedContrast)
    }
    val currentFontFamily = FontFamily.SansSerif
    val layoutDirection = LayoutDirection.Ltr
    val typography = remember(currentFontFamily) {
        getArixTypography(currentFontFamily)
    }
    CompositionLocalProvider(
        LocalLayoutDirection provides layoutDirection,
        LocalReduceMotion provides accessibility.reduceMotion,
    ) {
        MaterialTheme(
            colorScheme = when {
                darkTheme && accessibility.increasedContrast -> DarkHighContrastArixColors
                darkTheme -> DarkArixColors
                accessibility.increasedContrast -> LightHighContrastArixColors
                else -> LightArixColors
            },
            typography = typography,
            content = content
        )
    }
}
