package com.arix.app.data

import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/**
 * ArixAniListClient — provider 1 of the Anime tool (v2.4.0).
 *
 * Replaces the old AnimeLok scraper with the public AniList GraphQL API
 * (graphql.anilist.co):
 *
 *  - Keyless, free, extremely stable (the anime community's reference DB).
 *  - Latest: trending anime (`sort: TRENDING_DESC`), plus this-season picks.
 *  - Search: `search: "<q>"`.
 *  - Episodes: AniList's `episodes` count (or `nextAiringEpisode.episode - 1`
 *    for currently-airing shows).
 *
 * Playback: AniList carries no IMDb ids, so each episode resolves its embed
 * servers by looking the title up in the Cinemeta catalog (Stremio) and then
 * building free embed-player URLs (vidsrc.to / 2embed / vidsrc.in) keyed on
 * the resulting IMDb id — the same embed architecture the MovieBox "Web
 * player" fallback uses. The lookup is cached so each series maps once.
 *
 * All methods perform blocking network IO — call them from Dispatchers.IO.
 */
object ArixAniListClient {

    private const val Endpoint = "https://graphql.anilist.co"

    /** Pseudo-URL scheme for AniList grid items: `anilist:<mediaId>`. */
    const val UrlScheme = "anilist:"

    private val JsonMediaType = "application/json; charset=utf-8".toMediaType()

    private val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(12, TimeUnit.SECONDS)
        .readTimeout(20, TimeUnit.SECONDS)
        .build()

    private val queryClient: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(8, TimeUnit.SECONDS)
        .readTimeout(12, TimeUnit.SECONDS)
        .build()

    /* ------------------------------------------------------------ catalog */

    private val MediaFields = """
        id
        title { romaji english native }
        episodes
        description(asHtml: false)
        averageScore
        seasonYear
        format
        status
        nextAiringEpisode { episode }
        coverImage { large extraLarge }
        genres
    """.trimIndent()

    /** Trending anime — the default "Latest anime" feed. */
    fun latest(page: Int = 1, limit: Int = 36): List<ArixAnimeSiteClient.AnimeItem> {
        val query = """
            query (${'$'}page: Int, ${'$'}perPage: Int) {
              Page(page: ${'$'}page, perPage: ${'$'}perPage) {
                media(type: ANIME, sort: TRENDING_DESC, isAdult: false) { $MediaFields }
              }
            }
        """.trimIndent()
        val variables = JSONObject()
            .put("page", page.coerceIn(1, 50))
            .put("perPage", limit)
        return queryMedia(query, variables)
    }

    /** Keyword search. */
    fun search(query: String, limit: Int = 36): List<ArixAnimeSiteClient.AnimeItem> {
        if (query.isBlank()) return emptyList()
        val graphql = """
            query (${'$'}search: String, ${'$'}perPage: Int) {
              Page(perPage: ${'$'}perPage) {
                media(type: ANIME, search: ${'$'}search, sort: SEARCH_MATCH, isAdult: false) { $MediaFields }
              }
            }
        """.trimIndent()
        val variables = JSONObject()
            .put("search", query.trim())
            .put("perPage", limit)
        return queryMedia(graphql, variables)
    }

    private fun queryMedia(query: String, variables: JSONObject): List<ArixAnimeSiteClient.AnimeItem> {
        val body = JSONObject()
            .put("query", query)
            .put("variables", variables)
            .toString()
        val response = runCatching {
            client.newCall(
                Request.Builder()
                    .url(Endpoint)
                    .header("User-Agent", ArixMediaApi.BrowserUserAgent)
                    .header("Content-Type", "application/json")
                    .header("Accept", "application/json")
                    .post(body.toRequestBody(JsonMediaType))
                    .build(),
            ).execute().use { call ->
                if (!call.isSuccessful) error("AniList returned HTTP ${call.code}")
                call.body?.string() ?: error("Empty AniList response")
            }
        }.getOrNull() ?: return emptyList()
        val media = runCatching {
            JSONObject(response).optJSONObject("data")?.optJSONObject("Page")?.optJSONArray("media")
        }.getOrNull() ?: return emptyList()
        val result = mutableListOf<ArixAnimeSiteClient.AnimeItem>()
        for (i in 0 until media.length()) {
            val entry = media.optJSONObject(i) ?: continue
            val item = toItem(entry) ?: continue
            result.add(item)
        }
        return result
    }

    private fun toItem(entry: JSONObject): ArixAnimeSiteClient.AnimeItem? {
        val id = entry.optInt("id", 0)
        if (id <= 0) return null
        val title = entry.optJSONObject("title")
        val name = title?.optString("english").takeIf { !it.isNullOrBlank() }
            ?: title?.optString("romaji").takeIf { !it.isNullOrBlank() }
            ?: return null
        val cover = entry.optJSONObject("coverImage")
            ?.optString("extraLarge")
            ?.takeIf { it.startsWith("http") }
            ?: entry.optJSONObject("coverImage")?.optString("large")?.takeIf { it.startsWith("http") }
            .orEmpty()
        val meta = buildString {
            val year = entry.optInt("seasonYear", 0)
            if (year > 0) append(year)
            val format = entry.optString("format")
            if (format.isNotBlank()) append(if (isEmpty()) "" else " · ").append(format)
            val score = entry.optInt("averageScore", 0)
            if (score > 0) append(if (isEmpty()) "" else " · ").append("★ ").append((score / 10.0))
        }
        return ArixAnimeSiteClient.AnimeItem(
            title = cleanTitle(name),
            url = "$UrlScheme$id",
            thumbnail = cover,
            source = ArixAnimeSiteClient.SourceAniList,
            meta = meta,
        )
    }

    private fun cleanTitle(raw: String): String = raw.trim()

    /* ------------------------------------------------------------ detail */

    /** Full AniList media entry for an `anilist:<id>` item URL. */
    private fun mediaFor(itemUrl: String): JSONObject? {
        val id = itemUrl.removePrefix(UrlScheme).trim().toIntOrNull() ?: return null
        val query = """
            query (${'$'}id: Int) {
              Media(id: ${'$'}id, type: ANIME) { $MediaFields }
            }
        """.trimIndent()
        val variables = JSONObject().put("id", id)
        val body = JSONObject()
            .put("query", query)
            .put("variables", variables)
            .toString()
        val response = runCatching {
            client.newCall(
                Request.Builder()
                    .url(Endpoint)
                    .header("User-Agent", ArixMediaApi.BrowserUserAgent)
                    .header("Content-Type", "application/json")
                    .header("Accept", "application/json")
                    .post(body.toRequestBody(JsonMediaType))
                    .build(),
            ).execute().use { call ->
                if (!call.isSuccessful) error("AniList returned HTTP ${call.code}")
                call.body?.string() ?: error("Empty AniList response")
            }
        }.getOrNull() ?: return null
        return runCatching {
            JSONObject(response).optJSONObject("data")?.optJSONObject("Media")
        }.getOrNull()
    }

    /** Best display title of an AniList media entry. */
    private fun displayTitle(media: JSONObject): String {
        val title = media.optJSONObject("title") ?: return ""
        return title.optString("english").takeIf { it.isNotBlank() }
            ?: title.optString("romaji").takeIf { it.isNotBlank() }
            ?: title.optString("native").takeIf { it.isNotBlank() }
            .orEmpty()
    }

    /**
     * Episode list for an anime (1..N) based on AniList's episode count.
     * Currently-airing shows use `nextAiringEpisode - 1` so the list only
     * contains episodes that actually exist.
     */
    fun episodes(itemUrl: String): List<ArixAnimeSiteClient.AnimeEpisode> {
        val media = mediaFor(itemUrl) ?: return emptyList()
        var count = media.optInt("episodes", 0)
        if (count <= 0) {
            val next = media.optJSONObject("nextAiringEpisode")?.optInt("episode", 0) ?: 0
            if (next > 0) count = next - 1
        }
        // Unknown episode counts (movies / specials / unaired) still play as
        // a single "Episode 1" so the player never dead-ends.
        if (count <= 0) count = 1
        if (count <= 0) return emptyList()
        val result = mutableListOf<ArixAnimeSiteClient.AnimeEpisode>()
        for (ep in 1..count.coerceAtMost(500)) {
            result.add(
                ArixAnimeSiteClient.AnimeEpisode(
                    number = ep,
                    name = if (count == 1) "Movie / Special" else "Episode $ep",
                    url = "$itemUrl#$ep",
                ),
            )
        }
        return result
    }

    /** Description text for the player header. */
    fun description(itemUrl: String): String {
        val media = mediaFor(itemUrl) ?: return ""
        return media.optString("description")
            .replace(Regex("<[^>]+>"), "")
            .trim()
    }

    /* ---------------------------------------------------------- playback */

    /** IMDb-id lookup cache: AniList media id → Cinemeta IMDb id. */
    private val imdbCache = java.util.concurrent.ConcurrentHashMap<String, String>()

    /**
     * Resolves the IMDb id for an AniList media entry by searching the
     * Cinemeta series catalog with the English (or romaji) title. Cached per
     * media id so episode server lookups only hit Cinemeta once per series.
     */
    private fun resolveImdbId(itemUrl: String): String? {
        imdbCache[itemUrl]?.let { return it }
        val media = mediaFor(itemUrl) ?: return null
        val title = displayTitle(media)
        if (title.isBlank()) return null
        val candidates = listOf(title, title.substringBefore(":").trim())
            .distinct()
        for (candidate in candidates) {
            val url = "https://v3-cinemeta.strem.io/catalog/series/top/search=" +
                android.net.Uri.encode(candidate) + ".json"
            val body = runCatching {
                queryClient.newCall(
                    Request.Builder()
                        .url(url)
                        .header("User-Agent", ArixMediaApi.BrowserUserAgent)
                        .header("Accept", "application/json")
                        .build(),
                ).execute().use { call ->
                    if (!call.isSuccessful) return@use null
                    call.body?.string()
                }
            }.getOrNull() ?: continue
            val metas = runCatching {
                JSONObject(body).optJSONArray("metas")
            }.getOrNull() ?: continue
            for (i in 0 until metas.length()) {
                val meta = metas.optJSONObject(i) ?: continue
                val name = meta.optString("name").lowercase()
                // Loose containment match: "Demon Slayer: Kimetsu no Yaiba"
                // matches "demon slayer" and vice versa.
                val candidateLower = candidate.lowercase()
                if (name.isNotBlank() &&
                    (name.contains(candidateLower) || candidateLower.contains(name))
                ) {
                    val imdbId = meta.optString("id")
                    if (imdbId.startsWith("tt")) {
                        imdbCache[itemUrl] = imdbId
                        return imdbId
                    }
                }
            }
        }
        return null
    }

    /**
     * Free embed-player servers for one episode of an AniList anime.
     * Returns null when the title could not be matched to an IMDb id.
     */
    fun episodeServers(itemUrl: String, episode: Int): ArixAnimeSiteClient.AnimeEpisodeServers? {
        val media = mediaFor(itemUrl)
        val title = media?.let { displayTitle(it) }.orEmpty()
        val description = media?.optString("description")?.replace(Regex("<[^>]+>"), "")?.trim().orEmpty()
        val imdbId = resolveImdbId(itemUrl) ?: return null
        val season = 1
        val servers = listOf(
            ArixAnimeSiteClient.AnimeServer(
                label = "Server 1 · HD",
                language = "Sub",
                url = "https://vidsrc.to/embed/tv/$imdbId/$season-$episode",
            ),
            ArixAnimeSiteClient.AnimeServer(
                label = "Server 2",
                language = "Sub",
                url = "https://www.2embed.cc/embed/tv/$imdbId/$season-$episode",
            ),
            ArixAnimeSiteClient.AnimeServer(
                label = "Server 3",
                language = "Sub",
                url = "https://vidsrc.in/embed/tv/$imdbId/$season-$episode",
            ),
        )
        return ArixAnimeSiteClient.AnimeEpisodeServers(
            title = title,
            source = ArixAnimeSiteClient.SourceAniList,
            episodeNumber = episode,
            episodeName = "Episode $episode",
            servers = servers,
            languages = listOf("Sub"),
        )
    }

    /** Genre list helper (kept for future browse chips). */
    fun genres(media: JSONObject): List<String> {
        val array: JSONArray = media.optJSONArray("genres") ?: return emptyList()
        val result = mutableListOf<String>()
        for (i in 0 until array.length()) {
            array.opt(i)?.toString()?.takeIf { it.isNotBlank() }?.let { result.add(it) }
        }
        return result
    }
}
