package com.arix.app.agentmode

import android.content.ComponentName
import android.content.Context
import android.provider.Settings
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.util.Log

/**
 * No-root notification access for Agent Mode. The listener mirrors the active
 * notification list so the agent can read, filter, and dismiss notifications
 * through the agent_mode tool. Nothing is collected or uploaded elsewhere:
 * the snapshot lives in memory only while the service is bound by the system.
 */
class ArixNotificationListenerService : NotificationListenerService() {

    override fun onListenerConnected() {
        super.onListenerConnected()
        activeListener = this
        Log.i(Tag, "Arix notification listener connected.")
    }

    override fun onListenerDisconnected() {
        activeListener = null
        super.onListenerDisconnected()
    }

    fun snapshot(): List<StatusBarNotification> = runCatching {
        activeNotifications.orEmpty().toList()
    }.getOrDefault(emptyList())

    fun dismiss(key: String): Boolean = runCatching {
        cancelNotification(key)
        true
    }.getOrDefault(false)

    private companion object {
        const val Tag = "ArixNotifications"
    }
}

@Volatile
private var activeListener: ArixNotificationListenerService? = null

object ArixNotificationAccess {
    val isRunning: Boolean
        get() = activeListener != null

    fun service(): ArixNotificationListenerService? = activeListener

    fun isNotificationAccessEnabled(context: Context): Boolean {
        val componentName = ComponentName(context, ArixNotificationListenerService::class.java)
        val rawValue = Settings.Secure.getString(
            context.contentResolver,
            "enabled_notification_listeners",
        ).orEmpty()
        return rawValue.split(':')
            .map { it.trim() }
            .filter { it.isNotBlank() }
            .mapNotNull { runCatching { ComponentName.unflattenFromString(it) }.getOrNull() }
            .any { it == componentName }
    }
}
