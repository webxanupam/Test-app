package com.arix.app.data

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.MultipartBody
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.IOException
import java.security.SecureRandom
import java.util.concurrent.TimeUnit

/**
 * ArixFileShareClient — the File Share tool backend.
 *
 * Uploads any user-picked file to a free public host and returns a direct
 * download URL the user can copy or share. Five independent servers are
 * supported so one host being down (or blocking a network) never kills the
 * tool:
 *
 *  - Server 1 — Filebin.net (POST bin + PUT file, 6-day retention)
 *  - Server 2 — tmpfiles.org (multipart, 100 MB, 60-day retention)
 *  - Server 3 — GoFile.io (server-then-upload flow, generous limits)
 *  - Server 4 — qu.ax (multipart, 30-day retention)
 *  - Server 5 — x0.at (multipart, 32–200 MB, 30+ day retention)
 *
 * v2.4.1: Pixeldrain, 0x0.st and Litterbox were removed after prolonged
 * outages on mobile networks (auth walls, IP blocks, dead endpoints); every
 * replacement was verified to accept anonymous uploads.
 *
 * Every upload streams straight from the content resolver into OkHttp's
 * request body (no full in-memory copies), so multi-hundred-MB files work
 * within ordinary heap limits. All methods perform blocking network IO —
 * call them from Dispatchers.IO.
 */
object ArixFileShareClient {

    /** Server ids, in the order the UI shows them. */
    const val ServerFilebin = "filebin"
    const val ServerTmpFiles = "tmpfiles"
    const val ServerGoFile = "gofile"
    const val ServerQuAx = "quax"
    const val ServerX0 = "x0"

    data class UploadResult(
        val url: String,
        val server: String,
        val fileName: String,
        val sizeBytes: Long,
    )

    private val random = SecureRandom()

    private val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(10, TimeUnit.MINUTES)
        .writeTimeout(10, TimeUnit.MINUTES)
        .followRedirects(true)
        .build()

    /* ------------------------------------------------------------- public */

    /** Human label for a server id. */
    fun serverLabel(serverId: String): String = when (serverId) {
        ServerFilebin -> "Server 1"
        ServerTmpFiles -> "Server 2"
        ServerGoFile -> "Server 3"
        ServerQuAx -> "Server 4"
        ServerX0 -> "Server 5"
        else -> "Server"
    }

    /** Friendly host blurb shown under the server chips. */
    fun serverHint(serverId: String): String = when (serverId) {
        ServerFilebin -> "Filebin.net · 6-day availability"
        ServerTmpFiles -> "tmpfiles.org · up to 100 MB, 60 days"
        ServerGoFile -> "GoFile.io · generous limits, no signup"
        ServerQuAx -> "qu.ax · 30-day retention"
        ServerX0 -> "x0.at · up to 200 MB, 30+ days"
        else -> ""
    }

    /**
     * Uploads the file behind [uri] to [server] and returns the direct
     * download URL. Throws [IOException] with a readable message on failure.
     */
    fun upload(context: Context, uri: Uri, server: String): UploadResult {
        val appContext = context.applicationContext
        val resolver = appContext.contentResolver
        val displayName = queryDisplayName(resolver, uri)
        val size = querySize(resolver, uri)
        val contentType = resolver.getType(uri) ?: "application/octet-stream"
        val mediaType = contentType.toMediaType()
        // Stream the file: RequestBody backed by the resolver's stream.
        val body = object : okhttp3.RequestBody() {
            override fun contentType() = mediaType
            override fun contentLength(): Long = size
            override fun writeTo(sink: okio.BufferedSink) {
                resolver.openInputStream(uri)?.use { input ->
                    val buffer = ByteArray(64 * 1024)
                    while (true) {
                        val read = input.read(buffer)
                        if (read < 0) break
                        sink.write(buffer, 0, read)
                    }
                } ?: throw IOException("The selected file could not be opened.")
            }
        }
        return when (server) {
            ServerFilebin -> uploadToFilebin(body, displayName, size)
            ServerTmpFiles -> uploadToTmpFiles(body, displayName, size)
            ServerGoFile -> uploadToGoFile(body, displayName, size)
            ServerQuAx -> uploadToQuAx(body, displayName, size)
            ServerX0 -> uploadToX0(body, displayName, size)
            else -> error("Unknown upload server.")
        }
    }

    /* ---------------------------------------------------------- providers */

    /**
     * Filebin.net: create a fresh random bin (POST), then PUT the file into
     * it. Download URL: https://filebin.net/<bin>/<file> (browsers and curl
     * both resolve it directly).
     */
    private fun uploadToFilebin(body: okhttp3.RequestBody, fileName: String, size: Long): UploadResult {
        val bin = randomBinId()
        // 1. Create the bin (safe to call even when it already exists).
        val createRequest = Request.Builder()
            .url("https://filebin.net/$bin")
            .header("User-Agent", ArixMediaApi.BrowserUserAgent)
            .header("Accept", "application/json")
            .post(ByteArray(0).toRequestBody(null))
            .build()
        runCatching {
            client.newCall(createRequest).execute().use { response ->
                response.body?.string()
            }
        }
        // 2. Upload the file bytes.
        val putRequest = Request.Builder()
            .url("https://filebin.net/$bin/${urlSafe(fileName)}")
            .header("User-Agent", ArixMediaApi.BrowserUserAgent)
            .header("Accept", applicationJson)
            .header("Content-Type", "application/octet-stream")
            .put(body)
            .build()
        client.newCall(putRequest).execute().use { response ->
            val text = response.body?.string().orEmpty()
            if (!response.isSuccessful) {
                throw IOException("Filebin upload failed (HTTP ${response.code}). Try another server.")
            }
            val filename = runCatching {
                JSONObject(text).optJSONObject("file")?.optString("filename").orEmpty()
            }.getOrDefault("")
            val finalName = filename.takeIf { it.isNotBlank() } ?: fileName
            return UploadResult(
                url = "https://filebin.net/$bin/${urlSafe(finalName)}",
                server = ServerFilebin,
                fileName = finalName,
                sizeBytes = size,
            )
        }
    }

    /**
     * tmpfiles.org: POST https://tmpfiles.org/api/v1/upload (multipart
     * "file"). Response JSON: {"status":"success","data":{"url": ...}}.
     * The returned page URL becomes a direct link by inserting /dl/.
     */
    private fun uploadToTmpFiles(body: okhttp3.RequestBody, fileName: String, size: Long): UploadResult {
        val multipart = MultipartBody.Builder()
            .setType(MultipartBody.FORM)
            .addFormDataPart("file", fileName, body)
            .build()
        val request = Request.Builder()
            .url("https://tmpfiles.org/api/v1/upload")
            .header("User-Agent", ArixMediaApi.BrowserUserAgent)
            .post(multipart)
            .build()
        client.newCall(request).execute().use { response ->
            val text = response.body?.string().orEmpty()
            if (!response.isSuccessful) {
                throw IOException("tmpfiles.org upload failed (HTTP ${response.code}). Try another server.")
            }
            val pageUrl = runCatching {
                JSONObject(text).optJSONObject("data")?.optString("url").orEmpty()
            }.getOrDefault("")
            if (pageUrl.isBlank()) {
                throw IOException("tmpfiles.org did not return a link. Try another server.")
            }
            // https://tmpfiles.org/<id>/<name> -> https://tmpfiles.org/dl/<id>/<name>
            val directUrl = if (pageUrl.contains("/dl/")) pageUrl else pageUrl.replaceFirst("/([^/]+)/([^/]+)$".toRegex(), "/dl/$1/$2")
            return UploadResult(
                url = directUrl,
                server = ServerTmpFiles,
                fileName = fileName,
                sizeBytes = size,
            )
        }
    }

    /**
     * GoFile.io: ask https://api.gofile.io/servers for the best upload
     * server, then POST the file to https://<server>.gofile.io/contents/
     * uploadfile. Response JSON carries data.downloadPage.
     */
    private fun uploadToGoFile(body: okhttp3.RequestBody, fileName: String, size: Long): UploadResult {
        val serverRequest = Request.Builder()
            .url("https://api.gofile.io/servers")
            .header("User-Agent", ArixMediaApi.BrowserUserAgent)
            .get()
            .build()
        val serverName = client.newCall(serverRequest).execute().use { response ->
            val text = response.body?.string().orEmpty()
            if (!response.isSuccessful) {
                throw IOException("GoFile is not reachable right now (HTTP ${response.code}). Try another server.")
            }
            runCatching {
                JSONObject(text)
                    .optJSONObject("data")
                    ?.optJSONArray("servers")
                    ?.optJSONObject(0)
                    ?.optString("name")
                    .orEmpty()
            }.getOrDefault("")
        }
        if (serverName.isBlank()) {
            throw IOException("GoFile did not provide an upload server. Try another server.")
        }
        val multipart = MultipartBody.Builder()
            .setType(MultipartBody.FORM)
            .addFormDataPart("file", fileName, body)
            .build()
        val uploadRequest = Request.Builder()
            .url("https://$serverName.gofile.io/contents/uploadfile")
            .header("User-Agent", ArixMediaApi.BrowserUserAgent)
            .post(multipart)
            .build()
        client.newCall(uploadRequest).execute().use { response ->
            val text = response.body?.string().orEmpty()
            if (!response.isSuccessful) {
                throw IOException("GoFile upload failed (HTTP ${response.code}). Try another server.")
            }
            val downloadPage = runCatching {
                JSONObject(text).optJSONObject("data")?.optString("downloadPage").orEmpty()
            }.getOrDefault("")
            if (downloadPage.isBlank()) {
                throw IOException("GoFile did not return a link. Try another server.")
            }
            return UploadResult(
                url = downloadPage,
                server = ServerGoFile,
                fileName = fileName,
                sizeBytes = size,
            )
        }
    }

    /**
     * qu.ax: POST https://qu.ax/upload (multipart "files[]"). Response JSON:
     * {"files":[{"url": ...}],"success":true}.
     */
    private fun uploadToQuAx(body: okhttp3.RequestBody, fileName: String, size: Long): UploadResult {
        val multipart = MultipartBody.Builder()
            .setType(MultipartBody.FORM)
            .addFormDataPart("files[]", fileName, body)
            .build()
        val request = Request.Builder()
            .url("https://qu.ax/upload")
            .header("User-Agent", ArixMediaApi.BrowserUserAgent)
            .post(multipart)
            .build()
        client.newCall(request).execute().use { response ->
            val text = response.body?.string().orEmpty()
            if (!response.isSuccessful) {
                throw IOException("qu.ax upload failed (HTTP ${response.code}). Try another server.")
            }
            val url = runCatching {
                JSONObject(text)
                    .optJSONArray("files")
                    ?.optJSONObject(0)
                    ?.optString("url")
                    .orEmpty()
            }.getOrDefault("")
            if (url.isBlank()) {
                throw IOException("qu.ax did not return a link. Try another server.")
            }
            return UploadResult(
                url = url,
                server = ServerQuAx,
                fileName = fileName,
                sizeBytes = size,
            )
        }
    }

    /**
     * x0.at: POST https://x0.at/ (multipart "file"); the plain-text response
     * body is the direct URL.
     */
    private fun uploadToX0(body: okhttp3.RequestBody, fileName: String, size: Long): UploadResult {
        val multipart = MultipartBody.Builder()
            .setType(MultipartBody.FORM)
            .addFormDataPart("file", fileName, body)
            .build()
        val request = Request.Builder()
            .url("https://x0.at/")
            .header("User-Agent", "ArixFileShare/2.4 (Android; file sharing tool)")
            .post(multipart)
            .build()
        client.newCall(request).execute().use { response ->
            val text = response.body?.string()?.trim().orEmpty()
            if (!response.isSuccessful || !text.startsWith("http")) {
                throw IOException("x0.at is not reachable from this network (HTTP ${response.code}). Try another server.")
            }
            return UploadResult(
                url = text.substringBefore('\n'),
                server = ServerX0,
                fileName = fileName,
                sizeBytes = size,
            )
        }
    }

    /* -------------------------------------------------------------- utils */

    private const val applicationJson = "application/json"
    private val BinChars = "abcdefghjkmnpqrstuvwxyz23456789"

    private fun randomBinId(): String {
        val sb = StringBuilder("arix")
        repeat(14) {
            sb.append(BinChars[random.nextInt(BinChars.length)])
        }
        return sb.toString()
    }

    private fun urlSafe(name: String): String =
        name.replace(Regex("[^A-Za-z0-9._ ()-]"), "_").take(120).ifBlank { "file.bin" }

    private fun queryDisplayName(
        resolver: android.content.ContentResolver,
        uri: Uri,
    ): String = runCatching {
        resolver.query(uri, null, null, null, null)?.use { cursor ->
            if (cursor.moveToFirst()) {
                val index = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (index >= 0) cursor.getString(index) else null
            } else {
                null
            }
        }
    }.getOrNull()
        ?: uri.lastPathSegment?.substringAfterLast('/')?.substringAfter(':')
        ?: "arix-${System.currentTimeMillis()}.bin"

    private fun querySize(
        resolver: android.content.ContentResolver,
        uri: Uri,
    ): Long = runCatching {
        resolver.query(uri, null, null, null, null)?.use { cursor ->
            if (cursor.moveToFirst()) {
                val index = cursor.getColumnIndex(OpenableColumns.SIZE)
                if (index >= 0) cursor.getLong(index).takeIf { it > 0 } else null
            } else {
                null
            }
        }
    }.getOrNull() ?: -1L

    /** Formats a byte count for the result card. */
    fun formatBytes(bytes: Long): String {
        if (bytes <= 0) return "unknown size"
        val kb = bytes / 1024.0
        val mb = kb / 1024.0
        val gb = mb / 1024.0
        return when {
            gb >= 1 -> "%.2f GB".format(gb)
            mb >= 1 -> "%.1f MB".format(mb)
            kb >= 1 -> "%.0f KB".format(kb)
            else -> "$bytes B"
        }
    }
}
