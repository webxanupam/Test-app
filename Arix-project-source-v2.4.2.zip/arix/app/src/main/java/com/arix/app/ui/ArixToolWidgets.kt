package com.arix.app.ui

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import com.arix.app.data.ArixAnimeSiteClient
import com.arix.app.data.ArixMediaApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.automirrored.rounded.OpenInNew
import androidx.compose.material.icons.rounded.ChevronRight
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Download
import androidx.compose.material.icons.rounded.Movie
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material.icons.rounded.WarningAmber
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import com.arix.app.R
import com.arix.app.ui.theme.ArixOnPrimary
import com.arix.app.ui.theme.ArixOnSurface
import com.arix.app.ui.theme.ArixOnSurfaceVariant
import com.arix.app.ui.theme.ArixOutline
import com.arix.app.ui.theme.ArixPrimary
import com.arix.app.ui.theme.ArixSurfaceHigh
import com.arix.app.ui.theme.ArixSurfaceHigher
import java.io.File
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import okhttp3.OkHttpClient
import org.json.JSONObject

/**
 * Native in-chat widgets for bundled tool results.
 *
 * The QR Code Generator, Movie Explorer, and Anime Explorer extensions return
 * a structured `output_json` payload with every tool result; these widgets
 * render that payload directly in the conversation (image cards, poster
 * grids, and multi-server players) without depending on the extension UI
 * runtime. Instant native system commands (open app / settings / url) render
 * a compact result card as well.
 */

/* ------------------------------------------------------------------ models */

data class ArixQrWidgetModel(
    val data: String,
    val kind: String,
    val base64: String,
    val size: Int,
    val provider: String,
)

data class ArixMovieItemModel(
    val title: String,
    val url: String,
    val thumbnail: String,
    val views: String,
)

data class ArixMovieServerModel(
    val label: String,
    val url: String,
    /** Directly playable .mp4/.m3u8 stream resolved from the embed page.
     *  When present the player uses the built-in video stage instead of the
     *  embed host's own (often broken / captcha-walled) player. */
    val directUrl: String = "",
    /** Page origin the stream CDN expects in the Referer header (empty for
     *  servers that serve media without referer checks). */
    val pageOrigin: String = "",
)

data class ArixMovieDownloadModel(
    val quality: String,
    val label: String,
    val url: String,
)

data class ArixMovieListModel(
    val mode: String,
    val query: String,
    val page: Int,
    val results: List<ArixMovieItemModel>,
)

data class ArixMoviePlayerModel(
    val title: String,
    val description: String,
    val thumbnail: String,
    val url: String,
    val servers: List<ArixMovieServerModel>,
    val downloads: List<ArixMovieDownloadModel>,
)

data class ArixAnimeItemModel(
    val title: String,
    val url: String,
    val thumbnail: String,
    val source: String,
)

data class ArixAnimeEpisodeModel(
    val number: Int,
    val name: String,
    val url: String,
)

data class ArixAnimeServerModel(
    val label: String,
    val language: String,
    val url: String,
)

data class ArixAnimeListModel(
    val mode: String,
    val query: String,
    val page: Int,
    val results: List<ArixAnimeItemModel>,
)

data class ArixAnimePlayerModel(
    val title: String,
    val thumbnail: String,
    val source: String,
    val url: String,
    val description: String,
    val episodes: List<ArixAnimeEpisodeModel>,
    val servers: List<ArixAnimeServerModel>,
    val languages: List<String>,
    val selectedEpisode: Int,
    val episodeName: String,
)

data class ArixSystemResultModel(
    val ok: Boolean,
    val title: String,
    val detail: String,
)

/** Parsed widget payload from a tool invocation's structured output. */
sealed interface ArixToolWidgetPayload {
    data class Qr(val model: ArixQrWidgetModel) : ArixToolWidgetPayload
    data class MovieList(val model: ArixMovieListModel) : ArixToolWidgetPayload
    data class MoviePlayer(val model: ArixMoviePlayerModel) : ArixToolWidgetPayload
    data class AnimeList(val model: ArixAnimeListModel) : ArixToolWidgetPayload
    data class AnimePlayer(val model: ArixAnimePlayerModel) : ArixToolWidgetPayload
    data class SystemResult(val model: ArixSystemResultModel) : ArixToolWidgetPayload
}

internal fun parseArixToolWidgetPayload(outputJson: String): ArixToolWidgetPayload? {
    if (outputJson.isBlank()) return null
    val output = runCatching { JSONObject(outputJson) }.getOrNull() ?: return null
    return when (output.optString("widget")) {
        "qr_code" -> {
            val base64 = output.optString("base64")
            if (base64.isBlank()) return null
            ArixToolWidgetPayload.Qr(
                ArixQrWidgetModel(
                    data = output.optString("data"),
                    kind = output.optString("kind").ifBlank { "Text" },
                    base64 = base64,
                    size = output.optInt("size", 300),
                    provider = output.optString("provider"),
                ),
            )
        }

        "movie_list" -> {
            val results = output.optJSONArray("results") ?: return null
            val items = buildList {
                for (index in 0 until results.length()) {
                    val entry = results.optJSONObject(index) ?: continue
                    val title = entry.optString("title")
                    val url = entry.optString("url")
                    if (title.isBlank() || url.isBlank()) continue
                    add(
                        ArixMovieItemModel(
                            title = title,
                            url = url,
                            thumbnail = entry.optString("thumbnail"),
                            views = entry.optString("views"),
                        ),
                    )
                }
            }
            if (items.isEmpty()) return null
            ArixToolWidgetPayload.MovieList(
                ArixMovieListModel(
                    mode = output.optString("mode", "latest"),
                    query = output.optString("query"),
                    page = output.optInt("page", 1),
                    results = items,
                ),
            )
        }

        "movie_player" -> {
            val servers = buildList {
                val array = output.optJSONArray("servers")
                if (array != null) {
                    for (index in 0 until array.length()) {
                        val entry = array.optJSONObject(index) ?: continue
                        val url = entry.optString("url")
                        if (url.startsWith("http")) {
                            add(
                                ArixMovieServerModel(
                                    label = entry.optString("label").ifBlank { "Player ${index + 1}" },
                                    url = url,
                                    directUrl = entry.optString("direct_url"),
                                ),
                            )
                        }
                    }
                }
            }
            val downloads = buildList {
                val array = output.optJSONArray("downloads")
                if (array != null) {
                    for (index in 0 until array.length()) {
                        val entry = array.optJSONObject(index) ?: continue
                        val url = entry.optString("url")
                        if (url.startsWith("http")) {
                            add(
                                ArixMovieDownloadModel(
                                    quality = entry.optString("quality"),
                                    label = entry.optString("label").ifBlank { "Download ${index + 1}" },
                                    url = url,
                                ),
                            )
                        }
                    }
                }
            }
            ArixToolWidgetPayload.MoviePlayer(
                ArixMoviePlayerModel(
                    title = output.optString("title"),
                    description = output.optString("description"),
                    thumbnail = output.optString("thumbnail"),
                    url = output.optString("url"),
                    servers = servers,
                    downloads = downloads,
                ),
            )
        }

        "anime_list" -> {
            val results = output.optJSONArray("results") ?: return null
            val items = buildList {
                for (index in 0 until results.length()) {
                    val entry = results.optJSONObject(index) ?: continue
                    val title = entry.optString("title")
                    val url = entry.optString("url")
                    if (title.isBlank() || url.isBlank()) continue
                    add(
                        ArixAnimeItemModel(
                            title = title,
                            url = url,
                            thumbnail = entry.optString("thumbnail"),
                            source = entry.optString("source"),
                        ),
                    )
                }
            }
            if (items.isEmpty()) return null
            ArixToolWidgetPayload.AnimeList(
                ArixAnimeListModel(
                    mode = output.optString("mode", "latest"),
                    query = output.optString("query"),
                    page = output.optInt("page", 1),
                    results = items,
                ),
            )
        }

        "anime_player" -> {
            val episodes = buildList {
                val array = output.optJSONArray("episodes")
                if (array != null) {
                    for (index in 0 until array.length()) {
                        val entry = array.optJSONObject(index) ?: continue
                        add(
                            ArixAnimeEpisodeModel(
                                number = entry.optInt("number", index + 1),
                                name = entry.optString("name"),
                                url = entry.optString("url"),
                            ),
                        )
                    }
                }
            }
            val servers = buildList {
                val array = output.optJSONArray("servers")
                if (array != null) {
                    for (index in 0 until array.length()) {
                        val entry = array.optJSONObject(index) ?: continue
                        val url = entry.optString("url")
                        if (url.startsWith("http")) {
                            add(
                                ArixAnimeServerModel(
                                    label = entry.optString("label").ifBlank { "Server ${index + 1}" },
                                    language = entry.optString("language"),
                                    url = url,
                                ),
                            )
                        }
                    }
                }
            }
            val languages = buildList {
                val array = output.optJSONArray("languages")
                if (array != null) {
                    for (index in 0 until array.length()) add(array.optString(index))
                }
            }
            if (episodes.isEmpty() && servers.isEmpty()) return null
            ArixToolWidgetPayload.AnimePlayer(
                ArixAnimePlayerModel(
                    title = output.optString("title"),
                    thumbnail = output.optString("thumbnail"),
                    source = output.optString("source", "animelok"),
                    url = output.optString("url"),
                    description = output.optString("description"),
                    episodes = episodes,
                    servers = servers,
                    languages = languages,
                    selectedEpisode = output.optInt("selected_episode", output.optInt("episode_number", 0)),
                    episodeName = output.optString("episode_name"),
                ),
            )
        }

        "system_result" -> {
            val detail = output.optString("detail")
            val title = output.optString("title")
            if (detail.isBlank() && title.isBlank()) return null
            ArixToolWidgetPayload.SystemResult(
                ArixSystemResultModel(
                    ok = output.optBoolean("ok", true),
                    title = title,
                    detail = detail,
                ),
            )
        }

        else -> null
    }
}

private fun Modifier.widgetNoRippleClickable(onClick: () -> Unit): Modifier = composed {
    clickable(
        enabled = true,
        indication = null,
        interactionSource = remember { MutableInteractionSource() },
        onClick = onClick,
    )
}

/* ----------------------------------------------------------------- widgets */

/** Renders the native widget for a completed tool invocation, when present. */
@Composable
fun ArixToolResultWidget(
    toolName: String,
    outputJson: String,
    modifier: Modifier = Modifier,
) {
    val payload = remember(toolName, outputJson) {
        if (toolName in setOf("qr_code", "movie_explorer", "anime_explorer", "system_control")) {
            parseArixToolWidgetPayload(outputJson)
        } else {
            null
        }
    }
    when (payload) {
        is ArixToolWidgetPayload.Qr -> QrCodeWidget(payload.model, modifier)
        is ArixToolWidgetPayload.MovieList -> MovieListWidget(payload.model, modifier)
        is ArixToolWidgetPayload.MoviePlayer -> MoviePlayerWidget(payload.model, modifier)
        is ArixToolWidgetPayload.AnimeList -> AnimeListWidget(payload.model, modifier)
        is ArixToolWidgetPayload.AnimePlayer -> AnimePlayerWidget(payload.model, modifier)
        is ArixToolWidgetPayload.SystemResult -> SystemResultWidget(payload.model, modifier)
        null -> Unit
    }
}

@Composable
internal fun QrCodeWidget(
    model: ArixQrWidgetModel,
    modifier: Modifier = Modifier,
) {
    val context = LocalContext.current
    val bitmap = remember(model.base64) {
        runCatching {
            val bytes = android.util.Base64.decode(model.base64, android.util.Base64.DEFAULT)
            BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
        }.getOrNull()
    }
    var saving by remember { mutableStateOf(false) }
    var sharing by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    val downloadLabel = stringResource(R.string.widget_qr_download)
    val shareLabel = stringResource(R.string.widget_qr_share)
    val savedLabel = stringResource(R.string.widget_qr_saved)
    val failedLabel = stringResource(R.string.widget_qr_download_failed)
    val shareFailedLabel = stringResource(R.string.widget_qr_share_failed)

    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .background(ArixSurfaceHigh)
            .border(1.dp, ArixOutline.copy(alpha = 0.6f), RoundedCornerShape(18.dp))
            .padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            bitmap?.let {
                Image(
                    bitmap = it.asImageBitmap(),
                    contentDescription = stringResource(R.string.widget_qr_image_description),
                    modifier = Modifier
                        .size(148.dp)
                        .clip(RoundedCornerShape(14.dp))
                        .background(androidx.compose.ui.graphics.Color.White)
                        .padding(6.dp),
                    contentScale = ContentScale.Fit,
                )
            }
            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(4.dp),
            ) {
                Text(
                    text = model.data,
                    style = MaterialTheme.typography.bodyMedium,
                    color = ArixOnSurface,
                    maxLines = 3,
                    overflow = TextOverflow.Ellipsis,
                    fontWeight = FontWeight.Medium,
                )
                Text(
                    text = model.kind,
                    style = MaterialTheme.typography.labelMedium,
                    color = ArixPrimary,
                )
                Text(
                    text = "${model.size}×${model.size} · ${model.provider}",
                    style = MaterialTheme.typography.labelSmall,
                    color = ArixOnSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }
        }
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            ArixWidgetActionButton(
                label = downloadLabel,
                icon = Icons.Rounded.Download,
                primary = true,
                enabled = !saving && bitmap != null,
                modifier = Modifier.weight(1f),
            ) {
                saving = true
                scope.launch {
                    val result = withContext(Dispatchers.IO) {
                        runCatching {
                            val bytes = android.util.Base64.decode(model.base64, android.util.Base64.DEFAULT)
                            ArixMediaDownloads.saveToDownloads(
                                context = context,
                                displayName = "qr-code-${System.currentTimeMillis()}.png",
                                mimeType = "image/png",
                                bytes = bytes,
                            )
                        }
                    }
                    saving = false
                    val message = if (result.isSuccess) savedLabel else failedLabel
                    android.widget.Toast.makeText(context, message, android.widget.Toast.LENGTH_SHORT).show()
                }
            }
            ArixWidgetActionButton(
                label = shareLabel,
                icon = Icons.Rounded.Share,
                primary = false,
                enabled = !sharing && bitmap != null,
                modifier = Modifier.weight(1f),
            ) {
                sharing = true
                scope.launch {
                    val ok = withContext(Dispatchers.IO) {
                        ArixQrShare.sharePng(
                            context = context,
                            bytes = android.util.Base64.decode(model.base64, android.util.Base64.DEFAULT),
                        )
                    }
                    sharing = false
                    if (!ok) {
                        android.widget.Toast.makeText(context, shareFailedLabel, android.widget.Toast.LENGTH_SHORT).show()
                    }
                }
            }
        }
    }
}

@Composable
internal fun ArixWidgetActionButton(
    label: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    primary: Boolean,
    enabled: Boolean = true,
    modifier: Modifier = Modifier,
    onClick: () -> Unit,
) {
    val container = if (primary) ArixPrimary else ArixSurfaceHigher
    val content = if (primary) ArixOnPrimary else ArixOnSurface
    Row(
        modifier = modifier
            .clip(RoundedCornerShape(12.dp))
            .background(if (enabled) container else ArixSurfaceHigher)
            .padding(horizontal = 14.dp, vertical = 10.dp)
            .let { if (enabled) it.widgetNoRippleClickable(onClick = onClick) else it },
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            modifier = Modifier.size(18.dp),
            tint = if (enabled) content else ArixOnSurfaceVariant,
        )
        Text(
            text = label,
            style = MaterialTheme.typography.labelLarge,
            color = if (enabled) content else ArixOnSurfaceVariant,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
        )
    }
}

/** Loads a poster into an [ImageBitmap] through the media backend: memory
 *  cache → disk cache → direct origin → resizing proxy fallback. Posters
 *  are downloaded at most once per cache lifetime. Renders a quiet poster
 *  placeholder when the image cannot be fetched (v2.3.2 — previously an
 *  endless spinner). */
@Composable
internal fun rememberRemoteImage(url: String): ImageBitmap? {
    return produceState<ImageBitmap?>(initialValue = null, url) {
        if (url.isBlank()) return@produceState
        value = withContext(Dispatchers.IO) {
            ArixMediaApi.loadPoster(url, widthPx = 244)?.asImageBitmap()
        }
    }.value
}

/** True once a poster fetch has definitively failed for this URL. */
@Composable
internal fun rememberRemoteImageFailed(url: String): Boolean {
    return produceState(initialValue = false, url) {
        if (url.isBlank()) {
            value = true
            return@produceState
        }
        val failed = withTimeoutOrNull(30_000L) {
            withContext(Dispatchers.IO) { ArixMediaApi.loadPoster(url, widthPx = 244) == null }
        } ?: true
        value = failed == true
    }.value
}

@Composable
internal fun MoviePosterCard(
    item: ArixMovieItemModel,
    cardWidth: androidx.compose.ui.unit.Dp,
    onPlay: () -> Unit,
) {
    val poster = rememberRemoteImage(item.thumbnail)
    val posterFailed = poster == null && rememberRemoteImageFailed(item.thumbnail)
    Column(
        modifier = Modifier
            .width(cardWidth)
            .clip(RoundedCornerShape(14.dp))
            .background(ArixSurfaceHigher)
            .padding(6.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .aspectRatio(0.68f)
                .clip(RoundedCornerShape(10.dp))
                .background(ArixSurfaceHigh),
            contentAlignment = Alignment.Center,
        ) {
            if (poster != null) {
                Image(
                    bitmap = poster,
                    contentDescription = item.title,
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop,
                )
            } else if (posterFailed) {
                // Quiet placeholder instead of an endless spinner.
                Icon(
                    imageVector = Icons.Rounded.Movie,
                    contentDescription = null,
                    modifier = Modifier.size(30.dp),
                    tint = ArixOnSurfaceVariant.copy(alpha = 0.5f),
                )
            } else {
                CircularProgressIndicator(
                    modifier = Modifier.size(22.dp),
                    strokeWidth = 2.dp,
                    color = ArixPrimary,
                )
            }
        }
        Text(
            text = item.title,
            style = MaterialTheme.typography.labelSmall,
            color = ArixOnSurface,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.padding(horizontal = 2.dp),
        )
        ArixWidgetActionButton(
            label = stringResource(R.string.widget_movie_play),
            icon = Icons.Rounded.PlayArrow,
            primary = true,
            modifier = Modifier.fillMaxWidth(),
            onClick = onPlay,
        )
    }
}

@Composable
internal fun MovieListWidget(
    model: ArixMovieListModel,
    modifier: Modifier = Modifier,
) {
    // When the user taps Play on a poster, the widget resolves that movie's
    // servers natively (proxied fetch, no agent round-trip) and swaps the
    // rail for the player. Back returns to the rail.
    var playingUrl by remember(model) { mutableStateOf<String?>(null) }
    var loadingUrl by remember(model) { mutableStateOf<String?>(null) }
    var playerModel by remember(model) { mutableStateOf<ArixMoviePlayerModel?>(null) }
    var playError by remember(model) { mutableStateOf("") }
    val scope = rememberCoroutineScope()

    playingUrl?.let { url ->
        val loaded = playerModel
        if (loaded != null && loadingUrl == null) {
            MoviePlayerWidget(loaded, modifier) { playingUrl = null }
            return
        }
    }

    val header = if (model.mode == "search") {
        stringResource(R.string.widget_movie_search_results, model.query, model.results.size)
    } else {
        stringResource(R.string.widget_movie_latest_results, model.results.size)
    }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .background(ArixSurfaceHigh)
            .border(1.dp, ArixOutline.copy(alpha = 0.6f), RoundedCornerShape(18.dp))
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(
                text = header,
                style = MaterialTheme.typography.labelLarge,
                color = ArixOnSurface,
                fontWeight = FontWeight.SemiBold,
                modifier = Modifier.weight(1f),
            )
            Icon(
                imageVector = Icons.Rounded.ChevronRight,
                contentDescription = null,
                modifier = Modifier.size(18.dp),
                tint = ArixOnSurfaceVariant,
            )
        }
        if (loadingUrl != null || playError.isNotBlank()) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                if (loadingUrl != null) {
                    CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp, color = ArixPrimary)
                    Text(
                        text = stringResource(R.string.widget_movie_resolving),
                        style = MaterialTheme.typography.bodySmall,
                        color = ArixOnSurfaceVariant,
                    )
                } else if (playError.isNotBlank()) {
                    Text(
                        text = playError,
                        style = MaterialTheme.typography.bodySmall,
                        color = androidx.compose.ui.graphics.Color(0xFFE5757A),
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f),
                    )
                }
            }
        }
        // Horizontal poster rail — scrolls sideways independently of the
        // chat list, which fixes the "scrolling moves the chat" conflict.
        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            modifier = Modifier.fillMaxWidth(),
        ) {
            items(
                model.results,
                key = { item -> item.url },
            ) { item ->
                MoviePosterCard(item, cardWidth = 122.dp) {
                    playError = ""
                    loadingUrl = item.url
                    scope.launch {
                        val detail = withContext(Dispatchers.IO) {
                            runCatching { MovieSiteClient.fetchDetail(item.url) }.getOrNull()
                        }
                        loadingUrl = null
                        if (detail != null) {
                            playerModel = detail
                            playingUrl = item.url
                        } else {
                            playError = "Could not resolve the servers for \"${item.title.take(40)}\"."
                        }
                    }
                }
            }
        }
    }
}

@Composable
internal fun MoviePlayerWidget(
    model: ArixMoviePlayerModel,
    modifier: Modifier = Modifier,
    onBack: (() -> Unit)? = null,
) {
    val context = LocalContext.current
    var selectedServer by remember(model.url) { mutableStateOf(model.servers.firstOrNull()) }
    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .background(ArixSurfaceHigh)
            .border(1.dp, ArixOutline.copy(alpha = 0.6f), RoundedCornerShape(18.dp))
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            if (onBack != null) {
                Icon(
                    imageVector = Icons.AutoMirrored.Rounded.ArrowBack,
                    contentDescription = stringResource(R.string.widget_movie_back),
                    modifier = Modifier
                        .size(28.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .widgetNoRippleClickable(onClick = onBack)
                        .padding(3.dp),
                    tint = ArixOnSurfaceVariant,
                )
            }
            Text(
                text = model.title.ifBlank { stringResource(R.string.widget_movie_unknown_title) },
                style = MaterialTheme.typography.titleSmall,
                color = ArixOnSurface,
                fontWeight = FontWeight.SemiBold,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.weight(1f),
            )
        }
        if (model.description.isNotBlank()) {
            Text(
                text = model.description,
                style = MaterialTheme.typography.bodySmall,
                color = ArixOnSurfaceVariant,
                maxLines = 3,
                overflow = TextOverflow.Ellipsis,
            )
        }
        // Server chips
        if (model.servers.size > 1) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                model.servers.forEachIndexed { index, server ->
                    val selected = server == selectedServer
                    Text(
                        text = server.label.take(24),
                        style = MaterialTheme.typography.labelMedium,
                        color = if (selected) ArixOnPrimary else ArixOnSurface,
                        maxLines = 1,
                        modifier = Modifier
                            .clip(RoundedCornerShape(10.dp))
                            .background(if (selected) ArixPrimary else ArixSurfaceHigher)
                            .widgetNoRippleClickable { selectedServer = server }
                            .padding(horizontal = 12.dp, vertical = 7.dp),
                    )
                }
            }
        }
        // Native player stage (v2.3.2): ExoPlayer with explicit Referer/UA
        // headers — the WebView player 429'd on the referer-checking CDNs and
        // hls.js XHR died on CORS. Embed hosts without a resolved direct
        // stream still load through the hardened embed WebView.
        selectedServer?.let { server ->
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(16f / 9f)
                    .clip(RoundedCornerShape(12.dp))
                    .background(androidx.compose.ui.graphics.Color(0xFF0A0A0E)),
            ) {
                if (server.directUrl.isNotBlank()) {
                    ArixVideoPlayer(
                        streamUrl = server.directUrl,
                        referer = server.pageOrigin,
                        posterUrl = model.thumbnail,
                    )
                } else {
                    MovieEmbedWebView(url = server.url)
                }
            }
        } ?: Text(
            text = stringResource(R.string.widget_movie_no_servers),
            style = MaterialTheme.typography.bodySmall,
            color = ArixOnSurfaceVariant,
        )
        // Download links
        if (model.downloads.isNotEmpty()) {
            Text(
                text = stringResource(R.string.widget_movie_downloads, model.downloads.size),
                style = MaterialTheme.typography.labelLarge,
                color = ArixOnSurface,
                fontWeight = FontWeight.SemiBold,
            )
            model.downloads.take(8).forEach { download ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                        .background(ArixSurfaceHigher)
                        .widgetNoRippleClickable { openExternally(context, download.url) }
                        .padding(horizontal = 10.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    Text(
                        text = listOfNotNull(
                            download.quality.takeIf { it.isNotBlank() },
                            download.label.take(36),
                        ).joinToString(" · "),
                        style = MaterialTheme.typography.bodySmall,
                        color = ArixOnSurface,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f),
                    )
                    Icon(
                        imageVector = Icons.AutoMirrored.Rounded.OpenInNew,
                        contentDescription = stringResource(R.string.widget_movie_open),
                        modifier = Modifier.size(16.dp),
                        tint = ArixPrimary,
                    )
                }
            }
        }
    }
}

private fun openExternally(context: Context, url: String) {
    runCatching {
        context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }
}

/** Origin of a URL (scheme + host), or an empty string when unparseable. */
private fun serverOrigin(url: String): String = runCatching {
    val parsed = java.net.URI(url)
    buildString {
        if (parsed.scheme != null) append(parsed.scheme).append("://")
        if (parsed.host != null) append(parsed.host)
        append('/')
    }
}.getOrDefault("")

@SuppressLint("SetJavaScriptEnabled")
@Composable
private fun MovieEmbedWebView(url: String) {
    ArixEmbedWebView(url = url)
}

/**
 * Hardened embed player stage shared by the movie and anime players:
 *  - desktop-Chrome user agent (several embed hosts redirect mobile UAs)
 *  - DOM storage + autoplay + wide viewport
 *  - popup blocking: `window.open` / target=_blank attempts are swallowed by
 *    a WebChromeClient that never creates the new window, so ad popups can
 *    no longer navigate the player away
 *  - a compact error overlay with a Retry button when the embed fails to load
 */
@SuppressLint("SetJavaScriptEnabled")
@Composable
private fun ArixEmbedWebView(
    url: String,
    referer: String? = null,
) {
    var loadError by remember(url) { mutableStateOf(false) }
    var reloadKey by remember(url) { mutableStateOf(0) }
    AndroidView(
        factory = { context ->
            WebView(context).apply {
                setBackgroundColor(android.graphics.Color.TRANSPARENT)
                settings.javaScriptEnabled = true
                settings.domStorageEnabled = true
                settings.databaseEnabled = true
                settings.mediaPlaybackRequiresUserGesture = false
                settings.allowFileAccess = true
                settings.allowContentAccess = true
                settings.useWideViewPort = true
                settings.loadWithOverviewMode = true
                settings.setSupportZoom(false)
                settings.displayZoomControls = false
                settings.userAgentString = ArixMediaApi.BrowserUserAgent
                settings.mixedContentMode = android.webkit.WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
                // Block popups/new windows: embed hosts love window.open ads.
                settings.setSupportMultipleWindows(true)
                settings.javaScriptCanOpenWindowsAutomatically = false
                webViewClient = object : WebViewClient() {
                    @Deprecated("Deprecated in Java")
                    override fun onReceivedError(
                        view: WebView?,
                        errorCode: Int,
                        description: String?,
                        failingUrl: String?,
                    ) {
                        if (errorCode == ERROR_HOST_LOOKUP || errorCode == ERROR_CONNECT ||
                            errorCode == ERROR_TIMEOUT || errorCode == ERROR_UNKNOWN
                        ) {
                            loadError = true
                        }
                    }

                    override fun onReceivedError(
                        view: WebView?,
                        request: WebResourceRequest?,
                        error: WebResourceError?,
                    ) {
                        if (request?.isForMainFrame == true) loadError = true
                    }
                }
                webChromeClient = object : WebChromeClient() {
                    // Swallow new-window requests (popup ads) — never create them.
                    override fun onCreateWindow(
                        view: WebView?,
                        isDialog: Boolean,
                        isUserGesture: Boolean,
                        resultMsg: android.os.Message?,
                    ): Boolean {
                        // Popups are blocked outright — never create them.
                        return false
                    }
                }
                referer?.let { value ->
                    loadUrl(url, mapOf("Referer" to value))
                } ?: loadUrl(url)
            }
        },
        update = { webView ->
            if (webView.tag != "$url#$reloadKey") {
                webView.tag = "$url#$reloadKey"
                loadError = false
                referer?.let { value ->
                    webView.loadUrl(url, mapOf("Referer" to value))
                } ?: webView.loadUrl(url)
            }
        },
        modifier = Modifier.fillMaxSize(),
    )
    if (loadError) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(androidx.compose.ui.graphics.Color(0xCC101018)),
            contentAlignment = Alignment.Center,
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = stringResource(R.string.widget_embed_failed),
                    style = MaterialTheme.typography.bodySmall,
                    color = ArixOnSurfaceVariant,
                )
                Spacer(Modifier.height(8.dp))
                ArixWidgetActionButton(
                    label = stringResource(R.string.widget_embed_retry),
                    icon = Icons.Rounded.PlayArrow,
                    primary = true,
                ) { reloadKey += 1 }
            }
        }
    }
}

/* ------------------------------------------------------- anime widgets */

@Composable
private fun AnimePosterCard(
    item: ArixAnimeItemModel,
    cardWidth: androidx.compose.ui.unit.Dp,
    onPlay: () -> Unit,
) {
    val poster = rememberRemoteImage(item.thumbnail)
    Column(
        modifier = Modifier
            .width(cardWidth)
            .clip(RoundedCornerShape(14.dp))
            .background(ArixSurfaceHigher)
            .padding(6.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .aspectRatio(0.68f)
                .clip(RoundedCornerShape(10.dp))
                .background(ArixSurfaceHigh),
            contentAlignment = Alignment.Center,
        ) {
            if (poster != null) {
                Image(
                    bitmap = poster,
                    contentDescription = item.title,
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop,
                )
            } else {
                CircularProgressIndicator(
                    modifier = Modifier.size(22.dp),
                    strokeWidth = 2.dp,
                    color = ArixPrimary,
                )
            }
        }
        Text(
            text = item.title,
            style = MaterialTheme.typography.labelSmall,
            color = ArixOnSurface,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.padding(horizontal = 2.dp),
        )
        ArixWidgetActionButton(
            label = stringResource(R.string.widget_anime_watch),
            icon = Icons.Rounded.PlayArrow,
            primary = true,
            modifier = Modifier.fillMaxWidth(),
            onClick = onPlay,
        )
    }
}

/** Anime listing rail — tapping Watch resolves the episode list natively and
 *  swaps the rail for the episode player in place. */
@Composable
internal fun AnimeListWidget(
    model: ArixAnimeListModel,
    modifier: Modifier = Modifier,
) {
    var playingItem by remember(model) { mutableStateOf<ArixAnimeItemModel?>(null) }
    var loadingItem by remember(model) { mutableStateOf<ArixAnimeItemModel?>(null) }
    var playerModel by remember(model) { mutableStateOf<ArixAnimePlayerModel?>(null) }
    var playError by remember(model) { mutableStateOf("") }
    val scope = rememberCoroutineScope()

    playingItem?.let { item ->
        val loaded = playerModel
        if (loaded != null && loadingItem == null) {
            AnimePlayerWidget(loaded, modifier) { playingItem = null }
            return
        }
    }

    val header = if (model.mode == "search") {
        stringResource(R.string.widget_anime_search_results, model.query, model.results.size)
    } else {
        stringResource(R.string.widget_anime_latest_results, model.results.size)
    }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .background(ArixSurfaceHigh)
            .border(1.dp, ArixOutline.copy(alpha = 0.6f), RoundedCornerShape(18.dp))
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(
                text = header,
                style = MaterialTheme.typography.labelLarge,
                color = ArixOnSurface,
                fontWeight = FontWeight.SemiBold,
                modifier = Modifier.weight(1f),
            )
            Icon(
                imageVector = Icons.Rounded.ChevronRight,
                contentDescription = null,
                modifier = Modifier.size(18.dp),
                tint = ArixOnSurfaceVariant,
            )
        }
        if (loadingItem != null || playError.isNotBlank()) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                if (loadingItem != null) {
                    CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp, color = ArixPrimary)
                    Text(
                        text = stringResource(R.string.widget_anime_resolving),
                        style = MaterialTheme.typography.bodySmall,
                        color = ArixOnSurfaceVariant,
                    )
                } else if (playError.isNotBlank()) {
                    Text(
                        text = playError,
                        style = MaterialTheme.typography.bodySmall,
                        color = androidx.compose.ui.graphics.Color(0xFFE5757A),
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f),
                    )
                }
            }
        }
        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            modifier = Modifier.fillMaxWidth(),
        ) {
            items(
                model.results,
                key = { item -> item.url },
            ) { item ->
                AnimePosterCard(item, cardWidth = 122.dp) {
                    playError = ""
                    loadingItem = item
                    scope.launch {
                        val payload = withContext(Dispatchers.IO) {
                            runCatching {
                                val detail = ArixAnimeSiteClient.fetchEpisodes(item.url)
                                    ?: error("No episodes were found for this title.")
                                ArixAnimeSiteClient.detailOutputJson(
                                    detail,
                                    ArixAnimeSiteClient.AnimeItem(
                                        title = item.title,
                                        url = item.url,
                                        thumbnail = item.thumbnail,
                                        source = item.source,
                                    ),
                                )
                            }.getOrNull()
                        }
                        loadingItem = null
                        if (payload != null) {
                            playerModel = (parseArixToolWidgetPayload(payload)
                                as? ArixToolWidgetPayload.AnimePlayer)?.model
                            playingItem = item
                        } else {
                            playError = "Could not load episodes for \"${item.title.take(40)}\" — check your connection and try again."
                        }
                    }
                }
            }
        }
    }
}

/**
 * Anime player card: episode chips + language/server chips + a 16:9 stage.
 * Direct .m3u8 streams play through an inline hls.js page; embed links load
 * through the same hardened WebView used for movies.
 */
@Composable
internal fun AnimePlayerWidget(
    model: ArixAnimePlayerModel,
    modifier: Modifier = Modifier,
    onBack: (() -> Unit)? = null,
) {
    val context = LocalContext.current
    var baseModel by remember(model.url) { mutableStateOf(model) }
    var selectedEpisode by remember(model.url) { mutableStateOf(model.episodes.firstOrNull { it.number == model.selectedEpisode } ?: model.episodes.firstOrNull()) }
    var selectedServer by remember(model.url) { mutableStateOf<ArixAnimeServerModel?>(model.servers.firstOrNull()) }
    var loadingEpisode by remember(model.url) { mutableStateOf(false) }
    var episodeError by remember(model.url) { mutableStateOf("") }
    val scope = rememberCoroutineScope()

    fun loadServers(episode: ArixAnimeEpisodeModel) {
        loadingEpisode = true
        episodeError = ""
        scope.launch {
            val result = withContext(Dispatchers.IO) {
                runCatching {
                    ArixAnimeSiteClient.fetchEpisodeServers(baseModel.url, episode.number, episode.url)
                }.getOrNull()?.let { fetched ->
                    // v2.3.2: probe streams and put reachable servers first so
                    // the default pick is a live one, not a dead CDN.
                    fetched.copy(
                        servers = ArixAnimeSiteClient.prioritizeReachableServers(fetched.servers),
                    )
                }
            }
            loadingEpisode = false
            if (result == null || result.servers.isEmpty()) {
                episodeError = "No stream servers were found for episode ${episode.number}."
                selectedServer = null
                return@launch
            }
            selectedServer = result.servers.firstOrNull()
                ?.let { ArixAnimeServerModel(it.label, it.language, it.url) }
            baseModel = baseModel.copy(
                servers = result.servers.map { ArixAnimeServerModel(it.label, it.language, it.url) },
                languages = result.languages,
                selectedEpisode = episode.number,
                episodeName = result.episodeName,
            )
            selectedEpisode = episode
        }
    }

    // Auto-load servers for the initial episode when none are pre-attached.
    LaunchedEffect(model.url) {
        if (model.servers.isEmpty() && selectedEpisode != null) {
            loadServers(selectedEpisode!!)
        }
    }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .background(ArixSurfaceHigh)
            .border(1.dp, ArixOutline.copy(alpha = 0.6f), RoundedCornerShape(18.dp))
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            if (onBack != null) {
                Icon(
                    imageVector = Icons.AutoMirrored.Rounded.ArrowBack,
                    contentDescription = stringResource(R.string.widget_anime_back),
                    modifier = Modifier
                        .size(28.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .widgetNoRippleClickable(onClick = onBack)
                        .padding(3.dp),
                    tint = ArixOnSurfaceVariant,
                )
            }
            Text(
                text = baseModel.title.ifBlank { stringResource(R.string.widget_anime_unknown_title) },
                style = MaterialTheme.typography.titleSmall,
                color = ArixOnSurface,
                fontWeight = FontWeight.SemiBold,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.weight(1f),
            )
        }
        if (baseModel.episodes.isNotEmpty()) {
            Text(
                text = stringResource(R.string.widget_anime_episodes, baseModel.episodes.size),
                style = MaterialTheme.typography.labelLarge,
                color = ArixOnSurface,
                fontWeight = FontWeight.SemiBold,
            )
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(7.dp),
                modifier = Modifier.fillMaxWidth(),
            ) {
                items(
                    baseModel.episodes,
                    key = { episode -> episode.url.ifBlank { episode.number.toString() } },
                ) { episode ->
                    val selected = episode.number == selectedEpisode?.number
                    Text(
                        text = "${episode.number}",
                        style = MaterialTheme.typography.labelMedium,
                        color = if (selected) ArixOnPrimary else ArixOnSurface,
                        maxLines = 1,
                        modifier = Modifier
                            .clip(RoundedCornerShape(9.dp))
                            .background(if (selected) ArixPrimary else ArixSurfaceHigher)
                            .widgetNoRippleClickable {
                                if (!selected) {
                                    selectedEpisode = episode
                                    loadServers(episode)
                                }
                            }
                            .padding(horizontal = 11.dp, vertical = 6.dp),
                    )
                }
            }
        }
        if (loadingEpisode) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                CircularProgressIndicator(modifier = Modifier.size(16.dp), strokeWidth = 2.dp, color = ArixPrimary)
                Text(
                    text = stringResource(R.string.widget_anime_loading_servers),
                    style = MaterialTheme.typography.bodySmall,
                    color = ArixOnSurfaceVariant,
                )
            }
        } else if (episodeError.isNotBlank()) {
            Text(
                text = episodeError,
                style = MaterialTheme.typography.bodySmall,
                color = androidx.compose.ui.graphics.Color(0xFFE5757A),
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
            )
        }
        // Server / language chips
        if (baseModel.servers.size > 1) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                baseModel.servers.forEachIndexed { index, server ->
                    val selected = server.url == selectedServer?.url
                    Text(
                        text = server.label.take(26),
                        style = MaterialTheme.typography.labelMedium,
                        color = if (selected) ArixOnPrimary else ArixOnSurface,
                        maxLines = 1,
                        modifier = Modifier
                            .clip(RoundedCornerShape(10.dp))
                            .background(if (selected) ArixPrimary else ArixSurfaceHigher)
                            .widgetNoRippleClickable { selectedServer = server }
                            .padding(horizontal = 12.dp, vertical = 7.dp),
                    )
                }
            }
        }
        // Player stage (v2.3.2): direct .m3u8/.mp4 streams play in the native
        // ExoPlayer stage — many anime CDNs reject WebView/hls.js XHR fetches
        // (CORS/522) but accept plain HTTP with a browser UA. Embed pages
        // (abyssplayer, as-cdn26 player shells) keep the hardened WebView.
        selectedServer?.let { server ->
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(16f / 9f)
                    .clip(RoundedCornerShape(12.dp))
                    .background(androidx.compose.ui.graphics.Color(0xFF0A0A0E)),
            ) {
                val playable = remember(server.url) { ArixAnimeSiteClient.playableUrl(server.url) }
                val isDirectStream = playable.endsWith(".m3u8", ignoreCase = true) ||
                    playable.contains(".m3u8?", ignoreCase = true) ||
                    playable.endsWith(".mp4", ignoreCase = true) ||
                    playable.contains(".mp4?", ignoreCase = true)
                if (isDirectStream) {
                    ArixVideoPlayer(
                        streamUrl = playable,
                        referer = when (baseModel.source) {
                            ArixAnimeSiteClient.SourceAnimeSalt -> ArixMediaApi.AnimeSaltBase + "/"
                            ArixAnimeSiteClient.SourceAniList -> {
                                // v2.4.0: AniList provider plays through public
                                // embed hosts — send the embed's own origin.
                                serverOrigin(server.url)
                            }
                            else -> ArixMediaApi.AnimeLokBase + "/"
                        },
                    )
                } else {
                    ArixEmbedWebView(
                        url = playable,
                        referer = when (baseModel.source) {
                            ArixAnimeSiteClient.SourceAnimeSalt -> ArixMediaApi.AnimeSaltBase
                            ArixAnimeSiteClient.SourceAniList -> serverOrigin(server.url)
                            else -> ArixMediaApi.AnimeLokBase
                        },
                    )
                }
            }
        } ?: Text(
            text = stringResource(R.string.widget_anime_no_servers),
            style = MaterialTheme.typography.bodySmall,
            color = ArixOnSurfaceVariant,
        )
        if (baseModel.episodeName.isNotBlank()) {
            Text(
                text = baseModel.episodeName,
                style = MaterialTheme.typography.bodySmall,
                color = ArixOnSurfaceVariant,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
            )
        }
        // Open in browser fallback for the current episode page
        if (baseModel.url.startsWith("http")) {
            ArixWidgetActionButton(
                label = stringResource(R.string.widget_anime_open_page),
                icon = Icons.AutoMirrored.Rounded.OpenInNew,
                primary = false,
                modifier = Modifier.fillMaxWidth(),
            ) {
                openExternally(context, baseModel.url)
            }
        }
    }
}


/* --------------------------------------------------- system result card */

/** Compact card for instant native system commands (open app / settings / url). */
@Composable
internal fun SystemResultWidget(
    model: ArixSystemResultModel,
    modifier: Modifier = Modifier,
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(ArixSurfaceHigh)
            .border(1.dp, ArixOutline.copy(alpha = 0.6f), RoundedCornerShape(14.dp))
            .padding(horizontal = 12.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        Icon(
            imageVector = if (model.ok) Icons.Rounded.CheckCircle else Icons.Rounded.WarningAmber,
            contentDescription = null,
            modifier = Modifier.size(20.dp),
            tint = if (model.ok) ArixPrimary else androidx.compose.ui.graphics.Color(0xFFE5757A),
        )
        Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
            if (model.title.isNotBlank()) {
                Text(
                    text = model.title,
                    style = MaterialTheme.typography.labelLarge,
                    color = ArixOnSurface,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }
            if (model.detail.isNotBlank()) {
                Text(
                    text = model.detail,
                    style = MaterialTheme.typography.bodySmall,
                    color = ArixOnSurfaceVariant,
                    maxLines = 3,
                    overflow = TextOverflow.Ellipsis,
                )
            }
        }
    }
}

/* ------------------------------------------------------- download helper */

/** Shares a QR PNG through the system share sheet via FileProvider. */
object ArixQrShare {
    fun sharePng(context: Context, bytes: ByteArray): Boolean {
        return runCatching {
            val appContext = context.applicationContext
            val shareDir = File(appContext.cacheDir, "qr-share").apply { mkdirs() }
            // Keep only the newest file so the cache never grows unbounded.
            shareDir.listFiles()?.forEach { it.delete() }
            val shareFile = File(shareDir, "arix-qr-code.png")
            shareFile.writeBytes(bytes)
            val uri = androidx.core.content.FileProvider.getUriForFile(
                appContext,
                "${appContext.packageName}.fileprovider",
                shareFile,
            )
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = "image/png"
                putExtra(Intent.EXTRA_STREAM, uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            appContext.startActivity(
                Intent.createChooser(intent, "QR code").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            )
            true
        }.getOrDefault(false)
    }
}

/** Saves media bytes into the system Downloads collection (MediaStore on
 *  Android 10+, the public Downloads directory on older versions). */
object ArixMediaDownloads {
    fun saveToDownloads(
        context: Context,
        displayName: String,
        mimeType: String,
        bytes: ByteArray,
    ): Uri {
        val appContext = context.applicationContext
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val values = android.content.ContentValues().apply {
                put(android.provider.MediaStore.Downloads.DISPLAY_NAME, displayName)
                put(android.provider.MediaStore.Downloads.MIME_TYPE, mimeType)
                put(android.provider.MediaStore.Downloads.IS_PENDING, 1)
            }
            val resolver = appContext.contentResolver
            val collection =
                android.provider.MediaStore.Downloads.getContentUri(android.provider.MediaStore.VOLUME_EXTERNAL_PRIMARY)
            val itemUri = resolver.insert(collection, values)
                ?: error("The download could not be created in the system Downloads store.")
            try {
                resolver.openOutputStream(itemUri)?.use { output ->
                    output.write(bytes)
                    output.flush()
                } ?: error("The download file could not be written.")
                values.clear()
                values.put(android.provider.MediaStore.Downloads.IS_PENDING, 0)
                resolver.update(itemUri, values, null, null)
            } catch (throwable: Throwable) {
                runCatching { resolver.delete(itemUri, null, null) }
                error("The download failed: ${throwable.message}")
            }
            return itemUri
        }
        @Suppress("DEPRECATION")
        val downloadsDirectory = android.os.Environment
            .getExternalStoragePublicDirectory(android.os.Environment.DIRECTORY_DOWNLOADS)
        downloadsDirectory.mkdirs()
        val targetFile = File(downloadsDirectory, displayName)
        targetFile.writeBytes(bytes)
        return Uri.fromFile(targetFile)
    }
}

/* ------------------------------------------------------ movie site client */

/**
 * Native movie-site client used by the poster grid's instant Play button and
 * by the client-side native tool router (instant movie lists / search).
 *
 * v2.2.7: all network access moved to [com.arix.app.data.ArixMediaApi] —
 * DIRECT requests on both mirror domains are raced first (the origin serves
 * plain requests again; the old proxy-first chain wasted 30+ seconds on dead
 * workers.dev mirrors and frequently returned Cloudflare challenge pages
 * that contained no iframes, which is why movies stopped loading), public
 * proxies are only a validated fallback, and every listing/detail response
 * is cached as JSON (memory + disk) so repeat lists resolve instantly.
 */
object MovieSiteClient {

    const val BrowserUserAgent = ArixMediaApi.BrowserUserAgent

    val httpClient: OkHttpClient = ArixMediaApi.httpClient

    private fun decodeEntities(input: String): String = ArixMediaApi.decodeEntities(input)

    private fun normalizeUrl(raw: String): String = ArixMediaApi.normalizeUrl(raw)

    private fun cleanTitle(raw: String): String {
        var title = decodeEntities(raw.replace(Regex("<[^>]+>"), "")).trim()
        if (title.contains(" - ")) title = title.substringBefore(" - ").trim()
        if (title.contains(" | ")) title = title.substringBefore(" | ").trim()
        return title
    }

    /** Scrapes the postbox listing rows (mirrors the extension parser). */
    private fun scrapeList(html: String): List<ArixMovieItemModel> {
        val results = mutableListOf<ArixMovieItemModel>()
        val seen = mutableSetOf<String>()
        val blocks = html.split(Regex("<div[^>]*class=[\"'][^\"']*postbox[^\"']*[\"'][^>]*>", RegexOption.IGNORE_CASE))
        val linkRegex = Regex(
            "<h2[^>]*>\\s*<a[^>]+href=[\"']([^\"']+)[\"'][^>]*(?:title=[\"']([^\"']*)[\"'])?[^>]*>([\\s\\S]*?)</a>",
            RegexOption.IGNORE_CASE,
        )
        val imgRegex = Regex(
            "<img[^>]+?(?:data-wpfc-original-src|data-lazy-src|data-src|src)=[\"']([^\"']+)[\"']",
            RegexOption.IGNORE_CASE,
        )
        val viewsRegex = Regex("class=[\"'][^\"']*views[^\"']*[\"'][^>]*>([^<]+)<", RegexOption.IGNORE_CASE)
        for (block in blocks) {
            val segment = block.take(4000)
            val link = linkRegex.find(segment) ?: continue
            val url = normalizeUrl(decodeEntities(link.groupValues[1]))
            if (!url.startsWith("http") || !seen.add(url)) continue
            val title = cleanTitle(link.groupValues[2].ifBlank { link.groupValues[3] })
            if (title.isBlank()) continue
            var thumbnail = imgRegex.find(segment)?.let {
                normalizeUrl(decodeEntities(it.groupValues[1]))
            }.orEmpty()
            if (ArixMediaApi.isPlaceholderImage(thumbnail)) thumbnail = ""
            val views = viewsRegex.find(segment)?.let {
                decodeEntities(it.groupValues[1]).replace(Regex("^views\\s*:\\s*", RegexOption.IGNORE_CASE), "")
            }.orEmpty()
            results.add(ArixMovieItemModel(title, url, thumbnail, views))
        }
        return results
    }

    /** Latest movies listing (page 1..20) — cached as JSON, instant on repeat. */
    fun fetchLatest(page: Int = 1, limit: Int = 24): List<ArixMovieItemModel> {
        val normalized = page.coerceIn(1, 20)
        val url = if (normalized <= 1) "${ArixMediaApi.WompBase}/" else "${ArixMediaApi.WompBase}/page/$normalized/"
        val html = ArixMediaApi.fetchCachedJson(url, ArixMediaApi.Kind.MOVIE_LIST) {
            ArixMediaApi.fetchPage(url, ArixMediaApi.Kind.MOVIE_LIST)
        }
        return scrapeList(html).take(limit)
    }

    /** Search by name through the classic ?s= results page — cached as JSON. */
    fun search(query: String, limit: Int = 24): List<ArixMovieItemModel> {
        val url = "${ArixMediaApi.WompBase}/?s=${android.net.Uri.encode(query)}"
        val html = ArixMediaApi.fetchCachedJson(url, ArixMediaApi.Kind.MOVIE_LIST) {
            ArixMediaApi.fetchPage(url, ArixMediaApi.Kind.MOVIE_LIST)
        }
        return scrapeList(html).take(limit)
    }

    /** Fetch a movie detail page and resolve servers + download links. */
    fun fetchDetail(pageUrl: String): ArixMoviePlayerModel {
        val html = ArixMediaApi.fetchCachedJson(pageUrl, ArixMediaApi.Kind.MOVIE_DETAIL, ttl = 30 * 60 * 1000L) {
            ArixMediaApi.fetchPage(pageUrl, ArixMediaApi.Kind.MOVIE_DETAIL)
        }
        val servers = mutableListOf<ArixMovieServerModel>()
        val downloads = mutableListOf<ArixMovieDownloadModel>()

        // Players: <h2>label</h2> ... <iframe ...> (iframes on this site are
        // lazy-loaded — the real src lives in data-wpfc-original-src).
        val playerRegex = Regex("<h2[^>]*>([\\s\\S]*?)</h2>\\s*(?:<p[^>]*>)?\\s*(<iframe[^>]*>)", RegexOption.IGNORE_CASE)
        playerRegex.findAll(html).forEach { match ->
            val label = decodeEntities(match.groupValues[1].replace(Regex("<[^>]+>"), "")).trim()
            val iframeTag = match.groupValues[2]
            val src = Regex("(?:data-wpfc-original-src|data-lazy-src|data-src|src)\\s*=\\s*[\"']([^\"']+)[\"']", RegexOption.IGNORE_CASE)
                .find(iframeTag)?.groupValues?.get(1) ?: return@forEach
            val serverUrl = normalizeUrl(decodeEntities(src))
            if (!serverUrl.startsWith("http")) return@forEach
            if (serverUrl.contains("youtube.com/embed") || serverUrl.contains("google.com/maps")) return@forEach
            servers.add(
                ArixMovieServerModel(
                    label = label.replace(Regex("\\s*below\\s*$", RegexOption.IGNORE_CASE), "").trim()
                        .ifBlank { "Player ${servers.size + 1}" },
                    url = serverUrl,
                ),
            )
        }

        // Fallback: every iframe (some pages drop the h2 labels)
        if (servers.isEmpty()) {
            Regex("<iframe[^>]*>", RegexOption.IGNORE_CASE).findAll(html).forEachIndexed { index, match ->
                val src = Regex("(?:data-wpfc-original-src|data-lazy-src|data-src|src)\\s*=\\s*[\"']([^\"']+)[\"']", RegexOption.IGNORE_CASE)
                    .find(match.value)?.groupValues?.get(1) ?: return@forEachIndexed
                val serverUrl = normalizeUrl(decodeEntities(src))
                if (!serverUrl.startsWith("http")) return@forEachIndexed
                if (serverUrl.contains("youtube.com/embed") || serverUrl.contains("google.com/maps")) return@forEachIndexed
                servers.add(ArixMovieServerModel("Player ${index + 1}", serverUrl))
            }
        }

        // Downloads: quality <h2> followed by a <p> with anchors
        val downloadRegex = Regex("<h2[^>]*>([\\s\\S]*?)</h2>\\s*<p[^>]*>([\\s\\S]*?)</p>", RegexOption.IGNORE_CASE)
        val seenDownloads = mutableSetOf<String>()
        downloadRegex.findAll(html).forEach { match ->
            val quality = decodeEntities(match.groupValues[1].replace(Regex("<[^>]+>"), "")).trim()
            val body = match.groupValues[2]
            if (!Regex("quality|download|link", RegexOption.IGNORE_CASE).containsMatchIn(quality + body)) return@forEach
            Regex("<a[^>]+href=[\"']([^\"']+)[\"'][^>]*>([\\s\\S]*?)</a>", RegexOption.IGNORE_CASE).findAll(body).forEach { anchor ->
                val href = normalizeUrl(decodeEntities(anchor.groupValues[1]))
                val label = decodeEntities(anchor.groupValues[2].replace(Regex("<[^>]+>"), "")).trim()
                if (!href.startsWith("http") || href == "#" || !seenDownloads.add(href)) return@forEach
                if (Regex("addtoany|facebook|twitter|pinterest|whatsapp|google\\.com", RegexOption.IGNORE_CASE).containsMatchIn(href)) return@forEach
                downloads.add(ArixMovieDownloadModel(quality, label, href))
            }
        }

        val thumbnail = Regex("<meta[^>]+property=[\"']og:image[\"'][^>]+content=[\"']([^\"']+)[\"']", RegexOption.IGNORE_CASE)
            .find(html)?.groupValues?.get(1)?.let { normalizeUrl(decodeEntities(it)) }.orEmpty()

        val title = Regex("<h1[^>]*>([\\s\\S]*?)</h1>").find(html)?.let {
            decodeEntities(it.groupValues[1].replace(Regex("<[^>]+>"), "")).trim()
        }.orEmpty().ifBlank {
            Regex("<title>([\\s\\S]*?)</title>").find(html)?.let {
                decodeEntities(it.groupValues[1].trim())
            }.orEmpty()
        }

        // v2.2.8: resolve direct .mp4/.m3u8 streams from the embed pages.
        // The embed hosts' own players frequently break inside a WebView
        // (external player CDNs blocked, Dood captcha shells…) which is what
        // caused the "black player screen" on every server. A resolved direct
        // stream plays in the native stage and is immune to all of that.
        // All embeds are resolved in PARALLEL so the player card appears fast.
        val resolved = kotlinx.coroutines.runBlocking {
            kotlinx.coroutines.coroutineScope {
                servers.take(5).map { server ->
                    async(Dispatchers.IO) {
                        val embedHtml = ArixMediaApi.fetchEmbedPage(server.url, referer = pageUrl)
                        val direct = embedHtml?.let { ArixMediaApi.extractDirectVideoUrl(it) }.orEmpty()
                        // v2.3.2: send the embed host's own origin as the
                        // Referer for the resolved stream — several CDNs
                        // (ok.ru, vk cdns) mint URLs bound to the requesting
                        // session/origin and reject foreign referers.
                        val embedOrigin = runCatching {
                            android.net.Uri.parse(server.url).buildUpon()
                                .path("").clearQuery().fragment(null).build().toString() + "/"
                        }.getOrDefault("").ifBlank { "https://www.watch-movies.com.pk/" }
                        server.copy(directUrl = direct, pageOrigin = embedOrigin)
                    }
                }.awaitAll()
            }
        }
        val ordered = resolved.sortedByDescending { it.directUrl.isNotBlank() }

        return ArixMoviePlayerModel(
            title = title.substringBefore(" - ").substringBefore(" | ").trim(),
            description = Regex("class=[\"'][^\"']*singdesc[^\"']*[\"'][^>]*>([\\s\\S]*?)<", RegexOption.IGNORE_CASE)
                .find(html)?.groupValues?.get(1)?.let {
                    decodeEntities(it.replace(Regex("<[^>]+>"), "").trim())
                }.orEmpty(),
            thumbnail = thumbnail,
            url = pageUrl,
            servers = ordered,
            downloads = downloads,
        )
    }

/** Builds the widget payload JSON for a listing. */
    fun listOutputJson(mode: String, query: String, page: Int, items: List<ArixMovieItemModel>): String {
        return JSONObject().apply {
            put("widget", "movie_list")
            put("mode", mode)
            put("query", query)
            put("page", page)
            put("results", org.json.JSONArray().apply {
                items.forEach { item ->
                    put(
                        JSONObject().apply {
                            put("title", item.title)
                            put("url", item.url)
                            put("thumbnail", item.thumbnail)
                            put("views", item.views)
                        },
                    )
                }
            })
        }.toString()
    }

    /** Builds the widget payload JSON for a player result. */
    fun playerOutputJson(model: ArixMoviePlayerModel): String {
        return JSONObject().apply {
            put("widget", "movie_player")
            put("mode", "play")
            put("title", model.title)
            put("description", model.description)
            put("thumbnail", model.thumbnail)
            put("source", "native")
            put("url", model.url)
            put("servers", org.json.JSONArray().apply {
                model.servers.forEach { server ->
                    put(
                        JSONObject().apply {
                            put("label", server.label)
                            put("url", server.url)
                            if (server.directUrl.isNotBlank()) {
                                put("direct_url", server.directUrl)
                            }
                        },
                    )
                }
            })
            put("downloads", org.json.JSONArray().apply {
                model.downloads.take(24).forEach { download ->
                    put(
                        JSONObject().apply {
                            put("quality", download.quality)
                            put("label", download.label)
                            put("url", download.url)
                        },
                    )
                }
            })
        }.toString()
    }
}
