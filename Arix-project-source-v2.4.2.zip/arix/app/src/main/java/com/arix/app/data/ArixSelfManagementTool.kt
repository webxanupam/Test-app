package com.arix.app.data

import com.arix.app.data.pi.PiKernelBridge
import java.util.Locale
import kotlinx.coroutines.flow.first
import org.json.JSONArray
import org.json.JSONObject

private const val DefaultDeveloperLogTailChars = 20_000
private const val MaxDeveloperLogTailChars = 80_000

class ArixSelfManagementTool(
    private val settingsRepository: SettingsRepository,
    private val extensionsRepository: AgentExtensionsRepository,
    private val skillManager: AgentSkillManager,
    private val scheduledTaskManager: ScheduledTaskManager,
    private val piKernelBridge: PiKernelBridge,
    private val sessionId: String,
    private val diagnosticLogger: ArixDiagnosticLogger = ArixDiagnosticLogger.NoOp,
) {
    fun toolDefinitions(): List<JSONObject> = listOf(
        buildArixToolDefinition(
            name = "arix_config_get",
            description = "Read Arix app configuration for general preferences, reliability, Skills, scheduled tasks, and developer diagnostics. Provider and model configuration is intentionally omitted.",
            properties = JSONObject().apply {
                put(
                    "categories",
                    JSONObject().apply {
                        put("type", "array")
                        put("description", "Optional categories to read. Omit or pass an empty array to read all supported categories.")
                        put(
                            "items",
                            JSONObject().apply {
                                put("type", "string")
                                put(
                                    "enum",
                                    JSONArray(
                                        listOf(
                                            "general",
                                            "reliability",
                                            "agent_skills",
                                            "scheduled_tasks",
                                            "developer",
                                        )
                                    ),
                                )
                            },
                        )
                    },
                )
            },
        ),
        buildArixToolDefinition(
            name = "arix_config_set",
            description = "Modify allowed Arix settings. This tool cannot modify LLM provider, model, base URL, provider API keys, or default model selections.",
            properties = JSONObject().apply {
                put(
                    "category",
                    JSONObject().apply {
                        put("type", "string")
                        put("enum", JSONArray(listOf("general", "reliability")))
                        put("description", "Allowed settings category to update.")
                    },
                )
                put(
                    "settings",
                    JSONObject().apply {
                        put("type", "object")
                        put("description", "Patch object for the selected category.")
                        put("additionalProperties", true)
                    },
                )
            },
            required = listOf("category", "settings"),
        ),
        buildArixToolDefinition(
            name = "arix_skill_manage",
            description = "List, install, enable, disable, or remove Arix Agent Skills. Remote installs accept GitHub repository URLs or zip URLs supported by Arix.",
            properties = JSONObject().apply {
                put(
                    "action",
                    JSONObject().apply {
                        put("type", "string")
                        put("enum", JSONArray(listOf("list", "install_remote", "remove", "set_enabled")))
                    },
                )
                put("skill_id", JSONObject().apply { put("type", "string") })
                put("url", JSONObject().apply { put("type", "string") })
                put("enabled", JSONObject().apply { put("type", "boolean") })
            },
            required = listOf("action"),
        ),
        buildArixToolDefinition(
            name = "arix_runtime_manage",
            description = "Read or switch the current chat session runtime. Alpine is the only local runtime.",
            properties = JSONObject().apply {
                put(
                    "action",
                    JSONObject().apply {
                        put("type", "string")
                        put("enum", JSONArray(listOf("status", "set")))
                    },
                )
                put(
                    "runtime",
                    JSONObject().apply {
                        put("type", "string")
                        put("enum", JSONArray(listOf("alpine")))
                    },
                )
            },
            required = listOf("action"),
        ),
        buildArixToolDefinition(
            name = "arix_scheduled_task_manage",
            description = "List, create, update, enable, disable, or remove Arix scheduled tasks. Scheduled tasks wake Arix at the next matching time and run the prompt as an automated Agent turn.",
            properties = JSONObject().apply {
                put(
                    "action",
                    JSONObject().apply {
                        put("type", "string")
                        put("enum", JSONArray(listOf("list", "create", "update", "remove", "set_enabled")))
                    },
                )
                put("task_id", JSONObject().apply { put("type", "string") })
                put("name", JSONObject().apply { put("type", "string") })
                put("prompt", JSONObject().apply { put("type", "string") })
                put("session_id", JSONObject().apply { put("type", "string") })
                put("enabled", JSONObject().apply { put("type", "boolean") })
                put(
                    "schedule",
                    JSONObject().apply {
                        put("type", "object")
                        put(
                            "description",
                            "Schedule object. interval: {type:'interval', interval_minutes:30, active_start_time:'13:00', active_end_time:'18:00'}; daily: {type:'daily', times:['09:00','17:30']}; weekly: {type:'weekly', days_of_week:['mon','fri'], time:'10:00'}.",
                        )
                        put("additionalProperties", true)
                    },
                )
            },
            required = listOf("action"),
        ),
        buildArixToolDefinition(
            name = "arix_extension_manage",
            description = "List or reload source-compatible Pi extensions for the current Arix session, or invoke a registered Pi extension command. Extensions are discovered from ~/.pi/agent/extensions, the workspace .pi/extensions directory, and ~/.arix/extensions. Custom Pi TUI components are not supported.",
            properties = JSONObject().apply {
                put(
                    "action",
                    JSONObject().apply {
                        put("type", "string")
                        put("enum", JSONArray(listOf("list", "reload", "invoke_command")))
                    },
                )
                put(
                    "command",
                    JSONObject().apply {
                        put("type", "string")
                        put("description", "Registered extension command name, with or without a leading slash.")
                    },
                )
                put(
                    "args",
                    JSONObject().apply {
                        put("type", "string")
                        put("description", "Raw command argument string.")
                    },
                )
            },
            required = listOf("action"),
        ),
        buildArixToolDefinition(
            name = "arix_developer_manage",
            description = "Read Arix developer diagnostics such as recent diagnostic events or last crash details. Sensitive values are redacted.",
            properties = JSONObject().apply {
                put(
                    "action",
                    JSONObject().apply {
                        put("type", "string")
                        put("enum", JSONArray(listOf("read_diagnostics")))
                    },
                )
                put(
                    "include",
                    JSONObject().apply {
                        put("type", "string")
                        put("enum", JSONArray(listOf("events", "last_crash", "both")))
                    },
                )
                put("max_chars", JSONObject().apply { put("type", "integer") })
            },
            required = listOf("action"),
        ),
    )

    suspend fun execute(
        toolName: String,
        argumentsJson: String,
    ): String = when (toolName) {
        "arix_config_get" -> executeConfigGet(argumentsJson)
        "arix_config_set" -> executeConfigSet(argumentsJson)
        "arix_skill_manage" -> executeSkillManage(argumentsJson)
        "arix_scheduled_task_manage" -> executeScheduledTaskManage(argumentsJson)
        "arix_extension_manage" -> executeExtensionManage(argumentsJson)
        "arix_developer_manage" -> executeDeveloperManage(argumentsJson)
        else -> failure("Unknown Arix self-management tool '$toolName'.")
    }

    private suspend fun executeConfigGet(argumentsJson: String): String {
        val arguments = parseArguments(argumentsJson) ?: return invalidJson()
        val requestedCategories = parseCategories(arguments.optJSONArray("categories"))
        val categories = if (requestedCategories.isEmpty()) {
            SupportedConfigCategories
        } else {
            requestedCategories
        }
        val settings = settingsRepository.settings.first()
        val extensionState = extensionsRepository.extensionState.first()
        val payload = JSONObject()
        categories.forEach { category ->
            when (category) {
                "general" -> payload.put("general", generalSettingsJson(settings))
                "reliability" -> payload.put("reliability", reliabilitySettingsJson(settings))
                "agent_skills" -> payload.put("agent_skills", skillsJson(extensionState.installedSkills))
                "scheduled_tasks" -> payload.put("scheduled_tasks", scheduledTasksJson(scheduledTaskManager.snapshot()))
                "developer" -> payload.put("developer", developerSummaryJson())
                else -> return failure("Unsupported category '$category'.")
            }
        }
        return success(payload) {
            put("stdout", "Read ${categories.size} Arix configuration categories.")
        }
    }

    private suspend fun executeConfigSet(argumentsJson: String): String {
        val arguments = parseArguments(argumentsJson) ?: return invalidJson()
        val category = arguments.optString("category").trim().lowercase(Locale.US)
        val patch = arguments.optJSONObject("settings") ?: return failure("settings must be an object.")
        val current = settingsRepository.settings.first()
        val updated = when (category) {
            "general" -> current.copy(
                language = if (patch.hasAny("language", "app_language")) {
                    AppLanguage.fromStorage(patch.optStringAny("language", "app_language"), current.language)
                } else {
                    current.language
                },
                themeMode = if (patch.hasAny("theme_mode", "themeMode")) {
                    AppThemeMode.fromStorage(patch.optStringAny("theme_mode", "themeMode"))
                } else {
                    current.themeMode
                },
            )

            "reliability" -> current.copy(
                llmInactivityReconnectTimeoutSeconds = if (
                    patch.hasAny(
                            "llm_inactivity_reconnect_timeout_seconds",
                            "llmInactivityReconnectTimeoutSeconds",
                        )
                ) {
                    normalizeLlmInactivityReconnectTimeoutSeconds(
                        patch.optIntAny(
                            "llm_inactivity_reconnect_timeout_seconds",
                            "llmInactivityReconnectTimeoutSeconds",
                        )
                    )
                } else {
                    current.llmInactivityReconnectTimeoutSeconds
                },
                keepTasksRunningInBackground = if (
                    patch.hasAny("keep_tasks_running_in_background", "keepTasksRunningInBackground")
                ) {
                    patch.optBooleanAny(
                        "keep_tasks_running_in_background",
                        "keepTasksRunningInBackground",
                        current.keepTasksRunningInBackground,
                    )
                } else {
                    current.keepTasksRunningInBackground
                },
                notifyOnTaskCompletion = if (
                    patch.hasAny("notify_on_task_completion", "notifyOnTaskCompletion")
                ) {
                    patch.optBooleanAny(
                        "notify_on_task_completion",
                        "notifyOnTaskCompletion",
                        current.notifyOnTaskCompletion,
                    )
                } else {
                    current.notifyOnTaskCompletion
                },
            )

            else -> return failure("Unsupported or read-only category '$category'.")
        }
        settingsRepository.updateSettings(updated)
        return success(JSONObject().put(category, configCategoryJson(category, updated))) {
            put("stdout", "Updated Arix $category settings.")
        }
    }

    private suspend fun executeSkillManage(argumentsJson: String): String {
        val arguments = parseArguments(argumentsJson) ?: return invalidJson()
        return when (val action = arguments.optString("action").trim().lowercase(Locale.US)) {
            "list" -> {
                val skills = extensionsRepository.extensionState.first().installedSkills
                success(JSONObject().put("skills", skillsJson(skills))) {
                    put("stdout", "Listed ${skills.size} installed skills.")
                }
            }

            "install_remote" -> {
                val url = arguments.optString("url").trim()
                if (url.isBlank()) return failure("url is required for install_remote.")
                val installed = skillManager.installSkillFromRemote(url)
                    .getOrElse { throwable -> return failure(throwable.message ?: "Skill install failed.") }
                piKernelBridge.reloadSession(sessionId)
                success(JSONObject().put("skill", installedSkillJson(installed))) {
                    put("stdout", "Installed skill '${installed.name}'.")
                }
            }

            "remove" -> {
                val skillId = arguments.optString("skill_id").trim()
                    .ifBlank { arguments.optString("skillId").trim() }
                if (skillId.isBlank()) return failure("skill_id is required for remove.")
                skillManager.uninstallSkill(skillId)
                    .getOrElse { throwable -> return failure(throwable.message ?: "Skill removal failed.") }
                piKernelBridge.reloadSession(sessionId)
                success(JSONObject().put("skill_id", skillId)) {
                    put("stdout", "Removed skill '$skillId'.")
                }
            }

            "set_enabled" -> {
                val skillId = arguments.optString("skill_id").trim()
                    .ifBlank { arguments.optString("skillId").trim() }
                if (skillId.isBlank()) return failure("skill_id is required for set_enabled.")
                if (!arguments.has("enabled")) return failure("enabled is required for set_enabled.")
                val enabled = arguments.optBoolean("enabled")
                extensionsRepository.setSkillEnabled(skillId, enabled)
                piKernelBridge.reloadSession(sessionId)
                success(JSONObject().put("skill_id", skillId).put("enabled", enabled)) {
                    put("stdout", "Set skill '$skillId' enabled=$enabled.")
                }
            }

            else -> failure("Unsupported skill action '$action'.")
        }
    }

    private suspend fun executeScheduledTaskManage(argumentsJson: String): String {
        val arguments = parseArguments(argumentsJson) ?: return invalidJson()
        return when (val action = arguments.optString("action").trim().lowercase(Locale.US)) {
            "list" -> {
                val tasks = scheduledTaskManager.snapshot()
                success(JSONObject().put("tasks", scheduledTasksJson(tasks))) {
                    put("stdout", "Listed ${tasks.size} scheduled tasks.")
                }
            }

            "create" -> {
                val name = arguments.optString("name").trim().ifBlank { "Scheduled task" }
                val prompt = arguments.optString("prompt").trim()
                if (prompt.isBlank()) return failure("prompt is required for create.")
                val schedule = parseScheduledTaskSchedule(arguments.optJSONObject("schedule"))
                    ?: return failure("schedule is required and must be a valid interval, daily, or weekly schedule.")
                val task = scheduledTaskManager.upsertTask(
                    ScheduledTask(
                        name = name,
                        prompt = prompt,
                        schedule = schedule,
                        isEnabled = arguments.optNullableBoolean("enabled") ?: true,
                        sessionId = optArixString(arguments, "session_id", "sessionId"),
                        createdBy = ScheduledTaskCreator.Agent,
                    )
                )
                success(JSONObject().put("task", task.toPublicJson())) {
                    put("stdout", "Created scheduled task '${task.name}'.")
                }
            }

            "update" -> {
                val taskId = optArixString(arguments, "task_id", "taskId")
                if (taskId.isBlank()) return failure("task_id is required for update.")
                val existing = scheduledTaskManager.findTask(taskId)
                    ?: return failure("Scheduled task '$taskId' was not found.")
                val schedule = if (arguments.has("schedule") && !arguments.isNull("schedule")) {
                    parseScheduledTaskSchedule(arguments.optJSONObject("schedule"))
                        ?: return failure("schedule must be a valid interval, daily, or weekly schedule.")
                } else {
                    existing.schedule
                }
                val enabled = arguments.optNullableBoolean("enabled") ?: existing.isEnabled
                val updated = scheduledTaskManager.upsertTask(
                    existing.copy(
                        name = arguments.optString("name").trim().ifBlank { existing.name },
                        prompt = arguments.optString("prompt").trim().ifBlank { existing.prompt },
                        schedule = schedule,
                        isEnabled = enabled,
                        sessionId = optArixString(arguments, "session_id", "sessionId").ifBlank { existing.sessionId },
                    )
                )
                success(JSONObject().put("task", updated.toPublicJson())) {
                    put("stdout", "Updated scheduled task '${updated.name}'.")
                }
            }

            "remove" -> {
                val taskId = optArixString(arguments, "task_id", "taskId")
                if (taskId.isBlank()) return failure("task_id is required for remove.")
                scheduledTaskManager.removeTask(taskId)
                success(JSONObject().put("task_id", taskId)) {
                    put("stdout", "Removed scheduled task '$taskId'.")
                }
            }

            "set_enabled" -> {
                val taskId = optArixString(arguments, "task_id", "taskId")
                if (taskId.isBlank()) return failure("task_id is required for set_enabled.")
                if (!arguments.has("enabled")) return failure("enabled is required for set_enabled.")
                val task = scheduledTaskManager.setTaskEnabled(taskId, arguments.optBoolean("enabled"))
                    ?: return failure("Scheduled task '$taskId' was not found.")
                success(JSONObject().put("task", task.toPublicJson())) {
                    put("stdout", "Set scheduled task '${task.name}' enabled=${task.isEnabled}.")
                }
            }

            else -> failure("Unsupported scheduled task action '$action'.")
        }
    }

    private fun executeDeveloperManage(argumentsJson: String): String {
        val arguments = parseArguments(argumentsJson) ?: return invalidJson()
        return when (val action = arguments.optString("action").trim().lowercase(Locale.US)) {
            "read_diagnostics" -> {
                val include = arguments.optString("include").trim().lowercase(Locale.US).ifBlank { "both" }
                val maxChars = arguments.optInt("max_chars", DefaultDeveloperLogTailChars)
                    .coerceIn(1_000, MaxDeveloperLogTailChars)
                val output = JSONObject()
                if (include == "events" || include == "both") {
                    output.put("events_tail", diagnosticLogger.readEventsText().takeLast(maxChars))
                }
                if (include == "last_crash" || include == "both") {
                    output.put("last_crash", diagnosticLogger.readLastCrashText().takeLast(maxChars))
                }
                success(output) {
                    put("stdout", "Read Arix diagnostics.")
                }
            }

            else -> failure("Unsupported developer action '$action'.")
        }
    }

    private suspend fun executeExtensionManage(argumentsJson: String): String {
        val arguments = parseArguments(argumentsJson) ?: return invalidJson()
        return runCatching {
            when (val action = arguments.optString("action").trim().lowercase(Locale.US)) {
                "list" -> {
                    val payload = piKernelBridge.listExtensions(sessionId)
                    success(payload) {
                        put(
                            "stdout",
                            "Found ${payload.optJSONArray("extension_paths")?.length() ?: 0} loaded Pi extensions.",
                        )
                    }
                }

                "reload" -> {
                    val payload = piKernelBridge.reloadExtensions(sessionId)
                    success(payload) {
                        put(
                            "stdout",
                            when {
                                payload.optBoolean("scheduled") ->
                                    "Pi extension reload is scheduled for the end of the current turn."
                                payload.optBoolean("reloaded") ->
                                    "Reloaded Pi extensions."
                                else ->
                                    "Pi extension reload was rejected. Inspect the returned errors."
                            },
                        )
                    }
                }

                "invoke_command" -> {
                    val command = arguments.optString("command").trim()
                    if (command.isBlank()) return failure("command is required for invoke_command.")
                    val payload = piKernelBridge.invokeExtensionCommand(
                        sessionId = sessionId,
                        command = command,
                        args = arguments.optString("args"),
                    )
                    success(payload) {
                        put("stdout", "Invoked Pi extension command '$command'.")
                    }
                }

                else -> failure("Unsupported Pi extension action '$action'.")
            }
        }.getOrElse { throwable ->
            failure(throwable.message ?: "Pi extension operation failed.")
        }
    }

    private fun generalSettingsJson(settings: AppSettings): JSONObject =
        JSONObject()
            .put("language", settings.language.storageValue)
            .put("theme_mode", settings.themeMode.storageValue)

    private fun reliabilitySettingsJson(settings: AppSettings): JSONObject =
        JSONObject()
            .put("llm_inactivity_reconnect_timeout_seconds", settings.llmInactivityReconnectTimeoutSeconds)
            .put("keep_tasks_running_in_background", settings.keepTasksRunningInBackground)
            .put("notify_on_task_completion", settings.notifyOnTaskCompletion)

    private fun configCategoryJson(
        category: String,
        settings: AppSettings,
    ): JSONObject = when (category) {
        "general" -> generalSettingsJson(settings)
        "reliability" -> reliabilitySettingsJson(settings)
        else -> JSONObject()
    }

    private fun developerSummaryJson(): JSONObject =
        JSONObject()
            .put("diagnostic_events_available", diagnosticLogger.readEventsText().isNotBlank())
            .put("last_crash_available", diagnosticLogger.readLastCrashText().isNotBlank())
            .put("tools", JSONArray(listOf("arix_developer_manage")))

    private fun scheduledTasksJson(tasks: List<ScheduledTask>): JSONArray =
        JSONArray().apply {
            tasks.sortedWith(compareBy<ScheduledTask> { it.nextRunAtMillis ?: Long.MAX_VALUE }.thenBy { it.name.lowercase(Locale.US) })
                .forEach { put(it.toPublicJson()) }
        }

    private fun skillsJson(skills: List<InstalledSkill>): JSONArray =
        JSONArray().apply {
            skills.sortedBy { it.name.lowercase(Locale.US) }.forEach { put(installedSkillJson(it)) }
        }

    private fun installedSkillJson(skill: InstalledSkill): JSONObject =
        JSONObject()
            .put("id", skill.id)
            .put("name", skill.name)
            .put("description", skill.description)
            .put("action_label", skill.quickActionLabel())
            .put("is_enabled", skill.isEnabled)
            .put("source", JSONObject().apply {
                put("kind", skill.source.kind.storageValue)
                put("label", skill.source.label)
                put("uri", skill.source.uri)
                put("ref", skill.source.ref)
                put("subpath", skill.source.subpath)
            })
            .put("allowed_tools", JSONArray().apply { skill.allowedTools.forEach(::put) })
            .put("diagnostics", JSONArray().apply { skill.diagnostics.forEach(::put) })
            .put("resource_count", skill.resourceEntries.size)
            .put("installed_at_millis", skill.installedAtMillis)
            .put("updated_at_millis", skill.updatedAtMillis)

    private fun buildArixToolDefinition(
        name: String,
        description: String,
        properties: JSONObject,
        required: List<String> = emptyList(),
    ): JSONObject = JSONObject().apply {
        put("type", "function")
        put(
            "function",
            JSONObject().apply {
                put("name", name)
                put("description", description)
                put("parameters", buildPiToolParameters(properties, required))
            },
        )
    }

    private fun buildPiToolParameters(
        properties: JSONObject,
        required: List<String>,
    ): JSONObject = JSONObject().apply {
        put("type", "object")
        put("properties", JSONObject(properties.toString()))
        put("required", JSONArray(required))
        put("additionalProperties", false)
    }

    private fun keyValueArraySchema(description: String): JSONObject =
        JSONObject().apply {
            put("type", "array")
            put("description", description)
            put(
                "items",
                JSONObject().apply {
                    put("type", "object")
                    put(
                        "properties",
                        JSONObject().apply {
                            put("key", JSONObject().apply { put("type", "string") })
                            put("value", JSONObject().apply { put("type", "string") })
                        },
                    )
                    put("required", JSONArray(listOf("key", "value")))
                    put("additionalProperties", false)
                },
            )
        }

    private fun stdioEnvironmentSchema(): JSONObject =
        JSONObject().apply {
            put(
                "description",
                "Runtime environment for stdio MCP servers when provided as a string, or environment variables when provided as an array.",
            )
            put(
                "oneOf",
                JSONArray().apply {
                    put(
                        JSONObject().apply {
                            put("type", "string")
                            put("enum", JSONArray(listOf("default", "alpine")))
                        },
                    )
                    put(keyValueArraySchema("Environment variables for stdio MCP servers."))
                },
            )
        }

    private fun stringArraySchema(description: String): JSONObject =
        JSONObject().apply {
            put("type", "array")
            put("description", description)
            put(
                "items",
                JSONObject().apply {
                    put("type", "string")
                },
            )
        }

    private fun parseArguments(argumentsJson: String): JSONObject? =
        runCatching { JSONObject(argumentsJson) }.getOrNull()

    private fun parseCategories(array: JSONArray?): List<String> {
        if (array == null) return emptyList()
        return buildList {
            for (index in 0 until array.length()) {
                val category = array.optString(index).trim().lowercase(Locale.US)
                if (category.isNotBlank()) add(category)
            }
        }.distinct()
    }

    private fun parseStringArray(array: JSONArray?): List<String> {
        if (array == null) return emptyList()
        return buildList {
            for (index in 0 until array.length()) {
                val value = array.optString(index).trim()
                if (value.isNotBlank()) {
                    add(value)
                }
            }
        }
    }

    private fun success(
        payload: JSONObject = JSONObject(),
        configure: JSONObject.() -> Unit = {},
    ): String = JSONObject().apply {
        put("ok", true)
        payload.keys().forEach { key -> put(key, payload.opt(key)) }
        configure()
    }.toString()

    private fun failure(message: String): String =
        JSONObject()
            .put("ok", false)
            .put("errmsg", message)
            .toString()

    private fun invalidJson(): String = failure("Arguments were not valid JSON.")

    private fun redactSecret(value: String): String =
        if (value.isBlank()) "" else "[REDACTED]"

    private fun shouldRedactKey(key: String): Boolean {
        val normalized = key.lowercase(Locale.US)
        return SensitiveKeyFragments.any { it in normalized }
    }

    private fun JSONObject.hasAny(vararg names: String): Boolean =
        names.any(::has)

    private fun JSONObject.optStringAny(vararg names: String): String =
        names.firstOrNull(::has)?.let(::optString).orEmpty()

    private fun JSONObject.optIntAny(vararg names: String): Int? =
        names.firstOrNull(::has)?.let { optInt(it) }

    private fun JSONObject.optBooleanAny(
        primary: String,
        secondary: String,
        defaultValue: Boolean,
    ): Boolean = when {
        has(primary) -> optBoolean(primary, defaultValue)
        has(secondary) -> optBoolean(secondary, defaultValue)
        else -> defaultValue
    }

    private fun JSONObject.optBooleanAny(
        first: String,
        second: String,
        third: String,
        defaultValue: Boolean,
    ): Boolean = when {
        has(first) -> optBoolean(first, defaultValue)
        has(second) -> optBoolean(second, defaultValue)
        has(third) -> optBoolean(third, defaultValue)
        else -> defaultValue
    }

    private fun JSONObject.optNullableBoolean(name: String): Boolean? =
        if (has(name)) optBoolean(name) else null

    private fun JSONObject.optNullableLong(name: String): Long? =
        if (has(name)) optLong(name) else null

    private fun optArixString(
        arguments: JSONObject,
        primary: String,
        secondary: String,
    ): String = arguments.optString(primary).trim().ifBlank {
        arguments.optString(secondary).trim()
    }

    private companion object {
        val SupportedConfigCategories = listOf(
            "general",
            "reliability",
            "agent_skills",
            "scheduled_tasks",
            "developer",
        )
        val SensitiveKeyFragments = listOf(
            "apikey",
            "api_key",
            "authorization",
            "auth",
            "bearer",
            "token",
            "secret",
            "password",
            "key",
        )
    }
}
