package com.arix.app.data

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map

private val Context.piExtensionStateDataStore by preferencesDataStore(
    name = "arix_pi_extension_state",
)

data class PiExtensionLoadOptions(
    val disabledExtensionPaths: Set<String> = emptySet(),
    val disabledPackageSources: Set<String> = emptySet(),
) {
    fun toJsonArrays(): Pair<List<String>, List<String>> =
        disabledExtensionPaths.toList() to disabledPackageSources.toList()
}

/**
 * v2.2.9: the bundled power extensions (web access, MCP adapter, subagents)
 * ship ENABLED by default. Previously every bundled extension was disabled by
 * default, which is exactly why adding an MCP server and pressing Connect
 * answered "MCP extension not loaded yet" — the Pi-side extension never ran.
 * The movie / anime / QR explorers moved out of extensions/ into the native
 * Tools screen, so their stale entries are pruned by the v2 migration below.
 */
internal val DefaultDisabledPreinstalledExtensionPaths: Set<String> = emptySet()

internal val DefaultDisabledPreinstalledExtensionIds: Set<String> = emptySet()

/** Extensions that were removed from the bundle (moved to native Tools). */
private val RemovedExtensionBaseNames = setOf(
    "pi-movie-explorer",
    "pi-anime-explorer",
    "pi-qr-generator",
)

private const val ExtensionStateDefaultsVersion = 2

class PiExtensionStateRepository(
    private val context: Context,
) {
    val disabledExtensionIds: Flow<Set<String>> =
        context.piExtensionStateDataStore.data.map { preferences ->
            (preferences[DISABLED_EXTENSION_IDS] ?: DefaultDisabledPreinstalledExtensionIds)
                .map(::normalizeExtensionStateId)
                .toSet()
        }

    suspend fun setEnabled(
        extensionId: String,
        enabled: Boolean,
    ) {
        val normalizedId = extensionId.trim()
        if (normalizedId.isBlank()) return
        val stableId = normalizeExtensionStateId(normalizedId)
        val baseName = stableId.substringAfterLast('/')
        context.piExtensionStateDataStore.edit { preferences ->
            val disabledIds = (preferences[DISABLED_EXTENSION_IDS] ?: DefaultDisabledPreinstalledExtensionIds)
                .mapTo(mutableSetOf(), ::normalizeExtensionStateId)
            if (enabled) {
                disabledIds.remove(stableId)
                disabledIds.removeAll { it.substringAfterLast('/') == baseName }
            } else {
                disabledIds.add(stableId)
            }
            preferences[DISABLED_EXTENSION_IDS] = disabledIds
            preferences[DEFAULTS_VERSION] = ExtensionStateDefaultsVersion
        }
    }

    suspend fun loadOptions(): PiExtensionLoadOptions {
        migrateToCurrentDefaults()
        return loadOptionsForIds(disabledExtensionIds.first())
    }

    suspend fun replaceDisabledExtensionIds(extensionIds: Set<String>) {
        context.piExtensionStateDataStore.edit { preferences ->
            preferences[DISABLED_EXTENSION_IDS] = extensionIds
                .map(::normalizeExtensionStateId)
                .filter(String::isNotBlank)
                .filterNot { id -> id.substringAfterLast('/') in RemovedExtensionBaseNames }
                .toSet()
            preferences[DEFAULTS_VERSION] = ExtensionStateDefaultsVersion
        }
    }

    /**
     * One-time migration for installs that carry a v1 defaults snapshot:
     * drops entries for extensions that are no longer bundled and re-enables
     * the core bundled extensions once (users keep any later explicit choice
     * because the migration only ever runs when the stored version marker is
     * older than the current defaults version).
     */
    private suspend fun migrateToCurrentDefaults() {
        context.piExtensionStateDataStore.edit { preferences ->
            val storedVersion = preferences[DEFAULTS_VERSION] ?: 1
            if (storedVersion >= ExtensionStateDefaultsVersion) return@edit
            val current = preferences[DISABLED_EXTENSION_IDS]
            if (current == null) {
                // The key was never written: fresh install or a v1 install that
                // never touched extension toggles. Nothing persisted — the new
                // (empty) defaults apply automatically.
                preferences[DEFAULTS_VERSION] = ExtensionStateDefaultsVersion
                return@edit
            }
            val migrated = current
                .map(::normalizeExtensionStateId)
                .filterNot { id -> id.substringAfterLast('/') in RemovedExtensionBaseNames }
                .filterNot { id ->
                    id == "import:arix:/root/.arix/extensions/pi-mcp-adapter" ||
                        id == "import:arix:/root/.arix/extensions/pi-subagents" ||
                        id == "import:arix:/root/.arix/extensions/pi-web-access"
                }
                .toSet()
            preferences[DISABLED_EXTENSION_IDS] = migrated
            preferences[DEFAULTS_VERSION] = ExtensionStateDefaultsVersion
        }
    }

    private companion object {
        val DISABLED_EXTENSION_IDS = stringSetPreferencesKey("disabled_extension_ids")
        val DEFAULTS_VERSION = intPreferencesKey("extension_state_defaults_version")
    }
}

internal fun loadOptionsForIds(
    disabledExtensionIds: Set<String>,
): PiExtensionLoadOptions {
    val disabledExtensionPaths = mutableSetOf<String>()
    val disabledPackageSources = mutableSetOf<String>()
    disabledExtensionIds.forEach { rawId ->
        val id = rawId.trim()
        when {
            id.startsWith("package:") -> {
                id.removePrefix("package:")
                    .trim()
                    .takeIf(String::isNotBlank)
                    ?.let(disabledPackageSources::add)
            }

            id.startsWith("import:") -> {
                id.substringAfter(':', "")
                    .substringAfter(':', "")
                    .trim()
                    .takeIf(String::isNotBlank)
                    ?.let(::normalizeImportedExtensionPath)
                    ?.let(disabledExtensionPaths::add)
            }

            id.startsWith("/") -> {
                disabledExtensionPaths.add(normalizeImportedExtensionPath(id))
            }
        }
    }
    return PiExtensionLoadOptions(
        disabledExtensionPaths = disabledExtensionPaths,
        disabledPackageSources = disabledPackageSources,
    )
}

internal fun normalizeExtensionStateId(rawId: String): String {
    val id = rawId.trim()
    if (!id.startsWith("import:")) return id
    val scope = id.substringAfter(':', "").substringBefore(':', "").trim()
    val importedPath = id.substringAfter(':', "").substringAfter(':', "").trim()
    if (scope.isBlank() || importedPath.isBlank()) return id
    return "import:$scope:${normalizeImportedExtensionPath(importedPath)}"
}

internal fun normalizeImportedExtensionPath(rawPath: String): String {
    val path = rawPath.trim()
    val guestRoots = listOf(
        "/root/.arix/extensions",
        "/root/.pi/agent/extensions",
    )
    guestRoots.forEach { guestRoot ->
        val rootIndex = path.lastIndexOf(guestRoot)
        if (rootIndex >= 0) return path.substring(rootIndex)
    }
    return path
}
