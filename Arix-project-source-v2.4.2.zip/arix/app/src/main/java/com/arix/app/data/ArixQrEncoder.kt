package com.arix.app.data

/**
 * Pure-Kotlin QR Code encoder (byte mode, ECC level M, versions 1-40,
 * penalty-optimal mask selection).
 *
 * Produces matrices bit-identical to the reference `qrcode` Python library
 * (verified across versions 1-32 with random payloads incl. UTF-8).
 * No Android dependencies so it is unit-testable on the JVM.
 */
object ArixQrEncoder {

    class QrMatrix(val size: Int, val modules: BooleanArray) {
        val version: Int = (size - 17) / 4
        fun isDark(row: Int, col: Int): Boolean = modules[row * size + col]
    }

    class CapacityException(message: String) : Exception(message)

    // ------------------------------------------------------------- GF(256)

    private val gfExp = IntArray(255).also { exp ->
        var x = 1
        for (i in 0 until 255) {
            exp[i] = x
            x = x shl 1
            if (x and 0x100 != 0) x = x xor 0x11D
        }
    }

    private val gfLog = IntArray(256).also { log ->
        for (i in 0 until 255) log[gfExp[i]] = i
    }

    private fun gMul(a: Int, b: Int): Int {
        if (a == 0 || b == 0) return 0
        return gfExp[(gfLog[a] + gfLog[b]) % 255]
    }

    /** RS generator polynomial, ASCENDING coefficients, length degree+1. */
    private fun rsGenerator(degree: Int): IntArray {
        var poly = intArrayOf(1)
        for (i in 0 until degree) {
            // multiply by (x + a^i)
            val next = IntArray(poly.size + 1)
            for (j in poly.indices) {
                next[j + 1] = next[j + 1] xor poly[j] // c*x
                next[j] = next[j] xor gMul(poly[j], gfExp[i]) // c*a^i
            }
            poly = next
        }
        return poly
    }

    /** Remainder of data (ascending, zero-padded implicitly) divided by gen (ascending). */
    private fun rsRemainder(data: IntArray, genAscending: IntArray): IntArray {
        val degree = genAscending.size - 1
        val gen = IntArray(genAscending.size)
        for (i in genAscending.indices) gen[i] = genAscending[genAscending.size - 1 - i] // descending, gen[0]==1
        val res = IntArray(data.size + degree)
        System.arraycopy(data, 0, res, 0, data.size)
        for (i in 0 until data.size) {
            val factor = res[i]
            if (factor != 0) {
                for (j in 1 until gen.size) {
                    res[i + j] = res[i + j] xor gMul(gen[j], factor)
                }
            }
        }
        return res.copyOfRange(data.size, res.size)
    }

    // ---------------------------------------------------------- structure

    private fun blockGroups(version: Int): Array<IntArray> = ArixQrTables.rsBlocksM[version - 1]

    private fun dataCapacity(version: Int): Int {
        var total = 0
        for (group in blockGroups(version)) {
            total += group[0] * group[2]
        }
        return total
    }

    // -------------------------------------------------------------- encode

    fun encode(payload: ByteArray): QrMatrix {
        require(payload.isNotEmpty()) { "payload is empty" }
        var version = 0
        for (candidate in 1..40) {
            val countBits = if (candidate < 10) 8 else 16
            val need = 4 + countBits + payload.size * 8
            if (need <= dataCapacity(candidate) * 8) {
                version = candidate
                break
            }
        }
        if (version == 0) {
            throw CapacityException(
                "Payload of ${payload.size} bytes exceeds the largest QR version (2331 bytes at 40-M)."
            )
        }

        val capacity = dataCapacity(version)
        val countBits = if (version < 10) 8 else 16

        // --- bit stream
        val bits = BooleanArray(4 + countBits + payload.size * 8)
        var p = 0
        fun putBits(value: Int, n: Int) {
            for (i in n - 1 downTo 0) {
                bits[p] = ((value shr i) and 1) == 1
                p++
            }
        }
        putBits(0b0100, 4) // byte mode
        putBits(payload.size, countBits)
        for (b in payload) putBits(b.toInt() and 0xFF, 8)

        // terminator + byte alignment + padding
        val limit = capacity * 8
        val terminator = minOf(4, limit - bits.size)
        val terminated = bits.copyOf(bits.size + terminator)
        val padToByte = if (terminated.size % 8 != 0) 8 - (terminated.size % 8) else 0
        val padBytes = (limit - terminated.size - padToByte) / 8
        val full = BooleanArray(limit)
        System.arraycopy(terminated, 0, full, 0, terminated.size)
        var idx = terminated.size + padToByte
        var padFlip = false
        repeat(padBytes) {
            val byte = if (padFlip) 0x11 else 0xEC
            padFlip = !padFlip
            for (i in 7 downTo 0) {
                full[idx] = ((byte shr i) and 1) == 1
                idx++
            }
        }

        // --- codewords
        val codewords = IntArray(capacity)
        for (i in 0 until limit) {
            if (full[i]) codewords[i / 8] = codewords[i / 8] or (1 shl (7 - (i % 8)))
        }

        // --- split into blocks + ECC + interleave
        val groups = blockGroups(version)
        val dataBlocks = ArrayList<IntArray>()
        val eccBlocks = ArrayList<IntArray>()
        var offset = 0
        var totalCodewords = 0
        for (group in groups) {
            val count = group[0]
            val total = group[1]
            val dataCount = group[2]
            val gen = rsGenerator(total - dataCount)
            totalCodewords += count * total
            repeat(count) {
                val chunk = codewords.copyOfRange(offset, offset + dataCount)
                offset += dataCount
                dataBlocks.add(chunk)
                eccBlocks.add(rsRemainder(chunk, gen))
            }
        }
        check(offset == capacity)

        val maxData = dataBlocks.maxOf { it.size }
        val maxEcc = eccBlocks.maxOf { it.size }
        val final = IntArray(totalCodewords)
        var fi = 0
        for (i in 0 until maxData) {
            for (block in dataBlocks) if (i < block.size) final[fi++] = block[i]
        }
        for (i in 0 until maxEcc) {
            for (block in eccBlocks) if (i < block.size) final[fi++] = block[i]
        }
        check(fi == totalCodewords)

        // --- mask selection on test matrices, then final build
        var bestMask = 0
        var bestPenalty = Int.MAX_VALUE
        for (mask in 0..7) {
            val penalty = penalty(buildMatrix(version, final, mask, test = true))
            if (penalty < bestPenalty) {
                bestPenalty = penalty
                bestMask = mask
            }
        }
        return buildMatrix(version, final, bestMask, test = false)
    }

    // -------------------------------------------------------------- matrix

    private fun buildMatrix(version: Int, codewords: IntArray, mask: Int, test: Boolean): QrMatrix {
        val size = 17 + 4 * version
        // 0 = unset, 1 = dark, 2 = light
        val cells = ByteArray(size * size)

        fun probe(row: Int, col: Int) {
            for (r in -1..7) {
                val rr = row + r
                if (rr < 0 || rr >= size) continue
                for (c in -1..7) {
                    val cc = col + c
                    if (cc < 0 || cc >= size) continue
                    val dark = (r in 0..6 && (c == 0 || c == 6)) ||
                        (c in 0..6 && (r == 0 || r == 6)) ||
                        (r in 2..4 && c in 2..4)
                    cells[rr * size + cc] = if (dark) 1 else 2
                }
            }
        }

        probe(0, 0)
        probe(size - 7, 0)
        probe(0, size - 7)

        // alignment patterns BEFORE timing (reference order)
        val pos = ArixQrTables.alignmentPositions[version - 1]
        for (row in pos) {
            for (col in pos) {
                if (cells[row * size + col] != 0.toByte()) continue
                for (r in -2..2) {
                    for (c in -2..2) {
                        val dark = r == -2 || r == 2 || c == -2 || c == 2 || (r == 0 && c == 0)
                        cells[(row + r) * size + (col + c)] = if (dark) 1 else 2
                    }
                }
            }
        }

        // timing
        for (r in 8 until size - 8) {
            if (cells[r * size + 6] == 0.toByte()) cells[r * size + 6] = if (r % 2 == 0) 1 else 2
        }
        for (c in 8 until size - 8) {
            if (cells[6 * size + c] == 0.toByte()) cells[6 * size + c] = if (c % 2 == 0) 1 else 2
        }

        // format info (ECC M bits = 00)
        val formatBits = bchTypeInfo(mask)
        for (i in 0 until 15) {
            val mod = !test && ((formatBits shr i) and 1) == 1
            val v: Byte = if (mod) 1 else 2
            when {
                i < 6 -> cells[i * size + 8] = v
                i < 8 -> cells[(i + 1) * size + 8] = v
                else -> cells[(size - 15 + i) * size + 8] = v
            }
        }
        for (i in 0 until 15) {
            val mod = !test && ((formatBits shr i) and 1) == 1
            val v: Byte = if (mod) 1 else 2
            when {
                i < 8 -> cells[8 * size + (size - i - 1)] = v
                i < 9 -> cells[8 * size + (15 - i)] = v // 15-i-1+1
                else -> cells[8 * size + (14 - i)] = v // 15-i-1
            }
        }
        cells[(size - 8) * size + 8] = if (test) 2 else 1 // dark module

        // version info (v >= 7)
        if (version >= 7) {
            val vbits = bchVersion(version)
            for (i in 0 until 18) {
                val mod = !test && ((vbits shr i) and 1) == 1
                val v: Byte = if (mod) 1 else 2
                cells[(i / 3) * size + (i % 3 + size - 11)] = v
                cells[(i % 3 + size - 11) * size + (i / 3)] = v
            }
        }

        // data placement (two-column zigzag)
        var inc = -1
        var row = size - 1
        var bitIndex = 7
        var byteIndex = 0
        val nBytes = codewords.size
        var colIter = size - 1
        while (colIter > 0) {
            val col = if (colIter <= 6) colIter - 1 else colIter
            while (true) {
                for (c in intArrayOf(col, col - 1)) {
                    if (cells[row * size + c] == 0.toByte()) {
                        var dark = false
                        if (byteIndex < nBytes) {
                            dark = ((codewords[byteIndex] shr bitIndex) and 1) == 1
                        }
                        if (maskFn(mask, row, c)) dark = !dark
                        cells[row * size + c] = if (dark) 1 else 2
                        bitIndex--
                        if (bitIndex == -1) {
                            byteIndex++
                            bitIndex = 7
                        }
                    }
                }
                row += inc
                if (row < 0 || row >= size) {
                    row -= inc
                    inc = -inc
                    break
                }
            }
            colIter -= 2
        }

        val modules = BooleanArray(size * size)
        for (i in modules.indices) modules[i] = cells[i] == 1.toByte()
        return QrMatrix(size, modules)
    }

    // ------------------------------------------------------------ helpers

    private fun bchTypeInfo(data: Int): Int {
        var d = data shl 10
        val g = 0x537
        while (d != 0 && bitLength(d) >= bitLength(g)) {
            d = d xor (g shl (bitLength(d) - bitLength(g)))
        }
        return ((data shl 10) or d) xor 0x5412
    }

    private fun bchVersion(version: Int): Int {
        var d = version shl 12
        val g = 0x1F25
        while (d != 0 && bitLength(d) >= bitLength(g)) {
            d = d xor (g shl (bitLength(d) - bitLength(g)))
        }
        return (version shl 12) or d
    }

    private fun bitLength(value: Int): Int = Integer.SIZE - Integer.numberOfLeadingZeros(value)

    private fun maskFn(pattern: Int, i: Int, j: Int): Boolean = when (pattern) {
        0 -> (i + j) % 2 == 0
        1 -> i % 2 == 0
        2 -> j % 3 == 0
        3 -> (i + j) % 3 == 0
        4 -> (i / 2 + j / 3) % 2 == 0
        5 -> (i * j) % 2 + (i * j) % 3 == 0
        6 -> ((i * j) % 2 + (i * j) % 3) % 2 == 0
        else -> ((i * j) % 3 + (i + j) % 2) % 2 == 0
    }

    // ----------------------------------------------------------- penalty

    private fun penalty(matrix: QrMatrix): Int {
        val size = matrix.size
        var lost = 0

        // rule 1: runs of 5+
        for (row in 0 until size) {
            var run = 1
            for (c in 1 until size) {
                if (matrix.isDark(row, c) == matrix.isDark(row, c - 1)) run++
                else {
                    if (run >= 5) lost += 3 + (run - 5)
                    run = 1
                }
            }
            if (run >= 5) lost += 3 + (run - 5)
        }
        for (col in 0 until size) {
            var run = 1
            for (r in 1 until size) {
                if (matrix.isDark(r, col) == matrix.isDark(r - 1, col)) run++
                else {
                    if (run >= 5) lost += 3 + (run - 5)
                    run = 1
                }
            }
            if (run >= 5) lost += 3 + (run - 5)
        }

        // rule 2: 2x2 same-color blocks
        for (r in 0 until size - 1) {
            for (c in 0 until size - 1) {
                val v = matrix.isDark(r, c)
                if (v == matrix.isDark(r, c + 1) && v == matrix.isDark(r + 1, c) && v == matrix.isDark(r + 1, c + 1)) {
                    lost += 3
                }
            }
        }

        // rule 3: finder-like 11-module windows
        val pat1 = booleanArrayOf(true, false, true, true, true, false, true, false, false, false, false)
        val pat2 = booleanArrayOf(false, false, false, false, true, false, true, true, true, false, true)
        fun hits(line: (Int) -> Boolean): Int {
            var count = 0
            for (i in 0..size - 11) {
                var m1 = true
                var m2 = true
                for (k in 0 until 11) {
                    val v = line(i + k)
                    if (v != pat1[k]) m1 = false
                    if (v != pat2[k]) m2 = false
                }
                if (m1 || m2) count++
            }
            return count
        }
        for (r in 0 until size) lost += hits { c -> matrix.isDark(r, c) } * 40
        for (c in 0 until size) lost += hits { r -> matrix.isDark(r, c) } * 40

        // rule 4: dark/light balance
        var dark = 0
        for (v in matrix.modules) if (v) dark++
        val percent = dark * 100.0 / (size * size)
        val rating = kotlin.math.abs(percent - 50).toInt() / 5
        lost += rating * 10

        return lost
    }
}
