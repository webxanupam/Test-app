package com.arix.app.data

import android.app.ActivityManager
import android.content.Context
import android.os.Build
import android.os.StatFs
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.io.FileOutputStream
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import android.net.Uri
import android.provider.OpenableColumns
import java.io.InputStream
import java.io.OutputStream

/**
 * On-Device AI model manager (v2.2.7).
 *
 * Inspired by the PAi_Android project's ModelManager: a curated catalog of
 * LiteRT-LM (.litertlm) models from the HuggingFace litert-community org,
 * device-spec detection (RAM, CPU, GPU/OpenGL ES, free storage, ABI) with a
 * per-device recommendation, streaming downloads with progress, file import,
 * and deletion. Model files live in filesDir/local-models and are surfaced in
 * Settings → Data & storage for cleanup.
 */
object ArixLocalModels {

    const val ModelsDirName = "local-models"

    data class LocalModelInfo(
        val id: String,
        val displayName: String,
        val sizeMb: Int,
        val minRamMb: Int,
        val requiresGpu: Boolean,
        val description: String,
        val downloadUrl: String,
    ) {
        val filename: String get() = "$id.litertlm"
    }

    data class DeviceSpecs(
        val totalRamMb: Int,
        val availableRamMb: Int,
        val cpuCores: Int,
        val abi: String,
        val androidVersion: String,
        val sdkInt: Int,
        val glEsVersion: String,
        val freeStorageMb: Long,
        val hasGpu: Boolean,
    )

    data class Compatibility(
        val compatible: Boolean,
        val ramOk: Boolean,
        val diskOk: Boolean,
        val gpuOk: Boolean,
        val details: String,
    )

    private const val HfLitert = "https://huggingface.co/litert-community"

    /**
     * Curated LiteRT-LM catalog.
     *
     * v2.4.0 download fix: the old list shipped dead links — the two Gemma 3n
     * entries pointed at gated repos (HTTP 401 for anonymous downloads) and
     * the Qwen3 1.7B file name no longer existed on the server (HTTP 404),
     * which is why every model download failed instantly. All URLs below are
     * verified, anonymous-downloadable files with their real sizes.
     */
    val catalog: List<LocalModelInfo> = listOf(
        LocalModelInfo(
            id = "gemma-4-e2b",
            displayName = "Gemma 4 E2B (2.5 GB)",
            sizeMb = 2468,
            minRamMb = 8192,
            requiresGpu = true,
            description = "Google's multimodal Gemma 4 E2B instruction model. Best quality; needs a modern GPU and 8 GB RAM.",
            downloadUrl = "$HfLitert/gemma-4-E2B-it-litert-lm/resolve/main/gemma-4-E2B-it.litertlm",
        ),
        LocalModelInfo(
            id = "gemma-4-e4b",
            displayName = "Gemma 4 E4B (3.5 GB)",
            sizeMb = 3489,
            minRamMb = 12288,
            requiresGpu = true,
            description = "The larger Gemma 4 E4B instruction model. Highest quality of the Gemma family; needs 12 GB RAM and a good GPU.",
            downloadUrl = "$HfLitert/gemma-4-E4B-it-litert-lm/resolve/main/gemma-4-E4B-it.litertlm",
        ),
        LocalModelInfo(
            id = "qwen3-4b-mixed-int4",
            displayName = "Qwen3 4B int4 (2.5 GB)",
            sizeMb = 2536,
            minRamMb = 6144,
            requiresGpu = false,
            description = "Qwen3 4B with mixed int4 quantization. Strong reasoning that also runs CPU-only on 6 GB RAM devices.",
            downloadUrl = "$HfLitert/Qwen3-4B/resolve/main/qwen3_4b_mixed_int4.litertlm",
        ),
        LocalModelInfo(
            id = "qwen3-4b-int8",
            displayName = "Qwen3 4B int8 (5.4 GB)",
            sizeMb = 5410,
            minRamMb = 8192,
            requiresGpu = false,
            description = "Qwen3 4B with channel-wise int8 weights. Higher fidelity than int4 at double the size.",
            downloadUrl = "$HfLitert/Qwen3-4B/resolve/main/qwen3_4b_channelwise_int8_float32kv.litertlm",
        ),
        LocalModelInfo(
            id = "qwen3-1-7b-mixed-int4",
            displayName = "Qwen3 1.7B int4 (~1 GB)",
            sizeMb = 932,
            minRamMb = 4096,
            requiresGpu = false,
            description = "Qwen3 1.7B dynamic int4 — a light all-rounder that fits comfortably on 4 GB RAM devices.",
            downloadUrl = "$HfLitert/Qwen3-1.7B/resolve/main/Qwen3-1.7B_dynamic_wi4b32_afp32.litertlm",
        ),
        LocalModelInfo(
            id = "qwen3-0-6b-mixed-int4",
            displayName = "Qwen3 0.6B int4 (~500 MB)",
            sizeMb = 475,
            minRamMb = 2048,
            requiresGpu = false,
            description = "The smallest Qwen3. Snappy short answers on any device with 2 GB RAM or more — the best starter model.",
            downloadUrl = "$HfLitert/Qwen3-0.6B/resolve/main/qwen3_0_6b_mixed_int4.litertlm",
        ),
    )

    /* --------------------------------------------------------- storage */

    fun modelsDir(context: Context): File =
        File(context.filesDir, ModelsDirName).apply { mkdirs() }

    fun isDownloaded(context: Context, model: LocalModelInfo): Boolean =
        File(modelsDir(context), model.filename).let { it.exists() && it.length() > 1024 }

    fun downloadedFile(context: Context, model: LocalModelInfo): File? =
        File(modelsDir(context), model.filename).takeIf { it.exists() }

    /** All model files present in storage (downloaded or imported). */
    fun listModelFiles(context: Context): List<File> =
        modelsDir(context).listFiles()
            ?.filter { it.isFile && it.length() > 1024 }
            ?.sortedBy { it.name }
            .orEmpty()

    fun totalBytes(context: Context): Long =
        listModelFiles(context).sumOf { it.length() }

    fun deleteModel(context: Context, file: File): Boolean = file.delete()

    /** File extensions accepted by the importer (on-device model formats). */
    private val modelExtensions = listOf(
        ".litertlm", ".litert", ".task", ".tflite", ".bin", ".gguf", ".bm",
    )

    /**
     * Imports a model file chosen through the system file picker. v2.2.8:
     * takes a persistable URI grant, resolves the display name through
     * multiple fallbacks, validates the extension/size, and streams the file
     * into the models directory with progress reporting.
     */
    suspend fun importModel(
        context: Context,
        uri: android.net.Uri,
        onProgress: (Float) -> Unit = {},
    ): Result<File> =
        withContext(Dispatchers.IO) {
            runCatching {
                val appContext = context.applicationContext
                // Keep read access for the whole session (harmless if refused).
                runCatching {
                    appContext.contentResolver.takePersistableUriPermission(
                        uri,
                        android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION,
                    )
                }
                val resolver = appContext.contentResolver
                var display = queryDisplayName(resolver, uri)
                if (display.isNullOrBlank()) {
                    display = uri.lastPathSegment?.substringAfterLast('/')?.substringAfter(':')
                }
                if (display.isNullOrBlank()) {
                    display = "imported-${System.currentTimeMillis()}.litertlm"
                }
                // Strip query strings some providers append.
                display = display.substringBefore('?').ifBlank { "imported-model.litertlm" }
                var name = display
                if (!modelExtensions.any { name.endsWith(it, ignoreCase = true) }) {
                    name = "$name.litertlm"
                }
                // Never overwrite an existing model: suffix (1), (2), …
                val base = name.substringBeforeLast('.')
                val ext = name.substringAfterLast('.', "litertlm")
                var target = File(modelsDir(appContext), name)
                var attempt = 1
                while (target.exists()) {
                    target = File(modelsDir(appContext), "$base ($attempt).$ext")
                    attempt += 1
                }
                val size = runCatching {
                    resolver.openInputStream(uri)?.use { it.available().toLong() } ?: -1L
                }.getOrDefault(-1L)
                resolver.openInputStream(uri)?.use { input ->
                    FileOutputStream(target).use { output ->
                        val buffer = ByteArray(64 * 1024)
                        var copied = 0L
                        while (true) {
                            val read = input.read(buffer)
                            if (read < 0) break
                            output.write(buffer, 0, read)
                            copied += read
                            if (size > 0) onProgress((copied.toFloat() / size).coerceAtMost(1f))
                        }
                    }
                } ?: error("The selected file could not be opened.")
                if (target.length() <= 1024) {
                    runCatching { target.delete() }
                    error("The selected file is not a valid model file (too small).")
                }
                onProgress(1f)
                target
            }
        }

    private fun queryDisplayName(
        resolver: android.content.ContentResolver,
        uri: android.net.Uri,
    ): String? = runCatching {
        resolver.query(uri, null, null, null, null)?.use { cursor ->
            if (cursor.moveToFirst()) {
                val index = cursor.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME)
                if (index >= 0) cursor.getString(index) else null
            } else {
                null
            }
        }
    }.getOrNull()

    /* ------------------------------------------------------ downloads */

    private val downloadClient: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(10, TimeUnit.MINUTES)
        .build()

    private val cancelledDownloads = mutableSetOf<String>()
    private val activeDownloads = mutableMapOf<String, Int>()

    fun cancelDownload(modelId: String) {
        synchronized(cancelledDownloads) { cancelledDownloads.add(modelId) }
    }

    fun isCancelled(modelId: String): Boolean =
        synchronized(cancelledDownloads) { modelId in cancelledDownloads }

    fun activeProgress(modelId: String): Int? =
        synchronized(activeDownloads) { activeDownloads[modelId] }

    data class DownloadOutcome(
        val file: File,
        /** Public Download-folder copy when the platform allowed it. */
        val downloadsCopy: Uri?,
    )

    /**
     * Streams a model download with progress callbacks and cancellation
     * support. Partial files are cleaned up when cancelled. The finished
     * model is stored in the app models directory and (best effort) copied
     * into the system Download folder so it shows up in the Files app.
     */
    suspend fun downloadModel(
        context: Context,
        model: LocalModelInfo,
        onProgress: (Float) -> Unit = {},
    ): Result<DownloadOutcome> = withContext(Dispatchers.IO) {
        val target = File(modelsDir(context), model.filename)
        if (target.exists() && target.length() > 1024) {
            return@withContext Result.success(DownloadOutcome(target, copyFileToDownloads(context, target)))
        }
        synchronized(cancelledDownloads) { cancelledDownloads.remove(model.id) }
        synchronized(activeDownloads) { activeDownloads[model.id] = 0 }
        try {
            val response = downloadClient.newCall(
                Request.Builder().url(model.downloadUrl).header("User-Agent", downloadUserAgent()).build(),
            ).execute()
            if (!response.isSuccessful) {
                return@withContext Result.failure(IllegalStateException("HTTP ${response.code}"))
            }
            val body = response.body ?: return@withContext Result.failure(IllegalStateException("Empty response"))
            val total = body.contentLength()
            val partial = File(target.absolutePath + ".part")
            body.byteStream().use { input ->
                FileOutputStream(partial).use { output ->
                    val buffer = ByteArray(64 * 1024)
                    var copied = 0L
                    var lastPercent = -1f
                    while (true) {
                        if (isCancelled(model.id)) {
                            runCatching { input.close() }
                            runCatching { partial.delete() }
                            return@withContext Result.failure(IllegalStateException("cancelled"))
                        }
                        val read = input.read(buffer)
                        if (read < 0) break
                        output.write(buffer, 0, read)
                        copied += read
                        if (total > 0) {
                            val percent = copied.toFloat() / total
                            if (percent - lastPercent >= 0.02f) {
                                lastPercent = percent
                                synchronized(activeDownloads) { activeDownloads[model.id] = (percent * 100).toInt() }
                                onProgress(percent)
                            }
                        }
                    }
                }
            }
            if (isCancelled(model.id)) {
                runCatching { partial.delete() }
                return@withContext Result.failure(IllegalStateException("cancelled"))
            }
            if (!partial.renameTo(target)) {
                runCatching { partial.delete() }
                return@withContext Result.failure(IllegalStateException("The model file could not be saved."))
            }
            synchronized(activeDownloads) { activeDownloads.remove(model.id) }
            onProgress(1f)
            // v2.2.8: also drop a copy into the system Download folder so the
            // model is visible/manageable in the device's Files app (best
            // effort — the app-private copy above is the one we manage).
            val downloadCopy = copyFileToDownloads(context, target)
            Result.success(DownloadOutcome(target, downloadCopy))
        } catch (throwable: Throwable) {
            runCatching { File(target.absolutePath + ".part").delete() }
            synchronized(activeDownloads) { activeDownloads.remove(model.id) }
            Result.failure(throwable)
        }
    }

    /**
     * Streams a file into the public Download folder: MediaStore.Downloads on
     * Android 10+ (no permission needed) or the legacy public directory on
     * older devices. Returns the resulting content:// or file:// Uri, or null
     * when the platform refused (e.g. missing legacy write permission).
     */
    fun copyFileToDownloads(context: Context, file: File): Uri? = runCatching {
        val appContext = context.applicationContext
        val mime = "application/octet-stream"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val values = android.content.ContentValues().apply {
                put(android.provider.MediaStore.Downloads.DISPLAY_NAME, file.name)
                put(android.provider.MediaStore.Downloads.MIME_TYPE, mime)
                put(android.provider.MediaStore.Downloads.IS_PENDING, 1)
            }
            val resolver = appContext.contentResolver
            val collection = android.provider.MediaStore.Downloads
                .getContentUri(android.provider.MediaStore.VOLUME_EXTERNAL_PRIMARY)
            val itemUri = resolver.insert(collection, values)
                ?: return@runCatching null
            try {
                resolver.openOutputStream(itemUri)?.use { output ->
                    file.inputStream().use { input -> input.copyTo(output) }
                } ?: error("stream closed")
                values.clear()
                values.put(android.provider.MediaStore.Downloads.IS_PENDING, 0)
                resolver.update(itemUri, values, null, null)
                itemUri
            } catch (throwable: Throwable) {
                runCatching { resolver.delete(itemUri, null, null) }
                null
            }
        } else {
            @Suppress("DEPRECATION")
            val downloadsDir = android.os.Environment
                .getExternalStoragePublicDirectory(android.os.Environment.DIRECTORY_DOWNLOADS)
            runCatching { downloadsDir.mkdirs() }
            val target = File(downloadsDir, file.name)
            file.copyTo(target, overwrite = true)
            Uri.fromFile(target)
        }
    }.getOrNull()

    /* -------------------------------------------------- device specs */

    /**
     * Device capability snapshot. v2.2.8: the old implementation called
     * GLES10.glGetString() with no EGL context — on many devices that native
     * call hard-crashes the whole app (SIGSEGV, uncatchable), which is why
     * the On-device models page crashed on open. GPU info now comes from
     * ActivityManager's DeviceConfigurationInfo, which needs no GL context.
     * Every step is additionally guarded so this can never take the app down.
     */
    fun deviceSpecs(context: Context): DeviceSpecs = runCatching {
        val appContext = context.applicationContext
        val activityManager = appContext.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager
        val memoryInfo = ActivityManager.MemoryInfo().also { activityManager?.getMemoryInfo(it) }
        val totalRamMb = (memoryInfo.totalMem / (1024L * 1024L)).toInt()
        val availableRamMb = (memoryInfo.availMem / (1024L * 1024L)).toInt()
        val freeStorageMb = runCatching {
            StatFs(appContext.filesDir.absolutePath).availableBytes / (1024L * 1024L)
        }.getOrDefault(0L)
        val glEs = runCatching {
            activityManager?.deviceConfigurationInfo?.glEsVersion
        }.getOrNull() ?: ""
        DeviceSpecs(
            totalRamMb = totalRamMb,
            availableRamMb = availableRamMb,
            cpuCores = Runtime.getRuntime().availableProcessors(),
            abi = Build.SUPPORTED_ABIS.firstOrNull() ?: "unknown",
            androidVersion = Build.VERSION.RELEASE ?: "",
            sdkInt = Build.VERSION.SDK_INT,
            glEsVersion = glEs,
            freeStorageMb = freeStorageMb,
            hasGpu = glEs.isNotBlank(),
        )
    }.getOrDefault(
        DeviceSpecs(
            totalRamMb = 0,
            availableRamMb = 0,
            cpuCores = Runtime.getRuntime().availableProcessors(),
            abi = Build.SUPPORTED_ABIS.firstOrNull() ?: "unknown",
            androidVersion = Build.VERSION.RELEASE ?: "",
            sdkInt = Build.VERSION.SDK_INT,
            glEsVersion = "",
            freeStorageMb = 0L,
            hasGpu = false,
        ),
    )

    fun checkCompatibility(specs: DeviceSpecs, model: LocalModelInfo): Compatibility {
        val ramOk = specs.totalRamMb >= model.minRamMb
        val diskOk = specs.freeStorageMb >= (model.sizeMb * 1.15).toLong()
        val gpuOk = !model.requiresGpu || (specs.hasGpu && specs.totalRamMb >= model.minRamMb)
        val details = buildString {
            append("RAM: ${specs.totalRamMb} MB of ${model.minRamMb} MB required — ${if (ramOk) "ok" else "not enough"}")
            append('\n')
            append("Free storage: ${specs.freeStorageMb} MB of ${model.sizeMb} MB needed — ${if (diskOk) "ok" else "not enough"}")
            append('\n')
            append(
                if (model.requiresGpu) {
                    "GPU delegate required — ${if (gpuOk) "available" else "not detected"}"
                } else {
                    "Runs on CPU or GPU"
                },
            )
        }
        return Compatibility(ramOk && diskOk && gpuOk, ramOk, diskOk, gpuOk, details)
    }

    /** The model the app recommends for the current device (largest that fits). */
    fun recommendedModel(context: Context): LocalModelInfo? {
        val specs = deviceSpecs(context)
        return catalog
            .filter { specs.totalRamMb >= it.minRamMb && specs.freeStorageMb >= (it.sizeMb * 1.15).toLong() }
            .maxByOrNull { it.sizeMb }
            ?: catalog.firstOrNull { it.id == "qwen3-0-6b-mixed-int4" }
    }

    /**
     * v2.4.0: the previous download user-agent was stale and several URLs in
     * the catalog pointed at gated/removed files, so downloads failed with
     * 401/404 before any progress appeared. The UA now identifies the current
     * version so HuggingFace serves the CDN redirect properly.
     */
    fun downloadUserAgent(): String = "Arix/2.4.0 (Android; local model download)"
}
