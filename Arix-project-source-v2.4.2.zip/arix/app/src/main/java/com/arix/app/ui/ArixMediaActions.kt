package com.arix.app.ui

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.core.content.FileProvider
import java.io.File
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * v2.4.1 — shared download/share actions for media produced by the agent
 * (chat-rendered images, generated files in the Alpine workspace).
 *
 * Reuses the FileProvider cache path declared for the assistant
 * (assistant_local_open/) so no new manifest plumbing is needed.
 */
object ArixMediaActions {

    /**
     * Saves media bytes into the system Downloads collection via
     * [ArixMediaDownloads]; returns the resulting content uri. Runs blocking
     * IO — call from Dispatchers.IO.
     */
    fun downloadToDownloads(
        context: Context,
        fileName: String,
        mimeType: String,
        bytes: ByteArray,
    ): Uri = ArixMediaDownloads.saveToDownloads(context, fileName, mimeType, bytes)

    /**
     * Stages [bytes] into the shared cache directory (evicting older staged
     * files) so they can be shared through the FileProvider. Runs on IO.
     */
    suspend fun stageShareFile(
        context: Context,
        fileName: String,
        bytes: ByteArray,
    ): File = withContext(Dispatchers.IO) {
        val appContext = context.applicationContext
        val shareDir = File(appContext.cacheDir, "assistant-local-open").apply { mkdirs() }
        // Keep the directory tiny: drop everything older than the new file.
        shareDir.listFiles()?.forEach { it.delete() }
        val safeName = fileName.replace(Regex("[^A-Za-z0-9._ ()-]"), "_").ifBlank { "arix-file" }
        File(shareDir, safeName).apply { writeBytes(bytes) }
    }

    /**
     * Opens the system share sheet for a previously staged file. Must be
     * called from the main thread.
     */
    fun shareStagedFile(
        context: Context,
        file: File,
        mimeType: String,
    ): Boolean = runCatching {
        val appContext = context.applicationContext
        val uri = FileProvider.getUriForFile(
            appContext,
            "${appContext.packageName}.fileprovider",
            file,
        )
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = mimeType.ifBlank { "application/octet-stream" }
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        appContext.startActivity(
            Intent.createChooser(intent, file.name).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
        )
        true
    }.getOrDefault(false)

    /**
     * Convenience for small in-memory payloads: stages and shares in one
     * synchronous call (main thread; the cache write is tiny).
     */
    fun shareBytes(
        context: Context,
        fileName: String,
        mimeType: String,
        bytes: ByteArray,
    ): Boolean = runCatching {
        val appContext = context.applicationContext
        val shareDir = File(appContext.cacheDir, "assistant-local-open").apply { mkdirs() }
        shareDir.listFiles()?.forEach { it.delete() }
        val safeName = fileName.replace(Regex("[^A-Za-z0-9._ ()-]"), "_").ifBlank { "arix-file" }
        val shareFile = File(shareDir, safeName)
        shareFile.writeBytes(bytes)
        shareStagedFile(context, shareFile, mimeType)
    }.getOrDefault(false)

    /** Human-friendly byte size for file cards. */
    fun formatFileSize(bytes: Long): String {
        if (bytes <= 0) return ""
        val kb = bytes / 1024.0
        val mb = kb / 1024.0
        val gb = mb / 1024.0
        return when {
            gb >= 1 -> "%.2f GB".format(gb)
            mb >= 1 -> "%.1f MB".format(mb)
            kb >= 1 -> "%.0f KB".format(kb)
            else -> "$bytes B"
        }
    }
}
