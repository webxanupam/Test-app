package com.arix.app.data

import android.annotation.SuppressLint
import android.content.Context
import android.os.Handler
import android.os.Looper
import android.webkit.WebView
import android.webkit.WebViewClient
import kotlinx.coroutines.delay
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withTimeout
import org.json.JSONObject
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicLong
import kotlin.coroutines.resume

/**
 * WebView-backed page fetcher for extension data sources.
 *
 * Some sites (e.g. the movie explorer source) sit behind Cloudflare bot
 * management that blocks every non-browser TLS fingerprint, so plain HTTP
 * clients receive 403 challenge pages regardless of headers. This fetcher
 * loads a real Chromium WebView on the site origin — the same engine the
 * in-chat players already use — lets any challenge clear, and then runs a
 * same-origin `fetch()` inside the page so the response arrives with the
 * browser's TLS fingerprint and cookies intact.
 *
 * One WebView is kept alive per origin (a challenge only has to clear once)
 * and reloaded only when the session is challenged again.
 */
class WebViewFetcher(context: Context) {

    private val appContext = context.applicationContext
    private val mainHandler = Handler(Looper.getMainLooper())
    private val origins = ConcurrentHashMap<String, OriginSession>()

    private class OriginSession {
        val webView = AtomicReferenceHolder()
        @Volatile var ready: Boolean = false
        @Volatile var lastFinishedAtMillis: Long = 0L
        @Volatile var lastFinishedUrl: String = ""
    }

    private class AtomicReferenceHolder {
        private val reference = java.util.concurrent.atomic.AtomicReference<WebView?>(null)
        fun get(): WebView? = reference.get()
        fun set(value: WebView?) = reference.set(value)
    }

    suspend fun fetch(url: String, timeoutMs: Long = 25_000): String {
        val origin = extractOrigin(url) ?: error("A valid http(s) URL is required.")
        return withTimeout(timeoutMs) {
            val session = obtainSession(origin)
            if (!session.ready) {
                waitForOriginReady(origin, session, reload = false)
            }
            fetchInOrigin(origin, session, url)
        }
    }

    private fun obtainSession(origin: String): OriginSession =
        origins.getOrPut(origin) {
            val session = OriginSession()
            mainHandler.post {
                session.webView.set(createWebView(session))
                session.webView.get()?.loadUrl("$origin/")
            }
            session
        }

    /** Wait until the origin page finished loading and any Cloudflare
     *  challenge on it has cleared. */
    private suspend fun waitForOriginReady(origin: String, session: OriginSession, reload: Boolean) {
        if (reload) {
            session.ready = false
            session.lastFinishedUrl = ""
            mainHandler.post { session.webView.get()?.loadUrl("$origin/") }
        }
        val deadline = System.currentTimeMillis() + ChallengeClearTimeoutMs
        // First wait for a page finish on the origin host.
        while (System.currentTimeMillis() < deadline) {
            if (session.lastFinishedUrl.startsWith(origin) &&
                System.currentTimeMillis() - session.lastFinishedAtMillis > PostLoadSettleMs
            ) {
                break
            }
            delay(350)
        }
        // Then poll until the loaded page is not a challenge page.
        while (System.currentTimeMillis() < deadline) {
            val webView = session.webView.get()
            if (webView == null) {
                delay(200)
                continue
            }
            when (evaluateState(webView)) {
                OriginState.Ready -> {
                    session.ready = true
                    return
                }

                OriginState.Challenge -> delay(900)

                OriginState.Loading -> delay(450)
            }
        }
        // Never became fully ready — still attempt the fetch, some challenges
        // only clear after the first real data navigation.
        session.ready = true
    }

    /** Run a same-origin fetch() inside the origin page and await its body. */
    private suspend fun fetchInOrigin(origin: String, session: OriginSession, url: String): String {
        val webView = session.webView.get() ?: error("The origin WebView is no longer available.")
        var attempt = 0
        while (attempt < 2) {
            attempt += 1
            val started = evaluateJsSuspending(webView, startFetchScript(url))
            if (started != "started") {
                error("The in-page fetch could not be started: $started")
            }
            val deadline = System.currentTimeMillis() + FetchPollTimeoutMs
            while (System.currentTimeMillis() < deadline) {
                val outcome = readScriptedFetchResult(webView)
                when (outcome) {
                    is FetchOutcome.Pending -> delay(280)

                    is FetchOutcome.Done -> {
                        if (outcome.isChallengeLike && attempt == 1) {
                            // The session was re-challenged: reload the origin
                            // root once, wait for clearance, then retry.
                            waitForOriginReady(origin, session, reload = true)
                            break
                        }
                        if (outcome.body.isNotBlank()) return outcome.body
                        error("The site returned HTTP ${outcome.status} with an empty body.")
                    }

                    is FetchOutcome.Failed -> error(outcome.message)
                }
            }
        }
        error("The page fetch timed out.")
    }

    private fun startFetchScript(url: String): String {
        val urlLiteral = JSONObject.quote(url) ?: "\"\""
        return """
            (function(){
              try {
                window.__arixFetchResult = null;
                window.__arixFetchError = null;
                fetch($urlLiteral, {credentials:'include', redirect:'follow'})
                  .then(function(r){
                    return r.text().then(function(t){
                      window.__arixFetchResult = JSON.stringify({status: r.status, body: t});
                    });
                  })
                  .catch(function(e){ window.__arixFetchError = String(e && e.message || e); });
                return 'started';
              } catch (e) { return 'error:' + String(e && e.message || e); }
            })()
        """.trimIndent()
    }

    private suspend fun readScriptedFetchResult(webView: WebView): FetchOutcome {
        val raw = evaluateJsSuspending(
            webView,
            "(function(){ try { return JSON.stringify({ result: window.__arixFetchResult, error: window.__arixFetchError }); } catch (e) { return '{}'; } })()",
        )
        val wrapper = runCatching { JSONObject(raw.orEmpty()) }.getOrNull() ?: return FetchOutcome.Pending
        val error = wrapper.optString("error")
        if (error.isNotBlank() && error != "null") {
            return FetchOutcome.Failed("The in-page fetch failed: $error")
        }
        val result = wrapper.optString("result")
        if (result.isBlank() || result == "null") return FetchOutcome.Pending
        val payload = runCatching { JSONObject(result) }.getOrNull() ?: return FetchOutcome.Pending
        val status = payload.optInt("status", 0)
        val body = payload.optString("body")
        val challengeLike = status == 403 || status == 503 ||
            (body.contains("Just a moment", ignoreCase = true) &&
                body.contains("<", ignoreCase = true) &&
                !body.contains("postbox"))
        return FetchOutcome.Done(status, body, challengeLike)
    }

    private suspend fun evaluateState(webView: WebView): OriginState {
        val state = evaluateJsSuspending(
            webView,
            """
            (function(){
              try {
                var title = document.title || '';
                var text = (document.body && document.body.innerText) || '';
                if (title.indexOf('Just a moment') >= 0 ||
                    title.indexOf('Attention Required') >= 0 ||
                    title.indexOf('Verify you are human') >= 0 ||
                    text.indexOf('Verify you are human') >= 0 ||
                    text.indexOf('Checking your browser') >= 0) {
                  return 'challenge';
                }
                if (document.readyState === 'loading' && text.trim().length === 0) return 'loading';
                return 'ready';
              } catch (e) { return 'loading'; }
            })()
            """.trimIndent(),
        ).orEmpty()
        return when {
            state.contains("challenge", ignoreCase = true) -> OriginState.Challenge
            state.contains("ready", ignoreCase = true) -> OriginState.Ready
            else -> OriginState.Loading
        }
    }

    /** Evaluate JS on the main thread and resume with the decoded value. */
    private suspend fun evaluateJsSuspending(webView: WebView, script: String): String? =
        suspendCancellableCoroutine { continuation ->
            val posted = mainHandler.post {
                runCatching {
                    webView.evaluateJavascript(script) { value ->
                        if (continuation.isActive) continuation.resume(decodeJsStringValue(value))
                    }
                }.onFailure { throwable ->
                    if (continuation.isActive) {
                        continuation.resume(
                            "error:" + (throwable.message ?: throwable.javaClass.simpleName)
                        )
                    }
                }
            }
            if (!posted && continuation.isActive) {
                continuation.resume("error:main thread unavailable")
            }
        }

    private fun decodeJsStringValue(value: String?): String? {
        if (value == null) return null
        if (value == "null") return null
        if (value.length >= 2 && value.startsWith("\"") && value.endsWith("\"")) {
            return runCatching { JSONObject("{\"v\":$value}").optString("v") }.getOrDefault(value)
        }
        return value
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun createWebView(session: OriginSession): WebView =
        WebView(appContext).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.userAgentString = BrowserUserAgent
            settings.blockNetworkImage = true
            settings.loadsImagesAutomatically = false
            webViewClient = object : WebViewClient() {
                override fun onPageFinished(view: WebView?, url: String?) {
                    session.lastFinishedAtMillis = System.currentTimeMillis()
                    session.lastFinishedUrl = url.orEmpty()
                    if (url.orEmpty().startsWith("about:blank").not() && url.orEmpty().isNotBlank()) {
                        // A real page finished; readiness is confirmed by polling.
                    }
                }
            }
        }

    private sealed interface FetchOutcome {
        data object Pending : FetchOutcome
        data class Done(val status: Int, val body: String, val isChallengeLike: Boolean) : FetchOutcome
        data class Failed(val message: String) : FetchOutcome
    }

    private enum class OriginState { Loading, Ready, Challenge }

    private companion object {
        const val ChallengeClearTimeoutMs = 18_000L
        const val PostLoadSettleMs = 600L
        const val FetchPollTimeoutMs = 18_000L
        const val BrowserUserAgent =
            "Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 " +
                "(KHTML, like Gecko) Chrome/125.0.0.0 Mobile Safari/537.36"
    }
}

private fun extractOrigin(url: String): String? {
    val marker = url.indexOf("://")
    if (marker <= 0) return null
    val rest = url.substring(marker + 3)
    val slash = rest.indexOf('/')
    val authority = if (slash >= 0) rest.substring(0, slash) else rest
    if (authority.isBlank()) return null
    return url.substring(0, marker + 3) + authority
}
