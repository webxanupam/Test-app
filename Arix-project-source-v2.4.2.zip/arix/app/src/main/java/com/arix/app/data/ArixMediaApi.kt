package com.arix.app.data

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.LruCache
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.runBlocking
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.io.File
import java.security.MessageDigest
import java.util.concurrent.TimeUnit
import kotlin.coroutines.cancellation.CancellationException

/**
 * ArixMediaApi — the app-side "backend" for the Movie Explorer and Anime
 * Explorer tools.
 *
 * v2.2.7 root-cause fix: the previous fetch chain led with 15 public CORS
 * proxies and only tried the origin afterwards. Those workers.dev proxies are
 * frequently dead or rate-limited and return Cloudflare challenge pages that
 * still pass the naive "looks like HTML" check, so the scraper received a
 * challenge page instead of the movie page and found zero playable servers.
 * Live testing showed the origin now serves plain requests directly, so the
 * order is now:
 *
 *   1. DIRECT request on both mirror domains, raced in parallel (fast path)
 *   2. Public CORS proxies, raced in small parallel waves (fallback)
 *
 * Every response is VALIDATED per content kind (a list page must contain
 * postbox markers, a detail page must contain an iframe) so a proxy that
 * returns a challenge/error page can never win the race again.
 *
 * On top of the fetch chain sits a JSON cache layer (memory + disk) so repeat
 * requests for the same listing resolve instantly — the UI consumes pure JSON
 * exactly like a backend API response. Poster images go through the same
 * backend with an optional resizing proxy and a memory + disk bitmap cache.
 */
object ArixMediaApi {

    const val BrowserUserAgent =
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 " +
            "(KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36"

    const val WompBase = "https://www.watchonlinemovies.com.pk"
    const val SiteBase = "https://www.watch-movies.com.pk"
    const val AnimeLokBase = "https://animelok.live"
    const val AnimeSaltBase = "https://animesalt.cx"

    /** Public CORS proxies used ONLY as a fallback when direct fetch fails. */
    private val proxies = listOf(
        "https://cors.caliph.my.id/",
        "https://api.codetabs.com/v1/proxy?quest=",
        "https://api.allorigins.win/raw?url=",
        "https://proxy.it-mohmmed.workers.dev/?url=",
        "https://proxy.khacmanh-info.workers.dev/?url=",
        "https://proxy.khacdat-info.workers.dev/?url=",
        "https://proxy.nkm1703.workers.dev/?url=",
        "https://proxy.uneti-it.workers.dev/?url=",
        "https://proxy.teamvn1235.workers.dev/?url=",
        "https://proxy.zeronightpro.workers.dev/?url=",
        "https://proxy.manhrit.workers.dev/?url=",
        "https://proxy.cskh-n8n.workers.dev/?url=",
        "https://proxy.manhnguyenict.workers.dev/?url=",
        "https://proxy.nguyenmanhict.workers.dev/?url=",
        "https://proxy.cskh-zm.workers.dev/?url=",
        "https://proxy.tgb6jphrx7.workers.dev/?url=",
        "https://proxy.manhict.workers.dev/?url=",
    )

    val httpClient: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(9, TimeUnit.SECONDS)
        .readTimeout(14, TimeUnit.SECONDS)
        .followRedirects(true)
        .build()

    private val imageClient: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(8, TimeUnit.SECONDS)
        .readTimeout(12, TimeUnit.SECONDS)
        .followRedirects(true)
        .build()

    /** Dedicated client for embed player pages: they must fail fast so the
     *  player card never stalls waiting for a dead video host. */
    val embedClient: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(7, TimeUnit.SECONDS)
        .readTimeout(10, TimeUnit.SECONDS)
        .followRedirects(true)
        .build()

    /** Content kinds used for response validation. */
    enum class Kind { MOVIE_LIST, MOVIE_DETAIL, ANIME_LIST, ANIME_DETAIL, JSON, GENERIC }

    /* ------------------------------------------------------------- caching */

    private const val MemoryCacheEntries = 24
    private val memoryCache = LinkedHashMap<String, CacheEntry>(16, 0.75f, true)
    private var cacheDir: File? = null
    private val cacheLock = Any()

    private const val ListTtlMillis = 10 * 60 * 1000L
    private const val DetailTtlMillis = 30 * 60 * 1000L

    private class CacheEntry(val body: String, val timestamp: Long, val ttl: Long) {
        val isFresh: Boolean get() = System.currentTimeMillis() - timestamp < ttl
    }

    fun initialize(context: Context) {
        synchronized(cacheLock) {
            cacheDir = File(context.cacheDir, "media-api").apply { mkdirs() }
            // Trim any stale entries left behind by a previous run.
        cacheDir?.listFiles()?.forEach { file ->
                runCatching {
                    val wrapper = JSONObject(file.readText())
                    val ts = wrapper.optLong("ts", 0L)
                    val ttl = wrapper.optLong("ttl", ListTtlMillis)
                    if (System.currentTimeMillis() - ts > ttl * 3) file.delete()
                }
            }
        }
    }

    private fun cacheKey(url: String): String = md5(url)

    private fun diskFile(key: String): File? = cacheDir?.let { File(it, "$key.json") }

    /**
     * Cached JSON fetch: memory → disk (fresh) → network. When the network
     * fails but a stale cached copy exists, the stale copy is served so the
     * widget still renders instantly instead of erroring out.
     */
    fun fetchCachedJson(
        url: String,
        kind: Kind,
        ttl: Long = if (kind == Kind.MOVIE_DETAIL || kind == Kind.ANIME_DETAIL) DetailTtlMillis else ListTtlMillis,
        fetcher: () -> String,
    ): String {
        val key = cacheKey(url)
        synchronized(cacheLock) {
            memoryCache[key]?.let { entry ->
                if (entry.isFresh) return entry.body
            }
        }
        diskFile(key)?.let { file ->
            if (file.exists()) {
                runCatching {
                    val wrapper = JSONObject(file.readText())
                    val body = wrapper.optString("body")
                    if (body.isNotBlank()) {
                        val entry = CacheEntry(body, wrapper.optLong("ts", 0L), wrapper.optLong("ttl", ttl))
                        if (entry.isFresh) {
                            synchronized(cacheLock) {
                                memoryCache[key] = entry
                                trimMemoryLocked()
                            }
                            return body
                        }
                    }
                }
            }
        }
        val fetched = fetcher()
        if (fetched.isNotBlank()) {
            val entry = CacheEntry(fetched, System.currentTimeMillis(), ttl)
            synchronized(cacheLock) {
                memoryCache[key] = entry
                trimMemoryLocked()
            }
            runCatching {
                diskFile(key)?.writeText(
                    JSONObject()
                        .put("url", url)
                        .put("ts", entry.timestamp)
                        .put("ttl", ttl)
                        .put("body", fetched)
                        .toString(),
                )
            }
        }
        return fetched
    }

    /** Returns a stale cached body when available (network failed). */
    fun staleCachedJson(url: String): String? {
        val key = cacheKey(url)
        synchronized(cacheLock) {
            memoryCache[key]?.let { return it.body }
        }
        diskFile(key)?.let { file ->
            if (file.exists()) {
                runCatching {
                    val wrapper = JSONObject(file.readText())
                    val body = wrapper.optString("body")
                    if (body.isNotBlank()) return body
                }
            }
        }
        return null
    }

    fun clearCaches() {
        synchronized(cacheLock) {
            memoryCache.clear()
        }
        runCatching { cacheDir?.deleteRecursively() }
        runCatching { cacheDir?.mkdirs() }
        runCatching { posterDiskDir?.deleteRecursively() }
        runCatching { posterDiskDir?.mkdirs() }
        posterMemory.evictAll()
    }

    private fun trimMemoryLocked() {
        while (memoryCache.size > MemoryCacheEntries) {
            val eldest = memoryCache.entries.iterator()
            if (!eldest.hasNext()) break
            eldest.next()
            eldest.remove()
        }
    }

    /* -------------------------------------------------------------- fetch */

    /** True when the HTML looks like the page we actually asked for. */
    fun validate(body: String, kind: Kind): Boolean {
        if (body.length < 900) return false
        return when (kind) {
            Kind.MOVIE_LIST -> body.contains("postbox", ignoreCase = true) ||
                body.contains("wp-json", ignoreCase = true) ||
                body.contains("\"title\"", ignoreCase = true)
            Kind.MOVIE_DETAIL -> body.contains("<iframe", ignoreCase = true) ||
                body.contains("data-wpfc-original-src", ignoreCase = true) ||
                body.contains("entry-content", ignoreCase = true)
            Kind.ANIME_LIST -> body.contains("/anime/", ignoreCase = true) ||
                body.contains("anime", ignoreCase = true)
            Kind.ANIME_DETAIL -> body.contains("iframe", ignoreCase = true) ||
                body.contains("episode", ignoreCase = true) ||
                body.contains("servers", ignoreCase = true)
            Kind.JSON -> body.trim().startsWith("{") || body.trim().startsWith("[")
            Kind.GENERIC -> body.contains("<")
        }
    }

    private fun requestFor(url: String, accept: String): Request = Request.Builder()
        .url(url)
        .header("User-Agent", BrowserUserAgent)
        .header("Accept", accept)
        .header("Accept-Language", "en-US,en;q=0.9")
        .header("Sec-Fetch-Dest", "document")
        .header("Sec-Fetch-Mode", "navigate")
        .header("Sec-Fetch-Site", "none")
        .header("Upgrade-Insecure-Requests", "1")
        .build()

    private fun fetchDirect(url: String, accept: String): String? = runCatching {
        httpClient.newCall(requestFor(url, accept)).execute().use { response ->
            if (!response.isSuccessful) return@runCatching null
            val body = response.body?.string().orEmpty()
            if (body.isBlank()) null else body
        }
    }.getOrNull()

    /** Fetch via a public CORS proxy (raw URL appended, never encoded). */
    private fun fetchViaProxy(proxy: String, url: String): String? = runCatching {
        val request = Request.Builder()
            .url(proxy + url) // raw URL — workers.dev proxies reject encoded targets
            .header("User-Agent", BrowserUserAgent)
            .header("Accept", "text/html,application/xhtml+xml,application/json;q=0.9,*/*;q=0.8")
            .build()
        httpClient.newCall(request).execute().use { response ->
            if (!response.isSuccessful) return@runCatching null
            val body = response.body?.string().orEmpty()
            if (body.isBlank()) null else body
        }
    }.getOrNull()

    /**
     * Fetch a page with DIRECT-first ordering and per-kind validation.
     * Mirrors: for the movie site both domains are raced; anime sites race
     * their redirect targets. Proxies are only tried when direct fails.
     */
    fun fetchPage(url: String, kind: Kind = Kind.GENERIC): String {
        val errors = mutableListOf<String>()
        val mirror = mirrorFor(url)
        val directCandidates = buildList {
            add(url)
            if (mirror != null && mirror != url) add(mirror)
        }

        // 1. DIRECT first — raced in parallel, first VALID body wins.
        runCatching {
            val results = runBlocking {
                coroutineScope {
                    directCandidates.map { candidate ->
                        async(Dispatchers.IO) {
                            fetchDirect(candidate, "text/html,application/xhtml+xml,*/*;q=0.8")
                        }
                    }.awaitAll()
                }
            }
            results.forEachIndexed { index, body ->
                if (body != null && validate(body, kind)) return body
                if (body != null) errors.add("direct${if (index > 0) "-mirror" else ""}: invalid-content")
            }
        }.onFailure { throwable ->
            if (throwable is CancellationException) throw throwable
            errors.add("direct: ${throwable.message?.take(40) ?: "error"}")
        }

        // 2. Proxy fallback — two small parallel waves over shuffled proxies.
        val shuffled = proxies.shuffled()
        for (wave in 0 until 2) {
            val batch = shuffled.drop(wave * 4).take(4)
            if (batch.isEmpty()) break
            val results = runCatching {
                runBlocking {
                    coroutineScope {
                        batch.map { proxy ->
                            async(Dispatchers.IO) {
                                runCatching { fetchViaProxy(proxy, url) }.getOrNull()
                            }
                        }.awaitAll()
                    }
                }
            }.getOrNull() ?: emptyList()
            results.forEach { body ->
                if (body != null && validate(body, kind)) return body
            }
            errors.add("proxies-wave-$wave: no valid response")
        }

        error("All fetch attempts failed (${errors.take(4).joinToString("; ")})")
    }

    /** Fetch a JSON API endpoint (direct first, proxies as fallback). */
    fun fetchJson(url: String): String = fetchPage(url, Kind.JSON)

    private fun mirrorFor(url: String): String? = when {
        url.startsWith(WompBase) -> url.replace(WompBase, SiteBase)
        url.startsWith(SiteBase) -> url.replace(SiteBase, WompBase)
        url.startsWith("https://animesalt.ac/") -> url.replace("https://animesalt.ac/", "$AnimeSaltBase/")
        url.startsWith("https://animesalt.cx/") -> url.replace("$AnimeSaltBase/", "https://animesalt.ac/")
        else -> null
    }

    /* ---------------------------------------------------- poster loading */

    /**
     * Rewrites a poster URL through the wsrv.nl resizing proxy when the host
     * is supported (movie site, tmdb, generic hosts). AniList CDN images are
     * served directly (wsrv.nl rejects them) — the bitmap cache handles those.
     */
    fun thumbUrl(original: String, widthPx: Int = 244): String {
        if (original.isBlank() || !original.startsWith("http")) return original
        if (original.contains("anilist.co", ignoreCase = true)) return original
        if (original.contains("wsrv.nl", ignoreCase = true)) return original
        return "https://wsrv.nl/?url=" + android.net.Uri.encode(original) +
            "&w=$widthPx&output=webp&q=72&il"
    }

    private val posterMemory: LruCache<String, Bitmap> = object : LruCache<String, Bitmap>(36) {}
    private var posterDiskDir: File? = null

    fun initializePosterCache(context: Context) {
        posterDiskDir = File(context.cacheDir, "posters").apply { mkdirs() }
    }

    private fun posterKey(url: String): String = md5(url)

    /**
     * Loads a poster bitmap with memory → disk → network resolution and a
     * downscaled disk copy so a poster is downloaded at most once per cache
     * lifetime. Blocks; call from Dispatchers.IO.
     *
     * v2.3.2: the direct origin is tried FIRST and the wsrv.nl resizing
     * proxy only as a fallback. The proxy is unreachable from several
     * networks (which left MovieBox posters blank), while the origin CDN
     * (pbcdnw.aoneroom.com, tmdb) serves images without any referer.
     */
    fun loadPoster(url: String, widthPx: Int = 244): Bitmap? {
        if (url.isBlank()) return null
        val key = posterKey(url)
        posterMemory.get(key)?.let { return it }
        posterDiskDir?.let { dir ->
            val file = File(dir, key)
            if (file.exists()) {
                runCatching {
                    val cached = BitmapFactory.decodeFile(file.absolutePath)
                    if (cached != null) {
                        posterMemory.put(key, cached)
                        return cached
                    }
                }
            }
        }
        val normalized = if (url.startsWith("//")) "https:$url" else url
        val downloaded = downloadBitmap(normalized)
            ?: downloadBitmap(thumbUrl(normalized, widthPx))
        var bitmap = downloaded ?: return null
        // Normalize the size so the disk cache stays small.
        if (bitmap.width > widthPx * 2) {
            val scale = (widthPx * 2).toFloat() / bitmap.width
            bitmap = Bitmap.createScaledBitmap(
                bitmap,
                (bitmap.width * scale).toInt().coerceAtLeast(1),
                (bitmap.height * scale).toInt().coerceAtLeast(1),
                true,
            )
        }
        posterMemory.put(key, bitmap)
        posterDiskDir?.let { dir ->
            runCatching {
                val file = File(dir, key)
                file.outputStream().use { output ->
                    bitmap.compress(Bitmap.CompressFormat.WEBP_LOSSY, 78, output)
                }
            }
        }
        return bitmap
    }

    private fun downloadBitmap(url: String): Bitmap? = runCatching {
        val request = Request.Builder()
            .url(url)
            .header("User-Agent", BrowserUserAgent)
            .header("Accept", "image/avif,image/webp,image/*,*/*;q=0.8")
            .build()
        imageClient.newCall(request).execute().use { response ->
            if (!response.isSuccessful) return@runCatching null
            val bytes = response.body?.byteStream()?.use { it.readBytes() } ?: return@runCatching null
            if (bytes.isEmpty() || bytes.size > 8 * 1024 * 1024) return@runCatching null
            BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
        }
    }.getOrNull()

    /* -------------------------------------------------------------- utils */

    fun md5(value: String): String {
        val digest = MessageDigest.getInstance("MD5")
        return digest.digest(value.toByteArray(Charsets.UTF_8))
            .joinToString("") { "%02x".format(it) }
    }

    fun decodeEntities(input: String): String = input
        .replace("&nbsp;", " ")
        .replace("&amp;", "&")
        .replace("&quot;", "\"")
        .replace("&#0?39;".toRegex(), "'")
        .replace("&apos;", "'")
        .replace("&#x27;".toRegex(), "'")
        .replace("&lt;", "<")
        .replace("&gt;", ">")
        .replace("&#8211;|&ndash;".toRegex(), "-")
        .replace("&#8212;|&mdash;".toRegex(), "-")
        .replace("&#8216;|&#8217;|&lsquo;|&rsquo;".toRegex(), "'")
        .replace("&#8220;|&#8221;|&ldquo;|&rdquo;".toRegex(), "\"")
        .replace("&#(\\d+);".toRegex()) { match ->
            match.groupValues[1].toIntOrNull()?.toChar()?.toString() ?: ""
        }
        .replace("\\s+".toRegex(), " ")
        .trim()

    /** True for lazy-load placeholders (wp-fastest-cache blank.gif, logos…). */
    fun isPlaceholderImage(url: String): Boolean {
        val value = url.lowercase()
        return value.contains("logo") ||
            value.contains("placeholder") ||
            value.contains("wp-fastest-cache") ||
            value.endsWith("blank.gif") ||
            value.endsWith("blank.png") ||
            value.endsWith("default.png")
    }

    fun normalizeUrl(raw: String): String {
        val value = raw.trim()
        return if (value.startsWith("//")) "https:$value" else value
    }

    /* ------------------------------------------------ direct video resolver */

    /**
     * Decodes every Dean Edwards `eval(function(p,a,c,k,e,d){…})` packed
     * script in the page. Embed hosts wrap their stream setup in such a
     * packer — and so do the ad scripts around it — so all occurrences are
     * decoded and the caller scans each result for a video URL.
     */
    fun unpackAllPackedJs(html: String): List<String> {
        val results = mutableListOf<String>()
        val marker = "eval(function(p,a,c,k,e,d)"
        var searchFrom = 0
        while (results.size < 12) { // sanity cap
            val start = html.indexOf(marker, searchFrom)
            if (start < 0) break
            tryUnpackAt(html, start)?.let { results.add(it) }
            searchFrom = start + marker.length
        }
        return results
    }

    /** Back-compat single-result variant. */
    fun unpackPackedJs(html: String): String? = unpackAllPackedJs(html).firstOrNull()

    private fun tryUnpackAt(html: String, start: Int): String? {
        // The payload call ends with .split('|'),0,{})  — find the arguments:
        // }('PAYLOAD',RADIX,COUNT,'k1|k2|…'.split('|'),0,{})
        val argsStart = html.indexOf("}('", start)
        if (argsStart < 0 || argsStart - start > 4096) return null
        var index = argsStart + 3
        val payload = StringBuilder()
        // Scan the single-quoted payload honoring backslash escapes.
        while (index < html.length) {
            val ch = html[index]
            if (ch == '\\' && index + 1 < html.length) {
                payload.append(ch).append(html[index + 1])
                index += 2
                continue
            }
            if (ch == '\'') break
            payload.append(ch)
            index += 1
        }
        if (index >= html.length) return null
        val afterPayload = html.substring(index + 1)
        val argsMatch = Regex("^\\s*,\\s*(\\d+)\\s*,\\s*(\\d+)\\s*,\\s*'").find(afterPayload)
            ?: return null
        val radix = argsMatch.groupValues[1].toIntOrNull() ?: return null
        val count = argsMatch.groupValues[2].toIntOrNull() ?: return null
        if (radix !in 2..36 || count <= 0 || count > 5000) return null
        // NB: argsMatch ranges are relative to afterPayload — scan the token
        // string inside that same substring (indexing html here was exactly
        // the v2.2.8 bug that broke pkembed/mixdrop extraction).
        val tokensStart = argsMatch.range.last + 1
        val tokens = StringBuilder()
        index = tokensStart
        while (index < afterPayload.length) {
            val ch = afterPayload[index]
            if (ch == '\\' && index + 1 < afterPayload.length) {
                tokens.append(ch).append(afterPayload[index + 1])
                index += 2
                continue
            }
            if (ch == '\'') break
            tokens.append(ch)
            index += 1
        }
        val tokenList = tokens.toString().split('|')
        if (tokenList.size < count) return null
        val decodedPayload = unescapeJsString(payload.toString())
        // Single-pass token replacement: every \b<base36 index>\b word that
        // maps to a non-empty token is substituted exactly once.
        val wordRegex = Regex("\\b[0-9a-z]+\\b")
        return wordRegex.replace(decodedPayload) { match ->
            val tokenIndex = decodeBase36(match.value, radix)
            if (tokenIndex != null && tokenIndex < count) {
                tokenList[tokenIndex].ifEmpty { match.value }
            } else {
                match.value
            }
        }
    }

    private fun unescapeJsString(value: String): String = value
        .replace("\\'", "'")
        .replace("\\\"", "\"")
        .replace("\\\\", "\\")
        .replace("\\n", "\n")
        .replace("\\r", "\r")
        .replace("\\t", "\t")

    private fun decodeBase36(word: String, radix: Int): Int? {
        var result = 0
        for (ch in word) {
            val digit = when (ch) {
                in '0'..'9' -> ch - '0'
                in 'a'..'z' -> ch - 'a' + 10
                else -> return null
            }
            if (digit >= radix) return null
            result = result * radix + digit
            if (result > 100_000) return null
        }
        return result
    }

    private val directVideoRegex = Regex(
        """(?:https?:)?//[^\s"'\\<>]+?\.(?:mp4|m3u8)(?:\?[^\s"'\\<>]*)?""",
        RegexOption.IGNORE_CASE,
    )

    /**
     * Extracts a directly playable video URL (.mp4 / .m3u8) from an embed
     * page: first from the raw HTML, then from every unpacked packed script
     * (ad packers included — the stream packer is not always the first), and
     * finally from ok.ru-style HTML-escaped/URL-encoded data-options
     * attributes. Returns "" when nothing playable is found (e.g. Dood
     * captcha shells).
     */
    fun extractDirectVideoUrl(embedHtml: String): String {
        directVideoRegex.findAll(embedHtml).forEach { match ->
            val url = normalizeUrl(match.value)
            // Skip ad-network / tracking pseudo-media URLs.
            if (isPlayableStreamUrl(url)) return url
        }
        // v2.3.2: ok.ru (and mirrors) keep the m3u8 inside data-options="…"
        // as an HTML-entity-escaped, URL-encoded JSON string — invisible to
        // the raw regex above.
        extractDataOptionsStream(embedHtml)?.let { return it }
        unpackAllPackedJs(embedHtml).forEach { script ->
            directVideoRegex.findAll(script).forEach { match ->
                val url = normalizeUrl(match.value)
                if (isPlayableStreamUrl(url)) return url
            }
            extractDataOptionsStream(script)?.let { return it }
        }
        return ""
    }

    /** Unescapes HTML entities + URL-encoding inside data-options payloads
     *  and returns the first playable m3u8/mp4 found there. */
    private fun extractDataOptionsStream(embedHtml: String): String? {
        val optionsRegex = Regex("data-options=[\"']([^\"']+)[\"']", RegexOption.IGNORE_CASE)
        optionsRegex.findAll(embedHtml).forEach { match ->
            runCatching {
                // HTML entities first (&quot; etc.), then percent-decoding.
                var decoded = match.groupValues[1]
                    .replace("&quot;", "\"")
                    .replace("&#39;", "'")
                    .replace("&amp;", "&")
                decoded = java.net.URLDecoder.decode(decoded, "UTF-8")
                decoded = decoded.replace("\\u0026", "&").replace("\\/", "/")
                val found = directVideoRegex.findAll(decoded)
                    .map { normalizeUrl(it.value) }
                    .firstOrNull { isPlayableStreamUrl(it) }
                if (found != null) return found
            }
        }
        return null
    }

    private fun isPlayableStreamUrl(url: String): Boolean {
        val value = url.lowercase()
        if (value.contains("vidoomy") || value.contains("vast") || value.contains("/ads/")) return false
        if (value.contains("/videoplayback?") && value.contains("source=youtube")) return false
        return true
    }

    /**
     * Fetches an embed player page directly (with the movie page as referer —
     * several hosts serve a blank shell without it). Short timeouts, no
     * caching: embed pages mint fresh stream tokens per request.
     */
    fun fetchEmbedPage(url: String, referer: String? = null): String? = runCatching {
        val builder = Request.Builder()
            .url(url)
            .header("User-Agent", BrowserUserAgent)
            .header("Accept", "text/html,application/xhtml+xml,*/*;q=0.8")
            .header("Accept-Language", "en-US,en;q=0.9")
        referer?.let { builder.header("Referer", it) }
        embedClient.newCall(builder.build()).execute().use { response ->
            if (!response.isSuccessful) return@runCatching null
            val body = response.body?.string().orEmpty()
            if (body.isBlank() || body.length < 200) null else body
        }
    }.getOrNull()
}
