package com.arix.app.assistant

import android.content.Context
import android.content.SharedPreferences

/**
 * Small preferences store for the assistant surface (floating pill toggle).
 * Kept separate from the main DataStore settings so the overlay service can
 * read it synchronously without any repository dependency.
 */
object AssistantPrefs {
    private const val PreferencesName = "arix_assistant_prefs"
    private const val KeyFloatingPillEnabled = "floating_pill_enabled"

    private fun preferences(context: Context): SharedPreferences =
        context.getSharedPreferences(PreferencesName, Context.MODE_PRIVATE)

    fun isFloatingPillEnabled(context: Context): Boolean =
        preferences(context).getBoolean(KeyFloatingPillEnabled, false)

    fun setFloatingPillEnabled(context: Context, enabled: Boolean) {
        preferences(context).edit().putBoolean(KeyFloatingPillEnabled, enabled).apply()
    }
}
