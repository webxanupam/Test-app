package com.arix.app

import androidx.appcompat.app.AppCompatDelegate
import androidx.core.os.LocaleListCompat
import com.arix.app.data.AppLanguage
import com.arix.app.data.appLanguageForTag
import com.arix.app.data.defaultAppLanguage

object ArixLocaleManager {
    fun apply(language: AppLanguage) {
        AppCompatDelegate.setApplicationLocales(
            LocaleListCompat.forLanguageTags(language.languageTag),
        )
    }

    fun applyIfChanged(language: AppLanguage) {
        if (currentApplicationLanguage() == language) return
        apply(language)
    }

    fun currentApplicationLanguage(): AppLanguage? =
        AppCompatDelegate.getApplicationLocales().get(0)
            ?.toLanguageTag()
            ?.let(::appLanguageForTag)

    fun currentLanguage(): AppLanguage =
        currentApplicationLanguage() ?: defaultAppLanguage()
}
