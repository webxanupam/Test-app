package com.arix.app.data

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.service.notification.StatusBarNotification
import com.arix.app.agentmode.ArixNotificationAccess
import org.json.JSONArray
import org.json.JSONObject

/**
 * No-root, always-available Android system control. v2.3.2: the accessibility
 * service (and the Agent Mode built on it) was removed — every action here now
 * works with zero special permissions:
 *
 *  - open_app / list_apps: launch any installed app (PackageManager intents)
 *  - open_url / open_link: http(s) pages and app deep links (flipkart://…)
 *  - read_notifications: live notification snapshot through the notification
 *    listener (NOT accessibility) — this is how the agent answers "check my
 *    unread mail" (Gmail notifications carry the unread counts/titles)
 *  - open_settings, device_info, volume: plain Android APIs
 *
 * Deep web automation (browse a site, click, type, read the page) is handled
 * by the separate `chrome` tool which drives the in-Alpine headless Chromium.
 */
class ArixSystemControlTool(
    private val context: Context,
) {

    fun execute(argumentsJson: String): String {
        val arguments = runCatching { JSONObject(argumentsJson) }.getOrNull()
            ?: return failure("Arguments were not valid JSON.")
        return runCatching { executeAction(arguments) }
            .getOrElse { throwable -> failure("${throwable.message ?: throwable.javaClass.simpleName}") }
    }

    private fun executeAction(arguments: JSONObject): String {
        return when (arguments.optString("action").trim().lowercase()) {
            "open_settings" -> openSettings(arguments.optString("page").trim().lowercase())
            "open_app" -> openApp(
                target = arguments.optString("target").ifBlank { arguments.optString("app") }.trim(),
            )
            "list_apps" -> listApps(
                query = arguments.optString("query").trim(),
                includeSystem = arguments.optBoolean("include_system", false),
                maxResults = minOf(arguments.optInt("max_results", 40).coerceAtLeast(1), 200),
            )
            "read_notifications", "notifications" -> readNotifications(
                filter = arguments.optString("filter")
                    .ifBlank { arguments.optString("package") }
                    .trim(),
                maxItems = minOf(arguments.optInt("max_items", 30).coerceIn(1, 120), 120),
            )
            "notification_access_status" -> notificationAccessStatus()
            "open_url", "open_link" -> openLink(
                url = arguments.optString("url")
                    .ifBlank { arguments.optString("link") }
                    .trim(),
                forceBrowser = arguments.optBoolean("force_browser", false),
            )
            "device_info" -> deviceInfo()
            "volume" -> volume(
                stream = arguments.optString("stream", "music").trim().lowercase(),
                action = arguments.optString("volume_action", "get").trim().lowercase(),
                direction = arguments.optString("direction", "up").trim().lowercase(),
            )
            "status" -> status()
            else -> failure(
                "Unknown action. Use open_settings, open_app, list_apps, read_notifications, " +
                    "notification_access_status, open_url, device_info, volume, or status."
            )
        }
    }

    /* ------------------------------------------------------------- status */

    private fun status(): String = JSONObject().apply {
        put("ok", true)
        put("action", "status")
        put("notification_access", ArixNotificationAccess.isRunning)
        put(
            "write_settings",
            Settings.System.canWrite(context),
        )
        put("android_version", Build.VERSION.RELEASE)
        put("device", "${Build.MANUFACTURER} ${Build.MODEL}")
    }.toString()

    /* ------------------------------------------------------- open settings */

    private fun settingsIntent(page: String): Intent? = when (page) {
        "", "main", "home", "settings" -> Intent(Settings.ACTION_SETTINGS)
        "wifi", "wlan" -> Intent(Settings.ACTION_WIFI_SETTINGS)
        "bluetooth", "bt" -> Intent(Settings.ACTION_BLUETOOTH_SETTINGS)
        "apps", "applications", "app", "manage_apps" -> Intent(Settings.ACTION_MANAGE_APPLICATIONS_SETTINGS)
        "app_details", "application_details" -> null // needs a package; handled by open_app
        "notifications", "notification" -> Intent("android.settings.NOTIFICATION_SETTINGS")
        "notification_history" -> Intent("android.settings.NOTIFICATION_HISTORY_SETTINGS")
        "notification_access" -> Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS")
        "sound", "audio", "volume" -> Intent(Settings.ACTION_SOUND_SETTINGS)
        "display", "screen", "brightness" -> Intent(Settings.ACTION_DISPLAY_SETTINGS)
        "battery" -> Intent(Settings.ACTION_BATTERY_SAVER_SETTINGS)
        "storage", "memory" -> Intent(Settings.ACTION_INTERNAL_STORAGE_SETTINGS)
        "location", "gps" -> Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS)
        "security" -> Intent(Settings.ACTION_SECURITY_SETTINGS)
        "privacy" -> Intent(Settings.ACTION_PRIVACY_SETTINGS)
        "accounts", "account", "sync" -> Intent(Settings.ACTION_SYNC_SETTINGS)
        "date", "time", "date_time", "datetime" -> Intent(Settings.ACTION_DATE_SETTINGS)
        "language", "locale", "input_language" -> Intent(Settings.ACTION_LOCALE_SETTINGS)
        "keyboard", "input", "ime", "input_method" -> Intent(Settings.ACTION_INPUT_METHOD_SETTINGS)
        "developer", "developer_options" -> Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS)
        "about", "about_phone", "device_info" -> Intent(Settings.ACTION_DEVICE_INFO_SETTINGS)
        "airplane", "airplane_mode" -> Intent(Settings.ACTION_AIRPLANE_MODE_SETTINGS)
        "nfc" -> Intent(Settings.ACTION_NFC_SETTINGS)
        "cast", "screen_cast" -> Intent(Settings.ACTION_CAST_SETTINGS)
        "print", "printing" -> Intent(Settings.ACTION_PRINT_SETTINGS)
        "data_usage", "data" -> Intent(Settings.ACTION_DATA_USAGE_SETTINGS)
        "home", "default_apps" -> Intent(Settings.ACTION_HOME_SETTINGS)
        "search" -> Intent(Settings.ACTION_SEARCH_SETTINGS)
        "usage", "usage_access" -> Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)
        "vpn" -> Intent(Settings.ACTION_VPN_SETTINGS)
        else -> null
    }

    private fun openSettings(page: String): String {
        val intent = settingsIntent(page)
            ?: return failure(
                "Unknown settings page '$page'. Known pages: main, wifi, bluetooth, apps, notifications, " +
                    "notification_access, notification_history, sound, display, battery, storage, location, " +
                    "security, privacy, accounts, date, language, keyboard, developer, about, airplane, nfc, " +
                    "cast, print, data_usage, home, vpn, usage.",
            )
        return runCatching {
            context.startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            JSONObject().apply {
                put("ok", true)
                put("action", "open_settings")
                put("page", page)
                put("detail", "Opened the ${page.ifBlank { "main" }} settings screen.")
            }.toString()
        }.getOrElse { throwable ->
            failure("Could not open settings page '$page': ${throwable.message}")
        }
    }

    /* ----------------------------------------------------------- open app */

    private fun openApp(target: String): String {
        if (target.isBlank()) {
            return failure("Provide the app name or package name, e.g. {\"action\":\"open_app\",\"target\":\"gmail\"}.")
        }
        val manager = context.packageManager
        val launchables = manager.getInstalledApplications(0)
            .filter { manager.getLaunchIntentForPackage(it.packageName) != null }

        val byPackage = launchables.firstOrNull {
            it.packageName.equals(target, ignoreCase = true)
        }
        val byLabel = launchables
            .map { it to manager.getApplicationLabel(it).toString() }
            .firstOrNull { (info, label) ->
                label.equals(target, ignoreCase = true) ||
                    label.contains(target, ignoreCase = true) ||
                    info.packageName.contains(target, ignoreCase = true)
            }
        val resolved = byPackage ?: byLabel?.first
            ?: return failure(
                "No launchable app matched '$target'. Use list_apps to see installed apps, " +
                    "or open_link to open the site in the browser instead.",
            )
        val label = manager.getApplicationLabel(resolved).toString()
        val launch = manager.getLaunchIntentForPackage(resolved.packageName)
            ?: return failure("App '$label' has no launch intent.")
        return runCatching {
            context.startActivity(launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            JSONObject().apply {
                put("ok", true)
                put("action", "open_app")
                put("app", label)
                put("package", resolved.packageName)
                put("detail", "Launched $label.")
            }.toString()
        }.getOrElse { throwable ->
            failure("Could not launch '$label': ${throwable.message}")
        }
    }

    private fun listApps(query: String, includeSystem: Boolean, maxResults: Int): String {
        val manager = context.packageManager
        val launchables = manager.getInstalledApplications(0)
            .filter { manager.getLaunchIntentForPackage(it.packageName) != null }
            .map { info ->
                AppEntry(
                    label = manager.getApplicationLabel(info).toString(),
                    packageName = info.packageName,
                    isSystem = (info.flags and android.content.pm.ApplicationInfo.FLAG_SYSTEM) != 0,
                )
            }
            .filter { includeSystem || !it.isSystem }
            .filter { query.isBlank() || it.label.contains(query, true) || it.packageName.contains(query, true) }
            .sortedWith(compareByDescending<AppEntry> { it.label.startsWith(query, true) }.thenBy { it.label.lowercase() })
            .take(maxResults)
        return JSONObject().apply {
            put("ok", true)
            put("action", "list_apps")
            put("count", launchables.size)
            put("apps", JSONArray().apply {
                launchables.forEach { entry ->
                    put(
                        JSONObject().apply {
                            put("label", entry.label)
                            put("package", entry.packageName)
                            put("system", entry.isSystem)
                        },
                    )
                }
            })
            put("detail", "Found ${launchables.size} app(s)${if (query.isNotBlank()) " matching '$query'" else ""}.")
        }.toString()
    }

    private data class AppEntry(val label: String, val packageName: String, val isSystem: Boolean)

    /* -------------------------------------------------- read notifications */

    /**
     * Live notification snapshot through the notification listener (no-root,
     * no accessibility). This is the mechanism that answers questions like
     * "how many unread emails do I have?" — Gmail notifications carry the
     * counts and the latest message titles in their extras.
     */
    private fun readNotifications(filter: String, maxItems: Int): String {
        val service = ArixNotificationAccess.service()
        if (service == null) {
            return JSONObject().apply {
                put("ok", false)
                put("action", "read_notifications")
                put(
                    "errmsg",
                    "Notification access is not enabled, so notifications cannot be read. Ask the user to " +
                        "grant it once: open_settings with page=notification_access, choose Arix, and allow " +
                        "access. (This is regular notification access — not the removed accessibility " +
                        "service.) Then retry.",
                )
            }.toString()
        }
        val notifications: List<StatusBarNotification> = service.snapshot()
        val filtered = if (filter.isNotBlank()) {
            notifications.filter {
                it.packageName.contains(filter, ignoreCase = true)
            }
        } else {
            notifications
        }
        val items = JSONArray()
        filtered.take(maxItems).forEach { notification ->
            runCatching {
                // StatusBarNotification exposes extras through its Notification.
                val extras = notification.notification?.extras ?: return@runCatching
                val title = extras.getCharSequence("android.title")?.toString().orEmpty()
                val text = extras.getCharSequence("android.text")?.toString().orEmpty()
                val bigText = extras.getCharSequence("android.bigText")?.toString().orEmpty()
                val subText = extras.getCharSequence("android.subText")?.toString().orEmpty()
                if (title.isBlank() && text.isBlank() && bigText.isBlank()) return@runCatching
                items.put(
                    JSONObject().apply {
                        put("package", notification.packageName)
                        if (title.isNotBlank()) put("title", title.take(160))
                        if (text.isNotBlank()) put("text", text.take(400))
                        if (bigText.isNotBlank() && bigText != text) put("big_text", bigText.take(900))
                        if (subText.isNotBlank()) put("sub_text", subText.take(80))
                        put("when", notification.postTime)
                    },
                )
            }
        }
        // Per-package counts let the agent answer "unread mail" style
        // questions even when individual notifications are trimmed.
        val counts = JSONObject()
        notifications.groupBy { it.packageName }.forEach { (pkg, list) ->
            counts.put(pkg, list.size)
        }
        return JSONObject().apply {
            put("ok", true)
            put("action", "read_notifications")
            if (filter.isNotBlank()) put("filter", filter)
            put("count", items.length())
            put("total", notifications.size)
            put("items", items)
            put("package_counts", counts)
            put(
                "detail",
                "Read ${items.length()} notification(s)${if (filter.isNotBlank()) " from packages matching '$filter'" else ""}.",
            )
        }.toString()
    }

    private fun notificationAccessStatus(): String {
        val enabled = ArixNotificationAccess.isNotificationAccessEnabled(context)
        return JSONObject().apply {
            put("ok", true)
            put("action", "notification_access_status")
            put("enabled", enabled)
            put("connected", ArixNotificationAccess.isRunning)
            put(
                "detail",
                if (enabled) {
                    "Notification access is enabled — read_notifications works."
                } else {
                    "Notification access is not enabled. Ask the user: open_settings page=notification_access, " +
                        "pick Arix, allow. Then read_notifications returns live notifications (e.g. Gmail unread)."
                },
            )
        }.toString()
    }

    /* --------------------------------------------------------- open link */

    /**
     * Opens any URI: http(s) pages, and app deep links (flipkart://,
     * mailto:, whatsapp://…). When the target app for a deep link is missing,
     * the error suggests open_url with the site instead.
     */
    private fun openLink(url: String, forceBrowser: Boolean): String {
        if (url.isBlank()) {
            return failure("Provide the url to open (http/https or an app deep link like flipkart://search?q=…).")
        }
        val parsed = runCatching { Uri.parse(url) }.getOrNull()
            ?: return failure("Could not parse the URL '$url'.")
        val isHttp = url.startsWith("http://", ignoreCase = true) || url.startsWith("https://", ignoreCase = true)
        return runCatching {
            val intent = if (isHttp && forceBrowser) {
                Intent(Intent.ACTION_VIEW, parsed).apply {
                    addCategory(Intent.CATEGORY_BROWSABLE)
                    setPackage(
                        context.packageManager.resolveActivity(
                            Intent(Intent.ACTION_VIEW, Uri.parse("https://example.com")),
                            0,
                        )?.activityInfo?.packageName,
                    )
                }
            } else {
                Intent(Intent.ACTION_VIEW, parsed)
            }.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(intent)
            JSONObject().apply {
                put("ok", true)
                put("action", "open_url")
                put("url", url)
                put(
                    "detail",
                    "Opened $url" + if (isHttp) " in the default browser." else " (deep link).",
                )
            }.toString()
        }.getOrElse { throwable ->
            if (!isHttp) {
                failure(
                    "No app handled the deep link '$url'. The app may not be installed — " +
                        "open the website instead (e.g. https://…) or use the chrome tool to automate the site.",
                )
            } else {
                failure("Could not open URL: ${throwable.message}")
            }
        }
    }

    /* -------------------------------------------------------- device info */

    private fun deviceInfo(): String {
        val audio = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val battery = runCatching {
            val intent = context.registerReceiver(
                null,
                android.content.IntentFilter(Intent.ACTION_BATTERY_CHANGED),
            )
            val level = intent?.getIntExtra(android.os.BatteryManager.EXTRA_LEVEL, -1) ?: -1
            val scale = intent?.getIntExtra(android.os.BatteryManager.EXTRA_SCALE, -1) ?: -1
            if (level >= 0 && scale > 0) level * 100 / scale else null
        }.getOrNull()
        val metrics = context.resources.displayMetrics
        return JSONObject().apply {
            put("ok", true)
            put("action", "device_info")
            put("model", Build.MODEL)
            put("manufacturer", Build.MANUFACTURER)
            put("android_version", Build.VERSION.RELEASE)
            put("sdk", Build.VERSION.SDK_INT)
            battery?.let { put("battery_percent", it) }
            put("screen", JSONObject().apply {
                put("width_px", metrics.widthPixels)
                put("height_px", metrics.heightPixels)
                put("density", metrics.densityDpi / 160.0)
            })
            put("volume", JSONObject().apply {
                put("music", audio.getStreamVolume(AudioManager.STREAM_MUSIC))
                put("ring", audio.getStreamVolume(AudioManager.STREAM_RING))
                put("alarm", audio.getStreamVolume(AudioManager.STREAM_ALARM))
            })
        }.toString()
    }

    /* ------------------------------------------------------------ volume */

    private fun volume(stream: String, action: String, direction: String): String {
        val audio = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val streamId = when (stream) {
            "music", "media" -> AudioManager.STREAM_MUSIC
            "ring", "ringer" -> AudioManager.STREAM_RING
            "alarm" -> AudioManager.STREAM_ALARM
            "call" -> AudioManager.STREAM_VOICE_CALL
            "system" -> AudioManager.STREAM_SYSTEM
            "notification", "notifications" -> AudioManager.STREAM_NOTIFICATION
            else -> AudioManager.STREAM_MUSIC
        }
        if (action == "get") {
            return JSONObject().apply {
                put("ok", true)
                put("action", "volume")
                put("stream", stream)
                put("level", audio.getStreamVolume(streamId))
                put("max", audio.getStreamMaxVolume(streamId))
            }.toString()
        }
        val directionFlag = if (direction == "down") AudioManager.ADJUST_LOWER else AudioManager.ADJUST_RAISE
        if (action == "mute") {
            audio.adjustStreamVolume(streamId, AudioManager.ADJUST_MUTE, 0)
        } else if (action == "unmute") {
            audio.adjustStreamVolume(streamId, AudioManager.ADJUST_UNMUTE, 0)
        } else {
            audio.adjustStreamVolume(streamId, directionFlag, 0)
        }
        return JSONObject().apply {
            put("ok", true)
            put("action", "volume")
            put("stream", stream)
            put("level", audio.getStreamVolume(streamId))
            put("max", audio.getStreamMaxVolume(streamId))
        }.toString()
    }

    private fun failure(message: String): String = JSONObject()
        .put("ok", false)
        .put("errmsg", message)
        .toString()

    companion object {
        val toolDefinition: JSONObject = JSONObject().apply {
            put("name", "system_control")
            put(
                "description",
                "No-root Android device control. ALWAYS prefer this tool for: launching apps by name " +
                    "or package (open_app), listing installed apps, reading live notifications " +
                    "(read_notifications — answers 'check my unread mail' via Gmail notifications; needs the " +
                    "one-time notification access grant, see notification_access_status), opening URLs and " +
                    "app deep links (open_url — e.g. flipkart://search?q=iphone 17), opening system settings " +
                    "pages, volume control, and device info. For browsing a website with full automation " +
                    "(search, click, add to cart, read the page) use the chrome tool instead. " +
                    "For deep web flows: open the app with open_app, and if it is not installed drive the " +
                    "site with the chrome tool.",
            )
            put(
                "parameters",
                JSONObject().apply {
                    put("type", "object")
                    put(
                        "properties",
                        JSONObject().apply {
                            put(
                                "action",
                                JSONObject().put("type", "string")
                                    .put(
                                        "description",
                                        "One of: open_app, list_apps, read_notifications, " +
                                            "notification_access_status, open_url, open_settings, " +
                                            "device_info, volume, status.",
                                    ),
                            )
                            put(
                                "page",
                                JSONObject().put("type", "string")
                                    .put(
                                        "description",
                                        "For open_settings: main, wifi, bluetooth, apps, notifications, " +
                                            "notification_access, sound, display, battery, storage, location, " +
                                            "security, privacy, accounts, date, language, keyboard, developer, " +
                                            "about, airplane, nfc, cast, print, data_usage, home, vpn, usage.",
                                    ),
                            )
                            put("target", JSONObject().put("type", "string").put("description", "For open_app: app label or package name, e.g. gmail, flipkart."))
                            put("query", JSONObject().put("type", "string").put("description", "For list_apps: optional filter; for read_notifications: optional package filter, e.g. com.google.android.gm or gmail."))
                            put("filter", JSONObject().put("type", "string").put("description", "For read_notifications: filter notifications by package substring (e.g. gmail)."))
                            put("max_items", JSONObject().put("type", "number").put("description", "For read_notifications: max notifications to return (default 30)."))
                            put("include_system", JSONObject().put("type", "boolean").put("description", "For list_apps: include system apps."))
                            put("url", JSONObject().put("type", "string").put("description", "For open_url: http/https URL or an app deep link (flipkart://…, mailto:…)."))
                            put("force_browser", JSONObject().put("type", "boolean").put("description", "For open_url: open http links in the browser instead of an app handler."))
                            put("stream", JSONObject().put("type", "string").put("description", "For volume: music, ring, alarm, call, system, notification."))
                            put("volume_action", JSONObject().put("type", "string").put("description", "For volume: get (default), set, mute, unmute."))
                            put("direction", JSONObject().put("type", "string").put("description", "For volume set: up or down."))
                        },
                    )
                    put("required", JSONArray().put("action"))
                    put("additionalProperties", false)
                },
            )
            put("execution_mode", "sequential")
        }
    }
}
