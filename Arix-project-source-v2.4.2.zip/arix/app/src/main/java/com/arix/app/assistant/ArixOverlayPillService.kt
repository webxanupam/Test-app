package com.arix.app.assistant

import android.annotation.SuppressLint
import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowManager
import android.widget.FrameLayout
import com.arix.app.R

/**
 * Shows a small draggable floating pill over other apps (requires the
 * "Display over other apps" / SYSTEM_ALERT_WINDOW permission).
 *
 * Tap the pill to summon the assistant panel; long-press to hide it.
 * The pill snaps to the nearest horizontal screen edge when released.
 */
class ArixOverlayPillService : Service() {

    private var windowManager: WindowManager? = null
    private var pillView: View? = null

    override fun onCreate() {
        super.onCreate()
        if (!Settings.canDrawOverlays(this)) {
            stopSelf()
            return
        }
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        showPill()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (!Settings.canDrawOverlays(this)) {
            AssistantPrefs.setFloatingPillEnabled(this, false)
            stopSelf()
            return START_NOT_STICKY
        }
        if (pillView == null) showPill()
        return START_STICKY
    }

    override fun onDestroy() {
        pillView?.let { view ->
            runCatching { windowManager?.removeView(view) }
        }
        pillView = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    @SuppressLint("InflateParams", "ClickableViewAccessibility")
    private fun showPill() {
        val manager = windowManager ?: return
        val density = resources.displayMetrics.density
        val pillSizePx = (PILL_SIZE_DP * density).toInt()
        val marginPx = (PILL_MARGIN_DP * density).toInt()

        val params = WindowManager.LayoutParams(
            pillSizePx,
            pillSizePx,
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            } else {
                @Suppress("DEPRECATION")
                WindowManager.LayoutParams.TYPE_PHONE
            },
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT,
        ).apply {
            gravity = Gravity.BOTTOM or Gravity.START
            x = marginPx
            y = marginPx * 6
        }

        val view = LayoutInflater.from(this)
            .inflate(R.layout.overlay_pill, null) as FrameLayout
        pillView = view

        val touchSlop = ViewConfiguration.get(this).scaledTouchSlop
        var downX = 0f
        var downY = 0f
        var startX = 0
        var startY = 0
        var moved = false

        view.setOnTouchListener { _, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = event.rawX
                    downY = event.rawY
                    startX = params.x
                    startY = params.y
                    moved = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = event.rawX - downX
                    val dy = event.rawY - downY
                    if (moved || kotlin.math.abs(dx) > touchSlop || kotlin.math.abs(dy) > touchSlop) {
                        moved = true
                        // When anchored right, x measures the right edge offset.
                        val horizontalGravity = params.gravity and Gravity.HORIZONTAL_GRAVITY_MASK
                        if (horizontalGravity == Gravity.RIGHT) {
                            params.x = (startX - dx).toInt().coerceAtLeast(0)
                        } else {
                            params.x = (startX + dx).toInt().coerceAtLeast(0)
                        }
                        params.y = (startY - dy).toInt().coerceAtLeast(0)
                        runCatching { manager.updateViewLayout(view, params) }
                    }
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    if (!moved && event.actionMasked == MotionEvent.ACTION_UP) {
                        view.performClick()
                    } else {
                        snapToEdge(params, manager, view, pillSizePx)
                    }
                    true
                }
                else -> false
            }
        }

        view.setOnClickListener {
            val intent = Intent(this, AssistantActivity::class.java).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            runCatching { startActivity(intent) }
        }

        view.setOnLongClickListener {
            AssistantPrefs.setFloatingPillEnabled(this, false)
            stopSelf()
            true
        }

        runCatching { manager.addView(view, params) }
    }

    private fun snapToEdge(
        params: WindowManager.LayoutParams,
        manager: WindowManager,
        view: View,
        pillSizePx: Int,
    ) {
        val displayWidth = resources.displayMetrics.widthPixels
        val marginPx = (PILL_MARGIN_DP * resources.displayMetrics.density).toInt()
        val horizontalGravity = params.gravity and Gravity.HORIZONTAL_GRAVITY_MASK
        val distanceFromLeft = if (horizontalGravity == Gravity.RIGHT) {
            displayWidth - params.x - pillSizePx
        } else {
            params.x
        }
        val snapRight = distanceFromLeft > displayWidth / 2
        params.gravity = (params.gravity and Gravity.HORIZONTAL_GRAVITY_MASK.inv()) or
            if (snapRight) Gravity.RIGHT else Gravity.LEFT
        params.x = marginPx
        runCatching { manager.updateViewLayout(view, params) }
    }

    private companion object {
        const val PILL_SIZE_DP = 46
        const val PILL_MARGIN_DP = 10
    }
}
