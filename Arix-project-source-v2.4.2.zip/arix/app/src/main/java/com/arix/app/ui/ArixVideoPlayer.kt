package com.arix.app.ui

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.content.pm.ActivityInfo
import android.view.ViewGroup
import androidx.annotation.OptIn
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.ui.window.DialogWindowProvider
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.datasource.okhttp.OkHttpDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import com.arix.app.data.ArixMediaApi
import okhttp3.OkHttpClient
import java.util.concurrent.TimeUnit

/**
 * v2.3.2 — native video stage for direct streams (.mp4 / .m3u8 / .mpd).
 *
 * Replaces the WebView-based player stage: several stream CDNs validate the
 * Referer header (the MovieBox CDN answers 429 without it) and block
 * cross-origin manifest fetches (hls.js XHR). ExoPlayer performs plain HTTP
 * requests with explicit headers, so both problems disappear. The OkHttp
 * data source keeps TLS/HTTP2 behavior consistent with the scraper client.
 *
 * v2.4.1 — fullscreen playback: the controller's fullscreen button now
 * expands the stage into an immersive landscape dialog that hides the
 * system bars and re-binds the very same ExoPlayer instance, so playback
 * position and buffering survive the transition.
 *
 * @param streamUrl   direct media URL
 * @param referer     page origin the CDN expects (empty = no Referer header)
 * @param posterUrl   optional poster, kept for future artwork use
 */
@OptIn(UnstableApi::class)
@Composable
internal fun ArixVideoPlayer(
    streamUrl: String,
    referer: String = "",
    posterUrl: String = "",
) {
    val context = LocalContext.current
    var playerError by remember(streamUrl) { mutableStateOf<String?>(null) }
    var fullscreen by remember(streamUrl) { mutableStateOf(false) }

    // One client per composition is fine; headers are per-request anyway.
    val httpClient = remember {
        OkHttpClient.Builder()
            .connectTimeout(12, TimeUnit.SECONDS)
            .readTimeout(20, TimeUnit.SECONDS)
            .followRedirects(true)
            .build()
    }

    val player = remember(streamUrl) {
        val requestHeaders = buildMap {
            put("User-Agent", ArixMediaApi.BrowserUserAgent)
            if (referer.isNotBlank()) put("Referer", referer)
            put("Accept", "*/*")
            put("Accept-Language", "en-US,en;q=0.9")
        }
        val httpFactory = OkHttpDataSource.Factory(httpClient)
            .setUserAgent(ArixMediaApi.BrowserUserAgent)
            .setDefaultRequestProperties(requestHeaders)
        val dataSourceFactory = DefaultDataSource.Factory(context, httpFactory)
        val mediaSourceFactory = DefaultMediaSourceFactory(dataSourceFactory)
        ExoPlayer.Builder(context)
            .setMediaSourceFactory(mediaSourceFactory)
            .setSeekBackIncrementMs(10_000L)
            .setSeekForwardIncrementMs(10_000L)
            .build()
            .apply {
                val mimeType = when {
                    streamUrl.contains(".m3u8", ignoreCase = true) -> MimeTypes.APPLICATION_M3U8
                    streamUrl.contains(".mpd", ignoreCase = true) -> MimeTypes.APPLICATION_MPD
                    else -> null
                }
                val mediaItemBuilder = MediaItem.Builder().setUri(streamUrl)
                if (mimeType != null) mediaItemBuilder.setMimeType(mimeType)
                setMediaItem(mediaItemBuilder.build())
                playWhenReady = true
                addListener(object : Player.Listener {
                    override fun onPlayerError(error: PlaybackException) {
                        playerError = when (val cause = error.cause) {
                            is androidx.media3.datasource.HttpDataSource.InvalidResponseCodeException -> {
                                val code = cause.responseCode
                                "Stream rejected (HTTP $code). Try another server."
                            }
                            else -> "Playback failed: ${error.errorCodeName}. Try another server."
                        }
                    }
                })
                prepare()
            }
    }

    DisposableEffect(streamUrl) {
        onDispose { player.release() }
    }

    // Keep the error overlay in sync when switching servers quickly.
    LaunchedEffect(streamUrl) { playerError = null }

    // v2.4.1: immersive fullscreen — rotate landscape, hide the system bars,
    // and restore everything on exit. MainActivity declares configChanges
    // for orientation so the activity (and this composition) survive.
    val activity = remember(context) { context.findArixActivity() }
    DisposableEffect(fullscreen, activity) {
        val window = activity?.window
        if (fullscreen && window != null) {
            activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
            val controller = WindowCompat.getInsetsController(window, window.decorView)
            controller.systemBarsBehavior =
                WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            controller.hide(WindowInsetsCompat.Type.systemBars())
            onDispose {
                activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
                controller.show(WindowInsetsCompat.Type.systemBars())
            }
        } else {
            onDispose { }
        }
    }

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .aspectRatio(16f / 9f),
    ) {
        AndroidView(
            factory = { viewContext ->
                PlayerView(viewContext).apply {
                    useController = true
                    setShowSubtitleButton(true)
                    setShutterBackgroundColor(android.graphics.Color.BLACK)
                    layoutParams = ViewGroup.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.MATCH_PARENT,
                    )
                    resizeMode = AspectRatioFrameLayout.RESIZE_MODE_FIT
                    setFullscreenButtonClickListener { enter -> fullscreen = enter }
                }
            },
            update = { view -> view.player = if (fullscreen) null else player },
            onRelease = { view -> view.player = null },
            modifier = Modifier.fillMaxSize(),
        )
        playerError?.let { message ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 18.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = androidx.compose.foundation.layout.Arrangement.Center,
            ) {
                Text(
                    text = message,
                    color = Color(0xFFE5757A),
                    textAlign = TextAlign.Center,
                    style = androidx.compose.material3.MaterialTheme.typography.bodySmall,
                )
                Spacer(Modifier.height(6.dp))
                Text(
                    text = "Pick another quality or server chip below.",
                    color = Color(0xFF9AA0A6),
                    textAlign = TextAlign.Center,
                    style = androidx.compose.material3.MaterialTheme.typography.labelSmall,
                )
            }
        }
    }

    // Fullscreen stage: a full-bleed dialog hosting a second PlayerView bound
    // to the SAME player. The inline view above drops its surface binding
    // while the dialog is showing (see `update`), then re-binds on exit, so
    // there is never more than one attached PlayerView per ExoPlayer.
    if (fullscreen) {
        Dialog(
            onDismissRequest = { fullscreen = false },
            properties = DialogProperties(
                usePlatformDefaultWidth = false,
                decorFitsSystemWindows = false,
                dismissOnBackPress = true,
            ),
        ) {
            val exoPlayer = player
            val dialogView = LocalView.current
            LaunchedEffect(dialogView) {
                val window = (dialogView.parent as? DialogWindowProvider)?.window
                window?.let { w ->
                    WindowCompat.setDecorFitsSystemWindows(w, false)
                    val controller = WindowCompat.getInsetsController(w, w.decorView)
                    controller.systemBarsBehavior =
                        WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
                    controller.hide(WindowInsetsCompat.Type.systemBars())
                }
            }
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black),
            ) {
                AndroidView(
                    factory = { viewContext ->
                        PlayerView(viewContext).apply {
                            useController = true
                            setShowSubtitleButton(true)
                            setShutterBackgroundColor(android.graphics.Color.BLACK)
                            layoutParams = ViewGroup.LayoutParams(
                                ViewGroup.LayoutParams.MATCH_PARENT,
                                ViewGroup.LayoutParams.MATCH_PARENT,
                            )
                            resizeMode = AspectRatioFrameLayout.RESIZE_MODE_FIT
                            // Explicit setter: a bare `player =` inside apply{}
                            // resolves to the outer `val player` local.
                            setPlayer(exoPlayer)
                            setFullscreenButtonClickListener { enter -> fullscreen = enter }
                        }
                    },
                    onRelease = { view -> view.player = null },
                    modifier = Modifier.fillMaxSize(),
                )
            }
        }
    }
}

/** Unwraps ContextWrapper chains until the hosting Activity is found. */
internal tailrec fun Context.findArixActivity(): Activity? = when (this) {
    is Activity -> this
    is ContextWrapper -> baseContext.findArixActivity()
    else -> null
}

/** Media mime hint for captions side-loaded into the player. */
@OptIn(UnstableApi::class)
internal fun arixCaptionMimeType(url: String): String = when {
    url.contains(".vtt", ignoreCase = true) -> MimeTypes.TEXT_VTT
    else -> MimeTypes.APPLICATION_SUBRIP
}

@Suppress("unused")
private val unusedKeepReference: Any = C.TIME_UNSET
