package com.arix.app.data

import com.arix.app.ui.ArixMovieItemModel
import com.arix.app.ui.ArixMoviePlayerModel
import com.arix.app.ui.ArixMovieServerModel
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/**
 * ArixCinemetaClient — provider 1 of the Movies tool (v2.4.0).
 *
 * Replaces the old Watch-Movies web scraper with the public Stremio
 * Cinemeta catalog API (v3-cinemeta.strem.io):
 *
 *  - Keyless, CDN-backed, stable (served behind Cloudflare).
 *  - Catalogs: `/catalog/movie/top/skip=N.json`, `/catalog/movie/year/skip=N.json`
 *    (newest releases) and genre-filtered variants.
 *  - Search: `/catalog/movie/top/search=<q>.json`.
 *  - Detail: `/meta/movie/<imdbId>.json` — description, genres, runtime,
 *    rating, poster.
 *
 * Playback is provided by free public embed players keyed on the IMDb id:
 *  - vidsrc.to  (Server 1)
 *  - 2embed.cc  (Server 2)
 *  - vidsrc.in  (Server 3)
 *
 * All embeds load inside the hardened player WebView exactly like the
 * MovieBox "Web player" fallback server, so no new playback plumbing is
 * needed. All methods perform blocking network IO — call them from
 * Dispatchers.IO.
 */
object ArixCinemetaClient {

    private const val Base = "https://v3-cinemeta.strem.io"

    /** Pseudo-URL scheme used by grid items so the detail loader can tell
     *  Cinemeta entries apart from other providers. Format: `cinemeta:<imdbId>`. */
    const val UrlScheme = "cinemeta:"

    private val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(12, TimeUnit.SECONDS)
        .readTimeout(20, TimeUnit.SECONDS)
        .followRedirects(true)
        .build()

    /* ------------------------------------------------------------ catalog */

    /**
     * Latest / trending movies with pagination. Page 1 mixes the top catalog
     * with the newest releases so the grid opens with fresh, popular titles;
     * deeper pages keep flipping through the "top" catalog.
     */
    fun fetchLatest(page: Int = 1, limit: Int = 36): List<ArixMovieItemModel> {
        val normalized = page.coerceIn(1, 40)
        val skip = (normalized - 1) * 100
        // Newest releases first on page 1, then the all-time catalog.
        val catalogs = if (normalized == 1) {
            listOf("$Base/catalog/movie/year.json", "$Base/catalog/movie/top.json")
        } else {
            listOf("$Base/catalog/movie/top/skip=$skip.json")
        }
        val seen = mutableSetOf<String>()
        val result = mutableListOf<ArixMovieItemModel>()
        for (catalogUrl in catalogs) {
            val metas = runCatching { catalogMetas(catalogUrl) }.getOrDefault(emptyList())
            for (meta in metas) {
                val id = meta.optString("id")
                if (id.isBlank() || !seen.add(id)) continue
                result.add(
                    ArixMovieItemModel(
                        title = meta.optString("name"),
                        url = "$UrlScheme$id",
                        thumbnail = posterFor(meta),
                        views = meta.optString("imdbRating").takeIf { it.isNotBlank() }?.let { "★ $it" }.orEmpty(),
                    ),
                )
                if (result.size >= limit) return result
            }
        }
        return result
    }

    /** Genre-browsed catalog (Action, Comedy, Horror, …). */
    fun fetchGenre(genre: String, page: Int = 1, limit: Int = 36): List<ArixMovieItemModel> {
        val normalized = page.coerceIn(1, 40)
        val skip = (normalized - 1) * 100
        val url = "$Base/catalog/movie/genre=${android.net.Uri.encode(genre)}/skip=$skip.json"
        val seen = mutableSetOf<String>()
        val result = mutableListOf<ArixMovieItemModel>()
        for (meta in runCatching { catalogMetas(url) }.getOrDefault(emptyList())) {
            val id = meta.optString("id")
            if (id.isBlank() || !seen.add(id)) continue
            // Cinemeta's genre catalog filter is loose server-side; enforce it
            // client-side so the chips stay honest.
            val genres = meta.optJSONArray("genres")?.let { array ->
                (0 until array.length()).mapNotNull { array.optJSONObject(it)?.optString("name") ?: array.optString(it) }
            } ?: emptyList<String>()
            val genresText = genres.joinToString(",")
            if (genresText.isNotBlank() && genre.isNotBlank() &&
                !genresText.contains(genre, ignoreCase = true) &&
                genresText.isNotBlank()
            ) {
                continue
            }
            result.add(
                ArixMovieItemModel(
                    title = meta.optString("name"),
                    url = "$UrlScheme$id",
                    thumbnail = posterFor(meta),
                    views = meta.optString("imdbRating").takeIf { it.isNotBlank() }?.let { "★ $it" }.orEmpty(),
                ),
            )
            if (result.size >= limit) return result
        }
        return result
    }

    /** Keyword search across movies. */
    fun search(query: String, limit: Int = 36): List<ArixMovieItemModel> {
        if (query.isBlank()) return emptyList()
        val url = "$Base/catalog/movie/top/search=${android.net.Uri.encode(query)}.json"
        return runCatching { catalogMetas(url) }.getOrDefault(emptyList())
            .filter { it.optString("id").isNotBlank() }
            .take(limit)
            .map { meta ->
                ArixMovieItemModel(
                    title = meta.optString("name"),
                    url = "$UrlScheme${meta.optString("id")}",
                    thumbnail = posterFor(meta),
                    views = meta.optString("imdbRating").takeIf { it.isNotBlank() }?.let { "★ $it" }.orEmpty(),
                )
            }
    }

    /* ------------------------------------------------------------- detail */

    /**
     * Full detail + playable embed servers for a Cinemeta movie item
     * (`cinemeta:<imdbId>` or a bare IMDb id).
     */
    fun fetchDetail(itemUrl: String): ArixMoviePlayerModel? {
        val imdbId = itemUrl.removePrefix(UrlScheme).trim()
        if (!imdbId.startsWith("tt")) return null
        val url = "$Base/meta/movie/$imdbId.json"
        val body = runCatching {
            client.newCall(
                Request.Builder()
                    .url(url)
                    .header("User-Agent", ArixMediaApi.BrowserUserAgent)
                    .header("Accept", "application/json")
                    .build(),
            ).execute().use { response ->
                if (!response.isSuccessful) error("Cinemeta returned HTTP ${response.code}")
                response.body?.string() ?: error("Empty Cinemeta response")
            }
        }.getOrNull() ?: return null
        val meta = runCatching {
            JSONObject(body).optJSONObject("meta")
        }.getOrNull() ?: return null

        val title = meta.optString("name")
        val description = meta.optString("description")
        val genres = meta.optJSONArray("genres")?.let { array ->
            (0 until array.length()).mapNotNull { array.optJSONObject(it)?.optString("name") ?: array.optString(it) }
        } ?: emptyList<String>()
        val runtime = meta.optString("runtime")
        val year = meta.optString("releaseInfo")
        val rating = meta.optString("imdbRating")

        val servers = listOf(
            ArixMovieServerModel(
                label = "Server 1 · HD",
                url = "https://vidsrc.to/embed/movie/$imdbId",
            ),
            ArixMovieServerModel(
                label = "Server 2",
                url = "https://www.2embed.cc/embed/$imdbId",
            ),
            ArixMovieServerModel(
                label = "Server 3",
                url = "https://vidsrc.in/embed/movie/$imdbId",
            ),
        )

        return ArixMoviePlayerModel(
            title = title,
            description = listOfNotNull(
                rating.takeIf { it.isNotBlank() }?.let { "★ $it" },
                year.takeIf { it.isNotBlank() },
                runtime.takeIf { it.isNotBlank() },
                genres.joinToString(", ").takeIf { it.isNotBlank() },
                description.takeIf { it.isNotBlank() },
            ).joinToString("  ·  "),
            thumbnail = posterFor(meta),
            url = itemUrl,
            servers = servers,
            downloads = emptyList(),
        )
    }

    /* -------------------------------------------------------------- utils */

    private fun catalogMetas(url: String): List<JSONObject> {
        val body = client.newCall(
            Request.Builder()
                .url(url)
                .header("User-Agent", ArixMediaApi.BrowserUserAgent)
                .header("Accept", "application/json")
                .build(),
        ).execute().use { response ->
            if (!response.isSuccessful) error("Cinemeta returned HTTP ${response.code}")
            response.body?.string() ?: error("Empty Cinemeta response")
        }
        val metas = runCatching { JSONObject(body).optJSONArray("metas") }.getOrNull() ?: return emptyList()
        val result = mutableListOf<JSONObject>()
        for (i in 0 until metas.length()) {
            metas.optJSONObject(i)?.let { result.add(it) }
        }
        return result
    }

    /** Best poster URL for a catalog/meta entry (poster → background → logo). */
    private fun posterFor(meta: JSONObject): String {
        val poster = meta.optString("poster")
        if (poster.startsWith("http")) return poster
        val background = meta.optString("background")
        if (background.startsWith("http")) return background
        return ""
    }

    /** Popular genre chips shown in the Movies tool under provider 1. */
    val genreChips: List<String> = listOf(
        "Action", "Comedy", "Horror", "Sci-Fi", "Thriller", "Drama", "Adventure", "Animation",
    )
}
