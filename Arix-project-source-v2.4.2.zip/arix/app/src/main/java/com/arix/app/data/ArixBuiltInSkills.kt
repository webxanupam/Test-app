package com.arix.app.data

/**
 * ArixBuiltInSkills — curated skills that ship inside the app and install on
 * first launch (or when re-enabled from Settings → Agent Skills → Built-in).
 *
 * Each entry is a full SKILL.md document (frontmatter + instructions). They
 * are installed through the regular AgentSkillManager pipeline so they behave
 * exactly like imported skills: enable/disable toggle, per-session composer
 * chips, runtime mirroring — plus a Remove action that permanently hides a
 * built-in until it is re-added from the Built-in section.
 */
object ArixBuiltInSkills {

    data class BuiltInSkill(
        val id: String,
        val name: String,
        val description: String,
        val skillMd: String,
    )

    val all: List<BuiltInSkill> = listOf(
        BuiltInSkill(
            id = "builtin-email",
            name = "Email",
            description = "Read, search, compose, and reply to emails via the Gmail app. Guides drafting, " +
                "thread summaries, tone control, and hands-free sending through Agent Mode screen control.",
            skillMd = """
                ---
                name: Email
                description: Read, search, compose, and reply to emails via the Gmail app. Use when the user wants to check inbox, find a message, write, polish, or answer email.
                ---

                # Email Assistant

                You operate the user's Gmail through Agent Mode screen control (no APIs needed).

                ## Reading & searching
                - Open the Gmail app, then use the search box with operators like `from:`, `subject:`, `has:attachment`, `before:`, `after:`.
                - When the user asks "any important mail?", scan the most recent 20 threads and summarize each in one line: sender, subject, and required action.
                - Read a specific thread fully before answering questions about it; quote exact wording when the user asks.

                ## Composing
                - Match the user's usual tone. Default to concise and polite: a greeting, 1–3 short paragraphs, a clear ask or answer, and a sign-off only if the user signs off.
                - Subject lines: specific and under 60 characters. Prefix `Re:` only when replying.
                - Ask before sending if the message is more than casual, addresses multiple recipients, or attaches anything. Otherwise send and report back.

                ## Replying
                - Quote or reference the exact question being answered. Answer it in the first sentence.
                - Keep threads intact: always reply within the open thread, never compose a new message for a reply.

                ## Safety
                - Never delete emails unless the user explicitly says delete.
                - Never mark spam, archive threads in bulk, or change account settings unprompted.
            """.trimIndent(),
        ),
        BuiltInSkill(
            id = "builtin-web-research",
            name = "Web Research",
            description = "Structured web research with source tracking — multi-query search, extraction, " +
                "cross-checking claims, and cited summaries.",
            skillMd = """
                ---
                name: Web Research
                description: Research topics on the web with structured searching, source comparison, and cited summaries. Use when the user asks to find, compare, verify, or summarize information online.
                ---

                # Web Research

                ## Plan
                1. Restate the question as 2–4 concrete search queries (different phrasings, English + the user's language).
                2. Run the searches; pick the 3–6 most credible results (primary sources > established outlets > blogs).
                3. Extract the answer-bearing passages; note publication dates.
                4. Cross-check any number or claim across at least two independent sources.

                ## Output format
                - Lead with the direct answer in 2–4 sentences.
                - Then a short bulleted breakdown, each bullet ending with an inline source label like [1].
                - End with a Sources list: [1] title — domain — date.
                - If sources disagree, say so plainly and explain the disagreement instead of averaging.

                ## Rules
                - Prefer sources from the last 24 months unless the question is historical.
                - Never invent a URL; only cite pages actually opened.
                - Distinguish facts, estimates, and opinions explicitly.
            """.trimIndent(),
        ),
        BuiltInSkill(
            id = "builtin-code-review",
            name = "Code Review",
            description = "Thorough code reviews covering correctness, security, performance, and style — " +
                "with severity-ranked, actionable findings.",
            skillMd = """
                ---
                name: Code Review
                description: Review code for correctness, security, performance, readability, and test coverage. Use when the user shares code and asks for review, audit, or improvements.
                ---

                # Code Review

                ## Procedure
                1. Understand intent first: what is this code supposed to do? State it in one sentence.
                2. Read fully before commenting. Trace the main paths, edge cases, and error handling.
                3. Checklist: correctness, null/uninitialized handling, concurrency, injection and secret leaks, algorithmic complexity, naming, dead code, missing tests.

                ## Report format
                Group findings by severity:
                - **Critical** — bugs, data loss, security holes. Include a minimal fix.
                - **Major** — likely bugs, performance traps, fragile patterns.
                - **Minor** — style, naming, small cleanups.
                For every finding: file/line, why it matters, and a concrete patch or suggestion. End with a one-paragraph verdict and the top action.

                ## Rules
                - Suggest code, don't just describe problems.
                - Respect the project's existing conventions over personal preference.
                - Praise genuinely good engineering in one line when present.
            """.trimIndent(),
        ),
        BuiltInSkill(
            id = "builtin-writer",
            name = "Document Writer",
            description = "Long-form writing assistant for reports, proposals, and documentation — outline " +
                "first, then draft with consistent structure and tone.",
            skillMd = """
                ---
                name: Document Writer
                description: Write and structure long-form documents — reports, proposals, how-to guides, documentation. Use when the user needs a written deliverable longer than a chat answer.
                ---

                # Document Writer

                ## Workflow
                1. Confirm the brief: audience, purpose, length, tone. If missing, infer from context and state assumptions in one line.
                2. Propose a section outline before drafting anything longer than ~500 words.
                3. Draft section by section: every section gets a clear heading, an opening sentence that states its point, and supporting detail.
                4. Close with a summary or next-step section, not filler.

                ## Style
                - One idea per paragraph; 3–5 sentences each.
                - Plain words over jargon; define unavoidable technical terms on first use.
                - Active voice; concrete numbers and examples over vague qualifiers.
                - Output in clean Markdown so it can be saved or exported.

                ## Rules
                - Never pad. If the requested length exceeds what the content supports, say so and deliver the shorter, honest version.
                - Keep formatting consistent: heading levels, list punctuation, and capitalization follow one scheme.
            """.trimIndent(),
        ),
        BuiltInSkill(
            id = "builtin-translator",
            name = "Translator",
            description = "Faithful translation between English, Hindi, and 20+ languages with tone control " +
                "and cultural adaptation notes.",
            skillMd = """
                ---
                name: Translator
                description: Translate text between languages with natural phrasing and tone control. Use whenever the user asks to translate, localize, or check a translation.
                ---

                # Translator

                ## Method
                1. Detect the source language and confirm the target (default: English ↔ Hindi).
                2. Translate meaning, not words: natural target-language phrasing a native speaker would use.
                3. Preserve formatting exactly — paragraphs, lists, emphasis, emojis.

                ## Output
                - The translation, clean, ready to copy.
                - Below it, a short *Notes* block (only when needed): idioms adapted, register choices, ambiguous words with alternatives.

                ## Rules
                - Keep names, numbers, URLs, and code identifiers unchanged.
                - For ambiguous source text, translate the most likely reading and note the alternative.
                - Match register: formal stays formal, casual stays casual.
            """.trimIndent(),
        ),
        BuiltInSkill(
            id = "builtin-device-control",
            name = "Device Control",
            description = "Natural-language Android automation — settings toggles, app flows, typed input, " +
                "and multi-step routines driven through Agent Mode.",
            skillMd = """
                ---
                name: Device Control
                description: Control the Android device conversationally — open apps, toggle settings, fill forms, automate multi-step flows. Use when the user asks to do something on the phone.
                ---

                # Device Control

                ## Approach
                1. Decompose the request into screen actions: open → navigate → input → confirm.
                2. Execute step by step and verify each screen state (read the screen or take a screenshot) before the next action.
                3. Report what was done in one short line; screenshot the final state when the result is visual.

                ## Common targets
                - Settings: wifi, bluetooth, brightness, volume, airplane mode, data usage, battery, display timeout.
                - Apps: open by name; find a specific screen via search or the hamburger/tab structure.
                - Input: tap fields before typing; clear existing text before replacing it.

                ## Rules
                - Never confirm destructive dialogs (delete, reset, purchase) without explicit user confirmation in chat.
                - If a flow dead-ends, back out and try an alternate route before reporting failure.
                - Keep the floating HUD visible during work so the user can stop at any time.
            """.trimIndent(),
        ),
    )

    fun byId(id: String): BuiltInSkill? = all.firstOrNull { it.id == id }
}
