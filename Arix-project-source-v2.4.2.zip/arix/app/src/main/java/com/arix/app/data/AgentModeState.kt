package com.arix.app.data

/**
 * v2.3.2: standalone display/authorization state models.
 *
 * The accessibility-based Agent Mode controller was removed, but the Chrome
 * virtual display still reports its state through [AgentModeDisplayState],
 * and persisted chat metadata may carry authorization snapshots — so the
 * models live here, decoupled from any controller.
 */
enum class AgentModeAuthorizationIssue {
    None,
    NotificationAccessMissing,
    WriteSettingsMissing,
    AccessibilityMissing,
    AccessibilityReconnecting,
    DisplayUnavailable,
}

data class AgentModeAuthorizationState(
    val issue: AgentModeAuthorizationIssue = AgentModeAuthorizationIssue.None,
    val detail: String = "",
    val isReady: Boolean = false,
    val isAccessibilityServiceEnabled: Boolean = false,
    val isNotificationAccessEnabled: Boolean = false,
    val canWriteSettings: Boolean = false,
)

data class AgentModeDisplayInfo(
    val displayId: Int = -1,
    val name: String = "",
    val width: Int = 0,
    val height: Int = 0,
    val isArixDisplay: Boolean = false,
)

data class AgentModeDisplayState(
    val isActive: Boolean = false,
    val displayId: Int? = null,
    val width: Int = 0,
    val height: Int = 0,
    val isLivePreviewActive: Boolean = false,
    val status: String = "",
    val lastUpdatedMillis: Long = 0L,
    val latestPreviewPath: String = "",
    val latestWorkspacePath: String = "",
    val cursorX: Int? = null,
    val cursorY: Int? = null,
    val cursorAnimationDurationMillis: Int = 220,
    val displays: List<AgentModeDisplayInfo> = emptyList(),
)
