package com.arix.app.runtime

import com.arix.app.data.AppSettings
import com.arix.app.data.LocalRuntimeId
import org.json.JSONObject

class RuntimeRouter(
    private val alpineRuntime: LocalRuntime,
) {
    fun runtimeFor(
        settings: AppSettings,
        environment: String?,
    ): LocalRuntime? {
        val requested = environment?.trim().orEmpty().lowercase()
        if (requested == "termux") return null
        val runtimeId = when (requested) {
            "", "default", "alpine" -> LocalRuntimeId.Alpine
            else -> return null
        }
        if (settings.enabledRuntimeIds.isNotEmpty() && runtimeId !in settings.enabledRuntimeIds) {
            return null
        }
        return runtimeById(runtimeId)
    }

    fun runtimeById(runtimeId: LocalRuntimeId): LocalRuntime = when (runtimeId) {
        LocalRuntimeId.Alpine -> alpineRuntime
        LocalRuntimeId.Termux -> alpineRuntime
    }

    fun runtimeForRunId(runId: String): Pair<LocalRuntime, String>? {
        val separatorIndex = runId.indexOf(':')
        if (separatorIndex <= 0) return null
        val runtimeId = LocalRuntimeId.fromStorage(runId.substring(0, separatorIndex)) ?: return null
        return runtimeById(runtimeId) to runId.substring(separatorIndex + 1)
    }

    fun runtimeWorkspaceDirectory(
        settings: AppSettings,
        @Suppress("UNUSED_PARAMETER") legacyTermuxWorkspaceDirectory: String = "",
        environment: String? = null,
    ): String {
        val runtime = runtimeFor(settings, environment) ?: alpineRuntime
        return runtime.workspaceRoot
    }

    fun setupRequiredError(environment: String? = null): String =
        JSONObject().apply {
            put("ok", false)
            put("errmsg", "No local runtime is configured for this tool call.")
            put("hint", "Set up the Alpine runtime in Settings to use local tools.")
            if (!environment.isNullOrBlank()) put("environment", environment)
        }.toString()
}

fun JSONObject.runtimeEnvironment(): String =
    optString("environment").trim()
        .ifBlank { optString("runtime").trim() }
