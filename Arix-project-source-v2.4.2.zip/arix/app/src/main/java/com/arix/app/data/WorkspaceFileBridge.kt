package com.arix.app.data

import android.content.Context
import android.net.Uri
import android.webkit.MimeTypeMap
import com.arix.app.runtime.AlpineRuntime
import java.io.File
import java.net.URLDecoder
import java.nio.file.Paths
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Workspace file bridge for the built-in Alpine runtime. All workspace files
 * live on the Android host filesystem under the Alpine workspace root, so
 * reads, writes, and deletions are plain local file operations - no shell
 * dispatch and no external runtime app are involved.
 */
class WorkspaceFileBridge(
    context: Context,
    private val alpineRuntime: AlpineRuntime,
) {
    private val appContext = context.applicationContext

    fun workspaceDirectory(
        sessionId: String = "",
        mode: AgentWorkspaceMode = AgentWorkspaceMode.Shared,
    ): String = alpineRuntime.workspaceRoot

    fun workspaceUploadsDirectory(
        sessionId: String = "",
        mode: AgentWorkspaceMode = AgentWorkspaceMode.Shared,
    ): String = "${alpineRuntime.workspaceRoot}/uploads"

    suspend fun hasLegacySessionWorkspaces(): Boolean = false

    suspend fun deleteSessionRuntimeData(
        sessionId: String,
        sharedWorkspaceFilePaths: Collection<String> = emptyList(),
    ): Result<Unit> = deleteSessionsRuntimeData(
        sessionIds = listOf(sessionId),
        sharedWorkspaceFilePaths = sharedWorkspaceFilePaths,
    )

    suspend fun deleteSessionsRuntimeData(
        sessionIds: Collection<String>,
        sharedWorkspaceFilePaths: Collection<String> = emptyList(),
    ): Result<Unit> = withContext(Dispatchers.IO) {
        runCatching {
            val failures = mutableListOf<String>()
            val uniqueSharedWorkspaceFilePaths = sharedWorkspaceFilePaths
                .map(String::trim)
                .filter(String::isNotEmpty)
                .distinct()

            uniqueSharedWorkspaceFilePaths.forEach { path ->
                deleteSharedWorkspaceFile(path = path).onFailure { error ->
                    failures += "shared file $path: ${error.message.orEmpty()}"
                }
            }
            if (failures.isNotEmpty()) {
                error(
                    "Failed to clean up ${failures.size} runtime item(s): " +
                        failures.joinToString(" | ")
                )
            }
        }
    }

    private fun deleteSharedWorkspaceFile(path: String): Result<Unit> = runCatching {
        val resolved = alpineRuntime.resolveWorkspaceHostPath(
            path = path,
            workingDirectory = workspaceUploadsDirectory(),
        ) ?: error("Shared workspace path is outside the workspace: $path")
        val file = resolved.hostFile
        val uploadsRoot = alpineRuntime.resolveWorkspaceHostPath(
            path = workspaceUploadsDirectory(),
        )?.hostFile?.canonicalFile
        requireNotNull(uploadsRoot) { "Workspace uploads root could not be resolved." }
        val canonicalFile = file.canonicalFile
        if (canonicalFile != uploadsRoot &&
            !canonicalFile.path.startsWith("${uploadsRoot.path}${File.separator}")
        ) {
            error("Refusing to delete a path outside the workspace uploads directory: $path")
        }
        if (canonicalFile.exists() && !canonicalFile.isFile) {
            error("Refusing to delete a non-file workspace path: $path")
        }
        if (canonicalFile.isFile) {
            if (!canonicalFile.delete()) {
                error("Workspace file could not be deleted: $path")
            }
        }
    }

    fun resolveWorkspaceDownloadName(rawLink: String): String {
        val normalizedPath = resolveLinkPath(rawLink)
        return normalizedPath.substringAfterLast('/').ifBlank { "download" }
    }

    fun resolveLinkPath(rawLink: String): String =
        resolveWorkspacePath(
            path = normalizeFileLink(rawLink),
            workingDirectory = alpineRuntime.workspaceRoot,
        )

    fun resolveWorkspacePath(
        path: String,
        workingDirectory: String = alpineRuntime.workspaceRoot,
    ): String {
        val trimmedPath = path.trim()
        val normalizedWorkingDirectory = workingDirectory.trim()
            .ifBlank { alpineRuntime.workspaceRoot }
            .let(::normalizeLegacyHomePrefix)

        return when {
            trimmedPath.isBlank() -> normalizedWorkingDirectory
            trimmedPath == "~" -> alpineRuntime.homeDirectory
            trimmedPath.startsWith("~/") -> alpineRuntime.homeDirectory + trimmedPath.removePrefix("~")
            trimmedPath.startsWith("/") -> Paths.get(trimmedPath).normalize().toString()
            else -> Paths.get(normalizedWorkingDirectory).resolve(trimmedPath).normalize().toString()
        }
    }

    fun guessMimeType(path: String): String {
        val extension = path.substringAfterLast('.', "").lowercase()
        return MimeTypeMap.getSingleton().getMimeTypeFromExtension(extension).orEmpty()
    }

    suspend fun readWorkspaceFile(
        path: String,
        workingDirectory: String,
        byteLimit: Int,
    ): Result<WorkspaceFilePayload> = withContext(Dispatchers.IO) {
        runCatching {
            require(byteLimit > 0) { "byteLimit must be greater than 0." }
            val resolved = alpineRuntime.resolveWorkspaceHostPath(
                path = normalizeFileLink(path),
                workingDirectory = workingDirectory,
            ) ?: error("Path is outside the workspace: $path")
            val file = resolved.hostFile
            require(file.isFile) { "File was not found in the workspace: ${resolved.guestPath}" }
            val sizeBytes = file.length()
            require(sizeBytes <= byteLimit) {
                "File is larger than $byteLimit bytes: ${resolved.guestPath}"
            }
            val bytes = file.readBytes()
            require(bytes.size <= byteLimit) {
                "File is larger than $byteLimit bytes: ${resolved.guestPath}"
            }
            WorkspaceFilePayload(
                absolutePath = resolved.guestPath,
                bytes = bytes,
                sizeBytes = bytes.size.toLong(),
            )
        }
    }

    suspend fun readRootImageFile(
        path: String,
        workingDirectory: String,
        byteLimit: Int,
    ): Result<WorkspaceFilePayload> = readWorkspaceFile(
        path = path,
        workingDirectory = workingDirectory,
        byteLimit = byteLimit,
    )

    suspend fun saveWorkspaceFileToDocument(
        path: String,
        destinationUri: Uri,
        workingDirectory: String = alpineRuntime.workspaceRoot,
        byteLimit: Int = 256 * 1024 * 1024,
    ): Boolean = withContext(Dispatchers.IO) {
        runCatching {
            val resolved = alpineRuntime.resolveWorkspaceHostPath(
                path = normalizeFileLink(path),
                workingDirectory = workingDirectory,
            ) ?: error("Path is outside the workspace: $path")
            val source = resolved.hostFile
            require(source.isFile) { "File was not found in the workspace: ${resolved.guestPath}" }
            require(source.length() <= byteLimit) {
                "File is larger than $byteLimit bytes: ${resolved.guestPath}"
            }
            val didWrite = appContext.contentResolver.openOutputStream(destinationUri, "w")
                ?.use { output ->
                    source.inputStream().use { input -> input.copyTo(output) }
                    output.flush()
                    true
                } ?: false
            if (!didWrite) {
                runCatching { appContext.contentResolver.delete(destinationUri, null, null) }
            }
            didWrite
        }.getOrDefault(false)
    }

    suspend fun writeWorkspaceBytes(
        absolutePath: String,
        bytes: ByteArray,
    ): Result<Long> = withContext(Dispatchers.IO) {
        runCatching {
            val resolved = alpineRuntime.resolveWorkspaceHostPath(
                path = normalizeFileLink(absolutePath),
            ) ?: error("Path is outside the workspace: $absolutePath")
            resolved.hostFile.parentFile?.mkdirs()
            resolved.hostFile.outputStream().use { output ->
                output.write(bytes)
                output.flush()
            }
            bytes.size.toLong()
        }
    }

    private fun normalizeLegacyHomePrefix(path: String): String = when {
        path == "~" -> alpineRuntime.workspaceRoot
        path.startsWith("~/") -> alpineRuntime.workspaceRoot + path.removePrefix("~")
        else -> path
    }

    private fun normalizeFileLink(rawLink: String): String {
        val trimmed = rawLink.trim()
        if (!trimmed.startsWith("file://", ignoreCase = true)) return trimmed
        val withoutScheme = trimmed.substring("file://".length)
        val withoutLocalhost = when {
            withoutScheme.startsWith("localhost/") -> "/" + withoutScheme.removePrefix("localhost/")
            withoutScheme == "localhost" -> "/"
            else -> withoutScheme
        }
        return URLDecoder.decode(withoutLocalhost, Charsets.UTF_8.name()).trim()
    }
}

data class ImportedWorkspaceFile(
    val absolutePath: String,
    val bytesCopied: Long,
    val inlineBytes: ByteArray = ByteArray(0),
)

data class WorkspaceImportProgress(
    val bytesCopied: Long,
    val bytesPerSecond: Long,
)

data class WorkspaceFilePayload(
    val absolutePath: String,
    val bytes: ByteArray,
    val sizeBytes: Long,
) {
    override fun equals(other: Any?): Boolean = this === other
    override fun hashCode(): Int = System.identityHashCode(this)
}
