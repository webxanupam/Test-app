package com.arix.app.data.pi

import com.arix.app.data.AppSettings
import com.arix.app.data.LocalRuntimeId
import java.time.ZonedDateTime
import java.time.format.DateTimeFormatter
import java.util.Locale

private val DynamicPromptPlaceholderRegex = Regex("""\{\{\s*([A-Za-z0-9_-]+)\s*\}\}""")

internal fun buildPiAgentInstructions(
    settings: AppSettings,
    workspaceDirectory: String,
    runtimeId: LocalRuntimeId,
    agentModeEnabled: Boolean,
    chromeEnabled: Boolean = false,
): String = buildString {
    val configuredPrompt = expandDynamicPromptPlaceholders(settings.systemPrompt).trim()
    if (configuredPrompt.isNotBlank()) {
        append(configuredPrompt)
        append("\n\n")
    }
    append(
        "You are running inside Arix on Android. " +
            "The current local runtime is ${runtimeId.storageValue} and its session cwd is $workspaceDirectory. " +
            "User-uploaded files are placed under uploads/; use read on the provided path when image or file contents are needed. " +
            "Arix-owned configuration, Skill, runtime, Extension, scheduled-task, and developer operations are exposed only through available arix_* tools. " +
            "Never modify LLM provider credentials or model configuration through self-management tools. " +
            "Only claim device actions or command results that were actually observed."
    )
    append(
        "\n\nYou CAN control this Android device — without root and without any accessibility service — " +
            "through two mechanisms. Always actually DO the requested action with a tool call instead of " +
            "telling the user to do it themselves.\n" +
            "1. system_control tool (instant, no permissions beyond notification access for reading): " +
            "open_app target=<name-or-package> launches any installed app (gmail, flipkart, whatsapp, ...); " +
            "list_apps query=<name> finds installed apps; read_notifications filter=<package> reads live " +
            "notifications — this is how you check unread mail (filter gmail, then report the unread counts " +
            "and senders; enable once via open_settings page=notification_access); open_url opens web pages " +
            "AND app deep links (flipkart://search?q=iphone+17, mailto:...); open_settings page=wifi|bluetooth|...; " +
            "volume; device_info.\n" +
            "2. chrome tool (in-Alpine headless Chromium, full web automation): navigate, click, type, " +
            "get_readable, find_elements, evaluate — use it to automate websites end to end.\n" +
            "WORKFLOW EXAMPLES: 'check my unread mail' → read_notifications filter=gmail, summarize counts " +
            "and latest senders, then open_app target=gmail if the user wants to read them. 'Go to Flipkart " +
            "and add iPhone 17 to my cart' → first try system_control open_app target=flipkart; if not " +
            "installed or a deep link fails, use the chrome tool: navigate https://www.flipkart.com/search?q=iphone+17, " +
            "click the first product, click ADD TO CART, then verify with get_readable and report what happened. " +
            "Never claim an action completed unless a tool result confirmed it."
    )
    if (runtimeId == LocalRuntimeId.Alpine) {
        append(
            "\n\nAndroid system control without root: prefer the system_control tool for launching apps, " +
                "opening settings, and reading notifications — it is faster and cannot fail on PATH. The Alpine " +
                "shell also mounts the Android /system toolbox: '/system/bin/am start -n <pkg>/<activity>' or " +
                "'/system/bin/am start -a android.intent.action.VIEW -d <url>' launches apps and links, " +
                "'/system/bin/pm list packages -3' lists apps, and '/system/bin/dumpsys battery', " +
                "'dumpsys window' etc. report system state where permitted. Always call system binaries by " +
                "absolute path (/system/bin/am) in case PATH is reset by a login profile. Use the shell for " +
                "advanced inspection and system_control for everything the user can see."
        )
    }
    if (chromeEnabled) {
        append(
            "\n\nThe chat has enabled the browser tool (Chrome Extension tool). Prefer selectors and DOM-reading actions, and use coordinates only as a fallback."
        )
    }
}

private fun expandDynamicPromptPlaceholders(
    prompt: String,
    now: ZonedDateTime = ZonedDateTime.now(),
): String {
    if (!prompt.contains("{{")) return prompt
    val values = mapOf(
        "current_datetime" to now.format(DateTimeFormatter.ISO_OFFSET_DATE_TIME),
        "current_date" to now.toLocalDate().toString(),
        "current_time" to now.toLocalTime().withNano(0).toString(),
        "timezone" to now.zone.id,
        "unix_timestamp" to now.toEpochSecond().toString(),
    )
    return DynamicPromptPlaceholderRegex.replace(prompt) { match ->
        values[match.groupValues[1].lowercase(Locale.US)] ?: match.value
    }
}
