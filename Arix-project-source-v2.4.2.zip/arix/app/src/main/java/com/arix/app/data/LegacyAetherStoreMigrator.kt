package com.arix.app.data

import android.content.Context
import java.io.File

/**
 * One-time migration that carries user data written by earlier Arix builds
 * (v2.1.5, which still used internal "aether_*" storage file names) into the
 * rebranded "arix_*" storage names. Without this, installing the update over
 * v2.1.5 would silently reset settings, provider API keys, chat history and
 * scheduled tasks.
 *
 * The migration runs synchronously in [com.arix.app.ArixApplication.onCreate]
 * before any DataStore, SharedPreferences or Room database is opened, so it
 * cannot race with store initialization. It is safe to run repeatedly: a
 * SharedPreferences marker makes it a no-op after the first run, and each file
 * copy only happens when the legacy file still exists.
 */
object LegacyAetherStoreMigrator {
    private const val MarkerPreferencesName = "arix_store_migration"
    private const val MarkerKey = "migrated_from_legacy_aether_stores"

    private val dataStorePairs = listOf(
        "aether_settings" to "arix_settings",
        "aether_chats" to "arix_chats",
        "aether_agent_extensions" to "arix_agent_extensions",
        "aether_scheduled_tasks" to "arix_scheduled_tasks",
        "aether_pi_extension_state" to "arix_pi_extension_state",
    )

    private val sharedPreferencesPairs = listOf(
        "aether_discovered_skills" to "arix_discovered_skills",
        "aether_native_mods" to "arix_native_mods",
    )

    private val databasePairs = listOf(
        "aether_chat_history" to "arix_chat_history",
    )

    private val databaseSidecarSuffixes = listOf("", "-wal", "-shm", "-journal")

    fun migrate(context: Context) {
        val appContext = context.applicationContext
        val marker = appContext.getSharedPreferences(MarkerPreferencesName, Context.MODE_PRIVATE)
        if (marker.getBoolean(MarkerKey, false)) return
        try {
            migrateDataStores(appContext)
            migrateSharedPreferences(appContext)
            migrateDatabases(appContext)
        } catch (_: Exception) {
            // Best effort: a partial migration must never crash the app.
        } finally {
            marker.edit().putBoolean(MarkerKey, true).apply()
        }
    }

    private fun migrateDataStores(context: Context) {
        val datastoreDir = File(context.filesDir, "datastore")
        dataStorePairs.forEach { (legacyName, currentName) ->
            copyIfLegacyExists(
                source = File(datastoreDir, "$legacyName.preferences_pb"),
                target = File(datastoreDir, "$currentName.preferences_pb"),
            )
        }
    }

    private fun migrateSharedPreferences(context: Context) {
        val prefsDir = File(context.filesDir.parentFile, "shared_prefs")
        sharedPreferencesPairs.forEach { (legacyName, currentName) ->
            copyIfLegacyExists(
                source = File(prefsDir, "$legacyName.xml"),
                target = File(prefsDir, "$currentName.xml"),
            )
        }
    }

    private fun migrateDatabases(context: Context) {
        val dbDir = File(context.filesDir.parentFile, "databases")
        databasePairs.forEach { (legacyName, currentName) ->
            databaseSidecarSuffixes.forEach { suffix ->
                copyIfLegacyExists(
                    source = File(dbDir, "$legacyName.db$suffix"),
                    target = File(dbDir, "$currentName.db$suffix"),
                )
            }
        }
    }

    /**
     * Copies the legacy file over the current one. The current file is
     * replaced unconditionally because a crashing intermediate build may have
     * created an empty store; the legacy file always holds the user's real
     * data. When the legacy file is missing (fresh install) nothing happens.
     */
    private fun copyIfLegacyExists(source: File, target: File) {
        if (!source.isFile || source.length() == 0L) return
        try {
            target.parentFile?.mkdirs()
            if (target.exists()) {
                target.delete()
            }
            source.copyTo(target, overwrite = true)
        } catch (_: Exception) {
            // Individual file failures must not block the remaining copies.
        }
    }
}
