// Auto-generated from the reference QR tables (ISO/IEC 18004). ECC level M.
internal object ArixQrTables {
    /** Per version: groups of (blocks, totalCodewords, dataCodewords). */
    val rsBlocksM: Array<Array<IntArray>> = arrayOf(
        arrayOf(intArrayOf(1,26,16)), // v1 data=16
        arrayOf(intArrayOf(1,44,28)), // v2 data=28
        arrayOf(intArrayOf(1,70,44)), // v3 data=44
        arrayOf(intArrayOf(2,50,32)), // v4 data=64
        arrayOf(intArrayOf(2,67,43)), // v5 data=86
        arrayOf(intArrayOf(4,43,27)), // v6 data=108
        arrayOf(intArrayOf(4,49,31)), // v7 data=124
        arrayOf(intArrayOf(2,60,38), intArrayOf(2,61,39)), // v8 data=154
        arrayOf(intArrayOf(3,58,36), intArrayOf(2,59,37)), // v9 data=182
        arrayOf(intArrayOf(4,69,43), intArrayOf(1,70,44)), // v10 data=216
        arrayOf(intArrayOf(1,80,50), intArrayOf(4,81,51)), // v11 data=254
        arrayOf(intArrayOf(6,58,36), intArrayOf(2,59,37)), // v12 data=290
        arrayOf(intArrayOf(8,59,37), intArrayOf(1,60,38)), // v13 data=334
        arrayOf(intArrayOf(4,64,40), intArrayOf(5,65,41)), // v14 data=365
        arrayOf(intArrayOf(5,65,41), intArrayOf(5,66,42)), // v15 data=415
        arrayOf(intArrayOf(7,73,45), intArrayOf(3,74,46)), // v16 data=453
        arrayOf(intArrayOf(10,74,46), intArrayOf(1,75,47)), // v17 data=507
        arrayOf(intArrayOf(9,69,43), intArrayOf(4,70,44)), // v18 data=563
        arrayOf(intArrayOf(3,70,44), intArrayOf(11,71,45)), // v19 data=627
        arrayOf(intArrayOf(3,67,41), intArrayOf(13,68,42)), // v20 data=669
        arrayOf(intArrayOf(17,68,42)), // v21 data=714
        arrayOf(intArrayOf(17,74,46)), // v22 data=782
        arrayOf(intArrayOf(4,75,47), intArrayOf(14,76,48)), // v23 data=860
        arrayOf(intArrayOf(6,73,45), intArrayOf(14,74,46)), // v24 data=914
        arrayOf(intArrayOf(8,75,47), intArrayOf(13,76,48)), // v25 data=1000
        arrayOf(intArrayOf(19,74,46), intArrayOf(4,75,47)), // v26 data=1062
        arrayOf(intArrayOf(22,73,45), intArrayOf(3,74,46)), // v27 data=1128
        arrayOf(intArrayOf(3,73,45), intArrayOf(23,74,46)), // v28 data=1193
        arrayOf(intArrayOf(21,73,45), intArrayOf(7,74,46)), // v29 data=1267
        arrayOf(intArrayOf(19,75,47), intArrayOf(10,76,48)), // v30 data=1373
        arrayOf(intArrayOf(2,74,46), intArrayOf(29,75,47)), // v31 data=1455
        arrayOf(intArrayOf(10,74,46), intArrayOf(23,75,47)), // v32 data=1541
        arrayOf(intArrayOf(14,74,46), intArrayOf(21,75,47)), // v33 data=1631
        arrayOf(intArrayOf(14,74,46), intArrayOf(23,75,47)), // v34 data=1725
        arrayOf(intArrayOf(12,75,47), intArrayOf(26,76,48)), // v35 data=1812
        arrayOf(intArrayOf(6,75,47), intArrayOf(34,76,48)), // v36 data=1914
        arrayOf(intArrayOf(29,74,46), intArrayOf(14,75,47)), // v37 data=1992
        arrayOf(intArrayOf(13,74,46), intArrayOf(32,75,47)), // v38 data=2102
        arrayOf(intArrayOf(40,75,47), intArrayOf(7,76,48)), // v39 data=2216
        arrayOf(intArrayOf(18,75,47), intArrayOf(31,76,48)), // v40 data=2334
    )

    /** Per version: alignment pattern center coordinates. */
    val alignmentPositions: Array<IntArray> = arrayOf(
        intArrayOf(),
        intArrayOf(6,18),
        intArrayOf(6,22),
        intArrayOf(6,26),
        intArrayOf(6,30),
        intArrayOf(6,34),
        intArrayOf(6,22,38),
        intArrayOf(6,24,42),
        intArrayOf(6,26,46),
        intArrayOf(6,28,50),
        intArrayOf(6,30,54),
        intArrayOf(6,32,58),
        intArrayOf(6,34,62),
        intArrayOf(6,26,46,66),
        intArrayOf(6,26,48,70),
        intArrayOf(6,26,50,74),
        intArrayOf(6,30,54,78),
        intArrayOf(6,30,56,82),
        intArrayOf(6,30,58,86),
        intArrayOf(6,34,62,90),
        intArrayOf(6,28,50,72,94),
        intArrayOf(6,26,50,74,98),
        intArrayOf(6,30,54,78,102),
        intArrayOf(6,28,54,80,106),
        intArrayOf(6,32,58,84,110),
        intArrayOf(6,30,58,86,114),
        intArrayOf(6,34,62,90,118),
        intArrayOf(6,26,50,74,98,122),
        intArrayOf(6,30,54,78,102,126),
        intArrayOf(6,26,52,78,104,130),
        intArrayOf(6,30,56,82,108,134),
        intArrayOf(6,34,60,86,112,138),
        intArrayOf(6,30,58,86,114,142),
        intArrayOf(6,34,62,90,118,146),
        intArrayOf(6,30,54,78,102,126,150),
        intArrayOf(6,24,50,76,102,128,154),
        intArrayOf(6,28,54,80,106,132,158),
        intArrayOf(6,32,58,84,110,136,162),
        intArrayOf(6,26,54,82,110,138,166),
        intArrayOf(6,30,58,86,114,142,170),
    )
}
