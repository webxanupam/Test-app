import type { ExtensionAPI } from "@earendil-works/pi-coding-agent";
import {
  defineArixExtension,
  ui,
} from "@baimoqilin/arix-extension-api";

export default function activatePi(pi: ExtensionAPI) {
  pi.registerCommand("arix-example", {
    description: "Show that the package is also active in Pi",
    handler: async (_args, context) => {
      context.ui.notify("The combined extension is active.", "info");
    },
  });
}

export const activateArix = defineArixExtension((arix) => {
  arix.registerAction("increment", async () => {
    const count = arix.storage.get("count", 0) + 1;
    arix.storage.set("count", count);
    await arix.host.invoke("app.notify", {
      message: `Extension count: ${count}`,
    });
  });

  arix.registerAction("prefill", async () => {
    await arix.host.invoke("app.setDraftInput", {
      text: "Summarize the current workspace and suggest the next three tasks.",
    });
  });

  arix.registerSurface("chat.composer.top", {
    id: "quick-tools",
    order: 10,
    render: ({ storage, is_running }) =>
      ui.card([
        ui.row([
          ui.text("Combined extension", {
            style: "label",
            weight: "semibold",
          }),
          ui.text(is_running ? "Agent running" : "Ready", {
            color: "muted",
          }),
        ], {
          arrangement: "space-between",
          verticalAlignment: "center",
        }),
        ui.row([
          ui.button(`Count ${storage.count ?? 0}`, "increment", {
            tone: "neutral",
          }),
          ui.button("Prefill", "prefill"),
        ], {
          wrap: true,
          rowSpacing: 8,
        }),
      ], {
        radius: 22,
      }),
  });

  /* Full-screen page registration is intentionally unsupported. */
  arix.registerSettings({
    id: "dashboard",
    title: "Extension dashboard",
    subtitle: "Native Compose and trusted TypeScript",
    icon: "code",
    categories: [{ id: "dashboard", title: "Dashboard", sections: [{ settings: [] }] }],
  });

  arix.on("before_send", ({ text }) => {
    if (String(text).startsWith("!raw ")) {
      return { text: String(text).slice(5) };
    }
    return undefined;
  });
});
