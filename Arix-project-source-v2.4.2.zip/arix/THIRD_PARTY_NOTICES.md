# Third-party notices

This Android-only distribution no longer bundles the OpenMinis/ish-arm64 iOS
runtime, the Alpine Linux minirootfs it downloads, or any iOS-specific build
integration. All iOS-related third-party components were removed together with
the iOS target when this project was rebranded.

For licenses of the remaining third-party components (Termux terminal-emulator
and terminal-view libraries, the Pi framework and its extension ecosystem, and
all Android/Gradle dependencies), refer to the license files shipped with each
upstream project and the dependency metadata in `gradle/libs.versions.toml`.
