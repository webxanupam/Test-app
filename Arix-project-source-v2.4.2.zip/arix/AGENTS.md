This is an Android-only project (all iOS targets have been removed). Every change only needs to work and be verified on Android.

Retrospective notes:

- After modifying `shared/src/commonMain`, confirm whether the Android `app` module's platform implementations are affected, then compile and install to verify. Never assume a change took effect based on shared-layer code alone.
- When stacking shadows with `Box` in Compose, `matchParentSize()` children do not participate in the parent's size measurement. The parent must contain at least one normally-measured content child (for example a fixed-height `Row`); otherwise capsules, buttons, and similar controls may collapse to zero width and disappear entirely.
- After installation, always verify the package name and installation result on the actual connected device; a successful build alone is not sufficient.
- When searching files or code, always exclude cache directories, third-party source directories, build directories, and other generated-file directories by default to avoid being flooded with noise, unless you specifically need to search those directories.

Device installation flow:

- Android: first confirm the target serial with `adb devices -l`, then run `./gradlew :app:assembleDebug --no-daemon` and `adb -s <serial> install -r app/build/outputs/apk/debug/app-debug.apk`. After installing, run `adb -s <serial> shell pm path com.arix.app` and verify the version information with `dumpsys package`. In multi-device environments, never use `adb install` without `-s`.
