package com.arix.app.platform

actual val currentPlatformCapabilities: PlatformCapabilities = PlatformCapabilities.Android
