package com.arix.app.data.pi

import com.arix.app.runtime.MultiplatformLocalRuntime

internal actual fun createPlatformBrowserBackend(
    runtime: MultiplatformLocalRuntime,
): SharedBrowserBackend? = null
