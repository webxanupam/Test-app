package com.arix.app.ui

internal expect fun formatSharedMessageTimestamp(epochMillis: Long): String
