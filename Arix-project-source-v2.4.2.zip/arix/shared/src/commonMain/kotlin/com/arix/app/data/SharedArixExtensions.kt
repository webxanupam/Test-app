package com.arix.app.data

import com.arix.app.runtime.SharedPiBridgeClient
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonNull
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.booleanOrNull
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.intOrNull
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.longOrNull

data class SharedArixExtensionInfo(
    val id: String,
    val name: String,
    val path: String,
)

data class SharedArixExtensionSurface(
    val id: String,
    val extensionId: String,
    val extensionName: String,
    val slot: String,
    val order: Int,
    val tree: JsonElement?,
)

data class SharedArixExtensionComponent(
    val id: String,
    val extensionId: String,
    val extensionName: String,
    val target: String,
    val mode: String,
    val order: Int,
    val tree: JsonElement?,
)

data class SharedArixExtensionComposerMenuItem(
    val id: String,
    val localId: String,
    val extensionId: String,
    val extensionName: String,
    val title: String,
    val subtitle: String,
    val icon: String,
    val order: Int,
    val action: String,
    val args: JsonObject,
    val selected: Boolean,
)

data class SharedArixExtensionSettingsPage(
    val id: String,
    val localId: String,
    val extensionId: String,
    val extensionName: String,
    val title: String,
    val subtitle: String,
    val icon: String,
    val order: Int,
    val trailingIcon: String = "",
    val trailingAction: String = "",
    val trailingCategory: String = "",
    val trailingArgs: JsonObject = JsonObject(emptyMap()),
    val sections: List<JsonObject>,
    val categories: List<SharedArixExtensionSettingsCategory> = emptyList(),
)

data class SharedArixExtensionSettingsCategory(
    val id: String,
    val title: String,
    val subtitle: String,
    val icon: String,
    val order: Int,
    val trailingIcon: String = "",
    val trailingAction: String = "",
    val trailingCategory: String = "",
    val trailingArgs: JsonObject = JsonObject(emptyMap()),
    val hidden: Boolean = false,
    val sections: List<JsonObject>,
)

data class SharedArixExtensionMessageType(
    val id: String,
    val type: String,
    val extensionId: String,
    val extensionName: String,
    val title: String,
    val icon: String,
)

data class SharedArixExtensionCustomMessage(
    val id: String,
    val type: String,
    val extensionId: String,
    val tree: JsonElement?,
)

data class SharedArixExtensionError(
    val path: String,
    val extensionId: String,
    val phase: String,
    val message: String,
)

data class SharedArixExtensionNotification(
    val message: String,
    val level: String,
)

data class SharedPiExtensionUiRequest(
    val callId: String,
    val method: String,
    val title: String,
    val message: String = "",
    val placeholder: String = "",
    val options: List<String> = emptyList(),
)

data class SharedArixExtensionSnapshot(
    val apiVersion: Int = 2,
    val version: Long = 0,
    val extensions: List<SharedArixExtensionInfo> = emptyList(),
    val surfaces: List<SharedArixExtensionSurface> = emptyList(),
    val components: List<SharedArixExtensionComponent> = emptyList(),
    val composerMenuItems: List<SharedArixExtensionComposerMenuItem> = emptyList(),
    val settings: List<SharedArixExtensionSettingsPage> = emptyList(),
    val messageTypes: List<SharedArixExtensionMessageType> = emptyList(),
    val customMessages: List<SharedArixExtensionCustomMessage> = emptyList(),
    val eventNames: Set<String> = emptySet(),
    val errors: List<SharedArixExtensionError> = emptyList(),
) {
    fun surfacesAt(slot: String): List<SharedArixExtensionSurface> =
        surfaces.filter { it.slot == slot }.sortedWith(
            compareBy<SharedArixExtensionSurface> { it.order }.thenBy { it.id }
        )

    fun componentsAt(target: String): List<SharedArixExtensionComponent> =
        components.filter { it.target == target }.sortedWith(
            compareBy<SharedArixExtensionComponent> { it.order }.thenBy { it.id }
        )
}

class SharedArixExtensionManager(
    private val bridge: SharedPiBridgeClient,
    private val hostHandler: suspend (String, JsonObject) -> JsonObject,
) {
    private val mutex = Mutex()
    private val uiRequestMutex = Mutex()
    private val pendingUiRequests = ArrayDeque<SharedPiExtensionUiRequest>()
    private val _notifications = MutableSharedFlow<SharedArixExtensionNotification>(
        extraBufferCapacity = 8,
    )
    private val _piUiRequest = MutableStateFlow<SharedPiExtensionUiRequest?>(null)
    var snapshot: SharedArixExtensionSnapshot = SharedArixExtensionSnapshot()
        private set
    var error: String = ""
        private set

    val notifications: SharedFlow<SharedArixExtensionNotification> = _notifications.asSharedFlow()
    val piUiRequest: StateFlow<SharedPiExtensionUiRequest?> = _piUiRequest.asStateFlow()

    suspend fun refresh(
        context: JsonObject = JsonObject(emptyMap()),
    ): SharedArixExtensionSnapshot = mutex.withLock {
        val response = bridge.getArixExtensions(context, ::handleEvent)
        parseResponse(response)
    }

    suspend fun reload(
        context: JsonObject = JsonObject(emptyMap()),
    ): SharedArixExtensionSnapshot = mutex.withLock {
        val response = bridge.reloadArixExtensions(context, ::handleEvent)
        parseResponse(response)
    }

    suspend fun invokeAction(
        extensionId: String,
        action: String,
        args: JsonObject = JsonObject(emptyMap()),
        context: JsonObject = JsonObject(emptyMap()),
    ): SharedArixExtensionSnapshot = mutex.withLock {
        val response = bridge.invokeArixExtensionAction(
            extensionId = extensionId,
            action = action,
            args = args,
            context = context,
            onEvent = ::handleEvent,
        )
        parseResponse(response)
    }

    suspend fun dispatchEvent(
        event: String,
        data: JsonObject = JsonObject(emptyMap()),
        context: JsonObject = JsonObject(emptyMap()),
    ): JsonObject {
        if (event !in snapshot.eventNames) return JsonObject(emptyMap())
        return mutex.withLock {
            val response = bridge.dispatchArixExtensionEvent(
                event = event,
                data = data,
                context = context,
                onEvent = ::handleEvent,
            )
            response.objectOrNull("snapshot")?.let {
                snapshot = parseSharedArixExtensionSnapshot(it)
            }
            response
        }
    }

    suspend fun subscribe(
        onInvalidated: suspend () -> Unit,
    ) {
        bridge.subscribeArixExtensions { event, payload ->
            handleEvent(event, payload)
            if (event == "arix_invalidated") onInvalidated()
        }
    }

    suspend fun respondToPiExtensionUiRequest(
        callId: String,
        value: JsonElement?,
    ) {
        val request = uiRequestMutex.withLock {
            val current = _piUiRequest.value
            if (current?.callId != callId) return
            _piUiRequest.value = pendingUiRequests.removeFirstOrNull()
            current
        }
        bridge.sendArixHostResult(
            callId = request.callId,
            result = JsonObject(mapOf("value" to (value ?: JsonNull))),
        )
    }

    private suspend fun handleEvent(event: String, payload: JsonObject) {
        when (event) {
            "arix_notification" -> _notifications.emit(
                SharedArixExtensionNotification(
                    message = payload.string("message"),
                    level = payload.string("level").ifBlank { "info" },
                )
            )
            "arix_host_call" -> {
                val callId = payload.string("call_id")
                val method = payload.string("method")
                val args = payload.objectOrNull("args") ?: JsonObject(emptyMap())
                if (method == "pi_extension_notify") {
                    _notifications.emit(
                        SharedArixExtensionNotification(
                            message = args.string("message"),
                            level = args.string("type").ifBlank { "info" },
                        )
                    )
                    bridge.sendArixHostResult(
                        callId = callId,
                        result = JsonObject(mapOf("notified" to JsonPrimitive(true))),
                    )
                    return
                }
                if (method in SharedPiExtensionInteractiveUiMethods) {
                    val request = SharedPiExtensionUiRequest(
                        callId = callId,
                        method = method,
                        title = args.string("title"),
                        message = args.string("message"),
                        placeholder = args.string("placeholder"),
                        options = (args["options"] as? JsonArray)
                            .orEmpty()
                            .mapNotNull { option ->
                                (option as? JsonPrimitive)
                                    ?.contentOrNull
                                    ?.takeIf(String::isNotBlank)
                            },
                    )
                    uiRequestMutex.withLock {
                        if (_piUiRequest.value == null) {
                            _piUiRequest.value = request
                        } else {
                            pendingUiRequests.addLast(request)
                        }
                    }
                    return
                }
                val result = runCatching { hostHandler(method, args) }
                bridge.sendArixHostResult(
                    callId = callId,
                    result = result.getOrDefault(JsonObject(emptyMap())),
                    error = result.exceptionOrNull()?.message.orEmpty(),
                )
            }
        }
    }

    private fun parseResponse(response: JsonObject): SharedArixExtensionSnapshot {
        snapshot = parseSharedArixExtensionSnapshot(response.objectOrNull("snapshot"))
        error = (response["errors"] as? JsonArray)
            .orEmpty()
            .mapNotNull { (it as? JsonObject)?.string("error")?.takeIf(String::isNotBlank) }
            .take(3)
            .joinToString("; ")
        return snapshot
    }
}

private val SharedPiExtensionInteractiveUiMethods = setOf(
    "pi_extension_select",
    "pi_extension_confirm",
    "pi_extension_input",
)

internal fun parseSharedArixExtensionSnapshot(
    json: JsonObject?,
): SharedArixExtensionSnapshot {
    if (json == null) return SharedArixExtensionSnapshot()
    return SharedArixExtensionSnapshot(
        apiVersion = json.int("api_version") ?: 2,
        version = json.long("version") ?: 0,
        extensions = json.objects("extensions").map { item ->
            SharedArixExtensionInfo(
                id = item.string("id"),
                name = item.string("name"),
                path = item.string("path"),
            )
        },
        surfaces = json.objects("surfaces").map { item ->
            SharedArixExtensionSurface(
                id = item.string("id"),
                extensionId = item.string("extension_id"),
                extensionName = item.string("extension_name"),
                slot = item.string("slot"),
                order = item.int("order") ?: 0,
                tree = item["tree"],
            )
        },
        components = json.objects("components").map { item ->
            SharedArixExtensionComponent(
                id = item.string("id"),
                extensionId = item.string("extension_id"),
                extensionName = item.string("extension_name"),
                target = item.string("target"),
                mode = item.string("mode").ifBlank { "wrap" },
                order = item.int("order") ?: 0,
                tree = item["tree"],
            )
        },
        composerMenuItems = json.objects("composer_menu_items").map { item ->
            SharedArixExtensionComposerMenuItem(
                id = item.string("id"),
                localId = item.string("local_id"),
                extensionId = item.string("extension_id"),
                extensionName = item.string("extension_name"),
                title = item.string("title"),
                subtitle = item.string("subtitle"),
                icon = item.string("icon").ifBlank { "extension" },
                order = item.int("order") ?: 0,
                action = item.string("action"),
                args = item["args"] as? JsonObject ?: JsonObject(emptyMap()),
                selected = item.boolean("selected"),
            )
        },
        settings = json.objects("settings").map { item ->
            SharedArixExtensionSettingsPage(
                id = item.string("id"),
                localId = item.string("local_id"),
                extensionId = item.string("extension_id"),
                extensionName = item.string("extension_name"),
                title = item.string("title"),
                subtitle = item.string("subtitle"),
                icon = item.string("icon").ifBlank { "settings" },
                order = item.int("order") ?: 0,
                trailingIcon = item.string("trailing_icon").ifBlank { item.string("trailingIcon") },
                trailingAction = item.string("trailing_action").ifBlank { item.string("trailingAction") },
                trailingCategory = item.string("trailing_category").ifBlank { item.string("trailingCategory") },
                trailingArgs = item["trailing_args"] as? JsonObject
                    ?: item["trailingArgs"] as? JsonObject ?: JsonObject(emptyMap()),
                sections = item.objects("sections"),
                categories = item.objects("categories").map { category ->
                    SharedArixExtensionSettingsCategory(
                        id = category.string("id"),
                        title = category.string("title"),
                        subtitle = category.string("subtitle"),
                        icon = category.string("icon").ifBlank { "settings" },
                        order = category.int("order") ?: 0,
                        trailingIcon = category.string("trailing_icon").ifBlank { category.string("trailingIcon") },
                        trailingAction = category.string("trailing_action").ifBlank { category.string("trailingAction") },
                        trailingCategory = category.string("trailing_category").ifBlank { category.string("trailingCategory") },
                        trailingArgs = category["trailing_args"] as? JsonObject
                            ?: category["trailingArgs"] as? JsonObject ?: JsonObject(emptyMap()),
                        hidden = category["hidden"]?.jsonPrimitive?.booleanOrNull ?: false,
                        sections = category.objects("sections"),
                    )
                }.sortedWith(compareBy<SharedArixExtensionSettingsCategory> { it.order }.thenBy { it.id }),
            )
        },
        messageTypes = json.objects("message_types").map { item ->
            SharedArixExtensionMessageType(
                id = item.string("id"),
                type = item.string("type"),
                extensionId = item.string("extension_id"),
                extensionName = item.string("extension_name"),
                title = item.string("title"),
                icon = item.string("icon").ifBlank { "extension" },
            )
        },
        customMessages = json.objects("custom_messages").map { item ->
            SharedArixExtensionCustomMessage(
                id = item.string("id"),
                type = item.string("type"),
                extensionId = item.string("extension_id"),
                tree = item["tree"],
            )
        },
        eventNames = (json["event_names"] as? JsonArray)
            .orEmpty()
            .mapNotNull { it.jsonPrimitive.contentOrNull }
            .toSet(),
        errors = json.objects("errors").map { item ->
            SharedArixExtensionError(
                path = item.string("path"),
                extensionId = item.string("extension_id"),
                phase = item.string("phase"),
                message = item.string("error"),
            )
        },
    )
}

private fun JsonObject.string(name: String): String =
    get(name)?.jsonPrimitive?.contentOrNull.orEmpty()

private fun JsonObject.int(name: String): Int? =
    get(name)?.jsonPrimitive?.intOrNull

private fun JsonObject.long(name: String): Long? =
    get(name)?.jsonPrimitive?.longOrNull

private fun JsonObject.boolean(name: String): Boolean =
    get(name)?.jsonPrimitive?.booleanOrNull ?: false

private fun JsonObject.objectOrNull(name: String): JsonObject? = get(name) as? JsonObject

private fun JsonObject.objects(name: String): List<JsonObject> =
    (get(name) as? JsonArray).orEmpty().mapNotNull { it as? JsonObject }
