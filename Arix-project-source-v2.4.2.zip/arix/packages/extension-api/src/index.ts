export type ArixJsonObject = Record<string, unknown>;

export type ArixView =
  | ArixJsonObject
  | ArixView[]
  | string
  | null
  | undefined;

export type ArixRenderContext = ArixJsonObject & {
  extension: {
    id: string;
    name: string;
    path: string;
  };
  storage: ArixJsonObject;
};

export interface ArixSurfaceDefinition {
  id?: string;
  order?: number;
  render?:
    | ArixView
    | ((
      context: ArixRenderContext,
    ) => ArixView | Promise<ArixView>);
  tree?: ArixView;
}

export type ArixSettingType =
  | "text"
  | "password"
  | "textarea"
  | "number"
  | "toggle"
  | "select"
  | "dropdown"
  | "segmented"
  | "tab"
  | "tabs"
  | "slider"
  | "button"
  | "link"
  | "label"
  | "divider"
  | "spacer"
  | "item-card"
  | "card"
  | "empty-state"
  | "choice"
  | "radio"
  | "action-row"
  | "chips"
  | "detail-line"
  | "key-value"
  | "pill"
  | "badge"
  | "result-card"
  | "callout";

export interface ArixSettingOption {
  value: string;
  label: string;
}

export interface ArixSettingActionItem {
  label: string;
  action: string;
  args?: ArixJsonObject;
  category?: string;
  tone?: "primary" | "neutral" | "danger";
  enabled?: boolean;
}

export interface ArixSettingDetailItem {
  label: string;
  value: string;
}

export interface ArixSettingDefinition {
  id: string;
  label?: string;
  title?: string;
  description?: string;
  subtitle?: string;
  tag?: string;
  pill?: string;
  badge?: string;
  type?: ArixSettingType;
  default?: string | number | boolean;
  placeholder?: string;
  options?: ArixSettingOption[];
  min?: number;
  max?: number;
  step?: number;
  action?: string;
  args?: ArixJsonObject;
  category?: string;
  url?: string;
  icon?: string;
  tone?: "primary" | "neutral" | "danger";
  enabled?: boolean;
  checked?: boolean;
  selected?: boolean;
  toggleAction?: string;
  editAction?: string;
  editCategory?: string;
  editArgs?: ArixJsonObject;
  deleteAction?: string;
  deleteArgs?: ArixJsonObject;
  expanded?: boolean;
  actions?: ArixSettingActionItem[];
  details?: ArixSettingDetailItem[];
  resultText?: string;
  result?: string;
  buttonLabel?: string;
  multiline?: boolean;
  secret?: boolean;
  settings?: ArixSettingDefinition[];
}

export interface ArixSettingsSection {
  id?: string;
  title?: string;
  description?: string;
  settings: ArixSettingDefinition[];
}

export interface ArixSettingsDefinition {
  id: string;
  title: string;
  subtitle?: string;
  icon?: string;
  order?: number;
  trailingIcon?: string;
  trailingAction?: string;
  trailingCategory?: string;
  trailingArgs?: ArixJsonObject;
  sections?: ArixSettingsSection[];
  categories?: ArixSettingsCategory[];
}

export interface ArixSettingsCategory {
  id: string;
  title: string;
  subtitle?: string;
  icon?: string;
  order?: number;
  trailingIcon?: string;
  trailingAction?: string;
  trailingCategory?: string;
  trailingArgs?: ArixJsonObject;
  hidden?: boolean;
  sections: ArixSettingsSection[];
}

export interface ArixComposerMenuItemDefinition {
  id: string;
  title: string;
  subtitle?: string;
  icon?: string;
  order?: number;
  action?: string;
  args?: ArixJsonObject;
  selected?: boolean;
}

export interface ArixMessageTypeDefinition {
  type: string;
  title?: string;
  icon?: string;
  render:
    | ArixView
    | ((context: ArixRenderContext & { message: ArixJsonObject }) => ArixView | Promise<ArixView>);
}

export type ArixComponentMode =
  | "before"
  | "after"
  | "replace"
  | "wrap"
  | "hide";

export interface ArixComponentDefinition extends ArixSurfaceDefinition {
  mode?: ArixComponentMode;
}

export interface ArixActionContext extends ArixRenderContext {
  action: string;
}

export interface ArixEventContext extends ArixRenderContext {
  event: string;
}

export interface ArixUi {
  node(
    type: string,
    properties?: ArixJsonObject,
    children?: ArixView[],
  ): ArixJsonObject;
  text(text: string, properties?: ArixJsonObject): ArixJsonObject;
  code(text: string, properties?: ArixJsonObject): ArixJsonObject;
  column(
    children: ArixView[],
    properties?: ArixJsonObject,
  ): ArixJsonObject;
  row(
    children: ArixView[],
    properties?: ArixJsonObject,
  ): ArixJsonObject;
  box(
    children: ArixView[],
    properties?: ArixJsonObject,
  ): ArixJsonObject;
  card(
    children: ArixView[],
    properties?: ArixJsonObject,
  ): ArixJsonObject;
  button(
    label: string,
    action: string,
    properties?: ArixJsonObject,
  ): ArixJsonObject;
  iconButton(
    icon: string,
    action: string,
    properties?: ArixJsonObject,
  ): ArixJsonObject;
  switch(
    label: string,
    checked: boolean,
    action: string,
    properties?: ArixJsonObject,
  ): ArixJsonObject;
  input(
    value: string,
    action: string,
    properties?: ArixJsonObject,
  ): ArixJsonObject;
  spacer(size?: number, properties?: ArixJsonObject): ArixJsonObject;
  progress(value?: number, properties?: ArixJsonObject): ArixJsonObject;
  web(properties: ArixJsonObject): ArixJsonObject;
  core(properties?: ArixJsonObject): ArixJsonObject;
}

export interface ArixExtensionAPI {
  readonly apiVersion: 2;
  readonly extension: {
    id: string;
    name: string;
    path: string;
  };
  readonly ui: ArixUi;
  readonly host: {
    invoke(
      method: string,
      args?: ArixJsonObject,
    ): Promise<ArixJsonObject>;
  };
  readonly services: {
    list(): Promise<ArixJsonObject>;
    describe(service: string): Promise<ArixJsonObject>;
    invoke(
      service: string,
      method: string,
      args?: ArixJsonObject,
    ): Promise<ArixJsonObject>;
  };
  readonly state: {
    get(path?: string): Promise<ArixJsonObject>;
    patch(path: string, value: unknown): Promise<ArixJsonObject>;
    transaction(
      operations: Array<{
        op?: "set" | "remove";
        path: string;
        value?: unknown;
      }>,
    ): Promise<ArixJsonObject>;
  };
  readonly storage: {
    get<T = unknown>(key: string, fallback?: T): T;
    set(key: string, value: unknown): void;
    delete(key: string): void;
    clear(): void;
    snapshot(): ArixJsonObject;
  };
  readonly messages: {
    append(type: string, payload?: ArixJsonObject, text?: string): Promise<ArixJsonObject>;
  };
  registerSurface(
    slot: string,
    definition:
      | ArixSurfaceDefinition
      | ArixView
      | ((
        context: ArixRenderContext,
      ) => ArixView | Promise<ArixView>),
  ): () => void;
  registerComponent(
    target: string,
    definition:
      | ArixComponentDefinition
      | ArixView
      | ((
        context: ArixRenderContext,
      ) => ArixView | Promise<ArixView>),
  ): () => void;
  registerSettings(definition: ArixSettingsDefinition): () => void;
  registerComposerMenuItem(definition: ArixComposerMenuItemDefinition): () => void;
  registerComposerMenu(definition: ArixComposerMenuItemDefinition): () => void;
  registerMessageType(definition: ArixMessageTypeDefinition): () => void;
  registerCustomMessage(definition: ArixMessageTypeDefinition): () => void;
  registerToolTitle(
    toolName: string,
    runningTitle: string,
    completedTitle: string,
    priority?: number,
  ): () => void;
  registerAction(
    id: string,
    handler: (
      payload: ArixJsonObject,
      context: ArixActionContext,
    ) => unknown | Promise<unknown>,
  ): () => void;
  on(
    event: string,
    handler: (
      payload: ArixJsonObject,
      context: ArixEventContext,
    ) => unknown | Promise<unknown>,
  ): () => void;
  intercept(
    operation: string,
    handler: (
      payload: ArixJsonObject,
      context: ArixEventContext,
    ) => unknown | Promise<unknown>,
  ): () => void;
  invalidate(): void;
  notify(message: string, level?: "info" | "warning" | "error"): void;
}

export type ArixExtensionFactory = (
  api: ArixExtensionAPI,
) =>
  | void
  | (() => void | Promise<void>)
  | Promise<void | (() => void | Promise<void>)>;

export declare const ui: ArixUi;

export declare function defineArixExtension<
  T extends ArixExtensionFactory,
>(factory: T): T;
