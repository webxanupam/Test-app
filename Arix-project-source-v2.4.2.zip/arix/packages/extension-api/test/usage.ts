import {
  defineArixExtension,
  ui,
  type ArixExtensionAPI,
} from "@baimoqilin/arix-extension-api";

const factory = defineArixExtension((arix) => {
  arix.registerSurface("chat.composer.top", {
    render: ({ storage }) =>
      ui.card([
        ui.text(String(storage.count ?? 0)),
        ui.button("Increment", "increment"),
      ]),
  });
  arix.registerAction("increment", () => {
    const count = arix.storage.get("count", 0) + 1;
    arix.storage.set("count", count);
  });
  arix.registerSettings({
    id: "preferences",
    title: "Preferences",
    categories: [{ id: "general", title: "General", sections: [{ settings: [{ id: "enabled", label: "Enabled", type: "toggle", default: true }] }] }],
  });
  arix.registerComposerMenuItem({ id: "run", title: "Run", action: "run" });
  arix.registerMessageType({ type: "demo", render: ({ message }) => ui.text(String(message.text ?? "")) });
  arix.registerToolTitle("demo_search", "Searching demos", "Searched demos", 200);
  arix.registerAction("message", () => arix.messages.append("demo", { text: "hello" }));
});

const acceptsApi = (_api: ArixExtensionAPI) => factory;
void acceptsApi;
