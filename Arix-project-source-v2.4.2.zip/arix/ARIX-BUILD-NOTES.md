# Arix — Build & Signing Notes

This project is **Arix**, a rebrand of [Aether](https://github.com/Zhou-Shilin/Aether) (GPL-3.0).
All changes below were applied on top of upstream `c1c446e` (Aether 2.1.5).
It is an **Android-only** fork: all iOS targets, sources, scripts and the
iOS runtime submodule have been removed.

## Identity

| Item | Value |
| --- | --- |
| App name | Arix |
| Application ID (package) | `com.arix.app` |
| Namespace (app module) | `com.arix.app` |
| Namespace (shared module) | `com.arix.app.shared` |
| Root project name | `Arix` |
| Version | 2.2.2 (versionCode 14) |
| Developer | Anupam |
| Website | https://webxanupam.blogspot.com |

## Changes applied to upstream

1. **Rebrand (complete)**: project name, package/namespace (`com.zhousl.aether` /
   `com.baimoqilin.aether` → `com.arix.app`), app label, user-visible strings,
   system prompts, HTTP user agent. A second, exhaustive pass renamed every
   remaining `Aether`/`aether` identifier (classes like `ArixViewModel`,
   internal keys, Termux workspace paths `~/.arix`, the JS bridge module,
   extension script API `arix.*`, compose resources, CI, docs, issue
   templates). Zero `Aether` strings remain inside the APK.
2. **English only**: removed Simplified Chinese and Persian locales
   (`values-zh-rCN`, `values-fa`, Vazirmatn fonts, RTL layout logic,
   non-English `AppLanguage` entries). `resourceConfigurations += "en"`
   strips locale resources from every dependency as well.
3. **Language option removed**: the Settings → General language picker is gone
   (English is the only interface language). The theme picker remains.
4. **About page**: author is **Anupam**, website links to
   https://webxanupam.blogspot.com, the upstream GitHub row was removed, and
   the privacy policy points to the project website.
5. **GitHub update system removed**: deleted `AppUpdateManager` (+ test), the
   in-app update checker / "Check GitHub Releases" settings row / update
   dialog / APK download+install flow, the nightly build type & CI workflow,
   the `UPDATE_CHANNEL` build config field, the `REQUEST_INSTALL_PACKAGES`
   permission, and the unused App-Store lookup service in `shared`.
6. **iOS fully removed**: `iosApp/`, `shared/src/iosMain`, `shared/src/iosTest`,
   the `third_party/ish-arm64` submodule (+ `.gitmodules`), iOS build scripts,
   `iosArm64`/`iosSimulatorArm64` targets, `ktor-client-darwin`, the iOS CI
   job. The `shared` module now targets Android only.
7. **Assistant mode (new)** — Gemini-style quick assistant:
   - `AssistantActivity`: a translucent bottom panel summoned from anywhere.
     Collapsed it shows a capsule pill ("Ask Arix"); tapping expands it into
     a compact chat with the current session, streaming responses, and an
     "Open in Arix" button. It shares the runtime, session engine and
     persisted chat state with the main app, so conversations continue
     seamlessly.
   - **Default assistant**: Settings → Assistant → "Set as default assistant"
     uses `RoleManager.ROLE_ASSISTANT` (Android 10+). When Arix is the default
     assistant, the system corner-swipe / assistant gesture summons the panel.
   - **Quick settings tile** (`ArixTileService`): add "Arix Assistant" from the
     QS panel edit mode; tapping summons the panel from anywhere.
   - **Floating pill** (`ArixOverlayPillService`): a draggable overlay pill
     (SYSTEM_ALERT_WINDOW) that snaps to screen edges. Tap to summon,
     long-press to hide. Toggled in Settings → Assistant.
   - **Overlay permission**: Settings → Assistant → "Display over other apps"
     opens the system overlay-permission screen (also required on MIUI for
     reliable background summoning).
   - **Text selection & share**: selecting text anywhere offers "Arix" in the
     selection menu (ACTION_PROCESS_TEXT); sharing plain text to Arix opens
     the panel pre-filled.
8. **Release signing** (replaces the removed nightly signing):
   `signingConfigs.release` reads `keystore.properties` in the project root.
9. **Size optimizations** (no features removed): R8 minify + resource shrinking
   (inherited from upstream), English-only resource filtering, dependency-info
   blob stripped from the APK, `-repackageclasses ''` +
   `-allowaccessmodification`, release lint gate disabled
   (`checkReleaseBuilds = false`), arm64-v8a only.
10. **v2.1.7 — crash fix + data carry-over**:
    - **Fixed the instant crash on open** introduced in v2.1.6: the new
      mod-service bookkeeping list in `ArixViewModel` was declared *after* the
      `init {}` block that uses it. Kotlin initializes properties in
      declaration order, so the list was still `null` when
      `registerCoreModServices()` appended to it, throwing an
      `NullPointerException` inside the ViewModel constructor for *every*
      launch of MainActivity or AssistantActivity. The list is now declared
      before `init`, and `onCleared` unregisters defensively.
    - **User data survives the v2.1.5 → v2.1.7 update**: v2.1.6's blanket
      rename had also renamed every persisted store file
      (`aether_chat_history.db`, `aether_settings`, `aether_chats`,
      `aether_agent_extensions`, `aether_scheduled_tasks`,
      `aether_pi_extension_state`, `aether_discovered_skills`,
      `aether_native_mods` → `arix_*`), which silently reset settings,
      provider keys and chat history. `LegacyAetherStoreMigrator` now runs
      once at app startup and copies the old files over the new names before
      any store is opened.
    - **Room schema v8** (`Migration7To8`): renames the legacy
      `chat_agent_messageId` column to `arixMessageId` by recreating
      `chat_agent_message_refs` (safe on minSdk 26, whose SQLite lacks
      `ALTER TABLE RENAME COLUMN`). The migration detects which of the two
      historical v7 shapes the database uses, so both v2.1.5 databases and
      databases created by the broken v2.1.6 upgrade cleanly. The historical
      `Migration5To6` SQL was restored to its original column names.
    - Verified with Robolectric startup smoke tests (Application, settings,
      chat state, MainActivity + AssistantActivity composition on a simulated
      API 30 device) plus a real-SQLite migration test: 353 unit tests, 0
      failures.

## v2.4.0 — Provider swaps, File Share tool, MovieBox poster fix, real model downloads

1. **Movies tool — provider 1 replaced** (`ui/ArixToolsUi.kt`, new
   `data/ArixCinemetaClient.kt`): the Watch-Movies web scraper chip is gone
   from the Tools screen (the scraper itself remains available to the in-chat
   agent tools). The new provider 1 "CineHub (Free)" is backed by the public
   Stremio **Cinemeta** catalog API — keyless, CDN-backed catalogs (`top` +
   newest `year` releases), genre chips (Action, Comedy, Horror, Sci-Fi,
   Thriller, Drama, Adventure, Animation), keyword search, and full detail
   metadata. Playback resolves three free embed-player servers per IMDb id
   (vidsrc.to / 2embed.cc / vidsrc.xyz) rendered in the existing hardened
   player WebView — the same architecture as the MovieBox "Web player"
   fallback. Search box placeholder reduced to exactly "search here".
2. **Anime tool — provider 1 replaced** (new `data/ArixAniListClient.kt`,
   `data/ArixAnimeSiteClient.kt`): AnimeLok is no longer provider 1. The new
   provider 1 uses the **AniList GraphQL API** (trending feed, search, episode
   counts, covers, descriptions — extremely stable, no key). Each episode
   resolves its servers by mapping the title to an IMDb id through the
   Cinemeta search catalog (cached per series) and building the same three
   free embed-player URLs; the player sends the embed host's own origin as
   Referer for that source. Anime search box placeholder is now "search here"
   as well.
3. **MovieBox poster bug fixed** (`data/ArixMovieBoxClient.kt`): every live
   WeFeed endpoint now returns `cover` as a JSON *object*
   (`{url, width, height, …}`) in camelCase payloads (`subjectList` /
   `items`). The old string-only read coerced the whole object into a garbage
   "URL" so **every MovieBox poster silently failed and the grid showed
   placeholders**. `parseSubject` now reads the object shape first (with
   string-key fallback), and `findSubjectArray` recognizes the
   `subjectList`/`items` keys explicitly.
4. **New File Share tool** (new `data/ArixFileShareClient.kt`, new
   `ArixFileShareToolScreen` in `ui/ArixToolsUi.kt`): pick any file, upload it
   to a free public host and get a **direct download URL** with Copy / Share
   buttons (tap the link box to copy too). Server chips at the top:
   **Server 1 — Pixeldrain** (anonymous multipart upload, direct
   `?download` link), **Server 2 — Filebin.net** (fresh random bin + PUT,
   6-day retention), **Server 3 — 0x0.st** (multipart, 512 MB cap) and
   **Server 4 — Litterbox** (72 h quick share). Uploads stream from the
   content resolver straight into OkHttp (no full in-memory copies), so large
   files work within ordinary heap limits; per-server failures return
   actionable messages pointing at the other servers.
5. **On-device AI model downloads fixed** (`data/ArixLocalModels.kt`): the
   old catalog shipped dead links — Gemma 3n E2B/E4B pointed at **gated**
   HuggingFace repos (HTTP 401) and the Qwen3 1.7B file name **did not
   exist** (HTTP 404), which is why every download looked broken. The catalog
   now lists verified, anonymously-downloadable LiteRT-LM files with real
   sizes: Gemma 4 E2B (2.5 GB), Gemma 4 E4B (3.5 GB), Qwen3 4B int4/int8,
   Qwen3 1.7B dynamic int4, Qwen3 0.6B — plus an updated download user agent.
6. **Stale test fixed**: `ArixToolExecutorTest` still referenced the removed
   `sanitizeToolOutputForConversation` / `agentModeEnabled` APIs (Agent Mode
   was deleted in v2.3.2), breaking `testReleaseUnitTest`. Rewritten against
   the current API surface. 234 unit tests, 0 failures.
7. Version 2.4.0 (versionCode 25), same signing key as every release since
   v2.2.1 (SHA-256 `b4a16e88…3166b` — in-place upgrade over v2.3.x installs).

## v2.2.9 — Premium bottom navigation + Tools hub, MovieBox API, built-in skills, MCP/subagent/accessibility fixes, Alpine ADB

1. **Premium bottom navigation + Tools hub** (`ui/ArixBottomNavBar.kt`, `ui/ArixToolsUi.kt`):
   - `AppScreen` gains `Tools`, `Terminal`, `Browser` tabs. A floating icon-only
     pill bar (Home / Tools / Terminal / Browser, no labels, violet active glow,
     hides while the IME is open) overlays the four main tab screens; the chat
     composer reserves bottom padding so it never slides under the bar.
   - Terminal opens the Alpine shell full-screen; Browser opens the agent-mode
     Chromium (noVNC) desktop — both one tap from anywhere in the app.
   - New Tools hub with premium dark cards (icon + title + description):
     **Watch Movies & Series**, **QR Code Generator**, **Watch Anime**.
2. **Movie Explorer + QR + Anime removed from `extensions/`**: the three bundled
   TypeScript extensions are gone (their powers now live in the native Tools
   screens and in-chat widgets). `PiExtensionState` prunes their stale entries
   via a versioned defaults migration (v2).
3. **Watch Movies & Series tool**: dual provider — (a) the watch-movies.com.pk
   scraper (direct-first fetch with the 15 public CORS proxies as validated
   fallback, multi-server player, download links) and (b) a native Kotlin port
   of the MovieBox / WeFeed H5 BFF client (`data/ArixMovieBoxClient.kt`):
   token bootstrap via `home` + `x-user` refresh, search, trending with
   pagination, details with seasons/episodes, recommendations, play streams,
   subtitle selection and download links — mapped onto the multi-server player.
4. **QR Code Generator tool**: on-device encoder with qrserver + quickchart
   free-API fallbacks, payload templates (Link / Wi-Fi / Email / Phone), and
   Download (MediaStore) + Share (FileProvider) actions.
5. **Watch Anime tool**: provider switcher with generic names (Provider 1 /
   Provider 2 — no site names in the UI), latest + search, episode strip and
   the multi-server player via per-provider scrapers
   (`ArixAnimeSiteClient.latestFrom/searchFrom`).
6. **Built-in agent skills** (`data/ArixBuiltInSkills.kt`): Email, Web
   Research, Code Review, Document Writer, Translator, Device Control install
   on first launch through the standard skill pipeline (`SkillInstallKind.Builtin`),
   with enable/disable toggles, Remove (stays removed — remembered in prefs),
   and one-tap re-add from Settings → Agent Skills → Built-in.
7. **MCP "extension not loaded yet" fixed (root cause)**: bundled extensions
   (web access / MCP / subagents) previously shipped DISABLED by default, so
   the Pi-side MCP extension never ran and every connect/reconnect died. They
   now ship enabled, stale v1 default snapshots migrate once, `withBridge`
   failures carry an actionable recovery hint, and failed extension actions
   surface as notifications instead of being silently dropped.
8. **Subagent "Create agent definition" fixed**: the action only needs host
   capabilities but was gated behind the Pi bridge guard; it now runs
   bridge-independent and opens chat with the definition prompt pre-filled.
9. **Accessibility status malfunction fixed**: status no longer equals "is a
   service object alive this instant". `ArixAccessibility.isServiceEnabled`
   reads `Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES` (+ manager fallback),
   `onUnbind` keeps the instance across OEM rebind cycles, a new
   `AccessibilityReconnecting` state renders as neutral instead of red, and a
   transient rebind window can no longer stop a running Agent Mode session.
10. **Alpine ADB tools**: new `adb` package profile (`android-tools` → adb +
    fastboot) in Settings → Alpine, plus an optional "Auto-allow debugging
    prompts" switch (auto-enabled on install). When on, the accessibility
    service detects the system "Allow USB debugging?" / wireless debugging
    dialogs and taps Allow automatically — pairing needs zero interaction.
11. **Always-show visual interactions**: new Agent Mode toggle (default on).
    The live visual panel now stays visible while browsing, web searching,
    running system control (opening apps, tapping, typing, swiping) and
    capturing screenshots — including tool rows that previously never surfaced
    the panel (`system_control`, `tavily_search`, `fetch_web_url`).
12. **Bug fixes found in audit**: `androidTestImplementation(libs.androidx.sqlite.bundled)`
    restored so `ChatRepositoryCheckpointInstrumentedTest` compiles again;
    JSONObject-vs-JSONArray mixup fixed in the MovieBox tab parser; APK size
    pass (extra META-INF/about excludes), versionCode 21 / versionName 2.2.9.
    Full build verified: 233 unit tests, 0 failures; androidTest compiles;
    release APK signed with the Arix keystore (~13.8 MB).

## v2.2.5 — Instant native tools (movies + QR), Data & storage settings, system_control tool, Alpine PATH fix

1. **Instant native Movie Explorer + QR Generator (client-side intent router)** —
   the root cause of "raw URLs first, widget minutes later" was the LLM
   round-trip: the model streamed a text answer with URLs, the extension tool
   ran afterwards, and only then did the widget card appear.
   - New `ArixNativeIntent` router matches clear movie/QR commands in
     `ArixViewModel.submitCurrentMessageNow` BEFORE any LLM call ("show latest
     movies", "search movie X", "play movie X", "more movies", "movies page 2",
     "create a qr code for …", "QR code: …").
   - `runNativeToolTurn` appends the user message plus an assistant message
     carrying a running `movie_explorer` / `qr_code` tool invocation, then
     completes it with the same `output_json` widget payload the extension
     emits — so the native widgets render IMMEDIATELY in chat, with zero raw
     URLs, zero LLM latency, and a friendly error message on failure.
   - Conversation-style questions ("what is your favorite movie?") still go to
     the model; the router only fires on imperative commands, and never while
     a turn is running, while editing, or with attachments/skills.
2. **QR codes are now generated 100% on-device** — new pure-Kotlin
   `ArixQrEncoder` (byte mode, ECC M, versions 1–40, penalty-optimal mask)
   plus `ArixQrPng` renderer (Bitmap → PNG, quiet zone). No network, no qr
   APIs, no retries: a code appears in well under a second even offline.
   The encoder was ported from a Python prototype that was verified
   matrix-identical to the reference `qrcode` library across v1–v32 with
   random payloads incl. UTF-8; `ArixQrEncoderTest` bakes four of those
   vectors into the JVM suite (4/4 green).
3. **Movie fetching is now parallel and much faster** — `MovieSiteClient`
   races 5 proxies at a time (3 waves over the shuffled 15) instead of
   sequential 12-second attempts, then falls back to both mirror domains
   direct. Live checks during this build: list + detail pages return 200 with
   the expected postbox / iframe / quality-h2 structure.
4. **Scroll conflict fixed** — the poster grid was a tall static 2-column
   block inside the chat list, so vertical drags scrolled the chat. It is now
   a horizontal `LazyRow` rail (122dp cards) that scrolls sideways
   independently; tap Play resolves servers natively and swaps the rail for
   the multi-server player in place.
5. **QR widget Share button** — `ArixQrShare` shares the PNG through the
   system sheet via FileProvider (`qr-share/` cache path added to
   `file_paths.xml`). Download (MediaStore) and Share both act instantly on
   the locally-generated image.
6. **New `system_control` host tool (always available, no Agent Mode)** —
   native no-root actions for the requests that previously answered "I'm
   unable": `open_settings` (28 named pages), `open_app` (fuzzy label/package
   launch), `list_apps`, `what_on_screen` (accessibility tree read with
   bounds), `global_action` (back/home/recents/notifications/quick settings/
   lock/screenshot), `open_url`, `volume`, `device_info`, `status`. When the
   accessibility service is off the tool returns actionable instructions
   instead of failing. The agent system prompt now tells the model to use
   `system_control` FIRST and never claim it is unable to open apps/settings.
7. **`sh: am: not found` fixed at the root** — Alpine executed commands with
   `/bin/sh -lc` (login shell), and Alpine's `/etc/profile` RESETS PATH,
   dropping `/system/bin`. Every executed command is now prefixed with an
   explicit `export PATH="/system/bin:/system/xbin:…:$PATH"` guard that runs
   after profile sourcing, and the prompt documents absolute paths
   (`/system/bin/am start …`) as a belt-and-braces fallback.
8. **Settings → Data & storage** — new page (hub row under Statistics) that
   counts and deletes QR images the app saved to the system Downloads store
   (MediaStore `qr-code-%` on Android 10+, public Downloads pre-10) and shows
   plus clears the app cache (posters, previews, temp files).
9. Version 2.2.5 (versionCode 17), same signing key as every release since
   v2.2.1 (SHA-256 `b4a16e88…3166b` — in-place upgrade). Tests: ArixQrEncoderTest,
   ArixNativeIntentTest, ArixToolExecutorTest, ConversationUiTest (19),
   ConversationMessagesTest, StartupSmokeTest (6), PiAgentPromptTest,
   RuntimeRouterTest — all green.

## v2.2.4 — Movie fetch rebuilt (proxy-first), native chat widgets, accessibility fix, Alpine system control, new home screen

1. **Movie Explorer network layer rebuilt** — the v2.2.3 chain still led with
   direct requests and URL-ENCODED proxy targets. Live testing proved the
   workers.dev CORS proxies **reject encoded targets (500/502)** and only
   return the movie HTML when the **raw URL** is appended — exactly what the
   reference implementation does. The fetch order is now: shuffled proxies
   (raw URL, 15 mirrors, 6 tried per request) → direct on both mirror
   domains → in-app WebView fallback. Verified live: latest list (24 movies,
   558 ms), `?s=` HTML search ("dunki" → 4 results), and detail pages
   (4 servers + 8 download links). The WP REST API remains a fallback with
   the same proxy-first order. Error messages now enumerate every attempted
   method so failures are diagnosable.
2. **Native in-chat widgets** (the rendering path that cannot break): the
   `qr_code` and `movie_explorer` tools now return a structured
   `output_json` payload with every result, and the conversation renders it
   directly — no extension-runtime round-trip involved:
   - **QR Code card**: the scannable image, payload, kind, provider and size
     with a **Download PNG** button that saves into the system Downloads
     collection (MediaStore on Android 10+).
   - **Movie poster grid**: two-column poster grid with a Play button on
     every poster; tapping Play resolves the movie's servers **natively**
     (`MovieSiteClient`, same proxy strategy in Kotlin) and swaps the grid
     for the multi-server player — instant playback with no agent
     round-trip — with a back button to return to the grid.
   - **Movie player**: title, description, server chips, a 16:9 embedded
     WebView stage with autoplay enabled, and the download links (opened
     externally).
   - The tools no longer mirror results through `app.appendCustomMessage`
     (removed to avoid double cards); the custom-message path remains
     available for the QR composer item and quick-generate settings page.
3. **Accessibility service fixed** — the real reason Agent Mode "didn't
   work after enabling": the service was declared `android:exported="false"`,
   which prevents the OS from ever binding it, so the toggle appeared on
   but the service never connected. Now `exported="true"` (still safe: only
   the OS can bind via the signature-level BIND_ACCESSIBILITY_SERVICE
   permission).
4. **Alpine system control (no root)**: the Alpine runtime now bind-mounts
   `/system` into the proot namespace and exports the Android runtime env
   (`ANDROID_ROOT`, `/system/bin` on PATH), so the agent's shell can run
   `am start` (launch apps / open links), `pm list packages`, `settings
   get/put` (respecting the WRITE_SETTINGS grant) and read `dumpsys`
   reports directly. The agent system prompt documents this split: shell
   for launching/settings/inspection, `agent_mode` for screen interaction.
5. **Home screen refresh** (per the reference mock): a violet-glow avatar
   with the sparkle mark above the greeting, quick-start chips (Ask
   anything / Summarize / Analyze / Create) that submit their starter
   prompts, and a rotating "TRY SOMETHING NEW" suggestion card that sends
   the shown prompt on tap. The IST typewriter greeting and the existing
   composer are unchanged.
6. Version bumped to 2.2.4 (versionCode 16).

## v2.2.3 — Termux removed, no-root Agent Mode, chat widgets & extension fixes

1. **Termux fully removed** (setup, options, runtime):
   - Settings pages for Termux setup and Root setup progress are gone; the
     runtime is the built-in Alpine VM only. `RuntimeRouter` maps the legacy
     Termux runtime id to Alpine for stored-settings compatibility.
   - `arix_termux_manage` self-management tool, the Termux runtime module,
     Shizuku/root bridge services, and the root setup controller were deleted;
     stale Termux strings were removed or reworded; obsolete tests retired.
   - The bundled `third_party/termux` terminal libraries remain — they render
     the **Alpine** terminal UI and have nothing to do with the removed
     Termux app integration.
2. **No-root Agent Mode (accessibility-based)** — replaces the old
   Termux/Shizuku/virtual-display pipeline with public, user-authorized APIs:
   - `ArixAccessibilityService`: gesture dispatch (tap / long-press / swipe),
     global key actions (back / home / recents / notifications / quick
     settings / lock screen), text entry into the focused field, structured
     screen reading (node tree with bounds / ids / text), element lookup and
     click by text or view id, and full-screen capture on Android 11+ via
     `takeScreenshot` (API-34 three-argument overload, hardware buffer copied
     to a software bitmap).
   - `ArixNotificationListenerService`: read / filter / dismiss notifications
     through the `notifications` action.
   - Direct framework APIs: `AudioManager` volume control, battery / power /
     device info, app listing and launching through Intents, URI opening.
   - `WRITE_SETTINGS` system settings modification (brightness, screen
     timeout, etc. after user grant) and `TelecomManager` call handling
     (place / answer with `ANSWER_PHONE_CALLS`).
   - `AgentModeHudService` (`SYSTEM_ALERT_WINDOW`): floating stop/status HUD
     shown while a session is active.
   - `agent_mode` tool action set: start, stop, status, list_apps, launch,
     open, tap, swipe, key, text, screenshot, read_screen, find_element,
     click_element, notifications, device_info, volume, settings, call, hud.
   - The live virtual-display preview surface was removed; the preview panel
     now shows the latest accessibility screenshot with the animated cursor.
3. **Extension chat widgets** (the missing rendering path — custom messages
   were stored but never displayed):
   - `app.appendCustomMessage` results now flow into the extension runtime
     host context (`custom_messages`), which renders each registered message
     type into a widget tree; the chat renders those trees inline (QR cards,
     movie poster grids, movie players) via the existing extension view
     renderer. Plain text remains as fallback while a tree loads.
   - `ArixAppExtensionSnapshot` parses `custom_messages`; new public
     composables `arixExtensionCustomMessageAvailable` /
     `ArixExtensionCustomMessageView` render them in the message list.
4. **QR Code Generator fixed**: the QR image now really appears in chat as a
   card. New **Download PNG** button saves the image into the system
   Downloads store via the new `app.saveMediaToDownloads` host method
   (MediaStore on Android 10+, legacy Downloads dir below). Generated PNGs
   are stored in the private `~/.arix/qr-codes` folder and the settings page
   gained a **Clean saved QR codes** action (plus a count refresh) so stored
   generated images can be wiped in one tap. The tool no longer claims a
   workspace path it cannot show.
5. **Movie Explorer fixed**: the source site now serves Cloudflare bot
   challenges to every non-browser TLS client (plain `fetch` receives 403
   regardless of headers — verified live). The fetch chain was rebuilt:
   - Direct requests try **both** domains (`watchonlinemovies` first, then
     `watch-movies`) with full browser request headers.
   - New **WebView fetch fallback**: a real in-app Chromium WebView
     (`WebViewFetcher`) loads the site origin, clears any challenge, and runs
     a same-origin `fetch()` inside the page — the exact engine that already
     plays the movie embeds. Exposed to extensions as `app.webFetch`; the
     movie extension installs it automatically.
   - Public CORS proxies remain the last resort; failures now report every
     attempted method instead of a bare "WP API failed".
6. **Home screen polish**: the composer input field gained a 1dp
   `ArixOutlineSoft` border (plus focus-state emphasis) and the IST greeting
   no longer shows the time/date clock line — just the greeting, the
   typewriter reveal, and "What can I help with?".
7. **Housekeeping**: unnecessary README files removed (examples, packages,
   bundled extensions — only the root README and build notes remain); unused
   root/Termux onboarding strings deleted; `Schedule` icon import cleaned up.
8. Version bumped to 2.2.3 (versionCode 15).

## v2.2.2 — Premium dark theme refresh + new logo

1. **Provider subscription authorization (investigated, left unchanged)**:
   Google Gemini was evaluated for the "Use a subscription" (OAuth sign-in)
   list in provider settings. The runtime provider catalog
   (`@earendil-works/pi-ai` 0.84.1, verified from the published package)
   implements Google **API-key auth only** — no OAuth flow exists for the
   `google` provider (only Anthropic, GitHub Copilot, OpenAI Codex, Kimi
   Coding, OpenRouter, xAI and Radius have OAuth). Enabling OAuth for Gemini
   would fail at runtime ("Pi provider google does not support OAuth"), so
   Gemini remains in the Recommended list with its supported API-key flow
   and was **not** added to subscription authorization.
2. **Premium dark palette refresh** (`shared/.../ui/theme/Color.kt`, dark
   palette only — the app is permanently dark):
   - Background deepened from `#151619` to a rich OLED-friendly charcoal
     `#0E0F13` with a subtle blue-violet undertone; the home gradient top is
     `#15171D`.
   - Surface elevation ladder retuned (`#171A1F` / `#1F2228` / `#272B32` /
     `#2F343C`) so cards, sheets and chips read as gentle lifts off the base.
   - Sidebar, settings background, outlines and dividers re-tuned to match;
     message bubble deepened to a richer violet `#2F2455`.
   - All UI reads these tokens, so the refresh applies app-wide without
     touching screens individually.
3. **Premium accents**: the home greeting headline now renders with a soft
   violet-to-white vertical gradient brush (readable on the deep background);
   the composer send/pause buttons use a refined violet gradient
   (`#9D6BFF → #6E3FE8`) instead of the flat purple.
4. **New logo (same design language, new colors)**: the Arix mark keeps the
   exact original geometry (verified: alpha channel bit-identical) while the
   colors change from *white circle + pink gradient* to *dark premium tile +
   violet gradient*:
   - Circle background: subtle dark tile gradient `#262733 → #121319`.
   - Blob: hue-shifted −60° (pink → violet) preserving the original
     lightness curve — `#D3B0FF` at the top to `#A341FF` at the bottom — now
     matching the app's violet accent family.
   - Glyph: warm white `#F5F4F0`. Blend pixels were alpha-unmixed so no
     halo artifacts remain (verified programmatically).
   - Replaced in all three locations: `app/src/main/res/drawable-nodpi/`,
     `shared/.../composeResources/drawable/`, `public/`.
   - Adaptive-icon background updated `#FFFFFF → #121319` so the launcher
     icon is a seamless dark tile with the floating violet mark.
5. Version bumped to 2.2.2 (versionCode 14).

## v2.2.1 — IST time-based home greeting

1. **New greeting header on the home (new-chat) screen**, computed from Indian
   Standard Time (`Asia/Kolkata`) regardless of device timezone:
   - `4:00–5:59` → "Good early morning, Sir"; `6:00–11:59` → "Good morning,
     Sir"; `12:00–16:59` → "Good afternoon, Sir"; `17:00–19:59` → "Good
     evening, Sir"; `20:00–23:59` and `0:00–3:59` → "Good night, Sir".
   - Below the greeting a live clock line shows the current IST date/time
     ("Mon, 29 Aug · 9:41 AM IST") with a schedule icon, refreshed every
     20 seconds.
2. **Onboarding-style typewriter animation**: the greeting reveals word by
   word using the same reveal-unit engine as the onboarding
   `StreamingStepMessage` (word/word+space units, 96–240 ms per unit, 180 ms
   on punctuation, instant when Reduce Motion is on). The animation keys on
   the greeting phrase only, so the ticking clock never restarts it.
3. **Hides when chatting starts**: the greeting block fades out when the
   composer is focused, and the whole empty state (greeting + clock + welcome
   line) disappears as soon as the conversation has messages — the message
   list replaces it.
4. Implementation: `IstGreetingHeader` / `GreetingRevealText` /
   `rememberIstNow` in app `ConversationUi.kt`, rendered from the live
   `ConversationScreen` empty branch (below the chat-empty extension slot);
   five new `greeting_*` strings in shared resources. Note: the upstream
   `ConversationEmptyState` (ConversationUi.kt) and `EmptyChatState`
   (ArixApp.kt, preview-only) composables are unreachable dead code that R8
   strips — the greeting intentionally attaches to the code path that
   actually renders.

## v2.2.0 — Dark-only theme + Movie Explorer & QR Code Generator

1. **Theme picker removed; the app is permanently dark themed**:
   - The Settings → General page (which contained only the theme selector)
     was removed from the settings hub, along with `GeneralSettingsPageV2`,
     the `SettingsPage.General` route, and the `onUpdateThemeMode` /
     `updateAppThemeMode` / `updateThemeMode` plumbing.
   - `AppThemeMode.fromStorage()` now always resolves to `Dark` (existing
     installs that stored `system`/`light` switch over automatically), the
     `AppSettings` default is `Dark`, and `ArixTheme` forces the dark
     palette regardless of the passed mode.
2. **New bundled extension: Movie Explorer** (`extensions/pi-movie-explorer`):
   - Agent tool `movie_explorer` with modes `latest` / `search` / `play`.
   - Latest movies and search via the source site homepage HTML and the
     WordPress JSON search API; playback resolves every embed server
     (Player 1..N) plus download links from the movie page, with the
     WordPress REST API (`/wp-json/wp/v2/posts?slug=…`) and public CORS
     proxies as automatic fallbacks. Note: the `_fields` query parameter
     triggers the site's Cloudflare — the extension never uses it.
   - Rich Arix cards: a poster grid (`movie-list`) where tapping Play opens
     the multi-server player instantly (no agent round-trip), and a
     `movie-player` card with server tabs, a fullscreen embed stage, and a
     download list.
3. **New bundled extension: QR Code Generator** (`extensions/pi-qr-generator`):
   - Agent tool `qr_code` (text/link/Wi-Fi/email payloads) rendered as an
     in-chat QR card and saved into the workspace `qr-codes/` directory.
   - Composer menu item "QR Code" encodes the current draft instantly, and
     Settings → QR Code Generator offers a quick-generate box.
   - Free keyless QR APIs with automatic fallback chain:
     api.qrserver.com (goqr.me) → quickchart.io → qrtag.net.
4. **New `qr` extension icon** mapped to `Icons.Rounded.QrCode2` in both the
   app and shared icon registries.
5. Both new extensions follow the existing preinstalled-extension pattern:
   they ship in the APK under `assets/extensions/` and appear in
   Settings → Extensions, disabled by default until the user enables them
   (existing installs that already have extension state stored will see them
   enabled).

## Using the assistant on MIUI (Android 11)

On MIUI 12.5 (e.g. Poco X2), for the most reliable summoning from anywhere:

1. Settings → Apps → Manage apps → Arix → Autostart: **on** (so the floating
   pill survives).
2. Arix → Other permissions: enable **Display pop-up windows while running in
   the background** (needed by the tile / floating pill to open the panel when
   Arix is in the background).
3. Settings → Assistant → Display over other apps → **Allow**.
4. Settings → Assistant → Set as default assistant → choose **Arix**.
   The bottom-corner assistant gesture now summons Arix.
5. Optionally enable the **Floating pill** toggle and add the **Arix Assistant**
   quick settings tile.

## Signing the release build

The release signing key is included so you can publish follow-up updates of this
same app identity:

- Keystore: `keystore/arix-release.jks`
- Config: `keystore.properties` (loaded by `app/build.gradle.kts`)
- Keystore password: `ArixRelease2026`
- Key alias: `arix`
- Key password: `ArixRelease2026`

> Keep these files private if you plan to distribute the app. Anyone holding the
> keystore can sign updates that install over your users' copies.

## Building the APK

Requirements: JDK 17+, Android SDK (platform 36, build-tools 36), Node.js 22+.

```bash
./gradlew :app:assembleRelease
# → app/build/outputs/apk/release/app-release.apk
```

The build automatically runs `npm install` + `npm run build` inside `pi-bridge/`
and bundles `bridge.mjs`, the preinstalled extensions, and the Alpine runtime
assets into the APK.
