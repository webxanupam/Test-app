package com.arix.app.ui

import android.content.Context
import com.arix.app.ArixApplication
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.SystemClock
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.shrinkVertically
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.FastOutLinearInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.MutableTransitionState
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.animateIntOffsetAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.keyframes
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.ScrollState
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.KeyboardArrowLeft
import androidx.compose.material.icons.automirrored.rounded.KeyboardArrowRight
import androidx.compose.material.icons.automirrored.rounded.ArrowForwardIos
import androidx.compose.material.icons.automirrored.rounded.OpenInNew
import androidx.compose.material.icons.rounded.AttachFile
import androidx.compose.material.icons.rounded.Build
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.Description
import androidx.compose.material.icons.rounded.Download
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.Language
import androidx.compose.material.icons.rounded.Image
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.Terminal
import androidx.compose.material3.Icon
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.PopupPositionProvider
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.ui.window.Popup
import androidx.compose.ui.window.PopupProperties
import com.arix.app.R
import com.arix.app.ui.theme.ArixMessageBubble
import com.arix.app.ui.theme.ArixError
import com.arix.app.ui.theme.ArixOnPrimaryContainer
import com.arix.app.ui.theme.ArixOnSurface
import com.arix.app.ui.theme.ArixOnSurfaceVariant
import com.arix.app.ui.theme.ArixOutlineSoft
import com.arix.app.ui.theme.ArixPrimary
import com.arix.app.ui.theme.ArixScrim
import com.arix.app.ui.theme.ArixSecondary
import com.arix.app.ui.theme.ArixSurface
import com.arix.app.platform.LocalReduceMotion
import com.arix.app.ui.theme.ArixSurfaceHigh
import com.arix.app.ui.theme.ArixTertiary

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.IDN
import java.net.URI
import java.net.URL
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Base64
import java.util.Locale
import kotlin.math.roundToInt
import kotlin.math.max

private const val ToolInvocationCollapseThreshold = 3
private const val ToolTransitionDurationMillis = 360
private const val ToolInvocationAutoExpandDelayMillis = 1_000L
private const val ToolGroupCollapseStageDelayMillis = 180L
private const val StreamingChunkFadeDurationMillis = 400
private const val StreamingInitialChunkFadeDurationMillis = 600
private const val StreamingCjkChunkLength = 1
private const val StreamingFallbackChunkLength = 18
private const val FaviconFetchTimeoutMillis = 3_000
private const val MinimumEpochMillis = 946_684_800_000L
private const val TavilyFallbackDomain = "tavily.com"
private const val DefaultFaviconUserAgent =
    "Mozilla/5.0 (Linux; Android 15) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0 Mobile Safari/537.36"
private val ToolTransitionEasing = CubicBezierEasing(0.22f, 0.84f, 0.18f, 1f)
private val ToolGroupIndent = 14.dp
private val TimelineGlyphWidth = 22.dp
private val TimelineIconSize = 18.dp
private val TimelineLineWidth = 2.dp
private val TimelineLineTopGap = 9.dp
private val TimelineLineBottomGap = 0.dp
private val MessageTimestampFormatter = DateTimeFormatter.ofPattern("MMMM d, h:mm a", Locale.US)

@Composable
fun ConversationMessageBubble(
    message: ChatMessage,
    actionsEnabled: Boolean,
    workspaceDirectory: String?,
    allowRootImageRead: Boolean = false,
    onOpenAttachment: (ChatAttachment) -> Unit,
    onOpenLink: (String) -> Unit,
    onEdit: () -> Unit,
    onDelete: () -> Unit,
    onCopy: () -> Unit,
    onRedo: () -> Unit,
    onRetry: () -> Unit,
    onSwitchBranch: (Int) -> Unit,
    sessionTotalTokens: Long? = null,
) {
    if (message.author == MessageAuthor.User) {
        UserMessageBlock(
            message = message,
            onOpenAttachment = onOpenAttachment,
            onEdit = onEdit,
            onCopy = onCopy,
            onRetry = onRetry,
            onSwitchBranch = onSwitchBranch,
        )
    } else {
        AssistantMessageBlock(
            message = message,
            actionsEnabled = actionsEnabled,
            showActions = !message.assistantActionsHidden,
            workspaceDirectory = workspaceDirectory,
            allowRootImageRead = allowRootImageRead,
            onOpenAttachment = onOpenAttachment,
            onOpenLink = onOpenLink,
            onCopy = onCopy,
            onRedo = onRedo,
            onDelete = onDelete,
            sessionTotalTokens = sessionTotalTokens,
        )
    }
}

@Composable
fun SurfaceNotice(
    title: String,
    subtitle: String,
    actionLabel: String,
    onAction: () -> Unit,
    actionEnabled: Boolean,
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .shadow(12.dp, RoundedCornerShape(24.dp), ambientColor = ArixScrim, spotColor = ArixScrim)
            .clip(RoundedCornerShape(24.dp))
            .background(ArixSurface.copy(alpha = 0.96f))
            .padding(horizontal = 16.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.labelLarge, color = ArixOnSurface)
            Text(subtitle, style = MaterialTheme.typography.bodySmall, color = ArixOnSurfaceVariant)
        }
        ActionIconLabel(
            icon = Icons.Rounded.Close,
            label = actionLabel,
            enabled = actionEnabled,
            onClick = onAction,
        )
    }
}


@Composable
fun ComposerAttachmentTray(
    attachments: List<ChatAttachment>,
    onRemoveAttachment: (String) -> Unit,
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .shadow(10.dp, RoundedCornerShape(24.dp), ambientColor = ArixScrim, spotColor = ArixScrim)
            .clip(RoundedCornerShape(24.dp))
            .background(ArixSurface.copy(alpha = 0.96f))
            .padding(10.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        attachments.forEach { attachment ->
            if (attachment.kind == AttachmentKind.Image) {
                ComposerImageAttachmentCard(attachment = attachment, onRemove = { onRemoveAttachment(attachment.id) })
            } else {
                ComposerFileAttachmentCard(attachment = attachment, onRemove = { onRemoveAttachment(attachment.id) })
            }
        }
    }
}

@Composable
private fun UserMessageBlock(
    message: ChatMessage,
    onOpenAttachment: (ChatAttachment) -> Unit,
    onEdit: () -> Unit,
    onCopy: () -> Unit,
    onRetry: () -> Unit,
    onSwitchBranch: (Int) -> Unit,
) {
    var menuExpanded by remember { mutableStateOf(false) }
    var selectTextExpanded by remember { mutableStateOf(false) }
    val branchNavigation = message.branchNavigation()

    Column(
        modifier = Modifier.fillMaxWidth(),
        horizontalAlignment = Alignment.End,
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        BoxWithConstraints {
            val userBubbleMaxWidth = (maxWidth * 0.72f).coerceIn(300.dp, 520.dp)
            Column(
                horizontalAlignment = Alignment.End,
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                UserAttachments(message.attachments, onOpenAttachment)
                if (message.text.isNotBlank()) {
                    UserTextBubble(
                        text = message.text,
                        maxWidth = userBubbleMaxWidth,
                        onLongPress = { menuExpanded = true },
                    )
                }
                if (branchNavigation != null) {
                    UserMessageBranchSwitcher(
                        navigation = branchNavigation,
                        onPrevious = { onSwitchBranch(-1) },
                        onNext = { onSwitchBranch(1) },
                    )
                }
            }

            UserMessageActionDialog(
                expanded = menuExpanded,
                onDismissRequest = { menuExpanded = false },
                timestamp = formatMessageTimestamp(message.createdAtMillis),
                onCopy = {
                    menuExpanded = false
                    onCopy()
                },
                onSelectText = {
                    menuExpanded = false
                    selectTextExpanded = true
                },
                onEdit = {
                    menuExpanded = false
                    onEdit()
                },
                onRetry = {
                    menuExpanded = false
                    onRetry()
                },
            )

            SelectUserMessageTextDialog(
                expanded = selectTextExpanded,
                text = message.text,
                onDismissRequest = { selectTextExpanded = false },
            )
        }
    }
}

@Composable
private fun UserMessageActionDialog(
    expanded: Boolean,
    timestamp: String,
    onDismissRequest: () -> Unit,
    onCopy: () -> Unit,
    onSelectText: () -> Unit,
    onEdit: () -> Unit,
    onRetry: () -> Unit,
) {
    val menuVisibility = remember { MutableTransitionState(false) }
    menuVisibility.targetState = expanded
    if (!menuVisibility.currentState && !menuVisibility.targetState) return

    val density = LocalDensity.current
    val popupOffset = with(density) {
        IntOffset(x = 0, y = 30.dp.roundToPx())
    }

    Popup(
        alignment = Alignment.TopEnd,
        offset = popupOffset,
        onDismissRequest = onDismissRequest,
        properties = PopupProperties(
            focusable = true,
            dismissOnBackPress = true,
            dismissOnClickOutside = true,
        ),
    ) {
        AnimatedVisibility(
            visibleState = menuVisibility,
            enter = fadeIn() +
                scaleIn(
                    initialScale = 0.92f,
                    transformOrigin = TransformOrigin(1f, 0f),
                ) +
                slideInVertically(initialOffsetY = { -it / 10 }),
            exit = fadeOut() +
                scaleOut(
                    targetScale = 0.96f,
                    transformOrigin = TransformOrigin(1f, 0f),
                ) +
                slideOutVertically(targetOffsetY = { -it / 12 }),
        ) {
            Column(
                modifier = Modifier
                    .width(228.dp)
                    .shadow(20.dp, RoundedCornerShape(30.dp), ambientColor = ArixScrim, spotColor = ArixScrim)
                    .clip(RoundedCornerShape(30.dp))
                    .background(ArixSurface)
                    .padding(horizontal = 12.dp, vertical = 12.dp),
                verticalArrangement = Arrangement.spacedBy(2.dp),
            ) {
                if (timestamp.isNotBlank()) {
                    Text(
                        text = timestamp,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 8.dp, vertical = 4.dp),
                        style = MaterialTheme.typography.bodyLarge,
                        color = ArixOnSurfaceVariant,
                        textAlign = TextAlign.Center,
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                }
                UserMessageActionRow(
                    icon = Icons.Rounded.ContentCopy,
                    label = stringResource(R.string.common_copy),
                    onClick = onCopy,
                )
                UserMessageActionRow(
                    icon = Icons.Rounded.Description,
                    label = stringResource(R.string.common_select_text),
                    onClick = onSelectText,
                )
                UserMessageActionRow(
                    icon = Icons.Rounded.Edit,
                    label = stringResource(R.string.common_edit_message),
                    onClick = onEdit,
                )
                UserMessageActionRow(
                    icon = Icons.Rounded.Refresh,
                    label = stringResource(R.string.common_retry),
                    onClick = onRetry,
                )
            }
        }
    }
}

@Composable
private fun UserMessageBranchSwitcher(
    navigation: ChatBranchNavigation,
    onPrevious: () -> Unit,
    onNext: () -> Unit,
) {
    Row(
        modifier = Modifier.padding(end = 16.dp),
        horizontalArrangement = Arrangement.spacedBy(10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        BranchStepButton(
            enabled = navigation.canGoPrevious,
            icon = Icons.AutoMirrored.Rounded.KeyboardArrowLeft,
            onClick = onPrevious,
        )
        Text(
            text = "${navigation.selectedIndex + 1}/${navigation.branchCount}",
            style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.SemiBold),
            color = ArixOnSurfaceVariant,
        )
        BranchStepButton(
            enabled = navigation.canGoNext,
            icon = Icons.AutoMirrored.Rounded.KeyboardArrowRight,
            onClick = onNext,
        )
    }
}

@Composable
private fun BranchStepButton(
    enabled: Boolean,
    icon: ImageVector,
    onClick: () -> Unit,
) {
    Box(
        modifier = Modifier
            .size(32.dp)
            .clip(CircleShape)
            .clickable(enabled = enabled, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = if (enabled) ArixOnSurfaceVariant else ArixOnSurfaceVariant.copy(alpha = 0.32f),
            modifier = Modifier.size(30.dp),
        )
    }
}

@Composable
private fun UserMessageActionRow(
    icon: ImageVector,
    label: String,
    onClick: () -> Unit,
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .height(48.dp)
            .clip(RoundedCornerShape(22.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(18.dp),
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = ArixOnSurface,
            modifier = Modifier.size(24.dp),
        )
        Text(
            text = label,
            style = MaterialTheme.typography.bodyLarge,
            color = ArixOnSurface,
        )
    }
}

@Composable
private fun SelectUserMessageTextDialog(
    expanded: Boolean,
    text: String,
    onDismissRequest: () -> Unit,
) {
    if (!expanded) return

    Dialog(
        onDismissRequest = onDismissRequest,
        properties = DialogProperties(usePlatformDefaultWidth = false),
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth(0.9f)
                .widthIn(max = 520.dp)
                .shadow(22.dp, RoundedCornerShape(28.dp), ambientColor = ArixScrim, spotColor = ArixScrim)
                .clip(RoundedCornerShape(28.dp))
                .background(ArixSurface)
                .padding(22.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            Text(
                text = stringResource(R.string.common_select_text),
                style = MaterialTheme.typography.titleMedium,
                color = ArixOnSurface,
            )
            SelectionContainer {
                Text(
                    text = text,
                    style = MaterialTheme.typography.bodyLarge,
                    color = ArixOnSurface,
                )
            }
        }
    }
}

@Composable
private fun UserAttachments(
    attachments: List<ChatAttachment>,
    onOpenAttachment: (ChatAttachment) -> Unit,
) {
    attachments.forEach { attachment ->
        when (attachment.kind) {
            AttachmentKind.Image -> UserImageAttachmentCard(attachment = attachment, onClick = { onOpenAttachment(attachment) })
            AttachmentKind.File -> UserFileAttachmentCard(attachment = attachment, onClick = { onOpenAttachment(attachment) })
        }
    }
}

@Composable
@OptIn(ExperimentalFoundationApi::class)
private fun UserTextBubble(
    text: String,
    maxWidth: Dp,
    onLongPress: () -> Unit,
) {
    Box(
        modifier = Modifier
            .widthIn(max = maxWidth)
            .shadow(10.dp, RoundedCornerShape(24.dp), ambientColor = ArixScrim, spotColor = ArixScrim)
            .clip(RoundedCornerShape(24.dp))
            .background(ArixMessageBubble)
            .combinedClickable(
                onClick = {},
                onLongClick = onLongPress,
            )
            .padding(horizontal = 18.dp, vertical = 14.dp)
    ) {
        Text(
            text = text,
            style = MaterialTheme.typography.bodyLarge,
            color = ArixOnPrimaryContainer,
        )
    }
}

@Composable
private fun AssistantMessageBlock(
    message: ChatMessage,
    actionsEnabled: Boolean,
    showActions: Boolean,
    workspaceDirectory: String?,
    allowRootImageRead: Boolean,
    onOpenAttachment: (ChatAttachment) -> Unit,
    onOpenLink: (String) -> Unit,
    onCopy: () -> Unit,
    onRedo: () -> Unit,
    onDelete: () -> Unit,
    sessionTotalTokens: Long?,
) {
    val shouldFoldWorkBeforeFinalText = message.text.isNotBlank() &&
        (message.reasoningTrace != null ||
            message.thoughtDurationMillis != null ||
            message.toolInvocations.isNotEmpty() ||
            message.attachments.isNotEmpty())
    Column(
        modifier = Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        val context = LocalContext.current
        val replayToolInvocations = message.replayToolInvocations()
        val agentModeFrames = remember(context, replayToolInvocations) {
            buildAgentModeReplayFrames(context, replayToolInvocations)
        }

        val workContent: @Composable () -> Unit = {
            AssistantMessageWorkContent(
                message = message,
                agentModeFrames = agentModeFrames,
                workspaceDirectory = workspaceDirectory,
                allowRootImageRead = allowRootImageRead,
                onOpenAttachment = onOpenAttachment,
                onOpenLink = onOpenLink,
            )
        }
        if (shouldFoldWorkBeforeFinalText) {
            AgentWorkSummaryDisclosure(
                title = formatWorkedSummaryTitle(
                    workDurationMillisForMessages(
                        messages = listOf(message),
                        endAtMillis = message.createdAtMillis,
                    ),
                ),
                stateKey = "message-work-${message.id}",
                content = workContent,
            )
        }
        if (!shouldFoldWorkBeforeFinalText) {
        if (message.reasoningTrace != null) {
            ReasoningTraceStatus(
                trace = message.reasoningTrace,
                onOpenLink = onOpenLink,
            )
        } else {
            message.thoughtDurationMillis?.let { duration ->
                Text(
                    text = stringResource(R.string.chat_thought_for_duration, formatThoughtDuration(duration)),
                    style = MaterialTheme.typography.bodySmall,
                    color = ArixOnSurfaceVariant,
                )
            }
        }
        if (agentModeFrames.isNotEmpty()) {
            AgentModeReplayPanel(
                frames = agentModeFrames,
                stateKey = "agent-mode-replay-${message.id}",
                workspaceDirectory = workspaceDirectory,
                allowRootImageRead = allowRootImageRead,
                onOpenLink = onOpenLink,
            )
        } else if (message.reasoningTrace == null) {
            ToolInvocationList(
                toolInvocations = message.toolInvocations,
                stateKey = "message-tools-${message.id}",
            )
        }
        AssistantAttachments(
            attachments = message.attachments,
            onOpenAttachment = onOpenAttachment,
        )
        }
        if (message.text.isNotBlank()) {
            val customMessageType = message.customExtensionType
            if (
                customMessageType != null &&
                arixExtensionCustomMessageAvailable(message.id)
            ) {
                ArixExtensionCustomMessageView(messageId = message.id)
            } else {
                MarkdownContent(
                    markdown = message.text,
                    workspaceDirectory = workspaceDirectory,
                    allowRootImageRead = allowRootImageRead,
                    onLinkClick = onOpenLink,
                )
            }
        }
        if (message.statusText.isNotBlank()) {
            ReconnectingStatusCard(
                text = message.statusText,
                detail = message.statusDetail,
                modifier = Modifier.padding(top = 6.dp),
            )
        }
        if (showActions) {
            AssistantMessageActions(
                usageStatistics = message.usageStatistics,
                sessionTotalTokens = sessionTotalTokens,
                actionsEnabled = actionsEnabled,
                onCopy = onCopy,
                onRedo = onRedo,
                onDelete = onDelete,
            )
        }
    }
}

@Composable
private fun AssistantMessageWorkContent(
    message: ChatMessage,
    agentModeFrames: List<AgentModeReplayFrame>,
    workspaceDirectory: String?,
    allowRootImageRead: Boolean,
    onOpenAttachment: (ChatAttachment) -> Unit,
    onOpenLink: (String) -> Unit,
) {
    if (message.reasoningTrace != null) {
        ReasoningTraceStatus(
            trace = message.reasoningTrace,
            onOpenLink = onOpenLink,
        )
    } else {
        message.thoughtDurationMillis?.let { duration ->
            Text(
                text = stringResource(R.string.chat_thought_for_duration, formatThoughtDuration(duration)),
                style = MaterialTheme.typography.bodySmall,
                color = ArixOnSurfaceVariant,
            )
        }
    }
    if (agentModeFrames.isNotEmpty()) {
        AgentModeReplayPanel(
            frames = agentModeFrames,
            stateKey = "agent-mode-replay-${message.id}",
            workspaceDirectory = workspaceDirectory,
            allowRootImageRead = allowRootImageRead,
            onOpenLink = onOpenLink,
        )
    } else if (message.reasoningTrace == null) {
        ToolInvocationList(
            toolInvocations = message.toolInvocations,
            stateKey = "message-tools-${message.id}",
        )
    }
    AssistantAttachments(
        attachments = message.attachments,
        onOpenAttachment = onOpenAttachment,
    )
}

@Composable
fun ConversationAssistantGroupBubble(
    messages: List<ChatMessage>,
    actionsEnabled: Boolean,
    workspaceDirectory: String?,
    allowRootImageRead: Boolean = false,
    onOpenAttachment: (ChatAttachment) -> Unit,
    onOpenLink: (String) -> Unit,
    onCopy: () -> Unit,
    onRedo: () -> Unit,
    onDelete: () -> Unit,
    sessionTotalTokens: Long? = null,
) {
    if (messages.isEmpty()) return
    val groupUsageStatistics = messages.lastOrNull { it.usageStatistics != null }?.usageStatistics
    val thoughtDurationMillis = messages.lastOrNull()?.thoughtDurationMillis
    val hasReasoningTrace = messages.any { it.reasoningTrace != null }
    val showActions = messages.none { it.assistantActionsHidden }
    val context = LocalContext.current
    val agentModeReplayTimeline = remember(context, messages) {
        buildAgentModeReplayTimeline(context, messages)
    }
    val groupAgentModeFrames = agentModeReplayTimeline.frames
    val interleavedAgentModeTextIds = agentModeReplayTimeline.interleavedTextMessageIds
    val firstAgentModeMessageIndex = agentModeReplayTimeline.firstFrameMessageIndex
    val finalTextMessageIndex = messages.indexOfLast { message ->
        message.text.isNotBlank() && message.id !in interleavedAgentModeTextIds
    }
    if (groupAgentModeFrames.isNotEmpty()) {
        Column(
            modifier = Modifier.fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            AgentModeReplayPanel(
                frames = groupAgentModeFrames,
                stateKey = "agent-mode-replay-${messages.first().responseGroupId ?: messages.first().id}",
                workspaceDirectory = workspaceDirectory,
                allowRootImageRead = allowRootImageRead,
                onOpenLink = onOpenLink,
            )
            finalTextMessageIndex
                .takeIf { it >= 0 }
                ?.let { messages[it] }
                ?.let { message ->
                    MarkdownContent(
                        markdown = message.text,
                        workspaceDirectory = workspaceDirectory,
                        allowRootImageRead = allowRootImageRead,
                        onLinkClick = onOpenLink,
                    )
                }
            if (showActions) {
                AssistantMessageActions(
                    usageStatistics = groupUsageStatistics,
                    sessionTotalTokens = sessionTotalTokens,
                    actionsEnabled = actionsEnabled,
                    onCopy = onCopy,
                    onRedo = onRedo,
                    onDelete = onDelete,
                )
            }
        }
        return
    }
    val shouldFoldWorkBeforeFinalText = finalTextMessageIndex > 0
    val workMessages = if (shouldFoldWorkBeforeFinalText) {
        messages.take(finalTextMessageIndex)
    } else {
        emptyList()
    }
    val visibleMessages = if (shouldFoldWorkBeforeFinalText) {
        messages.drop(finalTextMessageIndex)
    } else {
        messages
    }
    Column(
        modifier = Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        if (!shouldFoldWorkBeforeFinalText && !hasReasoningTrace) thoughtDurationMillis?.let { duration ->
            Text(
                text = stringResource(R.string.chat_thought_for_duration, formatThoughtDuration(duration)),
                style = MaterialTheme.typography.bodySmall,
                color = ArixOnSurfaceVariant,
            )
        }
        if (shouldFoldWorkBeforeFinalText) {
            AgentWorkSummaryDisclosure(
                title = formatWorkedSummaryTitle(
                    workDurationMillisForMessages(
                        messages = messages,
                        endAtMillis = messages[finalTextMessageIndex].createdAtMillis,
                    ),
                ),
                stateKey = "assistant-work-${messages.first().responseGroupId ?: messages.first().id}",
            ) {
                if (groupAgentModeFrames.isNotEmpty()) {
                    AgentModeReplayPanel(
                        frames = groupAgentModeFrames,
                        stateKey = "agent-mode-replay-${messages.first().responseGroupId ?: messages.first().id}-folded",
                        workspaceDirectory = workspaceDirectory,
                        allowRootImageRead = allowRootImageRead,
                        onOpenLink = onOpenLink,
                    )
                }
                workMessages.forEachIndexed { index, message ->
                    AssistantGroupMessageContent(
                        message = message,
                        groupAgentModeFrames = if (groupAgentModeFrames.isNotEmpty() && index >= firstAgentModeMessageIndex) {
                            groupAgentModeFrames
                        } else {
                            emptyList()
                        },
                        interleavedAgentModeTextIds = interleavedAgentModeTextIds,
                        workspaceDirectory = workspaceDirectory,
                        allowRootImageRead = allowRootImageRead,
                        onOpenAttachment = onOpenAttachment,
                        onOpenLink = onOpenLink,
                    )
                }
            }
        }
        if (!shouldFoldWorkBeforeFinalText && groupAgentModeFrames.isNotEmpty() && firstAgentModeMessageIndex > 0) {
            messages.take(firstAgentModeMessageIndex).forEach { message ->
                AssistantGroupMessageContent(
                    message = message,
                    groupAgentModeFrames = emptyList(),
                    interleavedAgentModeTextIds = emptySet(),
                    workspaceDirectory = workspaceDirectory,
                    allowRootImageRead = allowRootImageRead,
                    onOpenAttachment = onOpenAttachment,
                    onOpenLink = onOpenLink,
                )
            }
        }
        if (!shouldFoldWorkBeforeFinalText && groupAgentModeFrames.isNotEmpty()) {
            AgentModeReplayPanel(
                frames = groupAgentModeFrames,
                stateKey = "agent-mode-replay-${messages.first().responseGroupId ?: messages.first().id}",
                workspaceDirectory = workspaceDirectory,
                allowRootImageRead = allowRootImageRead,
                onOpenLink = onOpenLink,
            )
        }
        messages.forEachIndexed { index, message ->
            if (shouldFoldWorkBeforeFinalText && message !in visibleMessages) {
                return@forEachIndexed
            }
            if (groupAgentModeFrames.isNotEmpty() && index < firstAgentModeMessageIndex) {
                return@forEachIndexed
            }
            AssistantGroupMessageContent(
                message = message,
                groupAgentModeFrames = groupAgentModeFrames,
                interleavedAgentModeTextIds = interleavedAgentModeTextIds,
                workspaceDirectory = workspaceDirectory,
                allowRootImageRead = allowRootImageRead,
                onOpenAttachment = onOpenAttachment,
                onOpenLink = onOpenLink,
            )
        }
        if (showActions) {
            AssistantMessageActions(
                usageStatistics = groupUsageStatistics,
                sessionTotalTokens = sessionTotalTokens,
                actionsEnabled = actionsEnabled,
                onCopy = onCopy,
                onRedo = onRedo,
                onDelete = onDelete,
            )
        }
    }
}

@Composable
private fun AssistantGroupMessageContent(
    message: ChatMessage,
    groupAgentModeFrames: List<AgentModeReplayFrame>,
    interleavedAgentModeTextIds: Set<String>,
    workspaceDirectory: String?,
    allowRootImageRead: Boolean,
    onOpenAttachment: (ChatAttachment) -> Unit,
    onOpenLink: (String) -> Unit,
) {
    val context = LocalContext.current
    val replayToolInvocations = message.replayToolInvocations()
    val agentModeFrames = remember(context, replayToolInvocations) {
        buildAgentModeReplayFrames(context, replayToolInvocations)
    }
    if (message.reasoningTrace != null) {
        ReasoningTraceStatus(
            trace = message.reasoningTrace,
            onOpenLink = onOpenLink,
        )
    } else if (agentModeFrames.isNotEmpty() && groupAgentModeFrames.isEmpty()) {
        AgentModeReplayPanel(
            frames = agentModeFrames,
            stateKey = "agent-mode-replay-${message.id}",
            workspaceDirectory = workspaceDirectory,
            allowRootImageRead = allowRootImageRead,
            onOpenLink = onOpenLink,
        )
    } else {
        val visibleInvocations = if (groupAgentModeFrames.isNotEmpty()) {
            message.toolInvocations.filterNot { it.isAgentModeDisplayInvocation() }
        } else {
            message.toolInvocations
        }
        ToolInvocationList(
            toolInvocations = visibleInvocations,
            stateKey = "message-tools-${message.id}",
        )
    }
    AssistantAttachments(
        attachments = message.attachments,
        onOpenAttachment = onOpenAttachment,
    )
    if (message.text.isNotBlank() && message.id !in interleavedAgentModeTextIds) {
        val customMessageType = message.customExtensionType
        if (
            customMessageType != null &&
            arixExtensionCustomMessageAvailable(message.id)
        ) {
            ArixExtensionCustomMessageView(messageId = message.id)
        } else {
            MarkdownContent(
                markdown = message.text,
                workspaceDirectory = workspaceDirectory,
                allowRootImageRead = allowRootImageRead,
                onLinkClick = onOpenLink,
            )
        }
    }
    if (message.statusText.isNotBlank()) {
        ReconnectingStatusCard(
            text = message.statusText,
            detail = message.statusDetail,
            modifier = Modifier.padding(top = 6.dp),
        )
    }
}

@Composable
private fun AgentModeReplayPanel(
    frames: List<AgentModeReplayFrame>,
    stateKey: String,
    workspaceDirectory: String? = null,
    allowRootImageRead: Boolean = false,
    onOpenLink: (String) -> Unit = {},
) {
    var selectedIndex by rememberSaveable(stateKey, frames.size) {
        mutableStateOf((frames.size - 1).coerceAtLeast(0))
    }
    if (selectedIndex !in frames.indices) {
        selectedIndex = (frames.size - 1).coerceAtLeast(0)
    }
    val frame = frames[selectedIndex]
    val overlayText = frame.overlayText
    val bitmap = remember(frame.previewPath, frame.completedAtUptimeMillis) {
        frame.previewPath
            .takeIf { it.isNotBlank() && File(it).exists() }
            ?.let { BitmapFactory.decodeFile(it) }
    }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .shadow(12.dp, RoundedCornerShape(24.dp), ambientColor = ArixScrim, spotColor = ArixScrim)
            .clip(RoundedCornerShape(24.dp))
            .background(ArixSurface)
            .padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        AgentModeReplayToolStatus(frame = frame)
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(280.dp)
                .clip(RoundedCornerShape(18.dp))
                .background(agentModeReplayBackdropBrush()),
            contentAlignment = Alignment.Center,
        ) {
            var previewSize by remember { mutableStateOf(IntSize.Zero) }
            val density = LocalDensity.current
            val imagePaddingPx = with(density) { 10.dp.toPx() }
            val cursorOffset = remember(
                previewSize,
                frame.width,
                frame.height,
                frame.cursorX,
                frame.cursorY,
            ) {
                resolveAgentModeCursorOffset(
                    previewSize = previewSize,
                    imagePaddingPx = imagePaddingPx,
                    displayWidth = frame.width,
                    displayHeight = frame.height,
                    cursorX = frame.cursorX,
                    cursorY = frame.cursorY,
                )
            }
            val animatedCursorOffset by animateIntOffsetAsState(
                targetValue = cursorOffset,
                animationSpec = tween(durationMillis = 260, easing = ToolTransitionEasing),
                label = "agent_mode_replay_cursor_offset",
            )
            if (bitmap != null) {
                Image(
                    bitmap = bitmap.asImageBitmap(),
                    contentDescription = stringResource(R.string.agent_mode_replay_frame),
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(10.dp)
                        .clip(RoundedCornerShape(14.dp)),
                    contentScale = ContentScale.Fit,
                )
            } else {
                Text(
                    text = stringResource(R.string.agent_mode_replay_preview_unavailable),
                    style = MaterialTheme.typography.bodySmall,
                    color = ArixOnSurfaceVariant,
                )
            }
            Box(
                modifier = Modifier
                    .matchParentSize()
                    .onSizeChanged { previewSize = it },
            ) {
                    AgentModeCursor(
                        modifier = Modifier
                            .offset {
                                val tipInsetPx = with(density) { 5.dp.roundToPx() }
                                IntOffset(animatedCursorOffset.x - tipInsetPx, animatedCursorOffset.y - tipInsetPx)
                            }
                            .size(30.dp),
                    )
                    if (overlayText.isNotBlank()) {
                        val bubbleOffset = remember(
                            cursorOffset,
                            previewSize,
                            density,
                        ) {
                            resolveAgentModeBubbleOffset(
                                cursorOffset = cursorOffset,
                                previewSize = previewSize,
                                density = density,
                            )
                        }
                        val animatedBubbleOffset by animateIntOffsetAsState(
                            targetValue = bubbleOffset,
                            animationSpec = tween(durationMillis = 260, easing = ToolTransitionEasing),
                            label = "agent_mode_replay_bubble_offset",
                        )
                        AgentModeCursorTextBubble(
                            text = overlayText,
                            workspaceDirectory = workspaceDirectory,
                            allowRootImageRead = allowRootImageRead,
                            onOpenLink = onOpenLink,
                            modifier = Modifier.offset { animatedBubbleOffset },
                        )
                    }
            }
        }
        if (frames.size > 1) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                ReplayStepButton(
                    enabled = selectedIndex > 0,
                    reverse = true,
                    onClick = { selectedIndex = (selectedIndex - 1).coerceAtLeast(0) },
                )
                Text(
                    text = "${selectedIndex + 1} / ${frames.size}",
                    modifier = Modifier.padding(horizontal = 14.dp),
                    style = MaterialTheme.typography.labelMedium,
                    color = ArixOnSurfaceVariant,
                )
                ReplayStepButton(
                    enabled = selectedIndex < frames.lastIndex,
                    reverse = false,
                    onClick = { selectedIndex = (selectedIndex + 1).coerceAtMost(frames.lastIndex) },
                )
            }
        }
    }
}

@Composable
private fun AgentModeCursor(
    modifier: Modifier = Modifier,
) {
    Image(
        painter = painterResource(R.drawable.mouse_pointer_2_white_fill),
        contentDescription = null,
        modifier = modifier,
    )
}

@Composable
private fun AgentModeCursorTextBubble(
    text: String,
    workspaceDirectory: String?,
    allowRootImageRead: Boolean,
    onOpenLink: (String) -> Unit,
    modifier: Modifier = Modifier,
) {
    val scrollState = rememberScrollState()
    LaunchedEffect(text, scrollState.maxValue) {
        if (scrollState.maxValue > 0) {
            scrollState.scrollTo(scrollState.maxValue)
        }
    }
    Box(
        modifier = modifier
            .widthIn(max = 320.dp)
            .shadow(18.dp, RoundedCornerShape(12.dp), ambientColor = ArixScrim, spotColor = ArixScrim)
            .clip(RoundedCornerShape(12.dp))
            .background(ArixSurface)
            .padding(horizontal = 14.dp, vertical = 12.dp),
    ) {
        Box(
            modifier = Modifier
                .heightIn(max = 104.dp)
                .verticalScroll(scrollState),
        ) {
            StreamingMarkdownContent(
                markdown = text,
                workspaceDirectory = workspaceDirectory,
                allowRootImageRead = allowRootImageRead,
                onLinkClick = onOpenLink,
            )
        }
    }
}

private fun resolveAgentModeCursorOffset(
    previewSize: IntSize,
    imagePaddingPx: Float,
    displayWidth: Int,
    displayHeight: Int,
    cursorX: Int?,
    cursorY: Int?,
): IntOffset {
    if (previewSize.width <= 0 || previewSize.height <= 0) return IntOffset.Zero
    val contentWidth = (previewSize.width - imagePaddingPx * 2f).coerceAtLeast(1f)
    val contentHeight = (previewSize.height - imagePaddingPx * 2f).coerceAtLeast(1f)
    val sourceWidth = displayWidth.coerceAtLeast(1)
    val sourceHeight = displayHeight.coerceAtLeast(1)
    val scale = minOf(contentWidth / sourceWidth, contentHeight / sourceHeight)
    val renderedWidth = sourceWidth * scale
    val renderedHeight = sourceHeight * scale
    val renderedLeft = imagePaddingPx + (contentWidth - renderedWidth) / 2f
    val renderedTop = imagePaddingPx + (contentHeight - renderedHeight) / 2f
    val cursorFractionX = cursorX?.let { it.toFloat() / sourceWidth } ?: 0.58f
    val cursorFractionY = cursorY?.let { it.toFloat() / sourceHeight } ?: 0.56f
    return IntOffset(
        x = (renderedLeft + renderedWidth * cursorFractionX.coerceIn(0f, 1f)).roundToInt(),
        y = (renderedTop + renderedHeight * cursorFractionY.coerceIn(0f, 1f)).roundToInt(),
    )
}

private fun resolveAgentModeBubbleOffset(
    cursorOffset: IntOffset,
    previewSize: IntSize,
    density: androidx.compose.ui.unit.Density,
): IntOffset {
    val bubbleMaxWidthPx = with(density) { 320.dp.roundToPx() }
    val bubbleMaxHeightPx = with(density) { 128.dp.roundToPx() }
    val horizontalGapPx = with(density) { 34.dp.roundToPx() }
    val verticalGapPx = with(density) { 34.dp.roundToPx() }
    val edgePaddingPx = with(density) { 8.dp.roundToPx() }
    val targetY = if (cursorOffset.y < previewSize.height / 2) {
        cursorOffset.y + verticalGapPx
    } else {
        cursorOffset.y - verticalGapPx - bubbleMaxHeightPx
    }
    return IntOffset(
        x = (cursorOffset.x + horizontalGapPx).coerceIn(
            edgePaddingPx,
            (previewSize.width - bubbleMaxWidthPx - edgePaddingPx).coerceAtLeast(edgePaddingPx),
        ),
        y = targetY.coerceIn(
            edgePaddingPx,
            (previewSize.height - edgePaddingPx).coerceAtLeast(edgePaddingPx),
        ),
    )
}

@Composable
private fun AgentModeReplayToolStatus(
    frame: AgentModeReplayFrame,
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .background(ArixSurfaceHigh)
            .padding(horizontal = 14.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Icon(
            imageVector = LucideIcons.MousePointer2,
            contentDescription = null,
            tint = Color(0xFF5D7CFF),
            modifier = Modifier.size(16.dp),
        )
        Text(
            text = frame.toolTitle,
            modifier = Modifier.weight(1f),
            style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Medium),
            color = ArixOnSurface,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
        )
    }
}

@Composable
private fun ReplayStepButton(
    enabled: Boolean,
    reverse: Boolean,
    onClick: () -> Unit,
) {
    Box(
        modifier = Modifier
            .size(32.dp)
            .clip(CircleShape)
            .background(if (enabled) ArixSurfaceHigh else Color.Transparent)
            .clickable(enabled = enabled, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Icon(
            imageVector = Icons.AutoMirrored.Rounded.ArrowForwardIos,
            contentDescription = null,
            tint = if (enabled) ArixOnSurface else ArixOnSurfaceVariant.copy(alpha = 0.36f),
            modifier = Modifier
                .size(13.dp)
                .graphicsLayer { rotationZ = if (reverse) 180f else 0f },
        )
    }
}

@Composable
fun ToolInvocationList(
    toolInvocations: List<ChatToolInvocation>,
    stateKey: String,
    autoExpand: Boolean = false,
) {
    if (toolInvocations.isEmpty()) return

    if (toolInvocations.size < ToolInvocationCollapseThreshold) {
        ToolInvocationCardsColumn(
            toolInvocations = toolInvocations,
        )
        return
    }

    val isRunning = toolInvocations.any { it.isRunning }
    var headerVisible by rememberSaveable(stateKey) { mutableStateOf(!autoExpand) }
    var expanded by rememberSaveable(stateKey) { mutableStateOf(autoExpand) }
    var lastAutoExpanded by rememberSaveable(stateKey) { mutableStateOf(autoExpand) }
    LaunchedEffect(autoExpand) {
        if (lastAutoExpanded != autoExpand) {
            if (autoExpand) {
                headerVisible = false
                expanded = true
            } else {
                headerVisible = true
                expanded = true
                delay(ToolGroupCollapseStageDelayMillis)
                expanded = false
            }
            lastAutoExpanded = autoExpand
        }
    }
    val childIndent by animateDpAsState(
        targetValue = if (headerVisible) ToolGroupIndent else 0.dp,
        animationSpec = tween(durationMillis = ToolTransitionDurationMillis, easing = ToolTransitionEasing),
        label = "tool_group_indent",
    )
    val arrowRotation by animateFloatAsState(
        targetValue = if (expanded) 90f else 0f,
        animationSpec = tween(durationMillis = ToolTransitionDurationMillis, easing = ToolTransitionEasing),
        label = "tool_group_arrow_rotation",
    )

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(top = 6.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        AnimatedVisibility(
            visible = headerVisible,
            enter = fadeIn(
                animationSpec = tween(
                    durationMillis = ToolTransitionDurationMillis - 100,
                    easing = ToolTransitionEasing,
                ),
            ) + expandVertically(
                animationSpec = tween(durationMillis = ToolTransitionDurationMillis, easing = ToolTransitionEasing),
                expandFrom = Alignment.Top,
            ),
            exit = fadeOut(
                animationSpec = tween(durationMillis = 180, easing = FastOutLinearInEasing),
            ) + shrinkVertically(
                animationSpec = tween(durationMillis = 220, easing = FastOutLinearInEasing),
                shrinkTowards = Alignment.Top,
            ),
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .noRippleClickable { expanded = !expanded },
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                if (isRunning) {
                    ShimmerStatusText(
                        text = stringResource(R.string.tool_invocation_group_executing, toolInvocations.size),
                        modifier = Modifier.weight(1f),
                        travelDurationMillis = 2600,
                        pauseDurationMillis = 1000,
                    )
                } else {
                    Text(
                        text = stringResource(R.string.tool_invocation_group_executed, toolInvocations.size),
                        modifier = Modifier.weight(1f),
                        style = MaterialTheme.typography.bodyMedium,
                        color = ArixOnSurfaceVariant,
                    )
                }
                Icon(
                    imageVector = Icons.AutoMirrored.Rounded.ArrowForwardIos,
                    contentDescription = if (expanded) {
                        stringResource(R.string.tool_invocation_collapse_tools)
                    } else {
                        stringResource(R.string.tool_invocation_expand_tools)
                    },
                    tint = ArixOnSurfaceVariant,
                    modifier = Modifier
                        .size(14.dp)
                        .graphicsLayer { rotationZ = arrowRotation },
                )
            }
        }

        AnimatedVisibility(
            visible = expanded,
            enter = expandVertically(
                animationSpec = tween(durationMillis = ToolTransitionDurationMillis, easing = ToolTransitionEasing),
                expandFrom = Alignment.Top,
            ) + fadeIn(
                animationSpec = tween(
                    durationMillis = ToolTransitionDurationMillis - 90,
                    delayMillis = 40,
                    easing = ToolTransitionEasing,
                ),
            ),
            exit = shrinkVertically(
                animationSpec = tween(durationMillis = 260, easing = FastOutLinearInEasing),
                shrinkTowards = Alignment.Top,
            ) + fadeOut(
                animationSpec = tween(durationMillis = 180, easing = FastOutLinearInEasing),
            ),
        ) {
            ToolInvocationCardsColumn(
                toolInvocations = toolInvocations,
                indent = childIndent,
                topPadding = 4.dp,
            )
        }
    }
}

@Composable
fun AgentWorkSummaryDisclosure(
    title: String,
    stateKey: String,
    modifier: Modifier = Modifier,
    initiallyExpanded: Boolean = false,
    content: @Composable () -> Unit,
) {
    var expanded by rememberSaveable(stateKey) { mutableStateOf(initiallyExpanded) }
    val arrowRotation by animateFloatAsState(
        targetValue = if (expanded) 90f else 0f,
        animationSpec = tween(durationMillis = ToolTransitionDurationMillis, easing = ToolTransitionEasing),
        label = "agent_work_arrow_rotation",
    )

    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(top = 6.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .noRippleClickable { expanded = !expanded },
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            Text(
                text = title,
                modifier = Modifier.weight(1f),
                style = MaterialTheme.typography.bodyMedium,
                color = ArixOnSurfaceVariant,
            )
            Icon(
                imageVector = Icons.AutoMirrored.Rounded.ArrowForwardIos,
                contentDescription = if (expanded) stringResource(R.string.agent_work_collapse) else stringResource(R.string.agent_work_expand),
                tint = ArixOnSurfaceVariant,
                modifier = Modifier
                    .size(14.dp)
                    .graphicsLayer { rotationZ = arrowRotation },
            )
        }

        AnimatedVisibility(
            visible = expanded,
            enter = expandVertically(
                animationSpec = tween(durationMillis = ToolTransitionDurationMillis, easing = ToolTransitionEasing),
                expandFrom = Alignment.Top,
            ) + fadeIn(
                animationSpec = tween(
                    durationMillis = ToolTransitionDurationMillis - 90,
                    delayMillis = 40,
                    easing = ToolTransitionEasing,
                ),
            ),
            exit = shrinkVertically(
                animationSpec = tween(durationMillis = 260, easing = FastOutLinearInEasing),
                shrinkTowards = Alignment.Top,
            ) + fadeOut(
                animationSpec = tween(durationMillis = 180, easing = FastOutLinearInEasing),
            ),
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(start = ToolGroupIndent)
                    .animateContentSize(
                        animationSpec = tween(durationMillis = ToolTransitionDurationMillis, easing = ToolTransitionEasing),
                    ),
                verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                content()
            }
        }
    }
}

@Composable
fun AgentWorkingStatusHeader(
    title: String,
    modifier: Modifier = Modifier,
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(top = 6.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Text(
            text = title,
            style = MaterialTheme.typography.bodyMedium,
            color = ArixOnSurfaceVariant,
        )
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(1.dp)
                .background(ArixOutlineSoft.copy(alpha = 0.62f))
        )
    }
}

@Composable
private fun ToolInvocationCardsColumn(
    toolInvocations: List<ChatToolInvocation>,
    indent: Dp = 0.dp,
    topPadding: Dp = 6.dp,
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(start = indent)
            .animateContentSize(
                animationSpec = tween(durationMillis = ToolTransitionDurationMillis, easing = ToolTransitionEasing),
            ),
        verticalArrangement = Arrangement.spacedBy(0.dp),
    ) {
        toolInvocations.forEach { toolInvocation ->
            ToolInvocationAnimatedCard(
                toolInvocation = toolInvocation,
                topPadding = topPadding,
            )
        }
    }
}

@Composable
private fun ToolInvocationAnimatedCard(
    toolInvocation: ChatToolInvocation,
    topPadding: Dp,
) {
    var visible by rememberSaveable(toolInvocation.id) { mutableStateOf(false) }
    LaunchedEffect(toolInvocation.id) {
        visible = true
    }

    AnimatedVisibility(
        visible = visible,
        enter = expandVertically(
            animationSpec = tween(durationMillis = ToolTransitionDurationMillis, easing = ToolTransitionEasing),
            expandFrom = Alignment.Top,
        ) + fadeIn(
            animationSpec = tween(
                durationMillis = ToolTransitionDurationMillis - 90,
                delayMillis = 30,
                easing = ToolTransitionEasing,
            ),
        ),
    ) {
        ToolInvocationCard(
            toolInvocation = toolInvocation,
            topPadding = topPadding,
        )
    }
}

@Composable
fun PendingAssistantResponseBlock(
    text: String,
    workspaceDirectory: String?,
    allowRootImageRead: Boolean = false,
    onOpenLink: (String) -> Unit,
) {
    Column(
        modifier = Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        StreamingMarkdownContent(
            markdown = text,
            workspaceDirectory = workspaceDirectory,
            allowRootImageRead = allowRootImageRead,
            onLinkClick = onOpenLink,
        )
    }
}

/**
 * v2.6.1: rate-limits the markdown handed to the renderer while streaming.
 * Every token used to trigger a FULL re-parse + re-layout of the answer —
 * on long "latest movies" replies (huge tables + tool widgets) that caused
 * the visible lag and jank on mid-range devices. The sampler coalesces
 * token bursts: it re-renders at most ~10x/sec while streaming fast, keeps
 * the streaming fade behavior, and ALWAYS flushes the final text (the
 * trailing delay is only cancelled by a newer token, never dropped).
 */
@Composable
private fun rememberStreamingMarkdownSample(source: String): String {
    var displayed by remember { mutableStateOf(source) }
    var lastEmitAtMillis by remember { mutableStateOf(0L) }
    LaunchedEffect(source) {
        if (source == displayed) return@LaunchedEffect
        val isAppend = source.startsWith(displayed)
        val sinceEmit = System.currentTimeMillis() - lastEmitAtMillis
        val deltaChars = source.length - displayed.length
        if (!isAppend || sinceEmit >= StreamingMarkdownSampleIntervalMillis ||
            deltaChars >= StreamingMarkdownSampleMinChars
        ) {
            displayed = source
            lastEmitAtMillis = System.currentTimeMillis()
        } else {
            // Trailing flush: only runs when the token burst pauses (or the
            // stream ends) — the next token restarts this effect and cancels
            // the delay, so no update is ever lost, just batched.
            delay(StreamingMarkdownSampleIntervalMillis)
            displayed = source
            lastEmitAtMillis = System.currentTimeMillis()
        }
    }
    return displayed
}

private const val StreamingMarkdownSampleIntervalMillis = 90L
private const val StreamingMarkdownSampleMinChars = 160

@Composable
fun StreamingMarkdownContent(
    markdown: String,
    workspaceDirectory: String?,
    allowRootImageRead: Boolean,
    onLinkClick: (String) -> Unit,
) {
    val markdown = rememberStreamingMarkdownSample(source = markdown)
    var trackedSource by remember { mutableStateOf("") }
    var activeFadeRange by remember { mutableStateOf<IntRange?>(null) }
    var activeFadeDurationMillis by remember { mutableStateOf(StreamingChunkFadeDurationMillis) }
    val fadeProgress = remember { Animatable(1f) }

    LaunchedEffect(markdown) {
        if (markdown.isBlank()) {
            trackedSource = ""
            activeFadeRange = null
            fadeProgress.snapTo(1f)
            return@LaunchedEffect
        }

        if (!markdown.startsWith(trackedSource)) {
            trackedSource = ""
            activeFadeRange = null
            fadeProgress.snapTo(1f)
        }

        val deltaStart = trackedSource.length
        val delta = markdown.removePrefix(trackedSource)
        trackedSource = markdown
        if (delta.isEmpty()) return@LaunchedEffect

        activeFadeRange = deltaStart until markdown.length
        activeFadeDurationMillis = if (deltaStart == 0) {
            StreamingInitialChunkFadeDurationMillis
        } else {
            StreamingChunkFadeDurationMillis
        }
    }

    LaunchedEffect(activeFadeRange, activeFadeDurationMillis) {
        val fadeRange = activeFadeRange ?: return@LaunchedEffect
        if (fadeRange.first > fadeRange.last) {
            fadeProgress.snapTo(1f)
            return@LaunchedEffect
        }

        fadeProgress.snapTo(0f)
        fadeProgress.animateTo(
            targetValue = 1f,
            animationSpec = tween(durationMillis = activeFadeDurationMillis, easing = LinearEasing),
        )
    }

    val streamingFrame = remember(markdown, activeFadeRange, fadeProgress.value) {
        val normalizedFadeRange = activeFadeRange?.let { range ->
            val clampedStart = range.first.coerceIn(0, markdown.length)
            val clampedEndExclusive = (range.last + 1).coerceIn(clampedStart, markdown.length)
            if (clampedEndExclusive <= clampedStart) {
                null
            } else {
                clampedStart until clampedEndExclusive
            }
        }

        StreamingMarkdownFrame(
            markdown = markdown,
            fadeSpan = normalizedFadeRange?.let { range ->
                MarkdownFadeSpan(
                    sourceRange = range,
                    alpha = fadeProgress.value.coerceIn(0f, 1f),
                )
            },
        )
    }

    MarkdownContent(
        markdown = streamingFrame.markdown,
        modifier = Modifier.fillMaxWidth(),
        workspaceDirectory = workspaceDirectory,
        allowRootImageRead = allowRootImageRead,
        onLinkClick = onLinkClick,
        fadeSpan = streamingFrame.fadeSpan,
    )
}

private data class StreamingMarkdownFrame(
    val markdown: String,
    val fadeSpan: MarkdownFadeSpan?,
)

private fun extractStreamingRevealUnits(buffer: String): Pair<List<String>, String> {
    if (buffer.isEmpty()) return emptyList<String>() to ""

    val units = mutableListOf<String>()
    var start = 0
    var index = 0

    while (index < buffer.length) {
        val char = buffer[index]
        val nextChar = buffer.getOrNull(index + 1)
        val tokenLength = index - start + 1

        val shouldSplit = when {
            isStreamingTokenBoundary(char) -> true
            char.isWhitespace() && start < index -> true
            isCjkCharacter(char) && tokenLength >= StreamingCjkChunkLength && nextChar != null && isCjkCharacter(nextChar) -> true
            tokenLength >= StreamingFallbackChunkLength &&
                nextChar != null &&
                !nextChar.isWhitespace() &&
                !isStreamingTokenBoundary(nextChar) -> true
            else -> false
        }

        if (shouldSplit) {
            var end = index + 1
            while (end < buffer.length && buffer[end].isWhitespace() && buffer[end] != '\n') {
                end += 1
            }
            units += buffer.substring(start, end)
            start = end
            index = end
            continue
        }

        index += 1
    }

    return units to buffer.substring(start)
}

private fun isStreamingTokenBoundary(char: Char): Boolean =
    isSentenceBoundary(char) ||
        char == ',' ||
        char == '\uFF0C' ||
        char == '\u3001' ||
        char == ')' ||
        char == ']' ||
        char == '}'

private fun isSentenceBoundary(char: Char): Boolean =
    char == '\n' || char == '.' || char == '!' || char == '?' ||
        char == '。' || char == '！' || char == '？' ||
        char == ';' || char == '；' || char == ':' || char == '：'

private fun isCjkCharacter(char: Char): Boolean {
    val block = Character.UnicodeBlock.of(char)
    return block == Character.UnicodeBlock.CJK_UNIFIED_IDEOGRAPHS ||
        block == Character.UnicodeBlock.CJK_UNIFIED_IDEOGRAPHS_EXTENSION_A ||
        block == Character.UnicodeBlock.CJK_UNIFIED_IDEOGRAPHS_EXTENSION_B ||
        block == Character.UnicodeBlock.CJK_COMPATIBILITY_IDEOGRAPHS ||
        block == Character.UnicodeBlock.HIRAGANA ||
        block == Character.UnicodeBlock.KATAKANA ||
        block == Character.UnicodeBlock.HANGUL_SYLLABLES
}

@Composable
fun ShimmerStatusText(
    text: String,
    modifier: Modifier = Modifier,
    travelDurationMillis: Int = 1800,
    pauseDurationMillis: Int = 1000,
) {
    if (LocalReduceMotion.current) {
        Text(text = text, modifier = modifier, style = MaterialTheme.typography.bodyMedium,
            color = ArixOnSurfaceVariant)
        return
    }
    val travelDistance = (280f + text.length * 18f).coerceIn(280f, 760f)
    val sweepHalfWidth = 180f
    val totalDurationMillis = travelDurationMillis + pauseDurationMillis
    val shimmerOffset by rememberInfiniteTransition(label = "status_shimmer").animateFloat(
        initialValue = -travelDistance,
        targetValue = travelDistance,
        animationSpec = infiniteRepeatable(
            animation = keyframes {
                durationMillis = totalDurationMillis
                travelDistance at travelDurationMillis using LinearEasing
                travelDistance at totalDurationMillis
            },
            repeatMode = RepeatMode.Restart,
        ),
        label = "status_shimmer_offset",
    )
    val shimmerBrush = Brush.linearGradient(
        colors = listOf(
            ArixOnSurfaceVariant.copy(alpha = 0.42f),
            ArixOnSurface.copy(alpha = 0.96f),
            ArixOnSurfaceVariant.copy(alpha = 0.42f),
        ),
        start = Offset(shimmerOffset - sweepHalfWidth, 0f),
        end = Offset(shimmerOffset + sweepHalfWidth, 0f),
    )

    Text(
        text = text,
        style = MaterialTheme.typography.bodyMedium.copy(brush = shimmerBrush),
        modifier = modifier,
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ReasoningTraceStatus(
    trace: ReasoningTrace,
    modifier: Modifier = Modifier,
    onOpenLink: (String) -> Unit = {},
) {
    var sheetVisible by remember(trace.id) { mutableStateOf(false) }
    val latestDetail = remember(trace.latestStatusText, trace.chunks) {
        trace.latestStatusText.ifBlank {
            trace.chunks.lastOrNull { it.detail.isNotBlank() || it.title.isNotBlank() }
            ?.let { chunk -> chunk.detail.ifBlank { chunk.title } }
            .orEmpty()
        }
    }
    val completed = trace.completedAtMillis != null
    val statusText = if (completed) {
        formatReasoningTraceDoneLabel(trace)
    } else {
        latestDetail
    }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(top = 6.dp)
            .noRippleClickable { sheetVisible = true },
        verticalArrangement = Arrangement.spacedBy(4.dp),
    ) {
        when {
            completed -> Text(
                text = statusText,
                style = MaterialTheme.typography.bodyMedium,
                color = ArixOnSurfaceVariant,
            )

            statusText.isNotBlank() -> ReasoningTypewriterText(
                text = statusText,
                styleColor = ArixOnSurfaceVariant,
            )

            else -> ShimmerStatusText(
                text = stringResource(R.string.chat_thinking),
            )
        }
    }

    if (sheetVisible) {
        ModalBottomSheet(
            onDismissRequest = { sheetVisible = false },
            containerColor = ArixSurface,
            contentColor = ArixOnSurface,
            dragHandle = {
                Box(
                    modifier = Modifier
                        .padding(top = 10.dp, bottom = 8.dp)
                        .width(56.dp)
                        .height(5.dp)
                        .clip(RoundedCornerShape(999.dp))
                        .background(ArixOnSurfaceVariant.copy(alpha = 0.16f))
                )
            },
        ) {
            ReasoningTraceSheetContent(
                trace = trace,
                onOpenLink = onOpenLink,
            )
        }
    }
}

@Composable
private fun ReasoningTypewriterText(
    text: String,
    styleColor: Color,
) {
    var rendered by remember(text) { mutableStateOf("") }
    LaunchedEffect(text) {
        if (text.isBlank()) {
            rendered = ""
            return@LaunchedEffect
        }
        if (!text.startsWith(rendered)) {
            rendered = ""
        }
        while (rendered.length < text.length) {
            val nextEnd = (rendered.length + 3).coerceAtMost(text.length)
            rendered = text.substring(0, nextEnd)
            delay(18)
        }
    }
    Text(
        text = rendered.ifBlank { text },
        style = MaterialTheme.typography.bodyMedium,
        color = styleColor,
    )
}

@Composable
private fun ReasoningTraceSheetContent(
    trace: ReasoningTrace,
    onOpenLink: (String) -> Unit,
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .heightIn(max = 640.dp)
            .verticalScroll(rememberScrollState())
            .padding(start = 24.dp, top = 10.dp, end = 24.dp, bottom = 30.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        if (trace.hasTimelineContent || trace.completedAtMillis != null) {
            ReasoningTimeline(
                trace = trace,
                onOpenLink = onOpenLink,
            )
        } else {
            RawReasoningPanel(rawText = trace.rawText)
        }
    }
}

@Composable
private fun RawReasoningPanel(
    rawText: String,
) {
    val waitingForReasoning = stringResource(R.string.chat_waiting_for_reasoning)
    val displayText = remember(rawText, waitingForReasoning) {
        rawText.ifBlank { waitingForReasoning }.let { text ->
            if (text.length <= 12_000) text else text.take(12_000).trimEnd() + "\n..."
        }
    }
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(
            text = stringResource(R.string.chat_raw_reasoning),
            style = MaterialTheme.typography.labelMedium,
            color = ArixOnSurfaceVariant,
        )
        SelectionContainer {
            Text(
                text = displayText,
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(18.dp))
                    .background(ArixSurfaceHigh)
                    .padding(14.dp),
                style = MaterialTheme.typography.bodyMedium,
                color = ArixOnSurfaceVariant,
            )
        }
    }
}

@Composable
private fun ReasoningTimeline(
    trace: ReasoningTrace,
    onOpenLink: (String) -> Unit,
) {
    val timelineItems = remember(trace.chunks, trace.toolInvocations) {
        reasoningTimelineItems(trace)
    }
    val hasDoneChunk = trace.completedAtMillis != null
    val summarizingReasoningTitle = stringResource(R.string.chat_summarizing_reasoning)
    val preparingReasoningSummary = stringResource(R.string.chat_preparing_reasoning_summary)
    Column(verticalArrangement = Arrangement.spacedBy(0.dp)) {
        timelineItems.forEachIndexed { index, item ->
            val isLast = !hasDoneChunk && index == timelineItems.lastIndex
            when (item) {
                is ReasoningTimelineItem.Summary -> ReasoningTimelineRow(
                    title = item.chunk.title.ifBlank { summarizingReasoningTitle },
                    detail = when {
                        item.chunk.detail.isNotBlank() -> item.chunk.detail
                        else -> preparingReasoningSummary
                    },
                    isLast = isLast,
                )

                is ReasoningTimelineItem.Tool -> ReasoningTimelineToolRow(
                    toolInvocation = item.toolInvocation,
                    isLast = isLast,
                    onOpenLink = onOpenLink,
                )
            }
        }
        if (hasDoneChunk) {
            ReasoningTimelineDoneRow(trace = trace)
        }
    }
}

internal sealed interface ReasoningTimelineItem {
    val sortOrder: Long
    val fallbackOrder: Int

    data class Summary(
        val chunk: ReasoningSummaryChunk,
        override val sortOrder: Long,
        override val fallbackOrder: Int,
    ) : ReasoningTimelineItem

    data class Tool(
        val toolInvocation: ChatToolInvocation,
        override val sortOrder: Long,
        override val fallbackOrder: Int,
    ) : ReasoningTimelineItem
}

internal fun reasoningTimelineItems(trace: ReasoningTrace): List<ReasoningTimelineItem> {
    val visibleChunks = trace.chunks.filter {
        it.title.isNotBlank() || it.detail.isNotBlank() || it.isPending || it.rawText.isNotBlank()
    }
    val items = buildList {
        visibleChunks.forEachIndexed { index, chunk ->
            add(
                ReasoningTimelineItem.Summary(
                    chunk = chunk,
                    sortOrder = chunk.timelineOrder
                        .takeIf { it > 0L }
                        ?: chunk.createdAtMillis.takeIf { it > 0L }
                        ?: Long.MAX_VALUE,
                    fallbackOrder = index,
                )
            )
        }
        trace.toolInvocations.forEachIndexed { index, invocation ->
            add(
                ReasoningTimelineItem.Tool(
                    toolInvocation = invocation,
                    sortOrder = invocation.timelineOrder
                        .takeIf { it > 0L }
                        ?: invocation.startedAtMillis.takeIf { it > 0L }
                        ?: Long.MAX_VALUE,
                    fallbackOrder = visibleChunks.size + index,
                )
            )
        }
    }

    return items.sortedWith(
        compareBy<ReasoningTimelineItem> { it.sortOrder }
            .thenBy { it.fallbackOrder }
    )
}

@Composable
private fun ReasoningTimelineRow(
    title: String,
    detail: String,
    isLast: Boolean,
) {
    // v2.6.1 crash fix: these rows previously used height(IntrinsicSize.Min)
    // so the timeline connector line could fill the row height. With large
    // tool results (a fetched movie-list page, for example) the intrinsic
    // height exploded past what Compose's bit-packed Constraints can
    // represent ("Can't represent a width of 0 and height of 263604 in
    // Constraints") and the app crashed. The connector line is now drawn
    // behind the row via drawBehind — no intrinsic measurement at all.
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .reasoningTimelineConnector(isLast = isLast),
        horizontalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        TimelineGlyph(isLast = isLast)
        Column(
            modifier = Modifier
                .weight(1f)
                .padding(bottom = if (isLast) 0.dp else 22.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            Text(
                text = title,
                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Medium),
                color = ArixOnSurface,
            )
            if (detail.isNotBlank()) {
                Text(
                    text = detail,
                    style = MaterialTheme.typography.bodyMedium,
                    color = ArixOnSurfaceVariant,
                )
            }
        }
    }
}

@Composable
private fun ReasoningTimelineToolRow(
    toolInvocation: ChatToolInvocation,
    isLast: Boolean,
    onOpenLink: (String) -> Unit,
) {
    val arguments = remember(toolInvocation.argumentsJson) { parseJsonObject(toolInvocation.argumentsJson) }
    val output = remember(toolInvocation.outputJson) { parseJsonObject(toolInvocation.outputJson) }
    val webSourceMetadata = remember(toolInvocation.toolName, toolInvocation.argumentsJson, toolInvocation.outputJson) {
        webSourceMetadata(toolInvocation.toolName, arguments, output)
    }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .reasoningTimelineConnector(isLast = isLast),
        horizontalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        TimelineGlyph(
            icon = reasoningToolIcon(toolInvocation.toolName),
            isLast = isLast,
        )
        Column(
            modifier = Modifier
                .weight(1f)
                .padding(bottom = if (isLast) 0.dp else 18.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            ToolInvocationCard(
                toolInvocation = toolInvocation,
                topPadding = 0.dp,
            )
            webSourceMetadata?.let { metadata ->
                WebSourcePill(
                    metadata = metadata,
                    onOpenLink = onOpenLink,
                )
            }
        }
    }
}

@Composable
private fun ReasoningTimelineDoneRow(
    trace: ReasoningTrace,
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .reasoningTimelineConnector(isLast = true),
        horizontalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        TimelineGlyph(
            icon = Icons.Rounded.CheckCircle,
            isLast = true,
        )
        Column(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            Text(
                text = formatReasoningTraceDoneChunkTitle(trace),
                style = MaterialTheme.typography.bodyMedium,
                color = ArixOnSurface,
            )
            Text(
                text = stringResource(R.string.common_done),
                style = MaterialTheme.typography.bodyMedium,
                color = ArixOnSurfaceVariant,
            )
        }
    }
}

/**
 * v2.6.1 crash fix: draws the reasoning timeline's vertical connector line
 * BEHIND the row, at the glyph column's horizontal center, spanning from just
 * below the glyph icon down to the row's measured bottom. Replaces the old
 * height(IntrinsicSize.Min) + fillMaxHeight glyph layout whose intrinsic
 * measurement crashed on huge tool results (see ReasoningTimelineRow).
 */
private fun Modifier.reasoningTimelineConnector(isLast: Boolean): Modifier = drawBehind {
    if (isLast) return@drawBehind
    val lineTop = TimelineIconSize.toPx() + TimelineLineTopGap.toPx()
    val lineBottom = size.height - TimelineLineBottomGap.toPx()
    if (lineBottom <= lineTop) return@drawBehind
    val centerX = TimelineGlyphWidth.toPx() / 2f
    val halfStroke = (TimelineLineWidth.toPx() / 2f).coerceAtLeast(0.5f)
    drawRoundRect(
        color = ArixOnSurfaceVariant.copy(alpha = 0.12f),
        topLeft = Offset(centerX - halfStroke, lineTop),
        size = Size(halfStroke * 2f, lineBottom - lineTop),
        cornerRadius = CornerRadius(halfStroke),
    )
}

@Composable
private fun TimelineGlyph(
    icon: ImageVector? = null,
    isLast: Boolean,
) {
    Box(
        modifier = Modifier
            .width(TimelineGlyphWidth),
        contentAlignment = Alignment.TopCenter,
    ) {
        if (icon != null) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = ArixOnSurfaceVariant,
                modifier = Modifier.size(TimelineIconSize),
            )
        } else {
            Box(
                modifier = Modifier
                    .padding(top = 5.dp)
                    .size(8.dp)
                    .clip(CircleShape)
                    .background(ArixOnSurfaceVariant)
            )
        }
    }
}

private fun reasoningToolIcon(toolName: String): ImageVector = when (toolName.lowercase()) {
    "bash" -> Icons.Rounded.Terminal
    "fetch_web_url", "tavily_search" -> Icons.Rounded.Language
    else -> Icons.Rounded.Build
}

@Composable
private fun WebSourcePill(
    metadata: WebSourceMetadata,
    onOpenLink: (String) -> Unit,
) {
    val favicon = rememberRemoteBitmap(metadata.faviconUrl)
    Row(
        modifier = Modifier
            .clip(RoundedCornerShape(999.dp))
            .background(ArixSurfaceHigh.copy(alpha = 0.72f))
            .noRippleClickable { onOpenLink(metadata.url) }
            .padding(start = 10.dp, top = 7.dp, end = 12.dp, bottom = 7.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(7.dp),
    ) {
        if (favicon != null) {
            Image(
                bitmap = favicon,
                contentDescription = null,
                modifier = Modifier
                    .size(16.dp)
                    .clip(CircleShape),
                contentScale = ContentScale.Fit,
            )
        } else {
            Icon(
                imageVector = Icons.Rounded.Language,
                contentDescription = null,
                tint = ArixOnSurfaceVariant,
                modifier = Modifier.size(16.dp),
            )
        }
        Text(
            text = metadata.domain,
            style = MaterialTheme.typography.bodyMedium,
            color = ArixOnSurfaceVariant,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
        )
    }
}

@Composable
private fun rememberRemoteBitmap(
    url: String?,
): ImageBitmap? {
    val bitmap by produceState<ImageBitmap?>(initialValue = null, url) {
        value = withContext(Dispatchers.IO) {
            val sourceUrl = url?.takeIf { it.isNotBlank() } ?: return@withContext null
            runCatching {
                val connection = (URL(sourceUrl).openConnection() as HttpURLConnection).apply {
                    connectTimeout = FaviconFetchTimeoutMillis
                    readTimeout = FaviconFetchTimeoutMillis
                    instanceFollowRedirects = true
                    setRequestProperty("User-Agent", DefaultFaviconUserAgent)
                    setRequestProperty("Accept", "image/avif,image/webp,image/png,image/svg+xml,image/*;q=0.8,*/*;q=0.5")
                }
                connection.inputStream.use { stream ->
                    BitmapFactory.decodeStream(stream)?.asImageBitmap()
                }
            }.getOrNull()
        }
    }
    return bitmap
}

private fun webSourceMetadata(
    toolName: String,
    arguments: JSONObject?,
    output: JSONObject?,
): WebSourceMetadata? = when (toolName.lowercase()) {
    "fetch_web_url" -> {
        val sourceUrl = output?.optString("final_url").orEmpty()
            .ifBlank { output?.optString("request_url").orEmpty() }
            .ifBlank { arguments?.optString("url").orEmpty() }
        webSourceMetadataFromUrl(sourceUrl)
    }
    "tavily_search" -> tavilySourceMetadata(arguments, output)
    else -> null
}

private fun tavilySourceMetadata(
    arguments: JSONObject?,
    output: JSONObject?,
): WebSourceMetadata {
    val result = output?.optJSONArray("results")?.let { results ->
        (0 until results.length())
            .asSequence()
            .mapNotNull(results::optJSONObject)
            .firstOrNull { it.optString("url").isNotBlank() || it.optString("favicon").isNotBlank() }
    }
    val resultUrl = result?.optString("url").orEmpty()
    val argumentDomain = firstSearchArgumentDomain(arguments)
    val domain = normalizedDomain(resultUrl)
        .ifBlank { argumentDomain }
        .ifBlank { TavilyFallbackDomain }
    val url = normalizedHttpUrl(resultUrl)
        .ifBlank { normalizedHttpUrl(domain) }
        .ifBlank { "https://$TavilyFallbackDomain" }
    val faviconUrl = result?.optString("favicon").orEmpty()
        .takeIf { (it.startsWith("http://") || it.startsWith("https://")) && !it.endsWith(".svg", ignoreCase = true) }
        ?: faviconUrlForDomain(domain)
    return WebSourceMetadata(
        domain = domain,
        url = url,
        faviconUrl = faviconUrl,
    )
}

private fun webSourceMetadataFromUrl(url: String): WebSourceMetadata? {
    val domain = normalizedDomain(url)
    if (domain.isBlank()) return null
    return WebSourceMetadata(
        domain = domain,
        url = normalizedHttpUrl(url).ifBlank { "https://$domain" },
        faviconUrl = faviconUrlForDomain(domain),
    )
}

private fun firstSearchArgumentDomain(arguments: JSONObject?): String {
    val includeDomains = arguments?.optJSONArray("include_domains")
        ?: arguments?.optJSONArray("includeDomains")
    if (includeDomains != null) {
        for (index in 0 until includeDomains.length()) {
            val domain = normalizedDomain(includeDomains.optString(index))
            if (domain.isNotBlank()) return domain
        }
    }

    val query = arguments?.optString("query").orEmpty()
    val domainPattern = Regex("""(?:site:)?([A-Za-z0-9][A-Za-z0-9.-]*\.[A-Za-z]{2,})(?:/[^\s]*)?""")
    return domainPattern.find(query)
        ?.groupValues
        ?.getOrNull(1)
        ?.let(::normalizedDomain)
        .orEmpty()
}

private fun normalizedDomain(urlOrDomain: String): String {
    val trimmed = urlOrDomain.trim()
    if (trimmed.isBlank()) return ""
    val candidate = if (trimmed.contains("://")) trimmed else "https://$trimmed"
    val host = runCatching { URI(candidate).host }
        .getOrNull()
        .orEmpty()
        .ifBlank { trimmed.substringBefore('/').substringBefore('?').substringBefore('#') }
        .trim('.')
    if (host.isBlank()) return ""
    return runCatching { IDN.toUnicode(host) }
        .getOrDefault(host)
        .removePrefix("www.")
        .lowercase(Locale.US)
}

private fun normalizedHttpUrl(urlOrDomain: String): String {
    val trimmed = urlOrDomain.trim()
    if (trimmed.isBlank()) return ""
    val candidate = if (trimmed.contains("://")) trimmed else "https://$trimmed"
    val uri = runCatching { URI(candidate) }.getOrNull() ?: return ""
    val scheme = uri.scheme?.lowercase(Locale.US).orEmpty()
    if (scheme != "http" && scheme != "https") return ""
    val host = uri.host.orEmpty()
    if (host.isBlank()) return ""
    return uri.toString()
}

private fun faviconUrlForDomain(domain: String): String =
    "https://www.google.com/s2/favicons?domain=${Uri.encode(domain)}&sz=64"

@Composable
fun ReconnectingStatusCard(
    text: String,
    detail: String,
    isRunning: Boolean = false,
    modifier: Modifier = Modifier,
) {
    var expanded by rememberSaveable(text, detail) { mutableStateOf(false) }
    LaunchedEffect(detail) {
        if (detail.isBlank()) {
            expanded = false
        }
    }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .animateContentSize(
                animationSpec = tween(durationMillis = ToolTransitionDurationMillis, easing = ToolTransitionEasing),
            )
            .noRippleClickable(enabled = detail.isNotBlank()) { expanded = !expanded },
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        if (isRunning) {
            ShimmerStatusText(text = text)
        } else {
            Text(
                text = text,
                style = MaterialTheme.typography.bodyMedium,
                color = ArixOnSurfaceVariant,
            )
        }

        AnimatedVisibility(
            visible = expanded && detail.isNotBlank(),
            enter = expandVertically(
                animationSpec = tween(durationMillis = ToolTransitionDurationMillis, easing = ToolTransitionEasing),
                expandFrom = Alignment.Top,
            ) + fadeIn(
                animationSpec = tween(
                    durationMillis = ToolTransitionDurationMillis - 90,
                    delayMillis = 40,
                    easing = ToolTransitionEasing,
                ),
            ),
            exit = shrinkVertically(
                animationSpec = tween(durationMillis = 240, easing = FastOutLinearInEasing),
                shrinkTowards = Alignment.Top,
            ) + fadeOut(
                animationSpec = tween(durationMillis = 160, easing = FastOutLinearInEasing),
            ),
        ) {
            SyntaxHighlightedCodeBlock(
                label = stringResource(R.string.common_error),
                content = remember(detail) { highlightToolResult(detail) },
            )
        }
    }
}

@Composable
fun ToolInvocationCard(
    toolInvocation: ChatToolInvocation,
    topPadding: Dp = 6.dp,
) {
    val context = LocalContext.current
    val arguments = remember(toolInvocation.argumentsJson) { parseJsonObject(toolInvocation.argumentsJson) }
    val output = remember(toolInvocation.outputJson) { parseJsonObject(toolInvocation.outputJson) }
    val title = remember(context, toolInvocation.toolName, toolInvocation.isRunning, toolInvocation.argumentsJson) {
        formatToolInvocationTitleLabel(context, toolInvocation, arguments = arguments)
    }
    val noOutputLabel = stringResource(R.string.chat_no_output)
    val contentTruncatedLabel = stringResource(R.string.chat_content_truncated)
    val exitCodeLabel = remember(context) {
        { exitCode: Int -> context.getString(R.string.tool_invocation_exit_code, exitCode) }
    }
    val detail = remember(
        toolInvocation.toolName,
        toolInvocation.isRunning,
        toolInvocation.argumentsJson,
        toolInvocation.outputJson,
        noOutputLabel,
        contentTruncatedLabel,
        exitCodeLabel,
    ) {
        formatToolInvocationDetail(
            toolInvocation = toolInvocation,
            arguments = arguments,
            output = output,
            noOutputLabel = noOutputLabel,
            contentTruncatedLabel = contentTruncatedLabel,
            exitCodeLabel = exitCodeLabel,
        )
    }
    var expanded by rememberSaveable(toolInvocation.id) { mutableStateOf(false) }
    // Native in-chat widgets: completed qr_code / movie_explorer tool calls
    // render a rich card (QR image + download button, movie poster grid,
    // multi-server player) built straight from the structured tool output.
    val toolWidgetPayload = remember(toolInvocation.toolName, toolInvocation.outputJson, toolInvocation.isRunning) {
        if (!toolInvocation.isRunning && toolInvocation.outputJson.isNotBlank()) {
            parseArixToolWidgetPayload(toolInvocation.outputJson)
        } else {
            null
        }
    }
    LaunchedEffect(
        toolInvocation.id,
        toolInvocation.isRunning,
        toolInvocation.startedAtUptimeMillis,
        toolInvocation.completedAtUptimeMillis,
    ) {
        if (!toolInvocation.isRunning) {
            expanded = false
            return@LaunchedEffect
        }

        val startedAt = toolInvocation.startedAtUptimeMillis
            .takeIf { it > 0L }
            ?: SystemClock.uptimeMillis()
        val remainingDelayMillis = ToolInvocationAutoExpandDelayMillis -
            (SystemClock.uptimeMillis() - startedAt)
        if (remainingDelayMillis > 0L) {
            delay(remainingDelayMillis)
        }
        expanded = true
    }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .animateContentSize(
                animationSpec = tween(durationMillis = ToolTransitionDurationMillis, easing = ToolTransitionEasing),
            )
            .noRippleClickable { expanded = !expanded }
            .padding(top = topPadding),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        if (toolInvocation.isRunning) {
            ShimmerStatusText(
                text = title,
                travelDurationMillis = 3200,
                pauseDurationMillis = 1000,
            )
        } else {
            Text(
                text = title,
                style = MaterialTheme.typography.bodyMedium,
                color = ArixOnSurfaceVariant,
            )
        }
        // Native widget: replaces the raw command/result blocks for tool
        // calls that carry a structured widget payload.
        if (toolWidgetPayload != null && !toolInvocation.isRunning) {
            ArixToolResultWidget(
                toolName = toolInvocation.toolName,
                outputJson = toolInvocation.outputJson,
            )
            return@Column
        }
        AnimatedVisibility(
            visible = expanded && detail.command.isNotBlank(),
            enter = expandVertically(
                animationSpec = tween(durationMillis = ToolTransitionDurationMillis, easing = ToolTransitionEasing),
                expandFrom = Alignment.Top,
            ) + fadeIn(
                animationSpec = tween(
                    durationMillis = ToolTransitionDurationMillis - 90,
                    delayMillis = 40,
                    easing = ToolTransitionEasing,
                ),
            ),
            exit = shrinkVertically(
                animationSpec = tween(durationMillis = 240, easing = FastOutLinearInEasing),
                shrinkTowards = Alignment.Top,
            ) + fadeOut(
                animationSpec = tween(durationMillis = 160, easing = FastOutLinearInEasing),
            ),
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                SyntaxHighlightedCodeBlock(
                    label = stringResource(R.string.tool_invocation_command),
                    content = remember(detail.command) { highlightBashCommand(detail.command) },
                )
                detail.result?.let { result ->
                    SyntaxHighlightedCodeBlock(
                        label = stringResource(R.string.tool_invocation_result),
                        content = remember(result) { highlightToolResult(result) },
                    )
                }
            }
        }
    }
}

private fun Modifier.noRippleClickable(
    enabled: Boolean = true,
    onClick: () -> Unit,
): Modifier = composed {
    clickable(
        enabled = enabled,
        indication = null,
        interactionSource = remember { MutableInteractionSource() },
        onClick = onClick,
    )
}

@Composable
internal fun SyntaxHighlightedCodeBlock(
    label: String,
    content: AnnotatedString,
    modifier: Modifier = Modifier,
    maxHeight: Dp = 220.dp,
    scrollState: ScrollState = rememberScrollState(),
) {
    Column(
        modifier = modifier,
        verticalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            color = ArixOnSurfaceVariant,
        )
        SelectionContainer {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(ArixSurfaceHigh)
                    .padding(horizontal = 12.dp, vertical = 10.dp)
                    .heightIn(max = maxHeight)
                    .verticalScroll(scrollState),
            ) {
                Text(
                    text = content,
                    style = MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace),
                    color = ArixOnSurface,
                )
            }
        }
    }
}

@Composable
private fun AssistantAttachments(
    attachments: List<ChatAttachment>,
    onOpenAttachment: (ChatAttachment) -> Unit,
) {
    attachments.forEach { attachment ->
        when (attachment.kind) {
            AttachmentKind.Image -> UserImageAttachmentCard(attachment = attachment, onClick = { onOpenAttachment(attachment) })
            AttachmentKind.File -> UserFileAttachmentCard(attachment = attachment, onClick = { onOpenAttachment(attachment) })
        }
    }
}

@Composable
fun AttachmentPreviewDialog(
    attachment: ChatAttachment,
    onDismiss: () -> Unit,
    onSave: () -> Unit,
) {
    val attachmentKindLabel = attachmentTypeLabel(attachment.kind)
    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false),
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 18.dp, vertical = 24.dp)
                .shadow(24.dp, RoundedCornerShape(30.dp), ambientColor = ArixScrim, spotColor = ArixScrim)
                .clip(RoundedCornerShape(30.dp))
            .background(ArixSurface.copy(alpha = 0.98f))
                .padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .clip(CircleShape)
                        .background(ArixSurfaceHigh),
                    contentAlignment = Alignment.Center,
                ) {
                    Icon(
                        imageVector = if (attachment.kind == AttachmentKind.Image) Icons.Rounded.Image else Icons.Rounded.Description,
                        contentDescription = null,
                        tint = ArixOnSurface,
                    )
                }
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = attachment.name,
                        style = MaterialTheme.typography.titleMedium,
                        color = ArixOnSurface,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis,
                    )
                    Text(
                        text = formatAttachmentMetaLabel(attachmentKindLabel, attachment),
                        style = MaterialTheme.typography.bodySmall,
                        color = ArixOnSurfaceVariant,
                    )
                }
                IconOnlyAction(
                    icon = Icons.Rounded.Close,
                    contentDescription = stringResource(R.string.attachment_close_preview),
                    onClick = onDismiss,
                )
            }

            when (attachment.kind) {
                AttachmentKind.Image -> AttachmentImagePreview(attachment)
                AttachmentKind.File -> AttachmentFilePreview(attachment)
            }

            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                ActionIconLabel(
                    icon = Icons.Rounded.Download,
                    label = stringResource(R.string.common_save),
                    enabled = true,
                    onClick = onSave,
                )
            }
        }
    }
}

@Composable
private fun AttachmentImagePreview(
    attachment: ChatAttachment,
) {
    val bitmap = rememberAttachmentBitmap(attachment, maxSize = 2200)
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .heightIn(min = 220.dp, max = 560.dp)
            .clip(RoundedCornerShape(24.dp))
            .background(ArixSurfaceHigh),
        contentAlignment = Alignment.Center,
    ) {
        if (bitmap != null) {
            Image(
                bitmap = bitmap,
                contentDescription = attachment.name,
                modifier = Modifier.fillMaxWidth(),
                contentScale = ContentScale.Fit,
            )
        } else {
            Icon(
                imageVector = Icons.Rounded.Image,
                contentDescription = null,
                tint = ArixOnSurfaceVariant,
                modifier = Modifier.size(40.dp),
            )
        }
    }
}

@Composable
private fun AttachmentFilePreview(
    attachment: ChatAttachment,
) {
    val preview = rememberAttachmentTextPreview(attachment)

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(24.dp))
            .background(ArixSurfaceHigh)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        if (preview == null) {
            Text(
                text = stringResource(R.string.attachment_file_preview_unavailable),
                style = MaterialTheme.typography.bodyMedium,
                color = ArixOnSurfaceVariant,
            )
        } else {
            SelectionContainer {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(min = 160.dp, max = 360.dp)
                        .verticalScroll(rememberScrollState()),
                ) {
                    Text(
                        text = preview.text,
                        style = MaterialTheme.typography.bodyMedium,
                        color = ArixOnSurface,
                    )
                }
            }
            if (preview.isTruncated) {
                Text(
                    text = stringResource(R.string.attachment_preview_truncated),
                    style = MaterialTheme.typography.bodySmall,
                    color = ArixOnSurfaceVariant,
                )
            }
        }
    }
}

@Composable
private fun UserImageAttachmentCard(
    attachment: ChatAttachment,
    onClick: () -> Unit,
) {
    val bitmap = rememberAttachmentBitmap(attachment, maxSize = 1400)
    Box(
        modifier = Modifier
            .widthIn(max = 300.dp)
            .shadow(10.dp, RoundedCornerShape(24.dp), ambientColor = ArixScrim, spotColor = ArixScrim)
            .clip(RoundedCornerShape(24.dp))
            .background(ArixSurface)
            .clickable(onClick = onClick)
    ) {
        if (bitmap != null) {
            Image(
                bitmap = bitmap,
                contentDescription = attachment.name,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(210.dp),
                contentScale = ContentScale.Crop,
            )
        } else {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(210.dp)
                    .background(ArixSurfaceHigh),
            ) {
                Icon(
                    imageVector = Icons.Rounded.Image,
                    contentDescription = null,
                    tint = ArixOnSurfaceVariant,
                    modifier = Modifier.align(Alignment.Center),
                )
            }
        }
    }
}

@Composable
private fun UserFileAttachmentCard(
    attachment: ChatAttachment,
    onClick: () -> Unit,
) {
    val attachmentKindLabel = attachmentTypeLabel(attachment.kind)
    Row(
        modifier = Modifier
            .widthIn(max = 300.dp)
            .shadow(10.dp, RoundedCornerShape(22.dp), ambientColor = ArixScrim, spotColor = ArixScrim)
            .clip(RoundedCornerShape(22.dp))
            .background(ArixSurface)
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Box(
            modifier = Modifier
                .size(36.dp)
                .clip(CircleShape)
                .background(ArixSurfaceHigh),
            contentAlignment = Alignment.Center,
        ) {
            Icon(Icons.Rounded.Description, contentDescription = null, tint = ArixOnSurface)
        }
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = attachment.name,
                style = MaterialTheme.typography.labelLarge,
                color = ArixOnSurface,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            Text(
                text = formatAttachmentMetaLabel(attachmentKindLabel, attachment),
                style = MaterialTheme.typography.bodySmall,
                color = ArixOnSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }
        Icon(
            imageVector = Icons.AutoMirrored.Rounded.ArrowForwardIos,
            contentDescription = null,
            tint = ArixOnSurfaceVariant,
            modifier = Modifier.size(14.dp),
        )
    }
}

@Composable
private fun ComposerImageAttachmentCard(
    attachment: ChatAttachment,
    onRemove: () -> Unit,
) {
    val attachmentKindLabel = attachmentTypeLabel(attachment.kind)
    val copyingToWorkspaceLabel = stringResource(R.string.attachment_copying_to_workspace)
    val workspaceCopyFailedLabel = stringResource(R.string.attachment_workspace_copy_failed)
    val bitmap = rememberAttachmentBitmap(attachment, maxSize = 600)
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .background(ArixSurfaceHigh)
            .padding(10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Box(
            modifier = Modifier
                .size(62.dp)
                .clip(RoundedCornerShape(16.dp))
            .background(ArixSurface),
            contentAlignment = Alignment.Center,
        ) {
            if (bitmap != null) {
                Image(
                    bitmap = bitmap,
                    contentDescription = attachment.name,
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop,
                )
            } else {
                Icon(Icons.Rounded.Image, contentDescription = null, tint = ArixOnSurfaceVariant)
            }
        }
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = attachment.name,
                style = MaterialTheme.typography.labelLarge,
                color = ArixOnSurface,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            Text(
                text = formatComposerAttachmentMetaLabel(
                    attachmentKindLabel = attachmentKindLabel,
                    copyingToWorkspaceLabel = copyingToWorkspaceLabel,
                    workspaceCopyFailedLabel = workspaceCopyFailedLabel,
                    attachment = attachment,
                ),
                style = MaterialTheme.typography.bodySmall,
                color = ArixOnSurfaceVariant,
            )
        }
        IconOnlyAction(
            icon = Icons.Rounded.Close,
            contentDescription = stringResource(R.string.attachment_remove),
            onClick = onRemove,
        )
    }
}

@Composable
private fun ComposerFileAttachmentCard(
    attachment: ChatAttachment,
    onRemove: () -> Unit,
) {
    val attachmentKindLabel = attachmentTypeLabel(attachment.kind)
    val copyingToWorkspaceLabel = stringResource(R.string.attachment_copying_to_workspace)
    val workspaceCopyFailedLabel = stringResource(R.string.attachment_workspace_copy_failed)
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .background(ArixSurfaceHigh)
            .padding(horizontal = 12.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Box(
            modifier = Modifier
                .size(38.dp)
                .clip(CircleShape)
            .background(ArixSurface),
            contentAlignment = Alignment.Center,
        ) {
            Icon(Icons.Rounded.AttachFile, contentDescription = null, tint = ArixOnSurface)
        }
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = attachment.name,
                style = MaterialTheme.typography.labelLarge,
                color = ArixOnSurface,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            Text(
                text = formatComposerAttachmentMetaLabel(
                    attachmentKindLabel = attachmentKindLabel,
                    copyingToWorkspaceLabel = copyingToWorkspaceLabel,
                    workspaceCopyFailedLabel = workspaceCopyFailedLabel,
                    attachment = attachment,
                ),
                style = MaterialTheme.typography.bodySmall,
                color = ArixOnSurfaceVariant,
            )
        }
        IconOnlyAction(
            icon = Icons.Rounded.Close,
            contentDescription = stringResource(R.string.attachment_remove),
            onClick = onRemove,
        )
    }
}

@Composable
private fun ActionIconLabel(
    icon: ImageVector,
    label: String,
    enabled: Boolean,
    onClick: () -> Unit,
) {
    Row(
        modifier = Modifier
            .clip(RoundedCornerShape(999.dp))
            .background(if (enabled) ArixSurfaceHigh else ArixSurfaceHigh.copy(alpha = 0.45f))
            .clickable(enabled = enabled, onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        Icon(icon, contentDescription = null, tint = if (enabled) ArixOnSurface else ArixOnSurface.copy(alpha = 0.45f), modifier = Modifier.size(14.dp))
        Text(label, style = MaterialTheme.typography.labelMedium, color = if (enabled) ArixOnSurface else ArixOnSurface.copy(alpha = 0.45f))
    }
}

@Composable
private fun IconOnlyAction(
    icon: ImageVector,
    contentDescription: String,
    enabled: Boolean = true,
    onClick: () -> Unit,
) {
    Box(
        modifier = Modifier
            .size(28.dp)
            .clip(CircleShape)
            .background(
                if (enabled) ArixSurface.copy(alpha = 0.72f) else ArixSurface.copy(alpha = 0.35f)
            )
            .clickable(enabled = enabled, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Icon(
            imageVector = icon,
            contentDescription = contentDescription,
            tint = if (enabled) ArixOnSurfaceVariant else ArixOnSurfaceVariant.copy(alpha = 0.4f),
            modifier = Modifier.size(16.dp),
        )
    }
}

@Composable
private fun AssistantMessageAction(
    icon: ImageVector,
    contentDescription: String,
    enabled: Boolean = true,
    onClick: () -> Unit,
) {
    Box(
        modifier = Modifier
            .size(24.dp)
            .clickable(enabled = enabled, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Icon(
            imageVector = icon,
            contentDescription = contentDescription,
            tint = if (enabled) ArixOnSurfaceVariant else ArixOnSurfaceVariant.copy(alpha = 0.36f),
            modifier = Modifier.size(14.dp),
        )
    }
}

@Composable
private fun AssistantMessageActions(
    usageStatistics: ChatUsageStatistics?,
    sessionTotalTokens: Long?,
    actionsEnabled: Boolean,
    onCopy: () -> Unit,
    onRedo: () -> Unit,
    onDelete: () -> Unit,
) {
    var showStatistics by rememberSaveable { mutableStateOf(false) }
    var keepStatisticsPopup by remember { mutableStateOf(false) }
    val statisticsPopupAlpha by animateFloatAsState(
        targetValue = if (showStatistics) 1f else 0f,
        animationSpec = if (showStatistics) {
            tween(durationMillis = 140, easing = ToolTransitionEasing)
        } else {
            tween(durationMillis = 90, easing = FastOutLinearInEasing)
        },
        finishedListener = { alpha ->
            if (alpha == 0f) keepStatisticsPopup = false
        },
        label = "statistics_popup_alpha",
    )
    val statisticsPopupScale by animateFloatAsState(
        targetValue = if (showStatistics) 1f else 0.98f,
        animationSpec = if (showStatistics) {
            tween(durationMillis = 160, easing = ToolTransitionEasing)
        } else {
            tween(durationMillis = 90, easing = FastOutLinearInEasing)
        },
        label = "statistics_popup_scale",
    )
    Box {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            AssistantMessageAction(
                icon = LucideIcons.Copy,
                contentDescription = stringResource(R.string.common_copy_reply),
                onClick = onCopy,
            )
            AssistantMessageAction(
                icon = LucideIcons.RotateCcw,
                contentDescription = stringResource(R.string.common_redo_reply),
                enabled = actionsEnabled,
                onClick = onRedo,
            )
            AssistantMessageAction(
                icon = LucideIcons.Trash2,
                contentDescription = stringResource(R.string.common_delete_reply),
                enabled = actionsEnabled,
                onClick = onDelete,
            )
            AssistantMessageAction(
                icon = LucideIcons.ChartNoAxesColumn,
                contentDescription = stringResource(R.string.statistics_title),
                onClick = {
                    keepStatisticsPopup = true
                    showStatistics = true
                },
            )
        }
        if (keepStatisticsPopup || showStatistics) {
            Popup(
                popupPositionProvider = remember { StatisticsPopupPositionProvider() },
                onDismissRequest = { showStatistics = false },
                properties = PopupProperties(focusable = true),
            ) {
                MessageStatisticsPopup(
                    usageStatistics = usageStatistics,
                    sessionTotalTokens = sessionTotalTokens,
                    modifier = Modifier.graphicsLayer {
                        alpha = statisticsPopupAlpha
                        scaleX = statisticsPopupScale
                        scaleY = statisticsPopupScale
                        transformOrigin = TransformOrigin(0.18f, 1f)
                    },
                )
            }
        }
    }
}

@Composable
private fun MessageStatisticsPopup(
    usageStatistics: ChatUsageStatistics?,
    sessionTotalTokens: Long?,
    modifier: Modifier = Modifier,
) {
    Column(
        modifier = modifier
            .widthIn(min = 236.dp, max = 300.dp)
            .shadow(18.dp, RoundedCornerShape(22.dp), ambientColor = ArixScrim, spotColor = ArixScrim)
            .clip(RoundedCornerShape(22.dp))
            .background(ArixSurface.copy(alpha = 0.98f))
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            Box(
                modifier = Modifier
                    .size(28.dp)
                    .clip(CircleShape)
                    .background(ArixPrimary.copy(alpha = 0.12f)),
                contentAlignment = Alignment.Center,
            ) {
                Icon(
                    imageVector = LucideIcons.ChartNoAxesColumn,
                    contentDescription = null,
                    tint = ArixPrimary,
                    modifier = Modifier.size(16.dp),
                )
            }
            Text(
                text = stringResource(R.string.statistics_title),
                style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.SemiBold),
                color = ArixOnSurface,
            )
        }
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            MessageStatisticRow(
                label = stringResource(R.string.statistics_session_tokens),
                value = sessionTotalTokens?.let(::formatTokenCount)
                    ?: stringResource(R.string.statistics_unavailable),
            )
            MessageStatisticRow(
                label = stringResource(R.string.statistics_turn_tokens),
                value = usageStatistics?.totalTokens?.let(::formatTokenCount)
                    ?: stringResource(R.string.statistics_unavailable),
            )
            MessageStatisticRow(
                label = stringResource(R.string.statistics_reasoning_tokens),
                value = usageStatistics?.reasoningTokens?.let(::formatTokenCount)
                    ?: stringResource(R.string.statistics_unavailable),
            )
            MessageStatisticRow(
                label = stringResource(R.string.statistics_output_rate),
                value = usageStatistics?.outputTokensPerSecond?.let(::formatTokenRate)
                    ?: stringResource(R.string.statistics_unavailable),
            )
            MessageStatisticRow(
                label = stringResource(R.string.statistics_first_token_latency),
                value = usageStatistics?.firstTokenLatencyMillis?.let(::formatLatency)
                    ?: stringResource(R.string.statistics_unavailable),
            )
        }
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
                .background(ArixSurfaceHigh)
                .padding(horizontal = 12.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
        ) {
            CompactStatisticValue(
                label = stringResource(R.string.statistics_input),
                value = usageStatistics?.inputTokens?.let(::formatTokenCount)
                    ?: stringResource(R.string.statistics_dash),
            )
            CompactStatisticValue(
                label = stringResource(R.string.statistics_output),
                value = usageStatistics?.outputTokens?.let(::formatTokenCount)
                    ?: stringResource(R.string.statistics_dash),
            )
            CompactStatisticValue(
                label = stringResource(R.string.statistics_source),
                value = usageStatistics?.tokenUsageSource?.ifBlank { null }
                    ?: stringResource(R.string.statistics_dash),
            )
        }
    }
}

@Composable
private fun MessageStatisticRow(
    label: String,
    value: String,
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.bodySmall,
            color = ArixOnSurfaceVariant,
        )
        Text(
            text = value,
            style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Medium),
            color = ArixOnSurface,
            textAlign = TextAlign.End,
        )
    }
}

@Composable
private fun CompactStatisticValue(
    label: String,
    value: String,
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(2.dp),
    ) {
        Text(
            text = value,
            style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.SemiBold),
            color = ArixOnSurface,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
        )
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            color = ArixOnSurfaceVariant,
            maxLines = 1,
        )
    }
}

private class StatisticsPopupPositionProvider : PopupPositionProvider {
    override fun calculatePosition(
        anchorBounds: androidx.compose.ui.unit.IntRect,
        windowSize: IntSize,
        layoutDirection: androidx.compose.ui.unit.LayoutDirection,
        popupContentSize: IntSize,
    ): IntOffset {
        val margin = 28
        val preferredX = anchorBounds.right + 18
        val fallbackX = anchorBounds.left - popupContentSize.width + 18
        val x = if (preferredX + popupContentSize.width <= windowSize.width - margin) {
            preferredX
        } else {
            fallbackX.coerceAtLeast(margin)
        }
        val y = (anchorBounds.top - 10).coerceIn(
            margin,
            max(margin, windowSize.height - popupContentSize.height - margin),
        )
        return IntOffset(x, y)
    }
}

private fun formatTokenCount(tokens: Long): String = when {
    tokens >= 1_000_000L -> String.format(Locale.US, "%.1fM", tokens / 1_000_000.0)
    tokens >= 1_000L -> String.format(Locale.US, "%.1fK", tokens / 1_000.0)
    else -> tokens.toString()
}

private fun formatTokenRate(tokensPerSecond: Double): String =
    String.format(Locale.US, "%.1f tok/s", tokensPerSecond)

private fun formatLatency(millis: Long): String =
    if (millis >= 1_000L) {
        String.format(Locale.US, "%.2fs", millis / 1000.0)
    } else {
        "${millis}ms"
    }

private fun formatMessageTimestamp(createdAtMillis: Long): String {
    if (createdAtMillis <= 0L) return ""
    return runCatching {
        Instant.ofEpochMilli(createdAtMillis)
            .atZone(ZoneId.systemDefault())
            .format(MessageTimestampFormatter)
    }.getOrDefault("")
}

@Composable
private fun rememberAttachmentBitmap(
    attachment: ChatAttachment,
    maxSize: Int,
): ImageBitmap? {
    val context = LocalContext.current
    val bitmap by produceState<ImageBitmap?>(initialValue = null, attachment, maxSize) {
        value = withContext(Dispatchers.IO) {
            decodeInlineAttachmentBitmap(attachment, maxSize)
                ?: decodeUriAttachmentBitmap(
                    resolver = context.contentResolver,
                    uriString = attachment.uri,
                    maxSize = maxSize,
                )
        }
    }
    return bitmap
}

private fun decodeInlineAttachmentBitmap(
    attachment: ChatAttachment,
    maxSize: Int,
): ImageBitmap? = runCatching {
    if (attachment.inlineBase64.isBlank()) return@runCatching null
    val bytes = Base64.getDecoder().decode(attachment.inlineBase64)
    val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
    if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return@runCatching null

    val sampleSize = calculateSampleSize(bounds.outWidth, bounds.outHeight, maxSize)
    val options = BitmapFactory.Options().apply { inSampleSize = sampleSize }
    BitmapFactory.decodeByteArray(bytes, 0, bytes.size, options)?.asImageBitmap()
}.getOrNull()

private fun decodeUriAttachmentBitmap(
    resolver: android.content.ContentResolver,
    uriString: String,
    maxSize: Int,
): ImageBitmap? = decodeUriAttachmentBitmap(
    uriString = uriString,
    maxSize = maxSize,
    openInputStream = { uri -> resolver.openInputStream(uri) },
)

internal fun decodeUriAttachmentBitmap(
    uriString: String,
    maxSize: Int,
    openInputStream: (Uri) -> java.io.InputStream?,
): ImageBitmap? = runCatching {
    val uri = Uri.parse(uriString)
    val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
    if (bounds.outWidth <= 0 || bounds.outHeight <= 0) {
        return@runCatching null
    }

    val sampleSize = calculateSampleSize(bounds.outWidth, bounds.outHeight, maxSize)
    val options = BitmapFactory.Options().apply { inSampleSize = sampleSize }
    openInputStream(uri)?.use { stream ->
        BitmapFactory.decodeStream(stream, null, options)?.asImageBitmap()
    }
}.getOrNull()

@Composable
private fun rememberAttachmentTextPreview(
    attachment: ChatAttachment,
): AttachmentTextPreview? {
    val context = LocalContext.current
    val preview by produceState<AttachmentTextPreview?>(initialValue = null, attachment) {
        value = withContext(Dispatchers.IO) {
            if (!isLikelyTextAttachment(attachment)) {
                return@withContext null
            }

            val bytes = readAttachmentBytes(
                resolver = context.contentResolver,
                uriString = attachment.uri,
                byteLimit = 64 * 1024 + 1,
            ) ?: return@withContext null

            val decoded = decodeTextAttachment(bytes) ?: return@withContext null
            val isTruncated = bytes.size > 64 * 1024 || decoded.length > 12_000
            AttachmentTextPreview(
                text = decoded.take(12_000),
                isTruncated = isTruncated,
            )
        }
    }
    return preview
}

private fun readAttachmentBytes(
    resolver: android.content.ContentResolver,
    uriString: String,
    byteLimit: Int,
): ByteArray? = runCatching {
    resolver.openInputStream(Uri.parse(uriString))?.use { inputStream ->
        val output = java.io.ByteArrayOutputStream()
        val buffer = ByteArray(DEFAULT_BUFFER_SIZE)
        var totalRead = 0

        while (true) {
            val read = inputStream.read(buffer)
            if (read <= 0) break

            val remaining = byteLimit - totalRead
            if (remaining <= 0) break

            val writeCount = minOf(read, remaining)
            output.write(buffer, 0, writeCount)
            totalRead += writeCount

            if (totalRead >= byteLimit) break
        }

        output.toByteArray()
    }
}.getOrNull()

private fun decodeTextAttachment(
    bytes: ByteArray,
): String? {
    if (bytes.take(512).any { it == 0.toByte() }) return null

    val decoded = bytes.toString(Charsets.UTF_8)
    val replacementCount = decoded.count { it == '\uFFFD' }
    return if (replacementCount > 12) null else decoded
}

private fun isLikelyTextAttachment(
    attachment: ChatAttachment,
): Boolean {
    val mimeType = attachment.mimeType.lowercase()
    if (
        mimeType.startsWith("text/") ||
        mimeType.contains("json") ||
        mimeType.contains("xml") ||
        mimeType.contains("yaml") ||
        mimeType.contains("csv") ||
        mimeType.contains("javascript")
    ) {
        return true
    }

    val extension = attachment.name.substringAfterLast('.', "").lowercase()
    return extension in setOf(
        "txt",
        "md",
        "json",
        "xml",
        "yaml",
        "yml",
        "csv",
        "log",
        "kt",
        "java",
        "kts",
        "js",
        "ts",
        "tsx",
        "jsx",
        "py",
        "rb",
        "go",
        "rs",
        "c",
        "cc",
        "cpp",
        "h",
        "hpp",
        "html",
        "css",
        "sql",
        "sh",
        "gradle",
        "properties",
    )
}

private fun calculateSampleSize(
    width: Int,
    height: Int,
    maxSize: Int,
): Int {
    var sampleSize = 1
    var currentWidth = width
    var currentHeight = height

    while (currentWidth > maxSize || currentHeight > maxSize) {
        currentWidth /= 2
        currentHeight /= 2
        sampleSize *= 2
    }
    return sampleSize.coerceAtLeast(1)
}

private fun formatThoughtDuration(durationMillis: Long): String {
    val totalSeconds = (durationMillis / 1000f).roundToInt().coerceAtLeast(1)
    val hours = totalSeconds / 3600
    val minutes = (totalSeconds % 3600) / 60
    val seconds = totalSeconds % 60
    return buildList {
        if (hours > 0) add("${hours}h")
        if (minutes > 0 || hours > 0) add("${minutes}min")
        add("${seconds}s")
    }.joinToString(" ")
}

@Composable
fun formatWorkedSummaryTitle(durationMillis: Long): String =
    stringResource(R.string.chat_working_for_duration, formatThoughtDuration(durationMillis))

fun workDurationMillisForMessages(
    messages: List<ChatMessage>,
    endAtMillis: Long? = null,
): Long {
    messages.asReversed().forEach { message ->
        val usage = message.usageStatistics ?: return@forEach
        if (
            usage.startedAtMillis >= MinimumEpochMillis &&
            usage.completedAtMillis >= usage.startedAtMillis
        ) {
            return (usage.completedAtMillis - usage.startedAtMillis).coerceAtLeast(1_000L)
        }
    }
    messages.lastOrNull()?.thoughtDurationMillis?.let { duration ->
        return duration.coerceAtLeast(1_000L)
    }

    val timestamps = mutableListOf<Long>()
    messages.forEach { message ->
        if (message.createdAtMillis > 0L) {
            timestamps += message.createdAtMillis
        }
        message.reasoningTrace?.let { trace ->
            if (trace.startedAtMillis > 0L) timestamps += trace.startedAtMillis
            trace.completedAtMillis?.takeIf { it > 0L }?.let { timestamps += it }
            trace.chunks.forEach { chunk ->
                if (chunk.createdAtMillis > 0L) timestamps += chunk.createdAtMillis
            }
        }
        message.toolInvocations.forEach { invocation ->
            if (invocation.startedAtMillis > 0L) timestamps += invocation.startedAtMillis
            invocation.completedAtMillis?.takeIf { it > 0L }?.let { timestamps += it }
        }
    }
    endAtMillis?.takeIf { it > 0L }?.let { timestamps += it }

    val wallClockTimestamps = timestamps.filter { it >= MinimumEpochMillis }
    if (wallClockTimestamps.size < 2) {
        return 1_000L
    }
    return (wallClockTimestamps.maxOrNull()!! - wallClockTimestamps.minOrNull()!!)
        .coerceAtLeast(1_000L)
}

fun workDurationMillisForBlocks(
    blocks: List<AssistantResponseBlock>,
    endAtMillis: Long = System.currentTimeMillis(),
): Long {
    val timestamps = mutableListOf<Long>()
    blocks.forEach { block ->
        when (block) {
            is AssistantResponseBlock.Text -> Unit
            is AssistantResponseBlock.Status -> Unit
            is AssistantResponseBlock.ToolGroup -> block.toolInvocations.forEach { invocation ->
                if (invocation.startedAtMillis > 0L) timestamps += invocation.startedAtMillis
                invocation.completedAtMillis?.takeIf { it > 0L }?.let { timestamps += it }
            }
            is AssistantResponseBlock.Reasoning -> {
                val trace = block.trace
                if (trace.startedAtMillis > 0L) timestamps += trace.startedAtMillis
                trace.completedAtMillis?.takeIf { it > 0L }?.let { timestamps += it }
                trace.chunks.forEach { chunk ->
                    if (chunk.createdAtMillis > 0L) timestamps += chunk.createdAtMillis
                }
                trace.toolInvocations.forEach { invocation ->
                    if (invocation.startedAtMillis > 0L) timestamps += invocation.startedAtMillis
                    invocation.completedAtMillis?.takeIf { it > 0L }?.let { timestamps += it }
                }
            }
        }
    }
    timestamps += endAtMillis

    val wallClockTimestamps = timestamps.filter { it >= MinimumEpochMillis }
    if (wallClockTimestamps.size < 2) {
        return 1_000L
    }
    return (wallClockTimestamps.maxOrNull()!! - wallClockTimestamps.minOrNull()!!)
        .coerceAtLeast(1_000L)
}

fun workDurationMillisForToolInvocations(
    toolInvocations: List<ChatToolInvocation>,
    endAtMillis: Long = System.currentTimeMillis(),
): Long {
    val timestamps = mutableListOf<Long>()
    toolInvocations.forEach { invocation ->
        if (invocation.startedAtMillis > 0L) timestamps += invocation.startedAtMillis
        invocation.completedAtMillis?.takeIf { it > 0L }?.let { timestamps += it }
    }
    timestamps += endAtMillis

    val wallClockTimestamps = timestamps.filter { it >= MinimumEpochMillis }
    if (wallClockTimestamps.size < 2) {
        return 1_000L
    }
    return (wallClockTimestamps.maxOrNull()!! - wallClockTimestamps.minOrNull()!!)
        .coerceAtLeast(1_000L)
}

@Composable
private fun formatReasoningTraceDoneLabel(trace: ReasoningTrace): String {
    val startedAt = trace.startedAtMillis.takeIf { it > 0L }
    val endedAt = trace.completedAtMillis ?: System.currentTimeMillis()
    val duration = startedAt?.let { formatThoughtDuration((endedAt - it).coerceAtLeast(1L)) } ?: "0s"
    val toolCount = trace.toolInvocations.size
    return if (toolCount > 0) {
        stringResource(R.string.chat_thought_for_duration_and_tools, duration, toolCount)
    } else {
        stringResource(R.string.chat_thought_for_duration, duration)
    }
}

@Composable
private fun formatReasoningTraceDoneChunkTitle(trace: ReasoningTrace): String {
    val startedAt = trace.startedAtMillis.takeIf { it > 0L }
    val endedAt = trace.completedAtMillis ?: System.currentTimeMillis()
    val duration = startedAt?.let { formatThoughtDuration((endedAt - it).coerceAtLeast(1L)) } ?: "0s"
    return stringResource(R.string.chat_thought_for_duration, duration)
}

@Composable
private fun attachmentTypeLabel(kind: AttachmentKind): String = stringResource(
    if (kind == AttachmentKind.Image) R.string.attachment_type_photo else R.string.attachment_type_file,
)

private fun formatAttachmentMetaLabel(attachmentKindLabel: String, attachment: ChatAttachment): String {
    val sizeLabel = attachment.sizeBytes?.let(::formatAttachmentSize)
    return listOfNotNull(attachmentKindLabel, sizeLabel).joinToString(" | ")
}

private fun formatComposerAttachmentMetaLabel(
    attachmentKindLabel: String,
    copyingToWorkspaceLabel: String,
    workspaceCopyFailedLabel: String,
    attachment: ChatAttachment,
): String {
    val statusLabel = when (attachment.workspaceState) {
        AttachmentWorkspaceState.Pending -> copyingToWorkspaceLabel
        AttachmentWorkspaceState.Failed -> workspaceCopyFailedLabel
        AttachmentWorkspaceState.Ready -> null
    }
    return listOfNotNull(
        formatAttachmentMetaLabel(attachmentKindLabel, attachment).ifBlank { null },
        if (attachment.workspaceState == AttachmentWorkspaceState.Pending) {
            formatWorkspaceCopyProgress(copyingToWorkspaceLabel, attachment)
        } else {
            statusLabel
        },
    ).joinToString(" | ")
}

private fun formatWorkspaceCopyProgress(copyingToWorkspaceLabel: String, attachment: ChatAttachment): String {
    val copiedLabel = attachment.workspaceBytesCopied
        .takeIf { it > 0L }
        ?.let(::formatAttachmentSize)
    val totalLabel = attachment.sizeBytes?.takeIf { it > 0L }?.let(::formatAttachmentSize)
    val speedLabel = attachment.workspaceBytesPerSecond
        .takeIf { it > 0L }
        ?.let { "${formatAttachmentSize(it)}/s" }
    val progressLabel = when {
        copiedLabel != null && totalLabel != null -> "$copiedLabel / $totalLabel"
        copiedLabel != null -> copiedLabel
        else -> null
    }
    return listOfNotNull(copyingToWorkspaceLabel, progressLabel, speedLabel).joinToString(" · ")
}

private fun formatToolInvocationTitleLabel(
    context: Context,
    toolInvocation: ChatToolInvocation,
    isRunningOverride: Boolean = toolInvocation.isRunning,
    arguments: JSONObject? = parseJsonObject(toolInvocation.argumentsJson),
): String {
    val isRunning = isRunningOverride
    (context.applicationContext as? ArixApplication)?.runtime?.modKernel?.toolTitles
        ?.titleFor(toolInvocation.toolName, isRunning)?.let { return it }
    return when (toolInvocation.toolName.lowercase()) {
        "bash" -> context.getString(if (isRunning) R.string.tool_title_bash_running else R.string.tool_title_bash_done)
        "read" -> context.getString(if (isRunning) R.string.tool_title_read_running else R.string.tool_title_read_done)
        "edit" -> context.getString(if (isRunning) R.string.tool_title_edit_running else R.string.tool_title_edit_done)
        "write" -> context.getString(if (isRunning) R.string.tool_title_write_running else R.string.tool_title_write_done)
        "grep" -> context.getString(if (isRunning) R.string.tool_title_grep_running else R.string.tool_title_grep_done)
        "find" -> context.getString(if (isRunning) R.string.tool_title_find_running else R.string.tool_title_find_done)
        "ls" -> context.getString(if (isRunning) R.string.tool_title_ls_running else R.string.tool_title_ls_done)
        "agent_mode" -> formatAgentDisplayTitle(context = context, isRunning = isRunning, arguments = arguments)
        "chrome", "browser" -> formatChromeTitle(context = context, isRunning = isRunning, arguments = arguments)
        "arix_config_get",
        "arix_config_set",
        "arix_skill_manage",
        "arix_agent_mode_manage",
        "arix_developer_manage" -> formatArixToolTitle(
            context = context,
            toolName = toolInvocation.toolName,
            isRunning = isRunning,
            arguments = arguments,
        )
        else -> if (isRunning) {
            context.getString(R.string.tool_title_using_tool, toolInvocation.toolName)
        } else {
            context.getString(R.string.tool_title_used_tool, toolInvocation.toolName)
        }
    }
}

private fun summarizeToolInvocationCommandLabel(
    toolName: String,
    arguments: JSONObject?,
): String {
    if (arguments == null) return toolName
    return when (toolName.lowercase()) {
        "bash" -> arguments.optString("command").trim()
        "read" -> buildString {
            append("read ")
            append(arguments.optString("path").trim())
            val offset = arguments.takeIf { it.has("offset") }?.optInt("offset") ?: 0
            val limit = arguments.takeIf { it.has("limit") }?.optInt("limit")
            if (offset > 0 || limit != null) {
                append(" (offset=")
                append(offset)
                if (limit != null) {
                    append(", limit=")
                    append(limit)
                }
                append(')')
            }
        }
        "edit" -> {
            val path = arguments.optString("path").trim()
            val editCount = arguments.optJSONArray("edits")?.length()
                ?: if (arguments.has("oldText") || arguments.has("newText")) 1 else 0
            "edit $path${if (editCount > 0) " ($editCount edit${if (editCount == 1) "" else "s"})" else ""}"
        }
        "write" -> "write ${arguments.optString("path").trim()}"
        "grep" -> "grep ${arguments.optString("pattern").trim()} in ${arguments.optString("path").trim()}"
        "find" -> "find ${arguments.optString("pattern").trim()} in ${arguments.optString("path").trim()}"
        "ls" -> "ls ${arguments.optString("path").trim()}"
        // v2.4.2: the MCP proxy tool used to render as a bare "$ mcp" that
        // looked like a failed shell command. Summarize what it actually did.
        "mcp" -> summarizeMcpProxyCommand(arguments)
        "analyze_image" -> buildString {
            append("analyze_image ")
            append(arguments.optString("path").trim())
            val prompt = arguments.optString("prompt").trim()
            if (prompt.isNotBlank()) {
                append(" (")
                append(prompt.take(48))
                if (prompt.length > 48) {
                    append("...")
                }
                append(')')
            }
        }
        "agent_mode" -> summarizeAgentDisplayCommand(arguments)
        "chrome", "browser" -> summarizeChromeCommand(arguments)
        "tavily_search" -> "search ${arguments.optString("query").trim()}"
        "fetch_web_url" -> "fetch ${arguments.optString("url").trim()}"
        "arix_config_get",
        "arix_config_set",
        "arix_skill_manage",
        "arix_mcp_manage",
        "arix_agent_mode_manage",
        "arix_developer_manage" -> summarizeArixToolCommand(toolName, arguments)
        else -> toolName
    }.trim()
}

private fun formatToolInvocationDetail(
    toolInvocation: ChatToolInvocation,
    arguments: JSONObject? = parseJsonObject(toolInvocation.argumentsJson),
    output: JSONObject? = parseJsonObject(toolInvocation.outputJson),
    noOutputLabel: String,
    contentTruncatedLabel: String,
    exitCodeLabel: (Int) -> String,
): ToolInvocationDetail {
    val command = output?.optString("command")
        .orEmpty()
        .trim()
        .ifBlank { summarizeToolInvocationCommandLabel(toolInvocation.toolName, arguments) }
        .ifBlank { toolInvocation.toolName }

    if (toolInvocation.isRunning && output == null) {
        return ToolInvocationDetail(
            command = command,
            result = null,
        )
    }

    val result = when {
        output == null -> toolInvocation.outputJson.trim().ifBlank { noOutputLabel }
        toolInvocation.toolName.startsWith("arix_", ignoreCase = true) -> {
            toolInvocation.outputJson.trim().ifBlank { noOutputLabel }
        }
        toolInvocation.toolName.equals("fetch_web_url", ignoreCase = true) -> {
            formatFetchWebUrlResult(output, noOutputLabel, contentTruncatedLabel)
        }
        output.optString("stdout").trim().isNotBlank() &&
            output.optString("stderr").trim().isNotBlank() -> {
            buildString {
                appendLine(output.optString("stdout").trim())
                appendLine()
                append("stderr: ")
                append(output.optString("stderr").trim())
            }
        }
        output.optString("stdout").trim().isNotBlank() -> output.optString("stdout").trim()
        output.optString("stderr").trim().isNotBlank() -> output.optString("stderr").trim()
        output.optString("errmsg").trim().isNotBlank() -> output.optString("errmsg").trim()
        output.optString("hint").trim().isNotBlank() -> output.optString("hint").trim()
        output.has("exit_code") && output.optInt("exit_code") != 0 -> exitCodeLabel(output.optInt("exit_code"))
        else -> noOutputLabel
    }

    // v2.6.1 stability fix: cap the tool-result text handed to the UI. A
    // fetched movie-listing page used to pour its entire (100+ KB) markdown
    // into the tool card's code block — the repeated layout/annotation pass
    // over that string caused the visible lag, jank and eventual crash on
    // long "latest movies" answers. The visible block is already capped at
    // 220 dp with its own scroll, so a generous character cap loses nothing.
    val cappedResult = if (result.length > MaxToolResultDetailChars) {
        buildString {
            append(result.take(MaxToolResultDetailChars))
            append('\n')
            append('\n')
            append(contentTruncatedLabel)
        }
    } else {
        result
    }

    return ToolInvocationDetail(
        command = command,
        result = cappedResult,
    )
}

private fun formatFetchWebUrlResult(
    output: JSONObject,
    noOutputLabel: String,
    contentTruncatedLabel: String,
): String {
    val markdown = output.optString("markdown").trim()
    if (markdown.isNotBlank()) {
        return buildString {
            append(markdown)

            if (output.optBoolean("truncated")) {
                appendLine()
                appendLine()
                append(contentTruncatedLabel)
            }
        }.trim()
    }

    return output.optString("stdout").trim().ifBlank { noOutputLabel }
}

/** v2.6.1 stability fix: maximum characters of a tool result rendered in the
 *  expandable command/result code blocks (see formatToolInvocationDetail). */
private const val MaxToolResultDetailChars = 6_000

private fun summarizeToolInvocationCommand(
    toolName: String,
    arguments: JSONObject?,
): String {
    if (arguments == null) return toolName
    return when (toolName.lowercase()) {
        "bash" -> arguments.optString("command").trim()
        "read" -> buildString {
            append("read ")
            append(arguments.optString("path").trim())
            val offset = arguments.takeIf { it.has("offset") }?.optInt("offset") ?: 0
            val limit = arguments.takeIf { it.has("limit") }?.optInt("limit")
            if (offset > 0 || limit != null) {
                append(" (offset=")
                append(offset)
                if (limit != null) {
                    append(", limit=")
                    append(limit)
                }
                append(')')
            }
        }
        "edit" -> {
            val path = arguments.optString("path").trim()
            val editCount = arguments.optJSONArray("edits")?.length()
                ?: if (arguments.has("oldText") || arguments.has("newText")) 1 else 0
            "edit $path${if (editCount > 0) " ($editCount edit${if (editCount == 1) "" else "s"})" else ""}"
        }
        "write" -> "write ${arguments.optString("path").trim()}"
        "grep" -> "grep ${arguments.optString("pattern").trim()} in ${arguments.optString("path").trim()}"
        "find" -> "find ${arguments.optString("pattern").trim()} in ${arguments.optString("path").trim()}"
        "ls" -> "ls ${arguments.optString("path").trim()}"
        "mcp" -> summarizeMcpProxyCommand(arguments)
        "agent_mode" -> summarizeAgentDisplayCommand(arguments)
        "chrome", "browser" -> summarizeChromeCommand(arguments)
        "tavily_search" -> "search ${arguments.optString("query").trim()}"
        "fetch_web_url" -> "fetch ${arguments.optString("url").trim()}"
        "arix_config_get",
        "arix_config_set",
        "arix_skill_manage",
        "arix_mcp_manage",
        "arix_agent_mode_manage",
        "arix_developer_manage" -> summarizeArixToolCommand(toolName, arguments)
        else -> toolName
    }.trim()
}

private fun formatArgumentDrivenTitle(
    isRunning: Boolean,
    progressiveVerb: String,
    completedVerb: String,
    subject: String,
    fallback: String,
): String {
    val normalizedSubject = subject.trim()
    val action = if (isRunning) progressiveVerb else completedVerb
    if (normalizedSubject.isBlank()) {
        return "$action $fallback"
    }

    return "$action ${normalizedSubject.take(72)}${if (normalizedSubject.length > 72) "..." else ""}"
}

private fun formatAgentDisplayTitle(
    context: Context,
    isRunning: Boolean,
    arguments: JSONObject?,
): String {
    val action = arguments?.optString("action").orEmpty().lowercase()
    return when (action) {
        "list_apps", "apps", "installed_apps" -> formatArgumentDrivenTitle(
            isRunning = isRunning,
            progressiveVerb = context.getString(R.string.tool_title_reading),
            completedVerb = context.getString(R.string.tool_title_read),
            subject = arguments?.optString("query").orEmpty(),
            fallback = context.getString(R.string.tool_title_installed_apps_fallback),
        )
        "start" -> context.getString(if (isRunning) R.string.tool_title_starting_agent_mode_display else R.string.tool_title_started_agent_mode_display)
        "status" -> context.getString(if (isRunning) R.string.tool_title_checking_agent_mode_display else R.string.tool_title_checked_agent_mode_display)
        "launch" -> formatArgumentDrivenTitle(
            isRunning = isRunning,
            progressiveVerb = context.getString(R.string.tool_title_launching),
            completedVerb = context.getString(R.string.tool_title_launched),
            subject = arguments?.optString("target").orEmpty(),
            fallback = context.getString(R.string.tool_title_agent_mode_app_fallback),
        )
        "tap" -> context.getString(if (isRunning) R.string.tool_title_tapping_agent_mode_display else R.string.tool_title_tapped_agent_mode_display)
        "swipe" -> context.getString(if (isRunning) R.string.tool_title_swiping_agent_mode_display else R.string.tool_title_swiped_agent_mode_display)
        "key" -> formatArgumentDrivenTitle(
            isRunning = isRunning,
            progressiveVerb = context.getString(R.string.tool_title_pressing),
            completedVerb = context.getString(R.string.tool_title_pressed),
            subject = arguments?.optString("key").orEmpty(),
            fallback = context.getString(R.string.tool_title_agent_mode_key_fallback),
        )
        "text" -> context.getString(if (isRunning) R.string.tool_title_typing_agent_mode else R.string.tool_title_typed_agent_mode)
        "screenshot", "read_screen", "read", "screen" -> context.getString(if (isRunning) R.string.tool_title_capturing_agent_mode_display else R.string.tool_title_captured_agent_mode_display)
        "stop" -> context.getString(if (isRunning) R.string.tool_title_stopping_agent_mode_display else R.string.tool_title_stopped_agent_mode_display)
        else -> context.getString(if (isRunning) R.string.tool_title_using_agent_mode_display else R.string.tool_title_used_agent_mode_display)
    }
}

private fun formatArixToolTitle(
    context: Context,
    toolName: String,
    isRunning: Boolean,
    arguments: JSONObject?,
): String {
    val action = arguments?.optString("action").orEmpty().trim()
    return when (toolName.lowercase()) {
        "arix_config_get" -> formatArgumentDrivenTitle(
            isRunning = isRunning,
            progressiveVerb = context.getString(R.string.tool_title_reading),
            completedVerb = context.getString(R.string.tool_title_read),
            subject = summarizeArixCategories(arguments),
            fallback = context.getString(R.string.tool_title_arix_settings_fallback),
        )
        "arix_config_set" -> formatArgumentDrivenTitle(
            isRunning = isRunning,
            progressiveVerb = context.getString(R.string.tool_title_updating),
            completedVerb = context.getString(R.string.tool_title_updated),
            subject = arguments?.optString("category").orEmpty(),
            fallback = context.getString(R.string.tool_title_arix_settings_fallback),
        )
        "arix_skill_manage" -> when (action.lowercase()) {
            "install_remote" -> formatArgumentDrivenTitle(isRunning, context.getString(R.string.tool_title_installing), context.getString(R.string.tool_title_installed), arguments?.optString("url").orEmpty(), context.getString(R.string.tool_title_agent_skill_fallback))
            "remove" -> formatArgumentDrivenTitle(isRunning, context.getString(R.string.tool_title_removing), context.getString(R.string.tool_title_removed), optArixString(arguments, "skill_id", "skillId"), context.getString(R.string.tool_title_agent_skill_fallback))
            "set_enabled" -> formatArgumentDrivenTitle(isRunning, context.getString(R.string.tool_title_updating), context.getString(R.string.tool_title_updated), optArixString(arguments, "skill_id", "skillId"), context.getString(R.string.tool_title_agent_skill_fallback))
            else -> context.getString(if (isRunning) R.string.tool_title_reading_agent_skills else R.string.tool_title_read_agent_skills)
        }
        "arix_mcp_manage" -> when (action.lowercase()) {
            "upsert_streamable_http", "upsert_stdio" -> formatArgumentDrivenTitle(isRunning, context.getString(R.string.tool_title_saving), context.getString(R.string.tool_title_saved), optArixString(arguments, "display_name", "displayName"), context.getString(R.string.tool_title_mcp_server_fallback))
            "remove" -> formatArgumentDrivenTitle(isRunning, context.getString(R.string.tool_title_removing), context.getString(R.string.tool_title_removed), optArixString(arguments, "server_id", "serverId"), context.getString(R.string.tool_title_mcp_server_fallback))
            "set_enabled" -> formatArgumentDrivenTitle(isRunning, context.getString(R.string.tool_title_updating), context.getString(R.string.tool_title_updated), optArixString(arguments, "server_id", "serverId"), context.getString(R.string.tool_title_mcp_server_fallback))
            else -> context.getString(if (isRunning) R.string.tool_title_reading_mcp_servers else R.string.tool_title_read_mcp_servers)
        }
        "arix_agent_mode_manage" -> when (action.lowercase()) {
            "set_authorization" -> context.getString(if (isRunning) R.string.tool_title_updating_agent_mode_authorization else R.string.tool_title_updated_agent_mode_authorization)
            "stop_session" -> context.getString(if (isRunning) R.string.tool_title_stopping_agent_mode_display else R.string.tool_title_stopped_agent_mode_display)
            else -> context.getString(if (isRunning) R.string.tool_title_checking_agent_mode_authorization else R.string.tool_title_checked_agent_mode_authorization)
        }
        "arix_developer_manage" -> context.getString(if (isRunning) R.string.tool_title_reading_arix_diagnostics else R.string.tool_title_read_arix_diagnostics)
        else -> context.getString(if (isRunning) R.string.tool_title_managing_arix else R.string.tool_title_managed_arix)
    }
}

private fun summarizeArixToolCommand(
    toolName: String,
    arguments: JSONObject,
): String {
    val action = arguments.optString("action").trim()
    return when (toolName.lowercase()) {
        "arix_config_get" -> "arix_config_get categories=${summarizeArixCategories(arguments).ifBlank { "all" }}"
        "arix_config_set" -> "arix_config_set category=${arguments.optString("category").trim()} ${summarizeArixSettingsPatch(arguments.optJSONObject("settings"))}".trim()
        "arix_skill_manage" -> buildString {
            append("arix_skill_manage action=")
            append(action.ifBlank { "list" })
            appendArixKeyValue(arguments, "skill_id", "skillId")
            appendArixKeyValue(arguments, "url")
            if (arguments.has("enabled")) append(" enabled=").append(arguments.optBoolean("enabled"))
        }.trim()
        "arix_mcp_manage" -> buildString {
            append("arix_mcp_manage action=")
            append(action.ifBlank { "list" })
            appendArixKeyValue(arguments, "server_id", "serverId")
            appendArixKeyValue(arguments, "display_name", "displayName")
            appendArixKeyValue(arguments, "url")
            appendArixKeyValue(arguments, "command")
            if (arguments.has("enabled")) append(" enabled=").append(arguments.optBoolean("enabled"))
        }.trim()
        "arix_agent_mode_manage" -> buildString {
            append("arix_agent_mode_manage action=")
            append(action.ifBlank { "inspect_authorization" })
            if (arguments.has("enabled")) append(" enabled=").append(arguments.optBoolean("enabled"))
            appendArixKeyValue(arguments, "method")
        }.trim()
        "arix_developer_manage" -> buildString {
            append("arix_developer_manage action=")
            append(action.ifBlank { "read_diagnostics" })
            appendArixKeyValue(arguments, "include")
            appendArixKeyValue(arguments, "max_chars", "maxChars")
        }.trim()
        else -> toolName
    }
}

private fun summarizeArixCategories(arguments: JSONObject?): String {
    val categories = arguments?.optJSONArray("categories") ?: return ""
    return buildList {
        for (index in 0 until categories.length()) {
            val value = categories.optString(index).trim()
            if (value.isNotBlank()) add(value)
        }
    }.joinToString(",")
}

private fun summarizeArixSettingsPatch(settings: JSONObject?): String {
    if (settings == null) return ""
    val keys = buildList {
        settings.keys().forEach { add(it) }
    }
    return if (keys.isEmpty()) "" else "fields=${keys.joinToString(",")}"
}

private fun optArixString(
    arguments: JSONObject?,
    primary: String,
    secondary: String,
): String = arguments?.optString(primary).orEmpty().ifBlank {
    arguments?.optString(secondary).orEmpty()
}

private fun StringBuilder.appendArixKeyValue(
    arguments: JSONObject,
    primary: String,
    secondary: String = "",
) {
    val value = arguments.optString(primary).ifBlank {
        if (secondary.isBlank()) "" else arguments.optString(secondary)
    }.trim()
    if (value.isNotBlank()) {
        append(' ')
        append(primary)
        append('=')
        append(value.take(96))
        if (value.length > 96) append("...")
    }
}

private fun summarizeAgentDisplayCommand(arguments: JSONObject?): String {
    if (arguments == null) return "agent_mode"
    val action = arguments.optString("action").trim().ifBlank { "unknown" }
    return when (action.lowercase()) {
        "list_apps", "apps", "installed_apps" -> {
            val query = arguments.optString("query").trim()
            "agent_mode list_apps${if (query.isBlank()) "" else " $query"}"
        }
        "launch" -> "agent_mode launch ${arguments.optString("target").trim()}"
        "tap" -> "agent_mode tap x=${arguments.optString("x").trim()} y=${arguments.optString("y").trim()}"
        "swipe" -> "agent_mode swipe ${arguments.optString("x1").trim()},${arguments.optString("y1").trim()} -> ${arguments.optString("x2").trim()},${arguments.optString("y2").trim()} ${arguments.optString("duration_ms").ifBlank { arguments.optString("durationMs") }.trim()}ms"
        "key" -> "agent_mode key ${arguments.optString("key").trim()}"
        "text" -> {
            val text = arguments.optString("text").trim()
            "agent_mode text ${text.take(48)}${if (text.length > 48) "..." else ""}"
        }
        "start", "status", "read_screen", "read", "screen", "stop" -> "agent_mode $action"
        else -> "agent_mode $action"
    }.trim()
}

private fun buildAgentModeReplayTimeline(
    context: Context,
    messages: List<ChatMessage>,
): AgentModeReplayTimeline {
    val frames = mutableListOf<AgentModeReplayFrame>()
    val interleavedTextMessageIds = mutableSetOf<String>()
    var firstFrameMessageIndex = -1
    messages.forEachIndexed { index, message ->
        val messageFrames = buildAgentModeReplayFrames(context, message.replayToolInvocations())
        if (messageFrames.isNotEmpty()) {
            if (firstFrameMessageIndex < 0) {
                firstFrameMessageIndex = index
            }
            frames += messageFrames
        }
        if (message.text.isNotBlank() && frames.isNotEmpty() && messages.hasFutureAgentModeFrame(context, index + 1)) {
            frames[frames.lastIndex] = frames.last().copy(overlayText = message.text)
            interleavedTextMessageIds += message.id
        }
    }
    return AgentModeReplayTimeline(
        frames = frames,
        interleavedTextMessageIds = interleavedTextMessageIds,
        firstFrameMessageIndex = firstFrameMessageIndex,
    )
}

private fun List<ChatMessage>.hasFutureAgentModeFrame(context: Context, startIndex: Int): Boolean =
    drop(startIndex).any { message ->
        buildAgentModeReplayFrames(context, message.replayToolInvocations()).isNotEmpty()
    }

private fun ChatMessage.replayToolInvocations(): List<ChatToolInvocation> =
    (toolInvocations + reasoningTrace?.toolInvocations.orEmpty()).distinctBy(ChatToolInvocation::id)

private fun buildAgentModeReplayFrames(
    context: Context,
    toolInvocations: List<ChatToolInvocation>,
): List<AgentModeReplayFrame> = buildList {
    toolInvocations.forEach { invocation ->
        if (
            !invocation.toolName.equals("agent_mode", ignoreCase = true) &&
            !invocation.toolName.equals("chrome", ignoreCase = true) &&
            !invocation.toolName.equals("browser", ignoreCase = true)
        ) return@forEach
        val output = parseJsonObject(invocation.outputJson) ?: return@forEach
        if (!output.optBoolean("ok")) return@forEach
        val previewPath = output.optString("preview_path").ifBlank {
            output.optString("previewPath").ifBlank {
                output.optString("screenshot_path")
            }
        }
        if (previewPath.isBlank()) return@forEach
        add(
            AgentModeReplayFrame(
                previewPath = previewPath,
                width = output.optInt("width"),
                height = output.optInt("height"),
                cursorX = output.optionalInt("cursor_x", "cursorX"),
                cursorY = output.optionalInt("cursor_y", "cursorY"),
                overlayText = "",
                completedAtUptimeMillis = invocation.completedAtUptimeMillis ?: invocation.startedAtUptimeMillis,
                toolTitle = formatToolInvocationTitleLabel(
                    context = context,
                    toolInvocation = invocation,
                    isRunningOverride = true,
                    arguments = parseJsonObject(invocation.argumentsJson),
                ),
            )
        )
    }
}

private fun ChatToolInvocation.isAgentModeDisplayInvocation(): Boolean =
    toolName.equals("agent_mode", ignoreCase = true) ||
        toolName.equals("chrome", ignoreCase = true) || toolName.equals("browser", ignoreCase = true)

private fun agentModeReplayBackdropBrush(): Brush = Brush.linearGradient(
    colorStops = arrayOf(
        0.00f to Color(0xFFBEEBFF),
        0.22f to Color(0xFF75C7FF),
        0.44f to Color(0xFFD5E9FF),
        0.68f to Color(0xFF83B5FF),
        1.00f to Color(0xFF4E86F7),
    ),
    start = Offset.Zero,
    end = Offset(900f, 620f),
)

private fun parseJsonObject(rawValue: String): JSONObject? {
    if (rawValue.isBlank()) return null
    return runCatching { JSONObject(rawValue) }.getOrNull()
}

private fun JSONObject.optionalInt(vararg keys: String): Int? =
    keys.firstOrNull { has(it) && !isNull(it) }?.let { optInt(it) }

internal fun highlightBashCommand(command: String): AnnotatedString = buildAnnotatedString {
    appendStyled("$ ", SpanStyle(color = ArixSecondary, fontWeight = FontWeight.SemiBold))

    val tokenPattern = Regex("""\s+|&&|\|\||[|;><()]|"(?:\\.|[^"])*"|'(?:\\.|[^'])*'|\$[A-Za-z_][A-Za-z0-9_]*|--?[A-Za-z0-9][\w-]*|[^\s|;><()]+""")
    var expectsCommand = true

    tokenPattern.findAll(command).forEach { match ->
        val token = match.value
        val style = when {
            token.isBlank() -> null
            token in setOf("|", "||", "&&", ";", ">", "<", "(", ")") -> {
                expectsCommand = true
                SpanStyle(color = ArixOnSurfaceVariant)
            }
            token.startsWith("\"") || token.startsWith("'") -> SpanStyle(color = ArixTertiary)
            token.startsWith("$") -> SpanStyle(color = ArixPrimary)
            token.startsWith("-") -> SpanStyle(color = ArixSecondary)
            token.startsWith("/") || token.startsWith("~/") || token.startsWith("./") || token.startsWith("../") -> SpanStyle(color = ArixSecondary)
            expectsCommand -> {
                expectsCommand = false
                SpanStyle(color = ArixPrimary, fontWeight = FontWeight.SemiBold)
            }
            token.all(Char::isDigit) -> SpanStyle(color = ArixTertiary)
            else -> SpanStyle(color = ArixOnSurface)
        }
        appendStyled(token, style)
    }
}

internal fun highlightToolResult(result: String): AnnotatedString = buildAnnotatedString {
    val tokenPattern = Regex("""\s+|~?/[\w./-]+|\b\d+\b|[A-Za-z_][A-Za-z0-9_]*:|[^\s]+""")

    tokenPattern.findAll(result).forEach { match ->
        val token = match.value
        val lowerToken = token.lowercase()
        val style = when {
            token.isBlank() -> null
            lowerToken.contains("error") ||
                lowerToken.contains("failed") ||
                lowerToken.contains("denied") -> SpanStyle(color = ArixError, fontWeight = FontWeight.Medium)
            lowerToken.startsWith("http://") ||
                lowerToken.startsWith("https://") ||
                token.startsWith("/") ||
                token.startsWith("~/") ||
                token.contains("/") -> SpanStyle(color = ArixSecondary)
            token.all(Char::isDigit) -> SpanStyle(color = ArixTertiary)
            token.endsWith(":") -> SpanStyle(color = ArixOnSurfaceVariant, fontWeight = FontWeight.Medium)
            else -> SpanStyle(color = ArixOnSurface)
        }
        appendStyled(token, style)
    }
}

private fun formatChromeTitle(
    context: Context,
    isRunning: Boolean,
    arguments: JSONObject?,
): String = when (arguments?.optString("action")?.trim()?.lowercase()) {
    "start" -> context.getString(
        if (isRunning) R.string.tool_title_starting_chrome else R.string.tool_title_started_chrome,
    )
    "status" -> context.getString(
        if (isRunning) R.string.tool_title_checking_chrome else R.string.tool_title_checked_chrome,
    )
    "navigate", "open" -> {
        val url = arguments?.optString("url").orEmpty().trim()
        if (url.isBlank()) {
            context.getString(
                if (isRunning) {
                    R.string.tool_title_navigating_chrome
                } else {
                    R.string.tool_title_navigated_chrome
                },
            )
        } else {
            context.getString(
                if (isRunning) {
                    R.string.tool_title_navigating_chrome_url
                } else {
                    R.string.tool_title_navigated_chrome_url
                },
                url.take(72) + if (url.length > 72) "..." else "",
            )
        }
    }
    "tap", "click" -> context.getString(
        if (isRunning) R.string.tool_title_tapping_chrome else R.string.tool_title_tapped_chrome,
    )
    "swipe", "scroll" -> context.getString(
        if (isRunning) R.string.tool_title_scrolling_chrome else R.string.tool_title_scrolled_chrome,
    )
    "text", "type" -> context.getString(
        if (isRunning) R.string.tool_title_typing_chrome else R.string.tool_title_typed_chrome,
    )
    "key" -> {
        val key = arguments?.optString("key").orEmpty().trim()
        if (key.isBlank()) {
            context.getString(
                if (isRunning) R.string.tool_title_pressing_chrome else R.string.tool_title_pressed_chrome,
            )
        } else {
            context.getString(
                if (isRunning) {
                    R.string.tool_title_pressing_chrome_key
                } else {
                    R.string.tool_title_pressed_chrome_key
                },
                key.take(32),
            )
        }
    }
    "back" -> context.getString(
        if (isRunning) R.string.tool_title_going_back_chrome else R.string.tool_title_went_back_chrome,
    )
    "forward" -> context.getString(
        if (isRunning) R.string.tool_title_going_forward_chrome else R.string.tool_title_went_forward_chrome,
    )
    "reload" -> context.getString(
        if (isRunning) R.string.tool_title_reloading_chrome else R.string.tool_title_reloaded_chrome,
    )
    "evaluate", "execute_js", "get_text", "get_page_info", "find_elements", "get_readable", "get_backbone", "wait_for_dom_stable" -> context.getString(
        if (isRunning) R.string.tool_title_evaluating_chrome else R.string.tool_title_evaluated_chrome,
    )
    "screenshot" -> context.getString(
        if (isRunning) R.string.tool_title_capturing_chrome else R.string.tool_title_captured_chrome,
    )
    "stop" -> context.getString(
        if (isRunning) R.string.tool_title_stopping_chrome else R.string.tool_title_stopped_chrome,
    )
    else -> context.getString(
        if (isRunning) R.string.tool_title_using_chrome else R.string.tool_title_used_chrome,
    )
}

/**
 * v2.4.2: human-readable summary of the MCP proxy tool call. Without this the
 * card showed a bare "mcp" (rendered "$ mcp") that looked like an empty shell
 * command. Mirrors the proxy tool's argument surface: tool/action + server.
 */
private fun summarizeMcpProxyCommand(arguments: JSONObject?): String {
    if (arguments == null) return "mcp"
    val tool = arguments.optString("tool").trim()
    if (tool.isNotBlank()) return "mcp call $tool"
    val action = arguments.optString("action").trim()
    val server = arguments.optString("server").trim()
    if (action.isNotBlank()) {
        return if (server.isNotBlank()) "mcp $action $server" else "mcp $action"
    }
    val query = arguments.optString("search").trim()
    if (query.isNotBlank()) return "mcp search $query"
    val describe = arguments.optString("describe").trim()
    if (describe.isNotBlank()) return "mcp describe $describe"
    if (server.isNotBlank()) return "mcp list $server"
    return "mcp"
}

private fun summarizeChromeCommand(arguments: JSONObject?): String {
    if (arguments == null) return "chrome"
    val action = arguments.optString("action").trim().ifBlank { "unknown" }
    return when (action.lowercase()) {
        "navigate", "open" -> "browser navigate ${arguments.optString("url").trim()}"
        "tap", "click" -> arguments.optString("selector").trim().ifBlank {
            "browser click x=${arguments.optString("x").trim()} y=${arguments.optString("y").trim()}"
        }.let { value -> if (value.startsWith("browser ")) value else "browser click $value" }
        "swipe", "scroll" -> "browser scroll"
        "key" -> "browser key ${arguments.optString("key").trim()}"
        "text", "type" -> "browser type"
        "evaluate", "execute_js" -> "browser execute_js"
        else -> "browser $action"
    }.trim()
}

internal fun highlightTerminalTranscript(result: String): AnnotatedString = buildAnnotatedString {
    result.lineSequence().forEachIndexed { index, line ->
        if (index > 0) append('\n')
        if (line.startsWith("$ ")) {
            append(highlightBashCommand(line.removePrefix("$ ")))
        } else {
            append(highlightToolResult(line))
        }
    }
}

private fun AnnotatedString.Builder.appendStyled(
    text: String,
    style: SpanStyle?,
) {
    if (style == null) {
        append(text)
        return
    }

    pushStyle(style)
    append(text)
    pop()
}

private fun formatAttachmentSize(bytes: Long): String = when {
    bytes >= 1024 * 1024 -> String.format("%.1f MB", bytes / (1024f * 1024f))
    bytes >= 1024 -> String.format("%.1f KB", bytes / 1024f)
    else -> "$bytes B"
}

private data class AttachmentTextPreview(
    val text: String,
    val isTruncated: Boolean,
)

private data class ToolInvocationDetail(
    val command: String,
    val result: String?,
)

private data class WebSourceMetadata(
    val domain: String,
    val url: String,
    val faviconUrl: String?,
)

private data class AgentModeReplayFrame(
    val previewPath: String,
    val width: Int,
    val height: Int,
    val cursorX: Int?,
    val cursorY: Int?,
    val overlayText: String,
    val completedAtUptimeMillis: Long,
    val toolTitle: String,
)

private data class AgentModeReplayTimeline(
    val frames: List<AgentModeReplayFrame>,
    val interleavedTextMessageIds: Set<String>,
    val firstFrameMessageIndex: Int,
)
