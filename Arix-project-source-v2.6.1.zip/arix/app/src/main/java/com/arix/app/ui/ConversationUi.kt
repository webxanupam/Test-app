package com.arix.app.ui

import android.graphics.BitmapFactory
import android.os.SystemClock
import androidx.compose.animation.AnimatedContent
import androidx.compose.foundation.Canvas
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.SizeTransform
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.MutableTransitionState
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateIntOffsetAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.WindowInsetsSides
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.ime
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.only
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.ArrowUpward
import androidx.compose.material.icons.rounded.AttachFile
import androidx.compose.material.icons.rounded.AddBox
import androidx.compose.material.icons.rounded.Analytics
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Cloud
import androidx.compose.material.icons.rounded.Compress
import androidx.compose.material.icons.rounded.Extension
import androidx.compose.material.icons.rounded.Image
import androidx.compose.material.icons.rounded.Menu
import androidx.compose.material.icons.rounded.Mic
import androidx.compose.material.icons.rounded.Stop
import androidx.compose.material.icons.automirrored.rounded.KeyboardArrowRight
import androidx.compose.material.icons.rounded.RadioButtonUnchecked
import androidx.compose.material.icons.rounded.Public
import androidx.compose.material.icons.rounded.Schedule
import androidx.compose.material.icons.rounded.Terminal
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.runtime.withFrameNanos
import androidx.compose.runtime.key
import androidx.compose.runtime.produceState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.draw.BlurredEdgeTreatment
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.asComposePath
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.painter.Painter
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.drawscope.scale
import androidx.compose.ui.input.nestedscroll.NestedScrollConnection
import androidx.compose.ui.input.nestedscroll.NestedScrollSource
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.boundsInRoot
import androidx.compose.ui.layout.boundsInWindow
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.PlatformTextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.text.style.LineHeightStyle
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.Velocity
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Popup
import androidx.compose.ui.window.PopupProperties
import androidx.core.graphics.PathParser
import com.arix.app.R
import com.arix.app.data.InstalledSkill
import com.arix.app.data.AppLanguage
import com.arix.app.data.AgentModeDisplayState
import com.arix.app.data.AlpineChromeViewerUrl
import com.arix.app.data.McpServerConfig
import com.arix.app.data.McpTransportConfig
import com.arix.app.data.ModelCatalogInfo
import com.arix.app.data.PendingSessionInput
import com.arix.app.data.ProviderModelOption
import com.arix.app.data.SessionExecutionState
import com.arix.app.data.SessionFollowUpMode
import com.arix.app.data.quickActionLabel
import com.arix.app.data.thinkingCatalogKey
import com.arix.app.platform.PlatformWebView
import com.arix.app.ui.theme.ArixBackground
import com.arix.app.ui.theme.ArixBackgroundGradientTop
import com.arix.app.ui.theme.ArixOnSurface
import com.arix.app.ui.theme.ArixOnSurfaceVariant
import com.arix.app.ui.theme.ArixPrimary
import com.arix.app.ui.theme.ArixOutlineSoft
import com.arix.app.ui.theme.ArixScrim
import com.arix.app.ui.theme.ArixSurface
import com.arix.app.ui.theme.ArixSurfaceHigh
import com.arix.app.ui.theme.ArixSurfaceHigher
import kotlinx.coroutines.launch
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.delay
import kotlin.math.roundToInt
import org.json.JSONObject
import java.time.ZoneId
import java.time.ZonedDateTime
import java.util.Locale

private sealed interface ConversationListItem {
    val key: String

    data class Message(
        val message: ChatMessage,
    ) : ConversationListItem {
        override val key: String = message.id
    }

    data class AssistantGroup(
        val messages: List<ChatMessage>,
    ) : ConversationListItem {
        override val key: String = messages.firstOrNull()?.responseGroupId
            ?: messages.firstOrNull()?.id
            ?: "assistant-group"
    }

    data class CompactStatus(
        val message: ChatMessage,
    ) : ConversationListItem {
        override val key: String = message.id
    }
}

private val ConversationTopFadeHeight = 42.dp
private val ComposerCardShape = RoundedCornerShape(26.dp)
private val ComposerFocusedCardShape = RoundedCornerShape(28.dp)
private val ComposerPlusMenuMaxHeight = 372.dp
private const val ComposerPopupActionDelayMillis = 240L
private const val MinimumWallClockMillis = 946_684_800_000L
private val ChatGptControlShadow = Color(0x14000000)
private val ChatGptComposerShadow = Color(0x18000000)

// Premium violet gradient used for primary composer actions (send / pause).
private val ComposerAccentBrush = Brush.linearGradient(
    listOf(
        Color(0xFF9D6BFF),
        Color(0xFF6E3FE8),
    ),
)
private val ChatGptMotionEasing = CubicBezierEasing(0.22f, 0.84f, 0.18f, 1f)

internal enum class PendingGenerationIndicator {
    None,
    Thinking,
    Status,
}

internal fun pendingGenerationIndicator(
    isSending: Boolean,
    pendingAssistantText: String,
    pendingStatusText: String,
    hasVisiblePendingReasoning: Boolean = false,
    hasVisiblePendingWork: Boolean = false,
    lastVisibleMessageAuthor: MessageAuthor? = null,
): PendingGenerationIndicator = when {
    !isSending -> PendingGenerationIndicator.None
    pendingStatusText.isNotBlank() -> PendingGenerationIndicator.Status
    hasVisiblePendingReasoning -> PendingGenerationIndicator.None
    hasVisiblePendingWork -> PendingGenerationIndicator.None
    lastVisibleMessageAuthor == MessageAuthor.Agent -> PendingGenerationIndicator.None
    pendingAssistantText.isBlank() -> PendingGenerationIndicator.Thinking
    else -> PendingGenerationIndicator.None
}

internal fun shouldRenderPendingGenerationBlock(
    isSending: Boolean,
    pendingResponseBlocks: List<AssistantResponseBlock>,
    pendingToolInvocations: List<ChatToolInvocation>,
    pendingStatusText: String,
    lastVisibleAgentText: String?,
): Boolean {
    val hasPendingContent = pendingResponseBlocks.isNotEmpty() ||
        pendingToolInvocations.isNotEmpty() ||
        isSending
    if (!hasPendingContent) return false

    val pendingText = pendingResponseBlocks.visibleText().trim()
    val lastAgentText = lastVisibleAgentText?.trim().orEmpty()
    val isCommittedTextEcho = pendingText.isNotBlank() &&
        lastAgentText.isNotBlank() &&
        pendingText == lastAgentText &&
        pendingToolInvocations.isEmpty() &&
        pendingStatusText.isBlank()
    return !isCommittedTextEcho
}

internal fun hasVisibleReasoningStatus(trace: ReasoningTrace): Boolean =
    trace.latestStatusText.isNotBlank() ||
        trace.rawText.isNotBlank() ||
        trace.hasTimelineContent ||
        trace.completedAtMillis != null

private fun topOverlayBodyGradient(): Brush = Brush.verticalGradient(
    colorStops = arrayOf(
        0.0f to ArixBackground.copy(alpha = 0.98f),
        0.28f to ArixBackground.copy(alpha = 0.92f),
        0.58f to ArixBackground.copy(alpha = 0.52f),
        0.82f to ArixBackground.copy(alpha = 0.18f),
        1.0f to Color.Transparent,
    )
)

private fun topOverlayTailGradient(): Brush = Brush.verticalGradient(
    colorStops = arrayOf(
        0.0f to ArixBackground.copy(alpha = 0.10f),
        0.42f to ArixBackground.copy(alpha = 0.04f),
        1.0f to Color.Transparent,
    )
)

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun ConversationScreen(
    conversationStateKey: String,
    messages: List<ChatMessage>,
    workspaceDirectory: String,
    pendingToolInvocations: List<ChatToolInvocation>,
    pendingToolInvocationStateKey: String,
    pendingResponseBlocks: List<AssistantResponseBlock>,
    pendingAssistantText: String,
    pendingStatusText: String,
    pendingStatusDetail: String,
    activeTurnStartedAtMillis: Long?,
    isCompacting: Boolean,
    pendingInputs: List<PendingSessionInput>,
    inputValue: String,
    draftAttachments: List<ChatAttachment>,
    modelOptions: List<ProviderModelOption>,
    modelCatalogInfo: Map<String, ModelCatalogInfo>,
    selectedModelKey: String,
    reasoningEffort: String,
    thinkingLevelsByProviderModel: Map<String, List<String>>,
    thinkingLevelClampsByProviderModel: Map<String, Map<String, String>>,
    availableSkills: List<InstalledSkill>,
    availableMcpServers: List<McpServerConfig>,
    selectedSkillIds: List<String>,
    selectedMcpServerIds: List<String>,
    agentModeAvailable: Boolean,
    agentModeSelected: Boolean,
    agentModeDisplayState: AgentModeDisplayState,
    chromeAvailable: Boolean,
    chromeSelected: Boolean,
    chromeDisplayState: AgentModeDisplayState,
    isEditing: Boolean,
    showStarterPromptHint: Boolean,
    voiceInputEnabled: Boolean = true,
    voiceInputState: com.arix.app.voice.ArixSystemSttEngine.State = com.arix.app.voice.ArixSystemSttEngine.State.Idle,
    voiceAudioLevel: Float = 0f,
    onStartVoiceInput: () -> Unit = {},
    onStopVoiceInput: () -> Unit = {},
    onVoiceTranscriptFinal: (String) -> Unit = {},
    onInputChanged: (String) -> Unit,
    onModelSelected: (String, (Boolean) -> Unit) -> Unit,
    onModelSelectorOpened: () -> Unit,
    onReasoningEffortSelected: (String) -> Unit,
    onRemoveDraftAttachment: (String) -> Unit,
    onSetSkillSelected: (String, Boolean) -> Unit,
    onSetMcpServerSelected: (String, Boolean) -> Unit,
    onSetAgentModeSelected: (Boolean) -> Unit,
    onSetChromeSelected: (Boolean) -> Unit,
    onCancelEdit: () -> Unit,
    onSend: () -> Unit,
    onQueueFollowUp: () -> Unit,
    onSteerFollowUp: () -> Unit,
    onMenu: () -> Unit,
    onNewChat: () -> Unit,
    onPickImages: () -> Unit,
    onPickFiles: () -> Unit,
    onSaveAttachment: (ChatAttachment) -> Unit,
    onOpenLink: (String) -> Unit,
    onEditMessage: (String) -> Unit,
    onDeleteMessage: (String) -> Unit,
    onRedoAgentMessage: (String) -> Unit,
    onRetryUserMessage: (String) -> Unit,
    onSwitchUserMessageBranch: (String, Int) -> Unit,
    onCopyMessage: (ChatMessage) -> Unit,
    onPauseGeneration: () -> Unit,
    onDismissStarterPromptHint: () -> Unit,
    isSending: Boolean,
    /** Extra bottom padding so the composer clears the floating bottom nav. */
    bottomBarReserve: Dp = 0.dp,
) {
    val listState = rememberSaveable(
        conversationStateKey,
        saver = LazyListState.Saver,
    ) {
        LazyListState()
    }
    // Workspace files live in app-private storage on the host, so every
    // workspace image can be read directly without elevated access.
    val allowRootImageRead = true
    val conversationItems = remember(messages) { buildConversationListItems(messages) }
    val compactSuggestion = remember(messages) { compactCommandSuggestion(messages) }
    val sessionTotalTokens = remember(messages) {
        messages.sumOf { message -> message.usageStatistics?.totalTokens ?: 0L }
            .takeIf { it > 0L }
    }
    val compactSuggestionText = compactSuggestion.percent?.let { percent ->
        stringResource(R.string.chat_compact_thread_context_percent, percent)
    } ?: stringResource(R.string.chat_compact_thread_context)
    val lastVisibleMessageAuthor = remember(messages) {
        messages.lastOrNull { message ->
            message.displayKind == MessageDisplayKind.Standard
        }?.author
    }
    val lastVisibleAgentText = remember(messages) {
        messages.lastOrNull { message ->
            message.displayKind == MessageDisplayKind.Standard &&
                message.author == MessageAuthor.Agent
        }?.text
    }
    var previewAttachment by remember { mutableStateOf<ChatAttachment?>(null) }
    var shouldAutoFollow by rememberSaveable(conversationStateKey) { mutableStateOf(true) }
    var topBarBodyHeightPx by remember { mutableIntStateOf(0) }
    var composerBodyHeightPx by remember { mutableIntStateOf(0) }
    var pendingGenerationHeightPx by remember { mutableIntStateOf(0) }
    var composerFocused by remember { mutableStateOf(false) }
    val density = LocalDensity.current
    val fallbackTopBarBodyHeight = with(density) {
        WindowInsets.statusBars.getTop(this).toDp() + 68.dp
    }
    val topBarBodyHeight = with(density) {
        if (topBarBodyHeightPx > 0) topBarBodyHeightPx.toDp() else fallbackTopBarBodyHeight
    }
    val composerBodyHeight = with(density) {
        if (composerBodyHeightPx > 0) composerBodyHeightPx.toDp() else 112.dp
    }
    val imeBottom = with(density) {
        WindowInsets.ime.getBottom(this).toDp()
    }
    val animatedImeBottom by animateDpAsState(
        targetValue = imeBottom,
        animationSpec = tween(durationMillis = 260, easing = ChatGptMotionEasing),
        label = "conversation_empty_ime_bottom",
    )
    val animatedImeBottomPx = with(density) { animatedImeBottom.roundToPx() }
    // The bottom nav hides while the IME is open — collapse the reserve too.
    val effectiveNavReserve = if (imeBottom > 0.dp) 0.dp else bottomBarReserve
    val conversationScrollConnection = remember(listState) {
        object : NestedScrollConnection {
            override fun onPostScroll(
                consumed: Offset,
                available: Offset,
                source: NestedScrollSource,
            ): Offset {
                if (source == NestedScrollSource.UserInput) {
                    shouldAutoFollow = listState.isAtConversationBottom()
                }
                return Offset.Zero
            }

            override suspend fun onPostFling(consumed: Velocity, available: Velocity): Velocity {
                shouldAutoFollow = listState.isAtConversationBottom()
                return Velocity.Zero
            }
        }
    }

    suspend fun scrollToConversationBottom() {
        val lastItemIndex = listState.layoutInfo.totalItemsCount - 1
        if (lastItemIndex >= 0) {
            listState.scrollToItem(lastItemIndex)
        }
    }

    LaunchedEffect(listState, shouldAutoFollow, animatedImeBottomPx, composerBodyHeightPx) {
        if (!shouldAutoFollow) return@LaunchedEffect
        snapshotFlow {
            val layoutInfo = listState.layoutInfo
            val lastVisibleItem = layoutInfo.visibleItemsInfo.lastOrNull()
            listOf(
                layoutInfo.totalItemsCount,
                lastVisibleItem?.index ?: -1,
                lastVisibleItem?.offset ?: 0,
                lastVisibleItem?.size ?: 0,
            )
        }
            .distinctUntilChanged()
            .collect {
                if (
                    shouldAutoFollow &&
                    !listState.isScrollInProgress &&
                    listState.layoutInfo.totalItemsCount > 0
                ) {
                    scrollToConversationBottom()
                }
            }
    }
    val autoFollowContentKey = remember(
        conversationItems,
        pendingInputs,
        pendingResponseBlocks,
        pendingAssistantText,
        pendingToolInvocations,
        pendingStatusText,
        pendingStatusDetail,
        isCompacting,
        isSending,
    ) {
        buildString {
            append(conversationItems.lastOrNull()?.key.orEmpty())
            append('|')
            append(pendingInputs.joinToString("|") { "${it.id}:${it.preview.length}:${it.attachmentCount}" })
            append('|')
            append(
                pendingResponseBlocks.joinToString("|") { block ->
                    when (block) {
                        is AssistantResponseBlock.Text -> "${block.id}:text:${block.text.length}"
                        is AssistantResponseBlock.ToolGroup -> block.toolInvocations.joinToString(
                            prefix = "${block.id}:tools:",
                            separator = ",",
                        ) { invocation ->
                            "${invocation.id}:${invocation.isRunning}:${invocation.outputJson.length}"
                        }
                        is AssistantResponseBlock.Reasoning -> buildString {
                            append("${block.id}:reasoning:")
                            append(block.trace.rawText.length)
                            append(':')
                            append(block.trace.latestStatusText.length)
                            append(':')
                            append(block.trace.completedAtMillis ?: 0L)
                            append(':')
                            append(block.trace.chunks.joinToString(",") { chunk ->
                                "${chunk.id}:${chunk.title.length}:${chunk.detail.length}:${chunk.isPending}:${chunk.timelineOrder}"
                            })
                            append(':')
                            append(block.trace.toolInvocations.joinToString(",") { invocation ->
                                "${invocation.id}:${invocation.isRunning}:${invocation.outputJson.length}:${invocation.startedAtMillis}:${invocation.completedAtMillis ?: 0L}:${invocation.timelineOrder}"
                            })
                        }
                        is AssistantResponseBlock.Status ->
                            "${block.id}:status:${block.text}:${block.detail}"
                    }
                }
            )
            append('|')
            append(pendingAssistantText.length)
            append('|')
            append(
                pendingToolInvocations.joinToString("|") { invocation ->
                    "${invocation.id}:${invocation.isRunning}:${invocation.outputJson.length}"
                }
            )
            append('|')
            append(pendingStatusText)
            append('|')
            append(pendingStatusDetail)
            append('|')
            append(isCompacting)
            append('|')
            append(isSending)
        }
    }
    LaunchedEffect(
        autoFollowContentKey,
        pendingGenerationHeightPx,
        animatedImeBottomPx,
        composerBodyHeightPx,
        shouldAutoFollow,
    ) {
        if (!shouldAutoFollow || listState.layoutInfo.totalItemsCount == 0) return@LaunchedEffect
        withFrameNanos { }
        if (shouldAutoFollow && !listState.isScrollInProgress) {
            scrollToConversationBottom()
        }
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        containerColor = ArixBackground,
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        listOf(ArixBackgroundGradientTop, ArixBackground, ArixSurface)
                    )
                )
                .padding(innerPadding)
        ) {
            if (messages.isEmpty()) {
                ArixExtensionSlot(
                    slot = ArixExtensionSlotChatEmpty,
                    modifier = Modifier
                        .align(Alignment.TopCenter)
                        .fillMaxWidth()
                        .padding(
                            start = 20.dp,
                            end = 20.dp,
                            top = topBarBodyHeight + 12.dp,
                        ),
                )
                IstGreetingHeader(
                    modifier = Modifier
                        .align(Alignment.Center)
                        .fillMaxWidth()
                        .padding(
                            start = 22.dp,
                            end = 22.dp,
                            top = topBarBodyHeight,
                            bottom = composerBodyHeight + effectiveNavReserve + 26.dp,
                        ),
                    dimmed = composerFocused,
                )
            } else {
                LazyColumn(
                    state = listState,
                    modifier = Modifier
                        .fillMaxSize()
                        .nestedScroll(conversationScrollConnection),
                    contentPadding = PaddingValues(
                        start = 20.dp,
                        end = 20.dp,
                        top = topBarBodyHeight + 10.dp,
                        bottom = composerBodyHeight + effectiveNavReserve + animatedImeBottom + 28.dp,
                    ),
                    verticalArrangement = Arrangement.spacedBy(22.dp),
                ) {
                    item(key = "arix-extension-chat-list-start") {
                        ArixExtensionSlot(ArixExtensionSlotChatListStart)
                    }
                    items(conversationItems, key = { it.key }) { item ->
                        when (item) {
                            is ConversationListItem.Message -> {
                                val message = item.message
                                ConversationMessageBubble(
                                    message = message,
                                    actionsEnabled = !isSending,
                                    workspaceDirectory = workspaceDirectory,
                                    allowRootImageRead = allowRootImageRead,
                                    onOpenAttachment = { previewAttachment = it },
                                    onOpenLink = onOpenLink,
                                    onEdit = { onEditMessage(message.id) },
                                    onDelete = { onDeleteMessage(message.id) },
                                    onCopy = { onCopyMessage(message) },
                                    onRedo = { onRedoAgentMessage(message.id) },
                                    onRetry = { onRetryUserMessage(message.id) },
                                    onSwitchBranch = { delta -> onSwitchUserMessageBranch(message.id, delta) },
                                    sessionTotalTokens = sessionTotalTokens,
                                )
                            }

                            is ConversationListItem.AssistantGroup -> {
                                val lastMessage = item.messages.last()
                                ConversationAssistantGroupBubble(
                                    messages = item.messages,
                                    actionsEnabled = !isSending,
                                    workspaceDirectory = workspaceDirectory,
                                    allowRootImageRead = allowRootImageRead,
                                    onOpenAttachment = { previewAttachment = it },
                                    onOpenLink = onOpenLink,
                                    onCopy = {
                                        onCopyMessage(
                                            lastMessage.copy(
                                                text = item.messages.joinToString("\n\n") { message -> message.text }
                                                    .trim(),
                                            )
                                        )
                                    },
                                    onRedo = { onRedoAgentMessage(lastMessage.id) },
                                    onDelete = { onDeleteMessage(lastMessage.id) },
                                    sessionTotalTokens = sessionTotalTokens,
                                )
                            }

                            is ConversationListItem.CompactStatus -> {
                                CompactStatusDivider(text = item.message.text.ifBlank { stringResource(R.string.chat_context_compacted) })
                            }
                        }
                    }
                    if (isCompacting) {
                        item(key = "compact-running-status") {
                            CompactStatusDivider(
                                text = stringResource(R.string.chat_compacting_context),
                                isRunning = true,
                            )
                        }
                    }
                    if (
                        shouldRenderPendingGenerationBlock(
                            isSending = isSending,
                            pendingResponseBlocks = pendingResponseBlocks,
                            pendingToolInvocations = pendingToolInvocations,
                            pendingStatusText = pendingStatusText,
                            lastVisibleAgentText = lastVisibleAgentText,
                        )
                    ) {
                        item(key = "pending-generation-block") {
                            val indicator = pendingGenerationIndicator(
                                isSending = isSending,
                                pendingAssistantText = pendingAssistantText,
                                pendingStatusText = pendingStatusText,
                                hasVisiblePendingWork = pendingResponseBlocks.hasVisiblePendingWork() ||
                                    pendingToolInvocations.isNotEmpty(),
                                lastVisibleMessageAuthor = lastVisibleMessageAuthor,
                                hasVisiblePendingReasoning = pendingResponseBlocks.any {
                                    it is AssistantResponseBlock.Reasoning &&
                                        hasVisibleReasoningStatus(it.trace)
                                },
                            )
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .onSizeChanged { pendingGenerationHeightPx = it.height }
                                    .animateContentSize(),
                                verticalArrangement = Arrangement.spacedBy(10.dp),
                            ) {
                                PendingAssistantTimeline(
                                    blocks = pendingResponseBlocks,
                                    workspaceDirectory = workspaceDirectory,
                                    allowRootImageRead = allowRootImageRead,
                                    onOpenLink = onOpenLink,
                                    pendingToolInvocationStateKey = pendingToolInvocationStateKey,
                                    pendingToolInvocations = pendingToolInvocations,
                                    activeTurnStartedAtMillis = activeTurnStartedAtMillis,
                                    agentModeSelected = agentModeSelected,
                                    agentModeDisplayState = agentModeDisplayState,
                                    chromeSelected = chromeSelected,
                                    chromeDisplayState = chromeDisplayState,
                                )
                                when (indicator) {
                                    PendingGenerationIndicator.Thinking -> {
                                        ConversationThinkingIndicator()
                                    }

                                    PendingGenerationIndicator.Status -> {
                                        ReconnectingStatusCard(
                                            text = pendingStatusText,
                                            detail = pendingStatusDetail,
                                            isRunning = true,
                                            modifier = Modifier.padding(top = 6.dp),
                                        )
                                    }

                                    PendingGenerationIndicator.None -> Unit
                                }
                            }
                        }
                    }
                    items(pendingInputs, key = { it.id }) { pendingInput ->
                        PendingSessionInputBubble(pendingInput = pendingInput)
                    }
                    item(key = "arix-extension-chat-list-end") {
                        ArixExtensionSlot(ArixExtensionSlotChatListEnd)
                    }
                    item(key = "conversation-bottom-anchor") {
                        Spacer(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(1.dp)
                        )
                    }
                }
            }

            ConversationTopOverlay(
                modifier = Modifier.align(Alignment.TopCenter),
                onBodyHeightChanged = { topBarBodyHeightPx = it },
                modelOptions = modelOptions,
                modelCatalogInfo = modelCatalogInfo,
                selectedModelKey = selectedModelKey,
                reasoningEffort = reasoningEffort,
                thinkingLevelsByProviderModel = thinkingLevelsByProviderModel,
                thinkingLevelClampsByProviderModel = thinkingLevelClampsByProviderModel,
                onMenu = onMenu,
                onModelSelected = onModelSelected,
                onModelSelectorOpened = onModelSelectorOpened,
                onReasoningEffortSelected = onReasoningEffortSelected,
                onNewChat = onNewChat,
            )

            ConversationComposerOverlay(
                modifier = Modifier.align(Alignment.BottomCenter),
                conversationStateKey = conversationStateKey,
                onBodyHeightChanged = { composerBodyHeightPx = it },
                bottomBarReserve = effectiveNavReserve,
                value = inputValue,
                attachments = draftAttachments,
                availableSkills = availableSkills,
                availableMcpServers = availableMcpServers,
                selectedSkillIds = selectedSkillIds,
                selectedMcpServerIds = selectedMcpServerIds,
                agentModeAvailable = agentModeAvailable,
                agentModeSelected = agentModeSelected,
                chromeAvailable = chromeAvailable,
                chromeSelected = chromeSelected,
                isEditing = isEditing,
                isSending = isSending,
                showStarterPromptHint = showStarterPromptHint,
                compactSuggestionText = compactSuggestionText,
                voiceInputEnabled = voiceInputEnabled,
                voiceInputState = voiceInputState,
                voiceAudioLevel = voiceAudioLevel,
                onStartVoiceInput = onStartVoiceInput,
                onStopVoiceInput = onStopVoiceInput,
                onVoiceTranscriptFinal = onVoiceTranscriptFinal,
                onValueChange = onInputChanged,
                onRemoveAttachment = onRemoveDraftAttachment,
                onSetSkillSelected = onSetSkillSelected,
                onSetMcpServerSelected = onSetMcpServerSelected,
                onSetAgentModeSelected = onSetAgentModeSelected,
                onSetChromeSelected = onSetChromeSelected,
                onCancelEdit = onCancelEdit,
                onPickImages = onPickImages,
                onPickFiles = onPickFiles,
                onPauseGeneration = onPauseGeneration,
                onDismissStarterPromptHint = onDismissStarterPromptHint,
                onFocusChanged = { composerFocused = it },
                onSend = onSend,
                onQueueFollowUp = onQueueFollowUp,
                onSteerFollowUp = onSteerFollowUp,
            )

            previewAttachment?.let { attachment ->
                AttachmentPreviewDialog(
                    attachment = attachment,
                    onDismiss = { previewAttachment = null },
                    onSave = { onSaveAttachment(attachment) },
                )
            }
        }
    }
}

private fun LazyListState.isAtConversationBottom(): Boolean {
    val layoutInfo = layoutInfo
    if (layoutInfo.totalItemsCount == 0) return true
    val lastVisibleItem = layoutInfo.visibleItemsInfo.lastOrNull() ?: return true
    val isLastItemVisible = lastVisibleItem.index == layoutInfo.totalItemsCount - 1
    val distanceFromBottom = layoutInfo.viewportEndOffset - (lastVisibleItem.offset + lastVisibleItem.size)
    return isLastItemVisible && distanceFromBottom >= -32
}

@Composable
private fun ConversationTopOverlay(
    modifier: Modifier = Modifier,
    onBodyHeightChanged: (Int) -> Unit,
    modelOptions: List<ProviderModelOption>,
    modelCatalogInfo: Map<String, ModelCatalogInfo>,
    selectedModelKey: String,
    reasoningEffort: String,
    thinkingLevelsByProviderModel: Map<String, List<String>>,
    thinkingLevelClampsByProviderModel: Map<String, Map<String, String>>,
    onMenu: () -> Unit,
    onModelSelected: (String, (Boolean) -> Unit) -> Unit,
    onModelSelectorOpened: () -> Unit,
    onReasoningEffortSelected: (String) -> Unit,
    onNewChat: () -> Unit,
) {
    Column(
        modifier = modifier.fillMaxWidth(),
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(topOverlayBodyGradient())
                .onSizeChanged { onBodyHeightChanged(it.height) },
        ) {
            Column {
                ConversationTopBar(
                    modelOptions = modelOptions,
                    modelCatalogInfo = modelCatalogInfo,
                    selectedModelKey = selectedModelKey,
                    reasoningEffort = reasoningEffort,
                    thinkingLevelsByProviderModel = thinkingLevelsByProviderModel,
                    thinkingLevelClampsByProviderModel = thinkingLevelClampsByProviderModel,
                    onMenu = onMenu,
                    onModelSelected = onModelSelected,
                    onModelSelectorOpened = onModelSelectorOpened,
                    onReasoningEffortSelected = onReasoningEffortSelected,
                    onNewChat = onNewChat,
                )
                ArixExtensionSlot(
                    slot = ArixExtensionSlotChatTop,
                    modifier = Modifier.padding(horizontal = 20.dp),
                )
            }
        }
        Spacer(
            modifier = Modifier
                .fillMaxWidth()
                .height(ConversationTopFadeHeight)
                .background(topOverlayTailGradient())
        )
    }
}

@Composable
private fun ConversationTopBar(
    modifier: Modifier = Modifier,
    modelOptions: List<ProviderModelOption>,
    modelCatalogInfo: Map<String, ModelCatalogInfo>,
    selectedModelKey: String,
    reasoningEffort: String,
    thinkingLevelsByProviderModel: Map<String, List<String>>,
    thinkingLevelClampsByProviderModel: Map<String, Map<String, String>>,
    onMenu: () -> Unit,
    onModelSelected: (String, (Boolean) -> Unit) -> Unit,
    onModelSelectorOpened: () -> Unit,
    onReasoningEffortSelected: (String) -> Unit,
    onNewChat: () -> Unit,
) {
    ArixConversationTopBarFrame(
        modifier = modifier
            .fillMaxWidth()
            .statusBarsPadding(),
        menuDescription = stringResource(R.string.common_menu),
        newChatDescription = stringResource(R.string.common_new_chat),
        onMenu = onMenu,
        onNewChat = onNewChat,
    ) {
        ConversationModelSelector(
            options = modelOptions,
            modelCatalogInfo = modelCatalogInfo,
            selectedModelKey = selectedModelKey,
            reasoningEffort = reasoningEffort,
            thinkingLevelsByProviderModel = thinkingLevelsByProviderModel,
            thinkingLevelClampsByProviderModel = thinkingLevelClampsByProviderModel,
            onSelected = onModelSelected,
            onOpened = onModelSelectorOpened,
            onReasoningEffortSelected = onReasoningEffortSelected,
            modifier = Modifier.fillMaxWidth(),
        )
    }
}

@Composable
private fun ConversationModelSelector(
    options: List<ProviderModelOption>,
    modelCatalogInfo: Map<String, ModelCatalogInfo>,
    selectedModelKey: String,
    reasoningEffort: String,
    thinkingLevelsByProviderModel: Map<String, List<String>>,
    thinkingLevelClampsByProviderModel: Map<String, Map<String, String>>,
    onSelected: (String, (Boolean) -> Unit) -> Unit,
    onOpened: () -> Unit,
    onReasoningEffortSelected: (String) -> Unit,
    modifier: Modifier = Modifier,
) {
    var expanded by remember { mutableStateOf(false) }
    var showingReasoningEffort by remember { mutableStateOf(false) }
    var menuSelectedModelKey by remember { mutableStateOf(selectedModelKey) }
    var anchorHeightPx by remember { mutableIntStateOf(0) }
    val menuVisibility = remember { MutableTransitionState(false) }
    menuVisibility.targetState = expanded
    val density = LocalDensity.current
    val menuWidth = 242.dp
    val selectedOption = options.firstOrNull { it.key == menuSelectedModelKey } ?: options.firstOrNull()
    val supportedThinkingLevels = selectedOption?.let { option ->
        thinkingLevelsByProviderModel[thinkingCatalogKey(option.piProviderId, option.modelId)]
    }.orEmpty()
    val effectiveReasoningEffort = selectedOption?.let { option ->
        thinkingLevelClampsByProviderModel[thinkingCatalogKey(option.piProviderId, option.modelId)]
            ?.get(reasoningEffort)
    } ?: reasoningEffort
    val fallbackLabel = stringResource(R.string.chat_select_model)
    val selectedDisplay = remember(selectedOption, modelCatalogInfo) {
        selectedOption?.let { option ->
            formatSelectedModelDisplayName(
                rawName = modelCatalogInfo[option.key]?.displayName ?: option.modelId,
            )
        }
    }
    val selectedModelName = selectedDisplay
        ?.let { display -> listOf(display.primary, display.secondary).filter(String::isNotBlank) }
        ?.joinToString(" ")
        ?.takeIf(String::isNotBlank)
        ?: selectedOption?.chatLabel
        ?: fallbackLabel

    Box(
        modifier = modifier,
        contentAlignment = Alignment.CenterStart,
    ) {
        Box(
            modifier = Modifier.height(38.dp)
                .onGloballyPositioned { coordinates ->
                    val bounds = coordinates.boundsInWindow()
                    anchorHeightPx = bounds.height.toInt()
                },
        ) {
            Box(
                modifier = Modifier.matchParentSize()
                    .offset(y = 4.dp)
                    .blur(14.dp, edgeTreatment = BlurredEdgeTreatment.Unbounded)
                    .clip(RoundedCornerShape(999.dp))
                    .background(ChatGptControlShadow),
            )
            Row(
                modifier = Modifier.height(38.dp)
                    .clip(RoundedCornerShape(999.dp))
                    .background(ArixSurface.copy(alpha = 0.96f))
                    .clickable(enabled = options.isNotEmpty()) {
                        onOpened()
                        menuSelectedModelKey = selectedModelKey
                        showingReasoningEffort = false
                        expanded = true
                },
                verticalAlignment = Alignment.CenterVertically,
            ) {
                if (selectedDisplay != null) {
                    SelectedModelDisplay(
                        displayName = selectedDisplay,
                        modifier = Modifier
                            .widthIn(max = 240.dp)
                            .padding(horizontal = 17.dp),
                    )
                } else {
                    Text(
                        text = fallbackLabel,
                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Normal),
                        color = ArixOnSurface,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier
                            .widthIn(max = 220.dp)
                            .padding(horizontal = 17.dp),
                    )
                }
            }
        }

        if (menuVisibility.currentState || menuVisibility.targetState) {
            Popup(
                alignment = Alignment.TopStart,
                offset = IntOffset(0, anchorHeightPx + with(density) { 10.dp.roundToPx() }),
                onDismissRequest = { expanded = false },
                properties = PopupProperties(
                    focusable = true,
                    dismissOnBackPress = true,
                    dismissOnClickOutside = true,
                ),
            ) {
                androidx.compose.animation.AnimatedVisibility(
                    visibleState = menuVisibility,
                    enter = fadeIn() + scaleIn(
                        initialScale = 0.96f,
                        transformOrigin = TransformOrigin(0.5f, 0f),
                    ) + slideInVertically(initialOffsetY = { -it / 10 }),
                    exit = fadeOut() + scaleOut(
                        targetScale = 0.98f,
                        transformOrigin = TransformOrigin(0.5f, 0f),
                    ) + slideOutVertically(targetOffsetY = { -it / 12 }),
                ) {
                    AnimatedContent(
                        targetState = showingReasoningEffort && supportedThinkingLevels.isNotEmpty(),
                        transitionSpec = {
                            val enteringOffset: (Int) -> Int = { width ->
                                if (targetState) width / 10 else -width / 10
                            }
                            val exitingOffset: (Int) -> Int = { width ->
                                if (targetState) -width / 10 else width / 10
                            }
                            (
                                fadeIn(
                                    animationSpec = tween(
                                        durationMillis = 220,
                                        delayMillis = 60,
                                        easing = ChatGptMotionEasing,
                                    ),
                                ) + slideInHorizontally(
                                    animationSpec = tween(
                                        durationMillis = 340,
                                        easing = ChatGptMotionEasing,
                                    ),
                                    initialOffsetX = enteringOffset,
                                )
                            ).togetherWith(
                                fadeOut(
                                    animationSpec = tween(
                                        durationMillis = 150,
                                        easing = ChatGptMotionEasing,
                                    ),
                                ) + slideOutHorizontally(
                                    animationSpec = tween(
                                        durationMillis = 280,
                                        easing = ChatGptMotionEasing,
                                    ),
                                    targetOffsetX = exitingOffset,
                                )
                            ).using(
                                SizeTransform(clip = false) { _, _ ->
                                    tween(
                                        durationMillis = 360,
                                        easing = ChatGptMotionEasing,
                                    )
                                }
                            )
                        },
                        modifier = Modifier
                            .width(menuWidth)
                            .shadow(14.dp, RoundedCornerShape(22.dp), ambientColor = ArixScrim, spotColor = ArixScrim)
                            .clip(RoundedCornerShape(22.dp))
                            .background(ArixSurface)
                            .padding(vertical = 5.dp),
                        label = "conversation-model-menu-mode",
                    ) {
                        if (it) {
                            ConversationReasoningEffortMenu(
                                efforts = supportedThinkingLevels,
                                selectedEffort = effectiveReasoningEffort,
                                selectedModelName = selectedModelName,
                                onBack = { showingReasoningEffort = false },
                                onSelected = { effort ->
                                    onReasoningEffortSelected(effort)
                                    expanded = false
                                },
                            )
                        } else {
                            ConversationModelListMenu(
                                options = options,
                                modelCatalogInfo = modelCatalogInfo,
                                selectedOption = selectedOption,
                                reasoningEffort = effectiveReasoningEffort,
                                showReasoningEffort = supportedThinkingLevels.isNotEmpty(),
                                onReasoningEffortClick = { showingReasoningEffort = true },
                                onSelected = { option ->
                                    menuSelectedModelKey = option.key
                                    onSelected(option.key) { hasThinkingLevels ->
                                        if (expanded && menuSelectedModelKey == option.key) {
                                            if (hasThinkingLevels) {
                                                showingReasoningEffort = true
                                            } else {
                                                expanded = false
                                            }
                                        }
                                    }
                                },
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun reasoningEffortLabel(effort: String): String = when (effort.trim().lowercase()) {
    "off" -> stringResource(R.string.chat_reasoning_effort_off)
    "minimal" -> stringResource(R.string.chat_reasoning_effort_minimal)
    "low" -> stringResource(R.string.chat_reasoning_effort_low)
    "medium" -> stringResource(R.string.chat_reasoning_effort_medium)
    "high" -> stringResource(R.string.chat_reasoning_effort_high)
    "xhigh" -> stringResource(R.string.chat_reasoning_effort_xhigh)
    "max" -> stringResource(R.string.chat_reasoning_effort_max)
    else -> effort.trim().replaceFirstChar { it.titlecase() }
}

@Composable
private fun ConversationMenuModeEntry(
    title: String,
    value: String,
    onClick: () -> Unit,
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(start = 19.dp, end = 14.dp, top = 10.dp, bottom = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column {
            Text(
                text = title,
                style = MaterialTheme.typography.bodyMedium,
                color = ArixOnSurface,
            )
            Text(
                text = value,
                style = MaterialTheme.typography.bodySmall,
                color = ArixOnSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }
    }
}

@Composable
private fun ConversationReasoningEffortMenu(
    efforts: List<String>,
    selectedEffort: String,
    selectedModelName: String,
    onBack: () -> Unit,
    onSelected: (String) -> Unit,
) {
    Column(
        horizontalAlignment = Alignment.Start,
    ) {
        ConversationMenuModeEntry(
            title = stringResource(R.string.chat_model),
            value = selectedModelName,
            onClick = onBack,
        )
        efforts.forEach { effort ->
            val selected = effort == selectedEffort
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 5.dp, vertical = 1.dp)
                    .clip(RoundedCornerShape(15.dp))
                    .background(
                        if (selected) ArixOnSurface.copy(alpha = 0.06f) else Color.Transparent,
                    )
                    .clickable { onSelected(effort) }
                    .padding(horizontal = 14.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(
                    text = reasoningEffortLabel(effort),
                    style = MaterialTheme.typography.bodyMedium,
                    color = ArixOnSurface,
                    modifier = Modifier.weight(1f),
                )
                if (selected) {
                    Icon(
                        imageVector = Icons.Rounded.Check,
                        contentDescription = null,
                        tint = ArixOnSurfaceVariant,
                        modifier = Modifier.size(16.dp),
                    )
                }
            }
        }
    }
}

@Composable
private fun ConversationModelListMenu(
    options: List<ProviderModelOption>,
    modelCatalogInfo: Map<String, ModelCatalogInfo>,
    selectedOption: ProviderModelOption?,
    reasoningEffort: String,
    showReasoningEffort: Boolean,
    onReasoningEffortClick: () -> Unit,
    onSelected: (ProviderModelOption) -> Unit,
) {
    Column(
        horizontalAlignment = Alignment.Start,
    ) {
        if (showReasoningEffort) {
            ConversationMenuModeEntry(
                title = stringResource(R.string.chat_reasoning_effort),
                value = reasoningEffortLabel(reasoningEffort),
                onClick = onReasoningEffortClick,
            )
        }
        Column(
            modifier = Modifier
                .heightIn(max = 312.dp)
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.Start,
        ) {
            options.forEach { option ->
                ConversationModelMenuRow(
                    label = option.chatLabel,
                    catalogInfo = modelCatalogInfo[option.key],
                    selected = option.key == selectedOption?.key,
                    onClick = { onSelected(option) },
                )
            }
        }
    }
}

@Composable
private fun ConversationModelMenuRow(
    label: String,
    catalogInfo: ModelCatalogInfo?,
    selected: Boolean,
    onClick: () -> Unit,
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 5.dp, vertical = 1.dp)
            .clip(RoundedCornerShape(15.dp))
            .background(if (selected) ArixOnSurface.copy(alpha = 0.06f) else Color.Transparent)
            .clickable(onClick = onClick)
            .padding(horizontal = 9.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(9.dp),
    ) {
        LabLogoBadge(
            catalogInfo = catalogInfo,
            modifier = Modifier.size(22.dp),
        )
        Text(
            text = label,
            style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Normal),
            color = ArixOnSurface,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            textAlign = TextAlign.Start,
            modifier = Modifier.weight(1f),
        )
        if (selected) {
            Icon(
                imageVector = Icons.Rounded.Check,
                contentDescription = null,
                tint = ArixOnSurfaceVariant,
                modifier = Modifier.size(16.dp),
            )
        }
    }
}

@Composable
private fun LabLogoBadge(
    catalogInfo: ModelCatalogInfo?,
    modifier: Modifier = Modifier,
) {
    val info = catalogInfo
    val logoPaths = remember(catalogInfo) {
        info?.toLabLogoPaths().orEmpty()
    }
    if (info != null && logoPaths.isNotEmpty()) {
        Canvas(
            modifier = modifier,
        ) {
            val scaleX = size.width / info.labLogoViewportWidth
            val scaleY = size.height / info.labLogoViewportHeight
            scale(scaleX = scaleX, scaleY = scaleY, pivot = Offset.Zero) {
                logoPaths.forEach { path ->
                    drawPath(path = path, color = labLogoTint())
                }
            }
        }
        return
    }
    Box(
        modifier = modifier,
    )
}

private fun ModelCatalogInfo.toLabLogoPaths(): List<Path> {
    if (labLogoPathData.isEmpty()) return emptyList()
    return labLogoPathData.mapNotNull { pathData ->
        runCatching {
            PathParser.createPathFromPathData(pathData).asComposePath()
        }.getOrNull()
    }
}

private fun labLogoTint(): Color = ArixOnSurface

@Composable
private fun SelectedModelDisplay(
    displayName: SelectedModelDisplayName,
    modifier: Modifier = Modifier,
) {
    Row(
        modifier = modifier,
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(5.dp),
    ) {
        Text(
            text = displayName.primary,
            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Normal),
            color = ArixOnSurface,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
        )
        if (displayName.secondary.isNotBlank()) {
            Text(
                text = displayName.secondary,
                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Normal),
                color = ArixOnSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.weight(1f, fill = false),
            )
        }
        displayName.icon?.let { icon ->
            Icon(
                imageVector = when (icon) {
                    SelectedModelDisplayIcon.Fast -> LucideIcons.Zap
                    SelectedModelDisplayIcon.Reasoning -> LucideIcons.Brain
                },
                contentDescription = null,
                tint = ArixOnSurfaceVariant,
                modifier = Modifier.size(15.dp),
            )
        }
    }
}

internal data class SelectedModelDisplayName(
    val primary: String,
    val secondary: String,
    val icon: SelectedModelDisplayIcon? = null,
)

internal enum class SelectedModelDisplayIcon {
    Fast,
    Reasoning,
}

internal fun formatSelectedModelDisplayName(rawName: String): SelectedModelDisplayName {
    val normalizedTokens = rawName
        .trim()
        .substringAfterLast('/')
        .replace(Regex("[()]"), " ")
        .split(Regex("[\\s_-]+"))
        .mapNotNull { token ->
            token.trim().takeIf { it.isNotEmpty() }
        }
    val icon = when {
        normalizedTokens.any { it.equals("reasoning", ignoreCase = true) || it.equals("thinking", ignoreCase = true) } ->
            SelectedModelDisplayIcon.Reasoning
        normalizedTokens.any { token ->
            token.equals("ultraspeed", ignoreCase = true) ||
                token.equals("fast", ignoreCase = true) ||
                token.equals("spark", ignoreCase = true) ||
                token.equals("highspeed", ignoreCase = true)
        } -> SelectedModelDisplayIcon.Fast
        else -> null
    }
    val visibleTokens = normalizedTokens
        .filterNot { token ->
            token.equals("preview", ignoreCase = true) ||
                token.equals("reasoning", ignoreCase = true) ||
                token.equals("thinking", ignoreCase = true) ||
                token.equals("ultraspeed", ignoreCase = true) ||
                token.equals("fast", ignoreCase = true) ||
                token.equals("spark", ignoreCase = true) ||
                token.equals("highspeed", ignoreCase = true)
        }
        .let { tokens ->
            val isLong = tokens.joinToString(" ").length > 28 || tokens.size > 4
            if (!isLong) {
                tokens
            } else {
                tokens.filterNot { token -> token.matches(Regex("\\d+b", RegexOption.IGNORE_CASE)) || token.matches(Regex("a\\d+b", RegexOption.IGNORE_CASE)) }
            }
        }
    if (visibleTokens.isEmpty()) {
        return SelectedModelDisplayName(primary = rawName.trim().ifBlank { "" }, secondary = "", icon = icon)
    }
    val splitFirst = splitTrailingNumber(visibleTokens.first())
    val primary = titleModelToken(splitFirst.first)
    val secondaryTokens = buildList {
        splitFirst.second?.takeIf { it.isNotBlank() }?.let(::add)
        addAll(visibleTokens.drop(1))
    }
    return SelectedModelDisplayName(
        primary = primary,
        secondary = secondaryTokens.joinToString(" ") { titleModelToken(it) },
        icon = icon,
    )
}

private fun splitTrailingNumber(token: String): Pair<String, String?> {
    val match = Regex("^([A-Za-z]+)(\\d[\\w.]*)$").matchEntire(token) ?: return token to null
    return match.groupValues[1] to match.groupValues[2]
}

private fun titleModelToken(token: String): String {
    if (token.isBlank()) return token
    val uppercaseToken = token.uppercase()
    if (uppercaseToken == token && token.any(Char::isLetter)) return token
    if (token.equals("gpt", ignoreCase = true) || token.equals("glm", ignoreCase = true)) {
        return token.uppercase()
    }
    if (token.startsWith("v") && token.drop(1).firstOrNull()?.isDigit() == true) {
        return "v" + token.drop(1)
    }
    if (token.first().isDigit()) return token
    return token.replaceFirstChar { char ->
        if (char.isLowerCase()) char.titlecase(Locale.getDefault()) else char.toString()
    }
}

private val IstZone: ZoneId = ZoneId.of("Asia/Kolkata")

@Composable
private fun rememberIstHour(): Int = remember { ZonedDateTime.now(IstZone).hour }


private fun Modifier.noRippleClickable(onClick: () -> Unit): Modifier = composed {
    clickable(
        enabled = true,
        indication = null,
        interactionSource = remember { MutableInteractionSource() },
        onClick = onClick,
    )
}

@Composable
private fun IstGreetingHeader(
    modifier: Modifier = Modifier,
    dimmed: Boolean,
) {
    val istHour = rememberIstHour()
    val greetingText = when (istHour) {
        in 4..5 -> stringResource(R.string.greeting_early_morning)
        in 6..11 -> stringResource(R.string.greeting_morning)
        in 12..16 -> stringResource(R.string.greeting_afternoon)
        in 17..19 -> stringResource(R.string.greeting_evening)
        else -> stringResource(R.string.greeting_night)
    }
    val alpha by animateFloatAsState(
        targetValue = if (dimmed) 0f else 1f,
        animationSpec = tween(durationMillis = 220, easing = ChatGptMotionEasing),
        label = "ist_greeting_header_alpha",
    )
    // v2.5.2 home-screen redesign: the 3D futuristic Arix robot IS the home
    // screen. All quick-action suggestion cards and the "Today's tip" card
    // were removed (nothing replaces them); the IST typewriter greeting —
    // the app's signature — stays, now framing a large, alive, glossy
    // violet/blue robot floating on a holographic energy ring.
    val dividerBrush = remember {
        Brush.horizontalGradient(
            colors = listOf(
                Color.Transparent,
                Color(0xFFA78BFA).copy(alpha = 0.42f),
                Color(0xFFC3AFFF).copy(alpha = 0.22f),
                Color.Transparent,
            ),
        )
    }
    Column(
        modifier = modifier
            .alpha(alpha)
            .verticalScroll(rememberScrollState()),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Spacer(Modifier.height(10.dp))
        GreetingRevealText(text = greetingText)
        Spacer(Modifier.height(12.dp))
        Box(
            modifier = Modifier
                .width(132.dp)
                .height(1.dp)
                .background(dividerBrush),
        )
        Spacer(Modifier.height(18.dp))
        // ── the hero: the animated 3D AI assistant robot ──
        ArixAiAssistantRobot(
            modifier = Modifier
                .fillMaxWidth()
                .height(340.dp),
        )
        Spacer(Modifier.height(18.dp))
        Text(
            text = stringResource(R.string.chat_welcome_help),
            style = MaterialTheme.typography.titleMedium.copy(
                letterSpacing = 0.2.sp,
            ),
            color = ArixOnSurfaceVariant,
            textAlign = TextAlign.Center,
        )
        Spacer(Modifier.height(10.dp))
    }
}

@Composable
private fun GreetingRevealText(
    text: String,
) {
    var revealed by remember(text) { mutableStateOf("") }
    LaunchedEffect(text) {
        revealed = ""
        splitGreetingRevealUnits(text).forEach { unit ->
            delay(greetingRevealUnitDelay(unit))
            revealed += unit
        }
    }
    val greetingBrush = remember {
        Brush.verticalGradient(
            listOf(
                Color(0xFFF6F2FF),
                Color(0xFFD9CBFF),
                Color(0xFFB79CFF),
            ),
        )
    }
    Text(
        text = revealed.ifEmpty { " " },
        style = MaterialTheme.typography.headlineMedium.copy(
            fontWeight = FontWeight.SemiBold,
            fontSize = 31.sp,
            lineHeight = 38.sp,
            letterSpacing = (-0.2).sp,
            brush = greetingBrush,
        ),
        textAlign = TextAlign.Center,
    )
}

private fun splitGreetingRevealUnits(text: String): List<String> {
    if (text.isBlank()) return emptyList()
    val units = mutableListOf<String>()
    val builder = StringBuilder()
    text.forEach { char ->
        builder.append(char)
        val shouldSplit = char == ' ' || char == '\n' || char == '.' || char == '!' || char == '?' || char == ','
        if (shouldSplit) {
            units += builder.toString()
            builder.clear()
        }
    }
    if (builder.isNotEmpty()) {
        units += builder.toString()
    }
    return units
}

private fun greetingRevealUnitDelay(unit: String): Long {
    val trimmed = unit.trim()
    if (trimmed.isEmpty()) return 18L
    if (trimmed.length == 1 && trimmed.first() in setOf('.', ',', '!', '?')) return 180L
    return (80L + trimmed.length * 18L).coerceIn(96L, 240L)
}

@Composable
private fun ConversationThinkingIndicator() {
    ShimmerStatusText(
        text = stringResource(R.string.chat_thinking),
        modifier = Modifier.padding(top = 6.dp),
    )
}

@Composable
private fun PendingAssistantTimeline(
    blocks: List<AssistantResponseBlock>,
    workspaceDirectory: String,
    allowRootImageRead: Boolean,
    onOpenLink: (String) -> Unit,
    pendingToolInvocationStateKey: String,
    pendingToolInvocations: List<ChatToolInvocation>,
    activeTurnStartedAtMillis: Long?,
    agentModeSelected: Boolean,
    agentModeDisplayState: AgentModeDisplayState,
    chromeSelected: Boolean,
    chromeDisplayState: AgentModeDisplayState,
) {
    val blockAgentModeInvocations = blocks.flatMap { it.agentModeToolInvocations() }
    val pendingAgentModeInvocations = pendingToolInvocations.filter { it.isAgentModeDisplayInvocation() }
    val blockChromeInvocations = blocks.flatMap { it.chromeToolInvocations() }
    val pendingChromeInvocations = pendingToolInvocations.filter { it.isChromeDisplayInvocation() }
    // (v2.5.1: visiblePendingInvocations is computed below once
    // chromePreviewVisible is known, so browser invocations only fold into the
    // panel when that panel actually renders.)
    // v2.4.9 (user request: no visual display in normal conversation): the
    // visual display panel renders ONLY when this is an actual agentic or
    // system task — i.e. the session selected Agent Mode (device/system
    // control) or Chrome (visual browsing) AND those tools are genuinely
    // running. Normal chat turns never show any visual panel.
    // v2.5.1 fix (double browser, part 1): the agent-mode panel now requires
    // REAL agent_mode tool invocations. agentModeDisplayState is the SAME
    // chrome display state (ArixApp passes uiState.chromeDisplayState for
    // both), so a stale agent-mode draft flag plus a running agent browser
    // used to leak the Chrome desktop into the "Agent Mode" panel through the
    // latestPreviewPath fallback — the browser then showed under two panels
    // at once. That fallback was chrome preview data, never agent-mode data,
    // so it is gone.
    val agentModePreviewUnfiltered =
        agentModeSelected && agentModeDisplayState.isActive &&
            (blockAgentModeInvocations.isNotEmpty() ||
                pendingAgentModeInvocations.isNotEmpty())
    // v2.5.1 fix (double browser, part 2): since v2.4.9 the browser tool is
    // always active, so chromeDisplayState.isActive became true for EVERY
    // agentic browsing turn and the live noVNC panel auto-showed in the chat
    // even with the Chrome toggle off — while the very same browser remained
    // one tap away in the Browser tab, so the browser appeared twice. The
    // live preview panel is now strictly opt-in via the Chrome toggle (the
    // documented v2.4.9 design: "the Chrome mode toggle now only controls the
    // extra visual live-preview rendering"). The agent itself keeps full,
    // always-on browser access; browsing results and screenshots still flow
    // through the tool output as before.
    val chromePreviewVisible =
        chromeSelected &&
            (blockChromeInvocations.isNotEmpty() ||
                pendingChromeInvocations.isNotEmpty() ||
                (blockAgentModeInvocations.isEmpty() &&
                    pendingAgentModeInvocations.isEmpty() &&
                    chromeDisplayState.latestPreviewPath.isNotBlank()))
    // v2.5.1 fix (tool visibility): browser invocations are only folded into
    // the live panel when that panel actually renders; with the toggle off
    // they now stay in the regular tool list so the turn never looks silent.
    val visiblePendingInvocations = pendingToolInvocations.filterNot {
        it.isAgentModeDisplayInvocation() ||
            (chromePreviewVisible && it.isChromeDisplayInvocation())
    }
    // v2.4.6 fix (double display): the agent-mode preview and the Chrome
    // preview are fed by the SAME display state (ArixApp passes
    // uiState.chromeDisplayState for both), so when both flags were true the
    // same virtual display rendered twice, stacked, while the agent browsed —
    // most visibly with "Always show visual interactions" on (default).
    // Render exactly one panel: the live Chrome panel wins when visible,
    // otherwise the agent-mode panel keeps its previous behavior unchanged.
    val agentModePreviewVisible = agentModePreviewUnfiltered && !chromePreviewVisible
    val firstAgentModeBlockIndex = blocks.firstAgentModeBlockIndex().let { index ->
        if (index >= 0) index else if (agentModePreviewVisible) blocks.size else -1
    }
    val agentModeOverlayText = if (agentModePreviewVisible) {
        blocks.lastTextBlockAfterAgentMode().orEmpty().ifBlank {
            blocks.latestReasoningStatusAfterTool { it.isAgentModeDisplayInvocation() }
        }
    } else {
        ""
    }
    val chromeOverlayText = if (chromePreviewVisible) {
        blocks.latestReasoningStatusAfterTool { it.isChromeDisplayInvocation() }
    } else {
        ""
    }
    if (blocks.isEmpty()) {
        if (chromePreviewVisible) {
            AgentModePreviewPanel(
                displayState = chromeDisplayState,
                toolInvocation = pendingChromeInvocations.lastOrNull(),
                label = stringResource(R.string.chrome_label),
                contentDescription = stringResource(R.string.chrome_label),
                pendingText = stringResource(R.string.chat_chrome_preview_pending),
                useLiveSurface = false,
                overlayText = chromeOverlayText,
            )
        }
        if (agentModePreviewVisible) {
            AgentModePreviewPanel(
                displayState = agentModeDisplayState,
                toolInvocation = pendingAgentModeInvocations.lastOrNull(),
                overlayText = agentModeOverlayText,
                workspaceDirectory = workspaceDirectory,
                allowRootImageRead = allowRootImageRead,
                onOpenLink = onOpenLink,
            )
        } else if (!chromePreviewVisible && visiblePendingInvocations.isNotEmpty()) {
            val pendingToolsStartedAtMillis = visiblePendingInvocations
                .mapNotNull { it.startedAtMillis.takeIf { timestamp -> timestamp > 0L } }
                .plus(listOfNotNull(activeTurnStartedAtMillis?.takeIf { it > 0L }))
                .filter { it >= MinimumWallClockMillis }
                .minOrNull()
            val pendingToolsFallbackStartedRealtimeMillis = remember(pendingToolInvocationStateKey) {
                SystemClock.elapsedRealtime()
            }
            val pendingToolsDurationMillis by produceState(
                initialValue = runningWorkDurationMillis(
                    startedAtMillis = pendingToolsStartedAtMillis,
                    fallbackStartedRealtimeMillis = pendingToolsFallbackStartedRealtimeMillis,
                ),
                pendingToolsStartedAtMillis,
                pendingToolsFallbackStartedRealtimeMillis,
            ) {
                while (true) {
                    value = runningWorkDurationMillis(
                        startedAtMillis = pendingToolsStartedAtMillis,
                        fallbackStartedRealtimeMillis = pendingToolsFallbackStartedRealtimeMillis,
                    )
                    kotlinx.coroutines.delay(1_000L)
                }
            }
            AgentWorkingStatusHeader(
                title = formatWorkedSummaryTitle(pendingToolsDurationMillis),
            )
            ToolInvocationList(
                toolInvocations = visiblePendingInvocations,
                stateKey = pendingToolInvocationStateKey,
                autoExpand = true,
            )
        }
        return
    }

    if (chromePreviewVisible) {
        AgentModePreviewPanel(
            displayState = chromeDisplayState,
            toolInvocation = (blockChromeInvocations + pendingChromeInvocations).lastOrNull(),
            label = stringResource(R.string.chrome_label),
            contentDescription = stringResource(R.string.chrome_label),
            pendingText = stringResource(R.string.chat_chrome_preview_pending),
            useLiveSurface = false,
            overlayText = chromeOverlayText,
        )
    }
    if (agentModePreviewVisible) {
        AgentModePreviewPanel(
            displayState = agentModeDisplayState,
            toolInvocation = (blockAgentModeInvocations + pendingAgentModeInvocations).lastOrNull(),
            overlayText = agentModeOverlayText,
            workspaceDirectory = workspaceDirectory,
            allowRootImageRead = allowRootImageRead,
            onOpenLink = onOpenLink,
        )
        return
    }
    if (chromePreviewVisible) {
        return
    }

    val workStartedAtMillis = listOfNotNull(
        blocks.workStartedAtMillis(),
        activeTurnStartedAtMillis?.takeIf { it >= MinimumWallClockMillis },
    ).minOrNull()
    val fallbackWorkStartedRealtimeMillis = remember(activeTurnStartedAtMillis) {
        SystemClock.elapsedRealtime()
    }
    val workingDurationMillis by produceState(
        initialValue = runningWorkDurationMillis(
            startedAtMillis = workStartedAtMillis,
            fallbackStartedRealtimeMillis = fallbackWorkStartedRealtimeMillis,
        ),
        workStartedAtMillis,
        fallbackWorkStartedRealtimeMillis,
    ) {
        while (true) {
            value = runningWorkDurationMillis(
                startedAtMillis = workStartedAtMillis,
                fallbackStartedRealtimeMillis = fallbackWorkStartedRealtimeMillis,
            )
            kotlinx.coroutines.delay(1_000L)
        }
    }
    val shouldShowWorkingDisclosure = blocks.any { block ->
        when (block) {
            is AssistantResponseBlock.Text -> block.text.isNotBlank()
            is AssistantResponseBlock.ToolGroup -> block.toolInvocations.isNotEmpty()
            is AssistantResponseBlock.Reasoning -> hasVisibleReasoningStatus(block.trace)
            is AssistantResponseBlock.Status -> block.text.isNotBlank()
        }
    }

    if (shouldShowWorkingDisclosure) {
        AgentWorkingStatusHeader(
            title = formatWorkedSummaryTitle(workingDurationMillis),
        )
        blocks.forEachIndexed { index, block ->
            if (agentModePreviewVisible && index == firstAgentModeBlockIndex) {
                AgentModePreviewPanel(
                    displayState = agentModeDisplayState,
                    toolInvocation = (blockAgentModeInvocations + pendingAgentModeInvocations).lastOrNull()
                        ?: pendingToolInvocations.lastOrNull(),
                    overlayText = agentModeOverlayText,
                    workspaceDirectory = workspaceDirectory,
                    allowRootImageRead = allowRootImageRead,
                    onOpenLink = onOpenLink,
                )
            }
            PendingAssistantTimelineBlock(
                block = block,
                index = index,
                isLastBlock = index == blocks.lastIndex,
                agentModePreviewVisible = false,
                workspaceDirectory = workspaceDirectory,
                allowRootImageRead = allowRootImageRead,
                onOpenLink = onOpenLink,
                pendingToolInvocationStateKey = pendingToolInvocationStateKey,
                agentModeSelected = agentModeSelected,
                agentModeDisplayState = agentModeDisplayState,
            )
        }
    }
}

@Composable
private fun PendingAssistantTimelineBlock(
    block: AssistantResponseBlock,
    index: Int,
    isLastBlock: Boolean,
    agentModePreviewVisible: Boolean,
    workspaceDirectory: String,
    allowRootImageRead: Boolean,
    onOpenLink: (String) -> Unit,
    pendingToolInvocationStateKey: String,
    agentModeSelected: Boolean,
    agentModeDisplayState: AgentModeDisplayState,
) {
    when (block) {
        is AssistantResponseBlock.Text -> {
            if (!agentModePreviewVisible) {
                PendingAssistantResponseBlock(
                    text = block.text,
                    workspaceDirectory = workspaceDirectory,
                    allowRootImageRead = allowRootImageRead,
                    onOpenLink = onOpenLink,
                )
            }
        }

        is AssistantResponseBlock.ToolGroup -> {
            val visibleInvocations = if (agentModePreviewVisible) {
                block.toolInvocations.filterNot { it.isAgentModeDisplayInvocation() }
            } else {
                block.toolInvocations
            }
            val shouldShowAgentModePreview =
                !agentModePreviewVisible &&
                    isLastBlock &&
                    agentModeSelected &&
                    agentModeDisplayState.isActive &&
                    block.toolInvocations.any { it.toolName.equals("agent_mode", ignoreCase = true) }
            if (shouldShowAgentModePreview) {
                AgentModePreviewPanel(
                    displayState = agentModeDisplayState,
                    toolInvocation = block.toolInvocations.lastOrNull(),
                    overlayText = "",
                    workspaceDirectory = workspaceDirectory,
                    allowRootImageRead = allowRootImageRead,
                    onOpenLink = onOpenLink,
                )
            } else if (visibleInvocations.isNotEmpty()) {
                ToolInvocationList(
                    toolInvocations = visibleInvocations,
                    stateKey = "$pendingToolInvocationStateKey-${block.id}",
                    autoExpand = isLastBlock,
                )
            }
        }

        is AssistantResponseBlock.Reasoning -> {
            if (hasVisibleReasoningStatus(block.trace)) {
                ReasoningTraceStatus(
                    trace = block.trace,
                    onOpenLink = onOpenLink,
                )
            }
        }

        is AssistantResponseBlock.Status -> ReconnectingStatusCard(
            text = block.text,
            detail = block.detail,
        )
    }
}

private fun AssistantResponseBlock.agentModeToolInvocations(): List<ChatToolInvocation> = when (this) {
    is AssistantResponseBlock.ToolGroup -> toolInvocations.filter { it.isAgentModeDisplayInvocation() }
    is AssistantResponseBlock.Reasoning -> trace.toolInvocations.filter { it.isAgentModeDisplayInvocation() }
    is AssistantResponseBlock.Text -> emptyList()
    is AssistantResponseBlock.Status -> emptyList()
}

private fun AssistantResponseBlock.chromeToolInvocations(): List<ChatToolInvocation> = when (this) {
    is AssistantResponseBlock.ToolGroup -> toolInvocations.filter { it.isChromeDisplayInvocation() }
    is AssistantResponseBlock.Reasoning -> trace.toolInvocations.filter { it.isChromeDisplayInvocation() }
    is AssistantResponseBlock.Text -> emptyList()
    is AssistantResponseBlock.Status -> emptyList()
}

private fun ChatToolInvocation.isAgentModeDisplayInvocation(): Boolean =
    toolName.equals("agent_mode", ignoreCase = true)

private fun ChatToolInvocation.isChromeDisplayInvocation(): Boolean =
    toolName.equals("chrome", ignoreCase = true) || toolName.equals("browser", ignoreCase = true)

private fun List<AssistantResponseBlock>.firstAgentModeBlockIndex(): Int =
    indexOfFirst { it.agentModeToolInvocations().isNotEmpty() }

private fun List<AssistantResponseBlock>.lastTextBlockAfterAgentMode(): String? {
    val firstAgentModeBlockIndex = firstAgentModeBlockIndex()
    if (firstAgentModeBlockIndex < 0) {
        return null
    }
    return drop(firstAgentModeBlockIndex + 1)
        .filterIsInstance<AssistantResponseBlock.Text>()
        .lastOrNull { it.text.isNotBlank() }
        ?.text
}

private fun List<AssistantResponseBlock>.latestReasoningStatusAfterTool(
    predicate: (ChatToolInvocation) -> Boolean,
): String {
    val firstToolBlock = indexOfFirst { block ->
        when (block) {
            is AssistantResponseBlock.ToolGroup -> block.toolInvocations.any(predicate)
            is AssistantResponseBlock.Reasoning -> block.trace.toolInvocations.any(predicate)
            is AssistantResponseBlock.Text -> false
            is AssistantResponseBlock.Status -> false
        }
    }
    if (firstToolBlock < 0) return ""
    return drop(firstToolBlock).asReversed().firstNotNullOfOrNull { block ->
        val trace = (block as? AssistantResponseBlock.Reasoning)?.trace ?: return@firstNotNullOfOrNull null
        trace.latestStatusText.ifBlank {
            trace.chunks.lastOrNull { it.detail.isNotBlank() || it.title.isNotBlank() }
                ?.let { it.detail.ifBlank(it::title) }
                .orEmpty()
        }.takeIf(String::isNotBlank)
    }.orEmpty()
}

private fun List<AssistantResponseBlock>.visibleText(): String =
    filterIsInstance<AssistantResponseBlock.Text>()
        .joinToString("\n\n") { it.text }

private fun List<AssistantResponseBlock>.hasVisiblePendingWork(): Boolean =
    any { block ->
        when (block) {
            is AssistantResponseBlock.Text -> block.text.isNotBlank()
            is AssistantResponseBlock.ToolGroup -> block.toolInvocations.isNotEmpty()
            is AssistantResponseBlock.Reasoning -> hasVisibleReasoningStatus(block.trace)
            is AssistantResponseBlock.Status -> block.text.isNotBlank()
        }
    }

private fun List<AssistantResponseBlock>.workStartedAtMillis(): Long? =
    flatMap { block ->
        when (block) {
            is AssistantResponseBlock.Text -> emptyList()
            is AssistantResponseBlock.Status -> emptyList()
            is AssistantResponseBlock.ToolGroup -> block.toolInvocations.mapNotNull {
                it.startedAtMillis.takeIf { timestamp -> timestamp > 0L }
            }
            is AssistantResponseBlock.Reasoning -> buildList {
                block.trace.startedAtMillis.takeIf { it > 0L }?.let(::add)
                block.trace.chunks.forEach { chunk ->
                    chunk.createdAtMillis.takeIf { it > 0L }?.let(::add)
                }
                block.trace.toolInvocations.forEach { invocation ->
                    invocation.startedAtMillis.takeIf { it > 0L }?.let(::add)
                }
            }
        }
    }
        .filter { it >= MinimumWallClockMillis }
        .minOrNull()

internal fun runningWorkDurationMillis(
    startedAtMillis: Long?,
    fallbackStartedRealtimeMillis: Long,
    nowMillis: Long = System.currentTimeMillis(),
    nowRealtimeMillis: Long = SystemClock.elapsedRealtime(),
): Long =
    if (startedAtMillis != null) {
        (nowMillis - startedAtMillis).coerceAtLeast(1_000L)
    } else {
        (nowRealtimeMillis - fallbackStartedRealtimeMillis).coerceAtLeast(1_000L)
    }

private fun buildConversationListItems(
    messages: List<ChatMessage>,
): List<ConversationListItem> = buildList {
    var index = 0
    while (index < messages.size) {
        val message = messages[index]
        when (message.displayKind) {
            MessageDisplayKind.HiddenContext -> {
                index += 1
                continue
            }

            MessageDisplayKind.CompactStatus -> {
                add(ConversationListItem.CompactStatus(message))
                index += 1
                continue
            }

            MessageDisplayKind.Standard -> Unit
        }
        val responseGroupId = message.responseGroupId
        if (
            message.author == MessageAuthor.Agent &&
            (!responseGroupId.isNullOrBlank() || isLegacyAssistantGroupStart(messages, index))
        ) {
            val groupedMessages = buildList {
                var groupIndex = index
                while (groupIndex < messages.size) {
                    val candidate = messages[groupIndex]
                    if (candidate.author != MessageAuthor.Agent) {
                        break
                    }
                    val matchesGroup = if (!responseGroupId.isNullOrBlank()) {
                        candidate.responseGroupId == responseGroupId
                    } else {
                        val offset = groupIndex - index
                        candidate.responseGroupId.isNullOrBlank() &&
                            candidate.createdAtMillis == message.createdAtMillis + offset
                    }
                    if (!matchesGroup) {
                        break
                    }
                    add(candidate)
                    groupIndex += 1
                }
            }
            if (groupedMessages.isNotEmpty()) {
                add(ConversationListItem.AssistantGroup(groupedMessages))
                index += groupedMessages.size
                continue
            }
        }
        add(ConversationListItem.Message(message))
        index += 1
    }
}

private data class CompactCommandSuggestion(
    val percent: Int?,
)

private fun compactCommandSuggestion(messages: List<ChatMessage>): CompactCommandSuggestion {
    val visibleMessages = messages.filter {
        it.displayKind != MessageDisplayKind.HiddenContext &&
            it.displayKind != MessageDisplayKind.CompactStatus
    }
    if (visibleMessages.size < 2) return CompactCommandSuggestion(percent = null)
    val estimatedChars = visibleMessages.sumOf { message ->
        message.text.length +
            message.attachments.sumOf { attachment ->
                attachment.name.length + attachment.mimeType.length + attachment.workspacePath.length
            } +
            message.toolInvocations.sumOf { invocation ->
                invocation.toolName.length + invocation.argumentsJson.length + invocation.outputJson.length
            }
    }
    val percent = ((estimatedChars * 100L) / 120_000L).toInt().coerceIn(1, 100)
    return CompactCommandSuggestion(percent = percent)
}

@Composable
private fun CompactStatusDivider(
    text: String,
    isRunning: Boolean = false,
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 2.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        Box(
            modifier = Modifier
                .weight(1f)
                .height(1.dp)
                .background(ArixOnSurfaceVariant.copy(alpha = 0.08f)),
        )
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(7.dp),
        ) {
            Icon(
                imageVector = if (isRunning) Icons.Rounded.RadioButtonUnchecked else Icons.Rounded.Check,
                contentDescription = null,
                tint = ArixOnSurfaceVariant.copy(alpha = 0.82f),
                modifier = Modifier.size(15.dp),
            )
            if (isRunning) {
                ShimmerStatusText(
                    text = text,
                    modifier = Modifier.widthIn(max = 190.dp),
                    travelDurationMillis = 2200,
                    pauseDurationMillis = 700,
                )
            } else {
                Text(
                    text = text,
                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Medium),
                    color = ArixOnSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }
        }
        Box(
            modifier = Modifier
                .weight(1f)
                .height(1.dp)
                .background(ArixOnSurfaceVariant.copy(alpha = 0.08f)),
        )
    }
}

@Composable
private fun CompactCommandSuggestion(
    text: String,
    onClick: () -> Unit,
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 11.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        Box(
            modifier = Modifier
                .size(24.dp)
                .clip(CircleShape)
                .background(ArixSurface),
            contentAlignment = Alignment.Center,
        ) {
            Icon(
                imageVector = Icons.Rounded.RadioButtonUnchecked,
                contentDescription = null,
                tint = ArixOnSurfaceVariant,
                modifier = Modifier.size(16.dp),
            )
        }
        Text(
            text = stringResource(R.string.chat_compact),
            style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Medium),
            color = ArixOnSurface,
            maxLines = 1,
        )
        Text(
            text = text,
            style = MaterialTheme.typography.bodyMedium,
            color = ArixOnSurfaceVariant,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.weight(1f),
        )
    }
}

@Composable
private fun SlashCommandSuggestionRow(
    suggestion: SlashCommandSuggestion,
    detail: String,
    input: String,
    onClick: () -> Unit,
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(22.dp))
            .background(ArixSurfaceHigh.copy(alpha = 0.92f))
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        Icon(
            imageVector = when (suggestion.icon) {
                SlashCommandIcon.Skill -> Icons.Rounded.AutoAwesome
                SlashCommandIcon.Extension -> Icons.Rounded.Extension
                SlashCommandIcon.Command -> Icons.Rounded.Compress
            },
            contentDescription = null,
            tint = ArixOnSurfaceVariant,
            modifier = Modifier.size(18.dp),
        )
        Text(
            text = slashHighlightedName(suggestion.command, input),
            style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Medium),
            color = ArixOnSurface,
        )
        Text(
            text = detail,
            style = MaterialTheme.typography.bodyMedium,
            color = ArixOnSurfaceVariant,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.weight(1f),
            textAlign = TextAlign.End,
        )
    }
}

private fun isLegacyAssistantGroupStart(
    messages: List<ChatMessage>,
    index: Int,
): Boolean {
    val message = messages.getOrNull(index) ?: return false
    if (
        message.author != MessageAuthor.Agent ||
        !message.responseGroupId.isNullOrBlank()
    ) {
        return false
    }
    val next = messages.getOrNull(index + 1) ?: return false
    return next.author == MessageAuthor.Agent &&
        next.responseGroupId.isNullOrBlank() &&
        next.createdAtMillis == message.createdAtMillis + 1
}

@Composable
private fun PendingSessionInputBubble(
    pendingInput: PendingSessionInput,
) {
    val modeLabel = when (pendingInput.mode) {
        SessionFollowUpMode.Queue -> stringResource(R.string.chat_pending_input_queued)
        SessionFollowUpMode.Steer -> stringResource(R.string.chat_pending_input_steering)
    }
    val attachmentLabel = when (pendingInput.attachmentCount) {
        0 -> null
        1 -> stringResource(R.string.chat_attachment_count_one)
        else -> stringResource(R.string.chat_attachment_count_other, pendingInput.attachmentCount)
    }
    Column(
        modifier = Modifier.fillMaxWidth(),
        horizontalAlignment = Alignment.End,
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Column(
            modifier = Modifier
                .widthIn(max = 300.dp)
                .shadow(8.dp, RoundedCornerShape(24.dp), ambientColor = ArixScrim, spotColor = ArixScrim)
                .clip(RoundedCornerShape(24.dp))
                .background(ArixSurfaceHigh.copy(alpha = 0.96f))
                .padding(horizontal = 18.dp, vertical = 14.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(
                    text = modeLabel,
                    style = MaterialTheme.typography.labelMedium,
                    color = ArixOnSurfaceVariant,
                )
                attachmentLabel?.let { label ->
                    Text(
                        text = label,
                        style = MaterialTheme.typography.labelSmall,
                        color = ArixOnSurfaceVariant,
                    )
                }
            }
            Text(
                text = pendingInput.preview.ifBlank {
                    stringResource(R.string.chat_additional_context)
                },
                style = MaterialTheme.typography.bodyLarge,
                color = ArixOnSurface,
            )
        }
    }
}

@Composable
private fun ConversationComposerOverlay(
    modifier: Modifier = Modifier,
    conversationStateKey: String,
    onBodyHeightChanged: (Int) -> Unit,
    bottomBarReserve: Dp = 0.dp,
    value: String,
    attachments: List<ChatAttachment>,
    availableSkills: List<InstalledSkill>,
    availableMcpServers: List<McpServerConfig>,
    selectedSkillIds: List<String>,
    selectedMcpServerIds: List<String>,
    agentModeAvailable: Boolean,
    agentModeSelected: Boolean,
    chromeAvailable: Boolean,
    chromeSelected: Boolean,
    isEditing: Boolean,
    isSending: Boolean,
    showStarterPromptHint: Boolean,
    compactSuggestionText: String,
    voiceInputEnabled: Boolean = true,
    voiceInputState: com.arix.app.voice.ArixSystemSttEngine.State = com.arix.app.voice.ArixSystemSttEngine.State.Idle,
    voiceAudioLevel: Float = 0f,
    onStartVoiceInput: () -> Unit = {},
    onStopVoiceInput: () -> Unit = {},
    onVoiceTranscriptFinal: (String) -> Unit = {},
    onValueChange: (String) -> Unit,
    onRemoveAttachment: (String) -> Unit,
    onSetSkillSelected: (String, Boolean) -> Unit,
    onSetMcpServerSelected: (String, Boolean) -> Unit,
    onSetAgentModeSelected: (Boolean) -> Unit,
    onSetChromeSelected: (Boolean) -> Unit,
    onCancelEdit: () -> Unit,
    onPickImages: () -> Unit,
    onPickFiles: () -> Unit,
    onPauseGeneration: () -> Unit,
    onDismissStarterPromptHint: () -> Unit,
    onFocusChanged: (Boolean) -> Unit,
    onSend: () -> Unit,
    onQueueFollowUp: () -> Unit,
    onSteerFollowUp: () -> Unit,
) {
    val density = LocalDensity.current
    val imeVisible = WindowInsets.ime.getBottom(density) > 0
    val bottomLift by animateDpAsState(
        targetValue = if (imeVisible) 12.dp else 18.dp,
        animationSpec = tween(durationMillis = 260, easing = ChatGptMotionEasing),
        label = "composer_bottom_lift",
    )
    Box(
        modifier = modifier
            .fillMaxWidth()
            .windowInsetsPadding(WindowInsets.ime.only(WindowInsetsSides.Bottom))
            .navigationBarsPadding()
            .padding(bottom = bottomLift + bottomBarReserve),
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .onSizeChanged { onBodyHeightChanged(it.height) },
        ) {
            Column {
                ArixExtensionSlot(
                    slot = ArixExtensionSlotChatComposerTop,
                    modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp),
                )
                key(conversationStateKey) {
                    ConversationComposerBar(
                    conversationStateKey = conversationStateKey,
                    value = value,
                    attachments = attachments,
                    availableSkills = availableSkills,
                    availableMcpServers = availableMcpServers,
                    selectedSkillIds = selectedSkillIds,
                    selectedMcpServerIds = selectedMcpServerIds,
                    agentModeAvailable = agentModeAvailable,
                    agentModeSelected = agentModeSelected,
                    chromeAvailable = chromeAvailable,
                    chromeSelected = chromeSelected,
                    isEditing = isEditing,
                    isSending = isSending,
                    showStarterPromptHint = showStarterPromptHint,
                    compactSuggestionText = compactSuggestionText,
                    voiceInputEnabled = voiceInputEnabled,
                    voiceInputState = voiceInputState,
                    voiceAudioLevel = voiceAudioLevel,
                    onStartVoiceInput = onStartVoiceInput,
                    onStopVoiceInput = onStopVoiceInput,
                    onVoiceTranscriptFinal = onVoiceTranscriptFinal,
                    onValueChange = onValueChange,
                    onRemoveAttachment = onRemoveAttachment,
                    onSetSkillSelected = onSetSkillSelected,
                    onSetMcpServerSelected = onSetMcpServerSelected,
                    onSetAgentModeSelected = onSetAgentModeSelected,
                    onSetChromeSelected = onSetChromeSelected,
                    onCancelEdit = onCancelEdit,
                    onPickImages = onPickImages,
                    onPickFiles = onPickFiles,
                    onPauseGeneration = onPauseGeneration,
                    onDismissStarterPromptHint = onDismissStarterPromptHint,
                    onFocusChanged = onFocusChanged,
                    onSend = onSend,
                    onQueueFollowUp = onQueueFollowUp,
                        onSteerFollowUp = onSteerFollowUp,
                    )
                }
            }
        }
    }
}

@Composable
private fun ConversationComposerBar(
    modifier: Modifier = Modifier,
    conversationStateKey: String,
    value: String,
    attachments: List<ChatAttachment>,
    availableSkills: List<InstalledSkill>,
    availableMcpServers: List<McpServerConfig>,
    selectedSkillIds: List<String>,
    selectedMcpServerIds: List<String>,
    agentModeAvailable: Boolean,
    agentModeSelected: Boolean,
    chromeAvailable: Boolean,
    chromeSelected: Boolean,
    isEditing: Boolean,
    isSending: Boolean,
    showStarterPromptHint: Boolean,
    compactSuggestionText: String,
    voiceInputEnabled: Boolean = true,
    voiceInputState: com.arix.app.voice.ArixSystemSttEngine.State = com.arix.app.voice.ArixSystemSttEngine.State.Idle,
    voiceAudioLevel: Float = 0f,
    onStartVoiceInput: () -> Unit = {},
    onStopVoiceInput: () -> Unit = {},
    onVoiceTranscriptFinal: (String) -> Unit = {},
    onValueChange: (String) -> Unit,
    onRemoveAttachment: (String) -> Unit,
    onSetSkillSelected: (String, Boolean) -> Unit,
    onSetMcpServerSelected: (String, Boolean) -> Unit,
    onSetAgentModeSelected: (Boolean) -> Unit,
    onSetChromeSelected: (Boolean) -> Unit,
    onCancelEdit: () -> Unit,
    onPickImages: () -> Unit,
    onPickFiles: () -> Unit,
    onPauseGeneration: () -> Unit,
    onDismissStarterPromptHint: () -> Unit,
    onFocusChanged: (Boolean) -> Unit,
    onSend: () -> Unit,
    onQueueFollowUp: () -> Unit,
    onSteerFollowUp: () -> Unit,
) {
    var attachmentMenuExpanded by remember(conversationStateKey) { mutableStateOf(false) }
    val attachmentMenuVisibility = remember(conversationStateKey) { MutableTransitionState(false) }
    attachmentMenuVisibility.targetState = attachmentMenuExpanded
    val attachmentMenuActionScope = rememberCoroutineScope()
    var followUpMenuExpanded by remember(conversationStateKey) { mutableStateOf(false) }
    val followUpMenuVisibility = remember(conversationStateKey) { MutableTransitionState(false) }
    followUpMenuVisibility.targetState = followUpMenuExpanded
    var textFieldFocused by remember { mutableStateOf(false) }
    // v2.6.0: live partial transcript overlay while the system mic listens.
    val isVoiceListening = voiceInputState is com.arix.app.voice.ArixSystemSttEngine.State.Listening ||
        voiceInputState is com.arix.app.voice.ArixSystemSttEngine.State.Partial
    val voicePartialText = (voiceInputState as? com.arix.app.voice.ArixSystemSttEngine.State.Partial)?.text.orEmpty()
    LaunchedEffect(voiceInputState) {
        when (val state = voiceInputState) {
            is com.arix.app.voice.ArixSystemSttEngine.State.Final -> {
                // Commit the finalized utterance into the composer draft.
                onVoiceTranscriptFinal(state.text)
            }
            else -> Unit
        }
    }
    var fieldValue by remember(conversationStateKey) { mutableStateOf(TextFieldValue(value, TextRange(value.length))) }
    LaunchedEffect(value) {
        if (value != fieldValue.text) fieldValue = TextFieldValue(value, TextRange(value.length))
    }
    var measuredTextLineCount by remember { mutableIntStateOf(1) }
    var measuredTextHeight by remember { mutableStateOf(22.dp) }
    val density = LocalDensity.current
    val imeVisible = WindowInsets.ime.getBottom(density) > 0
    val selectedSkillSet = remember(selectedSkillIds) { selectedSkillIds.toSet() }
    val selectedMcpServerSet = remember(selectedMcpServerIds) { selectedMcpServerIds.toSet() }
    val selectedSkillActions = remember(availableSkills, selectedSkillSet) {
        availableSkills.filter { selectedSkillSet.contains(it.id) }
    }
    val selectedMcpActions = remember(availableMcpServers, selectedMcpServerSet) {
        availableMcpServers.filter { selectedMcpServerSet.contains(it.id) }
    }
    val hasSelectedActions =
        selectedSkillActions.isNotEmpty() ||
            selectedMcpActions.isNotEmpty() ||
            agentModeSelected ||
            chromeSelected
    val extensionUiController = LocalArixExtensionUiController.current
    val hasExtensionActionTray =
        extensionUiController
            ?.snapshot
            ?.componentsAt(ArixExtensionComponentChatComposerActionTray)
            ?.isNotEmpty() == true ||
            extensionUiController
                ?.nativeComponents
                ?.any { it.target == ArixExtensionComponentChatComposerActionTray } == true
    val hasComposerActionTray = hasSelectedActions || hasExtensionActionTray
    val composerPlaceholder = when {
        value.isNotBlank() -> ""
        attachments.isNotEmpty() -> stringResource(R.string.chat_add_note)
        agentModeSelected && selectedSkillActions.isEmpty() && selectedMcpActions.isEmpty() ->
            stringResource(R.string.chat_ask_agent_mode)
        chromeSelected && !agentModeSelected && selectedSkillActions.isEmpty() && selectedMcpActions.isEmpty() ->
            stringResource(R.string.chat_ask_chrome)
        selectedSkillActions.size + selectedMcpActions.size == 1 && !agentModeSelected && !chromeSelected -> {
            selectedSkillActions.firstOrNull()?.quickActionLabel()
                ?: selectedMcpActions.firstOrNull()?.quickActionLabel()
                ?: stringResource(R.string.chat_reply_to_arix)
        }
        hasSelectedActions -> stringResource(R.string.chat_ask_with_selected_tools)
        else -> stringResource(R.string.chat_ask_arix)
    }
    val hasDraft = value.isNotBlank() || attachments.isNotEmpty()
    val slashSuggestions = remember(fieldValue.text) {
        slashCommandSuggestions(fieldValue.text)
    }
    fun applySlashSuggestion(command: String) {
        val typedLength = fieldValue.text.drop(1).takeWhile { !it.isWhitespace() }.length
        val replaceEnd = (1 + typedLength).coerceAtMost(fieldValue.text.length)
        val suffix = fieldValue.text.substring(replaceEnd)
        val needsSpace = suffix.isEmpty() && slashSuggestions.firstOrNull { it.command == command }?.argumentHint?.isNotBlank() == true
        val replacement = command + if (needsSpace) " " else ""
        val next = replacement + suffix
        fieldValue = TextFieldValue(next, TextRange(replacement.length))
        onValueChange(next)
    }
    val canSendDraft = attachments.all { it.workspaceState == AttachmentWorkspaceState.Ready }
    val keepPlusSeparated = value.isNotBlank() || hasComposerActionTray
    val plusSeparated = keepPlusSeparated || (textFieldFocused && imeVisible)
    val explicitTextLineCount = if (value.isBlank()) {
        1
    } else {
        value.count { it == '\n' } + 1
    }
    val composerTextLineCount = if (value.isBlank()) {
        1
    } else {
        maxOf(explicitTextLineCount, measuredTextLineCount).coerceIn(1, 5)
    }
    val isMultilineComposer = composerTextLineCount > 1
    val composerTextStyle = MaterialTheme.typography.bodyLarge.copy(
        color = ArixOnSurface,
        fontSize = 16.sp,
        lineHeight = 22.sp,
        platformStyle = PlatformTextStyle(includeFontPadding = false),
        lineHeightStyle = LineHeightStyle(
            alignment = LineHeightStyle.Alignment.Center,
            trim = LineHeightStyle.Trim.Both,
        ),
    )
    val fieldTopPadding = when {
        hasComposerActionTray -> 12.dp
        isMultilineComposer -> 12.dp
        else -> 8.dp
    }
    val fieldBottomPadding = when {
        hasComposerActionTray -> 12.dp
        isMultilineComposer -> 12.dp
        else -> 8.dp
    }
    LaunchedEffect(plusSeparated) {
        onFocusChanged(plusSeparated)
    }
    fun runAfterAttachmentMenuDismiss(action: () -> Unit) {
        attachmentMenuExpanded = false
        action()
    }
    val composerHorizontalPadding by animateDpAsState(
        targetValue = when {
            plusSeparated -> 14.dp
            hasComposerActionTray -> 18.dp
            else -> 30.dp
        },
        animationSpec = tween(durationMillis = 260, easing = ChatGptMotionEasing),
        label = "composer_horizontal_padding",
    )
    val fieldStartPadding by animateDpAsState(
        targetValue = if (plusSeparated) 50.dp else 0.dp,
        animationSpec = tween(durationMillis = 260, easing = ChatGptMotionEasing),
        label = "composer_field_start",
    )
    val fieldContentStartPadding by animateDpAsState(
        targetValue = if (plusSeparated) 18.dp else 52.dp,
        animationSpec = tween(durationMillis = 260, easing = ChatGptMotionEasing),
        label = "composer_field_content_start",
    )
    val fieldMinHeight by animateDpAsState(
        targetValue = maxOf(
            if (plusSeparated) 56.dp else 50.dp,
            measuredTextHeight + fieldTopPadding + fieldBottomPadding,
        ),
        animationSpec = tween(durationMillis = 260, easing = ChatGptMotionEasing),
        label = "composer_field_min_height",
    )
    val plusShadowElevation by animateDpAsState(
        targetValue = if (plusSeparated) 10.dp else 0.dp,
        animationSpec = tween(durationMillis = 260, easing = ChatGptMotionEasing),
        label = "composer_plus_shadow",
    )

    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = composerHorizontalPadding),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        if (showStarterPromptHint) {
            SurfaceNotice(
                title = stringResource(R.string.chat_first_prompt_ready_title),
                subtitle = stringResource(R.string.chat_first_prompt_ready_subtitle),
                actionLabel = stringResource(R.string.common_hide),
                onAction = onDismissStarterPromptHint,
                actionEnabled = true,
            )
        }
        if (isEditing) {
            SurfaceNotice(
                title = stringResource(R.string.chat_editing_earlier_message_title),
                subtitle = stringResource(R.string.chat_editing_earlier_message_subtitle),
                actionLabel = stringResource(R.string.common_cancel),
                onAction = onCancelEdit,
                actionEnabled = true,
            )
        }
        AnimatedVisibility(
            visible = attachments.isEmpty() && slashSuggestions.isNotEmpty(),
            enter = fadeIn(animationSpec = tween(durationMillis = 160, easing = ChatGptMotionEasing)) +
                slideInVertically(
                    animationSpec = tween(durationMillis = 220, easing = ChatGptMotionEasing),
                    initialOffsetY = { it / 3 },
                ),
            exit = fadeOut(animationSpec = tween(durationMillis = 120, easing = ChatGptMotionEasing)) +
                slideOutVertically(
                    animationSpec = tween(durationMillis = 180, easing = ChatGptMotionEasing),
                    targetOffsetY = { it / 3 },
                ),
        ) {
            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 300.dp)
                    .clip(RoundedCornerShape(18.dp))
                    .background(ArixSurfaceHigh.copy(alpha = 0.98f))
                    .padding(vertical = 4.dp),
            ) {
                items(slashSuggestions, key = { it.command }) { suggestion ->
                    SlashCommandSuggestionRow(
                        suggestion = suggestion,
                        detail = if (suggestion.command == "/compact") compactSuggestionText else suggestion.description,
                        input = fieldValue.text,
                        onClick = { applySlashSuggestion(suggestion.command) },
                    )
                }
            }
        }
        if (attachments.isNotEmpty()) {
            ComposerAttachmentTray(
                attachments = attachments,
                onRemoveAttachment = onRemoveAttachment,
            )
        }

        val fieldShape = if (plusSeparated) ComposerFocusedCardShape else ComposerCardShape
        val fieldControlAlignment = if (isMultilineComposer) Alignment.Bottom else Alignment.CenterVertically
        val fieldTextAlignment = if (isMultilineComposer) Alignment.TopStart else Alignment.CenterStart
        val plusButtonAlignment = if (isMultilineComposer || hasComposerActionTray) Alignment.BottomStart else Alignment.CenterStart
        Box(
            modifier = Modifier
                .fillMaxWidth(),
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(start = fieldStartPadding)
            ) {
                Box(
                    modifier = Modifier
                        .matchParentSize()
                        .offset(y = 8.dp)
                        .blur(
                            radius = 22.dp,
                            edgeTreatment = BlurredEdgeTreatment.Unbounded,
                        )
                        .clip(fieldShape)
                        .background(ChatGptComposerShadow),
                )
                val composerBorderColor by animateColorAsState(
                    targetValue = if (textFieldFocused) {
                        ArixPrimary.copy(alpha = 0.55f)
                    } else {
                        ArixOutlineSoft
                    },
                    animationSpec = tween(durationMillis = 220, easing = ChatGptMotionEasing),
                    label = "composer_border_color",
                )
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(min = fieldMinHeight)
                        .animateContentSize(
                            animationSpec = tween(durationMillis = 320, easing = ChatGptMotionEasing),
                        )
                        .clip(fieldShape)
                        .background(ArixSurface)
                        .border(
                            width = 1.dp,
                            color = composerBorderColor,
                            shape = fieldShape,
                        )
                        .padding(
                            start = fieldContentStartPadding,
                            end = 8.dp,
                            top = fieldTopPadding,
                            bottom = fieldBottomPadding,
                        ),
                    verticalArrangement = Arrangement.spacedBy(if (hasComposerActionTray) 10.dp else 0.dp),
                ) {
                    AnimatedVisibility(
                        visible = hasComposerActionTray,
                        enter = fadeIn(
                            animationSpec = tween(durationMillis = 220, easing = ChatGptMotionEasing),
                        ) + slideInVertically(
                            animationSpec = tween(durationMillis = 280, easing = ChatGptMotionEasing),
                            initialOffsetY = { -it / 2 },
                        ),
                        exit = fadeOut(
                            animationSpec = tween(durationMillis = 160, easing = ChatGptMotionEasing),
                        ) + slideOutVertically(
                            animationSpec = tween(durationMillis = 220, easing = ChatGptMotionEasing),
                            targetOffsetY = { -it / 3 },
                        ),
                    ) {
                        ArixExtensionComponentHost(
                            target = ArixExtensionComponentChatComposerActionTray,
                            modifier = Modifier.fillMaxWidth(),
                        ) {
                            ComposerActionTray(
                                modifier = Modifier.fillMaxWidth(),
                                skills = selectedSkillActions,
                                mcpServers = selectedMcpActions,
                                agentModeSelected = agentModeSelected,
                                chromeSelected = chromeSelected,
                                onRemoveSkill = { skillId -> onSetSkillSelected(skillId, false) },
                                onRemoveMcpServer = { serverId -> onSetMcpServerSelected(serverId, false) },
                                onRemoveAgentMode = { onSetAgentModeSelected(false) },
                                onRemoveChrome = { onSetChromeSelected(false) },
                            )
                        }
                    }

                    // v2.6.0: live transcript strip while the system mic listens
                    // (also surfaces recognizer errors — e.g. no speech service
                    // installed — instead of failing silently).
                    // v2.6.1: the strip leads with an animated voice waveform
                    // whose bars react to the live microphone loudness.
                    val voiceErrorText =
                        (voiceInputState as? com.arix.app.voice.ArixSystemSttEngine.State.Error)?.message.orEmpty()
                    AnimatedVisibility(
                        visible = isVoiceListening || voiceErrorText.isNotBlank(),
                        enter = fadeIn(tween(200, easing = ChatGptMotionEasing)),
                        exit = fadeOut(tween(160, easing = ChatGptMotionEasing)),
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 2.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            if (isVoiceListening) {
                                VoiceWaveformBars(
                                    level = voiceAudioLevel,
                                    modifier = Modifier.size(width = 20.dp, height = 16.dp),
                                )
                            } else {
                                Box(
                                    modifier = Modifier
                                        .size(7.dp)
                                        .clip(CircleShape)
                                        .background(Color(0xFFE5484D)),
                                )
                            }
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = when {
                                    voiceErrorText.isNotBlank() -> voiceErrorText
                                    voicePartialText.isNotBlank() -> voicePartialText
                                    else -> stringResource(R.string.chat_voice_listening)
                                },
                                style = MaterialTheme.typography.bodySmall,
                                color = if (voiceErrorText.isNotBlank()) {
                                    Color(0xFFE5484D)
                                } else {
                                    ArixOnSurface.copy(alpha = 0.75f)
                                },
                                maxLines = 2,
                                overflow = TextOverflow.Ellipsis,
                                modifier = Modifier.weight(1f),
                            )
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = fieldControlAlignment,
                    ) {
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .heightIn(min = measuredTextHeight.coerceAtLeast(22.dp)),
                            contentAlignment = fieldTextAlignment,
                        ) {
                            if (value.isBlank()) {
                                Text(
                                    text = composerPlaceholder,
                                    style = composerTextStyle,
                                    color = Color(0xFF8C8C8C),
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                )
                            }
                            BasicTextField(
                                value = fieldValue,
                                onValueChange = { next ->
                                    fieldValue = next
                                    // v2.6.0 Gemini-style: the moment the user
                                    // starts typing (or edits the draft), voice
                                    // dictation stops and the send button takes
                                    // over the trailing slot.
                                    if (isVoiceListening) onStopVoiceInput()
                                    onValueChange(next.text)
                                },
                                enabled = true,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .onFocusChanged { focusState ->
                                        if (textFieldFocused != focusState.isFocused) {
                                            textFieldFocused = focusState.isFocused
                                        }
                                        // v2.6.0 Gemini-style: tapping into the
                                        // input field stops the mic so the
                                        // keyboard takes over.
                                        if (focusState.isFocused && isVoiceListening) {
                                            onStopVoiceInput()
                                        }
                                    },
                                textStyle = composerTextStyle,
                                maxLines = 5,
                                onTextLayout = { textLayoutResult ->
                                    val lineCount = textLayoutResult.lineCount.coerceIn(1, 5)
                                    if (measuredTextLineCount != lineCount) {
                                        measuredTextLineCount = lineCount
                                    }
                                    val visibleLineBottom = textLayoutResult.getLineBottom(lineCount - 1)
                                    val visibleLineTop = textLayoutResult.getLineTop(0)
                                    val textHeight = with(density) {
                                        (visibleLineBottom - visibleLineTop).toDp()
                                    }
                                    if (measuredTextHeight != textHeight) {
                                        measuredTextHeight = textHeight
                                    }
                                },
                                cursorBrush = SolidColor(ArixOnSurface),
                            )
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        // v2.6.0: Gemini-style trailing action. The send button's
                        // slot doubles as the voice input button:
                        //  - empty draft  → mic button (send hidden),
                        //  - user types   → mic morphs into the send button,
                        //  - listening    → pulsating stop control,
                        //  - draft cleared → mic returns.
                        // v2.6.1: while Arix is generating, the stop control takes
                        // over the trailing slot — the voice button is hidden
                        // (previously the pause button rendered BESIDE the mic;
                        // it now occupies the mic's exact position instead).
                        if (voiceInputEnabled) {
                            val micContext = androidx.compose.ui.platform.LocalContext.current
                            var micPermissionGranted by androidx.compose.runtime.remember(micContext) {
                                androidx.compose.runtime.mutableStateOf(
                                    androidx.core.content.ContextCompat.checkSelfPermission(
                                        micContext,
                                        android.Manifest.permission.RECORD_AUDIO,
                                    ) == android.content.pm.PackageManager.PERMISSION_GRANTED,
                                )
                            }
                            val micPermissionLauncher = androidx.activity.compose.rememberLauncherForActivityResult(
                                androidx.activity.result.contract.ActivityResultContracts.RequestPermission(),
                            ) { granted ->
                                micPermissionGranted = granted
                                if (granted) onStartVoiceInput()
                            }
                            // v2.6.1 bug fix: re-check the mic permission every
                            // time the app resumes. The old remember(context)
                            // cache stayed stale (false) when the permission was
                            // granted from system settings, so the composer kept
                            // re-requesting / showing the permission error even
                            // though RECORD_AUDIO was already granted.
                            val lifecycleOwner = androidx.compose.ui.platform.LocalLifecycleOwner.current
                            androidx.compose.runtime.DisposableEffect(lifecycleOwner, micContext) {
                                val observer = androidx.lifecycle.LifecycleEventObserver { _, event ->
                                    if (event == androidx.lifecycle.Lifecycle.Event.ON_RESUME) {
                                        micPermissionGranted = androidx.core.content.ContextCompat.checkSelfPermission(
                                            micContext,
                                            android.Manifest.permission.RECORD_AUDIO,
                                        ) == android.content.pm.PackageManager.PERMISSION_GRANTED
                                    }
                                }
                                lifecycleOwner.lifecycle.addObserver(observer)
                                onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
                            }
                            // v2.6.1 bug fix: as soon as the permission is granted
                            // (via the dialog or system settings), a stale
                            // permission Error state is retried immediately so
                            // the "microphone permission required" strip never
                            // lingers after a successful grant.
                            androidx.compose.runtime.LaunchedEffect(micPermissionGranted, voiceInputState) {
                                val errorState = voiceInputState as? com.arix.app.voice.ArixSystemSttEngine.State.Error
                                if (micPermissionGranted && errorState != null &&
                                    errorState.message.contains("permission", ignoreCase = true)
                                ) {
                                    onStartVoiceInput()
                                }
                            }
                            val trailingAction = when {
                                isVoiceListening -> ComposerTrailingAction.StopVoice
                                isSending && !hasDraft -> ComposerTrailingAction.StopGeneration
                                hasDraft -> ComposerTrailingAction.Send
                                else -> ComposerTrailingAction.Voice
                            }
                            AnimatedContent(
                                targetState = trailingAction,
                                transitionSpec = {
                                    (
                                        fadeIn(tween(180, easing = ChatGptMotionEasing)) +
                                            scaleIn(
                                                initialScale = 0.7f,
                                                animationSpec = tween(220, easing = ChatGptMotionEasing),
                                            )
                                        ).togetherWith(
                                        fadeOut(tween(140, easing = ChatGptMotionEasing)) +
                                            scaleOut(
                                                targetScale = 0.7f,
                                                animationSpec = tween(160, easing = ChatGptMotionEasing),
                                            ),
                                    )
                                },
                                label = "composer_trailing_action",
                            ) { action ->
                                when (action) {
                                    ComposerTrailingAction.StopVoice -> ComposerVoiceButton(
                                        isListening = true,
                                        onToggle = onStopVoiceInput,
                                    )

                                    // v2.6.1: generation stop control — renders in
                                    // the trailing slot exactly where the mic
                                    // button sits, so the layout never grows an
                                    // extra control beside the voice input.
                                    ComposerTrailingAction.StopGeneration -> ComposerPauseButton(
                                        onClick = onPauseGeneration,
                                    )

                                    ComposerTrailingAction.Voice -> ComposerVoiceButton(
                                        isListening = false,
                                        onToggle = {
                                            if (micPermissionGranted) {
                                                onStartVoiceInput()
                                            } else {
                                                micPermissionLauncher.launch(android.Manifest.permission.RECORD_AUDIO)
                                            }
                                        },
                                    )

                                    ComposerTrailingAction.Send -> Box {
                                        ComposerSubmitButton(
                                            hasDraft = hasDraft,
                                            canSendDraft = canSendDraft,
                                            isSending = isSending,
                                            onClick = {
                                                if (!hasDraft || !canSendDraft) return@ComposerSubmitButton
                                                if (isSending) {
                                                    followUpMenuExpanded = true
                                                } else {
                                                    onSend()
                                                }
                                            },
                                        )
                                        if (isSending && (followUpMenuVisibility.currentState || followUpMenuVisibility.targetState)) {
                                            FollowUpMenuPopup(
                                                density = density,
                                                onDismiss = { followUpMenuExpanded = false },
                                                followUpMenuVisibility = followUpMenuVisibility,
                                                onSteerFollowUp = onSteerFollowUp,
                                                onQueueFollowUp = onQueueFollowUp,
                                            )
                                        }
                                    }
                                }
                            }
                        } else {
                            // v2.6.1: voice input is always on, but this fallback
                            // (theoretical voiceInputEnabled=false path) still
                            // needs a stop control while generating with an empty
                            // draft — it renders in the same trailing slot.
                            if (isSending && !hasDraft) {
                                ComposerPauseButton(
                                    onClick = onPauseGeneration,
                                )
                            } else {
                                Box {
                                ComposerSubmitButton(
                                    hasDraft = hasDraft,
                                    canSendDraft = canSendDraft,
                                    isSending = isSending,
                                    onClick = {
                                        if (!hasDraft || !canSendDraft) return@ComposerSubmitButton
                                        if (isSending) {
                                            followUpMenuExpanded = true
                                        } else {
                                            onSend()
                                        }
                                    },
                                )
                                if (isSending && (followUpMenuVisibility.currentState || followUpMenuVisibility.targetState)) {
                                    FollowUpMenuPopup(
                                        density = density,
                                        onDismiss = { followUpMenuExpanded = false },
                                        followUpMenuVisibility = followUpMenuVisibility,
                                        onSteerFollowUp = onSteerFollowUp,
                                        onQueueFollowUp = onQueueFollowUp,
                                    )
                                }
                                }
                            }
                        }
                    }
                }
            }

            Box(
                modifier = Modifier.align(plusButtonAlignment)
            ) {
                Box(
                    modifier = Modifier
                        .size(48.dp)
                        .shadow(plusShadowElevation, CircleShape, ambientColor = ChatGptControlShadow, spotColor = ChatGptControlShadow)
                        .clip(CircleShape)
                        .background(if (plusSeparated) ArixSurface else Color.Transparent)
                        .clickable(onClick = { attachmentMenuExpanded = !attachmentMenuExpanded }),
                    contentAlignment = Alignment.Center,
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Add,
                        contentDescription = stringResource(R.string.chat_add_attachment_or_tool),
                        tint = ArixOnSurface,
                        modifier = Modifier.size(27.dp),
                    )
                }

                if (attachmentMenuVisibility.currentState || attachmentMenuVisibility.targetState) {
                    Popup(
                        alignment = Alignment.BottomStart,
                        offset = with(density) {
                            IntOffset(0, -42.dp.roundToPx())
                        },
                        onDismissRequest = { attachmentMenuExpanded = false },
                        properties = PopupProperties(
                            focusable = true,
                            dismissOnBackPress = true,
                            dismissOnClickOutside = true,
                        ),
                    ) {
                        androidx.compose.animation.AnimatedVisibility(
                            visibleState = attachmentMenuVisibility,
                            enter = fadeIn() +
                                scaleIn(
                                    initialScale = 0.92f,
                                    transformOrigin = TransformOrigin(0f, 1f),
                                ) +
                                slideInVertically(initialOffsetY = { it / 10 }),
                            exit = fadeOut() +
                                scaleOut(
                                    targetScale = 0.96f,
                                    transformOrigin = TransformOrigin(0f, 1f),
                                ) +
                                slideOutVertically(targetOffsetY = { it / 12 }),
                        ) {
                            Box(
                                modifier = Modifier
                                    .widthIn(min = 284.dp, max = 304.dp)
                                    .shadow(20.dp, RoundedCornerShape(30.dp), ambientColor = ArixScrim, spotColor = ArixScrim)
                                    .clip(RoundedCornerShape(30.dp))
                                    .background(ArixSurface),
                            ) {
                                Column(
                                    modifier = Modifier
                                        .heightIn(max = ComposerPlusMenuMaxHeight)
                                        .verticalScroll(rememberScrollState())
                                        .padding(horizontal = 12.dp, vertical = 12.dp),
                                    verticalArrangement = Arrangement.spacedBy(2.dp),
                                ) {
                                    ComposerPlusMenuRow(
                                        title = stringResource(R.string.chat_photos),
                                        icon = Icons.Rounded.Image,
                                        iconTint = Color(0xFF4E8D5A),
                                        iconContainerColor = ArixSurfaceHigh,
                                        onClick = {
                                            runAfterAttachmentMenuDismiss(onPickImages)
                                        },
                                    )
                                    ComposerPlusMenuRow(
                                        title = stringResource(R.string.chat_files),
                                        icon = Icons.Rounded.AttachFile,
                                        iconTint = ArixOnSurface,
                                        iconContainerColor = ArixSurfaceHigh,
                                        onClick = {
                                            runAfterAttachmentMenuDismiss(onPickFiles)
                                        },
                                    )
                                    if (agentModeAvailable || chromeAvailable || availableSkills.isNotEmpty() || availableMcpServers.isNotEmpty()) {
                                        Spacer(modifier = Modifier.height(6.dp))
                                    }
                                    if (agentModeAvailable) {
                                        ComposerPlusMenuRow(
                                            title = stringResource(R.string.agent_mode_label),
                                            icon = LucideIcons.MousePointer2,
                                            selected = agentModeSelected,
                                            iconTint = Color(0xFF6D5CFF),
                                            iconContainerColor = ArixSurfaceHigh,
                                            onClick = {
                                                runAfterAttachmentMenuDismiss {
                                                    onSetAgentModeSelected(!agentModeSelected)
                                                }
                                            },
                                        )
                                    }
                                    if (chromeAvailable) {
                                        ComposerPlusMenuRow(
                                            title = stringResource(R.string.chrome_label),
                                            icon = Icons.Rounded.Public,
                                            selected = chromeSelected,
                                            iconTint = Color(0xFF2F6DA3),
                                            iconContainerColor = ArixSurfaceHigh,
                                            onClick = {
                                                runAfterAttachmentMenuDismiss {
                                                    onSetChromeSelected(!chromeSelected)
                                                }
                                            },
                                        )
                                    }
                                    ArixExtensionComponentHost(
                                        target = ArixExtensionComponentChatComposerSkillPicker,
                                        modifier = Modifier.fillMaxWidth(),
                                    ) {
                                        availableSkills.forEach { skill ->
                                            val selected = selectedSkillSet.contains(skill.id)
                                            ComposerPlusMenuRow(
                                                title = skill.quickActionLabel(),
                                                icon = Icons.Rounded.Extension,
                                                selected = selected,
                                                iconTint = Color(0xFF9C6B2F),
                                                iconContainerColor = ArixSurfaceHigh,
                                                onClick = {
                                                    runAfterAttachmentMenuDismiss {
                                                        onSetSkillSelected(skill.id, !selected)
                                                    }
                                                },
                                            )
                                        }
                                    }
                                    availableMcpServers.forEach { server ->
                                        val selected = selectedMcpServerSet.contains(server.id)
                                        val isStdIo = server.transport is McpTransportConfig.StdIo
                                        ComposerPlusMenuRow(
                                            title = server.quickActionLabel(),
                                            icon = if (isStdIo) Icons.Rounded.Terminal else Icons.Rounded.Cloud,
                                            selected = selected,
                                            iconTint = if (isStdIo) Color(0xFF2F6DA3) else Color(0xFF2A9C9A),
                                            iconContainerColor = ArixSurfaceHigh,
                                            onClick = {
                                                runAfterAttachmentMenuDismiss {
                                                    onSetMcpServerSelected(server.id, !selected)
                                                }
                                            },
                                        )
                                    }
                                    extensionUiController?.snapshot?.composerMenuItems.orEmpty().forEach { item ->
                                        ComposerPlusMenuRow(
                                            title = item.title,
                                            icon = Icons.Rounded.Extension,
                                            selected = item.selected,
                                            iconTint = ArixPrimary,
                                            iconContainerColor = ArixSurfaceHigh,
                                            onClick = {
                                                runAfterAttachmentMenuDismiss {
                                                    extensionUiController?.onAction?.invoke(
                                                        item.extensionId,
                                                        item.action.ifBlank { item.localId },
                                                        item.args,
                                                    )
                                                }
                                            },
                                        )
                                    }
                                    ArixExtensionSlot(ArixExtensionSlotChatComposerPlusMenu)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ComposerPauseButton(
    onClick: () -> Unit,
) {
    Box(
        modifier = Modifier
            .size(38.dp)
            .clip(CircleShape)
            .background(ComposerAccentBrush)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Box(
            modifier = Modifier
                .offset(x = 0.5.dp)
                .size(11.dp)
                .clip(RoundedCornerShape(3.dp))
                .background(Color.White)
        )
    }
}

@Composable
private fun ComposerSubmitButton(
    hasDraft: Boolean,
    canSendDraft: Boolean,
    isSending: Boolean,
    onClick: () -> Unit,
) {
    val enabled = hasDraft && canSendDraft
    val buttonBrush = if (enabled) {
        ComposerAccentBrush
    } else {
        null
    }
    Box(
        modifier = Modifier
            .size(38.dp)
            .clip(CircleShape)
            .then(
                if (buttonBrush != null) {
                    Modifier.background(buttonBrush)
                } else {
                    Modifier.background(ArixSurfaceHigher)
                },
            )
            .clickable(
                enabled = enabled,
                onClick = onClick,
            ),
        contentAlignment = Alignment.Center,
    ) {
        Icon(
            imageVector = Icons.Rounded.ArrowUpward,
            contentDescription = if (isSending) {
                stringResource(R.string.common_send_follow_up)
            } else {
                stringResource(R.string.common_send)
            },
            tint = Color.White,
            modifier = Modifier.size(21.dp),
        )
    }
}

/**
 * v2.6.0: the composer's trailing action slot — Gemini-style swap between
 * the voice input button and the send button (see the composer layout).
 */
private enum class ComposerTrailingAction {
    /** Empty draft — mic button, send hidden. */
    Voice,
    /** Mic active — pulsating stop control. */
    StopVoice,
    /** v2.6.1: Arix is generating with an empty draft — the generation stop
     *  control replaces the mic button in the trailing slot. */
    StopGeneration,
    /** Draft present — send button replaces the mic. */
    Send,
}

/**
 * v2.6.0: follow-up menu popup, extracted so both the voice-enabled and the
 * voice-disabled trailing slots render the identical menu.
 */
@Composable
private fun FollowUpMenuPopup(
    density: androidx.compose.ui.unit.Density,
    onDismiss: () -> Unit,
    followUpMenuVisibility: androidx.compose.animation.core.MutableTransitionState<Boolean>,
    onSteerFollowUp: () -> Unit,
    onQueueFollowUp: () -> Unit,
) {
    Popup(
        alignment = Alignment.BottomEnd,
        offset = with(density) {
            IntOffset(0, -12.dp.roundToPx())
        },
        onDismissRequest = onDismiss,
        properties = PopupProperties(
            focusable = true,
            dismissOnBackPress = true,
            dismissOnClickOutside = true,
        ),
    ) {
        androidx.compose.animation.AnimatedVisibility(
            visibleState = followUpMenuVisibility,
            enter = fadeIn() +
                scaleIn(
                    initialScale = 0.92f,
                    transformOrigin = TransformOrigin(1f, 1f),
                ) +
                slideInVertically(initialOffsetY = { it / 10 }),
            exit = fadeOut() +
                scaleOut(
                    targetScale = 0.96f,
                    transformOrigin = TransformOrigin(1f, 1f),
                ) +
                slideOutVertically(targetOffsetY = { it / 12 }),
        ) {
            Column(
                modifier = Modifier
                    .widthIn(min = 252.dp, max = 284.dp)
                    .shadow(20.dp, RoundedCornerShape(30.dp), ambientColor = ArixScrim, spotColor = ArixScrim)
                    .clip(RoundedCornerShape(30.dp))
                    .background(ArixSurface)
                    .padding(horizontal = 12.dp, vertical = 12.dp),
                verticalArrangement = Arrangement.spacedBy(2.dp),
            ) {
                ComposerPlusMenuRow(
                    title = stringResource(R.string.branch_steer_current_run),
                    icon = Icons.Rounded.AutoAwesome,
                    iconTint = Color(0xFF8D6C2F),
                    iconContainerColor = Color(0xFFFFF3DE),
                    onClick = {
                        onDismiss()
                        onSteerFollowUp()
                    },
                )
                ComposerPlusMenuRow(
                    title = stringResource(R.string.branch_queue_next_turn),
                    icon = Icons.Rounded.ArrowUpward,
                    iconTint = Color(0xFF2F6DA3),
                    iconContainerColor = Color(0xFFEAF2FF),
                    onClick = {
                        onDismiss()
                        onQueueFollowUp()
                    },
                )
            }
        }
    }
}

/**
 * v2.6.0: system-voice-input mic button for the composer (Gemini-style
 * trailing slot). Pulsates while listening.
 */
@Composable
private fun ComposerVoiceButton(
    isListening: Boolean,
    onToggle: () -> Unit,
) {
    val pulseScale by androidx.compose.animation.core.animateFloatAsState(
        targetValue = if (isListening) 1.12f else 1f,
        animationSpec = androidx.compose.animation.core.infiniteRepeatable(
            animation = androidx.compose.animation.core.tween(650),
            repeatMode = androidx.compose.animation.core.RepeatMode.Reverse,
        ),
        label = "voice_button_pulse",
    )
    val containerColor by animateColorAsState(
        targetValue = if (isListening) Color(0xFFE5484D) else ArixSurfaceHigher,
        animationSpec = tween(durationMillis = 220, easing = ChatGptMotionEasing),
        label = "voice_button_color",
    )
    Box(
        modifier = Modifier
            .size(38.dp)
            .graphicsLayer {
                scaleX = pulseScale
                scaleY = pulseScale
            }
            .clip(CircleShape)
            .background(containerColor)
            .clickable(onClick = onToggle),
        contentAlignment = Alignment.Center,
    ) {
        Icon(
            imageVector = if (isListening) Icons.Rounded.Stop else Icons.Rounded.Mic,
            contentDescription = stringResource(
                if (isListening) R.string.chat_voice_input_stop else R.string.chat_voice_input_start,
            ),
            tint = if (isListening) Color.White else ArixOnSurface,
            modifier = Modifier.size(if (isListening) 17.dp else 19.dp),
        )
    }
}

/**
 * v2.6.1: animated voice-input waveform for the composer's live-transcript
 * strip. Five rounded bars rise and fall in a travelling wave; the overall
 * amplitude tracks the live microphone loudness reported by the system
 * recognizer (falls back to a gentle idle wave when the recognizer never
 * delivers RMS values — e.g. some MIUI builds).
 */
@Composable
private fun VoiceWaveformBars(
    level: Float,
    modifier: Modifier = Modifier,
) {
    val transition = androidx.compose.animation.core.rememberInfiniteTransition(
        label = "voice_waveform",
    )
    val phase by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = androidx.compose.animation.core.infiniteRepeatable(
            animation = androidx.compose.animation.core.tween(
                durationMillis = 950,
                easing = androidx.compose.animation.core.LinearEasing,
            ),
        ),
        label = "voice_waveform_phase",
    )
    // Smooth the loudness so single RMS spikes don't jump the whole wave.
    val smoothLevel by androidx.compose.animation.core.animateFloatAsState(
        targetValue = level.coerceIn(0f, 1f),
        animationSpec = androidx.compose.animation.core.tween(
            durationMillis = 90,
            easing = androidx.compose.animation.core.LinearEasing,
        ),
        label = "voice_waveform_level",
    )
    Canvas(modifier = modifier) {
        val barCount = 5
        val gap = size.width / (barCount * 2f + 1f)
        val barWidth = gap * 1.35f
        val minBarHeight = size.height * 0.28f
        // Quiet ambient motion (0.2) blended with the live mic level.
        val amplitude = 0.2f + 0.8f * smoothLevel
        val waveColor = Color(0xFFE5484D)
        for (index in 0 until barCount) {
            val phaseOffset = (phase + index * 0.19f) % 1f
            val wave = 0.5f - 0.5f * kotlin.math.cos(phaseOffset * 2f * PI_FLOAT)
            val barHeight = (minBarHeight + (size.height - minBarHeight) * amplitude * wave)
                .coerceIn(minBarHeight, size.height)
            val x = gap + index * (barWidth + gap)
            drawRoundRect(
                color = waveColor,
                topLeft = androidx.compose.ui.geometry.Offset(x, (size.height - barHeight) / 2f),
                size = androidx.compose.ui.geometry.Size(barWidth, barHeight),
                cornerRadius = androidx.compose.ui.geometry.CornerRadius(barWidth / 2f),
            )
        }
    }
}

private const val PI_FLOAT = 3.141592653589793f

@Composable
private fun ComposerActionTray(
    modifier: Modifier = Modifier,
    skills: List<InstalledSkill>,
    mcpServers: List<McpServerConfig>,
    agentModeSelected: Boolean,
    chromeSelected: Boolean,
    onRemoveSkill: (String) -> Unit,
    onRemoveMcpServer: (String) -> Unit,
    onRemoveAgentMode: () -> Unit,
    onRemoveChrome: () -> Unit,
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .horizontalScroll(rememberScrollState())
            .padding(end = 6.dp),
        horizontalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        if (agentModeSelected) {
            ComposerActionChip(
                label = stringResource(R.string.agent_mode_label),
                icon = LucideIcons.MousePointer2,
                onRemove = onRemoveAgentMode,
            )
        }
        if (chromeSelected) {
            ComposerActionChip(
                label = stringResource(R.string.chrome_label),
                icon = Icons.Rounded.Public,
                onRemove = onRemoveChrome,
            )
        }
        skills.forEach { skill ->
            ComposerActionChip(
                label = skill.quickActionLabel(),
                icon = Icons.Rounded.Extension,
                onRemove = { onRemoveSkill(skill.id) },
            )
        }
        mcpServers.forEach { server ->
            ComposerActionChip(
                label = server.quickActionLabel(),
                icon = if (server.transport is McpTransportConfig.StdIo) {
                    Icons.Rounded.Terminal
                } else {
                    Icons.Rounded.Cloud
                },
                onRemove = { onRemoveMcpServer(server.id) },
            )
        }
    }
}

@Composable
private fun AgentModePreviewPanel(
    displayState: AgentModeDisplayState,
    toolInvocation: ChatToolInvocation?,
    label: String? = null,
    contentDescription: String? = null,
    pendingText: String? = null,
    useLiveSurface: Boolean = true,
    overlayText: String = "",
    workspaceDirectory: String = "",
    allowRootImageRead: Boolean = false,
    onOpenLink: (String) -> Unit = {},
) {
    val resolvedLabel = label ?: stringResource(R.string.agent_mode_label)
    val resolvedContentDescription =
        contentDescription ?: stringResource(R.string.chat_agent_mode_virtual_display)
    val resolvedPendingText =
        pendingText ?: stringResource(R.string.chat_agent_mode_preview_pending)
    val bitmap = remember(displayState.latestPreviewPath, displayState.lastUpdatedMillis) {
        displayState.latestPreviewPath
            .takeIf { it.isNotBlank() }
            ?.let { BitmapFactory.decodeFile(it) }
    }
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .shadow(12.dp, RoundedCornerShape(24.dp), ambientColor = ArixScrim, spotColor = ArixScrim)
            .clip(RoundedCornerShape(24.dp))
            .background(ArixSurface)
            .padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        if (toolInvocation != null) {
            AgentModePreviewToolStatus(toolInvocation = toolInvocation)
        } else {
            AgentModePreviewHeader(
                displayState = displayState,
                label = resolvedLabel,
                isChrome = !useLiveSurface,
            )
        }
        if (displayState.isActive || bitmap != null) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(280.dp)
                    .clip(RoundedCornerShape(18.dp))
                    .background(agentModePreviewBackdropBrush()),
                contentAlignment = Alignment.Center,
            ) {
                var previewSize by remember { mutableStateOf(IntSize.Zero) }
                val density = LocalDensity.current
                val imagePaddingPx = with(density) { 10.dp.toPx() }
                val cursorOffset = remember(
                    previewSize,
                    displayState.width,
                    displayState.height,
                    displayState.cursorX,
                    displayState.cursorY,
                ) {
                    resolveAgentModeCursorOffset(
                        previewSize = previewSize,
                        imagePaddingPx = imagePaddingPx,
                        displayWidth = displayState.width,
                        displayHeight = displayState.height,
                        cursorX = displayState.cursorX,
                        cursorY = displayState.cursorY,
                    )
                }
                val animationDurationMillis = displayState.cursorAnimationDurationMillis.coerceIn(80, 1_200)
                val animatedCursorOffset by animateIntOffsetAsState(
                    targetValue = cursorOffset,
                    animationSpec = tween(durationMillis = animationDurationMillis, easing = ChatGptMotionEasing),
                    label = "agent_mode_cursor_offset",
                )
                if (displayState.isActive && useLiveSurface && bitmap != null) {
                    Image(
                        bitmap = bitmap.asImageBitmap(),
                        contentDescription = resolvedContentDescription,
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(10.dp)
                            .clip(RoundedCornerShape(14.dp)),
                        contentScale = ContentScale.Fit,
                    )
                } else if (displayState.isActive && !useLiveSurface) {
                    // v2.4.6 fix (white flash): a non-transparent WebView paints
                    // a solid WHITE background until the noVNC page loads, which
                    // read as a broken blank display inside the dark preview
                    // panel. Transparent lets the panel's dark backdrop show
                    // through while the viewer connects; once noVNC paints it
                    // fills the same area exactly as before.
                    PlatformWebView(
                        url = AlpineChromeViewerUrl,
                        scrollEnabled = false,
                        transparentBackground = true,
                        modifier = Modifier
                            .fillMaxHeight()
                            .padding(10.dp)
                            .aspectRatio(
                                displayState.width.coerceAtLeast(1).toFloat() /
                                    displayState.height.coerceAtLeast(1).toFloat(),
                                matchHeightConstraintsFirst = true,
                            )
                            .clip(RoundedCornerShape(14.dp)),
                    )
                } else if (bitmap != null) {
                    Image(
                    bitmap = bitmap.asImageBitmap(),
                    contentDescription = resolvedContentDescription,
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(10.dp)
                        .clip(RoundedCornerShape(14.dp)),
                        contentScale = ContentScale.Fit,
                    )
                }
                Box(
                    modifier = Modifier
                        .matchParentSize()
                        .onSizeChanged { previewSize = it },
                ) {
                    AgentModeCursor(
                        modifier = Modifier
                            .offset {
                                val tipInsetPx = with(density) { 5.dp.roundToPx() }
                                IntOffset(animatedCursorOffset.x - tipInsetPx, animatedCursorOffset.y - tipInsetPx)
                            }
                            .size(30.dp),
                    )
                    if (overlayText.isNotBlank()) {
                        val bubbleOffset = remember(
                            cursorOffset,
                            previewSize,
                            density,
                        ) {
                            resolveAgentModeBubbleOffset(
                                cursorOffset = cursorOffset,
                                previewSize = previewSize,
                                density = density,
                            )
                        }
                        val animatedBubbleOffset by animateIntOffsetAsState(
                            targetValue = bubbleOffset,
                            animationSpec = tween(durationMillis = animationDurationMillis, easing = ChatGptMotionEasing),
                            label = "agent_mode_bubble_offset",
                        )
                        AgentModeCursorTextBubble(
                            text = overlayText,
                            workspaceDirectory = workspaceDirectory,
                            allowRootImageRead = allowRootImageRead,
                            onOpenLink = onOpenLink,
                            modifier = Modifier.offset { animatedBubbleOffset },
                        )
                    }
                }
            }
        } else {
            Text(
                text = resolvedPendingText,
                style = MaterialTheme.typography.bodySmall,
                color = ArixOnSurfaceVariant,
            )
        }
    }
}

@Composable
private fun AgentModeCursor(
    modifier: Modifier = Modifier,
) {
    Image(
        painter = painterResource(R.drawable.mouse_pointer_2_white_fill),
        contentDescription = null,
        modifier = modifier,
    )
}

@Composable
private fun AgentModeCursorTextBubble(
    text: String,
    workspaceDirectory: String,
    allowRootImageRead: Boolean,
    onOpenLink: (String) -> Unit,
    modifier: Modifier = Modifier,
) {
    val scrollState = rememberScrollState()
    LaunchedEffect(text, scrollState.maxValue) {
        if (scrollState.maxValue > 0) {
            scrollState.scrollTo(scrollState.maxValue)
        }
    }
    Box(
        modifier = modifier
            .widthIn(max = 320.dp)
            .shadow(18.dp, RoundedCornerShape(12.dp), ambientColor = ArixScrim, spotColor = ArixScrim)
            .clip(RoundedCornerShape(12.dp))
            .background(ArixSurface)
            .padding(horizontal = 14.dp, vertical = 12.dp),
    ) {
        Box(
            modifier = Modifier
                .heightIn(max = 104.dp)
                .verticalScroll(scrollState),
        ) {
            StreamingMarkdownContent(
                markdown = text,
                workspaceDirectory = workspaceDirectory,
                allowRootImageRead = allowRootImageRead,
                onLinkClick = onOpenLink,
            )
        }
    }
}

private fun resolveAgentModeCursorOffset(
    previewSize: IntSize,
    imagePaddingPx: Float,
    displayWidth: Int,
    displayHeight: Int,
    cursorX: Int?,
    cursorY: Int?,
): IntOffset {
    if (previewSize.width <= 0 || previewSize.height <= 0) return IntOffset.Zero
    val contentWidth = (previewSize.width - imagePaddingPx * 2f).coerceAtLeast(1f)
    val contentHeight = (previewSize.height - imagePaddingPx * 2f).coerceAtLeast(1f)
    val sourceWidth = displayWidth.coerceAtLeast(1)
    val sourceHeight = displayHeight.coerceAtLeast(1)
    val scale = minOf(contentWidth / sourceWidth, contentHeight / sourceHeight)
    val renderedWidth = sourceWidth * scale
    val renderedHeight = sourceHeight * scale
    val renderedLeft = imagePaddingPx + (contentWidth - renderedWidth) / 2f
    val renderedTop = imagePaddingPx + (contentHeight - renderedHeight) / 2f
    val cursorFractionX = cursorX?.let { it.toFloat() / sourceWidth } ?: 0.58f
    val cursorFractionY = cursorY?.let { it.toFloat() / sourceHeight } ?: 0.56f
    return IntOffset(
        x = (renderedLeft + renderedWidth * cursorFractionX.coerceIn(0f, 1f)).roundToInt(),
        y = (renderedTop + renderedHeight * cursorFractionY.coerceIn(0f, 1f)).roundToInt(),
    )
}

private fun resolveAgentModeBubbleOffset(
    cursorOffset: IntOffset,
    previewSize: IntSize,
    density: androidx.compose.ui.unit.Density,
): IntOffset {
    val bubbleMaxWidthPx = with(density) { 320.dp.roundToPx() }
    val bubbleMaxHeightPx = with(density) { 128.dp.roundToPx() }
    val horizontalGapPx = with(density) { 34.dp.roundToPx() }
    val verticalGapPx = with(density) { 34.dp.roundToPx() }
    val edgePaddingPx = with(density) { 8.dp.roundToPx() }
    val targetY = if (cursorOffset.y < previewSize.height / 2) {
        cursorOffset.y + verticalGapPx
    } else {
        cursorOffset.y - verticalGapPx - bubbleMaxHeightPx
    }
    return IntOffset(
        x = (cursorOffset.x + horizontalGapPx).coerceIn(
            edgePaddingPx,
            (previewSize.width - bubbleMaxWidthPx - edgePaddingPx).coerceAtLeast(edgePaddingPx),
        ),
        y = targetY.coerceIn(
            edgePaddingPx,
            (previewSize.height - edgePaddingPx).coerceAtLeast(edgePaddingPx),
        ),
    )
}

@Composable
private fun AgentModePreviewHeader(
    displayState: AgentModeDisplayState,
    label: String,
    isChrome: Boolean,
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Icon(
            imageVector = if (isChrome) Icons.Rounded.Public else LucideIcons.MousePointer2,
            contentDescription = null,
            tint = Color(0xFF6D5CFF),
            modifier = Modifier.size(16.dp),
        )
        Text(
            text = label,
            style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Medium),
            color = ArixOnSurface,
        )
        if (displayState.isLivePreviewActive) {
            Row(
                modifier = Modifier
                    .clip(RoundedCornerShape(999.dp))
                    .background(Color(0xFFE5F8EE))
                    .padding(horizontal = 8.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(5.dp),
            ) {
                Box(
                    modifier = Modifier
                        .size(6.dp)
                        .clip(CircleShape)
                        .background(Color(0xFF20A564)),
                )
                Text(
                    text = stringResource(R.string.chat_live),
                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Medium),
                    color = Color(0xFF137A49),
                )
            }
        }
        Spacer(modifier = Modifier.weight(1f))
        Text(
            text = displayState.displayId?.let {
                stringResource(R.string.agent_mode_display_id, it)
            } ?: stringResource(R.string.chat_standby),
            style = MaterialTheme.typography.labelSmall,
            color = ArixOnSurfaceVariant,
        )
    }
}

@Composable
private fun AgentModePreviewToolStatus(
    toolInvocation: ChatToolInvocation,
) {
    val label = formatPendingAgentModeToolLabel(toolInvocation)
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .background(ArixSurfaceHigh)
            .padding(horizontal = 14.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Icon(
            imageVector = when (toolInvocation.toolName.lowercase()) {
                "agent_display" -> LucideIcons.MousePointer2
                "chrome", "browser" -> Icons.Rounded.Public
                else -> Icons.Rounded.AutoAwesome
            },
            contentDescription = null,
            tint = Color(0xFF5D7CFF),
            modifier = Modifier.size(16.dp),
        )
        if (toolInvocation.isRunning) {
            ShimmerStatusText(
                text = label,
                modifier = Modifier.weight(1f),
                travelDurationMillis = 2600,
                pauseDurationMillis = 900,
            )
        } else {
            Text(
                text = label,
                modifier = Modifier.weight(1f),
                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Medium),
                color = ArixOnSurface,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }
    }
}

@Composable
private fun formatPendingAgentModeToolLabel(toolInvocation: ChatToolInvocation): String {
    val arguments = parseJsonObject(toolInvocation.argumentsJson)
    return formatPendingToolTitle(
        toolName = toolInvocation.toolName,
        isRunning = toolInvocation.isRunning,
        arguments = arguments,
    )
}

@Composable
private fun formatPendingToolTitle(
    toolName: String,
    isRunning: Boolean,
    arguments: JSONObject?,
): String {
    val context = LocalContext.current
    (context.applicationContext as? com.arix.app.ArixApplication)?.runtime?.modKernel?.toolTitles
        ?.titleFor(toolName, isRunning)?.let { return it }
    return when (toolName.lowercase()) {
    "bash" -> toolStatusLabel(isRunning, R.string.tool_title_bash_running, R.string.tool_title_bash_done)
    "read" -> toolStatusLabel(isRunning, R.string.tool_title_read_running, R.string.tool_title_read_done)
    "edit" -> toolStatusLabel(isRunning, R.string.tool_title_edit_running, R.string.tool_title_edit_done)
    "write" -> toolStatusLabel(isRunning, R.string.tool_title_write_running, R.string.tool_title_write_done)
    "grep" -> toolStatusLabel(isRunning, R.string.tool_title_grep_running, R.string.tool_title_grep_done)
    "find" -> toolStatusLabel(isRunning, R.string.tool_title_find_running, R.string.tool_title_find_done)
    "ls" -> toolStatusLabel(isRunning, R.string.tool_title_ls_running, R.string.tool_title_ls_done)
    "arix_config_get",
    "arix_config_set",
    "arix_skill_manage",
    "arix_agent_mode_manage",
    "arix_scheduled_task_manage",
    "arix_developer_manage" -> formatArixToolTitle(toolName, isRunning, arguments)
    "agent_mode" -> formatAgentDisplayToolTitle(isRunning, arguments)
    "chrome", "browser" -> formatChromeToolTitle(isRunning, arguments)
    else -> if (isRunning) {
        stringResource(R.string.tool_title_using_tool, toolName)
    } else {
        stringResource(R.string.tool_title_used_tool, toolName)
    }
    }
}

@Composable
private fun toolStatusLabel(
    isRunning: Boolean,
    runningRes: Int,
    doneRes: Int,
): String = stringResource(if (isRunning) runningRes else doneRes)

@Composable
private fun formatArgumentDrivenToolTitle(
    isRunning: Boolean,
    runningVerbRes: Int,
    doneVerbRes: Int,
    subject: String,
    fallbackRes: Int,
): String {
    val action = stringResource(if (isRunning) runningVerbRes else doneVerbRes)
    val normalizedSubject = subject.trim()
    if (normalizedSubject.isBlank()) {
        return stringResource(R.string.tool_title_action_subject, action, stringResource(fallbackRes))
    }
    val clipped = normalizedSubject.take(72)
    val displaySubject = if (normalizedSubject.length > 72) "$clipped..." else clipped
    return stringResource(R.string.tool_title_action_subject, action, displaySubject)
}

@Composable
private fun formatArixToolTitle(
    toolName: String,
    isRunning: Boolean,
    arguments: JSONObject?,
): String {
    val action = arguments?.optString("action").orEmpty().trim()
    return when (toolName.lowercase()) {
        "arix_config_get" -> formatArgumentDrivenToolTitle(isRunning, R.string.tool_title_reading, R.string.tool_title_read, formatArixCategories(arguments), R.string.tool_title_arix_settings_fallback)
        "arix_config_set" -> formatArgumentDrivenToolTitle(isRunning, R.string.tool_title_updating, R.string.tool_title_updated, arguments?.optString("category").orEmpty(), R.string.tool_title_arix_settings_fallback)
        "arix_skill_manage" -> when (action.lowercase()) {
            "install_remote" -> formatArgumentDrivenToolTitle(isRunning, R.string.tool_title_installing, R.string.tool_title_installed, arguments?.optString("url").orEmpty(), R.string.tool_title_agent_skill_fallback)
            "remove" -> formatArgumentDrivenToolTitle(isRunning, R.string.tool_title_removing, R.string.tool_title_removed, optArixString(arguments, "skill_id", "skillId"), R.string.tool_title_agent_skill_fallback)
            "set_enabled" -> formatArgumentDrivenToolTitle(isRunning, R.string.tool_title_updating, R.string.tool_title_updated, optArixString(arguments, "skill_id", "skillId"), R.string.tool_title_agent_skill_fallback)
            else -> toolStatusLabel(isRunning, R.string.tool_title_reading_agent_skills, R.string.tool_title_read_agent_skills)
        }
        "arix_mcp_manage" -> when (action.lowercase()) {
            "upsert_streamable_http", "upsert_stdio" -> formatArgumentDrivenToolTitle(isRunning, R.string.tool_title_saving, R.string.tool_title_saved, optArixString(arguments, "display_name", "displayName"), R.string.tool_title_mcp_server_fallback)
            "remove" -> formatArgumentDrivenToolTitle(isRunning, R.string.tool_title_removing, R.string.tool_title_removed, optArixString(arguments, "server_id", "serverId"), R.string.tool_title_mcp_server_fallback)
            "set_enabled" -> formatArgumentDrivenToolTitle(isRunning, R.string.tool_title_updating, R.string.tool_title_updated, optArixString(arguments, "server_id", "serverId"), R.string.tool_title_mcp_server_fallback)
            else -> toolStatusLabel(isRunning, R.string.tool_title_reading_mcp_servers, R.string.tool_title_read_mcp_servers)
        }
        "arix_agent_mode_manage" -> when (action.lowercase()) {
            "set_authorization" -> toolStatusLabel(isRunning, R.string.tool_title_updating_agent_mode_authorization, R.string.tool_title_updated_agent_mode_authorization)
            "stop_session" -> toolStatusLabel(isRunning, R.string.tool_title_stopping_agent_mode_display, R.string.tool_title_stopped_agent_mode_display)
            else -> toolStatusLabel(isRunning, R.string.tool_title_checking_agent_mode_authorization, R.string.tool_title_checked_agent_mode_authorization)
        }
        "arix_scheduled_task_manage" -> when (action.lowercase()) {
            "create" -> formatArgumentDrivenToolTitle(isRunning, R.string.tool_title_creating, R.string.tool_title_created, arguments?.optString("name").orEmpty(), R.string.tool_title_scheduled_task_fallback)
            "update" -> formatArgumentDrivenToolTitle(isRunning, R.string.tool_title_updating, R.string.tool_title_updated, optArixString(arguments, "task_id", "taskId"), R.string.tool_title_scheduled_task_fallback)
            "remove" -> formatArgumentDrivenToolTitle(isRunning, R.string.tool_title_removing, R.string.tool_title_removed, optArixString(arguments, "task_id", "taskId"), R.string.tool_title_scheduled_task_fallback)
            "set_enabled" -> formatArgumentDrivenToolTitle(isRunning, R.string.tool_title_updating, R.string.tool_title_updated, optArixString(arguments, "task_id", "taskId"), R.string.tool_title_scheduled_task_fallback)
            else -> toolStatusLabel(isRunning, R.string.tool_title_reading_scheduled_tasks, R.string.tool_title_read_scheduled_tasks)
        }
        "arix_developer_manage" -> toolStatusLabel(isRunning, R.string.tool_title_reading_arix_diagnostics, R.string.tool_title_read_arix_diagnostics)
        else -> toolStatusLabel(isRunning, R.string.tool_title_managing_arix, R.string.tool_title_managed_arix)
    }
}

@Composable
private fun formatAgentDisplayToolTitle(
    isRunning: Boolean,
    arguments: JSONObject?,
): String = when (arguments?.optString("action").orEmpty().lowercase()) {
    "list_apps", "apps", "installed_apps" -> formatArgumentDrivenToolTitle(
        isRunning = isRunning,
        runningVerbRes = R.string.tool_title_reading,
        doneVerbRes = R.string.tool_title_read,
        subject = arguments?.optString("query").orEmpty(),
        fallbackRes = R.string.tool_title_installed_apps_fallback,
    )
    "start" -> toolStatusLabel(isRunning, R.string.tool_title_starting_agent_mode_display, R.string.tool_title_started_agent_mode_display)
    "status" -> toolStatusLabel(isRunning, R.string.tool_title_checking_agent_mode_display, R.string.tool_title_checked_agent_mode_display)
    "launch" -> formatArgumentDrivenToolTitle(
        isRunning = isRunning,
        runningVerbRes = R.string.tool_title_launching,
        doneVerbRes = R.string.tool_title_launched,
        subject = arguments?.optString("target").orEmpty(),
        fallbackRes = R.string.tool_title_agent_mode_app_fallback,
    )
    "tap" -> toolStatusLabel(isRunning, R.string.tool_title_tapping_agent_mode_display, R.string.tool_title_tapped_agent_mode_display)
    "swipe" -> toolStatusLabel(isRunning, R.string.tool_title_swiping_agent_mode_display, R.string.tool_title_swiped_agent_mode_display)
    "key" -> formatArgumentDrivenToolTitle(
        isRunning = isRunning,
        runningVerbRes = R.string.tool_title_pressing,
        doneVerbRes = R.string.tool_title_pressed,
        subject = arguments?.optString("key").orEmpty(),
        fallbackRes = R.string.tool_title_agent_mode_key_fallback,
    )
    "text" -> toolStatusLabel(isRunning, R.string.tool_title_typing_agent_mode, R.string.tool_title_typed_agent_mode)
    "screenshot", "read_screen", "read", "screen" -> toolStatusLabel(isRunning, R.string.tool_title_capturing_agent_mode_display, R.string.tool_title_captured_agent_mode_display)
    "stop" -> toolStatusLabel(isRunning, R.string.tool_title_stopping_agent_mode_display, R.string.tool_title_stopped_agent_mode_display)
    else -> toolStatusLabel(isRunning, R.string.tool_title_using_agent_mode_display, R.string.tool_title_used_agent_mode_display)
}

@Composable
private fun formatChromeToolTitle(
    isRunning: Boolean,
    arguments: JSONObject?,
): String = when (arguments?.optString("action")?.trim()?.lowercase()) {
    "start" -> toolStatusLabel(
        isRunning,
        R.string.tool_title_starting_chrome,
        R.string.tool_title_started_chrome,
    )
    "status" -> toolStatusLabel(
        isRunning,
        R.string.tool_title_checking_chrome,
        R.string.tool_title_checked_chrome,
    )
    "navigate", "open" -> {
        val url = arguments?.optString("url").orEmpty().trim()
        if (url.isBlank()) {
            toolStatusLabel(
                isRunning,
                R.string.tool_title_navigating_chrome,
                R.string.tool_title_navigated_chrome,
            )
        } else {
            stringResource(
                if (isRunning) {
                    R.string.tool_title_navigating_chrome_url
                } else {
                    R.string.tool_title_navigated_chrome_url
                },
                url.take(72) + if (url.length > 72) "..." else "",
            )
        }
    }
    "tap", "click" -> toolStatusLabel(
        isRunning,
        R.string.tool_title_tapping_chrome,
        R.string.tool_title_tapped_chrome,
    )
    "swipe", "scroll" -> toolStatusLabel(
        isRunning,
        R.string.tool_title_scrolling_chrome,
        R.string.tool_title_scrolled_chrome,
    )
    "text", "type" -> toolStatusLabel(
        isRunning,
        R.string.tool_title_typing_chrome,
        R.string.tool_title_typed_chrome,
    )
    "key" -> {
        val key = arguments?.optString("key").orEmpty().trim()
        if (key.isBlank()) {
            toolStatusLabel(
                isRunning,
                R.string.tool_title_pressing_chrome,
                R.string.tool_title_pressed_chrome,
            )
        } else {
            stringResource(
                if (isRunning) {
                    R.string.tool_title_pressing_chrome_key
                } else {
                    R.string.tool_title_pressed_chrome_key
                },
                key.take(32),
            )
        }
    }
    "back" -> toolStatusLabel(
        isRunning,
        R.string.tool_title_going_back_chrome,
        R.string.tool_title_went_back_chrome,
    )
    "forward" -> toolStatusLabel(
        isRunning,
        R.string.tool_title_going_forward_chrome,
        R.string.tool_title_went_forward_chrome,
    )
    "reload" -> toolStatusLabel(
        isRunning,
        R.string.tool_title_reloading_chrome,
        R.string.tool_title_reloaded_chrome,
    )
    "evaluate", "execute_js", "get_text", "get_page_info", "find_elements", "get_readable", "get_backbone", "wait_for_dom_stable" -> toolStatusLabel(
        isRunning,
        R.string.tool_title_evaluating_chrome,
        R.string.tool_title_evaluated_chrome,
    )
    "screenshot" -> toolStatusLabel(
        isRunning,
        R.string.tool_title_capturing_chrome,
        R.string.tool_title_captured_chrome,
    )
    "stop" -> toolStatusLabel(
        isRunning,
        R.string.tool_title_stopping_chrome,
        R.string.tool_title_stopped_chrome,
    )
    else -> toolStatusLabel(
        isRunning,
        R.string.tool_title_using_chrome,
        R.string.tool_title_used_chrome,
    )
}

private fun formatArixCategories(arguments: JSONObject?): String {
    val categories = arguments?.optJSONArray("categories") ?: return ""
    return buildList {
        for (index in 0 until categories.length()) {
            val value = categories.optString(index).trim()
            if (value.isNotBlank()) add(value)
        }
    }.joinToString(",")
}

private fun optArixString(
    arguments: JSONObject?,
    primary: String,
    secondary: String,
): String = arguments?.optString(primary).orEmpty().ifBlank {
    arguments?.optString(secondary).orEmpty()
}

private fun parseJsonObject(rawValue: String): JSONObject? =
    if (rawValue.isBlank()) null else runCatching { JSONObject(rawValue) }.getOrNull()

private fun agentModePreviewBackdropBrush(): Brush = Brush.linearGradient(
    colorStops = arrayOf(
        0.00f to Color(0xFFBEEBFF),
        0.22f to Color(0xFF75C7FF),
        0.44f to Color(0xFFD5E9FF),
        0.68f to Color(0xFF83B5FF),
        1.00f to Color(0xFF4E86F7),
    ),
    start = Offset.Zero,
    end = Offset(900f, 620f),
)

@Composable
private fun ComposerActionChip(
    label: String,
    icon: ImageVector,
    onRemove: () -> Unit,
) {
    Row(
        modifier = Modifier
            .widthIn(max = 220.dp)
            .clip(RoundedCornerShape(18.dp))
            .background(Color(0xFFE8F1FF))
            .padding(start = 12.dp, end = 6.dp, top = 8.dp, bottom = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = Color(0xFF4F8CFF),
            modifier = Modifier.size(16.dp),
        )
        Text(
            text = label,
            modifier = Modifier.weight(1f, fill = false),
            style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Medium),
            color = Color(0xFF2E6FD5),
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
        )
        Box(
            modifier = Modifier
                .size(18.dp)
                .clickable(onClick = onRemove),
            contentAlignment = Alignment.Center,
        ) {
            Icon(
                imageVector = Icons.Rounded.Close,
                contentDescription = stringResource(R.string.common_remove),
                tint = Color(0xFF4F8CFF),
                modifier = Modifier.size(14.dp),
            )
        }
    }
}

@Composable
private fun ComposerPlusMenuRow(
    title: String,
    icon: ImageVector,
    iconTint: Color,
    iconContainerColor: Color,
    onClick: () -> Unit,
    selected: Boolean = false,
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(22.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 8.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Box(
            modifier = Modifier
                .size(38.dp)
                .clip(CircleShape)
                .background(iconContainerColor),
            contentAlignment = Alignment.Center,
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = iconTint,
                modifier = Modifier.size(20.dp),
            )
        }
        Text(
            text = title,
            modifier = Modifier.weight(1f),
            style = MaterialTheme.typography.bodyLarge,
            color = ArixOnSurface,
        )
        if (selected) {
            Box(
                modifier = Modifier
                    .size(24.dp)
                    .clip(CircleShape)
                    .background(ArixPrimary.copy(alpha = 0.14f)),
                contentAlignment = Alignment.Center,
            ) {
                Icon(
                    imageVector = Icons.Rounded.Check,
                    contentDescription = null,
                    tint = ArixPrimary,
                    modifier = Modifier.size(15.dp),
                )
            }
        }
    }
}
