package com.arix.app.data

import android.content.Context
import com.arix.app.runtime.AlpineRuntime
import java.io.File
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject

/**
 * v2.4.8: minimal Agent Mode controller — no hardcoded system control.
 *
 * The only capability here is capturing a screenshot via `adb shell screencap`
 * so the visual display panel renders in chat. All other device control
 * (tapping, swiping, typing, pressing keys) is done by the agent through
 * the bash tool with `adb shell input ...` commands — there is no separate
 * system_control host tool.
 *
 * First-time ADB setup (one-time, on the device):
 *   1. Settings → System → Developer options → Wireless debugging → ON
 *   2. Open "Pair device with pairing code" — note IP:PORT + 6-digit code
 *   3. In the Alpine terminal tab: arix-adb pair 127.0.0.1:PORT CODE
 *   4. Then: arix-adb connect 127.0.0.1:PORT
 */
class ArixAgentModeController(
    private val context: Context,
    private val alpineRuntimeProvider: () -> AlpineRuntime? = { null },
) {
    suspend fun execute(argumentsJson: String): String {
        val arguments = runCatching { JSONObject(argumentsJson) }.getOrNull()
            ?: return failure("Arguments were not valid JSON.")
        val action = arguments.optString("action").trim().lowercase().ifBlank { "screenshot" }
        return when (action) {
            "screenshot" -> screenshot()
            "status" -> status()
            else -> failure("Unknown action '$action'. Use 'screenshot' or 'status'.")
        }
    }

    private suspend fun status(): String {
        val runtime = alpineRuntimeProvider()
            ?: return failure("Alpine runtime is not ready. Open Settings → Alpine → install the 'ADB tools' preset.")
        val available = isAdbAvailable(runtime)
        return JSONObject().apply {
            put("ok", true)
            put("action", "status")
            put("adb_available", available)
            if (!available) {
                put("detail", "ADB is not installed. Install the 'ADB tools' preset in Settings → Alpine → Packages, then pair via Wireless debugging.")
            } else {
                put("detail", "ADB is available. Use bash with `adb shell` commands for device control.")
            }
        }.toString()
    }

    private suspend fun screenshot(): String {
        val runtime = alpineRuntimeProvider()
            ?: return failure("Alpine runtime is not ready. Cannot capture screenshot.")
        if (!isAdbAvailable(runtime)) {
            return failure("ADB is not installed. Install the 'ADB tools' preset in Settings → Alpine → Packages, then pair via Wireless debugging.")
        }
        val captureDir = File(context.filesDir, "arix-agent/captures").apply { mkdirs() }
        val timestamp = System.currentTimeMillis()
        val remotePath = "/sdcard/arix_shot_$timestamp.png"
        val localFile = File(captureDir, "shot_$timestamp.png")
        return withContext(Dispatchers.IO) {
            val command = """
                set -e
                arix-adb shell 'screencap -p $remotePath' 2>&1
                arix-adb pull '$remotePath' '${localFile.absolutePath}' 2>&1
                arix-adb shell 'rm -f $remotePath' 2>&1
            """.trimIndent()
            val result = JSONObject(runtime.executeCommand(command, runtime.homeDirectory, 30_000L))
            val ok = result.optBoolean("ok") && localFile.exists() && localFile.length() > 0
            if (!ok) {
                return@withContext failure(result.optString("stderr", "").ifBlank { "adb screencap failed. Make sure the device is paired and connected." })
            }
            JSONObject().apply {
                put("ok", true)
                put("action", "screenshot")
                put("path", localFile.absolutePath)
                put("size_bytes", localFile.length())
                put("captured_at", timestamp)
                put("detail", "Captured device screen to ${localFile.absolutePath}.")
            }.toString()
        }
    }

    private suspend fun isAdbAvailable(runtime: AlpineRuntime): Boolean = withContext(Dispatchers.IO) {
        val result = runtime.executeCommand(
            "command -v adb >/dev/null 2>&1 && command -v arix-adb >/dev/null 2>&1 && echo ok",
            runtime.homeDirectory,
            10_000L,
        )
        JSONObject(result).optBoolean("ok") &&
            JSONObject(result).optString("stdout", "").contains("ok")
    }

    private fun failure(message: String): String = JSONObject()
        .put("ok", false)
        .put("errmsg", message)
        .toString()
}
